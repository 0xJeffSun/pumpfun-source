00185ed0: bf 16 00 00 00 00 00 00  mov64 r6, r1
00185ed8: 18 01 00 00 03 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffffd
00185ee8: 79 29 08 00 00 00 00 00  ldxdw r9, [r2 + 0x8]
00185ef0: 15 09 4f 00 63 01 00 00  jeq r9, 0x163, +0x4f <custom_panic+0x2eeb8> ; branch 0x186170
00185ef8: a5 09 4e 00 a5 00 00 00  jlt r9, 0xa5, +0x4e <custom_panic+0x2eeb8> ; branch 0x186170
00185f00: 79 27 00 00 00 00 00 00  ldxdw r7, [r2 + 0x0]
00185f08: bf a1 00 00 00 00 00 00  mov64 r1, r10
00185f10: 07 01 00 00 50 ff ff ff  add64 r1, -0xb0
00185f18: bf 72 00 00 00 00 00 00  mov64 r2, r7
00185f20: b7 03 00 00 a5 00 00 00  mov64 r3, 0xa5
00185f28: 85 10 00 00 8b 1c 00 00  call 0x1c8b ; call target 0x194388, ordinal 730
00185f30: 79 a3 60 ff 00 00 00 00  ldxdw r3, [r10 - 0xa0]
00185f38: 79 a4 58 ff 00 00 00 00  ldxdw r4, [r10 - 0xa8]
00185f40: 79 a1 50 ff 00 00 00 00  ldxdw r1, [r10 - 0xb0]
00185f48: 61 a8 d8 ff 00 00 00 00  ldxw r8, [r10 - 0x28]
00185f50: 15 08 43 00 02 00 00 00  jeq r8, 0x2, +0x43 <custom_panic+0x2eeb8> ; branch 0x186170
00185f58: 7b 1a e8 fd 00 00 00 00  stxdw [r10 - 0x218], r1
00185f60: 7b 3a f0 fd 00 00 00 00  stxdw [r10 - 0x210], r3
00185f68: 7b 4a f8 fd 00 00 00 00  stxdw [r10 - 0x208], r4
00185f70: bf a1 00 00 00 00 00 00  mov64 r1, r10
00185f78: 07 01 00 00 f8 fe ff ff  add64 r1, -0x108
00185f80: bf a2 00 00 00 00 00 00  mov64 r2, r10
00185f88: 07 02 00 00 68 ff ff ff  add64 r2, -0x98
00185f90: b7 03 00 00 54 00 00 00  mov64 r3, 0x54
00185f98: 85 10 00 00 ce 5a 00 00  call 0x5ace ; call target 0x1b3610, ordinal 1021
00185fa0: 79 a1 bd ff 00 00 00 00  ldxdw r1, [r10 - 0x43]
00185fa8: 7b 1a d8 fe 00 00 00 00  stxdw [r10 - 0x128], r1
00185fb0: 79 a1 c5 ff 00 00 00 00  ldxdw r1, [r10 - 0x3b]
00185fb8: 7b 1a e0 fe 00 00 00 00  stxdw [r10 - 0x120], r1
00185fc0: 79 a1 cd ff 00 00 00 00  ldxdw r1, [r10 - 0x33]
00185fc8: 7b 1a e8 fe 00 00 00 00  stxdw [r10 - 0x118], r1
00185fd0: 61 a1 d4 ff 00 00 00 00  ldxw r1, [r10 - 0x2c]
00185fd8: 63 1a ef fe 00 00 00 00  stxw [r10 - 0x111], r1
00185fe0: 79 a1 dc ff 00 00 00 00  ldxdw r1, [r10 - 0x24]
00185fe8: 7b 1a b0 fe 00 00 00 00  stxdw [r10 - 0x150], r1
00185ff0: 79 a1 e4 ff 00 00 00 00  ldxdw r1, [r10 - 0x1c]
00185ff8: 7b 1a b8 fe 00 00 00 00  stxdw [r10 - 0x148], r1
00186000: 79 a1 ec ff 00 00 00 00  ldxdw r1, [r10 - 0x14]
00186008: 7b 1a c0 fe 00 00 00 00  stxdw [r10 - 0x140], r1
00186010: 79 a1 f4 ff 00 00 00 00  ldxdw r1, [r10 - 0xc]
00186018: 7b 1a c8 fe 00 00 00 00  stxdw [r10 - 0x138], r1
00186020: 61 a1 fc ff 00 00 00 00  ldxw r1, [r10 - 0x4]
00186028: 63 1a d0 fe 00 00 00 00  stxw [r10 - 0x130], r1
00186030: 71 a1 bc ff 00 00 00 00  ldxb r1, [r10 - 0x44]
00186038: 55 01 05 00 00 00 00 00  jne r1, 0x0, +0x5 <custom_panic+0x2edb0> ; branch 0x186068
00186040: 18 01 00 00 09 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffff7
00186050: 79 a3 f0 fd 00 00 00 00  ldxdw r3, [r10 - 0x210]
00186058: 79 a4 f8 fd 00 00 00 00  ldxdw r4, [r10 - 0x208]
00186060: 05 00 21 00 00 00 00 00  ja +0x21 <custom_panic+0x2eeb8> ; branch 0x186170
00186068: 7b 1a e0 fd 00 00 00 00  stxdw [r10 - 0x220], r1
00186070: bf a1 00 00 00 00 00 00  mov64 r1, r10
00186078: 07 01 00 00 58 fe ff ff  add64 r1, -0x1a8
00186080: bf a2 00 00 00 00 00 00  mov64 r2, r10
00186088: 07 02 00 00 f8 fe ff ff  add64 r2, -0x108
00186090: b7 03 00 00 54 00 00 00  mov64 r3, 0x54
00186098: 85 10 00 00 ae 5a 00 00  call 0x5aae ; call target 0x1b3610, ordinal 1021
001860a0: 79 a1 d8 fe 00 00 00 00  ldxdw r1, [r10 - 0x128]
001860a8: 7b 1a 38 fe 00 00 00 00  stxdw [r10 - 0x1c8], r1
001860b0: 79 a1 e0 fe 00 00 00 00  ldxdw r1, [r10 - 0x120]
001860b8: 7b 1a 40 fe 00 00 00 00  stxdw [r10 - 0x1c0], r1
001860c0: 79 a1 e8 fe 00 00 00 00  ldxdw r1, [r10 - 0x118]
001860c8: 7b 1a 48 fe 00 00 00 00  stxdw [r10 - 0x1b8], r1
001860d0: 61 a1 ef fe 00 00 00 00  ldxw r1, [r10 - 0x111]
001860d8: 63 1a 4f fe 00 00 00 00  stxw [r10 - 0x1b1], r1
001860e0: 79 a1 b0 fe 00 00 00 00  ldxdw r1, [r10 - 0x150]
001860e8: 7b 1a 10 fe 00 00 00 00  stxdw [r10 - 0x1f0], r1
001860f0: 79 a1 b8 fe 00 00 00 00  ldxdw r1, [r10 - 0x148]
001860f8: 7b 1a 18 fe 00 00 00 00  stxdw [r10 - 0x1e8], r1
00186100: 79 a1 c0 fe 00 00 00 00  ldxdw r1, [r10 - 0x140]
00186108: 7b 1a 20 fe 00 00 00 00  stxdw [r10 - 0x1e0], r1
00186110: 79 a1 c8 fe 00 00 00 00  ldxdw r1, [r10 - 0x138]
00186118: 7b 1a 28 fe 00 00 00 00  stxdw [r10 - 0x1d8], r1
00186120: 61 a1 d0 fe 00 00 00 00  ldxw r1, [r10 - 0x130]
00186128: 63 1a 30 fe 00 00 00 00  stxw [r10 - 0x1d0], r1
00186130: 15 09 16 00 a5 00 00 00  jeq r9, 0xa5, +0x16 <custom_panic+0x2ef30> ; branch 0x1861e8
00186138: 18 01 00 00 03 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffffd
00186148: b7 04 00 00 00 00 00 00  mov64 r4, 0x0
00186150: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00186158: 15 09 02 00 a6 00 00 00  jeq r9, 0xa6, +0x2 <custom_panic+0x2eeb8> ; branch 0x186170
00186160: 71 72 a5 00 00 00 00 00  ldxb r2, [r7 + 0xa5]
00186168: 15 02 0f 00 02 00 00 00  jeq r2, 0x2, +0xf <custom_panic+0x2ef30> ; branch 0x1861e8
00186170: 7b 3a 60 ff 00 00 00 00  stxdw [r10 - 0xa0], r3
00186178: 7b 4a 58 ff 00 00 00 00  stxdw [r10 - 0xa8], r4
00186180: 7b 1a 50 ff 00 00 00 00  stxdw [r10 - 0xb0], r1
00186188: bf a1 00 00 00 00 00 00  mov64 r1, r10
00186190: 07 01 00 00 00 fe ff ff  add64 r1, -0x200
00186198: bf a2 00 00 00 00 00 00  mov64 r2, r10
001861a0: 07 02 00 00 50 ff ff ff  add64 r2, -0xb0
001861a8: 85 10 00 00 41 2b 00 00  call 0x2b41 ; call target 0x19bbb8, ordinal 793
001861b0: 79 a1 00 fe 00 00 00 00  ldxdw r1, [r10 - 0x200]
001861b8: 79 a2 08 fe 00 00 00 00  ldxdw r2, [r10 - 0x1f8]
001861c0: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
001861c8: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
001861d0: b7 08 00 00 02 00 00 00  mov64 r8, 0x2
001861d8: 63 86 88 00 00 00 00 00  stxw [r6 + 0x88], r8
001861e0: 95 00 00 00 00 00 00 00  exit
001861e8: bf 61 00 00 00 00 00 00  mov64 r1, r6
001861f0: 07 01 00 00 18 00 00 00  add64 r1, 0x18
001861f8: bf a2 00 00 00 00 00 00  mov64 r2, r10
00186200: 07 02 00 00 58 fe ff ff  add64 r2, -0x1a8
00186208: b7 03 00 00 54 00 00 00  mov64 r3, 0x54
00186210: 85 10 00 00 7f 5a 00 00  call 0x5a7f ; call target 0x1b3610, ordinal 1021
00186218: 79 a1 38 fe 00 00 00 00  ldxdw r1, [r10 - 0x1c8]
00186220: 7b 16 6d 00 00 00 00 00  stxdw [r6 + 0x6d], r1
00186228: 79 a1 40 fe 00 00 00 00  ldxdw r1, [r10 - 0x1c0]
00186230: 7b 16 75 00 00 00 00 00  stxdw [r6 + 0x75], r1
00186238: 79 a1 48 fe 00 00 00 00  ldxdw r1, [r10 - 0x1b8]
00186240: 7b 16 7d 00 00 00 00 00  stxdw [r6 + 0x7d], r1
00186248: 61 a1 4f fe 00 00 00 00  ldxw r1, [r10 - 0x1b1]
00186250: 63 16 84 00 00 00 00 00  stxw [r6 + 0x84], r1
00186258: 61 a1 30 fe 00 00 00 00  ldxw r1, [r10 - 0x1d0]
00186260: 63 16 ac 00 00 00 00 00  stxw [r6 + 0xac], r1
00186268: 79 a1 28 fe 00 00 00 00  ldxdw r1, [r10 - 0x1d8]
00186270: 7b 16 a4 00 00 00 00 00  stxdw [r6 + 0xa4], r1
00186278: 79 a1 20 fe 00 00 00 00  ldxdw r1, [r10 - 0x1e0]
00186280: 7b 16 9c 00 00 00 00 00  stxdw [r6 + 0x9c], r1
00186288: 79 a1 18 fe 00 00 00 00  ldxdw r1, [r10 - 0x1e8]
00186290: 7b 16 94 00 00 00 00 00  stxdw [r6 + 0x94], r1
00186298: 79 a1 10 fe 00 00 00 00  ldxdw r1, [r10 - 0x1f0]
001862a0: 7b 16 8c 00 00 00 00 00  stxdw [r6 + 0x8c], r1
001862a8: 79 a1 e0 fd 00 00 00 00  ldxdw r1, [r10 - 0x220]
001862b0: 73 16 6c 00 00 00 00 00  stxb [r6 + 0x6c], r1
001862b8: 79 a1 f0 fd 00 00 00 00  ldxdw r1, [r10 - 0x210]
001862c0: 7b 16 10 00 00 00 00 00  stxdw [r6 + 0x10], r1
001862c8: 79 a1 f8 fd 00 00 00 00  ldxdw r1, [r10 - 0x208]
001862d0: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
001862d8: 79 a1 e8 fd 00 00 00 00  ldxdw r1, [r10 - 0x218]
001862e0: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
001862e8: 05 00 dd ff 00 00 00 00  ja -0x23 <custom_panic+0x2ef20> ; branch 0x1861d8
