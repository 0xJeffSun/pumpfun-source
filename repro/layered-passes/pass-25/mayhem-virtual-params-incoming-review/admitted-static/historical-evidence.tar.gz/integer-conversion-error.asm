0019bd08: bf 16 00 00 00 00 00 00  mov64 r6, r1
0019bd10: bf a1 00 00 00 00 00 00  mov64 r1, r10
0019bd18: 07 01 00 00 a0 ff ff ff  add64 r1, -0x60
0019bd20: 18 02 00 00 60 5f 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1b5f60 ; pointer 0x1b5f60 data80 b'\x06\x10\x00\x00c\x00\x00\x00I\x00\x00\x00!\x00\x00\x00src/lib.rssrc/de/mod.rsfailed to fill whole buffer()a Display im'
0019bd30: 85 10 00 00 3f 05 00 00  call 0x53f ; call target 0x19e730, ordinal 808
0019bd38: 18 01 00 00 10 67 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b6710 ; pointer 0x1b6710 data80 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00AccountNotSignerPermissionDeniedTokenGroupMemberno storage space'
0019bd48: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
0019bd50: bf a1 00 00 00 00 00 00  mov64 r1, r10
0019bd58: 07 01 00 00 e8 ff ff ff  add64 r1, -0x18
0019bd60: 7b 1a c8 ff 00 00 00 00  stxdw [r10 - 0x38], r1
0019bd68: 18 01 00 00 e8 b8 1a 00 00 00 00 00 00 00 00 00  lddw r1, 0x1ab8e8 ; pointer 0x1ab8e8 data80 b'\xbf!\x00\x00\x00\x00\x00\x00\x18\x02\x00\x00K\xc9\x1b\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb7\x03\x00\x00/\x00\x00\x00\x85\x10\x00\x00\xa6\x06\x00\x00\x95\x00\x00\x00\x00\x00\x00\x00\xbf&\x00\x00\x00\x00\x00\x00\xbf\x17\x00\x00\x00\x00\x00\x00\x85\x10\x00\x00I\x0e\x00\x00\xb7\x08\x00\x00\x01\x00\x00\x00'
0019bd78: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
0019bd80: bf a1 00 00 00 00 00 00  mov64 r1, r10
0019bd88: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
0019bd90: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
0019bd98: 7a 0a d8 ff 00 00 00 00  stdw [r10 - 0x28], 0x0
0019bda0: 7a 0a c0 ff 01 00 00 00  stdw [r10 - 0x40], 0x1
0019bda8: 7a 0a d0 ff 01 00 00 00  stdw [r10 - 0x30], 0x1
0019bdb0: bf a1 00 00 00 00 00 00  mov64 r1, r10
0019bdb8: 07 01 00 00 88 ff ff ff  add64 r1, -0x78
0019bdc0: bf a2 00 00 00 00 00 00  mov64 r2, r10
0019bdc8: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
0019bdd0: 85 10 00 00 8e 1e 00 00  call 0x1e8e ; call target 0x1ab248, ordinal 936
0019bdd8: b7 01 00 00 a0 00 00 00  mov64 r1, 0xa0
0019bde0: b7 02 00 00 08 00 00 00  mov64 r2, 0x8
0019bde8: 85 10 00 00 3f 76 ff ff  call -0x89c1 ; call target 0x156fe8, ordinal 583
0019bdf0: 55 00 03 00 00 00 00 00  jne r0, 0x0, +0x3 <custom_panic+0x44b58> ; branch 0x19be10
0019bdf8: b7 01 00 00 08 00 00 00  mov64 r1, 0x8
0019be00: b7 02 00 00 a0 00 00 00  mov64 r2, 0xa0
0019be08: 85 10 00 00 74 1e 00 00  call 0x1e74 ; call target 0x1ab1b0, ordinal 932
0019be10: 7a 00 00 00 02 00 00 00  stdw [r0 + 0x0], 0x2
0019be18: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
0019be20: 7b 10 20 00 00 00 00 00  stxdw [r0 + 0x20], r1
0019be28: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
0019be30: 7b 10 28 00 00 00 00 00  stxdw [r0 + 0x28], r1
0019be38: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
0019be40: 7b 10 30 00 00 00 00 00  stxdw [r0 + 0x30], r1
0019be48: 79 a1 88 ff 00 00 00 00  ldxdw r1, [r10 - 0x78]
0019be50: 7b 10 38 00 00 00 00 00  stxdw [r0 + 0x38], r1
0019be58: 79 a1 90 ff 00 00 00 00  ldxdw r1, [r10 - 0x70]
0019be60: 7b 10 40 00 00 00 00 00  stxdw [r0 + 0x40], r1
0019be68: 79 a1 98 ff 00 00 00 00  ldxdw r1, [r10 - 0x68]
0019be70: 7b 10 48 00 00 00 00 00  stxdw [r0 + 0x48], r1
0019be78: 62 00 98 00 06 10 00 00  stw [r0 + 0x98], 0x1006
0019be80: 72 00 50 00 02 00 00 00  stb [r0 + 0x50], 0x2
0019be88: 7b 06 08 00 00 00 00 00  stxdw [r6 + 0x8], r0
0019be90: 7a 06 00 00 00 00 00 00  stdw [r6 + 0x0], 0x0
0019be98: 95 00 00 00 00 00 00 00  exit
