#!/usr/bin/env python3
"""Static evidence extraction. Does not construct transactions or run programs."""
from pathlib import Path
import datetime,hashlib,json,re,struct,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'));from elf_reader import Elf
sha=lambda b:hashlib.sha256(b).hexdigest()
original=ROOT/'evidence/original/pump/deployed.so';e=Elf(original);idx={a:i for i,a in enumerate(e.entries)}
starts={'wrapper':0x1255a8,'context':0xcd3d8,'body':0x137fc0,'exit':0xcf510,'reserve-update-helper':0xa23f0,
 'curve-serialize':0x5a28,'curve-deserialize-wrapper':0x9b148,'global-deserialize-wrapper':0x15fdd0,
 'u128-multiply':0x1b55c8,'u128-divide-wrapper':0x1b4088,'integer-conversion-error':0x19bd08,
 'token-program-parser':0x13ff0,'global-decode':0x1600a8,'global-account-parser':0x96d0,
 'token-account-parser':0x2e48,'token-account-decode':0x185ed0,
 'clock-helper':0x1a0938,'event-log-helper':0x1a04f8,'event-cpi-helper':0x1a0530,
 'mint-account-parser':0x32d8,'token-account-unpack':0x194388,
 'invoke-signed-helper':0x1a1d70}
ranges={name:(a,e.entries[idx[a]+1])for name,a in starts.items()};records={name:[]for name in starts}
assembly=ROOT/'research/imported-lab/analysis/pump_fun/pump.asm'
for line in assembly.read_text().splitlines():
 m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2} )+[0-9a-f]{2})\s+(.+)',line)
 if not m:continue
 at=int(m[1],16)
 for name,(a,b)in ranges.items():
  if not a<=at<b:continue
  bs=bytes.fromhex(m[2]);assert e.b[at:at+len(bs)]==bs
  extra=[];op=e.b[at];r={'at':hex(at),'raw_hex':bs.hex(),'instruction':m[3]}
  if at in e.calls:
   r['call_target']=hex(e.calls[at]);extra.append(f'call target {e.calls[at]:#x}, ordinal {idx.get(e.calls[at])}')
  if at in e.relocations:
   reloc=e.relocations[at]
   if reloc['type']==10:r['external']=reloc['symbol'];extra.append('external '+reloc['symbol'])
   elif op==0x18:
    ptr=struct.unpack_from('<I',e.b,at+4)[0]|struct.unpack_from('<I',e.b,at+12)[0]<<32;r['pointer']=hex(ptr);r['data80_hex']=e.b[ptr:ptr+80].hex();extra.append(f'pointer {ptr:#x} data80 '+repr(e.b[ptr:ptr+80]))
  if op&7==5 and op not in [0x85,0x8d,0x95]:
   disp=struct.unpack_from('<h',e.b,at+2)[0];target=at+8+8*disp;r['branch_displacement']=disp;r['branch_target']=hex(target);extra.append(f'branch {target:#x}')
  r['annotated']=f'{at:08x}: {m[2]}  {m[3]}'+(' ; '+' ; '.join(extra)if extra else'');records[name].append(r)
windows=[]
for name,rows in records.items():
 a,b=ranges[name];assert sum(len(bytes.fromhex(x['raw_hex'])) for x in rows)==b-a
 (W/f'{name}.asm').write_text('\n'.join(x['annotated']for x in rows)+'\n')
 (W/f'{name}.json').write_text(json.dumps(rows,indent=2)+'\n')
 windows.append({'name':name,'start':hex(a),'end':hex(b),'bytes':b-a,'sha256':sha(e.b[a:b]),'all_dump_bytes_verified':True})
idl=json.loads((ROOT/'evidence/upstream/pump.json').read_text());instruction=next(x for x in idl['instructions']if x['name']=='set_mayhem_virtual_params');event=next(x for x in idl['events']if x['name']=='UpdateMayhemVirtualParamsEvent');event_type=next(x for x in idl['types']if x['name']==event['name'])
(W/'idl-excerpt.json').write_text(json.dumps({'instruction':instruction,'event':event,'event_type':event_type,'account_types':[x for x in idl['types']if x['name']in ['Global','BondingCurve']],'errors':idl['errors']},indent=2)+'\n')
dispatch=json.loads((ROOT/'evidence/dispatch-map.json').read_text())['pump'];match=dispatch['instructions']['set_mayhem_virtual_params'];assert dispatch['binary_sha256']==sha(e.b);assert match['matches'][0]['first_direct_calls'][0]['target']==starts['wrapper']
(W/'dispatch-excerpt.json').write_text(json.dumps(match,indent=2)+'\n')
baseline_rev=subprocess.check_output(['git','rev-parse','49e4ccc'],cwd=ROOT,text=True).strip()
files=subprocess.check_output(['git','ls-tree','-r','--name-only',baseline_rev,'programs/pump'],cwd=ROOT,text=True).splitlines();source=[]
for name in files:
 if not(name.endswith('.rs')or name.endswith('Cargo.toml')or name.endswith('Cargo.lock')):continue
 b=subprocess.check_output(['git','show',f'{baseline_rev}:{name}'],cwd=ROOT);assert b==(ROOT/name).read_bytes();source.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 for keep in ['programs/pump/src/lib.rs','programs/pump/src/trade_types.rs']:
  if name==keep:
   out=W/'baseline-source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
candidate=ROOT/'repro/pump/holder-nested-fortytwo/candidate.so';assert sha(candidate.read_bytes())=='c07e67b055c87da881b33c9e07bddf913d5b0beffa1cfe52169ba1bc3f6d2bbf'
refs=['evidence/upstream/pump.json','evidence/dispatch-map.json','evidence/disassembly-manifest.json','repro/pump/holder-nested-fortytwo/build-comparison.json','work/pump-global-init-recovery/notes.md','work/pump-remaining-handlers.md','work/mayhem-next-static/REPORT.md','repro/pump_fees/framework-matching/elf_reader.py']
inputs={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static only; no Mayhem initializer body/caller exploration, no fixtures, builds, transactions, RPC or main edits.','source_git_revision':baseline_rev,'baseline_source_files':source,'published_candidate_elf':{'path':str(candidate.relative_to(ROOT)),'bytes':candidate.stat().st_size,'sha256':sha(candidate.read_bytes()),'not_a_git_revision':True},'original_elf':{'path':str(original.relative_to(ROOT)),'bytes':len(e.b),'sha256':sha(e.b)},'source_assembly':{'path':str(assembly.relative_to(ROOT)),'sha256':sha(assembly.read_bytes())},'references':[{'path':p,'sha256':sha((ROOT/p).read_bytes())}for p in refs],'windows':windows,'full_bytes_equal':False,'recovered_handler_count_increment':0}
(W/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(W/'elf_reader.snapshot.py').write_bytes((ROOT/refs[-1]).read_bytes())
print(json.dumps({'windows':windows,'baseline_sources':len(source),'revision':baseline_rev,'candidate_sha256':inputs['published_candidate_elf']['sha256']},indent=2))
