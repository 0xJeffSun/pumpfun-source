#!/usr/bin/env python3
"""Seal static observations and package files. Does not execute recovered logic."""
import hashlib
import json
from pathlib import Path
import struct

W = Path(__file__).resolve().parent
inputs = json.loads((W / 'inputs.json').read_text())
windows = {x['name']: json.loads((W / (x['name'] + '.json')).read_text()) for x in inputs['windows']}
at = {int(row['at'], 16): row for rows in windows.values() for row in rows}
constraints = [
    ('sol_vault_authority', 'Mayhem PDA', 0xcdf28, 2006),
    ('sol_vault_authority', 'writable', 0xce2a0, 2000),
    ('sol_vault_authority', 'signer', 0xce318, 2002),
    ('mayhem_token_vault', 'token program', 0xce268, 2023),
    ('mayhem_token_vault', 'token authority', 0xce460, 2015),
    ('mayhem_token_vault', 'associated address', 0xce700, 2009),
    ('mayhem_token_vault', 'writable', 0xcea98, 2000),
    ('global', 'Pump PDA', 0xce968, 2006),
    ('bonding_curve', 'Pump PDA', 0xcecc0, 2006),
    ('bonding_curve', 'writable', 0xcf060, 2000),
    ('event_authority', 'Pump PDA', 0xcef28, 2006),
]
rows = []
for order, (account, check, address, error) in enumerate(constraints, 1):
    row = at[address]
    assert struct.unpack_from('<i', bytes.fromhex(row['raw_hex']), 4)[0] == error
    rows.append({'order_after_typed_parsing': order, 'account': account,
                 'constraint': check, 'error_code': error, 'evidence': row})
anchor_groups = {
    'wrapper_calls': [0x125648, 0x125750, 0x125798],
    'pda_then_mut_then_signer': [0xcdef8, 0xcdf10, 0xce168, 0xce178],
    'body_arguments': [0x137fd8, 0x137fe0, 0x138030, 0x138038, 0x138048, 0x138070],
    'no_ops': [0xa2408, 0xa2420, 0xa2500, 0xa2518, 0xa2570, 0xa2588],
    'checked_u64_denominator': [0xa2430, 0xa2438, 0xa2440, 0xa2448, 0xa2450, 0xa24e0],
    'checked_u128_product_and_division': [0xa25a8, 0xa25e8, 0xa2608, 0xa2620, 0xa2638, 0xa2640, 0xa2660, 0xa2668, 0xa2708],
    'conversion_before_cap': [0xa2788, 0xa27a8, 0xa27d0, 0xa27f0, 0x19be78, 0xa2810, 0xa2838, 0xa2848, 0xa2870],
    'clock_and_events': [0x138088, 0x1380a0, 0x1a0978, 0x138278, 0x138358, 0x1a04f8, 0x138670, 0x1387e8, 0x138988, 0x1a2068],
    'global_field_binding': [0x160368, 0x1613e8, 0x9a58, 0xcd9e0, 0xcf2d0],
    'token_amount_binding': [0x1943b8, 0x194808, 0x185f98, 0x186098, 0x186210, 0x31c0, 0xcd610, 0xcf1e0],
}
findings = {
    'scope': 'Static observations and an uncompiled body hypothesis only',
    'source_git_revision': inputs['source_git_revision'],
    'candidate_sha256': inputs['published_candidate_elf']['sha256'],
    'original_sha256': inputs['original_elf']['sha256'],
    'instruction': 'set_mayhem_virtual_params',
    'discriminator_hex': '3da9bcbf99952a61', 'argument_bytes': 0,
    'typed_parsing_precedes_constraints': True,
    'constraints': rows,
    'anchors': {group: [at[address] for address in addresses] for group, addresses in anchor_groups.items()},
    'formula': 'D = checked_u64(2*T-G-M); Q = checked_u128((u128(D)+u128(V))*u128(R))/D; VQ = min(checked_u64(Q), cap)',
    'thresholds_and_caps': {
        'all_zero_quote_mint': {'minimum_real_quote_reserves': 10000000, 'minimum_D': 1000000000000, 'cap': 2000000000000},
        'any_nonzero_quote_mint': {'minimum_real_quote_reserves': 1000000, 'minimum_D': 1000000000000, 'cap': 160000000000},
    },
    'outcome': 'No supported ordinary direct signer; retain static research only',
    'full_bytes_equal': False, 'builds': 0, 'runtime_receipts': 0, 'handler_count_increment': 0,
}
(W / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
files = []
for p in sorted(W.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts or p.name in {'manifest.json', 'verification-result.json'}:
        continue
    data = p.read_bytes()
    files.append({'path': str(p.relative_to(W)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(W / 'manifest.json').write_text(json.dumps({'schema_version': 1, 'scope': 'Static-only Pump set_mayhem_virtual_params evidence', 'files': files}, indent=2) + '\n')
print(json.dumps({'sealed_files': len(files), 'manifest_sha256': hashlib.sha256((W / 'manifest.json').read_bytes()).hexdigest()}))
