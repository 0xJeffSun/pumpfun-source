0009b148: bf 16 00 00 00 00 00 00  mov64 r6, r1
0009b150: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
0009b158: a5 01 10 00 08 00 00 00  jlt r1, 0x8, +0x10 <.text+0x9b0c0> ; branch 0x9b1e0
0009b160: 79 23 00 00 00 00 00 00  ldxdw r3, [r2 + 0x0]
0009b168: 79 34 00 00 00 00 00 00  ldxdw r4, [r3 + 0x0]
0009b170: 18 05 00 00 17 b7 f8 37 00 00 00 00 60 d8 ac 60  lddw r5, 0x60acd86037f8b717
0009b180: 1d 54 19 00 00 00 00 00  jeq r4, r5, +0x19 <.text+0x9b130> ; branch 0x9b250
0009b188: 18 01 00 00 03 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffffd
0009b198: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
0009b1a0: bf a1 00 00 00 00 00 00  mov64 r1, r10
0009b1a8: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
0009b1b0: bf a2 00 00 00 00 00 00  mov64 r2, r10
0009b1b8: 07 02 00 00 e8 ff ff ff  add64 r2, -0x18
0009b1c0: 85 10 00 00 3e 01 02 00  call 0x2013e ; call target 0x19bbb8, ordinal 793
0009b1c8: 79 a1 d8 ff 00 00 00 00  ldxdw r1, [r10 - 0x28]
0009b1d0: 79 a2 e0 ff 00 00 00 00  ldxdw r2, [r10 - 0x20]
0009b1d8: 05 00 0a 00 00 00 00 00  ja +0xa <.text+0x9b110> ; branch 0x9b230
0009b1e0: 18 01 00 00 03 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffffd
0009b1f0: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
0009b1f8: bf a1 00 00 00 00 00 00  mov64 r1, r10
0009b200: 07 01 00 00 b8 ff ff ff  add64 r1, -0x48
0009b208: bf a2 00 00 00 00 00 00  mov64 r2, r10
0009b210: 07 02 00 00 e8 ff ff ff  add64 r2, -0x18
0009b218: 85 10 00 00 33 01 02 00  call 0x20133 ; call target 0x19bbb8, ordinal 793
0009b220: 79 a1 b8 ff 00 00 00 00  ldxdw r1, [r10 - 0x48]
0009b228: 79 a2 c0 ff 00 00 00 00  ldxdw r2, [r10 - 0x40]
0009b230: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
0009b238: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
0009b240: 72 06 9d 00 02 00 00 00  stb [r6 + 0x9d], 0x2
0009b248: 95 00 00 00 00 00 00 00  exit
0009b250: 07 03 00 00 08 00 00 00  add64 r3, 0x8
0009b258: 7b 32 00 00 00 00 00 00  stxdw [r2 + 0x0], r3
0009b260: 07 01 00 00 f8 ff ff ff  add64 r1, -0x8
0009b268: 7b 12 08 00 00 00 00 00  stxdw [r2 + 0x8], r1
0009b270: a5 01 01 00 29 00 00 00  jlt r1, 0x29, +0x1 <.text+0x9b160> ; branch 0x9b280
0009b278: 05 00 0b 00 00 00 00 00  ja +0xb <.text+0x9b1b8> ; branch 0x9b2d8
0009b280: 18 01 00 00 03 00 00 00 00 00 00 00 00 00 00 80  lddw r1, -0x7ffffffffffffffd
0009b290: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
0009b298: bf a1 00 00 00 00 00 00  mov64 r1, r10
0009b2a0: 07 01 00 00 c8 ff ff ff  add64 r1, -0x38
0009b2a8: bf a2 00 00 00 00 00 00  mov64 r2, r10
0009b2b0: 07 02 00 00 e8 ff ff ff  add64 r2, -0x18
0009b2b8: 85 10 00 00 1f 01 02 00  call 0x2011f ; call target 0x19bbb8, ordinal 793
0009b2c0: 79 a1 c8 ff 00 00 00 00  ldxdw r1, [r10 - 0x38]
0009b2c8: 79 a2 d0 ff 00 00 00 00  ldxdw r2, [r10 - 0x30]
0009b2d0: 05 00 eb ff 00 00 00 00  ja -0x15 <.text+0x9b110> ; branch 0x9b230
0009b2d8: a5 01 01 00 49 00 00 00  jlt r1, 0x49, +0x1 <.text+0x9b1c8> ; branch 0x9b2e8
0009b2e0: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b1e0> ; branch 0x9b300
0009b2e8: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b2f0: 85 10 00 00 75 00 00 00  call 0x75 ; call target 0x9b6a0, ordinal 362
0009b2f8: 05 00 e9 ff 00 00 00 00  ja -0x17 <.text+0x9b128> ; branch 0x9b248
0009b300: 15 01 01 00 49 00 00 00  jeq r1, 0x49, +0x1 <.text+0x9b1f0> ; branch 0x9b310
0009b308: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b208> ; branch 0x9b328
0009b310: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b318: 85 10 00 00 21 01 00 00  call 0x121 ; call target 0x9bc28, ordinal 363
0009b320: 05 00 e4 ff 00 00 00 00  ja -0x1c <.text+0x9b128> ; branch 0x9b248
0009b328: a5 01 01 00 4b 00 00 00  jlt r1, 0x4b, +0x1 <.text+0x9b218> ; branch 0x9b338
0009b330: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b230> ; branch 0x9b350
0009b338: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b340: 85 10 00 00 df 01 00 00  call 0x1df ; call target 0x9c240, ordinal 364
0009b348: 05 00 df ff 00 00 00 00  ja -0x21 <.text+0x9b128> ; branch 0x9b248
0009b350: a5 01 01 00 6b 00 00 00  jlt r1, 0x6b, +0x1 <.text+0x9b240> ; branch 0x9b360
0009b358: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b258> ; branch 0x9b378
0009b360: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b368: 85 10 00 00 b1 02 00 00  call 0x2b1 ; call target 0x9c8f8, ordinal 365
0009b370: 05 00 da ff 00 00 00 00  ja -0x26 <.text+0x9b128> ; branch 0x9b248
0009b378: a5 01 01 00 74 00 00 00  jlt r1, 0x74, +0x1 <.text+0x9b268> ; branch 0x9b388
0009b380: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b280> ; branch 0x9b3a0
0009b388: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b390: 85 10 00 00 8e 03 00 00  call 0x38e ; call target 0x9d008, ordinal 366
0009b398: 05 00 d5 ff 00 00 00 00  ja -0x2b <.text+0x9b128> ; branch 0x9b248
0009b3a0: 15 01 01 00 74 00 00 00  jeq r1, 0x74, +0x1 <.text+0x9b290> ; branch 0x9b3b0
0009b3a8: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b2a8> ; branch 0x9b3c8
0009b3b0: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b3b8: 85 10 00 00 92 04 00 00  call 0x492 ; call target 0x9d850, ordinal 367
0009b3c0: 05 00 d0 ff 00 00 00 00  ja -0x30 <.text+0x9b128> ; branch 0x9b248
0009b3c8: a5 01 01 00 85 00 00 00  jlt r1, 0x85, +0x1 <.text+0x9b2b8> ; branch 0x9b3d8
0009b3d0: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b2d0> ; branch 0x9b3f0
0009b3d8: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b3e0: 85 10 00 00 b2 05 00 00  call 0x5b2 ; call target 0x9e178, ordinal 368
0009b3e8: 05 00 cb ff 00 00 00 00  ja -0x35 <.text+0x9b128> ; branch 0x9b248
0009b3f0: a5 01 01 00 9e 00 00 00  jlt r1, 0x9e, +0x1 <.text+0x9b2e0> ; branch 0x9b400
0009b3f8: 05 00 03 00 00 00 00 00  ja +0x3 <.text+0x9b2f8> ; branch 0x9b418
0009b400: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b408: 85 10 00 00 dc 06 00 00  call 0x6dc ; call target 0x9eaf0, ordinal 369
0009b410: 05 00 c6 ff 00 00 00 00  ja -0x3a <.text+0x9b128> ; branch 0x9b248
0009b418: bf 61 00 00 00 00 00 00  mov64 r1, r6
0009b420: 85 10 00 00 1b 08 00 00  call 0x81b ; call target 0x9f500, ordinal 370
0009b428: 05 00 c3 ff 00 00 00 00  ja -0x3d <.text+0x9b128> ; branch 0x9b248
