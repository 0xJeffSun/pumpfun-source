000cd3d8: bf 39 00 00 00 00 00 00  mov64 r9, r3
000cd3e0: bf 16 00 00 00 00 00 00  mov64 r6, r1
000cd3e8: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000cd3f0: 15 01 60 00 00 00 00 00  jeq r1, 0x0, +0x60 <.text+0xcd5d8> ; branch 0xcd6f8
000cd3f8: 79 55 08 f0 00 00 00 00  ldxdw r5, [r5 - 0xff8]
000cd400: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000cd408: 7b 19 08 00 00 00 00 00  stxdw [r9 + 0x8], r1
000cd410: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000cd418: bf 13 00 00 00 00 00 00  mov64 r3, r1
000cd420: 07 03 00 00 30 00 00 00  add64 r3, 0x30
000cd428: 7b 39 00 00 00 00 00 00  stxdw [r9 + 0x0], r3
000cd430: 79 18 08 00 00 00 00 00  ldxdw r8, [r1 + 0x8]
000cd438: 79 80 00 00 00 00 00 00  ldxdw r0, [r8 + 0x0]
000cd440: 07 00 00 00 01 00 00 00  add64 r0, 0x1
000cd448: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000cd450: 15 00 01 00 00 00 00 00  jeq r0, 0x0, +0x1 <.text+0xcd340> ; branch 0xcd460
000cd458: b7 03 00 00 00 00 00 00  mov64 r3, 0x0
000cd460: 79 14 00 00 00 00 00 00  ldxdw r4, [r1 + 0x0]
000cd468: 7b 08 00 00 00 00 00 00  stxdw [r8 + 0x0], r0
000cd470: 55 03 01 00 01 00 00 00  jne r3, 0x1, +0x1 <.text+0xcd360> ; branch 0xcd480
000cd478: 85 10 00 00 ff ff ff ff  call -0x1 ; external abort
000cd480: 79 17 10 00 00 00 00 00  ldxdw r7, [r1 + 0x10]
000cd488: 79 70 00 00 00 00 00 00  ldxdw r0, [r7 + 0x0]
000cd490: 07 00 00 00 01 00 00 00  add64 r0, 0x1
000cd498: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000cd4a0: 15 00 01 00 00 00 00 00  jeq r0, 0x0, +0x1 <.text+0xcd390> ; branch 0xcd4b0
000cd4a8: b7 03 00 00 00 00 00 00  mov64 r3, 0x0
000cd4b0: 7b 2a 70 f2 00 00 00 00  stxdw [r10 - 0xd90], r2
000cd4b8: 7b 5a 88 f2 00 00 00 00  stxdw [r10 - 0xd78], r5
000cd4c0: 7b 4a 90 f2 00 00 00 00  stxdw [r10 - 0xd70], r4
000cd4c8: 7b 07 00 00 00 00 00 00  stxdw [r7 + 0x0], r0
000cd4d0: 55 03 01 00 01 00 00 00  jne r3, 0x1, +0x1 <.text+0xcd3c0> ; branch 0xcd4e0
000cd4d8: 05 00 f3 ff 00 00 00 00  ja -0xd <.text+0xcd358> ; branch 0xcd478
000cd4e0: 71 12 2a 00 00 00 00 00  ldxb r2, [r1 + 0x2a]
000cd4e8: 7b 2a 58 f2 00 00 00 00  stxdw [r10 - 0xda8], r2
000cd4f0: 71 12 29 00 00 00 00 00  ldxb r2, [r1 + 0x29]
000cd4f8: 7b 2a 80 f2 00 00 00 00  stxdw [r10 - 0xd80], r2
000cd500: 71 12 28 00 00 00 00 00  ldxb r2, [r1 + 0x28]
000cd508: 7b 2a 78 f2 00 00 00 00  stxdw [r10 - 0xd88], r2
000cd510: 79 12 20 00 00 00 00 00  ldxdw r2, [r1 + 0x20]
000cd518: 7b 2a 60 f2 00 00 00 00  stxdw [r10 - 0xda0], r2
000cd520: 79 11 18 00 00 00 00 00  ldxdw r1, [r1 + 0x18]
000cd528: 7b 1a 68 f2 00 00 00 00  stxdw [r10 - 0xd98], r1
000cd530: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd538: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cd540: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cd548: 85 10 00 00 90 65 fe ff  call -0x19a70 ; call target 0x1d0, ordinal 1
000cd550: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cd558: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cd560: 61 a1 a8 f6 00 00 00 00  ldxw r1, [r10 - 0x958]
000cd568: 15 01 43 00 02 00 00 00  jeq r1, 0x2, +0x43 <.text+0xcd668> ; branch 0xcd788
000cd570: 7b 1a 38 f2 00 00 00 00  stxdw [r10 - 0xdc8], r1
000cd578: 7b 2a 40 f2 00 00 00 00  stxdw [r10 - 0xdc0], r2
000cd580: 7b 3a 48 f2 00 00 00 00  stxdw [r10 - 0xdb8], r3
000cd588: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cd590: 7b 1a 90 f5 00 00 00 00  stxdw [r10 - 0xa70], r1
000cd598: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cd5a0: 7b 1a 88 f5 00 00 00 00  stxdw [r10 - 0xa78], r1
000cd5a8: 79 a1 18 f6 00 00 00 00  ldxdw r1, [r10 - 0x9e8]
000cd5b0: 7b 1a 50 f2 00 00 00 00  stxdw [r10 - 0xdb0], r1
000cd5b8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd5c0: 07 01 00 00 48 f5 ff ff  add64 r1, -0xab8
000cd5c8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cd5d0: 07 02 00 00 20 f6 ff ff  add64 r2, -0x9e0
000cd5d8: b7 03 00 00 40 00 00 00  mov64 r3, 0x40
000cd5e0: 85 10 00 00 05 cc 01 00  call 0x1cc05 ; call target 0x1b3610, ordinal 1021
000cd5e8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd5f0: 07 01 00 00 00 f5 ff ff  add64 r1, -0xb00
000cd5f8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cd600: 07 02 00 00 60 f6 ff ff  add64 r2, -0x9a0
000cd608: b7 03 00 00 48 00 00 00  mov64 r3, 0x48
000cd610: 85 10 00 00 ff cb 01 00  call 0x1cbff ; call target 0x1b3610, ordinal 1021
000cd618: 79 a1 ac f6 00 00 00 00  ldxdw r1, [r10 - 0x954]
000cd620: 7b 1a d8 f4 00 00 00 00  stxdw [r10 - 0xb28], r1
000cd628: 79 a1 b4 f6 00 00 00 00  ldxdw r1, [r10 - 0x94c]
000cd630: 7b 1a e0 f4 00 00 00 00  stxdw [r10 - 0xb20], r1
000cd638: 79 a1 bc f6 00 00 00 00  ldxdw r1, [r10 - 0x944]
000cd640: 7b 1a e8 f4 00 00 00 00  stxdw [r10 - 0xb18], r1
000cd648: 79 a1 c4 f6 00 00 00 00  ldxdw r1, [r10 - 0x93c]
000cd650: 7b 1a f0 f4 00 00 00 00  stxdw [r10 - 0xb10], r1
000cd658: 61 a1 cc f6 00 00 00 00  ldxw r1, [r10 - 0x934]
000cd660: 63 1a f8 f4 00 00 00 00  stxw [r10 - 0xb08], r1
000cd668: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd670: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cd678: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cd680: 85 10 00 00 80 65 fe ff  call -0x19a80 ; call target 0x288, ordinal 2
000cd688: 61 a1 f8 f5 00 00 00 00  ldxw r1, [r10 - 0xa08]
000cd690: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0xcd580> ; branch 0xcd6a0
000cd698: 05 00 37 00 00 00 00 00  ja +0x37 <.text+0xcd738> ; branch 0xcd858
000cd6a0: 79 a3 08 f6 00 00 00 00  ldxdw r3, [r10 - 0x9f8]
000cd6a8: 79 a2 00 f6 00 00 00 00  ldxdw r2, [r10 - 0xa00]
000cd6b0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd6b8: 07 01 00 00 c8 f2 ff ff  add64 r1, -0xd38
000cd6c0: 18 04 00 00 48 5f 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b5f48 ; pointer 0x1b5f48 data80 b'mint@\x00\x00\x00Z\x00\x00\x00\x1a\x00\x00\x00H\x00\x00\x00a\x00\x00\x00\x06\x10\x00\x00c\x00\x00\x00I\x00\x00\x00!\x00\x00\x00src/lib.rssrc/de/mod.rsfailed to fill wh'
000cd6d0: b7 05 00 00 04 00 00 00  mov64 r5, 0x4
000cd6d8: 85 10 00 00 4a 6a fe ff  call -0x195b6 ; call target 0x2930, ordinal 10
000cd6e0: 79 a1 c8 f2 00 00 00 00  ldxdw r1, [r10 - 0xd38]
000cd6e8: 79 a2 d0 f2 00 00 00 00  ldxdw r2, [r10 - 0xd30]
000cd6f0: 05 00 1a 00 00 00 00 00  ja +0x1a <.text+0xcd6a8> ; branch 0xcd7c8
000cd6f8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd700: 07 01 00 00 a8 f2 ff ff  add64 r1, -0xd58
000cd708: b7 02 00 00 bd 0b 00 00  mov64 r2, 0xbbd
000cd710: 85 10 00 00 81 a3 01 00  call 0x1a381 ; call target 0x19f320, ordinal 809
000cd718: 79 a3 b0 f2 00 00 00 00  ldxdw r3, [r10 - 0xd50]
000cd720: 79 a2 a8 f2 00 00 00 00  ldxdw r2, [r10 - 0xd58]
000cd728: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd730: 07 01 00 00 98 f2 ff ff  add64 r1, -0xd68
000cd738: 18 04 00 00 96 77 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7796 ; pointer 0x1b7796 data80 b'sol_vault_authoritywithdraw_authoritypool_authority_mint_accountpool_authority_w'
000cd748: b7 05 00 00 13 00 00 00  mov64 r5, 0x13
000cd750: 85 10 00 00 3b 6a fe ff  call -0x195c5 ; call target 0x2930, ordinal 10
000cd758: 79 a1 98 f2 00 00 00 00  ldxdw r1, [r10 - 0xd68]
000cd760: 79 a2 a0 f2 00 00 00 00  ldxdw r2, [r10 - 0xd60]
000cd768: 7b 26 10 00 00 00 00 00  stxdw [r6 + 0x10], r2
000cd770: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000cd778: 62 06 00 00 02 00 00 00  stw [r6 + 0x0], 0x2
000cd780: 05 00 19 00 00 00 00 00  ja +0x19 <.text+0xcd730> ; branch 0xcd850
000cd788: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd790: 07 01 00 00 b8 f2 ff ff  add64 r1, -0xd48
000cd798: 18 04 00 00 71 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7571 ; pointer 0x1b7571 data80 b'mayhem_token_vaultglobal_paramsmint_authoritytoken_programnot implemented: admin'
000cd7a8: b7 05 00 00 12 00 00 00  mov64 r5, 0x12
000cd7b0: 85 10 00 00 2f 6a fe ff  call -0x195d1 ; call target 0x2930, ordinal 10
000cd7b8: 79 a1 b8 f2 00 00 00 00  ldxdw r1, [r10 - 0xd48]
000cd7c0: 79 a2 c0 f2 00 00 00 00  ldxdw r2, [r10 - 0xd40]
000cd7c8: 7b 26 10 00 00 00 00 00  stxdw [r6 + 0x10], r2
000cd7d0: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000cd7d8: 62 06 00 00 02 00 00 00  stw [r6 + 0x0], 0x2
000cd7e0: 79 81 00 00 00 00 00 00  ldxdw r1, [r8 + 0x0]
000cd7e8: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000cd7f0: 7b 18 00 00 00 00 00 00  stxdw [r8 + 0x0], r1
000cd7f8: 55 01 03 00 00 00 00 00  jne r1, 0x0, +0x3 <.text+0xcd6f8> ; branch 0xcd818
000cd800: 79 81 08 00 00 00 00 00  ldxdw r1, [r8 + 0x8]
000cd808: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000cd810: 7b 18 08 00 00 00 00 00  stxdw [r8 + 0x8], r1
000cd818: 79 71 00 00 00 00 00 00  ldxdw r1, [r7 + 0x0]
000cd820: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000cd828: 7b 17 00 00 00 00 00 00  stxdw [r7 + 0x0], r1
000cd830: 55 01 03 00 00 00 00 00  jne r1, 0x0, +0x3 <.text+0xcd730> ; branch 0xcd850
000cd838: 79 71 08 00 00 00 00 00  ldxdw r1, [r7 + 0x8]
000cd840: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000cd848: 7b 17 08 00 00 00 00 00  stxdw [r7 + 0x8], r1
000cd850: 95 00 00 00 00 00 00 00  exit
000cd858: 7b 1a 28 f2 00 00 00 00  stxdw [r10 - 0xdd8], r1
000cd860: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cd868: 7b 1a 10 f2 00 00 00 00  stxdw [r10 - 0xdf0], r1
000cd870: 79 a1 00 f6 00 00 00 00  ldxdw r1, [r10 - 0xa00]
000cd878: 7b 1a 18 f2 00 00 00 00  stxdw [r10 - 0xde8], r1
000cd880: 61 a1 fc f5 00 00 00 00  ldxw r1, [r10 - 0xa04]
000cd888: 7b 1a 20 f2 00 00 00 00  stxdw [r10 - 0xde0], r1
000cd890: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd898: 07 01 00 00 b8 f5 ff ff  add64 r1, -0xa48
000cd8a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cd8a8: 07 02 00 00 10 f6 ff ff  add64 r2, -0x9f0
000cd8b0: b7 03 00 00 40 00 00 00  mov64 r3, 0x40
000cd8b8: 85 10 00 00 aa cb 01 00  call 0x1cbaa ; call target 0x1b3610, ordinal 1021
000cd8c0: 79 a1 58 f6 00 00 00 00  ldxdw r1, [r10 - 0x9a8]
000cd8c8: 7b 1a 98 f5 00 00 00 00  stxdw [r10 - 0xa68], r1
000cd8d0: 79 a1 60 f6 00 00 00 00  ldxdw r1, [r10 - 0x9a0]
000cd8d8: 7b 1a a0 f5 00 00 00 00  stxdw [r10 - 0xa60], r1
000cd8e0: 79 a1 68 f6 00 00 00 00  ldxdw r1, [r10 - 0x998]
000cd8e8: 7b 1a a8 f5 00 00 00 00  stxdw [r10 - 0xa58], r1
000cd8f0: 79 a1 70 f6 00 00 00 00  ldxdw r1, [r10 - 0x990]
000cd8f8: 7b 1a b0 f5 00 00 00 00  stxdw [r10 - 0xa50], r1
000cd900: 79 a1 50 f6 00 00 00 00  ldxdw r1, [r10 - 0x9b0]
000cd908: 7b 1a 30 f2 00 00 00 00  stxdw [r10 - 0xdd0], r1
000cd910: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd918: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cd920: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cd928: 85 10 00 00 28 8b fe ff  call -0x174d8 ; call target 0x13270, ordinal 129
000cd930: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cd938: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cd940: 71 a1 37 fa 00 00 00 00  ldxb r1, [r10 - 0x5c9]
000cd948: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0xcd838> ; branch 0xcd958
000cd950: 05 00 09 00 00 00 00 00  ja +0x9 <.text+0xcd880> ; branch 0xcd9a0
000cd958: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd960: 07 01 00 00 d8 f2 ff ff  add64 r1, -0xd28
000cd968: 18 04 00 00 26 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7326 ; pointer 0x1b7326 data80 b'globalevent_authorityprogram_signeridl_accountprogramsystem_programauthorityfee_'
000cd978: b7 05 00 00 06 00 00 00  mov64 r5, 0x6
000cd980: 85 10 00 00 f5 69 fe ff  call -0x1960b ; call target 0x2930, ordinal 10
000cd988: 79 a1 d8 f2 00 00 00 00  ldxdw r1, [r10 - 0xd28]
000cd990: 79 a2 e0 f2 00 00 00 00  ldxdw r2, [r10 - 0xd20]
000cd998: 05 00 c5 ff 00 00 00 00  ja -0x3b <.text+0xcd6a8> ; branch 0xcd7c8
000cd9a0: 7b 1a f8 f1 00 00 00 00  stxdw [r10 - 0xe08], r1
000cd9a8: 7b 2a 08 f2 00 00 00 00  stxdw [r10 - 0xdf8], r2
000cd9b0: 7b 3a 00 f2 00 00 00 00  stxdw [r10 - 0xe00], r3
000cd9b8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd9c0: 07 01 00 00 38 fa ff ff  add64 r1, -0x5c8
000cd9c8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cd9d0: 07 02 00 00 08 f6 ff ff  add64 r2, -0x9f8
000cd9d8: b7 03 00 00 2f 04 00 00  mov64 r3, 0x42f
000cd9e0: 85 10 00 00 85 cb 01 00  call 0x1cb85 ; call target 0x1b3610, ordinal 1021
000cd9e8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cd9f0: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cd9f8: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cda00: 85 10 00 00 c8 8a fe ff  call -0x17538 ; call target 0x13048, ordinal 126
000cda08: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cda10: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cda18: 71 a1 9d f6 00 00 00 00  ldxb r1, [r10 - 0x963]
000cda20: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0xcd910> ; branch 0xcda30
000cda28: 05 00 09 00 00 00 00 00  ja +0x9 <.text+0xcd958> ; branch 0xcda78
000cda30: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cda38: 07 01 00 00 e8 f2 ff ff  add64 r1, -0xd18
000cda40: 18 04 00 00 d8 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b73d8 ; pointer 0x1b73d8 data80 b'bonding_curveassociated_base_bonding_curveassociated_quote_bonding_curveassociat'
000cda50: b7 05 00 00 0d 00 00 00  mov64 r5, 0xd
000cda58: 85 10 00 00 da 69 fe ff  call -0x19626 ; call target 0x2930, ordinal 10
000cda60: 79 a1 e8 f2 00 00 00 00  ldxdw r1, [r10 - 0xd18]
000cda68: 79 a2 f0 f2 00 00 00 00  ldxdw r2, [r10 - 0xd10]
000cda70: 05 00 aa ff 00 00 00 00  ja -0x56 <.text+0xcd6a8> ; branch 0xcd7c8
000cda78: 7b 1a e0 f1 00 00 00 00  stxdw [r10 - 0xe20], r1
000cda80: 7b 2a f0 f1 00 00 00 00  stxdw [r10 - 0xe10], r2
000cda88: 7b 3a e8 f1 00 00 00 00  stxdw [r10 - 0xe18], r3
000cda90: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cda98: 07 01 00 00 68 fe ff ff  add64 r1, -0x198
000cdaa0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cdaa8: 07 02 00 00 08 f6 ff ff  add64 r2, -0x9f8
000cdab0: b7 03 00 00 95 00 00 00  mov64 r3, 0x95
000cdab8: 85 10 00 00 6a cb 01 00  call 0x1cb6a ; call target 0x1b3610, ordinal 1021
000cdac0: 69 a1 9e f6 00 00 00 00  ldxh r1, [r10 - 0x962]
000cdac8: 7b 1a d8 f1 00 00 00 00  stxdw [r10 - 0xe28], r1
000cdad0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdad8: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cdae0: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cdae8: 85 10 00 00 a0 8c fe ff  call -0x17360 ; call target 0x13ff0, ordinal 139
000cdaf0: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cdaf8: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cdb00: 15 02 01 00 02 00 00 00  jeq r2, 0x2, +0x1 <.text+0xcd9f0> ; branch 0xcdb10
000cdb08: 05 00 13 00 00 00 00 00  ja +0x13 <.text+0xcda88> ; branch 0xcdba8
000cdb10: 7b 3a d0 f1 00 00 00 00  stxdw [r10 - 0xe30], r3
000cdb18: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdb20: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cdb28: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cdb30: 85 10 00 00 2e 6a fe ff  call -0x195d2 ; call target 0x2ca8, ordinal 12
000cdb38: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cdb40: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cdb48: 71 a1 22 f6 00 00 00 00  ldxb r1, [r10 - 0x9de]
000cdb50: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0xcda40> ; branch 0xcdb60
000cdb58: 05 00 12 00 00 00 00 00  ja +0x12 <.text+0xcdad0> ; branch 0xcdbf0
000cdb60: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdb68: 07 01 00 00 f8 f2 ff ff  add64 r1, -0xd08
000cdb70: 18 04 00 00 2c 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b732c ; pointer 0x1b732c data80 b'event_authorityprogram_signeridl_accountprogramsystem_programauthorityfee_recipi'
000cdb80: b7 05 00 00 0f 00 00 00  mov64 r5, 0xf
000cdb88: 85 10 00 00 b4 69 fe ff  call -0x1964c ; call target 0x2930, ordinal 10
000cdb90: 79 a1 f8 f2 00 00 00 00  ldxdw r1, [r10 - 0xd08]
000cdb98: 79 a2 00 f3 00 00 00 00  ldxdw r2, [r10 - 0xd00]
000cdba0: 05 00 84 ff 00 00 00 00  ja -0x7c <.text+0xcd6a8> ; branch 0xcd7c8
000cdba8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdbb0: 07 01 00 00 c8 f4 ff ff  add64 r1, -0xb38
000cdbb8: 18 04 00 00 9e 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b759e ; pointer 0x1b759e data80 b'token_programnot implemented: admin_set_creator_authoritycurrent_creator_quote_t'
000cdbc8: b7 05 00 00 0d 00 00 00  mov64 r5, 0xd
000cdbd0: 85 10 00 00 ab 69 fe ff  call -0x19655 ; call target 0x2930, ordinal 10
000cdbd8: 79 a1 c8 f4 00 00 00 00  ldxdw r1, [r10 - 0xb38]
000cdbe0: 79 a2 d0 f4 00 00 00 00  ldxdw r2, [r10 - 0xb30]
000cdbe8: 05 00 7b ff 00 00 00 00  ja -0x85 <.text+0xcd6a8> ; branch 0xcd7c8
000cdbf0: 7b 1a b0 f1 00 00 00 00  stxdw [r10 - 0xe50], r1
000cdbf8: 7b 2a b8 f1 00 00 00 00  stxdw [r10 - 0xe48], r2
000cdc00: 7b 3a c8 f1 00 00 00 00  stxdw [r10 - 0xe38], r3
000cdc08: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cdc10: 7b 1a 08 ff 00 00 00 00  stxdw [r10 - 0xf8], r1
000cdc18: 79 a1 18 f6 00 00 00 00  ldxdw r1, [r10 - 0x9e8]
000cdc20: 7b 1a 10 ff 00 00 00 00  stxdw [r10 - 0xf0], r1
000cdc28: 69 a1 20 f6 00 00 00 00  ldxh r1, [r10 - 0x9e0]
000cdc30: 6b 1a 18 ff 00 00 00 00  stxh [r10 - 0xe8], r1
000cdc38: 61 a1 23 f6 00 00 00 00  ldxw r1, [r10 - 0x9dd]
000cdc40: 63 1a 00 ff 00 00 00 00  stxw [r10 - 0x100], r1
000cdc48: 71 a1 27 f6 00 00 00 00  ldxb r1, [r10 - 0x9d9]
000cdc50: 73 1a 04 ff 00 00 00 00  stxb [r10 - 0xfc], r1
000cdc58: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cdc60: 7b 1a c0 f1 00 00 00 00  stxdw [r10 - 0xe40], r1
000cdc68: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdc70: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cdc78: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cdc80: 85 10 00 00 04 6a fe ff  call -0x195fc ; call target 0x2ca8, ordinal 12
000cdc88: 79 a3 00 f6 00 00 00 00  ldxdw r3, [r10 - 0xa00]
000cdc90: 79 a2 f8 f5 00 00 00 00  ldxdw r2, [r10 - 0xa08]
000cdc98: 71 a1 22 f6 00 00 00 00  ldxb r1, [r10 - 0x9de]
000cdca0: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0xcdb90> ; branch 0xcdcb0
000cdca8: 05 00 0d 00 00 00 00 00  ja +0xd <.text+0xcdbf8> ; branch 0xcdd18
000cdcb0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdcb8: 07 01 00 00 08 f3 ff ff  add64 r1, -0xcf8
000cdcc0: 18 04 00 00 54 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7354 ; pointer 0x1b7354 data80 b'programsystem_programauthorityfee_recipientassociated_quote_fee_recipientbuyback'
000cdcd0: b7 05 00 00 07 00 00 00  mov64 r5, 0x7
000cdcd8: 85 10 00 00 8a 69 fe ff  call -0x19676 ; call target 0x2930, ordinal 10
000cdce0: 79 a1 08 f3 00 00 00 00  ldxdw r1, [r10 - 0xcf8]
000cdce8: 79 a2 10 f3 00 00 00 00  ldxdw r2, [r10 - 0xcf0]
000cdcf0: 7b 26 10 00 00 00 00 00  stxdw [r6 + 0x10], r2
000cdcf8: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000cdd00: 62 06 00 00 02 00 00 00  stw [r6 + 0x0], 0x2
000cdd08: 79 a2 c8 f1 00 00 00 00  ldxdw r2, [r10 - 0xe38]
000cdd10: 05 00 79 00 00 00 00 00  ja +0x79 <.text+0xcdfc0> ; branch 0xce0e0
000cdd18: 7b 1a 90 f1 00 00 00 00  stxdw [r10 - 0xe70], r1
000cdd20: 7b 2a 98 f1 00 00 00 00  stxdw [r10 - 0xe68], r2
000cdd28: 7b 3a a8 f1 00 00 00 00  stxdw [r10 - 0xe58], r3
000cdd30: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cdd38: 7b 1a 28 ff 00 00 00 00  stxdw [r10 - 0xd8], r1
000cdd40: 79 a1 18 f6 00 00 00 00  ldxdw r1, [r10 - 0x9e8]
000cdd48: 7b 1a 30 ff 00 00 00 00  stxdw [r10 - 0xd0], r1
000cdd50: 69 a1 20 f6 00 00 00 00  ldxh r1, [r10 - 0x9e0]
000cdd58: 6b 1a 38 ff 00 00 00 00  stxh [r10 - 0xc8], r1
000cdd60: 61 a1 23 f6 00 00 00 00  ldxw r1, [r10 - 0x9dd]
000cdd68: 63 1a 20 ff 00 00 00 00  stxw [r10 - 0xe0], r1
000cdd70: 71 a1 27 f6 00 00 00 00  ldxb r1, [r10 - 0x9d9]
000cdd78: 73 1a 24 ff 00 00 00 00  stxb [r10 - 0xdc], r1
000cdd80: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cdd88: 7b 1a a0 f1 00 00 00 00  stxdw [r10 - 0xe60], r1
000cdd90: 18 01 00 00 4e 03 45 59 00 00 00 00 80 3d 65 a3  lddw r1, -0x5c9ac27fa6bafcb2
000cdda0: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000cdda8: 18 01 00 00 5a d4 a0 67 00 00 00 00 16 60 67 4c  lddw r1, 0x4c67601667a0d45a
000cddb8: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
000cddc0: 18 01 00 00 a6 ea b0 a7 00 00 00 00 29 54 91 85  lddw r1, -0x7a6eabd6584f155a
000cddd0: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
000cddd8: 18 01 00 00 05 2a e5 d7 00 00 00 00 a7 da a7 24  lddw r1, 0x24a7daa7d7e52a05
000cdde8: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000cddf0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cddf8: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cde00: bf a4 00 00 00 00 00 00  mov64 r4, r10
000cde08: 07 04 00 00 e0 ff ff ff  add64 r4, -0x20
000cde10: 18 02 00 00 68 df 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1bdf68 ; pointer 0x1bdf68 data80 b'\x00\x00\x00\x00Gu\x1b\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xabu\x1b\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00Cv\x1b\x00\r\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf7k\x1b\x004\x00\x00\x00\x00\x00\x00\x00\xd9\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xf5n\x1b\x00'
000cde20: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000cde28: 85 10 00 00 11 b4 01 00  call 0x1b411 ; call target 0x1a7eb8, ordinal 885
000cde30: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cde38: 7b 1a 58 ff 00 00 00 00  stxdw [r10 - 0xa8], r1
000cde40: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cde48: 7b 1a 50 ff 00 00 00 00  stxdw [r10 - 0xb0], r1
000cde50: 79 a1 00 f6 00 00 00 00  ldxdw r1, [r10 - 0xa00]
000cde58: 7b 1a 48 ff 00 00 00 00  stxdw [r10 - 0xb8], r1
000cde60: 79 a1 f8 f5 00 00 00 00  ldxdw r1, [r10 - 0xa08]
000cde68: 7b 1a 40 ff 00 00 00 00  stxdw [r10 - 0xc0], r1
000cde70: 71 a1 18 f6 00 00 00 00  ldxb r1, [r10 - 0x9e8]
000cde78: 79 a2 88 f2 00 00 00 00  ldxdw r2, [r10 - 0xd78]
000cde80: 73 12 00 00 00 00 00 00  stxb [r2 + 0x0], r1
000cde88: 79 a9 90 f2 00 00 00 00  ldxdw r9, [r10 - 0xd70]
000cde90: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000cde98: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000cdea0: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000cdea8: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000cdeb0: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000cdeb8: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000cdec0: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000cdec8: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000cded0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cded8: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cdee0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cdee8: 07 02 00 00 40 ff ff ff  add64 r2, -0xc0
000cdef0: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000cdef8: 85 10 00 00 ef ca 01 00  call 0x1caef ; call target 0x1b3678, ordinal 1024
000cdf00: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000cdf08: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000cdf10: 15 00 49 00 00 00 00 00  jeq r0, 0x0, +0x49 <.text+0xce040> ; branch 0xce160
000cdf18: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdf20: 07 01 00 00 b8 f4 ff ff  add64 r1, -0xb48
000cdf28: b7 02 00 00 d6 07 00 00  mov64 r2, 0x7d6
000cdf30: 85 10 00 00 7d a2 01 00  call 0x1a27d ; call target 0x19f320, ordinal 809
000cdf38: 79 a3 c0 f4 00 00 00 00  ldxdw r3, [r10 - 0xb40]
000cdf40: 79 a2 b8 f4 00 00 00 00  ldxdw r2, [r10 - 0xb48]
000cdf48: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cdf50: 07 01 00 00 a8 f4 ff ff  add64 r1, -0xb58
000cdf58: 18 04 00 00 96 77 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7796 ; pointer 0x1b7796 data80 b'sol_vault_authoritywithdraw_authoritypool_authority_mint_accountpool_authority_w'
000cdf68: b7 05 00 00 13 00 00 00  mov64 r5, 0x13
000cdf70: 85 10 00 00 37 69 fe ff  call -0x196c9 ; call target 0x2930, ordinal 10
000cdf78: 79 a3 b0 f4 00 00 00 00  ldxdw r3, [r10 - 0xb50]
000cdf80: 79 a2 a8 f4 00 00 00 00  ldxdw r2, [r10 - 0xb58]
000cdf88: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000cdf90: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000cdf98: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000cdfa0: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000cdfa8: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000cdfb0: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000cdfb8: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000cdfc0: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000cdfc8: 79 a1 40 ff 00 00 00 00  ldxdw r1, [r10 - 0xc0]
000cdfd0: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000cdfd8: 79 a1 48 ff 00 00 00 00  ldxdw r1, [r10 - 0xb8]
000cdfe0: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000cdfe8: 79 a1 50 ff 00 00 00 00  ldxdw r1, [r10 - 0xb0]
000cdff0: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000cdff8: 79 a1 58 ff 00 00 00 00  ldxdw r1, [r10 - 0xa8]
000ce000: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000ce008: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce010: 07 01 00 00 98 f4 ff ff  add64 r1, -0xb68
000ce018: bf a4 00 00 00 00 00 00  mov64 r4, r10
000ce020: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000ce028: 85 10 00 00 31 9c 01 00  call 0x19c31 ; call target 0x19c1b8, ordinal 798
000ce030: 79 a1 98 f4 00 00 00 00  ldxdw r1, [r10 - 0xb68]
000ce038: 79 a2 a0 f4 00 00 00 00  ldxdw r2, [r10 - 0xb60]
000ce040: 7b 26 10 00 00 00 00 00  stxdw [r6 + 0x10], r2
000ce048: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000ce050: 62 06 00 00 02 00 00 00  stw [r6 + 0x0], 0x2
000ce058: 79 a3 a8 f1 00 00 00 00  ldxdw r3, [r10 - 0xe58]
000ce060: 79 31 00 00 00 00 00 00  ldxdw r1, [r3 + 0x0]
000ce068: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce070: 7b 13 00 00 00 00 00 00  stxdw [r3 + 0x0], r1
000ce078: 79 a2 c8 f1 00 00 00 00  ldxdw r2, [r10 - 0xe38]
000ce080: 55 01 03 00 00 00 00 00  jne r1, 0x0, +0x3 <.text+0xcdf80> ; branch 0xce0a0
000ce088: 79 31 08 00 00 00 00 00  ldxdw r1, [r3 + 0x8]
000ce090: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce098: 7b 13 08 00 00 00 00 00  stxdw [r3 + 0x8], r1
000ce0a0: 79 a3 a0 f1 00 00 00 00  ldxdw r3, [r10 - 0xe60]
000ce0a8: 79 31 00 00 00 00 00 00  ldxdw r1, [r3 + 0x0]
000ce0b0: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce0b8: 7b 13 00 00 00 00 00 00  stxdw [r3 + 0x0], r1
000ce0c0: 55 01 03 00 00 00 00 00  jne r1, 0x0, +0x3 <.text+0xcdfc0> ; branch 0xce0e0
000ce0c8: 79 31 08 00 00 00 00 00  ldxdw r1, [r3 + 0x8]
000ce0d0: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce0d8: 7b 13 08 00 00 00 00 00  stxdw [r3 + 0x8], r1
000ce0e0: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ce0e8: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce0f0: 7b 12 00 00 00 00 00 00  stxdw [r2 + 0x0], r1
000ce0f8: 55 01 03 00 00 00 00 00  jne r1, 0x0, +0x3 <.text+0xcdff8> ; branch 0xce118
000ce100: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ce108: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce110: 7b 12 08 00 00 00 00 00  stxdw [r2 + 0x8], r1
000ce118: 79 a2 c0 f1 00 00 00 00  ldxdw r2, [r10 - 0xe40]
000ce120: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ce128: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce130: 7b 12 00 00 00 00 00 00  stxdw [r2 + 0x0], r1
000ce138: 55 01 d4 fe 00 00 00 00  jne r1, 0x0, -0x12c <.text+0xcd6c0> ; branch 0xcd7e0
000ce140: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ce148: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000ce150: 7b 12 08 00 00 00 00 00  stxdw [r2 + 0x8], r1
000ce158: 05 00 d0 fe 00 00 00 00  ja -0x130 <.text+0xcd6c0> ; branch 0xcd7e0
000ce160: 79 a1 80 f2 00 00 00 00  ldxdw r1, [r10 - 0xd80]
000ce168: 15 01 24 00 00 00 00 00  jeq r1, 0x0, +0x24 <.text+0xce170> ; branch 0xce290
000ce170: 79 a1 78 f2 00 00 00 00  ldxdw r1, [r10 - 0xd88]
000ce178: 15 01 31 00 00 00 00 00  jeq r1, 0x0, +0x31 <.text+0xce1e8> ; branch 0xce308
000ce180: 79 a1 d0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe30]
000ce188: 79 11 00 00 00 00 00 00  ldxdw r1, [r1 + 0x0]
000ce190: 79 12 18 00 00 00 00 00  ldxdw r2, [r1 + 0x18]
000ce198: 7b 2a 78 ff 00 00 00 00  stxdw [r10 - 0x88], r2
000ce1a0: 79 12 10 00 00 00 00 00  ldxdw r2, [r1 + 0x10]
000ce1a8: 7b 2a 70 ff 00 00 00 00  stxdw [r10 - 0x90], r2
000ce1b0: 79 12 08 00 00 00 00 00  ldxdw r2, [r1 + 0x8]
000ce1b8: 7b 2a 68 ff 00 00 00 00  stxdw [r10 - 0x98], r2
000ce1c0: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
000ce1c8: 7b 2a 60 ff 00 00 00 00  stxdw [r10 - 0xa0], r2
000ce1d0: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
000ce1d8: 7b 2a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r2
000ce1e0: 79 12 08 00 00 00 00 00  ldxdw r2, [r1 + 0x8]
000ce1e8: 7b 2a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r2
000ce1f0: 79 12 10 00 00 00 00 00  ldxdw r2, [r1 + 0x10]
000ce1f8: 7b 2a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r2
000ce200: 79 11 18 00 00 00 00 00  ldxdw r1, [r1 + 0x18]
000ce208: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce210: 79 a9 50 f2 00 00 00 00  ldxdw r9, [r10 - 0xdb0]
000ce218: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000ce220: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ce228: 07 02 00 00 f8 f5 ff ff  add64 r2, -0xa08
000ce230: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ce238: 85 10 00 00 87 ca 01 00  call 0x1ca87 ; call target 0x1b3678, ordinal 1024
000ce240: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000ce248: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000ce250: 15 00 25 00 00 00 00 00  jeq r0, 0x0, +0x25 <.text+0xce260> ; branch 0xce380
000ce258: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce260: 07 01 00 00 88 f4 ff ff  add64 r1, -0xb78
000ce268: b7 02 00 00 e7 07 00 00  mov64 r2, 0x7e7
000ce270: 85 10 00 00 15 a2 01 00  call 0x1a215 ; call target 0x19f320, ordinal 809
000ce278: 79 a1 88 f4 00 00 00 00  ldxdw r1, [r10 - 0xb78]
000ce280: 79 a2 90 f4 00 00 00 00  ldxdw r2, [r10 - 0xb70]
000ce288: 05 00 b6 ff 00 00 00 00  ja -0x4a <.text+0xcdf20> ; branch 0xce040
000ce290: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce298: 07 01 00 00 28 f3 ff ff  add64 r1, -0xcd8
000ce2a0: b7 02 00 00 d0 07 00 00  mov64 r2, 0x7d0
000ce2a8: 85 10 00 00 0e a2 01 00  call 0x1a20e ; call target 0x19f320, ordinal 809
000ce2b0: 79 a3 30 f3 00 00 00 00  ldxdw r3, [r10 - 0xcd0]
000ce2b8: 79 a2 28 f3 00 00 00 00  ldxdw r2, [r10 - 0xcd8]
000ce2c0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce2c8: 07 01 00 00 18 f3 ff ff  add64 r1, -0xce8
000ce2d0: 18 04 00 00 96 77 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7796 ; pointer 0x1b7796 data80 b'sol_vault_authoritywithdraw_authoritypool_authority_mint_accountpool_authority_w'
000ce2e0: b7 05 00 00 13 00 00 00  mov64 r5, 0x13
000ce2e8: 85 10 00 00 c8 68 fe ff  call -0x19738 ; call target 0x2930, ordinal 10
000ce2f0: 79 a1 18 f3 00 00 00 00  ldxdw r1, [r10 - 0xce8]
000ce2f8: 79 a2 20 f3 00 00 00 00  ldxdw r2, [r10 - 0xce0]
000ce300: 05 00 a7 ff 00 00 00 00  ja -0x59 <.text+0xcdf20> ; branch 0xce040
000ce308: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce310: 07 01 00 00 48 f3 ff ff  add64 r1, -0xcb8
000ce318: b7 02 00 00 d2 07 00 00  mov64 r2, 0x7d2
000ce320: 85 10 00 00 ff a1 01 00  call 0x1a1ff ; call target 0x19f320, ordinal 809
000ce328: 79 a3 50 f3 00 00 00 00  ldxdw r3, [r10 - 0xcb0]
000ce330: 79 a2 48 f3 00 00 00 00  ldxdw r2, [r10 - 0xcb8]
000ce338: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce340: 07 01 00 00 38 f3 ff ff  add64 r1, -0xcc8
000ce348: 18 04 00 00 96 77 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7796 ; pointer 0x1b7796 data80 b'sol_vault_authoritywithdraw_authoritypool_authority_mint_accountpool_authority_w'
000ce358: b7 05 00 00 13 00 00 00  mov64 r5, 0x13
000ce360: 85 10 00 00 b9 68 fe ff  call -0x19747 ; call target 0x2930, ordinal 10
000ce368: 79 a1 38 f3 00 00 00 00  ldxdw r1, [r10 - 0xcc8]
000ce370: 79 a2 40 f3 00 00 00 00  ldxdw r2, [r10 - 0xcc0]
000ce378: 05 00 98 ff 00 00 00 00  ja -0x68 <.text+0xcdf20> ; branch 0xce040
000ce380: 79 a1 80 f5 00 00 00 00  ldxdw r1, [r10 - 0xa80]
000ce388: 7b 1a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r1
000ce390: 79 a1 78 f5 00 00 00 00  ldxdw r1, [r10 - 0xa88]
000ce398: 7b 1a 90 ff 00 00 00 00  stxdw [r10 - 0x70], r1
000ce3a0: 79 a1 70 f5 00 00 00 00  ldxdw r1, [r10 - 0xa90]
000ce3a8: 7b 1a 88 ff 00 00 00 00  stxdw [r10 - 0x78], r1
000ce3b0: 79 a1 68 f5 00 00 00 00  ldxdw r1, [r10 - 0xa98]
000ce3b8: 7b 1a 80 ff 00 00 00 00  stxdw [r10 - 0x80], r1
000ce3c0: 79 a2 90 f2 00 00 00 00  ldxdw r2, [r10 - 0xd70]
000ce3c8: 79 21 18 00 00 00 00 00  ldxdw r1, [r2 + 0x18]
000ce3d0: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000ce3d8: 79 21 10 00 00 00 00 00  ldxdw r1, [r2 + 0x10]
000ce3e0: 7b 1a b0 ff 00 00 00 00  stxdw [r10 - 0x50], r1
000ce3e8: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ce3f0: 7b 1a a8 ff 00 00 00 00  stxdw [r10 - 0x58], r1
000ce3f8: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ce400: 7b 1a a0 ff 00 00 00 00  stxdw [r10 - 0x60], r1
000ce408: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce410: 07 01 00 00 80 ff ff ff  add64 r1, -0x80
000ce418: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ce420: 07 02 00 00 a0 ff ff ff  add64 r2, -0x60
000ce428: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ce430: 85 10 00 00 48 ca 01 00  call 0x1ca48 ; call target 0x1b3678, ordinal 1024
000ce438: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000ce440: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000ce448: 15 00 26 00 00 00 00 00  jeq r0, 0x0, +0x26 <.text+0xce460> ; branch 0xce580
000ce450: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce458: 07 01 00 00 78 f4 ff ff  add64 r1, -0xb88
000ce460: b7 02 00 00 df 07 00 00  mov64 r2, 0x7df
000ce468: 85 10 00 00 d6 a1 01 00  call 0x1a1d6 ; call target 0x19f320, ordinal 809
000ce470: 79 a3 80 f4 00 00 00 00  ldxdw r3, [r10 - 0xb80]
000ce478: 79 a2 78 f4 00 00 00 00  ldxdw r2, [r10 - 0xb88]
000ce480: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce488: 07 01 00 00 68 f4 ff ff  add64 r1, -0xb98
000ce490: 18 04 00 00 71 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7571 ; pointer 0x1b7571 data80 b'mayhem_token_vaultglobal_paramsmint_authoritytoken_programnot implemented: admin'
000ce4a0: b7 05 00 00 12 00 00 00  mov64 r5, 0x12
000ce4a8: 85 10 00 00 90 68 fe ff  call -0x19770 ; call target 0x2930, ordinal 10
000ce4b0: 79 a3 70 f4 00 00 00 00  ldxdw r3, [r10 - 0xb90]
000ce4b8: 79 a2 68 f4 00 00 00 00  ldxdw r2, [r10 - 0xb98]
000ce4c0: 79 a1 98 ff 00 00 00 00  ldxdw r1, [r10 - 0x68]
000ce4c8: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce4d0: 79 a1 90 ff 00 00 00 00  ldxdw r1, [r10 - 0x70]
000ce4d8: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ce4e0: 79 a1 88 ff 00 00 00 00  ldxdw r1, [r10 - 0x78]
000ce4e8: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ce4f0: 79 a1 80 ff 00 00 00 00  ldxdw r1, [r10 - 0x80]
000ce4f8: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ce500: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
000ce508: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000ce510: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
000ce518: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000ce520: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
000ce528: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000ce530: 79 a1 b8 ff 00 00 00 00  ldxdw r1, [r10 - 0x48]
000ce538: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000ce540: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce548: 07 01 00 00 58 f4 ff ff  add64 r1, -0xba8
000ce550: bf a4 00 00 00 00 00 00  mov64 r4, r10
000ce558: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000ce560: 85 10 00 00 8a 9b 01 00  call 0x19b8a ; call target 0x19c1b8, ordinal 798
000ce568: 79 a1 58 f4 00 00 00 00  ldxdw r1, [r10 - 0xba8]
000ce570: 79 a2 60 f4 00 00 00 00  ldxdw r2, [r10 - 0xba0]
000ce578: 05 00 58 ff 00 00 00 00  ja -0xa8 <.text+0xcdf20> ; branch 0xce040
000ce580: 79 a1 30 f2 00 00 00 00  ldxdw r1, [r10 - 0xdd0]
000ce588: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
000ce590: 79 21 18 00 00 00 00 00  ldxdw r1, [r2 + 0x18]
000ce598: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000ce5a0: 79 21 10 00 00 00 00 00  ldxdw r1, [r2 + 0x10]
000ce5a8: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
000ce5b0: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ce5b8: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
000ce5c0: 7b 2a 80 f1 00 00 00 00  stxdw [r10 - 0xe80], r2
000ce5c8: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ce5d0: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000ce5d8: 79 a1 78 ff 00 00 00 00  ldxdw r1, [r10 - 0x88]
000ce5e0: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce5e8: 79 a1 70 ff 00 00 00 00  ldxdw r1, [r10 - 0x90]
000ce5f0: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ce5f8: 79 a1 68 ff 00 00 00 00  ldxdw r1, [r10 - 0x98]
000ce600: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ce608: 79 a1 60 ff 00 00 00 00  ldxdw r1, [r10 - 0xa0]
000ce610: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ce618: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce620: 07 01 00 00 c0 ff ff ff  add64 r1, -0x40
000ce628: 7b 1a 88 f1 00 00 00 00  stxdw [r10 - 0xe78], r1
000ce630: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ce638: 07 02 00 00 a0 ff ff ff  add64 r2, -0x60
000ce640: bf a3 00 00 00 00 00 00  mov64 r3, r10
000ce648: 07 03 00 00 e0 ff ff ff  add64 r3, -0x20
000ce650: bf a4 00 00 00 00 00 00  mov64 r4, r10
000ce658: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000ce660: 85 10 00 00 6f 95 01 00  call 0x1956f ; call target 0x1991e0, ordinal 754
000ce668: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000ce670: 79 12 18 00 00 00 00 00  ldxdw r2, [r1 + 0x18]
000ce678: 7b 2a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r2
000ce680: 79 12 10 00 00 00 00 00  ldxdw r2, [r1 + 0x10]
000ce688: 7b 2a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r2
000ce690: 79 12 08 00 00 00 00 00  ldxdw r2, [r1 + 0x8]
000ce698: 7b 2a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r2
000ce6a0: 79 11 00 00 00 00 00 00  ldxdw r1, [r1 + 0x0]
000ce6a8: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000ce6b0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce6b8: 07 01 00 00 e0 ff ff ff  add64 r1, -0x20
000ce6c0: 79 a2 88 f1 00 00 00 00  ldxdw r2, [r10 - 0xe78]
000ce6c8: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ce6d0: 85 10 00 00 f4 c9 01 00  call 0x1c9f4 ; call target 0x1b3678, ordinal 1024
000ce6d8: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000ce6e0: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000ce6e8: 15 00 26 00 00 00 00 00  jeq r0, 0x0, +0x26 <.text+0xce700> ; branch 0xce820
000ce6f0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce6f8: 07 01 00 00 48 f4 ff ff  add64 r1, -0xbb8
000ce700: b7 02 00 00 d9 07 00 00  mov64 r2, 0x7d9
000ce708: 85 10 00 00 82 a1 01 00  call 0x1a182 ; call target 0x19f320, ordinal 809
000ce710: 79 a3 50 f4 00 00 00 00  ldxdw r3, [r10 - 0xbb0]
000ce718: 79 a2 48 f4 00 00 00 00  ldxdw r2, [r10 - 0xbb8]
000ce720: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce728: 07 01 00 00 38 f4 ff ff  add64 r1, -0xbc8
000ce730: 18 04 00 00 71 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7571 ; pointer 0x1b7571 data80 b'mayhem_token_vaultglobal_paramsmint_authoritytoken_programnot implemented: admin'
000ce740: b7 05 00 00 12 00 00 00  mov64 r5, 0x12
000ce748: 85 10 00 00 3c 68 fe ff  call -0x197c4 ; call target 0x2930, ordinal 10
000ce750: 79 a3 40 f4 00 00 00 00  ldxdw r3, [r10 - 0xbc0]
000ce758: 79 a2 38 f4 00 00 00 00  ldxdw r2, [r10 - 0xbc8]
000ce760: 79 a1 f8 ff 00 00 00 00  ldxdw r1, [r10 - 0x8]
000ce768: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce770: 79 a1 f0 ff 00 00 00 00  ldxdw r1, [r10 - 0x10]
000ce778: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ce780: 79 a1 e8 ff 00 00 00 00  ldxdw r1, [r10 - 0x18]
000ce788: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ce790: 79 a1 e0 ff 00 00 00 00  ldxdw r1, [r10 - 0x20]
000ce798: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ce7a0: 79 a1 c0 ff 00 00 00 00  ldxdw r1, [r10 - 0x40]
000ce7a8: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000ce7b0: 79 a1 c8 ff 00 00 00 00  ldxdw r1, [r10 - 0x38]
000ce7b8: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000ce7c0: 79 a1 d0 ff 00 00 00 00  ldxdw r1, [r10 - 0x30]
000ce7c8: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000ce7d0: 79 a1 d8 ff 00 00 00 00  ldxdw r1, [r10 - 0x28]
000ce7d8: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000ce7e0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce7e8: 07 01 00 00 28 f4 ff ff  add64 r1, -0xbd8
000ce7f0: bf a4 00 00 00 00 00 00  mov64 r4, r10
000ce7f8: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000ce800: 85 10 00 00 36 9b 01 00  call 0x19b36 ; call target 0x19c1b8, ordinal 798
000ce808: 79 a1 28 f4 00 00 00 00  ldxdw r1, [r10 - 0xbd8]
000ce810: 79 a2 30 f4 00 00 00 00  ldxdw r2, [r10 - 0xbd0]
000ce818: 05 00 04 ff 00 00 00 00  ja -0xfc <.text+0xcdf20> ; branch 0xce040
000ce820: 71 91 29 00 00 00 00 00  ldxb r1, [r9 + 0x29]
000ce828: 15 01 4b 00 00 00 00 00  jeq r1, 0x0, +0x4b <.text+0xce968> ; branch 0xcea88
000ce830: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce838: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000ce840: 18 02 00 00 10 df 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1bdf10 ; pointer 0x1bdf10 data80 b'\x00\x00\x00\x00&s\x1b\x00\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x007p\x1b\x00\x19\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00wh\x1b\x00\x1e\x00\x00\x00\x00\x00\x00\x00\x1b\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00\xb0h\x1b\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00:u\x1b\x00'
000ce850: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000ce858: 79 a4 70 f2 00 00 00 00  ldxdw r4, [r10 - 0xd90]
000ce860: 85 10 00 00 ca b2 01 00  call 0x1b2ca ; call target 0x1a7eb8, ordinal 885
000ce868: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000ce870: 7b 1a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r1
000ce878: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000ce880: 7b 1a 90 ff 00 00 00 00  stxdw [r10 - 0x70], r1
000ce888: 79 a1 00 f6 00 00 00 00  ldxdw r1, [r10 - 0xa00]
000ce890: 7b 1a 88 ff 00 00 00 00  stxdw [r10 - 0x78], r1
000ce898: 79 a1 f8 f5 00 00 00 00  ldxdw r1, [r10 - 0xa08]
000ce8a0: 7b 1a 80 ff 00 00 00 00  stxdw [r10 - 0x80], r1
000ce8a8: 71 a1 18 f6 00 00 00 00  ldxb r1, [r10 - 0x9e8]
000ce8b0: 79 a2 88 f2 00 00 00 00  ldxdw r2, [r10 - 0xd78]
000ce8b8: 73 12 01 00 00 00 00 00  stxb [r2 + 0x1], r1
000ce8c0: 79 a1 08 f2 00 00 00 00  ldxdw r1, [r10 - 0xdf8]
000ce8c8: 79 19 00 00 00 00 00 00  ldxdw r9, [r1 + 0x0]
000ce8d0: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000ce8d8: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce8e0: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000ce8e8: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ce8f0: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000ce8f8: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ce900: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000ce908: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ce910: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce918: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000ce920: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ce928: 07 02 00 00 80 ff ff ff  add64 r2, -0x80
000ce930: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ce938: 85 10 00 00 a7 c9 01 00  call 0x1c9a7 ; call target 0x1b3678, ordinal 1024
000ce940: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000ce948: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000ce950: 15 00 35 00 00 00 00 00  jeq r0, 0x0, +0x35 <.text+0xce9e0> ; branch 0xceb00
000ce958: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce960: 07 01 00 00 18 f4 ff ff  add64 r1, -0xbe8
000ce968: b7 02 00 00 d6 07 00 00  mov64 r2, 0x7d6
000ce970: 85 10 00 00 35 a1 01 00  call 0x1a135 ; call target 0x19f320, ordinal 809
000ce978: 79 a3 20 f4 00 00 00 00  ldxdw r3, [r10 - 0xbe0]
000ce980: 79 a2 18 f4 00 00 00 00  ldxdw r2, [r10 - 0xbe8]
000ce988: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ce990: 07 01 00 00 08 f4 ff ff  add64 r1, -0xbf8
000ce998: 18 04 00 00 26 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7326 ; pointer 0x1b7326 data80 b'globalevent_authorityprogram_signeridl_accountprogramsystem_programauthorityfee_'
000ce9a8: b7 05 00 00 06 00 00 00  mov64 r5, 0x6
000ce9b0: 85 10 00 00 ef 67 fe ff  call -0x19811 ; call target 0x2930, ordinal 10
000ce9b8: 79 a3 10 f4 00 00 00 00  ldxdw r3, [r10 - 0xbf0]
000ce9c0: 79 a2 08 f4 00 00 00 00  ldxdw r2, [r10 - 0xbf8]
000ce9c8: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000ce9d0: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ce9d8: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000ce9e0: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ce9e8: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000ce9f0: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ce9f8: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000cea00: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000cea08: 79 a1 80 ff 00 00 00 00  ldxdw r1, [r10 - 0x80]
000cea10: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000cea18: 79 a1 88 ff 00 00 00 00  ldxdw r1, [r10 - 0x78]
000cea20: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000cea28: 79 a1 90 ff 00 00 00 00  ldxdw r1, [r10 - 0x70]
000cea30: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000cea38: 79 a1 98 ff 00 00 00 00  ldxdw r1, [r10 - 0x68]
000cea40: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000cea48: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cea50: 07 01 00 00 f8 f3 ff ff  add64 r1, -0xc08
000cea58: bf a4 00 00 00 00 00 00  mov64 r4, r10
000cea60: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000cea68: 85 10 00 00 e9 9a 01 00  call 0x19ae9 ; call target 0x19c1b8, ordinal 798
000cea70: 79 a1 f8 f3 00 00 00 00  ldxdw r1, [r10 - 0xc08]
000cea78: 79 a2 00 f4 00 00 00 00  ldxdw r2, [r10 - 0xc00]
000cea80: 05 00 b7 fe 00 00 00 00  ja -0x149 <.text+0xcdf20> ; branch 0xce040
000cea88: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cea90: 07 01 00 00 68 f3 ff ff  add64 r1, -0xc98
000cea98: b7 02 00 00 d0 07 00 00  mov64 r2, 0x7d0
000ceaa0: 85 10 00 00 0f a1 01 00  call 0x1a10f ; call target 0x19f320, ordinal 809
000ceaa8: 79 a3 70 f3 00 00 00 00  ldxdw r3, [r10 - 0xc90]
000ceab0: 79 a2 68 f3 00 00 00 00  ldxdw r2, [r10 - 0xc98]
000ceab8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ceac0: 07 01 00 00 58 f3 ff ff  add64 r1, -0xca8
000ceac8: 18 04 00 00 71 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7571 ; pointer 0x1b7571 data80 b'mayhem_token_vaultglobal_paramsmint_authoritytoken_programnot implemented: admin'
000cead8: b7 05 00 00 12 00 00 00  mov64 r5, 0x12
000ceae0: 85 10 00 00 c9 67 fe ff  call -0x19837 ; call target 0x2930, ordinal 10
000ceae8: 79 a1 58 f3 00 00 00 00  ldxdw r1, [r10 - 0xca8]
000ceaf0: 79 a2 60 f3 00 00 00 00  ldxdw r2, [r10 - 0xca0]
000ceaf8: 05 00 a8 fe 00 00 00 00  ja -0x158 <.text+0xcdf20> ; branch 0xce040
000ceb00: 79 a2 80 f1 00 00 00 00  ldxdw r2, [r10 - 0xe80]
000ceb08: 79 21 18 00 00 00 00 00  ldxdw r1, [r2 + 0x18]
000ceb10: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000ceb18: 79 21 10 00 00 00 00 00  ldxdw r1, [r2 + 0x10]
000ceb20: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
000ceb28: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ceb30: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
000ceb38: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ceb40: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000ceb48: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ceb50: 07 01 00 00 e0 ff ff ff  add64 r1, -0x20
000ceb58: 7b 1a d0 ff 00 00 00 00  stxdw [r10 - 0x30], r1
000ceb60: 18 01 00 00 3a 68 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b683a ; pointer 0x1b683a data80 b'bonding-curveprograms/pump/src/buy_v2.rsbuybuy_exact_quote_inprograms/pump/src/c'
000ceb70: 7b 1a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r1
000ceb78: 7a 0a d8 ff 20 00 00 00  stdw [r10 - 0x28], 0x20
000ceb80: 7a 0a c8 ff 0d 00 00 00  stdw [r10 - 0x38], 0xd
000ceb88: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ceb90: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000ceb98: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ceba0: 07 02 00 00 c0 ff ff ff  add64 r2, -0x40
000ceba8: b7 03 00 00 02 00 00 00  mov64 r3, 0x2
000cebb0: 79 a4 70 f2 00 00 00 00  ldxdw r4, [r10 - 0xd90]
000cebb8: 85 10 00 00 5f b2 01 00  call 0x1b25f ; call target 0x1a7eb8, ordinal 885
000cebc0: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cebc8: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000cebd0: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cebd8: 7b 1a b0 ff 00 00 00 00  stxdw [r10 - 0x50], r1
000cebe0: 79 a1 00 f6 00 00 00 00  ldxdw r1, [r10 - 0xa00]
000cebe8: 7b 1a a8 ff 00 00 00 00  stxdw [r10 - 0x58], r1
000cebf0: 79 a1 f8 f5 00 00 00 00  ldxdw r1, [r10 - 0xa08]
000cebf8: 7b 1a a0 ff 00 00 00 00  stxdw [r10 - 0x60], r1
000cec00: 71 a1 18 f6 00 00 00 00  ldxb r1, [r10 - 0x9e8]
000cec08: 79 a2 88 f2 00 00 00 00  ldxdw r2, [r10 - 0xd78]
000cec10: 73 12 02 00 00 00 00 00  stxb [r2 + 0x2], r1
000cec18: 79 a1 f0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe10]
000cec20: 79 19 00 00 00 00 00 00  ldxdw r9, [r1 + 0x0]
000cec28: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000cec30: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000cec38: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000cec40: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000cec48: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000cec50: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000cec58: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000cec60: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000cec68: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cec70: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cec78: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cec80: 07 02 00 00 a0 ff ff ff  add64 r2, -0x60
000cec88: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000cec90: 85 10 00 00 3c c9 01 00  call 0x1c93c ; call target 0x1b3678, ordinal 1024
000cec98: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000ceca0: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000ceca8: 15 00 26 00 00 00 00 00  jeq r0, 0x0, +0x26 <.text+0xcecc0> ; branch 0xcede0
000cecb0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cecb8: 07 01 00 00 e8 f3 ff ff  add64 r1, -0xc18
000cecc0: b7 02 00 00 d6 07 00 00  mov64 r2, 0x7d6
000cecc8: 85 10 00 00 ca a0 01 00  call 0x1a0ca ; call target 0x19f320, ordinal 809
000cecd0: 79 a3 f0 f3 00 00 00 00  ldxdw r3, [r10 - 0xc10]
000cecd8: 79 a2 e8 f3 00 00 00 00  ldxdw r2, [r10 - 0xc18]
000cece0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cece8: 07 01 00 00 d8 f3 ff ff  add64 r1, -0xc28
000cecf0: 18 04 00 00 d8 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b73d8 ; pointer 0x1b73d8 data80 b'bonding_curveassociated_base_bonding_curveassociated_quote_bonding_curveassociat'
000ced00: b7 05 00 00 0d 00 00 00  mov64 r5, 0xd
000ced08: 85 10 00 00 84 67 fe ff  call -0x1987c ; call target 0x2930, ordinal 10
000ced10: 79 a3 e0 f3 00 00 00 00  ldxdw r3, [r10 - 0xc20]
000ced18: 79 a2 d8 f3 00 00 00 00  ldxdw r2, [r10 - 0xc28]
000ced20: 79 91 18 00 00 00 00 00  ldxdw r1, [r9 + 0x18]
000ced28: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ced30: 79 91 10 00 00 00 00 00  ldxdw r1, [r9 + 0x10]
000ced38: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ced40: 79 91 08 00 00 00 00 00  ldxdw r1, [r9 + 0x8]
000ced48: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ced50: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
000ced58: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ced60: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
000ced68: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000ced70: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
000ced78: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000ced80: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
000ced88: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000ced90: 79 a1 b8 ff 00 00 00 00  ldxdw r1, [r10 - 0x48]
000ced98: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000ceda0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ceda8: 07 01 00 00 c8 f3 ff ff  add64 r1, -0xc38
000cedb0: bf a4 00 00 00 00 00 00  mov64 r4, r10
000cedb8: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000cedc0: 85 10 00 00 7e 9a 01 00  call 0x19a7e ; call target 0x19c1b8, ordinal 798
000cedc8: 79 a1 c8 f3 00 00 00 00  ldxdw r1, [r10 - 0xc38]
000cedd0: 79 a2 d0 f3 00 00 00 00  ldxdw r2, [r10 - 0xc30]
000cedd8: 05 00 4c fe 00 00 00 00  ja -0x1b4 <.text+0xcdf20> ; branch 0xce040
000cede0: 79 a1 f0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe10]
000cede8: 71 11 29 00 00 00 00 00  ldxb r1, [r1 + 0x29]
000cedf0: 15 01 4b 00 00 00 00 00  jeq r1, 0x0, +0x4b <.text+0xcef30> ; branch 0xcf050
000cedf8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cee00: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000cee08: 18 02 00 00 d8 db 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1bdbd8 ; pointer 0x1bdbd8 data80 b'\x00\x00\x00\x00\x07h\x1b\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80n\x1b\x00\x1f\x00\x00\x00\x00\x00\x00\x004\x03\x00\x00+\x00\x00\x00\x00\x00\x00\x00\x9fn\x1b\x00)\x00\x00\x00\x00\x00\x00\x00\xe8\x00\x00\x00 \x00\x00\x00\x00\x00\x00\x00Zo\x1b\x00\x19\x00\x00\x00\x00\x00\x00\x00'
000cee18: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000cee20: 79 a4 70 f2 00 00 00 00  ldxdw r4, [r10 - 0xd90]
000cee28: 85 10 00 00 11 b2 01 00  call 0x1b211 ; call target 0x1a7eb8, ordinal 885
000cee30: 79 a1 10 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f0]
000cee38: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000cee40: 79 a1 08 f6 00 00 00 00  ldxdw r1, [r10 - 0x9f8]
000cee48: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
000cee50: 79 a1 00 f6 00 00 00 00  ldxdw r1, [r10 - 0xa00]
000cee58: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
000cee60: 79 a1 f8 f5 00 00 00 00  ldxdw r1, [r10 - 0xa08]
000cee68: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000cee70: 71 a1 18 f6 00 00 00 00  ldxb r1, [r10 - 0x9e8]
000cee78: 79 a2 88 f2 00 00 00 00  ldxdw r2, [r10 - 0xd78]
000cee80: 73 12 03 00 00 00 00 00  stxb [r2 + 0x3], r1
000cee88: 79 a2 b8 f1 00 00 00 00  ldxdw r2, [r10 - 0xe48]
000cee90: 79 21 18 00 00 00 00 00  ldxdw r1, [r2 + 0x18]
000cee98: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000ceea0: 79 21 10 00 00 00 00 00  ldxdw r1, [r2 + 0x10]
000ceea8: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000ceeb0: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
000ceeb8: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000ceec0: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
000ceec8: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000ceed0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ceed8: 07 01 00 00 f8 f5 ff ff  add64 r1, -0xa08
000ceee0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000ceee8: 07 02 00 00 e0 ff ff ff  add64 r2, -0x20
000ceef0: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ceef8: 85 10 00 00 ef c8 01 00  call 0x1c8ef ; call target 0x1b3678, ordinal 1024
000cef00: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000cef08: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000cef10: 15 00 36 00 00 00 00 00  jeq r0, 0x0, +0x36 <.text+0xcefa8> ; branch 0xcf0c8
000cef18: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cef20: 07 01 00 00 b8 f3 ff ff  add64 r1, -0xc48
000cef28: b7 02 00 00 d6 07 00 00  mov64 r2, 0x7d6
000cef30: 85 10 00 00 7d a0 01 00  call 0x1a07d ; call target 0x19f320, ordinal 809
000cef38: 79 a3 c0 f3 00 00 00 00  ldxdw r3, [r10 - 0xc40]
000cef40: 79 a2 b8 f3 00 00 00 00  ldxdw r2, [r10 - 0xc48]
000cef48: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cef50: 07 01 00 00 a8 f3 ff ff  add64 r1, -0xc58
000cef58: 18 04 00 00 2c 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b732c ; pointer 0x1b732c data80 b'event_authorityprogram_signeridl_accountprogramsystem_programauthorityfee_recipi'
000cef68: b7 05 00 00 0f 00 00 00  mov64 r5, 0xf
000cef70: 85 10 00 00 37 67 fe ff  call -0x198c9 ; call target 0x2930, ordinal 10
000cef78: 79 a3 b0 f3 00 00 00 00  ldxdw r3, [r10 - 0xc50]
000cef80: 79 a2 a8 f3 00 00 00 00  ldxdw r2, [r10 - 0xc58]
000cef88: 79 a4 b8 f1 00 00 00 00  ldxdw r4, [r10 - 0xe48]
000cef90: 79 41 18 00 00 00 00 00  ldxdw r1, [r4 + 0x18]
000cef98: 7b 1a 10 f6 00 00 00 00  stxdw [r10 - 0x9f0], r1
000cefa0: 79 41 10 00 00 00 00 00  ldxdw r1, [r4 + 0x10]
000cefa8: 7b 1a 08 f6 00 00 00 00  stxdw [r10 - 0x9f8], r1
000cefb0: 79 41 08 00 00 00 00 00  ldxdw r1, [r4 + 0x8]
000cefb8: 7b 1a 00 f6 00 00 00 00  stxdw [r10 - 0xa00], r1
000cefc0: 79 41 00 00 00 00 00 00  ldxdw r1, [r4 + 0x0]
000cefc8: 7b 1a f8 f5 00 00 00 00  stxdw [r10 - 0xa08], r1
000cefd0: 79 a1 e0 ff 00 00 00 00  ldxdw r1, [r10 - 0x20]
000cefd8: 7b 1a 18 f6 00 00 00 00  stxdw [r10 - 0x9e8], r1
000cefe0: 79 a1 e8 ff 00 00 00 00  ldxdw r1, [r10 - 0x18]
000cefe8: 7b 1a 20 f6 00 00 00 00  stxdw [r10 - 0x9e0], r1
000ceff0: 79 a1 f0 ff 00 00 00 00  ldxdw r1, [r10 - 0x10]
000ceff8: 7b 1a 28 f6 00 00 00 00  stxdw [r10 - 0x9d8], r1
000cf000: 79 a1 f8 ff 00 00 00 00  ldxdw r1, [r10 - 0x8]
000cf008: 7b 1a 30 f6 00 00 00 00  stxdw [r10 - 0x9d0], r1
000cf010: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf018: 07 01 00 00 98 f3 ff ff  add64 r1, -0xc68
000cf020: bf a4 00 00 00 00 00 00  mov64 r4, r10
000cf028: 07 04 00 00 f8 f5 ff ff  add64 r4, -0xa08
000cf030: 85 10 00 00 30 9a 01 00  call 0x19a30 ; call target 0x19c1b8, ordinal 798
000cf038: 79 a1 98 f3 00 00 00 00  ldxdw r1, [r10 - 0xc68]
000cf040: 79 a2 a0 f3 00 00 00 00  ldxdw r2, [r10 - 0xc60]
000cf048: 05 00 fe fd 00 00 00 00  ja -0x202 <.text+0xcdf20> ; branch 0xce040
000cf050: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf058: 07 01 00 00 88 f3 ff ff  add64 r1, -0xc78
000cf060: b7 02 00 00 d0 07 00 00  mov64 r2, 0x7d0
000cf068: 85 10 00 00 56 a0 01 00  call 0x1a056 ; call target 0x19f320, ordinal 809
000cf070: 79 a3 90 f3 00 00 00 00  ldxdw r3, [r10 - 0xc70]
000cf078: 79 a2 88 f3 00 00 00 00  ldxdw r2, [r10 - 0xc78]
000cf080: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf088: 07 01 00 00 78 f3 ff ff  add64 r1, -0xc88
000cf090: 18 04 00 00 d8 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b73d8 ; pointer 0x1b73d8 data80 b'bonding_curveassociated_base_bonding_curveassociated_quote_bonding_curveassociat'
000cf0a0: b7 05 00 00 0d 00 00 00  mov64 r5, 0xd
000cf0a8: 85 10 00 00 10 67 fe ff  call -0x198f0 ; call target 0x2930, ordinal 10
000cf0b0: 79 a1 78 f3 00 00 00 00  ldxdw r1, [r10 - 0xc88]
000cf0b8: 79 a2 80 f3 00 00 00 00  ldxdw r2, [r10 - 0xc80]
000cf0c0: 05 00 ef fd 00 00 00 00  ja -0x211 <.text+0xcdf20> ; branch 0xce040
000cf0c8: 69 a1 18 ff 00 00 00 00  ldxh r1, [r10 - 0xe8]
000cf0d0: 6b 16 b0 01 00 00 00 00  stxh [r6 + 0x1b0], r1
000cf0d8: 79 a1 10 ff 00 00 00 00  ldxdw r1, [r10 - 0xf0]
000cf0e0: 7b 16 a8 01 00 00 00 00  stxdw [r6 + 0x1a8], r1
000cf0e8: 79 a1 08 ff 00 00 00 00  ldxdw r1, [r10 - 0xf8]
000cf0f0: 7b 16 a0 01 00 00 00 00  stxdw [r6 + 0x1a0], r1
000cf0f8: 71 a1 04 ff 00 00 00 00  ldxb r1, [r10 - 0xfc]
000cf100: 73 16 b7 01 00 00 00 00  stxb [r6 + 0x1b7], r1
000cf108: 61 a1 00 ff 00 00 00 00  ldxw r1, [r10 - 0x100]
000cf110: 63 16 b3 01 00 00 00 00  stxw [r6 + 0x1b3], r1
000cf118: 69 a1 38 ff 00 00 00 00  ldxh r1, [r10 - 0xc8]
000cf120: 6b 16 e0 01 00 00 00 00  stxh [r6 + 0x1e0], r1
000cf128: 79 a1 30 ff 00 00 00 00  ldxdw r1, [r10 - 0xd0]
000cf130: 7b 16 d8 01 00 00 00 00  stxdw [r6 + 0x1d8], r1
000cf138: 79 a1 28 ff 00 00 00 00  ldxdw r1, [r10 - 0xd8]
000cf140: 7b 16 d0 01 00 00 00 00  stxdw [r6 + 0x1d0], r1
000cf148: 61 a1 20 ff 00 00 00 00  ldxw r1, [r10 - 0xe0]
000cf150: 63 16 e3 01 00 00 00 00  stxw [r6 + 0x1e3], r1
000cf158: 71 a1 24 ff 00 00 00 00  ldxb r1, [r10 - 0xdc]
000cf160: 73 16 e7 01 00 00 00 00  stxb [r6 + 0x1e7], r1
000cf168: 79 a1 88 f5 00 00 00 00  ldxdw r1, [r10 - 0xa78]
000cf170: 7b 16 90 00 00 00 00 00  stxdw [r6 + 0x90], r1
000cf178: 79 a1 90 f5 00 00 00 00  ldxdw r1, [r10 - 0xa70]
000cf180: 7b 16 98 00 00 00 00 00  stxdw [r6 + 0x98], r1
000cf188: bf 61 00 00 00 00 00 00  mov64 r1, r6
000cf190: 07 01 00 00 a8 00 00 00  add64 r1, 0xa8
000cf198: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf1a0: 07 02 00 00 48 f5 ff ff  add64 r2, -0xab8
000cf1a8: b7 03 00 00 40 00 00 00  mov64 r3, 0x40
000cf1b0: 85 10 00 00 8b c8 01 00  call 0x1c88b ; call target 0x1b3610, ordinal 1021
000cf1b8: bf 61 00 00 00 00 00 00  mov64 r1, r6
000cf1c0: 07 01 00 00 e8 00 00 00  add64 r1, 0xe8
000cf1c8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf1d0: 07 02 00 00 00 f5 ff ff  add64 r2, -0xb00
000cf1d8: b7 03 00 00 48 00 00 00  mov64 r3, 0x48
000cf1e0: 85 10 00 00 85 c8 01 00  call 0x1c885 ; call target 0x1b3610, ordinal 1021
000cf1e8: 79 a1 d8 f4 00 00 00 00  ldxdw r1, [r10 - 0xb28]
000cf1f0: 7b 16 34 01 00 00 00 00  stxdw [r6 + 0x134], r1
000cf1f8: 79 a1 e0 f4 00 00 00 00  ldxdw r1, [r10 - 0xb20]
000cf200: 7b 16 3c 01 00 00 00 00  stxdw [r6 + 0x13c], r1
000cf208: 79 a1 e8 f4 00 00 00 00  ldxdw r1, [r10 - 0xb18]
000cf210: 7b 16 44 01 00 00 00 00  stxdw [r6 + 0x144], r1
000cf218: 79 a1 f0 f4 00 00 00 00  ldxdw r1, [r10 - 0xb10]
000cf220: 7b 16 4c 01 00 00 00 00  stxdw [r6 + 0x14c], r1
000cf228: 61 a1 f8 f4 00 00 00 00  ldxw r1, [r10 - 0xb08]
000cf230: 63 16 54 01 00 00 00 00  stxw [r6 + 0x154], r1
000cf238: bf 61 00 00 00 00 00 00  mov64 r1, r6
000cf240: 07 01 00 00 18 00 00 00  add64 r1, 0x18
000cf248: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf250: 07 02 00 00 b8 f5 ff ff  add64 r2, -0xa48
000cf258: b7 03 00 00 40 00 00 00  mov64 r3, 0x40
000cf260: 85 10 00 00 75 c8 01 00  call 0x1c875 ; call target 0x1b3610, ordinal 1021
000cf268: 79 a1 98 f5 00 00 00 00  ldxdw r1, [r10 - 0xa68]
000cf270: 7b 16 60 00 00 00 00 00  stxdw [r6 + 0x60], r1
000cf278: 79 a1 a0 f5 00 00 00 00  ldxdw r1, [r10 - 0xa60]
000cf280: 7b 16 68 00 00 00 00 00  stxdw [r6 + 0x68], r1
000cf288: 79 a1 a8 f5 00 00 00 00  ldxdw r1, [r10 - 0xa58]
000cf290: 7b 16 70 00 00 00 00 00  stxdw [r6 + 0x70], r1
000cf298: 79 a1 b0 f5 00 00 00 00  ldxdw r1, [r10 - 0xa50]
000cf2a0: 7b 16 78 00 00 00 00 00  stxdw [r6 + 0x78], r1
000cf2a8: bf 61 00 00 00 00 00 00  mov64 r1, r6
000cf2b0: 07 01 00 00 a0 02 00 00  add64 r1, 0x2a0
000cf2b8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf2c0: 07 02 00 00 38 fa ff ff  add64 r2, -0x5c8
000cf2c8: b7 03 00 00 2f 04 00 00  mov64 r3, 0x42f
000cf2d0: 85 10 00 00 67 c8 01 00  call 0x1c867 ; call target 0x1b3610, ordinal 1021
000cf2d8: bf 61 00 00 00 00 00 00  mov64 r1, r6
000cf2e0: 07 01 00 00 f8 01 00 00  add64 r1, 0x1f8
000cf2e8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf2f0: 07 02 00 00 68 fe ff ff  add64 r2, -0x198
000cf2f8: b7 03 00 00 95 00 00 00  mov64 r3, 0x95
000cf300: 85 10 00 00 61 c8 01 00  call 0x1c861 ; call target 0x1b3610, ordinal 1021
000cf308: 79 a1 d0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe30]
000cf310: 7b 16 d0 06 00 00 00 00  stxdw [r6 + 0x6d0], r1
000cf318: 79 a1 f8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe08]
000cf320: 73 16 cf 06 00 00 00 00  stxb [r6 + 0x6cf], r1
000cf328: 79 a1 00 f2 00 00 00 00  ldxdw r1, [r10 - 0xe00]
000cf330: 7b 16 98 02 00 00 00 00  stxdw [r6 + 0x298], r1
000cf338: 79 a1 08 f2 00 00 00 00  ldxdw r1, [r10 - 0xdf8]
000cf340: 7b 16 90 02 00 00 00 00  stxdw [r6 + 0x290], r1
000cf348: 79 a1 d8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe28]
000cf350: 6b 16 8e 02 00 00 00 00  stxh [r6 + 0x28e], r1
000cf358: 79 a1 e0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe20]
000cf360: 73 16 8d 02 00 00 00 00  stxb [r6 + 0x28d], r1
000cf368: 79 a1 e8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe18]
000cf370: 7b 16 f0 01 00 00 00 00  stxdw [r6 + 0x1f0], r1
000cf378: 79 a1 f0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe10]
000cf380: 7b 16 e8 01 00 00 00 00  stxdw [r6 + 0x1e8], r1
000cf388: 79 a1 90 f1 00 00 00 00  ldxdw r1, [r10 - 0xe70]
000cf390: 73 16 e2 01 00 00 00 00  stxb [r6 + 0x1e2], r1
000cf398: 79 a1 a0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe60]
000cf3a0: 7b 16 c8 01 00 00 00 00  stxdw [r6 + 0x1c8], r1
000cf3a8: 79 a1 a8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe58]
000cf3b0: 7b 16 c0 01 00 00 00 00  stxdw [r6 + 0x1c0], r1
000cf3b8: 79 a1 98 f1 00 00 00 00  ldxdw r1, [r10 - 0xe68]
000cf3c0: 7b 16 b8 01 00 00 00 00  stxdw [r6 + 0x1b8], r1
000cf3c8: 79 a1 b0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe50]
000cf3d0: 73 16 b2 01 00 00 00 00  stxb [r6 + 0x1b2], r1
000cf3d8: 79 a1 c0 f1 00 00 00 00  ldxdw r1, [r10 - 0xe40]
000cf3e0: 7b 16 98 01 00 00 00 00  stxdw [r6 + 0x198], r1
000cf3e8: 79 a1 c8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe38]
000cf3f0: 7b 16 90 01 00 00 00 00  stxdw [r6 + 0x190], r1
000cf3f8: 79 a1 b8 f1 00 00 00 00  ldxdw r1, [r10 - 0xe48]
000cf400: 7b 16 88 01 00 00 00 00  stxdw [r6 + 0x188], r1
000cf408: 79 a1 58 f2 00 00 00 00  ldxdw r1, [r10 - 0xda8]
000cf410: 73 16 82 01 00 00 00 00  stxb [r6 + 0x182], r1
000cf418: 79 a1 80 f2 00 00 00 00  ldxdw r1, [r10 - 0xd80]
000cf420: 73 16 81 01 00 00 00 00  stxb [r6 + 0x181], r1
000cf428: 79 a1 78 f2 00 00 00 00  ldxdw r1, [r10 - 0xd88]
000cf430: 73 16 80 01 00 00 00 00  stxb [r6 + 0x180], r1
000cf438: 79 a1 60 f2 00 00 00 00  ldxdw r1, [r10 - 0xda0]
000cf440: 7b 16 78 01 00 00 00 00  stxdw [r6 + 0x178], r1
000cf448: 79 a1 68 f2 00 00 00 00  ldxdw r1, [r10 - 0xd98]
000cf450: 7b 16 70 01 00 00 00 00  stxdw [r6 + 0x170], r1
000cf458: 7b 76 68 01 00 00 00 00  stxdw [r6 + 0x168], r7
000cf460: 7b 86 60 01 00 00 00 00  stxdw [r6 + 0x160], r8
000cf468: 79 a1 90 f2 00 00 00 00  ldxdw r1, [r10 - 0xd70]
000cf470: 7b 16 58 01 00 00 00 00  stxdw [r6 + 0x158], r1
000cf478: 79 a1 38 f2 00 00 00 00  ldxdw r1, [r10 - 0xdc8]
000cf480: 63 16 30 01 00 00 00 00  stxw [r6 + 0x130], r1
000cf488: 79 a1 50 f2 00 00 00 00  ldxdw r1, [r10 - 0xdb0]
000cf490: 7b 16 a0 00 00 00 00 00  stxdw [r6 + 0xa0], r1
000cf498: 79 a1 48 f2 00 00 00 00  ldxdw r1, [r10 - 0xdb8]
000cf4a0: 7b 16 88 00 00 00 00 00  stxdw [r6 + 0x88], r1
000cf4a8: 79 a1 40 f2 00 00 00 00  ldxdw r1, [r10 - 0xdc0]
000cf4b0: 7b 16 80 00 00 00 00 00  stxdw [r6 + 0x80], r1
000cf4b8: 79 a1 30 f2 00 00 00 00  ldxdw r1, [r10 - 0xdd0]
000cf4c0: 7b 16 58 00 00 00 00 00  stxdw [r6 + 0x58], r1
000cf4c8: 79 a1 10 f2 00 00 00 00  ldxdw r1, [r10 - 0xdf0]
000cf4d0: 7b 16 10 00 00 00 00 00  stxdw [r6 + 0x10], r1
000cf4d8: 79 a1 18 f2 00 00 00 00  ldxdw r1, [r10 - 0xde8]
000cf4e0: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000cf4e8: 79 a1 20 f2 00 00 00 00  ldxdw r1, [r10 - 0xde0]
000cf4f0: 63 16 04 00 00 00 00 00  stxw [r6 + 0x4], r1
000cf4f8: 79 a1 28 f2 00 00 00 00  ldxdw r1, [r10 - 0xdd8]
000cf500: 63 16 00 00 00 00 00 00  stxw [r6 + 0x0], r1
000cf508: 05 00 68 fc 00 00 00 00  ja -0x398 <.text+0xcd730> ; branch 0xcd850
