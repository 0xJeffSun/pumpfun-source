000cf510: bf 37 00 00 00 00 00 00  mov64 r7, r3
000cf518: bf 28 00 00 00 00 00 00  mov64 r8, r2
000cf520: bf 16 00 00 00 00 00 00  mov64 r6, r1
000cf528: 79 89 a0 00 00 00 00 00  ldxdw r9, [r8 + 0xa0]
000cf530: bf 81 00 00 00 00 00 00  mov64 r1, r8
000cf538: 07 01 00 00 80 00 00 00  add64 r1, 0x80
000cf540: bf 72 00 00 00 00 00 00  mov64 r2, r7
000cf548: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000cf550: 85 10 00 00 24 c8 01 00  call 0x1c824 ; call target 0x1b3678, ordinal 1024
000cf558: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
000cf560: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
000cf568: 55 00 1b 00 00 00 00 00  jne r0, 0x0, +0x1b <.text+0xcf528> ; branch 0xcf648
000cf570: bf 91 00 00 00 00 00 00  mov64 r1, r9
000cf578: 85 10 00 00 a8 98 01 00  call 0x198a8 ; call target 0x19bac0, ordinal 791
000cf580: 55 00 18 00 00 00 00 00  jne r0, 0x0, +0x18 <.text+0xcf528> ; branch 0xcf648
000cf588: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf590: 07 01 00 00 e8 ff ff ff  add64 r1, -0x18
000cf598: bf 92 00 00 00 00 00 00  mov64 r2, r9
000cf5a0: 85 10 00 00 f2 a6 01 00  call 0x1a6f2 ; call target 0x1a2d38, ordinal 845
000cf5a8: 79 a1 f8 ff 00 00 00 00  ldxdw r1, [r10 - 0x8]
000cf5b0: 79 a2 e8 ff 00 00 00 00  ldxdw r2, [r10 - 0x18]
000cf5b8: 18 03 00 00 1a 00 00 00 00 00 00 00 00 00 00 80  lddw r3, -0x7fffffffffffffe6
000cf5c8: 5d 32 04 00 00 00 00 00  jne r2, r3, +0x4 <.text+0xcf4d0> ; branch 0xcf5f0
000cf5d0: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
000cf5d8: 07 02 00 00 01 00 00 00  add64 r2, 0x1
000cf5e0: 7b 21 00 00 00 00 00 00  stxdw [r1 + 0x0], r2
000cf5e8: 05 00 0b 00 00 00 00 00  ja +0xb <.text+0xcf528> ; branch 0xcf648
000cf5f0: 79 a3 f0 ff 00 00 00 00  ldxdw r3, [r10 - 0x10]
000cf5f8: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000cf600: 7b 3a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r3
000cf608: 7b 2a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r2
000cf610: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf618: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000cf620: bf a2 00 00 00 00 00 00  mov64 r2, r10
000cf628: 07 02 00 00 e8 ff ff ff  add64 r2, -0x18
000cf630: 85 10 00 00 b0 98 01 00  call 0x198b0 ; call target 0x19bbb8, ordinal 793
000cf638: 79 a2 d8 ff 00 00 00 00  ldxdw r2, [r10 - 0x28]
000cf640: 55 02 17 00 02 00 00 00  jne r2, 0x2, +0x17 <.text+0xcf5e0> ; branch 0xcf700
000cf648: 07 08 00 00 e8 01 00 00  add64 r8, 0x1e8
000cf650: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf658: 07 01 00 00 b8 ff ff ff  add64 r1, -0x48
000cf660: bf 82 00 00 00 00 00 00  mov64 r2, r8
000cf668: 18 03 00 00 df 79 1b 00 00 00 00 00 00 00 00 00  lddw r3, 0x1b79df ; pointer 0x1b79df data80 b'\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15h\xbf\x17[\xaaQ\x89\xcb\x97\xf5\xd2\xff;e]+\xb6\xfdm\x18\xb0\x0c\x14\xde\xfc\x82^\xc6v\x94%\x08\x18\xbbe@e\xf4)\x8d1V\xd5q\xb4\xd4\xf8\t\x0c\x18\xe9\xa8c\x0c\x14\xde\xfc\x82^\xc6v\x94%\x08\x18\xbbe@e'
000cf678: bf 74 00 00 00 00 00 00  mov64 r4, r7
000cf680: 85 10 00 00 74 6c fe ff  call -0x1938c ; call target 0x5a28, ordinal 27
000cf688: b7 01 00 00 02 00 00 00  mov64 r1, 0x2
000cf690: 79 a2 b8 ff 00 00 00 00  ldxdw r2, [r10 - 0x48]
000cf698: 15 02 09 00 02 00 00 00  jeq r2, 0x2, +0x9 <.text+0xcf5c8> ; branch 0xcf6e8
000cf6a0: 79 a3 c0 ff 00 00 00 00  ldxdw r3, [r10 - 0x40]
000cf6a8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf6b0: 07 01 00 00 a8 ff ff ff  add64 r1, -0x58
000cf6b8: 18 04 00 00 d8 73 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b73d8 ; pointer 0x1b73d8 data80 b'bonding_curveassociated_base_bonding_curveassociated_quote_bonding_curveassociat'
000cf6c8: b7 05 00 00 0d 00 00 00  mov64 r5, 0xd
000cf6d0: 85 10 00 00 4b 66 fe ff  call -0x199b5 ; call target 0x2930, ordinal 10
000cf6d8: 79 a3 b0 ff 00 00 00 00  ldxdw r3, [r10 - 0x50]
000cf6e0: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
000cf6e8: 7b 36 08 00 00 00 00 00  stxdw [r6 + 0x8], r3
000cf6f0: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
000cf6f8: 95 00 00 00 00 00 00 00  exit
000cf700: 79 a3 e0 ff 00 00 00 00  ldxdw r3, [r10 - 0x20]
000cf708: bf a1 00 00 00 00 00 00  mov64 r1, r10
000cf710: 07 01 00 00 c8 ff ff ff  add64 r1, -0x38
000cf718: 18 04 00 00 71 75 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7571 ; pointer 0x1b7571 data80 b'mayhem_token_vaultglobal_paramsmint_authoritytoken_programnot implemented: admin'
000cf728: b7 05 00 00 12 00 00 00  mov64 r5, 0x12
000cf730: 85 10 00 00 3f 66 fe ff  call -0x199c1 ; call target 0x2930, ordinal 10
000cf738: 79 a3 d0 ff 00 00 00 00  ldxdw r3, [r10 - 0x30]
000cf740: 79 a1 c8 ff 00 00 00 00  ldxdw r1, [r10 - 0x38]
000cf748: 05 00 f3 ff 00 00 00 00  ja -0xd <.text+0xcf5c8> ; branch 0xcf6e8
