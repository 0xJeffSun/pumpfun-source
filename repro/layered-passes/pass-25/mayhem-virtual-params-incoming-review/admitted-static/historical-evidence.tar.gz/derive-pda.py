#!/usr/bin/env python3
"""Pure public-address derivation; no transaction, keypair, signer, or network."""
import json
from solders.pubkey import Pubkey

program = Pubkey.from_string('MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e')
seed = b'sol-vault'
pda, bump = Pubkey.find_program_address([seed], program)
print(json.dumps({
    'scope': 'Pure public-address derivation only; no keypair, transaction, signature, fixture, VM, or network use',
    'program_id': str(program), 'seeds_hex': [seed.hex()],
    'pda': str(pda), 'bump': bump, 'is_on_ed25519_curve': pda.is_on_curve(),
    'signer_required': True,
}, indent=2))
