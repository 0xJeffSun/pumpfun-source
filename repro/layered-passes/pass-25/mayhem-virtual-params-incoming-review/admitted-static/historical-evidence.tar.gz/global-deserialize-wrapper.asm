0015fdd0: bf 16 00 00 00 00 00 00  mov64 r6, r1
0015fdd8: 79 21 08 00 00 00 00 00  ldxdw r1, [r2 + 0x8]
0015fde0: a5 01 27 00 08 00 00 00  jlt r1, 0x8, +0x27 <custom_panic+0x8c68> ; branch 0x15ff20
0015fde8: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
0015fdf0: 79 11 00 00 00 00 00 00  ldxdw r1, [r1 + 0x0]
0015fdf8: 18 03 00 00 a7 e8 e8 b1 00 00 00 00 c8 6c 72 7f  lddw r3, 0x7f726cc8b1e8e8a7
0015fe08: 1d 31 50 00 00 00 00 00  jeq r1, r3, +0x50 <custom_panic+0x8dd8> ; branch 0x160090
0015fe10: bf a1 00 00 00 00 00 00  mov64 r1, r10
0015fe18: 07 01 00 00 90 ff ff ff  add64 r1, -0x70
0015fe20: 18 02 00 00 14 5f 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1b5f14 ; pointer 0x1b5f14 data80 b'\xba\x0b\x00\x00\r\x00\x00\x00\n\x00\x00\x00\x1b\x00\x00\x000\x00\x00\x00#\x00\x00\x00rent    N\x00\x00\x00>\x00\x00\x00data\x15\x00\x00\x00,\x00\x00\x00mint@\x00\x00\x00Z\x00\x00\x00\x1a\x00\x00\x00H\x00\x00\x00a\x00\x00\x00\x06\x10\x00\x00'
0015fe30: 85 10 00 00 1f 7d 00 00  call 0x7d1f ; call target 0x19e730, ordinal 808
0015fe38: 7a 0a b8 ff 00 00 00 00  stdw [r10 - 0x48], 0x0
0015fe40: 7a 0a b0 ff 01 00 00 00  stdw [r10 - 0x50], 0x1
0015fe48: 7a 0a a8 ff 00 00 00 00  stdw [r10 - 0x58], 0x0
0015fe50: 18 01 00 00 38 d8 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1bd838 ; pointer 0x1bd838 data80 b'\x00\x00\x00\x00\x00\xaf\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00X\xd2\x00\x00\x00\x00\x00\x00@\xd2\x00\x00\x00\x00\x00\x00X\xac\x00\x00\x00\x00\x00\x00\xf8\xae\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\xd2\x00\x00'
0015fe60: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
0015fe68: bf a1 00 00 00 00 00 00  mov64 r1, r10
0015fe70: 07 01 00 00 a8 ff ff ff  add64 r1, -0x58
0015fe78: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
0015fe80: 72 0a f8 ff 03 00 00 00  stb [r10 - 0x8], 0x3
0015fe88: 7a 0a f0 ff 20 00 00 00  stdw [r10 - 0x10], 0x20
0015fe90: 7a 0a d0 ff 00 00 00 00  stdw [r10 - 0x30], 0x0
0015fe98: 7a 0a c0 ff 00 00 00 00  stdw [r10 - 0x40], 0x0
0015fea0: bf a2 00 00 00 00 00 00  mov64 r2, r10
0015fea8: 07 02 00 00 c0 ff ff ff  add64 r2, -0x40
0015feb0: 18 01 00 00 14 5f 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b5f14 ; pointer 0x1b5f14 data80 b'\xba\x0b\x00\x00\r\x00\x00\x00\n\x00\x00\x00\x1b\x00\x00\x000\x00\x00\x00#\x00\x00\x00rent    N\x00\x00\x00>\x00\x00\x00data\x15\x00\x00\x00,\x00\x00\x00mint@\x00\x00\x00Z\x00\x00\x00\x1a\x00\x00\x00H\x00\x00\x00a\x00\x00\x00\x06\x10\x00\x00'
0015fec0: 85 10 00 00 d5 7e 00 00  call 0x7ed5 ; call target 0x19f570, ordinal 810
0015fec8: 15 00 11 00 00 00 00 00  jeq r0, 0x0, +0x11 <custom_panic+0x8ca0> ; branch 0x15ff58
0015fed0: bf a3 00 00 00 00 00 00  mov64 r3, r10
0015fed8: 07 03 00 00 f0 fe ff ff  add64 r3, -0x110
0015fee0: 18 01 00 00 a4 5f 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b5fa4 ; pointer 0x1b5fa4 data80 b'a Display implementation returned an error unexpectedly/home/runner/work/platfor'
0015fef0: b7 02 00 00 37 00 00 00  mov64 r2, 0x37
0015fef8: 18 04 00 00 68 d8 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1bd868 ; pointer 0x1bd868 data80 b'\x00\x00\x00\x00\xf8\xae\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\xd2\x00\x00\x00\x00\x00\x00\xdb_\x1b\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\xf0\xae\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00'
0015ff08: 18 05 00 00 88 d8 1b 00 00 00 00 00 00 00 00 00  lddw r5, 0x1bd888 ; pointer 0x1bd888 data80 b'\x00\x00\x00\x00\xdb_\x1b\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\xf0\xae\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\xa8\x00\x00\x00\x00\x00\x00z_\x1b\x00\r\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x006\x00\x00\x00'
0015ff18: 85 10 00 00 df 99 00 00  call 0x99df ; call target 0x1ace18, ordinal 961
0015ff20: bf a1 00 00 00 00 00 00  mov64 r1, r10
0015ff28: 07 01 00 00 c0 fe ff ff  add64 r1, -0x140
0015ff30: b7 02 00 00 b9 0b 00 00  mov64 r2, 0xbb9
0015ff38: 85 10 00 00 7c 7e 00 00  call 0x7e7c ; call target 0x19f320, ordinal 809
0015ff40: 79 a1 c0 fe 00 00 00 00  ldxdw r1, [r10 - 0x140]
0015ff48: 79 a2 c8 fe 00 00 00 00  ldxdw r2, [r10 - 0x138]
0015ff50: 05 00 23 00 00 00 00 00  ja +0x23 <custom_panic+0x8db8> ; branch 0x160070
0015ff58: 79 a1 b8 ff 00 00 00 00  ldxdw r1, [r10 - 0x48]
0015ff60: 7b 1a 38 ff 00 00 00 00  stxdw [r10 - 0xc8], r1
0015ff68: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
0015ff70: 7b 1a 30 ff 00 00 00 00  stxdw [r10 - 0xd0], r1
0015ff78: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
0015ff80: 7b 1a 28 ff 00 00 00 00  stxdw [r10 - 0xd8], r1
0015ff88: 79 a1 90 ff 00 00 00 00  ldxdw r1, [r10 - 0x70]
0015ff90: 7b 1a 10 ff 00 00 00 00  stxdw [r10 - 0xf0], r1
0015ff98: 79 a1 98 ff 00 00 00 00  ldxdw r1, [r10 - 0x68]
0015ffa0: 7b 1a 18 ff 00 00 00 00  stxdw [r10 - 0xe8], r1
0015ffa8: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
0015ffb0: 7b 1a 20 ff 00 00 00 00  stxdw [r10 - 0xe0], r1
0015ffb8: 18 01 00 00 c5 72 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b72c5 ; pointer 0x1b72c5 data80 b'programs/pump/src/lib.rsbuyback_fee never exceeds protocol_feebuyback fee is at '
0015ffc8: 7b 1a f8 fe 00 00 00 00  stxdw [r10 - 0x108], r1
0015ffd0: 62 0a 88 ff ba 0b 00 00  stw [r10 - 0x78], 0xbba
0015ffd8: 72 0a 40 ff 02 00 00 00  stb [r10 - 0xc0], 0x2
0015ffe0: 62 0a 08 ff 17 07 00 00  stw [r10 - 0xf8], 0x717
0015ffe8: 7a 0a 00 ff 18 00 00 00  stdw [r10 - 0x100], 0x18
0015fff0: 7a 0a f0 fe 00 00 00 00  stdw [r10 - 0x110], 0x0
0015fff8: bf a1 00 00 00 00 00 00  mov64 r1, r10
00160000: 07 01 00 00 e0 fe ff ff  add64 r1, -0x120
00160008: bf a2 00 00 00 00 00 00  mov64 r2, r10
00160010: 07 02 00 00 f0 fe ff ff  add64 r2, -0x110
00160018: 85 10 00 00 62 77 00 00  call 0x7762 ; call target 0x19bb30, ordinal 792
00160020: 79 a3 e8 fe 00 00 00 00  ldxdw r3, [r10 - 0x118]
00160028: 79 a2 e0 fe 00 00 00 00  ldxdw r2, [r10 - 0x120]
00160030: bf a1 00 00 00 00 00 00  mov64 r1, r10
00160038: 07 01 00 00 d0 fe ff ff  add64 r1, -0x130
00160040: 18 04 00 00 a1 7a 1b 00 00 00 00 00 00 00 00 00  lddw r4, 0x1b7aa1 ; pointer 0x1b7aa1 data80 b'Global\x05*\xe5\xd7\xa7\xda\xa7$\xa6\xea\xb0\xa7)T\x91\x85Z\xd4\xa0g\x16`gLN\x03EY\x80=e\xa3Instruction: IdlCreateAccountInstruction: '
00160050: b7 05 00 00 06 00 00 00  mov64 r5, 0x6
00160058: 85 10 00 00 1a 45 fd ff  call -0x2bae6 ; call target 0x2930, ordinal 10
00160060: 79 a1 d0 fe 00 00 00 00  ldxdw r1, [r10 - 0x130]
00160068: 79 a2 d8 fe 00 00 00 00  ldxdw r2, [r10 - 0x128]
00160070: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
00160078: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
00160080: 72 06 37 04 02 00 00 00  stb [r6 + 0x437], 0x2
00160088: 95 00 00 00 00 00 00 00  exit
00160090: bf 61 00 00 00 00 00 00  mov64 r1, r6
00160098: 85 10 00 00 01 00 00 00  call 0x1 ; call target 0x1600a8, ordinal 593
001600a0: 05 00 fc ff 00 00 00 00  ja -0x4 <custom_panic+0x8dd0> ; branch 0x160088
