#!/usr/bin/env python3
"""Verify static evidence only; never builds or executes recovered program logic."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((W / 'manifest.json').read_text())
for row in manifest['files']:
    data = (W / row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert sha(data) == row['sha256'], row['path']
actual = {str(p.relative_to(W)) for p in W.rglob('*') if p.is_file()
          and '__pycache__' not in p.parts
          and p.name not in {'manifest.json', 'verification-result.json'}}
assert actual == {r['path'] for r in manifest['files']}
inputs = json.loads((W / 'inputs.json').read_text())
assert inputs['source_git_revision'] == '49e4ccc17ab45308ff3160d20c3d580512b772af'
for row in [inputs['original_elf'], inputs['published_candidate_elf'],
            inputs['source_assembly'], *inputs['references']]:
    data = (ROOT / row['path']).read_bytes()
    assert sha(data) == row['sha256'], row['path']
    if 'bytes' in row:
        assert len(data) == row['bytes'], row['path']
for row in inputs['baseline_source_files']:
    data = (ROOT / row['path']).read_bytes()
    saved = subprocess.check_output(['git', 'show',
             f"{inputs['source_git_revision']}:{row['path']}"], cwd=ROOT)
    assert saved == data, row['path']
    assert sha(data) == row['sha256'], row['path']
original = (ROOT / inputs['original_elf']['path']).read_bytes()
instructions = branches = calls = 0
for window in inputs['windows']:
    start, end = int(window['start'], 16), int(window['end'], 16)
    assert end - start == window['bytes']
    assert sha(original[start:end]) == window['sha256']
    rows = json.loads((W / (window['name'] + '.json')).read_text())
    cursor = start
    for row in rows:
        at = int(row['at'], 16)
        raw = bytes.fromhex(row['raw_hex'])
        assert at == cursor
        assert original[at:at + len(raw)] == raw
        cursor += len(raw)
        instructions += 1
        if 'branch_displacement' in row:
            displacement = struct.unpack_from('<h', raw, 2)[0]
            assert displacement == row['branch_displacement']
            assert at + 8 + displacement * 8 == int(row['branch_target'], 16)
            branches += 1
        if 'call_target' in row:
            assert raw[0] == 0x85 and raw[1] >> 4 == 1
            assert at + 8 + struct.unpack_from('<i', raw, 4)[0] * 8 == int(row['call_target'], 16)
            calls += 1
        if 'pointer' in row:
            pointer = int(row['pointer'], 16)
            assert original[pointer:pointer + 80].hex() == row['data80_hex']
    assert cursor == end
    assert (W / (window['name'] + '.asm')).read_text() == '\n'.join(r['annotated'] for r in rows) + '\n'
assert inputs['full_bytes_equal'] is False
assert inputs['recovered_handler_count_increment'] == 0
result = {
    'result': 'pass', 'scope': 'static evidence verification only',
    'package_files': len(manifest['files']), 'windows': len(inputs['windows']),
    'instructions': instructions, 'branch_targets': branches,
    'direct_call_targets': calls, 'frozen_source_inputs': len(inputs['baseline_source_files']),
    'source_git_revision': inputs['source_git_revision'],
    'published_candidate_sha256': inputs['published_candidate_elf']['sha256'],
    'original_sha256': inputs['original_elf']['sha256'],
    'main_pump_sources_unchanged': True, 'builds': 0, 'runtime_receipts': 0,
    'full_bytes_equal': False, 'recovered_handler_count_increment': 0,
    'manifest_sha256': sha((W / 'manifest.json').read_bytes())
}
print(json.dumps(result, indent=2))
