00002e48: bf 27 00 00 00 00 00 00  mov64 r7, r2
00002e50: bf 16 00 00 00 00 00 00  mov64 r6, r1
00002e58: 79 78 18 00 00 00 00 00  ldxdw r8, [r7 + 0x18]
00002e60: bf 81 00 00 00 00 00 00  mov64 r1, r8
00002e68: 18 02 00 00 a8 5b 1b 00 00 00 00 00 00 00 00 00  lddw r2, 0x1b5ba8 ; pointer 0x1b5ba8 data80 b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)FShare bps must b'
00002e78: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00002e80: 85 10 00 00 fe 60 03 00  call 0x360fe ; call target 0x1b3678, ordinal 1024
00002e88: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00002e90: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
00002e98: 15 00 45 00 00 00 00 00  jeq r0, 0x0, +0x45 <.text+0x2fa8> ; branch 0x30c8
00002ea0: 18 09 00 00 34 9f 1b 00 00 00 00 00 00 00 00 00  lddw r9, 0x1b9f34 ; pointer 0x1b9f34 data80 b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/de/mod.rsfai"
00002eb0: 18 01 00 00 34 9f 1b 00 00 00 00 00 00 00 00 00  lddw r1, 0x1b9f34 ; pointer 0x1b9f34 data80 b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/de/mod.rsfai"
00002ec0: bf 82 00 00 00 00 00 00  mov64 r2, r8
00002ec8: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00002ed0: 85 10 00 00 f4 60 03 00  call 0x360f4 ; call target 0x1b3678, ordinal 1024
00002ed8: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00002ee0: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
00002ee8: 15 00 1e 00 00 00 00 00  jeq r0, 0x0, +0x1e <.text+0x2ec0> ; branch 0x2fe0
00002ef0: 07 09 00 00 20 00 00 00  add64 r9, 0x20
00002ef8: bf 91 00 00 00 00 00 00  mov64 r1, r9
00002f00: bf 82 00 00 00 00 00 00  mov64 r2, r8
00002f08: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00002f10: 85 10 00 00 ec 60 03 00  call 0x360ec ; call target 0x1b3678, ordinal 1024
00002f18: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00002f20: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
00002f28: 15 00 16 00 00 00 00 00  jeq r0, 0x0, +0x16 <.text+0x2ec0> ; branch 0x2fe0
00002f30: bf a1 00 00 00 00 00 00  mov64 r1, r10
00002f38: 07 01 00 00 30 ff ff ff  add64 r1, -0xd0
00002f40: b7 02 00 00 bf 0b 00 00  mov64 r2, 0xbbf
00002f48: 85 10 00 00 7a 38 03 00  call 0x3387a ; call target 0x19f320, ordinal 809
00002f50: 79 a3 38 ff 00 00 00 00  ldxdw r3, [r10 - 0xc8]
00002f58: 79 a2 30 ff 00 00 00 00  ldxdw r2, [r10 - 0xd0]
00002f60: 79 81 18 00 00 00 00 00  ldxdw r1, [r8 + 0x18]
00002f68: 7b 1a 68 ff 00 00 00 00  stxdw [r10 - 0x98], r1
00002f70: 79 81 10 00 00 00 00 00  ldxdw r1, [r8 + 0x10]
00002f78: 7b 1a 60 ff 00 00 00 00  stxdw [r10 - 0xa0], r1
00002f80: 79 81 08 00 00 00 00 00  ldxdw r1, [r8 + 0x8]
00002f88: 7b 1a 58 ff 00 00 00 00  stxdw [r10 - 0xa8], r1
00002f90: 79 81 00 00 00 00 00 00  ldxdw r1, [r8 + 0x0]
00002f98: 7b 1a 50 ff 00 00 00 00  stxdw [r10 - 0xb0], r1
00002fa0: bf a1 00 00 00 00 00 00  mov64 r1, r10
00002fa8: 07 01 00 00 20 ff ff ff  add64 r1, -0xe0
00002fb0: bf a4 00 00 00 00 00 00  mov64 r4, r10
00002fb8: 07 04 00 00 50 ff ff ff  add64 r4, -0xb0
00002fc0: 85 10 00 00 dd fe ff ff  call -0x123 ; call target 0x26b0, ordinal 9
00002fc8: 79 a1 20 ff 00 00 00 00  ldxdw r1, [r10 - 0xe0]
00002fd0: 15 01 01 00 02 00 00 00  jeq r1, 0x2, +0x1 <.text+0x2ec0> ; branch 0x2fe0
00002fd8: 05 00 5a 00 00 00 00 00  ja +0x5a <.text+0x3190> ; branch 0x32b0
00002fe0: bf a1 00 00 00 00 00 00  mov64 r1, r10
00002fe8: 07 01 00 00 50 ff ff ff  add64 r1, -0xb0
00002ff0: bf 72 00 00 00 00 00 00  mov64 r2, r7
00002ff8: 85 10 00 00 95 3f 03 00  call 0x33f95 ; call target 0x1a2ca8, ordinal 844
00003000: 79 a9 60 ff 00 00 00 00  ldxdw r9, [r10 - 0xa0]
00003008: 79 a1 58 ff 00 00 00 00  ldxdw r1, [r10 - 0xa8]
00003010: 79 a2 50 ff 00 00 00 00  ldxdw r2, [r10 - 0xb0]
00003018: 18 03 00 00 1a 00 00 00 00 00 00 00 00 00 00 80  lddw r3, -0x7fffffffffffffe6
00003028: 1d 32 01 00 00 00 00 00  jeq r2, r3, +0x1 <.text+0x2f18> ; branch 0x3038
00003030: 05 00 1c 00 00 00 00 00  ja +0x1c <.text+0x2ff8> ; branch 0x3118
00003038: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
00003040: 79 11 08 00 00 00 00 00  ldxdw r1, [r1 + 0x8]
00003048: 7b 1a 48 ff 00 00 00 00  stxdw [r10 - 0xb8], r1
00003050: 7b 2a 40 ff 00 00 00 00  stxdw [r10 - 0xc0], r2
00003058: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003060: 07 01 00 00 50 ff ff ff  add64 r1, -0xb0
00003068: bf a2 00 00 00 00 00 00  mov64 r2, r10
00003070: 07 02 00 00 40 ff ff ff  add64 r2, -0xc0
00003078: 85 10 00 00 ca 05 03 00  call 0x305ca ; call target 0x185ed0, ordinal 660
00003080: 79 a2 58 ff 00 00 00 00  ldxdw r2, [r10 - 0xa8]
00003088: 79 a1 50 ff 00 00 00 00  ldxdw r1, [r10 - 0xb0]
00003090: 61 a3 d8 ff 00 00 00 00  ldxw r3, [r10 - 0x28]
00003098: 15 03 01 00 02 00 00 00  jeq r3, 0x2, +0x1 <.text+0x2f88> ; branch 0x30a8
000030a0: 05 00 1b 00 00 00 00 00  ja +0x1b <.text+0x3060> ; branch 0x3180
000030a8: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
000030b0: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
000030b8: 62 06 b0 00 02 00 00 00  stw [r6 + 0xb0], 0x2
000030c0: 05 00 39 00 00 00 00 00  ja +0x39 <.text+0x3170> ; branch 0x3290
000030c8: bf 71 00 00 00 00 00 00  mov64 r1, r7
000030d0: 85 10 00 00 23 3f 03 00  call 0x33f23 ; call target 0x1a29f0, ordinal 838
000030d8: 55 00 b8 ff 00 00 00 00  jne r0, 0x0, -0x48 <.text+0x2d80> ; branch 0x2ea0
000030e0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000030e8: 07 01 00 00 00 ff ff ff  add64 r1, -0x100
000030f0: b7 02 00 00 c4 0b 00 00  mov64 r2, 0xbc4
000030f8: 85 10 00 00 44 38 03 00  call 0x33844 ; call target 0x19f320, ordinal 809
00003100: 79 a1 00 ff 00 00 00 00  ldxdw r1, [r10 - 0x100]
00003108: 79 a2 08 ff 00 00 00 00  ldxdw r2, [r10 - 0xf8]
00003110: 05 00 0a 00 00 00 00 00  ja +0xa <.text+0x3048> ; branch 0x3168
00003118: 7b 9a 60 ff 00 00 00 00  stxdw [r10 - 0xa0], r9
00003120: 7b 1a 58 ff 00 00 00 00  stxdw [r10 - 0xa8], r1
00003128: 7b 2a 50 ff 00 00 00 00  stxdw [r10 - 0xb0], r2
00003130: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003138: 07 01 00 00 10 ff ff ff  add64 r1, -0xf0
00003140: bf a2 00 00 00 00 00 00  mov64 r2, r10
00003148: 07 02 00 00 50 ff ff ff  add64 r2, -0xb0
00003150: 85 10 00 00 4c 31 03 00  call 0x3314c ; call target 0x19bbb8, ordinal 793
00003158: 79 a1 10 ff 00 00 00 00  ldxdw r1, [r10 - 0xf0]
00003160: 79 a2 18 ff 00 00 00 00  ldxdw r2, [r10 - 0xe8]
00003168: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
00003170: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
00003178: 05 00 29 00 00 00 00 00  ja +0x29 <.text+0x31a8> ; branch 0x32c8
00003180: 7b 1a f8 fe 00 00 00 00  stxdw [r10 - 0x108], r1
00003188: bf 61 00 00 00 00 00 00  mov64 r1, r6
00003190: 07 01 00 00 38 00 00 00  add64 r1, 0x38
00003198: 7b 2a f0 fe 00 00 00 00  stxdw [r10 - 0x110], r2
000031a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000031a8: 07 02 00 00 60 ff ff ff  add64 r2, -0xa0
000031b0: 7b 3a e8 fe 00 00 00 00  stxdw [r10 - 0x118], r3
000031b8: b7 03 00 00 78 00 00 00  mov64 r3, 0x78
000031c0: 85 10 00 00 89 60 03 00  call 0x36089 ; call target 0x1b3610, ordinal 1021
000031c8: 79 a1 dc ff 00 00 00 00  ldxdw r1, [r10 - 0x24]
000031d0: 7b 16 b4 00 00 00 00 00  stxdw [r6 + 0xb4], r1
000031d8: 79 a1 e4 ff 00 00 00 00  ldxdw r1, [r10 - 0x1c]
000031e0: 7b 16 bc 00 00 00 00 00  stxdw [r6 + 0xbc], r1
000031e8: 79 a1 ec ff 00 00 00 00  ldxdw r1, [r10 - 0x14]
000031f0: 7b 16 c4 00 00 00 00 00  stxdw [r6 + 0xc4], r1
000031f8: 79 a1 f4 ff 00 00 00 00  ldxdw r1, [r10 - 0xc]
00003200: 7b 16 cc 00 00 00 00 00  stxdw [r6 + 0xcc], r1
00003208: 61 a1 fc ff 00 00 00 00  ldxw r1, [r10 - 0x4]
00003210: 63 16 d4 00 00 00 00 00  stxw [r6 + 0xd4], r1
00003218: 79 81 18 00 00 00 00 00  ldxdw r1, [r8 + 0x18]
00003220: 7b 16 18 00 00 00 00 00  stxdw [r6 + 0x18], r1
00003228: 79 81 10 00 00 00 00 00  ldxdw r1, [r8 + 0x10]
00003230: 7b 16 10 00 00 00 00 00  stxdw [r6 + 0x10], r1
00003238: 79 81 08 00 00 00 00 00  ldxdw r1, [r8 + 0x8]
00003240: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
00003248: 79 81 00 00 00 00 00 00  ldxdw r1, [r8 + 0x0]
00003250: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
00003258: 79 a1 e8 fe 00 00 00 00  ldxdw r1, [r10 - 0x118]
00003260: 63 16 b0 00 00 00 00 00  stxw [r6 + 0xb0], r1
00003268: 79 a1 f0 fe 00 00 00 00  ldxdw r1, [r10 - 0x110]
00003270: 7b 16 30 00 00 00 00 00  stxdw [r6 + 0x30], r1
00003278: 79 a1 f8 fe 00 00 00 00  ldxdw r1, [r10 - 0x108]
00003280: 7b 16 28 00 00 00 00 00  stxdw [r6 + 0x28], r1
00003288: 7b 76 20 00 00 00 00 00  stxdw [r6 + 0x20], r7
00003290: 79 91 00 00 00 00 00 00  ldxdw r1, [r9 + 0x0]
00003298: 07 01 00 00 ff ff ff ff  add64 r1, -0x1
000032a0: 7b 19 00 00 00 00 00 00  stxdw [r9 + 0x0], r1
000032a8: 05 00 04 00 00 00 00 00  ja +0x4 <.text+0x31b0> ; branch 0x32d0
000032b0: 79 a2 28 ff 00 00 00 00  ldxdw r2, [r10 - 0xd8]
000032b8: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
000032c0: 7b 26 08 00 00 00 00 00  stxdw [r6 + 0x8], r2
000032c8: 62 06 b0 00 02 00 00 00  stw [r6 + 0xb0], 0x2
000032d0: 95 00 00 00 00 00 00 00  exit
