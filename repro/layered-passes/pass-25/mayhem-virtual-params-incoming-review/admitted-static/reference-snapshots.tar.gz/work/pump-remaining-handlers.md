# Remaining Pump handler ownership inventory

Read-only inventory against current main29 and captured official IDL. There are **56 IDL instructions, 31 source dispatch wrappers: 29 recovered handlers and two partial trade paths**. Thus25 IDL instructions have no main dispatch wrapper. This counts actual Rust wrappers, not stale ledger totals. Existing `buy_v3` and `sell_v3` remain partial despite being present.

## Assigned or excluded

- Claude owns six quote-control handlers: `initialize_quote_control`, `add_quote_control_mint`, `remove_quote_control_mint`, `set_quote_control_admin`, `set_quote_control_mint_reserves`, `set_quote_control_reserves_admin`. Evidence/scratch: `work/pump-quote-control-recovery/`. Do not duplicate.
- Parent owns `buy_exact_quote_in_v3`: `work/pump-exact-quote-recovery/`.
- Another child owns `create` and `create_v2`: `work/pump-create-recovery/`.
- `admin_update_token_incentives` and `claim_token_incentives` belong to the stopped Pump incentives experiment (`work/pump-incentives-recovery/`). Excluded from proposed work. The stopped Mayhem initializer experiment is also excluded; it is not a Pump IDL instruction.

The current task's explicit assignments take precedence over `work/coordination-surfpool.md`, whose append-only history contains older checkpoint counts. The ledger also assigns AMM cashback to root; that is a separate program, not evidence that Pump cashback is implemented.

## Remaining unassigned Pump instructions

“Unassigned” means no current ownership found in the supplied assignment or ledger; it is not permission to start a new lane without coordination.

| Handlers | Available evidence / starting point | Prerequisites and boundary |
| --- | --- | --- |
| `sell` | `scripts/pump_validate_sell.py`, `work/pump-recovery/expanded-validate-sell.py`, `sell-sbf-differential.json`, main `trade.rs`/`trade_types.rs` | Best next independent candidate: legacy account context with ordinary user signer, captured Token and Fees. Existing saved sell tests cover v3, so they are reusable infrastructure, not proof of this handler. Recover legacy vault payout, fee CPI, rounding, optional remaining-account behavior and events separately. |
| `buy`, `buy_exact_sol_in` | `scripts/pump_validate_buy.py`, `work/pump-recovery/probe-buy-fill.py`, `probe-buy-complete.py` | Ordinary user signer, Token/Fees and volume accumulators. Track-volume/partial-fill flags and cashback branches need separate coverage. Exact-input arithmetic overlaps parent's exact-quote lane; coordinate helper ownership before implementation. Do not resume stopped incentives handlers. |
| `buy_v2`, `sell_v2`, `buy_exact_quote_in_v2` | `scripts/pump_validate_quote.py`, `work/pump-recovery/probe-quote-buy.py`, `probe-quote-sell.py`, main trade parser | Token/Token2022/ATA/Fees, quote-side wallets/vaults, sharing and volume state. More account/CPI overlap with partial-v3 and exact-quote work; defer until shared arithmetic/interface handoff. |
| `initialize` | Official IDL: Global, ordinary writable user signer, System Program | Small static-first alternative. Determine original authorization/default values and creation behavior before assuming arbitrary ordinary-user success. No recovered Pump initializer fixture located in the shallow scratch inventory. IDL alone cannot exclude a body-level hardcoded authority. |
| `migrate`, `migrate_v2` | Official IDL plus captured `evidence/original/pump_amm/`, existing `work/pump-admin-cto-recovery/` and sharing fixtures | Ordinary user signer in IDL; genuine captured AMM pool creation, Token/Token2022/ATA, pool authority and completed curve state needed. Existing administrative CPI fixtures help setup but do not prove migration parity. Larger independent lane; no forged pool-authority signatures. |
| `claim_cashback`, `claim_cashback_v2` | Existing volume-layout/sync fixtures in `work/pump-volume-sync-recovery/`; official IDL | No user signer marked in these instruction accounts; transaction still needs an ordinary payer. Native/token accumulator ownership, rent floors and actual transfer rules require recovery. Do not reuse or extend the stopped Pump claim experiment; clarify scope with coordinator first. AMM cashback work is only an analogy. |
| `distribute_fee_to_holders` | Official IDL; holder-reward fields and original dependency captures | Global-bound holder_reward_claim_authority is an ordinary signer in IDL, but this is a payout/claim-adjacent lane. Defer pending coordinator scope review; no inference of authorization from injected state or prior incentives work. |
| `set_mayhem_virtual_params` | IDL explicitly requires signer PDA `sol-vault` under the Mayhem program | Not an ordinary direct-call lane. Static caller/context recovery only unless a legitimate captured-program CPI path is separately reviewed. Do not revive stopped Mayhem initialization or sign that PDA directly. |
| `multi_hop_curve_swap` | IDL explicitly requires AMM GlobalConfig PDA signer, plus user/source authority | Needs a genuine captured AMM caller and quote-chain/pool infrastructure. Static research possible; no direct forged signer. Depends heavily on nested-quote recovery, so not a good next independent runtime lane. |

## Recommendation and remaining source gaps

Recommend isolated legacy `sell` after coordinator claims it. It has no new privileged signer requirement in the IDL and existing ordinary signed trade infrastructure can be reused without modifying the active exact-input or creation lanes. Use the captured original and real dependencies; keep main unchanged until a standalone frozen candidate and receipts exist. This inventory ran no runtime probes and does not claim a successful legacy sell path already exists.

Main's partial-v3 routes still omit general quote chains/multi-hop behavior and exhaustive token-extension/account validation. Their trailing TradeEvent field interpretation remains unresolved. The extra `ReconstructionBranchUnsupported` error is documented in `work/pump-error-enum-review/REPORT.md`; removal depends on replacing those unsupported branches. Behavioral coverage, complete handler coverage and byte identity remain separate goals. Compiler/dependency provenance and whole-program instruction layout remain unresolved even for recovered handlers.

## Snapshot evidence

- Pump lib.rs SHA256: `17cd91e580c65638c863c4e001a4b335462d4b94b0e74d3fc07445dcc6d75104`.
- Official IDL SHA256: `7616681ea557975f9f623ac211080f22a93060781eaf4765b0a488d980997207`.
- Latest packaged baseline: `repro/pump/creator-twentynine/summary.json` (4590 cases; full byte equality false).

Missing main dispatch wrappers (exact inventory):

`add_quote_control_mint`, `admin_update_token_incentives`, `buy`, `buy_exact_quote_in_v2`, `buy_exact_quote_in_v3`, `buy_exact_sol_in`, `buy_v2`, `claim_cashback`, `claim_cashback_v2`, `claim_token_incentives`, `create`, `create_v2`, `distribute_fee_to_holders`, `initialize`, `initialize_quote_control`, `migrate`, `migrate_v2`, `multi_hop_curve_swap`, `remove_quote_control_mint`, `sell`, `sell_v2`, `set_mayhem_virtual_params`, `set_quote_control_admin`, `set_quote_control_mint_reserves`, `set_quote_control_reserves_admin`.
