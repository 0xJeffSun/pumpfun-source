# Pump global initialization recovery

Parent-assigned isolated lane. The latest `work/coordination-surfpool.md` was checked before implementation; no competing explicit claim for these Pump handlers was found. Main source and released buy packages remain untouched. Scratch baseline is the frozen main33 source copied from buy-v2 recovery, with its two buy-v2 additions removed before adding this module.

## Initialize: frozen and ready

The original captured Pump accepts ordinary test-owned initializer signers. Two unrelated keys independently created a 1088-byte Global account with initialized=true, authority=user and all remaining payload bytes zero. No event is emitted. The rent funding observed at the default local rent parameters is 8,463,360 lamports.

The focused implementation is `crate/src/global_init.rs`, SHA-256 `c5d65cd6536d9d0b18c4152617052023bc800f6a0c5652e031c33d90f1747891`. Integration needs its module/export and `initialize(Context<Initialize>)` wrapper only; do not copy the baseline crate over newer main source.

Clean build1 selected platform-tools v1.44 and retained the baseline lockfile. All recorded source hashes were reverified after execution. Candidate is 1,140,584 bytes, SHA-256 `84f1e7d9cb20b72f1f3de171108dc68ae2bf6523b288f4baaf3b8120c3c0c4a5`. This does not identify the original historical compiler version.

- **40/40** differential cases match errors, account data/balances, event bytes, inner instructions and return data.
- **14/14** Surfpool comparisons match, with **28 normally signed transactions** and no unexpected original errors.
- Cases include normal initialization, trailing instruction bytes, extra/missing accounts, wrong global/system addresses, readonly and unsigned account metas, insufficient/exact rent payer funds, prefunded empty system PDAs, preexisting program-owned accounts, discriminator/initialized variants and combined-invalid precedence.

Transactions retain ordinary test-owned signatures and verification. Tests execute captured original Pump offline; no live writes or privileged signer substitution. Source, build provenance, harnesses and compressed raw receipts are bound by `freeze-manifest.json`. Whole-program byte equality remains false; these bounded comparisons do not establish exhaustive parity.

## set_mayhem_virtual_params: prerequisite prevents this lane from proceeding

Official `evidence/upstream/pump.json` declares the first account `sol_vault_authority` writable and signer, constrained to seeds `sol-vault` under external program `MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`. The resulting PDA is `BwWK17cbHxwWBKZkUYvzxLcNQ1YVyaFezduWbtm2de6s`. This is not an ordinary test-owned signing key. The remaining context includes its Token2022 mint ATA, mint, Global PDA, bonding-curve PDA, Token2022 program and event CPI accounts; there are no instruction arguments.

A legitimate execution would need a reviewed instruction in the genuine captured external program that invokes Pump and signs its actual PDA seeds under normal caller authorization. This lane has not established that prerequisite. No direct invocation, fabricated signature, verification bypass, replacement privileged program or stopped Mayhem initializer experiment was attempted. No body is reconstructed or counted for this handler. Parent should assign a different lane or review an independently established legitimate caller before further execution work here.

## Reproduction

```sh
CARGO_HOME="$PWD/work/fees-v144-cargo-home" python3.12 scripts/build_partial_candidate.py --manifest work/pump-global-init-recovery/crate/Cargo.toml --program pump --artifact-name pump_recovered.so --tools-version v1.44 --output <fresh-build-dir>
work/localnet/venv/bin/python scripts/pump_global_init_differential.py --candidate <fresh-build-dir>/artifacts/pump_recovered.so --output <receipt.json>
work/localnet/venv/bin/python scripts/pump_global_init_surfpool.py --candidate <fresh-build-dir>/artifacts/pump_recovered.so --output <fresh-surfpool-dir>
```

Surfpool reserves localhost ports20261/20262. Raw receipts preserve transaction bytes, signatures and logs. Executable image bytes are excluded from semantic state comparison while candidate/original hashes are recorded separately.
