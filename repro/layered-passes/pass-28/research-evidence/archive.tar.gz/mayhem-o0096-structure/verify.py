"""Portable saved-only verifier for the exact complete O0096 structural review."""
from pathlib import Path
import argparse,hashlib,json,importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify(seal):
 assert H(P/'manifest.json')==seal==(P/'manifest.sha256').read_text().split()[0]
 m=json.loads((P/'manifest.json').read_bytes());assert set(m)=={str(p.relative_to(P))for p in P.rglob('*')if p.is_file()and p not in[P/'manifest.json',P/'manifest.sha256']}
 for n,r in m.items():assert not(P/n).is_symlink()and(P/n).stat().st_size==r['bytes']and H(P/n)==r['sha256']
 s=importlib.util.spec_from_file_location('local_saved_structure',P/'derive.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod);actual=json.loads(json.dumps(mod.derive()));expected=json.loads((P/'derive.stdout').read_bytes());assert actual==expected
 exit=json.loads((P/'derive.exit.json').read_bytes());assert exit['returncode']==0 and exit['actual_terminal_completion_observed']is True and exit['stdout_sha256']==H(P/'derive.stdout')and exit['stderr_sha256']==H(P/'derive.stderr')
 return {'passed':True,'records':584,'slots':737,'external_calls_unclosed':12,'opaque_lddw':153,'semantic_ledger_promotion':False,'new_body_data_or_target_execution':0}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--expected-seal',required=True);x=a.parse_args();print(json.dumps(verify(x.expected_seal)))
