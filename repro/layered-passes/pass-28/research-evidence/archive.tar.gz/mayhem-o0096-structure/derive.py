"""Saved-only complete O0096 structural audit; opaque LDDWs and unfollowed calls."""
from pathlib import Path
import hashlib,json,struct,collections
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def derive():
 C=P/'collection';seal='251cf7b5661e8620821a0c27cf2235e302ed42cb4df89a9aecc2362d6977c09a';assert H((C/'manifest.json').read_bytes())==seal
 m=json.loads((C/'manifest.json').read_bytes());m=m.get('files',m);actual={str(p.relative_to(C))for p in C.rglob('*')if p.is_file()and p not in[C/'manifest.json',C/'manifest.sha256']};assert actual==set(m)
 for n,r in m.items():assert not(C/n).is_symlink()and H((C/n).read_bytes())==(r['sha256']if isinstance(r,dict)else r)
 d=json.loads((C/'complete-code-instructions.json').read_bytes());raw=(C/'code-window.bin').read_bytes();assert H(raw)==d['raw_sha256']=='21b2ecaac2bb74aa5e4614f1e1e5665be7e89f062473906785839ce35ddb0bd2';assert d['start']==190160 and d['end']==196056 and len(raw)==5896
 rows=d['instructions'];pc=d['start'];nodes={};edges=[];calls=[];opaque=[];counts=collections.Counter();stores=[];loads=[]
 for row in rows:
  assert row['pc']==pc and row['offset']==pc-d['start'];op,reg,off,imm=struct.unpack_from('<BBhi',raw,pc-d['start']);size=16 if op==24 else 8;assert row['instruction_bytes']==size and row['raw_hex']==raw[pc-d['start']:pc-d['start']+size].hex();assert row['opcode']==op and row['destination_register']==reg&15 and row['source_register']==reg>>4 and row['signed_offset']==off
  if op==24:
   assert row['kind']=='lddw_instruction_payload_opaque'and row['signed_immediate']=='OPAQUE_LDDW_HALVES_NOT_COMBINED';assert raw[pc-d['start']+8:pc-d['start']+12]==b'\0'*4;opaque.append(pc)
  else:assert row['signed_immediate']==imm
  nodes[pc]=row;counts[row['kind']]+=1;nextpc=pc+size
  if op==0x95:succ=[]
  elif op==0x85:
   assert reg>>4==1 and row['target']==pc+8+imm*8 and row['callee_followed']is False;calls.append({'pc':pc,'target':row['target'],'fallthrough_if_returns':nextpc,'callee_contract_proved':False});succ=[nextpc]
  elif op&7 in[5,6]:
   target=pc+8+off*8;assert target==row['target']and row['target_within_window']is True;succ=[target]if op==5 else[target,nextpc]
  else:succ=[nextpc]
  edges.append({'pc':pc,'encoded_successors':succ,'branch_feasibility_asserted':False})
  if op&7 in[2,3]:stores.append({'pc':pc,'opcode':op,'base_register':reg&15,'source_register':reg>>4,'offset':off,'immediate':None if op&7==3 else imm})
  if op&7==1:loads.append({'pc':pc,'opcode':op,'base_register':reg>>4,'destination_register':reg&15,'offset':off})
  pc=nextpc
 assert pc==d['end']and len(rows)==584 and len(raw)//8==737 and len(opaque)==153
 boundary=[]
 for row in edges:
  for target in row['encoded_successors']:
   if target not in nodes:boundary.append({'pc':row['pc'],'successor':target,'scope':'outside admitted interval; no body followed'})
 assert boundary==[{'pc':196048,'successor':196056,'scope':'outside admitted interval; no body followed'}]
 reachable={d['start']};todo=[d['start']];adj={x['pc']:x['encoded_successors']for x in edges}
 while todo:
  for target in adj[todo.pop()]:
   if target in nodes and target not in reachable:reachable.add(target);todo.append(target)
 assert [x['pc']for x in rows if x['opcode']==0x95]==[195848]
 # Common literal-free return record. Register/pointer/type provenance remains open.
 expected=[(195824,0x7b,6,2,8),(195832,0x7b,6,1,16),(195840,0x7b,6,1,0)]
 for at,op,dst,src,off in expected:
  x=nodes[at];assert(x['opcode'],x['destination_register'],x['source_register'],x['signed_offset'])==(op,dst,src,off)
 assert nodes[190160]['opcode']==0xbf and nodes[190160]['destination_register']==6 and nodes[190160]['source_register']==1
 assert nodes[190168]['opcode']==0x61 and nodes[190168]['destination_register']==7 and nodes[190168]['source_register']==2 and nodes[190168]['signed_offset']==0
 lengths=[]
 for i,row in enumerate(rows):
  if row['opcode']==0x85 and row['target']==669768:
   prior=rows[i-3:i];assert len(prior)==3 and prior[0]['opcode']==prior[1]['opcode']==0xb7 and prior[2]['opcode']==24;assert prior[0]['destination_register']==1 and prior[0]['signed_immediate']==1 and prior[1]['destination_register']==2 and prior[2]['destination_register']==3;lengths.append({'call_pc':row['pc'],'r1_constant':1,'r2_constant':prior[1]['signed_immediate'],'r3':'opaque LDDW; not read or interpreted','noreturn_not_proved':True})
 return {'scope':'Complete admitted code interval only; no function/source/ABI or recursive equivalence assertion','source_collection_seal':seal,'instruction_records':len(rows),'covered_8byte_slots':737,'kind_counts':dict(counts),'opaque_lddw_pcs':opaque,'calls_unfollowed':calls,'encoded_edges':edges,'structural_reachable_nodes_with_all_branches_and_returning_calls':len(reachable),'structural_unreachable_pcs':sorted(set(nodes)-reachable),'boundary_fallthrough_if_final_call_returns':boundary,'memory_loads':loads,'memory_stores':stores,'common_return_stores':expected,'external_call_constant_argument_rows':lengths,'new_original_or_candidate_body_bytes':0,'new_literal_data_bytes':0,'called_body_reads':0,'compiler_VM_fixture_executions':0,'semantic_or_ledger_promotion':False,'selected_source_changed':False}
if __name__=='__main__':print(json.dumps(derive(),indent=2))
