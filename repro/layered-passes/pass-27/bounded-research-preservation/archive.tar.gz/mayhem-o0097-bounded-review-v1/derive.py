"""Pure O0097 constant-partition/control/dataflow derivation; opaque LDDWs."""
import hashlib,json
H=lambda b:hashlib.sha256(b).hexdigest()
def derive(window,raw,inventory):
 rows=window['instructions'];by={r['pc']:r for r in rows};start,end=window['start'],window['end']
 assert(start,end,len(raw))==(196056,196888,832)
 assert len(rows)==84 and sum(r['instruction_bytes']//8 for r in rows)==104
 prefix=[(196056,191,3,1,0,0),(196064,121,1,2,0,0),(196072,121,2,2,8,0),(196080,121,4,2,24,0),(196088,97,2,3,0,0)]
 for pc,op,dst,src,off,imm in prefix:
  r=by[pc];assert(r['opcode'],r['destination_register'],r['source_register'],r['signed_offset'],r['signed_immediate'])==(op,dst,src,off,imm)
 def select(value):
  pc=196096;path=[];opaque=None;scalar=None
  while True:
   r=by[pc];path.append(pc);op=r['opcode'];imm=r['signed_immediate'];off=r['signed_offset']
   if op in(101,213,21,85):
    assert r['destination_register']==2 and r['source_register']==0
    taken={101:value>imm,213:value<=imm,21:value==imm,85:value!=imm}[op]
    pc=pc+8+off*8 if taken else pc+8
   elif op==5:pc=pc+8+off*8
   elif op==24:
    assert r['kind']=='lddw_instruction_payload_opaque'and r['destination_register']==2
    assert opaque is None;opaque=pc;pc+=16
   elif op==183:
    assert r['destination_register']==3 and r['source_register']==0;scalar=imm;pc+=8
   elif op==141:
    assert(pc,imm)==(196872,4)and opaque is not None and scalar is not None
    return{'opaque_lddw_pc':opaque,'argument_r3_scalar':scalar,'branch_instruction_path':path}
   else:raise AssertionError(('unexpected path instruction',pc,op))
 cells=[]
 for lo in range(20):
  hi=lo+1 if lo<19 else 1<<32
  a,b=select(lo),select(hi-1);assert a==b
  if hi-lo>1:assert all(r['signed_immediate']<lo for r in rows if r['opcode']in(101,213,21,85))
  cells.append({'selector_u32_half_open':[lo,hi],**a})
 assert len({r['opaque_lddw_pc']for r in cells})==20
 union={x for c in cells for x in c['branch_instruction_path']}|{x[0]for x in prefix}|{196880}
 assert union==set(by),'all84 instruction records covered by the complete u32 partition'
 normal=bytearray(raw)
 for r in rows:
  if r.get('saved_relocation_metadata',{}).get('type')==8:
   i=r['offset'];normal[i+4:i+8]=bytes(4);normal[i+12:i+16]=bytes(4)
 normalized=H(normal)
 matches=[{'id':c['id'],'start':c['start'],'end':c['end'],'names':c['names'],'raw_sha256':c['raw_sha256']}for c in inventory['candidate_rows']if c['end']-c['start']==len(raw)and isinstance(c['body_analysis'],dict)and c['body_analysis']['normalized_sha256']==normalized]
 pairs=[]
 for r in inventory['original_rows']:
  if r['id']not in['O0071','O0077','O0079','O0081','O0082','O0083','O0084']:continue
  b=r['body_analysis'];a=[x['pc']for x in b['direct']if x['target']==190160];z=[x['pc']for x in b['direct']if x['target']==196056];assert len(a)==len(z)==2
  for left,right in zip(a,z):
   others=[{'kind':kind,'pc':x['pc']}for kind in['direct','indirect','external']for x in b[kind]if left<x['pc']<right]
   pairs.append({'caller_id':r['id'],'O0096_call_pc':left,'O0097_call_pc':right,'lexical_delta':right-left,'recorded_branches_between':[x['pc']for x in b['branches']if left<x['pc']<right],'recorded_exits_between':[x['pc']for x in b['exits']if left<x['pc']<right],'other_recorded_calls_between':others,'register_or_value_dependency_proved':False})
 return{'selector-partitions.json':cells,'candidate-normalized-comparison.json':{'original_bytes':832,'normalized_sha256':normalized,'candidate_rows_compared':len(inventory['candidate_rows']),'exact_full_size_normalized_matches':matches,'data_or_ABI_equality_claimed':False},'O0096-O0097-caller-order.metadata-only.json':pairs}
