"""Pure O0097 retained-code/metadata verification only."""
from pathlib import Path
import argparse,gzip,hashlib,json,runpy,struct
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda n:json.loads((P/n).read_text())
def verify(seal):
 assert H((P/'manifest.json').read_bytes())==seal
 m=J('manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and str(f.relative_to(P))not in('manifest.json','manifest.sha256')}
 for n,r in m.items():assert not(P/n).is_symlink()and(P/n).stat().st_size==r['bytes']and H((P/n).read_bytes())==r['sha256']
 c=P/'collection';assert H((c/'manifest.json').read_bytes())=='6ae3f115dc6191191fe353ffa9efaf7375a861970d5d71cce85ebcabb30aff86'
 cm=json.loads((c/'manifest.json').read_text())['files']
 for n,r in cm.items():assert(c/n).stat().st_size==r['bytes']and H((c/n).read_bytes())==r['sha256']
 result=J('collection/result.json');assert result['returncode']==0 and result['window_id']=='O0097'and result['new_original_data_bytes_read']==result['new_candidate_decodes']==result['new_builds']==result['new_target_executions']==0
 assert J('collection/current-before.json')==J('collection/current-after.json')
 raw=(c/'code-window.bin').read_bytes();w=J('collection/complete-code-instructions.json');assert len(raw)==w['bytes']==832 and H(raw)==w['raw_sha256']=='e037265f2e8e453cd13692bb9ad0484398ec89551656f01f4b4926260e6cdeb4'
 at=w['start'];parts=[];starts={r['pc']for r in w['instructions']}
 for r in w['instructions']:
  b=bytes.fromhex(r['raw_hex']);op,regs,off=struct.unpack_from('<BBh',b)
  assert r['pc']==at and(op,regs&15,regs>>4,off)==(r['opcode'],r['destination_register'],r['source_register'],r['signed_offset'])
  assert op&7 not in(2,3)and all(v not in(5,6,7,8,9,10)for v in[regs&15,regs>>4])
  if op==0x18:assert len(b)==16 and r['signed_immediate']=='OPAQUE_LDDW_HALVES_NOT_COMBINED'and b[8:12]==bytes(4)
  else:assert len(b)==8 and struct.unpack_from('<i',b,4)[0]==r['signed_immediate']
  if r['kind']=='branch_target_arithmetic_only':assert r['target']==at+8+off*8 and r['target']in starts
  parts.append(b);at+=len(b)
 assert b''.join(parts)==raw and at==w['end']==196888
 assert sum(r['opcode']==0x18 for r in w['instructions'])==20 and sum(r['kind']=='branch_target_arithmetic_only'for r in w['instructions'])==38
 assert sum(r['opcode']==0x8d for r in w['instructions'])==sum(r['opcode']==0x95 for r in w['instructions'])==1 and all(r['opcode']!=0x85 for r in w['instructions'])
 assert H((P/'016e.residual.manifest.json').read_bytes())=='016ee97909ac235760ce2063b466c3491b3d7994ebf0b45b85091c4ce8bf2567'
 original_manifest=J('016e.residual.manifest.json')['files'];assert H((P/'complete-inventory.json.gz').read_bytes())==original_manifest['retained/complete-inventory.json.gz']['sha256']
 inv=json.loads(gzip.decompress((P/'complete-inventory.json.gz').read_bytes()));assert len(inv['original_rows'])==441 and len(inv['candidate_rows'])==408
 computed=runpy.run_path(str(P/'derive.py'))['derive'](w,raw,inv)
 for n,value in computed.items():assert J(n)==value
 assert computed['candidate-normalized-comparison.json']['exact_full_size_normalized_matches']==[]
 facts=J('facts.json');assert facts['active_ledger_still']==[184,177,257]and facts['ledger_updated']is facts['O0096_is_a_direct_callee']is facts['r2_r3_pointer_length_or_string_ABI_proved']is False
 return{'passed':True,'exact_O0097_bytes':832,'instruction_records':84,'covered_slots':104,'opaque_lddw':20,'branches':38,'selector_cells':20,'direct_callees_or_local_memory_writes':0,'normalized_candidate_matches':0,'new_data_candidate_source_build_VM':0,'ledger_changed':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--expected-seal',required=True);a=p.parse_args();print(json.dumps(verify(a.expected_seal),indent=2))
