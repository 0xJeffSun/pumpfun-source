# O0097 complete bounded review — unintegrated

The root-admitted832B window is a selector-table indirect callback forwarder. It has84 instruction records/104 eight-byte slots,20 opaque LDDWs,38 branches,one indirect call andone exit. It has **no direct call to O0096 or any other direct callee**, and no local memory store, stack access, Rc adjustment or heap operation. A formatting/Display-like role is a hypothesis; strings, length ABI, enum/source identity and callback ownership remain unproved.

Root collection6ae3f115dc6191191fe353ffa9efaf7375a861970d5d71cce85ebcabb30aff86 fixes original[196056,196888),832B, SHAe037265f2e8e453cd13692bb9ad0484398ec89551656f01f4b4926260e6cdeb4. Exact grant/current-before/current-after/raw code/decoded metadata/result are retained. Actual collection exit0 and source14 before/after equality are authenticated. This review reads only that admitted saved code plus sealed016ee/bbb5 metadata; it opens no original/candidate ELF or active source and runs no collector/build/VM. O0096 was separately root-admitted later, but its body is not read in this packet. The stopped initializer stays excluded.

## Local ABI and ownership boundary

Entry r1 is copied to r3 at196056. The body reads a qword from entry r2+0 into r1, reads another qword from entry r2+8 into r2, then reads callback r4 from that second qword+24 at196080. It loads a32-bit selector from saved entry r1+0 into r2 at196088. These memory reads are conceptual instruction effects; their objects/pointers/types are not dereferenced by this analysis.

Every path then places one opaque LDDW payload into r2 and a small scalar into r3, and reaches CALLX r4 at196872. r1 remains the initial qword read from entry r2+0. r4 remains the callback target and r5 remains its incoming value; no additional argument count is assumed. R6–R9 and frame pointer are untouched. The sole exit196880 returns the callback's r0 without a local conversion or success/error interpretation.

There is no local output buffer construction or mutation. This does **not** make the whole routine pure or ownership-free: the unknown indirect callback may write, allocate, borrow, release, fail or diverge. No borrowed-string, owned-String, formatter-vtable, error-origin or lifetime contract is asserted from register positions alone. No pointer/scalar pair is treated as a length-qualified data extent. All20 LDDW halves remain opaque and uncombined, including type8 relocation payloads.

## Complete selector and branch coverage

Opcode0x61 zero-extends the selector load into the64-bit register, so the local domain is the full u32 range. The comparisons are signed64 greater/less-equal and equality/inequality against small nonnegative immediates. `selector-partitions.json` proves singleton cells0..18 and the final interval[19,2^32), preserving every branch PC and chosen pair. It checks all84 instruction-record PCs are covered by this complete local partition. This is a saved-instruction constant/control derivation, not a VM, runtime input fixture or proof that any particular selector reaches this routine from a handler.

| Selector class | Opaque LDDW PC | r3 scalar at callback |
|---|---:|---:|
|0|196344|17|
|1|196752|17|
|2|196496|13|
|3|196136|23|
|4|196624|17|
|5|196424|21|
|6|196816|31|
|7|196560|32|
|8|196256|20|
|9|196688|30|
|10|196384|25|
|11|196784|35|
|12|196528|56|
|13|196200|61|
|14|196656|19|
|15|196464|16|
|16|196848|26|
|17|196592|31|
|18|196304|21|
|19 through4294967295|196720|20|

The last path is a default for every u32≥19, not proof of a valid twenty-variant Rust enum. Selectors8 and≥19 share the scalar20 store but use different opaque payloads. No branch exits the exact window; targets align with instruction starts rather than LDDW continuations. The callback is not followed.

## Candidate comparison and O0096 relationship

Masking only the known type8 LDDW immediate fields without interpreting them gives normalized hash3040d366894a55c601386072be10f5d0747151ea79fa490799f1eeb68d48e0ff. Complete size+normalized comparison against all408 retained candidate rows finds no exact match. Candidate names do not supply original identity or ABI. No fresh candidate byte/body read or semantic classification upgrade occurs.

Saved metadata pairs each handler's two O0096 calls with its two O0097 calls:14 pairs across O0071/O0077/O0079/O0081/O0082/O0083/O0084, lexical deltas128 or136 bytes. There are no recorded intervening branches/exits/direct/indirect/external calls in those spans. This supports a concrete nearby predecessor relationship on ordinary fall-through after a returning O0096 call, but does not prove register/value dependency, domination, selector preservation or a name/message construction sequence. The caller register-setup bytes are not re-read here.

Accordingly O0096 is **not a callee prerequisite of O0097**. Its separate14 saved direct consumer calls provide an independent reason to inspect it, as root's later grant explicitly states. Reading O0096 may establish what that nearby peer returns; it does not by itself close O0097's unknown indirect callback or authorize any LDDW/string extent. The next O0096 review must stay within its independently admitted5896B and retain these distinctions.

## Proof and disposition

The pure verifier authenticates collection/manifest/raw hash, checks every non-LDDW tuple and all LDDW headers/coverage without decoding their payloads, recomputes the complete selector partition/candidate negatives/caller ordering from saved metadata and checks no local stores or direct calls exist. True debug function extent, source identity, strings, callback slice ABI, transitive effects and runtime behavior remain unproved. No source correction is justified here.

The active ledger remains184 admitted/177 normalized/257 opaque, including the stopped exclusion and all negatives/ambiguities. This is a staged unintegrated review; it does not edit the ledger or claim whole-binary identity. There is no new data, callee, candidate body, active source, signature/PDA/history, compiler or runtime operation.
