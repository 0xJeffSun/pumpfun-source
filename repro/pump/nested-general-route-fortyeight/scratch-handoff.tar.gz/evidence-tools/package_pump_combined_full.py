"""Package only selected source, public fixtures and saved evidence; no generated keys."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile,difflib
R=Path.cwd();W=R/'work/pump-nested-general-route-recovery/run-01';P=W/'handoff'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,b):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def cp(s,n):
 assert not s.name.endswith('-keypair.json');put(n,s.read_bytes())
def obj(n,v):put(n,(json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
def archive(n,rows,base=R):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w')as t:
  for path,digest in sorted(rows.items()):
   assert not Path(path).is_absolute()and '..'not in Path(path).parts and not Path(path).name.endswith('-keypair.json')
   data=(base/path).read_bytes();assert sha(data)==digest,path
   i=tarfile.TarInfo(path);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
 put(n,gzip.compress(b.getvalue(),mtime=0))
assert not P.exists();P.mkdir()
v=json.loads((W/'independent-verification.json').read_text());assert v['differential_case_count']==9237 and v['surfpool_comparisons']==1024 and not v['mismatches']
shutil.copytree(W/'focused-handoff',P/'focused-handoff')
for n in ['inputs-before.json','baseline.json','nested-execution-harness-manifest.json','nested-execution-source-map.patch','independent-verification.json','receipt-build-bindings.json','surfpool-executable-sha256.json','historical-two-curve-witness.json','focused-handoff-verification.json','receipt-verification.json','surfpool-port-reservation.json','surfpool-port-release.json']:
 cp(W/n,n)
for n in ['run_regressions.py','run_surfpool.py','verify_receipts.py','verify_receipts.portability.patch','run_regressions.py.source-binding.patch','run_surfpool.py.source-binding.patch']:
 cp(W/n,'evidence-tools/'+n)
cp(Path(__file__),'evidence-tools/package_pump_combined_full.py')
for directory in ['nested-execution-harness','two-curve-harness']:
 shutil.copytree(W/directory,P/directory)
for n in ['nested-original-acceptance','nested-differential']:
 for suffix in ['.json.gz','.log','.json.gz.partial.json.gz']:cp(W/(n+suffix),n+suffix)
 shutil.copytree(W/(n+'.json.gz.case-journal'),P/(n+'.json.gz.case-journal'))
cp(R/'work/pump-nested-correction-build/prebuild/depth-guard-review/saved-identities.json','historical-nested-identities.json')
cp(R/'evidence/upstream/pump.json','pump-idl.json')
old=(R/'work/pump-nested-correction-build/verify_nested_portable.py').read_text()
new=old.replace("H/'execution-harness'","H/'nested-execution-harness'").replace("H/'prebuild/depth-guard-review/saved-identities.json'","H/'historical-nested-identities.json'").replace("H/'evidence/upstream/pump.json'","H/'pump-idl.json'").replace('original-acceptance-01','nested-original-acceptance').replace('focused-01','nested-differential')
put('verify_nested_portable.py',new.encode())
put('evidence-tools/verify_nested_portability.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='accepted-nested/verify_nested_portable.py',tofile='verify_nested_portable.py')).encode())
for n in ['regression-invocation.log','surfpool-invocation.log']:cp(W/n,'logs/'+n)
for d in ['differential','surfpool']:
 cp(W/d/'run.json',d+'-run.json')
 for f in (W/d).glob('*.log'):put('logs/'+d+'/'+f.name+'.gz',gzip.compress(f.read_bytes(),mtime=0))
cp(W/'differential/summary.json','differential-summary.json')
inputs=json.loads((W/'inputs-before.json').read_text())
archive('harness-snapshot.tar.gz',inputs['harness_sha256']);archive('fixture-snapshot.tar.gz',inputs['repository_fixture_snapshot_sha256']);archive('baseline-source-snapshot.tar.gz',inputs['baseline_main_source'])
# Bind the exact nested execution imports/fixtures in addition to the older 96-file corpus closure.
nested=json.loads(gzip.decompress((W/'nested-differential.json.gz').read_bytes()))
repo_inputs=nested['provenance']['repository_inputs'];archive('nested-repository-inputs.tar.gz',repo_inputs)
obj('nested-repository-inputs.json',repo_inputs)
bindings=json.loads((W/'receipt-build-bindings.json').read_text());mapping={}
for i,b in enumerate(bindings):
 p=R/b['receipt'];data=p.read_bytes();assert sha(data)==b['receipt_sha256'];name=f'receipts/{i:02d}-{b["kind"]}-{p.name}'
 if data.startswith(b'\x1f\x8b'):payload=data;transport='original-bytes'
 else:payload=gzip.compress(data,mtime=0);transport='gzip-original-bytes';name+='.gz'
 put(name,payload);mapping[b['receipt']]={'path':name,'source_sha256':sha(data),'packaged_sha256':sha(payload),'transport':transport}
obj('receipt-copy-map.json',mapping)
cp(R/'work/pump-tokenkeg-two-curve-recovery/original-only-01.json.gz','historical-two-curve-original.json.gz')
accept=json.loads(gzip.decompress((W/'nested-original-acceptance.json.gz').read_bytes()));assert nested['provenance']['runtime_files']==accept['provenance']['runtime_files']
runtime=nested['provenance']['runtime_files']
for path,h in runtime.items():assert sha(Path(path).read_bytes())==h,path
obj('runtime-identities.json',{'python_solders_actual_loaded_files':runtime,'surfpool':{'path':inputs['surfpool_path'],'sha256':inputs['surfpool_sha256'],'bytes':(R/inputs['surfpool_path']).stat().st_size},'role':'Historical execution identities. Portable saved verification neither loads programs nor requires these Darwin executables.'})
obj('summary.json',{'candidate_sha256':v['candidate_sha256'],'original_sha256':v['original_sha256'],'source_inputs':37,'fully_bounded_handlers':48,'partial_instruction_paths':5,'handler_count_change':0,'existing_differential_cases':9237,'accepted_nested_cases':16,'new_general_route_cases':16,'combined_differential_cases':9269,'surfpool_comparisons':1024,'existing_differential_transactions':sum(x['verified']['transactions']for x in v['differential_suites']),'existing_differential_signatures':sum(x['verified']['signatures']for x in v['differential_suites']),'surfpool_transactions':2048,'surfpool_signatures':v['surfpool_verified_signatures'],'nested_paired_transactions':32,'nested_paired_signatures':64,'repeated_nested_original_acceptance_transactions':16,'repeated_nested_original_acceptance_signatures':32,'general_route_paired_transactions':32,'general_route_paired_signatures':32,'prior_unequal_candidate_receipts_reused':False,'full_original_byte_equality':False,'audit_complete':False,'main_modified':False})
print(json.dumps({'prepared':str(P.relative_to(R)),'receipt_bindings':len(bindings),'candidate':v['candidate_sha256']}))
