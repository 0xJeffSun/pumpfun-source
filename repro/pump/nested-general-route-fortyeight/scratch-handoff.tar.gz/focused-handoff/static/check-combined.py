#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,struct,sys
sys.dont_write_bytecode=True
from elf_reader import Elf
P=Path(__file__).resolve().parent;R=next(p for p in P.parents if(p/'evidence/original/pump/deployed.so').is_file());sha=lambda b:hashlib.sha256(b).hexdigest()
o=Elf(R/'evidence/original/pump/deployed.so');c=Elf(P/'candidate.so');s=Elf(P/'unstripped.so');b=Elf(P/'baseline-nested.so');bs=Elf(P/'baseline-nested-symbols.so');prior=json.loads((P/'baseline-depth-guard-match.json').read_text())
assert sha(b.b)==prior['candidate_sha256']=='568546bcf038740d995325c1e742528f218f630840ac152f96dcf5c2147eabc2'
assert b.b[b.lo:b.hi]==bs.b[bs.lo:bs.hi]and c.b[c.lo:c.hi]==s.b[s.lo:s.hi]
by={x['start']:x for x in s.funcs};oldby={x['start']:x for x in bs.funcs};walk=next(x for x in s.funcs if 'nested_create4walk17'in x['name']);old=prior['candidate_walk'];assert walk['size']==old['size']==11432
start=walk['start'];a=old['start'];n=walk['size'];eq=c.normalized[start:start+n]==b.normalized[a:a+n]and c.pattern(start,n)==b.pattern(a,n);assert eq,'Unchanged nested walk body differs; stop for review'
calls=[]
for current,previous in zip(c.callsites(start,n),b.callsites(a,n)):
 assert current['offset']==previous['offset'];f=by[current['target']];g=oldby[previous['target']];same=f['size']==g['size']and c.normalized[f['start']:f['start']+f['size']]==b.normalized[g['start']:g['start']+g['size']]and c.pattern(f['start'],f['size'])==b.pattern(g['start'],g['size'])
 calls.append(dict(offset=current['offset'],candidate_target=current['target'],baseline_target=previous['target'],candidate_symbol=f,baseline_symbol=g,complete_target_normalized_equal=same));assert same,(current,previous)
assert len(calls)==len(c.callsites(start,n))==len(b.callsites(a,n))
facts=[]
for fact in prior['instruction_facts']:
 off=fact['address']-a;at=start+off;assert list(struct.unpack_from('<BBhi',c.b,at))==fact['decoded'];facts.append(dict(offset=off,address=at,decoded=fact['decoded'],bytes_hex=c.b[at:at+8].hex()))
data=[]
for row in prior['consumed_data']:
 off=row['instruction']-a;at=start+off;ptr=struct.unpack_from('<I',c.b,at+4)[0]|struct.unpack_from('<I',c.b,at+12)[0]<<32;actual=c.b[ptr:ptr+row['bytes']].hex();assert actual==row['hex'];data.append(dict(offset=off,instruction=at,pointer=ptr,bytes=row['bytes'],hex=actual,label=row['label']))
selected=[]
for name,row in prior['actual_error_targets'].items():
 off=row['site']-a;now=next(x for x in calls if x['offset']==off);f=now['candidate_symbol']
 for ot in row['complete_original_body_matches']:
  end=o.entries[o.entries.index(ot)+1];assert end-ot==f['size']and o.normalized[ot:end]==c.normalized[f['start']:f['start']+f['size']]and o.pattern(ot,end-ot)==c.pattern(f['start'],f['size'])
 selected.append(dict(name=name,offset=off,candidate_target=f['start'],original_complete_matches=row['complete_original_body_matches']))
# Complete identity-admitted original hop parser and all immediate callee bodies.
hop=next(x for x in s.funcs if '..CurveHop$u20$as$u20$anchor_lang..Accounts$LT$'in x['name']and 'try_accounts'in x['name']);a=0xdd700;n=3512;start=hop['start'];assert hop['size']==n
normalized=[i for i in range(0,n,8)if o.normalized[a+i:a+i+8]!=c.normalized[start+i:start+i+8]];assert normalized==[2544,2552,2560],normalized
hop_calls=[]
for call in c.callsites(start,n):
 ot=o.calls[a+call['offset']];f=by[call['target']];end=o.entries[o.entries.index(ot)+1];assert end-ot==f['size']and o.normalized[ot:end]==c.normalized[f['start']:f['start']+f['size']]and o.pattern(ot,end-ot)==c.pattern(f['start'],f['size']);hop_calls.append(dict(**call,original_target=ot,candidate_function=f,complete_original_target_matches=True))
assert len(hop_calls)==33
labels=[]
for off,label in [(1344,'associated_base_bonding_curve'),(2976,'associated_quote_bonding_curve'),(3248,'associated_base_bonding_curve'),(3392,'associated_quote_bonding_curve')]:
 row=dict(offset=off,label=label)
 for key,e,st in [('original',o,a),('candidate',c,start)]:
  at=st+off;ptr=struct.unpack_from('<I',e.b,at+4)[0]|struct.unpack_from('<I',e.b,at+12)[0]<<32;length=struct.unpack_from('<i',e.b,at+20)[0];assert length==len(label)and e.b[ptr:ptr+length]==label.encode();row[key]=dict(instruction=at,pointer=ptr,length=length,hex=e.b[ptr:ptr+length].hex())
 labels.append(row)
report=dict(scope='Complete unchanged nested walk vs accepted568546 and its immediate target bodies, translated original guard/diagnostic facts and consumed data; complete original hop parser/callees/actual account names. No full nested walk/original or handler/whole-ELF equality claim.',candidate=c.identity(),symbols=s.identity(),original=o.identity(),baseline_nested=b.identity(),nested_walk={**walk,'raw_sha256':sha(c.b[walk['start']:walk['start']+walk['size']]),'baseline_complete_normalized_equal':eq},nested_direct_calls=calls,nested_instruction_facts=facts,nested_consumed_data=data,nested_actual_error_targets=selected,hop_parser=hop,hop_normalized_differences=[dict(offset=i,original_hex=o.b[a+i:a+i+8].hex(),candidate_hex=c.b[start+i:start+i+8].hex())for i in normalized],hop_direct_calls=hop_calls,hop_label_consumed_data=labels,original_whole_equal=o.b==c.b)
if '--check'in sys.argv:assert report==json.loads((P/'combined-static.json').read_text())
else:(P/'combined-static.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'candidate_sha256':sha(c.b),'nested_walk_bytes':walk['size'],'nested_whole_normalized_equal_baseline':eq,'nested_matched_direct_targets':len(calls),'nested_guard_error_targets':len(selected),'hop_parser_bytes':n,'hop_matched_direct_targets':len(hop_calls),'hop_label_sites_match':len(labels),'remaining_hop_normalized_offsets':normalized,'original_whole_equal':o.b==c.b}))
