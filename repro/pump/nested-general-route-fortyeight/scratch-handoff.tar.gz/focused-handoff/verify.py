#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,tarfile,subprocess,sys,base64,re
P=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda n:json.loads((P/n).read_text());p=argparse.ArgumentParser();p.add_argument('--signatures',action='store_true');a=p.parse_args();m=J('manifest-sha256.json');actual={str(q.relative_to(P))for q in P.rglob('*')if q.is_file()and q.name!='manifest-sha256.json'};assert actual==set(m)
for n,d in m.items():assert H(P/n)==d['sha256']and(P/n).stat().st_size==d['bytes'],n
ex=J('execution.json');source=J('build/source-sha256.json');build=J('build/build-comparison.json');attempt=J('build/build-attempt.json');phases=J('build/toolchain-phases.json');assert len(source)==37 and attempt['returncode']==0 and attempt['source_unchanged']
assert attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256'] and {p.removeprefix('work/pump-nested-general-route-recovery/run-01/source/'):h for p,h in build['source_sha256'].items()}==source
with tarfile.open(P/'build/proposed-source-snapshot.tar.gz')as t:assert {x.name:hashlib.sha256(t.extractfile(x).read()).hexdigest()for x in t if x.isfile()}==source
assert H(P/'static/candidate.so')==ex['candidate_sha256']==build['comparison']['candidate_sha256']==phases['candidate']['sha256']=='731003570927c206353555d9743d70229234e7e3fa167a5915fa146f3007fc93'
assert H(P/'static/unstripped.so')==ex['symbols_sha256'] and phases['compile']['before']==phases['compile']['after'] and J('build/dependency-before.json')==J('build/dependency-after.json')
for name,key in [('preflight','preflight_seal'),('focused-layer','focused_layer_seal')]:
 with tarfile.open(P/(name+'.tar.gz'))as t:
  raw=t.extractfile(name+'/manifest-sha256.json').read();assert hashlib.sha256(raw).hexdigest()==ex[key];inner=json.loads(raw)
  for n,d in inner.items():assert hashlib.sha256(t.extractfile(name+'/'+n).read()).hexdigest()==d['sha256']
for script in ['match-serializer.py','analyze-route.py','check-combined.py']:
 r=subprocess.run([sys.executable,'-B',str(P/'static'/script),'--check'],capture_output=True,text=True);assert r.returncode==0,(script,r.stderr)
O=J('focused-original/summary.json');C=J('focused-candidate/summary.json');assert O['all_pass']and C['all_pass']and O['case_count']==C['case_count']==16
assert C['candidate_sha256']==ex['candidate_sha256']and C['accepted_original_summary_sha256']==H(P/'focused-original/summary.json')
ob=J('focused-original/bindings-before.json');cb=J('focused-candidate/bindings-before.json');assert {k:v for k,v in cb.items()if k!='candidate'}==ob and cb['candidate']['source_sha256']==build['source_sha256']
for side,s in [('original',O),('candidate',C)]:
 assert(P/('focused-'+side+'/bindings-before.json')).read_bytes()==(P/('focused-'+side+'/bindings-after.json')).read_bytes()
 for n,h in s['receipt_sha256'].items():assert H(P/('focused-'+side)/n)==h
for r in C['rows']:
 n=r['file'];o=J('focused-original/'+n);c=J('focused-candidate/'+n);assert c['case']==o['case']and c['all_assertions_pass']and o['all_assertions_pass']and not r['mismatches']
 for k in ['error','normalized_logs','events','inner','return_data','before','after','pump_calls','token_calls']:assert c[k]==o[k],(n,k)
 for side,row in [('original',o),('candidate',c)]:
  tx=J('focused-'+side+'/'+n[:-5]+'.transaction.json');raw=J('focused-'+side+'/'+n[:-5]+'.raw-result.json');b=base64.b64decode(row['transaction_base64'])
  assert row['transaction_base64']==tx['transaction_base64']and row['before']==tx['before']and row['after']==raw['after']and row['raw_metadata']==raw['raw_metadata']
  assert hashlib.sha256(b).hexdigest()==row['transaction_sha256']and len(b)==1128 and row['verified_signature_count']==1
  assert row['normalized_logs']==[re.sub(r' consumed [0-9]+ of [0-9]+ compute units',' consumed <CU> of <CU> compute units',x)for x in row['logs']]
  if a.signatures:
   from solders.transaction import Transaction
   t=Transaction.from_bytes(b);assert len(t.signatures)==1 and all(t.verify_with_results())and len(t.message.instructions)==2
   x,y=t.message.instructions;assert str(t.message.account_keys[x.program_id_index])=='ComputeBudget111111111111111111111111111111'and bytes(x.data).hex()=='02c0270900'and len(x.accounts)==0
   assert str(t.message.account_keys[y.program_id_index])=='pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA'
print(json.dumps({'pass':True,'payloads':len(m),'source_inputs':37,'paired_comparisons':16,'successful_transactions':32,'signatures':32,'saved_signatures_rechecked':a.signatures,'candidate_sha256':ex['candidate_sha256']}))
