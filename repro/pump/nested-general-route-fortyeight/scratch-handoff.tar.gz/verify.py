#!/usr/bin/env python3
"""Verify saved evidence only: no program execution, transaction creation, or network."""
from pathlib import Path,PurePosixPath
import argparse,base64,gzip,hashlib,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
from solders.transaction import VersionedTransaction
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):
 p=PurePosixPath(n);assert not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json')
 f=P/p;assert not f.is_symlink();return f.read_bytes()
def obj(n):
 b=raw(n);return json.loads(gzip.decompress(b)if b.startswith(b'\x1f\x8b')else b)
def tar_map(n):
 rows={}
 with tarfile.open(P/n)as t:
  for m in t:
   p=PurePosixPath(m.name);assert m.isfile()and not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json')and m.name not in rows
   rows[m.name]=sha(t.extractfile(m).read())
 return rows
def transactions(v):
 if isinstance(v,dict):
  if isinstance(v.get('transaction_base64'),str):yield v['transaction_base64']
  for k,x in v.items():
   if k!='transaction_base64':yield from transactions(x)
 elif isinstance(v,list):
  for x in v:yield from transactions(x)
def signatures(v):
 count=sigs=0
 for enc in transactions(v):
  b=base64.b64decode(enc);tx=VersionedTransaction.from_bytes(b);assert bytes(tx)==b and all(tx.verify_with_results());count+=1;sigs+=len(tx.signatures)
 return {'transactions':count,'signatures':sigs}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path);ap.add_argument('--source-root',type=Path);a=ap.parse_args()
 manifest=obj('manifest-sha256.json');actual=set()
 for f in P.rglob('*'):
  assert not f.is_symlink()
  if f.is_file()and f!=P/'manifest-sha256.json':actual.add(f.relative_to(P).as_posix())
 assert actual==set(manifest),(actual-set(manifest),set(manifest)-actual)
 for n,v in manifest.items():b=raw(n);assert v=={'sha256':sha(b),'bytes':len(b)},n
 assert sha(raw('focused-handoff/manifest-sha256.json'))=='8a9f7e140a7f359b06c7dc9ccbe39da59bf203239506dd9e4ae32de6bc1505df'
 proc=subprocess.run([sys.executable,'-B',str(P/'focused-handoff/verify.py'),'--signatures'],cwd='/',capture_output=True,text=True)
 assert proc.returncode==0,(proc.stdout,proc.stderr);focused=json.loads(proc.stdout)
 source=obj('focused-handoff/build/source-sha256.json');assert len(source)==37
 build=obj('focused-handoff/build/build-comparison.json');attempt=obj('focused-handoff/build/build-attempt.json');actualsource=build['source_sha256']
 assert actualsource==attempt['source_sha256']==attempt['source_after_sha256']and attempt['source_unchanged']and attempt['returncode']==0
 assert {k[k.index('programs/pump/'):]:h for k,h in actualsource.items()}==source
 assert sha(raw('focused-handoff/build/build.log'))==build['build_log_sha256']
 candidate=sha(raw('focused-handoff/static/candidate.so'));original=sha(raw('focused-handoff/evidence/original/pump/deployed.so'))
 assert candidate==build['comparison']['candidate_sha256']=='731003570927c206353555d9743d70229234e7e3fa167a5915fa146f3007fc93'
 assert original==build['comparison']['original_sha256']and not build['comparison']['full_byte_equality']
 phases=obj('focused-handoff/build/toolchain-phases.json');assert phases['compile']['selected_version']=='v1.44'and phases['strip']['actual_distribution']=='v1.52'
 assert phases['compile']['before']==phases['compile']['after']
 inputs=obj('inputs-before.json');assert tar_map('harness-snapshot.tar.gz')==inputs['harness_sha256']
 assert tar_map('fixture-snapshot.tar.gz')==inputs['repository_fixture_snapshot_sha256']
 assert tar_map('baseline-source-snapshot.tar.gz')==inputs['baseline_main_source']
 assert actualsource==inputs['compiler_source_sha256']
 assert set(source)==set(inputs['baseline_main_source'])
 assert [n for n in source if source[n]!=inputs['baseline_main_source'][n]]==['programs/pump/src/multi_hop_curve.rs']
 assert source['programs/pump/src/multi_hop_curve.rs']=='f8091a092a7974c1f33e53ff65113e48c628435ffaa266c5de5a12bc0447a92d'
 for n,h in inputs['orchestration_sha256'].items():assert sha(raw('evidence-tools/'+Path(n).name))==h
 em=obj('nested-execution-harness-manifest.json')
 for n,h in em.items():assert sha(raw('nested-execution-harness/'+n))==h
 assert obj('nested-execution-harness/expected-source-map.json')==source
 nested=obj('nested-differential.json.gz');accept=obj('nested-original-acceptance.json.gz')
 assert tar_map('nested-repository-inputs.tar.gz')==obj('nested-repository-inputs.json')==nested['provenance']['repository_inputs']==accept['provenance']['repository_inputs']
 assert nested['candidate_sha256']==candidate
 nb=nested['provenance']['compiled_candidate_binding'];assert nb['actual_source_sha256']==actualsource
 assert nb['report_sha256']==sha(raw('focused-handoff/build/build-comparison.json'))and nb['attempt_sha256']==sha(raw('focused-handoff/build/build-attempt.json'))
 assert nested['provenance']['runtime_files']==accept['provenance']['runtime_files']==obj('runtime-identities.json')['python_solders_actual_loaded_files']
 v=obj('independent-verification.json');assert v['candidate_sha256']==candidate and v['original_sha256']==original and not v['mismatches']
 assert len(v['differential_suites'])==38 and sum(x['case_count']for x in v['differential_suites'])==9237
 assert len(v['surfpool_suites'])==28 and sum(x['cases']for x in v['surfpool_suites'])==1024
 mapping=obj('receipt-copy-map.json');bindings=obj('receipt-build-bindings.json');assert len(bindings)==len(mapping)==66
 expected={x['receipt_sha256']:x for x in v['differential_suites']+v['surfpool_suites']};assert len(expected)==66
 totals={k:{'transactions':0,'signatures':0}for k in ['differential','surfpool']};receipts={}
 for b in bindings:
  m=mapping[b['receipt']];payload=raw(m['path']);assert sha(payload)==m['packaged_sha256']
  assert m['transport']in ['gzip-original-bytes','original-bytes']
  data_bytes=gzip.decompress(payload)if m['transport']=='gzip-original-bytes'else payload
  assert sha(data_bytes)==m['source_sha256']==b['receipt_sha256']
  data=json.loads(gzip.decompress(data_bytes)if data_bytes.startswith(b'\x1f\x8b')else data_bytes)
  assert b['actual_compiler_inputs_sha256']==actualsource and b['build_report_sha256']==sha(raw('focused-handoff/build/build-comparison.json'))
  assert b['executed_candidate_sha256']==candidate and b['executed_original_sha256']==original
  assert not data.get('mismatches',[])and not data.get('failures',[])
  assert not data.get('unexpected_original_errors',[])and not data.get('unexpected_errors',[])
  if isinstance(data.get('cases'),list):
   for row in data['cases']:
    if isinstance(row,dict):assert not row.get('mismatches',[])and not row.get('failures',[])
  count=signatures({'original':data['original'],'candidate':data['candidate']}if b['kind']=='surfpool'else data)
  assert count==expected[b['receipt_sha256']]['verified']
  for k,z in count.items():totals[b['kind']][k]+=z
  receipts[(b['kind'],expected[b['receipt_sha256']]['suite'])]=data
 assert totals['surfpool']['transactions']==2048
 qc=receipts[('differential','quote_control')]['bound_inputs_sha256']
 for n,h in actualsource.items():assert qc[n]==h
 assert qc['work/pump-nested-general-route-recovery/run-01/build-01/build-comparison.json']==sha(raw('focused-handoff/build/build-comparison.json'))
 partial=receipts[('differential','multi_hop_curve_partial')];assert partial['case_count']==partial['passed']==56
 for row in partial['cases']:
  assert not row['mismatches']
  for k in ['error','events','inner','return_data','before','after']:assert row['original'][k]==row['candidate'][k]
 two=receipts[('differential','tokenkeg_two_curve')];assert two['provenance']['compiled_candidate_binding']['actual_source_sha256']==actualsource
 prior=obj('historical-two-curve-original.json.gz');assert sha(raw('historical-two-curve-original.json.gz'))==obj('historical-two-curve-witness.json')['sha256']
 norm=lambda logs:[x for x in logs if not re.fullmatch(r'Program \S+ consumed \d+ of \d+ compute units',x)]
 for old,row in zip(prior['cases'],two['cases']):
  assert old['case']==row['case']and old['parameters']==row['parameters']and not row['mismatches']
  for k in ['error','events','inner','return_data','before','after','pump_calls','token_calls']:assert old['original'][k]==row['original'][k]==row['candidate'][k]
  assert norm(row['original']['logs'])==norm(row['candidate']['logs'])
 from verify_nested_portable import run as verify_nested
 nv=verify_nested()
 if a.repo:
  for group in ['harness_sha256','repository_fixture_snapshot_sha256','baseline_main_source']:
   for n,h in inputs[group].items():assert sha((a.repo/n).read_bytes())==h,n
 if a.source_root:
  for n,h in source.items():assert sha((a.source_root/n).read_bytes())==h,n
 summary=obj('summary.json');assert summary['combined_differential_cases']==9237+16+16==9269
 assert summary['existing_differential_transactions']==totals['differential']['transactions']and summary['existing_differential_signatures']==totals['differential']['signatures']
 assert summary['surfpool_signatures']==totals['surfpool']['signatures']
 print(json.dumps({'status':'PASS','payloads':len(manifest),'source_inputs':37,'candidate_sha256':candidate,'existing_cases':9237,'accepted_nested_cases':16,'general_route_cases':16,'combined_differential_cases':9269,'surfpool_cases':1024,'existing_receipt_bindings':66,'signature_counts':totals,'nested_saved':nv,'route_focused':focused,'source_rebound':bool(a.source_root),'repository_rebound':bool(a.repo),'new_builds':0,'new_transactions':0},indent=2))
if __name__=='__main__':main()
