"""UNEXECUTED single build only; no target execution or active source writes."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,os,gzip,datetime
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[1]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
p=argparse.ArgumentParser();p.add_argument('--reviewed-control-sha256',required=True);p.add_argument('--launch-build',action='store_true');a=p.parse_args()
assert H(P/'manifest.json')==a.reviewed_control_sha256
m=J(P/'manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and f not in [P/'manifest.sha256',P/'manifest.json']},'complete manifest membership'
for n,h in m.items():assert not(P/n).is_symlink()and H(P/n)==h,n
g=J(P/'inputs.json');assert len(g['source'])==37
for n,h in g['source'].items():assert H(P/'baseline'/n)==h,n
assert H(P/'proof/manifest.json')==g['proof_seal']=='bcb32d74c6d9fc5c438809c72665545238bab7cb1933ecd7cd2bee818080a25e'
for n,h in J(P/'proof/manifest.json').items():assert H(P/'proof'/n)==h,n
assert H(P/'proof/proposal/admin_cto.rs')==g['proposal_sha256']
for n,h in g['helpers'].items():assert H(P/'helpers'/n)==h,n
assert g['helpers']['scripts/build_partial_candidate.py']=='bb683621ffc4297c58f030cb03da54484b7370b786fd8eda965a37f4b3198ee9'
def external():
 t=g['tools'];cli=t['files']['cargo-build-sbf'];selected=shutil.which('cargo-build-sbf');assert selected and Path(selected).resolve()==Path(cli['path']).resolve(),'resolved CLI selection'
 for v in t['files'].values():assert H(Path(v['path']))==v['sha256'],v['path']
 sdk=Path(t['sdk_source']);actual={str(f.relative_to(sdk)):H(f)for f in sdk.rglob('*')if f.is_file()and 'dependencies'not in f.relative_to(sdk).parts and not f.name.endswith('-keypair.json')};assert actual==g['sdk_source'],'SDK template'
 dep=P/'baseline-dependency-provenance.json.gz';assert H(dep)==g['dependency_sha256'];d=json.loads(gzip.decompress(dep.read_bytes()));count=0
 for package in d['packages']:
  for f in package['archives']:
   assert H(R/f['path'])==f['sha256']==package['lock_checksum'];count+=1
  for tree in package['source_trees_observed']:
   for n,h in tree['source_files_sha256'].items():assert H(R/tree['path']/n)==h;count+=1
 assert count==14281 and len(d['packages'])==252
 return {'resolved_cli':str(Path(selected).resolve()),'cli_sha256':H(Path(selected)),'locked_packages':252,'retained_dependency_files':count,'sdk_files':len(actual)}
checks=external()
if not a.launch_build:print(json.dumps({'preflight':'PASS','external':checks,'build':'UNRUN','runtime_authorized':False}));raise SystemExit(0)
W=P.parent/'pump-admin-cto-6030-2006-build';W.mkdir(exist_ok=False)
def record(n,v):
 with(W/n).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def event(v):
 with(W/'events.jsonl').open('a')as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**v})+'\n')
try:
 repo=W/'repo';shutil.copytree(P/'baseline',repo)
 for n in g['helpers']:
  dest=repo/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'helpers'/n,dest)
 shutil.copy2(P/'proof/proposal/admin_cto.rs',repo/'programs/pump/src/admin_cto.rs')
 dest=repo/'evidence/original/pump/deployed.so';dest.parent.mkdir(parents=True);shutil.copy2(P/'proof/original.so',dest)
 source={n:H(repo/n)for n in g['source']};assert[n for n in source if source[n]!=g['source'][n]]==['programs/pump/src/admin_cto.rs']
 record('source-before.json',source);record('preflight.json',{'source37':g['source'],'helpers':g['helpers'],'external':checks,'control_seal':a.reviewed_control_sha256,'build_limit':1,'runtime_authorized':False})
 B=W/'build-01';cmd=[sys.executable,'-B',str(repo/'scripts/build_partial_candidate.py'),'--manifest',str(repo/'programs/pump/Cargo.toml'),'--program','pump','--artifact-name','pump_recovered.so','--tools-version','v1.44','--output',str(B)]
 env={**os.environ,'CARGO_HOME':g['cache'],'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
 record('launch.json',{'command':cmd,'cwd':str(repo),'environment':{n:env[n]for n in ['CARGO_HOME','CARGO_NET_OFFLINE','PYTHONDONTWRITEBYTECODE']},'attempt':1,'strip_version':'v1.52 unchanged recipe'});event({'phase':'build-start'})
 with(W/'build.stdout').open('x')as out,(W/'build.stderr').open('x')as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record('build-exit.json',{'returncode':r.returncode});event({'phase':'build-exit','returncode':r.returncode})
 after={n:H(repo/n)for n in source};record('source-after.json',after);assert after==source
 for n,h in g['helpers'].items():assert H(repo/n)==h,n
 record('external-after.json',external());r.check_returncode()
 attempt=J(B/'build-attempt.json');assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['selected_toolchain']=='v1.44';assert attempt['source_sha256']==source==attempt['source_after_sha256']
 strip=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy';assert H(strip)==g['tools']['files']['stripper']['sha256']and(B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
 for n,h in g['sdk_source'].items():assert H(B/'sdk'/n)==h,n
 log=(B/'build.log').read_text().lower();bad=[x for x in ['stack offset','stack frame','stack size','stack overflow','llvm error','error: function']if x in log];record('stack-backend-gate.json',{'passed':not bad,'matches':bad});assert not bad
 # Byte-only inventory; does not execute targets or infer opaque ownership.
 A=W/'analysis';shutil.copytree(P/'method',A);(A/'static-inputs').mkdir()
 old=Path(g['baseline_artifact_root'])
 for src,name in [(P/'proof/original.so','original.so'),(old/'candidate.so','candidate.so'),(old/'unstripped.so','symbols.so')]:shutil.copy2(src,A/'static-inputs'/name)
 assert H(A/'static-inputs/candidate.so')==g['baseline_candidate']and H(A/'static-inputs/symbols.so')==g['baseline_symbols']
 shutil.copy2(B/'artifacts/pump_recovered.so',A/'candidate.so');shutil.copy2(B/'target/sbf-solana-solana/release/pump_recovered.so',A/'unstripped.so')
 with(W/'inventory.stdout').open('x')as out,(W/'inventory.stderr').open('x')as err:q=subprocess.run([sys.executable,'-B',str(A/'full_inventory.py')],cwd=A,stdout=out,stderr=err,env=env)
 record('inventory-exit.json',{'returncode':q.returncode});q.check_returncode()
 record('build-only-assessment.json',{'passed':True,'candidate_sha256':H(A/'candidate.so'),'symbols_sha256':H(A/'unstripped.so'),'runtime_executions':0,'semantic_acceptance':False,'next':'Root full emitted-body/error/tuple/call review required; separate runtime controller and authorization required.'})
except BaseException as exc:
 record('controller-exit.json',{'returncode':1,'error_type':type(exc).__name__,'message':str(exc)});event({'phase':'controller-failed'});raise
else:record('controller-exit.json',{'returncode':0});event({'phase':'awaiting-static-review-no-runtime'})
