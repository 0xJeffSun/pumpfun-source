# UNEXECUTED Pump CTO build-only plan

Root review of this control manifest and frozen bcb proof is required before launch. No build or target execution has been authorized by this packet.

The baseline is exactly 37 accepted 3ae/d9d inputs, copied hash-for-hash from the retained scratch and independently bound to accepted main source-proposed.json. Only admin_cto.rs changes, with the exact two-site bcb proposal: owned CreatorShouldNotBeZero + (target, default) and owned ConstraintSeeds + (actual holder_creator_vault, expected dest). No compared-key source locations are fabricated. Complete original bodies, typed-role/decoder proof, raw tuple construction and previous limitations remain in proof/.

The frozen restored bb helper uses explicit v1.44 and the existing SDK v1.52 strip phase; baseline used e0 explicit-v1.44. This controller does not claim helper byte equality with the historical baseline. It changes no flags, profile, path remaps, workspace or dependencies. All 37 compile inputs are frozen (README is not a baseline Pump compile input). Stopped files are copied and hashed opaquely, not investigated.

Commands, after root review, from the original repository:

    python3 -B work/pump-admin-cto-6030-2006-build-control/controller.py --reviewed-control-sha256 MANIFEST_SHA256
    python3 -B work/pump-admin-cto-6030-2006-build-control/controller.py --reviewed-control-sha256 MANIFEST_SHA256 --launch-build

The first command only remeasures retained files. The second creates work/pump-admin-cto-6030-2006-build exactly once; a failed attempt cannot be overwritten or retried. Actual process exits and stdout/stderr are retained. Sources, helpers, resolved cargo-build-sbf selection, five pinned tool binaries, 53 SDK files and 252 locked packages / 14,281 retained archive/source files are checked before/after. The dependency witness is retained baseline provenance, not a claim that the whole mutable cargo cache is identical. No dependency resolution refresh/download is authorized.

Successful compilation is followed only by stack/backend gates and byte-only before/after ledgers using the same admitted method; semantic roles of opaque windows remain unresolved. Full emitted CTO app/wrapper/parser/error-converter/compared-key bodies and tuple order must be independently reviewed before any semantic acceptance or separate runtime controller. The existing full baseline/focused input lists are not invoked here. Runtime, new fixtures, probes, active source/README/index/Git writes are absent.

Method output analysis/full-before-after-inventory.json.gz includes complete original inferred windows, candidate symbol and inferred windows, raw symbol aliases, branches/calls/relocations and section byte coverage. Different boundary methods are preserved and not conflated. Transitive data/semantic closure remains explicitly unknown. Historical full call/data and before/after ledgers are retained unchanged at packet root.

Preparation history: an initial packaging attempt used compare.py instead of scripts/compare.py and failed before any build/controller execution; the path was corrected. No target/build attempt occurred.
