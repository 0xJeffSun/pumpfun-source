"""Read-only classify saved CTO logs; parser2006 is not application2006 coverage."""
from pathlib import Path
import argparse,gzip,json,re,hashlib
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)if b[:2]==b'\x1f\x8b'else b)
D=a.root/'differential/admin_cto.json.gz';S=a.root/'surfpool/admin_cto.json.gz'
if not S.exists():
 found=[f for f in(a.root/'surfpool/admin_cto').glob('pump-*-transactions.json')if 'signed_transactions'in read(f)];assert len(found)==1;S=found[0]
results={}
for kind,path in [('differential',D),('surfpool',S)]:
 data=read(path);rows=[dict(r['original'],case=r['case'])for r in data['cases']]if kind=='differential'else data['original'];out={'cases':len(rows),'6030_application':[],'2006_application':[],'2006_parser_or_other':[]}
 for row in rows:
  logs=row.get('logs',[]);name=row['case'].get('name',row['case']);selected=[l for l in logs if 'Error Number: 6030.'in l or 'Error Number: 2006.'in l]
  for line in selected:
   field='6030_application'if 'admin_cto.rs:307.'in line and 'Error Number: 6030.'in line else '2006_application'if 'admin_cto.rs:648.'in line and 'Error Number: 2006.'in line else '2006_parser_or_other'
   out[field].append({'case':name,'original_error':row.get('error'),'raw_error_line':line})
 results[kind]={'receipt_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),**out}
a.output.write_text(json.dumps({'scope':'Existing original saved logs only; changed-domain evidence needs exact original application location. No new fixtures or probes.','counts':{k:{f:len(v[f])for f in ['6030_application','2006_application','2006_parser_or_other']}for k,v in results.items()},'details':results},indent=2)+'\n')
