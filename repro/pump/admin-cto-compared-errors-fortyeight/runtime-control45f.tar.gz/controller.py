"""UNEXECUTED runtime-only controller; frozen admitted case/harness lists only."""
from pathlib import Path
import argparse,json,gzip,hashlib,shutil,subprocess,sys,os,datetime
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[1];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
a=argparse.ArgumentParser();a.add_argument('--reviewed-control-sha256',required=True);a.add_argument('--run-existing-corpus',action='store_true');args=a.parse_args()
assert H(P/'manifest.json')==args.reviewed_control_sha256
m=J(P/'manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and f not in[P/'manifest.json',P/'manifest.sha256']}
for n,h in m.items():assert H(P/n)==h and not(P/n).is_symlink(),n
g=J(P/'inputs.json');B=P/'baseline-d9d';assert H(B/'manifest.json')==g['baseline_seal']=='d9d6adc2f5d1533c04999626f93d1aef6a6d0acfb100a11483b4ca777ef62cd6'
for n,v in J(B/'manifest.json').items():assert H(B/n)==v['sha256']and(B/n).stat().st_size==v['bytes'],n
for n,h in J(P/'runtime-python-files.json').items():assert H(Path(n))==h,n
for n,h in g['source37'].items():assert H(P/'compiled-source'/n)==h,n
assert H(P/'actual-build/candidate.so')==g['candidate']and H(P/'actual-build/unstripped.so')==g['symbols']
assert J(P/'actual-build/build-exit.json')['returncode']==J(P/'actual-build/controller-exit.json')['returncode']==0
assert H(P/'static944e/manifest.json')==g['static_seal']=='944e7c36099287528b3d118eb1e3e6329813ba8508054b4255c93f1744e24f3b'
checks=[]
def readonly_checks():
 commands=[('frozen-build-preflight',[g['python'],'-B',str(R/'work/pump-admin-cto-6030-2006-build-control-v2/controller.py'),'--reviewed-control-sha256',g['build_control_seal']]),('emitted-static',[g['python'],'-B',str(R/'work/pump-admin-cto-6030-2006-build-v2/static-review/verify_static.py'),'--check']),('explicit-helper-proof',[g['python'],'-B',str(B/'helper-explicit-version-proof/verify.py')])]
 out=[]
 for name,cmd in commands:
  r=subprocess.run(cmd,cwd=R,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});out.append({'name':name,'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,out[-1]
 return out
checks=readonly_checks()
if not args.run_existing_corpus:print(json.dumps({'preflight':'PASS','builds':0,'runtime':'UNRUN','read_only_checks':checks}));raise SystemExit(0)
O=P.parent/'pump-admin-cto-6030-2006-runtime';O.mkdir(exist_ok=False)
def record(n,v):
 with(O/n).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def snapshot(root):return {str(f.relative_to(root)):H(f)for f in root.rglob('*')if f.is_file()}
children=[]
def run(name,cmd,cwd):
 with(O/(name+'.stdout')).open('x')as out,(O/(name+'.stderr')).open('x')as err:r=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':os.pathsep.join(str(repo/n)for n in ['scripts','.','localnet'])})
 row={'name':name,'command':cmd,'returncode':r.returncode,'stdout_sha256':H(O/(name+'.stdout')),'stderr_sha256':H(O/(name+'.stderr'))};children.append(row);record(name+'-exit.json',row);r.check_returncode();return row
try:
 record('preflight.json',{'control_seal':args.reviewed_control_sha256,'read_only_checks':checks,'source37':g['source37'],'candidate':g['candidate'],'symbols':g['symbols'],'runtime_scope':'unchanged9269+1024/68bindings; no build/new cases'})
 repo=O/'repo';shutil.copytree(P/'seed-repo',repo);W=repo/'work/pump-admin-cto-error-batch-build';W.mkdir(parents=True)
 for n in ['run_regressions.py','run_surfpool.py','run_existing_extra.py','verify_receipts.py','verify_extra_saved.py','historical-nested-identities.json','pump-idl.json','baseline.json']:
  shutil.copy2(B/n,W/n)
 shutil.copytree(B/'runtime-layer',W/'runtime-layer');shutil.copytree(P/'compiled-source',W/'source')
 (W/'build-01/artifacts').mkdir(parents=True);shutil.copy2(P/'actual-build/candidate.so',W/'build-01/artifacts/pump_recovered.so');(W/'static-inputs').mkdir();shutil.copy2(B/'candidate.so',W/'static-inputs/candidate.so')
 # Explicit metadata-only path rebinding; original raw reports stay authenticated in control.
 rebindings=[];compiled={str((W/'source'/n).relative_to(repo)):h for n,h in g['source37'].items()}
 for name in ['build-attempt.json','build-comparison.json']:
  old=J(P/'actual-build/build-01'/name);new=json.loads(json.dumps(old))
  new['source_sha256']=compiled
  if 'source_after_sha256'in new:new['source_after_sha256']=compiled
  (W/'build-01'/name).write_text(json.dumps(new,indent=2)+'\n');rebindings.append({'file':'build-01/'+name,'raw_actual_sha256':H(P/'actual-build/build-01'/name),'runtime_metadata_sha256':H(W/'build-01'/name),'only_changed_fields':['source_sha256']+(['source_after_sha256']if 'source_after_sha256'in old else [])})
 shutil.copy2(P/'actual-build/build-01/build.log',W/'build-01/build.log')
 (W/'runtime-layer/nested-harness/expected-source-map.json').write_text(json.dumps(g['source37'],indent=2)+'\n')
 inputs=J(B/'inputs-before.json');inputs['compiler_source_sha256']=compiled;inputs['runtime_layer_sha256']={str(f.relative_to(repo)):H(f)for f in(W/'runtime-layer').rglob('*')if f.is_file()}
 # Baseline root programs remain historical incidental source; compiled sources are isolated at W/source.
 (W/'inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n');record('metadata-rebindings.json',{'records':rebindings,'inputs_changed_fields':['compiler_source_sha256','runtime_layer_sha256'],'nested_expected_map_changed':True,'harness_bytes_changed':0,'case_lists_changed':0,'helper_relationship':'Runtime archived e0 helper remains unchanged metadata input; actual compilation used audited bb, explicit-v1.44 AST equivalence proof retained/verified. No global gate failure ignored.'})
 frozen=snapshot(repo);record('runtime-inputs-before.json',frozen)
 for name in ['run_regressions','run_existing_extra','run_surfpool','verify_receipts','verify_extra_saved']:run(name,[g['python'],'-B',str(W/(name+'.py'))],repo)
 # Preserve independent per-child suite records and count the exact admitted receipt domains.
 diffs=J(W/'differential/run.json');surfs=J(W/'surfpool/run.json');assert len(diffs)==38 and sum(r['case_count']for r in diffs)==9237 and len(surfs)==28
 extra=J(W/'extra-run.json');assert len(extra)==4 and all(r['returncode']==0 for r in extra)
 assert J(W/'independent-verification.json')['surfpool_comparisons']==1024
 run('changed-domain-coverage',[g['python'],'-B',str(P/'coverage.py'),str(W),'--output',str(O/'changed-domain-coverage.json')],repo)
 for n,h in frozen.items():assert H(repo/n)==h,n
 record('runtime-inputs-after.json',{n:H(repo/n)for n in frozen});record('readonly-after.json',readonly_checks())
 for n,h in J(P/'runtime-python-files.json').items():assert H(Path(n))==h,n
 record('summary.json',{'passed':True,'candidate':g['candidate'],'symbols':g['symbols'],'differential_cases':9269,'surfpool_comparisons':1024,'receipt_bindings':68,'nested16_plus_route16_included_in9269':True,'all_actual_child_exits':children,'source37':g['source37'],'builds':0,'new_fixtures':0,'active_source_reads':False,'changed_domain_coverage':J(O/'changed-domain-coverage.json')['counts'],'limits':'No exhaustive/fulloriginal/logidentity claim; full saved original assertions/signatures/effects retained unchanged.'})
except BaseException as exc:
 # Always retain post-attempt source/tool/dependency evidence, even on child failure.
 post={}
 if 'frozen'in locals():
  current={n:H(repo/n)if(repo/n).is_file()else None for n in frozen};post['changed_or_missing']=[n for n in frozen if current[n]!=frozen[n]]
  if not(O/'runtime-inputs-after.json').exists():record('runtime-inputs-after.json',current)
 try:post['read_only_checks']=readonly_checks()
 except BaseException as gate:post['read_only_gate_failure']={'type':type(gate).__name__,'message':str(gate)}
 post['runtime_python_changed']=[n for n,h in J(P/'runtime-python-files.json').items()if not Path(n).is_file()or H(Path(n))!=h]
 record('failure-post-gates.json',post)
 record('controller-exit.json',{'returncode':1,'error_type':type(exc).__name__,'message':str(exc),'children':children});raise
else:record('controller-exit.json',{'returncode':0,'children':children})
