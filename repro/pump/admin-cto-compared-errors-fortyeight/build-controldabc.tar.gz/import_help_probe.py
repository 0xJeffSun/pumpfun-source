"""Import-only isolated help harness. Audit denies child processes and sockets."""
import sys,runpy,pathlib,json,hashlib,contextlib,io
script=pathlib.Path(sys.argv[1]).resolve();out=io.StringIO();sys.path.insert(0,str(script.parent));sys.argv=[str(script),'--help']
def audit(event,args):
 if event=='subprocess.Popen' or event=='os.system' or event.startswith('socket.'):raise RuntimeError('import-only harness denied '+event)
sys.addaudithook(audit)
with contextlib.redirect_stdout(out):
 try:runpy.run_path(str(script),run_name='__main__')
 except SystemExit as e:code=e.code
 else:raise AssertionError('Expected argparse help exit')
assert code==0,code
modules={}
for name,m in sorted(sys.modules.items()):
 file=getattr(m,'__file__',None)
 if file:
  p=pathlib.Path(file).resolve()
  if p.is_file():modules[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'local_helper':p.parent==script.parent}
local={n:v for n,v in modules.items()if v['local_helper']};assert set(local)=={'analyze','compare','build_source_manifest'},local
print(json.dumps({'returncode':code,'help_sha256':hashlib.sha256(out.getvalue().encode()).hexdigest(),'local_modules':local,'loaded_file_modules':modules,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'child_processes_and_sockets_denied':True},sort_keys=True))
