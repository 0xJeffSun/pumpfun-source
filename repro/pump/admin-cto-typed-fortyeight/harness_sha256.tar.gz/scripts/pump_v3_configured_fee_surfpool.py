#!/usr/bin/env python3
"""Signed offline Surfpool direct Pump creator-distribution comparisons with captured CPI programs."""
import argparse,base64,hashlib,json,socket,struct,subprocess,sys,time,urllib.request
from pathlib import Path
from solders.hash import Hash
from solders.instruction import AccountMeta,Instruction
from solders.transaction import Transaction
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import pump_v3_configured_fee_differential as fixture
from types import SimpleNamespace
from solders.compute_budget import set_compute_unit_limit
f=SimpleNamespace(Pubkey=fixture.f.Pubkey,PAYER=fixture.user,AUTH=fixture.user,OTHER=fixture.user,set_compute_unit_limit=set_compute_unit_limit)
for attr,name,folder in [('PUMP','pump','original'),('PROGRAM','pump_fees','original'),('AMM','pump_amm','original'),('TOKEN','spl_token','dependencies'),('TOKEN22','spl_token_2022','dependencies'),('ATA','associated_token','dependencies')]:setattr(f,attr,f.Pubkey.from_string(json.loads((ROOT/f'evidence/{folder}/{name}/capture.json').read_text())['program']))
PORT=20201
sha=lambda data:hashlib.sha256(data).hexdigest()
class RecordingVM:
 def __init__(self,vm):self.vm=vm;self.keys=set();self.accounts={};self.transaction=None
 def __getattr__(self,name):return getattr(self.vm,name)
 def set_account(self,key,account):self.keys.add(key);return self.vm.set_account(key,account)
 def send_transaction(self,tx):
  self.transaction=tx;self.accounts={}
  self.keys.update(tx.message.account_keys)
  for key in self.keys:
   a=self.vm.get_account(key)
   if a is None:self.accounts[str(key)]={'lamports':0,'data':'','owner':str(f.Pubkey.default()),'executable':False}
   elif not a.executable:self.accounts[str(key)]={'lamports':a.lamports,'data':a.data.hex(),'owner':str(a.owner),'executable':False}
  return self.vm.send_transaction(tx)
def prepare(c):
 original=fixture.f.LiteSVM;recorded=[]
 class VM(RecordingVM):
  def with_transaction_history(self,n):self.vm=self.vm.with_transaction_history(n);return self
 def factory():
  vm=VM(original());recorded.append(vm);return vm
 fixture.f.LiteSVM=factory
 try:receipt=fixture.run(ROOT/'evidence/original/pump/deployed.so',c)
 finally:fixture.f.LiteSVM=original
 vm=recorded[0]
 return {'case':c,'accounts':vm.accounts,'transaction_base64':base64.b64encode(bytes(vm.transaction)).decode(),'litesvm_error':receipt['error']}
def run(binary,cases,surfpool,output):
 def rpc(method,params=None):
  req=urllib.request.Request(f'http://127.0.0.1:{PORT}',data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params or []}).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=60) as response:result=json.load(response)
  if 'error' in result:raise RuntimeError((method,result['error']))
  return result['result']
 def get(key):
  a=rpc('getAccountInfo',[key,{'encoding':'base64'}])['value']
  return None if a is None else {'lamports':a['lamports'],'owner':a['owner'],'data':base64.b64decode(a['data'][0]).hex()}
 with (output/(binary.stem+'.log')).open('w') as log:
  proc=subprocess.Popen([str(surfpool),'start','--offline','--no-deploy','--no-tui','--no-studio','--host','127.0.0.1','--port',str(PORT),'--ws-port',str(PORT+1),'--airdrop-amount','0','--db',':memory:'],cwd=output,stdout=log,stderr=subprocess.STDOUT)
  try:
   for _ in range(100):
    if proc.poll() is not None:raise RuntimeError('Surfpool terminated')
    try:
     if rpc('getHealth')=='ok':break
    except OSError:pass
    time.sleep(.1)
   else:raise TimeoutError('Surfpool startup')
   programs=[(f.PROGRAM,ROOT/'evidence/original/pump_fees/deployed.so'),(f.PUMP,binary),(f.AMM,ROOT/'evidence/original/pump_amm/deployed.so')]+[(key,ROOT/f'evidence/dependencies/{name}/deployed.so') for name,key in [('spl_token',f.TOKEN),('spl_token_2022',f.TOKEN22),('associated_token',f.ATA)]]
   for key,path in programs:
    blob=path.read_bytes();extent=struct.unpack_from('<Q',blob,40)[0]+struct.unpack_from('<H',blob,58)[0]*struct.unpack_from('<H',blob,60)[0];assert not any(blob[extent:])
    rpc('surfnet_setAccount',[str(key),{'lamports':10**10,'data':blob[:extent].hex(),'owner':'BPFLoader2111111111111111111111111111111111','executable':True}])
   rows=[];previous=set()
   for row in cases:
    for key in previous-set(row['accounts']):rpc('surfnet_setAccount',[key,{'lamports':0,'data':'','owner':str(f.Pubkey.default()),'executable':False}])
    for key,account in row['accounts'].items():rpc('surfnet_setAccount',[key,account])
    previous=set(row['accounts']);before={key:get(key) for key in row['accounts']}
    old=Transaction.from_bytes(base64.b64decode(row['transaction_base64']));msg=old.message;h=msg.header;keys=msg.account_keys
    def writable(i):return i<h.num_required_signatures-h.num_readonly_signed_accounts if i<h.num_required_signatures else i<len(keys)-h.num_readonly_unsigned_accounts
    instructions=[Instruction(keys[ix.program_id_index],bytes(ix.data),[AccountMeta(keys[n],n<h.num_required_signatures,writable(n)) for n in ix.accounts]) for ix in msg.instructions]
    # Distinct compute budgets avoid transaction deduplication for repeated payloads.
    instructions[0]=f.set_compute_unit_limit(1400000-len(rows))
    signers=[f.PAYER];assert keys[:h.num_required_signatures]==[f.PAYER.pubkey()]
    tx=Transaction.new_signed_with_payer(instructions,f.PAYER.pubkey(),signers,Hash.from_string(rpc('getLatestBlockhash')['value']['blockhash']));assert all(tx.verify_with_results());encoded=base64.b64encode(bytes(tx)).decode()
    sim=rpc('simulateTransaction',[encoded,{'encoding':'base64','sigVerify':True,'innerInstructions':True}])['value'];sig=rpc('sendTransaction',[encoded,{'encoding':'base64','skipPreflight':True}])
    for _ in range(100):
     status=rpc('getSignatureStatuses',[[sig]])['value'][0]
     if status is not None:break
     time.sleep(.05)
    else:raise TimeoutError('Confirmation')
    assert status['err']==sim['err'];after={key:get(key) for key in row['accounts']}
    if status['err']:assert all(before[k]==after[k] for k in before if k!=str(f.PAYER.pubkey())),'Failed transaction changed nonpayer state'
    rows.append({'case':row['case'],'signature':sig,'transaction_base64':encoded,'error':status['err'],'before':before,'after':after,'logs':sim.get('logs',[]),'return_data':sim.get('returnData'),'inner_instructions':sim.get('innerInstructions')})
   return rows
  finally:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
def layouts():
 out={}
 for name in ['pump','pump_amm','pump_fees']:
  idl=json.loads((ROOT/f'evidence/upstream/{name}.json').read_text());types={t['name']:t for t in idl['types']}
  for e in idl['events']:
   offset=8
   for field in types[e['name']]['type']['fields']:
    if field['name']=='timestamp':out[bytes(e['discriminator'])]=offset;break
    t=field['type']
    if not isinstance(t,str) or t not in ['pubkey','u64','i64','bool','u8','u16','u32']:break
    offset+={'pubkey':32,'u64':8,'i64':8,'bool':1,'u8':1,'u16':2,'u32':4}[t]
 return out
def normalize_event(data,offsets):
 data=bytearray(data);key=bytes(data[:8]);assert key in offsets,('unknown event',key.hex());off=offsets[key];data[off:off+8]=bytes(8);return bytes(data)
def decode58(s):
 alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';n=0
 for c in s:n=n*58+alphabet.index(c)
 return bytes(len(s)-len(s.lstrip('1')))+n.to_bytes((n.bit_length()+7)//8,'big')
def normalized(row,offsets):
 events=[normalize_event(base64.b64decode(l.split(': ',1)[1]),offsets).hex() for l in row['logs'] if l.startswith('Program data: ')]
 inner=[]
 assert row['inner_instructions'] is not None,'RPC omitted inner instructions'
 for group in row['inner_instructions']:
  instructions=[]
  for ix in group['instructions']:
   if 'parsed' in ix:
    instructions.append(ix);continue
   data=decode58(ix['data'])
   if data[:8].hex()=='e445a52e51cb9a1d':data=data[:8]+normalize_event(data[8:],offsets)
   instructions.append({**ix,'data':data.hex()})
  inner.append({**group,'instructions':instructions})
 return {'error':row['error'],'before':row['before'],'after':row['after'],'events':events,'inner':inner,'return_data':row['return_data']}
def selected():
 rows=[c for c in fixture.cases() if (not c.get('flags') and c.get('mutation','none')=='none') or c['creator_override']==500]
 return [{**c,'name':str(i)} for i,c in enumerate(rows)]
def main():
 import re
 p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--surfpool',type=Path,default=ROOT/'work/localnet/surfpool');a=p.parse_args();a.output=a.output.resolve();a.surfpool=a.surfpool.resolve()
 assert subprocess.check_output([str(a.surfpool),'--version'],text=True).strip()=='surfpool 1.6.1'
 for port in [PORT,PORT+1]:
  with socket.socket() as s:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',port))
 a.output.mkdir(parents=True,exist_ok=False);original=a.output/'original.so';candidate=a.output/'candidate.so';original.write_bytes((ROOT/'evidence/original/pump/deployed.so').read_bytes());candidate.write_bytes(a.candidate.read_bytes())
 paths=[Path(__file__),Path(fixture.__file__),Path(fixture.f.__file__),ROOT/'research/imported-lab/analysis/pump_fun/curve-fresh-trades-v3-signed-surfpool.json']+[ROOT/f'evidence/original/{n}/deployed.so' for n in ['pump','pump_fees','pump_amm']]+[ROOT/f'evidence/dependencies/{n}/deployed.so' for n in ['spl_token','spl_token_2022','associated_token']]+[ROOT/f'evidence/upstream/{n}.json' for n in ['pump','pump_fees','pump_amm']];hashes={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths};cases=selected();prepared=[prepare(c) for c in cases];(a.output/'fixtures.json').write_text(json.dumps(prepared,indent=2)+'\n')
 x=run(original,prepared,a.surfpool,a.output);y=run(candidate,prepared,a.surfpool,a.output);(a.output/'raw-transactions.json').write_text(json.dumps({'original':x,'candidate':y},indent=2)+'\n');offsets=layouts();bad=[i for i,(l,r) in enumerate(zip(x,y)) if normalized(l,offsets)!=normalized(r,offsets)]
 def expected(v):
  if v is None:return None
  m=re.fullmatch(r'TransactionErrorInstructionError\(\((\d+), Tagged\(InstructionErrorCustom\((\d+)\)\)\)\)',v)
  if m:return {'InstructionError':[int(m[1]),{'Custom':int(m[2])}]}
  m=re.fullmatch(r'TransactionErrorInstructionError\(\((\d+), Fieldless\((\w+)\)\)\)',v)
  assert m,v
  return {'InstructionError':[int(m[1]),m[2]]}
 unexpected=[i for i,(r,p) in enumerate(zip(x,prepared)) if r['error']!=expected(p['litesvm_error'])]
 assert all(sha((ROOT/p).read_bytes())==h for p,h in hashes.items());assert sha(a.candidate.read_bytes())==sha(candidate.read_bytes())
 report={'scope':'Configured creator fee across three partial v3 handlers, SOL and synthetic USDC. Ordinary verified signed offline Surfpool transactions with actual captured dependency CPI. Exact state/errors/inner/returns/events comparison except known event timestamps. Other quote routes and full identity not established.','candidate_sha256':sha(candidate.read_bytes()),'original_sha256':sha(original.read_bytes()),'provenance':hashes,'surfpool_sha256':sha(a.surfpool.read_bytes()),'cases':len(cases),'signed_transactions':len(x)+len(y),'mismatches':bad,'unexpected_original_errors':unexpected,'original':x,'candidate':y};(a.output/'pump-v3-configured-fee-transactions.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['cases','signed_transactions','mismatches','unexpected_original_errors']},indent=2))
 if bad or unexpected:raise SystemExit(1)
if __name__=='__main__':main()
