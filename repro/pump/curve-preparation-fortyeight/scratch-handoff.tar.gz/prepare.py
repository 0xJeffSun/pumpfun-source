"""Freeze the approved three-file proposal and identical pinned build recipe."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, sys
R=Path.cwd();W=R/'work/pump-curve-preparation-build';P=R/'work/pump-buy-curve-decoder-integration-review/publication'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
def save(n,v):(W/n).write_text(json.dumps(v,indent=2)+'\n')
assert not(W/'source').exists()
assert H(P/'manifest.json')=='32681d971cfb86d0d4053a9ec067ae580ac983f933aadfc3ffa2f5ea765d33ad'
v=subprocess.run([sys.executable,'-B',str(P/'verify.py'),'--repo',str(R)],capture_output=True,text=True)
(W/'proposal-verification.stdout').write_text(v.stdout);(W/'proposal-verification.stderr').write_text(v.stderr);assert v.returncode==0
for n in [*J(P/'manifest.json'),'manifest.json','manifest.sha256']:
 assert not n.endswith('-keypair.json')and not n.endswith('.pyc')and '__pycache__'not in n
 p=W/'approved-proposal'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/n,p)
base=J(P/'current-source-sha256.json');source=J(P/'proposed-source-sha256.json');changes=J(P/'proposal/source-map.json')
assert len(base)==len(source)==37 and len(changes)==3
for n,h in base.items():
 assert H(R/n)==h
 p=W/'source'/n;p.parent.mkdir(parents=True,exist_ok=True)
 q=P/'proposal/source'/n if n in changes else P/'inputs/source'/n
 shutil.copyfile(q,p);assert H(p)==source[n]
assert {n for n in base if base[n]!=source[n]}==set(changes)
save('baseline-source-sha256.json',base);save('source-sha256.json',source);save('source-change-map.json',changes)
spec=importlib.util.spec_from_file_location('source_manifest',R/'scripts/build_source_manifest.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
actual=m.source_manifest(W/'source/programs/pump',W/'source/programs/pump',R)
assert len(actual)==37 and {n[n.index('programs/pump/'):]:h for n,h in actual.items()}==source
save('actual-source-sha256.json',actual)
previous=P/'inputs/repro/pump/final-error-metadata-fortyeight'
for n in ['tools-observed.json','sdk-source-sha256.json','build-helper-sha256.json','baseline-dependency-provenance.json.gz']:shutil.copyfile(previous/n,W/n)
for n,h in J(W/'build-helper-sha256.json').items():
 assert H(R/n)==h
 p=W/'build-helpers'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
old=P/'inputs/work/pump-final-error-metadata-build/build_once.py';text=old.read_text();text=text.replace("W=R/'work/pump-final-error-metadata-build'","W=R/'work/pump-curve-preparation-build'")
text=text.replace('One approved four-file metadata separation patch. No retry, repair, compiler/source/flag variants; no Buy mux.','One approved three-file connected decoder and preparation patch. No retry, repair, compiler/source/flag variants; no Buy mux.')
(W/'build_once.py').write_text(text)
save('build-runner-adaptation.json',{'source':str(old.relative_to(R)),'before_sha256':H(old),'after_sha256':H(W/'build_once.py'),'changes':['isolated work directory','scope description only']})
save('baseline.json',{'git_revision_observed':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'proposal_seal':H(P/'manifest.json'),'source_inputs':37,'changed_paths':list(changes),'main_source_unchanged':True,'scope':'Exactly approved connected decoder/preparation; no new fixtures or excluded branch work.'})
print(json.dumps({'prepared':True,'source_inputs':37,'changed_files':list(changes),'proposal_verification_exit':v.returncode},indent=2))
