from pathlib import Path
import difflib,json,hashlib
P=Path(__file__).resolve().parent

def replacement():return '''fn buy_prepare_curve<'info>(a: &BuyV3<'info>) -> Result<()> {
    // Original 0x3cd50: the temporary AccountInfo clone is dropped before rent.
    let current_size = a.bonding_curve.to_account_info().data_len();
    buy_fund_curve_rent(a, current_size.max(166))?;
    if current_size < 166 {
        // Original 0x3d0a8: preserve existing bytes; no explicit zero fill.
        a.bonding_curve.to_account_info().realloc(166, false)?;
    }
    Ok(())
}

fn buy_reserved_curve_fees(curve: &BondingCurve) -> Result<u64> {
    // Original 0xa2188: this first addition has its own error origin.
    curve.creator_fee.checked_add(curve.protocol_fees)
        .ok_or_else(|| error!(PumpError::Overflow))
}

fn buy_fund_curve_rent<'info>(a: &BuyV3<'info>, size: usize) -> Result<()> {
    // Original 0x3d250: stored quote decides native reservation, not base owner.
    let reserved = if a.bonding_curve.quote_mint == Pubkey::default() {
        let fees = buy_reserved_curve_fees(&a.bonding_curve)?;
        a.bonding_curve.real_quote_reserves.checked_add(fees)
            .ok_or_else(|| error!(PumpError::Overflow))?
    } else {
        0
    };
    let minimum = Rent::get()?.minimum_balance(size);
    // Drop the temporary clone/immutable borrow before building the CPI context.
    let available = a.bonding_curve.to_account_info().lamports()
        .saturating_sub(reserved);
    if minimum > available {
        anchor_lang::system_program::transfer(
            CpiContext::new(
                a.system_program.to_account_info(),
                anchor_lang::system_program::Transfer {
                    from: a.user.to_account_info(),
                    to: a.bonding_curve.to_account_info(),
                },
            ),
            minimum.saturating_sub(available),
        )?;
    }
    Ok(())
}
'''

def compose():
 before=(P/'inputs/source/admission.rs').read_text();a=before.index("fn buy_prepare_curve");z=before.index('fn buy_membership',a);after=before[:a]+replacement()+before[z:]
 return before,after,''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='source/admission.rs',tofile='source/admission.rs'))
if __name__=='__main__':
 b,a,d=compose();(P/'proposal').mkdir(exist_ok=True);(P/'proposal/admission.rs').write_text(a);(P/'proposal/preparation-only.patch').write_text(d)
 (P/'proposal/source-map.json').write_text(json.dumps({'scope':'Source-only patch against unaccepted partial composition, not main. Existing domain fence remains untouched. No claim of all117-row preservation.','before':hashlib.sha256(b.encode()).hexdigest(),'after':hashlib.sha256(a.encode()).hexdigest(),'changed_file':'source/admission.rs','main_edits':[]},indent=2)+'\n')
