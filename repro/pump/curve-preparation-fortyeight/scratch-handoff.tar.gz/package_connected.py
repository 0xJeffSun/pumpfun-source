from pathlib import Path
import json,gzip,hashlib,shutil,tarfile
R=Path.cwd();W=R/'work/pump-curve-preparation-build';P=W/'handoff';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)if b.startswith(b'\x1f\x8b')else b)
def cp(src,n):
 assert src.is_file()and not src.is_symlink()and not src.name.endswith('-keypair.json');dst=P/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def tree(src,n):
 for p in sorted(src.rglob('*')):
  assert not p.is_symlink()
  if p.is_file()and '__pycache__'not in p.parts:cp(p,str(Path(n)/p.relative_to(src)))
def save(n,v):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
assert not P.exists();ver=read(W/'independent-verification.json');assert ver['differential_case_count']==9237 and ver['surfpool_comparisons']==1024 and not ver['mismatches'];P.mkdir()
for n in ['approved-proposal','source','runtime-layer','static-inputs','build-helpers','route-original','route-candidate','nested-original.json.gz.case-journal','nested-differential.json.gz.case-journal']:tree(W/n,n)
files=['candidate.so','unstripped.so','source-sha256.json','baseline-source-sha256.json','actual-source-sha256.json','source-change-map.json','baseline.json','tools-observed.json','toolchain-phases.json','sdk-source-sha256.json','baseline-dependency-provenance.json.gz','dependency-before.json','dependency-after.json','build-helper-sha256.json','prebuild-manifest-sha256.json','build-launch.json','build-result.json','runtime-adaptation.json','runtime-layer-manifest.json','inputs-before.json','harness_sha256.tar.gz','repository_fixture_snapshot_sha256.tar.gz','published_additional_inputs.tar.gz','analyze_fresh.py','elf_reader.py','metadata_closure.py','layer01_analyze_original.py','layer_inventory.py','layer_inventory.adapter.patch','layer_inventory_adapter.json','full_inventory.py','fresh-metadata.json','before-after-inventory.json','metadata-closure.json','full-before-after-inventory.json.gz','function-match.json','match-serializer.py','verify_extra_saved.py','historical-nested-identities.json','pump-idl.json','extra-run.json','nested-original.json.gz','nested-original.json.gz.partial.json.gz','nested-differential.json.gz','nested-differential.json.gz.partial.json.gz','extra-saved-verification.json','independent-verification.json','receipt-build-bindings.json','surfpool-executable-sha256.json','prepare.py','prepare_runtime.py','build_once.py','run_regressions.py','run_surfpool.py','run_existing_extra.py','verify_receipts.py','validation-script-adaptations.json','additional-method-origins.json','root-runtime-exits.json','root-verifier-adaptation.json','verify_receipts.before-root.py','verify-receipts-root.patch']
for n in files:cp(W/n,n)
for n in ['build-attempt.json','build-comparison.json']:cp(W/'build-01'/n,'build/'+n)
(P/'build/build.log.gz').write_bytes(gzip.compress((W/'build-01/build.log').read_bytes(),mtime=0))
with tarfile.open(P/'source-snapshot.tar.gz','w:gz')as t:
 for n,h in read(W/'source-sha256.json').items():assert H(W/'source'/n)==h;t.add(W/'source'/n,arcname=n,recursive=False)
for p in W.iterdir():
 if p.is_file()and p.suffix in ['.stdout','.stderr']:cp(p,'logs/'+p.name)
for p in (W/'differential').iterdir():
 if p.is_file():
  if p.suffix=='.log':q=P/'logs'/('differential-'+p.name+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:cp(p,'differential/'+p.name)
cp(W/'surfpool/run.json','surfpool/run.json');bindings=[];actual=read(W/'actual-source-sha256.json');buildsha=H(P/'build/build-comparison.json');cand=H(P/'candidate.so');orig=H(P/'static-inputs/original.so')
for row in ver['differential_suites']:
 path='differential/'+row['suite']+'.json.gz';bindings.append({'suite':row['suite'],'kind':'differential','path':path,'sha256':H(P/path),'cases':row['case_count'],'verified':row['verified']})
for row,run in zip(ver['surfpool_suites'],read(W/'surfpool/run.json')):
 assert row['suite']==run['name'];directory=R/run['output'];found=[]
 for p in directory.glob('pump-*-transactions.json'):
  d=read(p)
  if isinstance(d,dict)and'candidate_sha256'in d and'signed_transactions'in d:found.append(p)
 assert len(found)==1;p=found[0];assert H(p)==row['receipt_sha256'];path='surfpool/'+row['suite']+'.json.gz';(P/path).write_bytes(gzip.compress(p.read_bytes(),mtime=0));bindings.append({'suite':row['suite'],'kind':'surfpool','path':path,'sha256':H(P/path),'cases':row['cases'],'verified':row['verified']})
 for log in directory.rglob('*.log'):
  q=P/'logs/surfpool-detail'/row['suite']/log.relative_to(directory);q.parent.mkdir(parents=True,exist_ok=True);q.with_suffix(q.suffix+'.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
bindings.append({'suite':'nested_general','kind':'differential','path':'nested-differential.json.gz','sha256':H(P/'nested-differential.json.gz'),'cases':16,'verified':{'transactions':32,'signatures':64}})
rows=read(P/'route-candidate/summary.json')['rows'];pairs=[{'case':r['case'],'original':read(P/'route-original'/r['file']),'candidate':read(P/'route-candidate'/r['file']),'mismatches':r['mismatches']}for r in rows]
route={'case_count':16,'cases':pairs,'candidate_sha256':cand,'original_sha256':orig,'mismatches':[],'scope':'Transport aggregate of unchanged16 original/candidate comparisons; no additional executions.'};path='route-differential.json.gz';(P/path).write_bytes(gzip.compress((json.dumps(route,separators=(',',':'))+'\n').encode(),mtime=0));bindings.append({'suite':'general_route','kind':'differential','path':path,'sha256':H(P/path),'cases':16,'verified':{'transactions':32,'signatures':32}})
for row in bindings:row.update(actual_source_sha256=actual,build_report_sha256=buildsha,candidate_sha256=cand,original_sha256=orig)
save('receipt-bindings.json',bindings);cp(R/'work/pump-tokenkeg-two-curve-recovery/original-only-01.json.gz','historical-two-curve-original.json.gz')
with tarfile.open(P/'prebuild-snapshot.tar.gz','w:gz')as t:
 for n,h in read(W/'prebuild-manifest-sha256.json').items():assert H(W/n)==h;t.add(W/n,arcname=n,recursive=False)
save('build-report-original-path.json',{'path':str((W/'build-01/build-comparison.json').relative_to(R))})
save('runtime-identities.json',{'python_solders_nested':read(W/'nested-differential.json.gz')['provenance']['runtime_files'],'python_solders_route':read(W/'route-candidate/bindings-after.json')['runtime_files'],'surfpool':{'path':read(W/'inputs-before.json')['surfpool_path'],'sha256':read(W/'inputs-before.json')['surfpool_sha256']}})
cp(R/'work/layer02-integration/verify_connected.py','verify.py');cp(Path(__file__),'package_connected.py')
print(json.dumps({'assembled':True,'files':sum(p.is_file()for p in P.rglob('*')),'bindings':len(bindings),'sealed':False}))
