from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
R=Path.cwd();W=R/'work/pump-curve-preparation-main';P=R/'repro/pump/curve-preparation-fortyeight';PY=R/'work/test-env/bin/python';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def invoke(name,root,success):
 cmd=[str(PY),'-B',str(root/'repro/pump/curve-preparation-fortyeight/verify.py'),'--current-main','--repo',str(root)];r=subprocess.run(cmd,cwd='/',text=True,capture_output=True);(W/(name+'.stdout')).write_text(r.stdout);(W/(name+'.stderr')).write_text(r.stderr);row={'name':name,'returncode':r.returncode,'expected_success':success,'result_as_expected':(r.returncode==0)==success,'stdout_sha256':H(W/(name+'.stdout')),'stderr_sha256':H(W/(name+'.stderr'))};records.append(row);print(json.dumps(row),flush=True);assert row['result_as_expected'],r.stdout+r.stderr
with tempfile.TemporaryDirectory(prefix='pump-public-current-')as td:
 root=Path(td);dest=root/P.relative_to(R);shutil.copytree(P,dest)
 groups=json.loads((P/'current-bindings.json').read_text())['groups']
 for group,entries in groups.items():
  for n,h in entries.items():
   src=R/n;out=root/n;assert H(src)==h
   if out.exists():assert H(out)==h
   else:out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,out)
 for cmd in [['git','init','-q'],['git','add','.']]:subprocess.run(cmd,cwd=root,check=True,capture_output=True)
 invoke('copied-current-main-positive',root,True)
 (dest/'candidate.so').unlink();invoke('copied-current-main-missing',root,False);shutil.copyfile(P/'candidate.so',dest/'candidate.so')
 source=root/'programs/pump/src/lib.rs';source.write_bytes(source.read_bytes()+b'\n');invoke('copied-current-main-source-tamper',root,False)
(W/'public-portability-results.json').write_text(json.dumps({'package_manifest_sha256':H(P/'manifest.json'),'tests':records,'scope':'Isolated copied repository only; git staging occurs only in this temporary copy, not the shared repository. No VM, build or signing.'},indent=2)+'\n')
