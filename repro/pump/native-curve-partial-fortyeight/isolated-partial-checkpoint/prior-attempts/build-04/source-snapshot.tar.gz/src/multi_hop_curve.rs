//! Partial independent reconstruction of ordinary native single-curve runs.
//! Multi-curve runs, token extensions, synthetic completion and non-native
//! quote branches are deliberately rejected pending separate recovery.
use anchor_lang::prelude::*;
use anchor_lang::solana_program::{instruction::{Instruction,AccountMeta},program::invoke_signed};
use anchor_spl::{token::{Token,SyncNative},token_2022::Token2022,token_interface::{self,Mint,TokenAccount,TransferChecked}};
use crate::{Global,PumpError,LegacyFeeConfig};
use crate::trade_types::{BondingCurve,FeeConfig,Fees,TradeEvent};
const FEES:Pubkey=anchor_lang::solana_program::pubkey!("pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ");
const AMM:Pubkey=anchor_lang::solana_program::pubkey!("pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA");
const WSOL:Pubkey=anchor_spl::token::spl_token::native_mint::ID;
#[event_cpi]
#[derive(Accounts)]
pub struct MultiHopCurve<'info>{
 #[account(seeds=[b"global"],bump)]pub global:Box<Account<'info,Global>>,
 #[account(seeds=[b"fee_config",crate::ID.as_ref()],bump=fee_config.to_account_info().try_borrow_data()?[8],seeds::program=FEES)]pub fee_config:Box<Account<'info,LegacyFeeConfig>>,
 #[account(seeds=[b"global_config"],bump,seeds::program=AMM)]pub pump_amm_global_config:Signer<'info>,
 #[account(mut)]pub user:Signer<'info>,
 pub source_authority:Signer<'info>,
 #[account(mut)]pub source:Box<InterfaceAccount<'info,TokenAccount>>,
 #[account(mut)]pub destination:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: Native recipient membership and its canonical WSOL ATA are checked.
 #[account(mut)]pub buyback_fee_recipient:UncheckedAccount<'info>,
 pub token_program:Program<'info,Token>,
 pub token_2022_program:Program<'info,Token2022>,
 pub system_program:Program<'info,System>,
}
#[derive(Accounts)]
pub struct CurveHop<'info>{
 pub base_mint:Box<InterfaceAccount<'info,Mint>>,
 pub quote_mint:Box<InterfaceAccount<'info,Mint>>,
 #[account(mut,seeds=[b"bonding-curve",base_mint.key().as_ref()],bump,
 constraint=bonding_curve.quote_mint==quote_mint.key() || (bonding_curve.quote_mint==Pubkey::default() && quote_mint.key()==WSOL) @ PumpError::MintDoesNotMatchBondingCurve)]
 pub bonding_curve:Box<Account<'info,BondingCurve>>,
 #[account(mut)]pub base_vault:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: Address and native quote branch checked before transfer.
 #[account(mut)]pub quote_vault:UncheckedAccount<'info>,
}
#[derive(AnchorSerialize,AnchorDeserialize,Clone)]
pub struct CurveRunResult{pub amount_out:u64,pub buyback_fee:u64}
fn add(a:u64,b:u64)->Result<u64>{a.checked_add(b).ok_or(error!(PumpError::Overflow))}
fn sub(a:u64,b:u64)->Result<u64>{a.checked_sub(b).ok_or(error!(PumpError::Overflow))}
fn n(a:u128)->Result<u64>{u64::try_from(a).map_err(|_|error!(PumpError::Truncation))}
fn fee(a:u64,b:u64)->Result<u64>{n((a as u128*b as u128+9999)/10000)}
fn fees(a:&MultiHopCurve,c:&BondingCurve)->Result<Fees>{
 let info=a.fee_config.to_account_info();let data=info.try_borrow_data()?;
 require!(data.len()>=2512,PumpError::FeeConfigTooShort);
 let config=FeeConfig::deserialize(&mut &data[8..]).map_err(|_|error!(anchor_lang::error::ErrorCode::AccountDidNotDeserialize))?;
 require!(!config.fee_tiers.is_empty(),PumpError::FeeTiersEmpty);
 let cap=(c.token_total_supply as u128*c.virtual_quote_reserves as u128).checked_div(c.virtual_token_reserves as u128).ok_or(error!(PumpError::DivisionByZero))?;
 let mut f=config.fee_tiers.iter().rev().find(|t|t.market_cap_lamports_threshold<=cap).unwrap_or(&config.fee_tiers[0]).fees.clone();
 if c.creator_fee_bps>0{f.creator_fee_bps=c.creator_fee_bps;}
 if c.creator==Pubkey::default(){f.creator_fee_bps=0;}
 Ok(f)
}
fn move_lamports(from:&AccountInfo,to:&AccountInfo,amount:u64)->Result<()>{
 if amount==0{return Ok(())}
 let a=sub(from.lamports(),amount)?;let b=add(to.lamports(),amount)?;
 **from.try_borrow_mut_lamports()?=a;**to.try_borrow_mut_lamports()?=b;Ok(())
}
fn native_buyback<'info>(a:&MultiHopCurve<'info>,curve:AccountInfo<'info>,amount:u64)->Result<()>{
 if amount==0{return Ok(())}
 let to=a.buyback_fee_recipient.to_account_info();move_lamports(&curve,&to,amount)?;
 // The original flushes the writable native balances through a genuine self CPI
 // before SyncNative. This signs only this program's own event-authority PDA.
 let bump=Pubkey::find_program_address(&[b"__event_authority"],&crate::ID).1;
 invoke_signed(&Instruction{program_id:crate::ID,accounts:vec![AccountMeta::new_readonly(a.event_authority.key(),true),AccountMeta::new(curve.key(),false),AccountMeta::new(to.key(),false)],data:vec![228,69,165,46,81,203,154,29]},&[a.event_authority.to_account_info(),curve,to.clone(),a.program.to_account_info()],&[&[b"__event_authority",&[bump]]])?;
 anchor_spl::token::sync_native(CpiContext::new(a.token_program.to_account_info(),SyncNative{account:to}))
}
pub fn execute<'info>(ctx:Context<'_,'_,'info,'info,MultiHopCurve<'info>>,amount_in:u64,hop_fees:Vec<u8>)->Result<CurveRunResult>{
 require!(amount_in>0,PumpError::BuyZeroAmount);
 require!(ctx.remaining_accounts.len()>=5 && ctx.remaining_accounts.len()%5==0,PumpError::NotEnoughRemainingAccounts);
 require!(hop_fees.len()==ctx.remaining_accounts.len()/5 && hop_fees.iter().all(|f|*f<4),PumpError::MultiHopHopFeesMismatch);
 require!(hop_fees.len()==1,PumpError::ReconstructionBranchUnsupported);
 let mut remaining=ctx.remaining_accounts;let mut bumps=CurveHopBumps::default();
 let mut h=CurveHop::try_accounts(&crate::ID,&mut remaining,&[],&mut bumps,&mut std::collections::BTreeSet::new())?;
 let a=&ctx.accounts;let c=&h.bonding_curve;let flag=hop_fees[0];
 require!(!c.complete,PumpError::BondingCurveComplete);
 require!(!c.is_cashback_coin,PumpError::CashbackCoinNotSupported);
 require!(!c.is_mayhem_mode,PumpError::MultiHopMayhemCurveNotSupported);
 require!(h.base_mint.to_account_info().owner==&anchor_spl::token::ID && h.base_mint.to_account_info().data_len()==82,PumpError::ReconstructionBranchUnsupported);
 require!(h.quote_mint.key()==WSOL && (c.quote_mint==Pubkey::default() || c.quote_mint==WSOL),PumpError::ReconstructionBranchUnsupported);
 require!(h.base_vault.to_account_info().owner==&anchor_spl::token::ID && h.base_vault.to_account_info().data_len()==165,PumpError::ReconstructionBranchUnsupported);
 require!(!c.is_holder_reward && h.bonding_curve.to_account_info().data_len()==166,PumpError::ReconstructionBranchUnsupported);
 let sell=a.source.mint==h.base_mint.key();
 require!(sell || a.source.mint==WSOL,PumpError::MultiHopDiscontinuousPath);
 require_keys_eq!(a.destination.mint,if sell{WSOL}else{h.base_mint.key()},PumpError::MultiHopDiscontinuousPath);
 let base_vault=anchor_spl::associated_token::get_associated_token_address_with_program_id(&h.bonding_curve.key(),&h.base_mint.key(),&anchor_spl::token::ID);
 let quote_vault=anchor_spl::associated_token::get_associated_token_address_with_program_id(&h.bonding_curve.key(),&WSOL,&anchor_spl::token::ID);
 require_keys_eq!(h.base_vault.key(),base_vault,anchor_lang::error::ErrorCode::ConstraintSeeds);
 require_keys_eq!(h.quote_vault.key(),quote_vault,anchor_lang::error::ErrorCode::ConstraintSeeds);
 if flag&1!=0{
  let info=a.buyback_fee_recipient.to_account_info();require_keys_eq!(*info.owner,anchor_spl::token::ID,PumpError::AccountTypeNotSupported);
  let state=TokenAccount::try_deserialize(&mut &info.try_borrow_data()?[..])?;
  require_keys_eq!(state.mint,WSOL,PumpError::MintDoesNotMatchBondingCurve);
  require!(a.global.buyback_fee_recipients.contains(&state.owner),PumpError::BuybackFeeRecipientNotAuthorized);
  require_keys_eq!(info.key(),anchor_spl::associated_token::get_associated_token_address_with_program_id(&state.owner,&WSOL,&anchor_spl::token::ID),anchor_lang::error::ErrorCode::ConstraintSeeds);
 }
 let mut f=fees(a,c)?;if flag&1==0{f.protocol_fee_bps=0;}if flag&2==0{f.creator_fee_bps=0;}
 let (base_amount,quote_amount,pf,cf)=if sell{
  let q=n(amount_in as u128*c.virtual_quote_reserves as u128/(c.virtual_token_reserves as u128+amount_in as u128))?;
  require!(q>0,PumpError::SellZeroAmount);
  (amount_in,q,fee(q,f.protocol_fee_bps)?,fee(q,f.creator_fee_bps)?)
 }else{
  let fee_quote=n(amount_in as u128*10000/(10000+f.protocol_fee_bps as u128+f.creator_fee_bps as u128))?;
  require!(fee_quote>0,PumpError::BuyNotEnoughSolToCoverFees);
  let pf=fee(fee_quote,f.protocol_fee_bps)?;let cf=fee(fee_quote,f.creator_fee_bps)?;
  let q=sub(sub(amount_in,pf)?,cf)?;
  require!(q>0,PumpError::BuySlippageBelowMinTokensOut);
  let effective=q.saturating_sub(1);
  let amount=n(c.virtual_token_reserves as u128*effective as u128/(c.virtual_quote_reserves as u128+effective as u128))?;
  require!(amount>0,PumpError::BuyZeroAmount);
  require!(amount<c.real_token_reserves,PumpError::ReconstructionBranchUnsupported);
  (amount,q,pf,cf)
 };
 let buyback=n(pf as u128*a.global.buyback_basis_points as u128/10000)?;
 let amount_out=if sell{sub(sub(quote_amount,pf)?,cf)?}else{base_amount};
 if sell{
  token_interface::transfer_checked(CpiContext::new(a.token_program.to_account_info(),TransferChecked{from:a.source.to_account_info(),mint:h.base_mint.to_account_info(),to:h.base_vault.to_account_info(),authority:a.source_authority.to_account_info()}),base_amount,h.base_mint.decimals)?;
 }
 let (vb,vq,rb,rq)=if sell{(add(c.virtual_token_reserves,base_amount)?,sub(c.virtual_quote_reserves,quote_amount)?,add(c.real_token_reserves,base_amount)?,sub(c.real_quote_reserves,quote_amount)?)}else{(sub(c.virtual_token_reserves,base_amount)?,add(c.virtual_quote_reserves,quote_amount)?,sub(c.real_token_reserves,base_amount)?,add(c.real_quote_reserves,quote_amount)?)};
 let creator_total=add(c.creator_fee,cf)?;let protocol_total=add(c.protocol_fees,sub(pf,buyback)?)?;
 let mint_key=h.base_mint.key();let bump=[bumps.bonding_curve];let seeds:&[&[u8]]=&[b"bonding-curve",mint_key.as_ref(),&bump];
 if !sell{
  require_keys_eq!(a.source_authority.key(),a.user.key(),PumpError::ReconstructionBranchUnsupported);
  anchor_lang::system_program::transfer(CpiContext::new(a.system_program.to_account_info(),anchor_lang::system_program::Transfer{from:a.user.to_account_info(),to:h.bonding_curve.to_account_info()}),amount_in)?;
  token_interface::transfer_checked(CpiContext::new_with_signer(a.token_program.to_account_info(),TransferChecked{from:h.base_vault.to_account_info(),mint:h.base_mint.to_account_info(),to:a.destination.to_account_info(),authority:h.bonding_curve.to_account_info()},&[seeds]),base_amount,h.base_mint.decimals)?;
 }
 native_buyback(a,h.bonding_curve.to_account_info(),buyback)?;
 if sell{move_lamports(&h.bonding_curve.to_account_info(),&a.user.to_account_info(),amount_out)?;}
 let c=&mut h.bonding_curve;c.virtual_token_reserves=vb;c.virtual_quote_reserves=vq;c.real_token_reserves=rb;c.real_quote_reserves=rq;c.creator_fee=creator_total;c.protocol_fees=protocol_total;
 let event=TradeEvent{mint:mint_key,sol_amount:quote_amount,token_amount:base_amount,is_buy:!sell,user:a.user.key(),timestamp:Clock::get()?.unix_timestamp,virtual_sol_reserves:vq,virtual_token_reserves:vb,real_sol_reserves:rq,real_token_reserves:rb,fee_recipient:Pubkey::default(),fee_basis_points:f.protocol_fee_bps,fee:pf,creator:c.creator,creator_fee_basis_points:f.creator_fee_bps,creator_fee:cf,track_volume:false,total_unclaimed_tokens:0,total_claimed_tokens:0,current_sol_volume:0,last_update_timestamp:0,ix_name:"multi_hop_swap".into(),mayhem_mode:false,cashback_fee_basis_points:0,cashback:0,buyback_fee_basis_points:a.global.buyback_basis_points,buyback_fee:buyback,shareholders:vec![],quote_mint:c.quote_mint,quote_amount,virtual_quote_reserves:vq,real_quote_reserves:rq,holder_rewards_bps:0,holder_rewards:0,creator_fee_unclaimed:creator_total,unparsed_trailing_field:0};
 emit!(event.clone());emit_cpi!(event);h.exit(&crate::ID)?;
 Ok(CurveRunResult{amount_out,buyback_fee:buyback})
}
