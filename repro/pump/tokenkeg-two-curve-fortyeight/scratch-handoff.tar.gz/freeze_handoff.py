#!/usr/bin/env python3
"""Freeze explicit allowlists; never open generated deployment keypairs."""
from pathlib import Path
import gzip,hashlib,json,shutil
W=Path(__file__).resolve().parent;R=next(p for p in W.parents if(p/'evidence/upstream/pump.json').is_file());H=W/'handoff';assert not H.exists();H.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification=json.loads((W/'independent-verification.json').read_text())
assert verification['differential_case_count']==9217 and verification['surfpool_comparisons']==1024 and verification['receipt_build_bindings']==65 and not verification['mismatches']
focused=json.loads((W/'focused-verification-01.json').read_text());assert focused['status']=='PASS'and focused['verified_signatures']==40
copies={}
def copy(source,destination,compress=False):
 assert not source.name.endswith('-keypair.json')and not source.is_symlink()
 target=H/destination;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
 raw=source.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0)if compress else raw)
 copies[str(source.relative_to(R))]={'path':destination,'source_sha256':hashlib.sha256(raw).hexdigest(),'packaged_sha256':sha(target),'transport':'gzip-original-bytes'if compress else'unchanged'}
for name in ['baseline.json','source-snapshot.tar.gz','baseline-source-sha256.json','candidate-source-sha256.json','source-proposal-02.patch','build-helper-sha256.json','dependency-provenance.json','toolchain-phases.json','cargo-rustc-info.json','build-preflight.json','inputs-before.json','harness-snapshot.tar.gz','harness-snapshot-sha256.json','verify_receipts.py','verify_handoff.py','independent-verification.json','receipt-build-bindings.json','surfpool-executable-sha256.json','run_regressions.py','run_surfpool.py','freeze_handoff.py','focused-01.json.gz','focused-01.log','focused-verification-01.json','focused-verification-01.stderr','verify_focused.py','harness-focused-01.py','ordinary_two_curve.py','base-fixture.json','verify_original_receipt.py']:
 copy(W/name,name)
for name in ['build-attempt.json','build-comparison.json']:copy(W/'build-01'/name,name)
for name in ['build-launcher-01.log','differential-orchestration.log','surfpool-orchestration.log']:copy(W/name,name)
copy(W/'build-01/artifacts/pump_recovered.so','candidate.so')
copy(W/'build-01/target/sbf-solana-solana/release/pump_recovered.so','unstripped.so')
copy(W/'build-01/build.log','build.log.gz',True)
for rel in json.loads((W/'build-helper-sha256.json').read_text()):copy(W/'build-helper-snapshot'/rel,'build-helper-snapshot/'+rel)
# The pre-build review package is copied byte for byte; its independent seal is retained.
pre=W/'prebuild-handoff';items=json.loads((pre/'manifest-sha256.json').read_text())
for name,info in items.items():assert sha(pre/name)==info['sha256'];copy(pre/name,'prebuild-handoff/'+name)
copy(pre/'manifest-sha256.json','prebuild-handoff/manifest-sha256.json')
for name in ['run.json','summary.json']:copy(W/'differential'/name,'differential/'+name)
for row in json.loads((W/'differential/run.json').read_text()):
 name=row['suite'];path=W/'differential'/(name+'.json.gz');already=path.read_bytes()[:2]==b'\x1f\x8b';copy(path,'differential/'+path.name,not already);copy(W/'differential'/(name+'.log'),'differential/'+name+'.log.gz',True)
copy(W/'surfpool/run.json','surfpool/run.json')
for row in json.loads((W/'surfpool/run.json').read_text()):
 directory=R/row['output'];name=row['name'];copy(W/'surfpool'/(name+'.log'),'surfpool/'+name+'.log.gz',True)
 found=[]
 for file in directory.glob('pump-*-transactions.json'):
  assert not file.name.endswith('-keypair.json');data=json.loads(file.read_text())
  if 'candidate_sha256'in data and 'signed_transactions'in data:found.append(file)
 assert len(found)==1
 copy(found[0],'surfpool/'+name+'/'+found[0].name+'.gz',True)
(H/'receipt-copy-map.json').write_text(json.dumps(copies,indent=2)+'\n')
summary={k:v for k,v in verification.items()if k not in ['differential_suites','surfpool_suites']}
summary.update({'candidate_bytes':(H/'candidate.so').stat().st_size,'new_two_curve_comparisons':20,'new_two_curve_verified_signatures':40,'new_two_curve_successes':16,'new_two_curve_genuine_pump_cpi_cases':18,'combined_differential_cases':9237,'implemented_handler_count_change':0,'partial_handler_count_change':0,'current_fully_implemented_handler_count':48,'current_partial_path_count':5,'source_change':'Only multi_hop_curve.rs; exact native/ordinary Tokenkeg two-curve routes added to an existing partial instruction.','build_attempts':1,'failed_builds':0,'unexpected_runtime_mismatches':0,'focused_expected_rejections_per_side':4,'compiler_selected':'v1.44','actual_sdk_strip_distribution':'v1.52','prebuild_seal_unchanged':True,'main_source_changed':False,'full_byte_equality':False,'security_audit_complete':False})
(H/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(H/'README.md').write_text('''# Isolated ordinary Tokenkeg two-curve Pump checkpoint

This package extends the existing partial `multi_hop_curve_swap` implementation to exactly SOL→A→B and B→A→SOL using ordinary Tokenkeg accounts, canonical pre-existing vaults and a native root whose stored quote is zero. Only `multi_hop_curve.rs` differs from the 36-input published Pump925 baseline at `80990317bd9c0363e071646b892490886d7bf946`. The one-curve body and all other instruction sources remain unchanged. Main promotion is not part of this package. Counts stay 48 fully implemented handlers and five partial paths.

The reviewed proposal02 compiled on the first attempt, with unchanged locks/profile/CLI/flags and all 36 inputs stable. `toolchain-phases.json` distinguishes the selected v1.44 compiler/linker from the unchanged installed CLI SDK's v1.52 `llvm-objcopy` stripping step. The whole ELF is 1,576,744 bytes, SHA-256 `5c1c1c2d1cd2c334b3e054b6a8fb5ac0638d80d13495c1c18d935ad20bfd62bb`. This is not byte-identical to the captured original. Historical source/toolchain equality and the security audit remain incomplete.

All 20 fixed original-versus-candidate cases pass, with 40 verified ordinary outer signatures. They include 16 successes, two AMM zero-input rejections before Pump, and two final AMM slippage rejections after successful Pump execution and outer rollback. Eighteen cases per side exercise an actual captured AMM→Pump CPI with 23 accounts and genuine AMM GlobalConfig PDA signing. All curves/vaults/volume accounts already exist as explicitly synthetic local state. No initializer, private authority substitution, altered historical signed payload or Token-2022 transfer is used. Compared projections include account state, actual inner instructions, events, return data, token transfers and logs after removing only compute-consumption lines. The original-only acceptance predates compilation and is retained unchanged with its independently reviewed arithmetic/authority verifier.

On the same candidate, all 37 unchanged differential suites (9,217 cases) and all 28 unchanged Surfpool runners (1,024 comparisons) also pass. Combined differential coverage is 9,237 cases. The old native one-curve subset remains 56 cases, 50 Pump CPIs, six caller rejections and 11 successes. Every fresh receipt binds this candidate and the actual 36 scratch compiler inputs; legacy embedded main-source maps are preserved as incidental checkout snapshots. Quote-control directly binds the adjacent scratch build report. No old runtime receipts are inherited for this executable.

Supported buys must remain strictly non-completing. Extension-bearing tokens, Token-2022 state, v3, stable/other quote routes, Mayhem, holder/cashback modes, arbitrary hop counts and other routing shapes remain unsupported. Stopped trade-fee/incentive/initializer lanes were not resumed. No new fully implemented handler is claimed.

`prebuild-handoff/` is preserved byte for byte with its original seal. The package retains source, exact build helpers, actual harness/runtime snapshot, build logs, compiler/strip evidence, dependency observations, all signed receipts and both source-review proposals. The preflight's initial JSON-wrapper lookup error is documented in `build-preflight.json`; it occurred before any build. There were no failed compile or differential attempts. Generated deployment keypair files are excluded before reads/hashing/copying. No entire build directory is archived.

Run `python verify_handoff.py` with solders installed to verify the saved package, source/harness archives, 65 established receipt bindings, the new two-curve binding and all signatures. This verifier executes no programs. Receipt compression is lossless and `receipt-copy-map.json` records both source and packaged hashes. Execution scripts retain their original workspace paths as provenance; they are not standalone replay instructions. The 131-file archive preserves the executed harness/fixture/orchestration inputs, while the new focused receipt separately records 32 observed Python/solders runtime files. Public dependency observations record 14,281 archive/source files and do not establish a hermetic historical graph.
''')
manifest={str(p.relative_to(H)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(H.rglob('*'))if p.is_file()}
(H/'manifest-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'payload_files':len(manifest),'payload_bytes':sum(x['bytes']for x in manifest.values()),'manifest_sha256':sha(H/'manifest-sha256.json'),'candidate_sha256':sha(H/'candidate.so')},indent=2))
