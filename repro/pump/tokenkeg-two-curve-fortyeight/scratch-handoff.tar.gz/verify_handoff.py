#!/usr/bin/env python3
"""Verify a frozen saved package, never executing a build or transaction."""
from pathlib import Path,PurePosixPath
import base64,gzip,hashlib,json,re,tarfile
from solders.transaction import VersionedTransaction
H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def safe(name):
 p=PurePosixPath(name);assert not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json'),name
 return p
def raw(name):
 p=H/safe(name);assert not p.is_symlink();return p.read_bytes()
def decoded(name):
 b=raw(name);return gzip.decompress(b)if b.startswith(b'\x1f\x8b')else b
def read(name):return json.loads(decoded(name))
def archive_map(name):
 out={}
 with tarfile.open(H/safe(name))as t:
  members=t.getmembers()
  for m in members:safe(m.name);assert m.isfile()and m.name not in out;out[m.name]=None
  for m in members:out[m.name]=sha(t.extractfile(m).read())
 return out
def encoded_transactions(v):
 if isinstance(v,dict):
  if isinstance(v.get('transaction_base64'),str):yield v['transaction_base64']
  for k,c in v.items():
   if k!='transaction_base64':yield from encoded_transactions(c)
 elif isinstance(v,list):
  for c in v:yield from encoded_transactions(c)
def signatures(v):
 count=sigs=0
 for s in encoded_transactions(v):
  b=base64.b64decode(s);tx=VersionedTransaction.from_bytes(b)
  assert bytes(tx)==b and all(tx.verify_with_results());count+=1;sigs+=len(tx.signatures)
 return {'transactions':count,'signatures':sigs}
manifest=read('manifest-sha256.json')
for name in manifest:safe(name)
for name,item in manifest.items():
 b=raw(name);assert item=={'sha256':sha(b),'bytes':len(b)},name
pre=read('prebuild-handoff/manifest-sha256.json')
assert sha(raw('prebuild-handoff/manifest-sha256.json'))=='0ec80f6f5543c00a2add73f241534d29c2e300db5ed651a3abccbeb76e6805b3'
for name,item in pre.items():
 b=raw('prebuild-handoff/'+name);assert item=={'sha256':sha(b),'bytes':len(b)},name
source=read('candidate-source-sha256.json');baseline=read('baseline-source-sha256.json')
assert len(source)==len(baseline)==36 and set(source)==set(baseline)
assert [p for p in source if source[p]!=baseline[p]]==['programs/pump/src/multi_hop_curve.rs']
assert archive_map('source-snapshot.tar.gz')==source
assert archive_map('harness-snapshot.tar.gz')==read('harness-snapshot-sha256.json')
attempt=read('build-attempt.json');build=read('build-comparison.json');actual=build['source_sha256']
assert attempt['returncode']==0 and attempt['source_unchanged']and actual==attempt['source_sha256']==attempt['source_after_sha256']
prefix='work/pump-tokenkeg-two-curve-recovery/source/'
assert all(p.startswith(prefix)for p in actual)
assert {p[len(prefix):]:v for p,v in actual.items()}==source
assert sha(decoded('build.log.gz'))==build['build_log_sha256']
candidate=sha(raw('candidate.so'));original=build['comparison']['original_sha256']
assert candidate==build['comparison']['candidate_sha256']and not build['comparison']['full_byte_equality']
phases=read('toolchain-phases.json')
assert phases['compile']['selected_version']=='v1.44'and phases['strip']['actual_distribution']=='v1.52'
assert sha(raw('unstripped.so'))==phases['compiled_unstripped']['sha256']
assert sha(raw('cargo-rustc-info.json'))==phases['compile']['cargo_rustc_info']['sha256']
assert phases['candidate']['sha256']==candidate
v=read('independent-verification.json');assert v['candidate_sha256']==candidate and v['original_sha256']==original and not v['mismatches']
copy=read('receipt-copy-map.json');bindings=read('receipt-build-bindings.json');assert len(bindings)==65
expected={r['receipt_sha256']:r for r in v['differential_suites']+v['surfpool_suites']};assert len(expected)==65
assert len(v['differential_suites'])==37 and sum(r['case_count']for r in v['differential_suites'])==9217
assert len(v['surfpool_suites'])==28 and sum(r['cases']for r in v['surfpool_suites'])==1024
counts={kind:{'transactions':0,'signatures':0}for kind in ['differential','surfpool','two_curve']}
for b in bindings:
 m=copy[b['receipt']];packet=raw(m['path']);assert sha(packet)==m['packaged_sha256']
 originalbytes=gzip.decompress(packet)if m['transport']=='gzip-original-bytes'else packet
 assert sha(originalbytes)==m['source_sha256']==b['receipt_sha256']
 assert b['actual_compiler_inputs_sha256']==actual and b['build_report_sha256']==manifest['build-comparison.json']['sha256']
 assert b['executed_candidate_sha256']==candidate and b['executed_original_sha256']==original
 data=json.loads(gzip.decompress(originalbytes)if originalbytes.startswith(b'\x1f\x8b')else originalbytes)
 assert not data.get('mismatches',[])and not data.get('failures',[])
 value={'original':data['original'],'candidate':data['candidate']}if b['kind']=='surfpool'else data
 n=signatures(value);assert n==expected[b['receipt_sha256']]['verified']
 if b['kind']=='surfpool':assert data['candidate_sha256']==candidate and data['original_sha256']==original
 for k,z in n.items():counts[b['kind']][k]+=z
focused=read('focused-01.json.gz');accepted=read('prebuild-handoff/original-only-01.json.gz')
assert focused['case_count']==len(focused['cases'])==20 and focused['inputs_unchanged']and focused['candidate_sha256']==candidate
fbind=focused['provenance']['compiled_candidate_binding'];assert fbind['actual_source_sha256']==actual and fbind['report_sha256']==manifest['build-comparison.json']['sha256']
assert fbind['candidate_sha256']==candidate and fbind['attempt_sha256']==manifest['build-attempt.json']['sha256']
assert sha(raw('harness-focused-01.py'))==focused['provenance']['repository_inputs']['work/pump-tokenkeg-two-curve-recovery/ordinary_two_curve.py']
normalize=lambda logs:[x for x in logs if not re.fullmatch(r'Program \S+ consumed \d+ of \d+ compute units',x)]
successes=cpis=0
for a,c in zip(accepted['cases'],focused['cases']):
 assert a['case']==c['case']and a['parameters']==c['parameters']and not c['mismatches']
 for k in ['error','events','inner','return_data','before','after','pump_calls','token_calls']:assert a['original'][k]==c['original'][k]==c['candidate'][k],(c['case'],k)
 assert normalize(c['original']['logs'])==normalize(c['candidate']['logs'])
 assert c['original']['fresh_vm']and c['candidate']['fresh_vm']
 for side,h in [('original',original),('candidate',candidate)]:assert c[side]['program_sha256']['6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P']==h
 successes+=c['original']['error']is None;cpis+=bool(c['original']['pump_calls'])
counts['two_curve']=signatures(focused)
assert counts['two_curve']=={'transactions':40,'signatures':40}and (successes,cpis)==(16,18)
summary=read('summary.json');assert summary['candidate_sha256']==candidate and summary['combined_differential_cases']==9237
assert summary['implemented_handler_count_change']==0 and summary['partial_handler_count_change']==0
print(json.dumps({'status':'PASS','manifest_files':len(manifest),'prebuild_payload_files':len(pre),'source_inputs':36,'candidate_sha256':candidate,'existing_receipt_bindings':65,'new_two_curve_binding':True,'existing_differential_cases':9217,'new_two_curve_cases':20,'combined_differential_cases':9237,'surfpool_comparisons':1024,'verified_signed_receipts':counts,'total_verified_signatures':sum(x['signatures']for x in counts.values()),'full_byte_equality':False},indent=2))
