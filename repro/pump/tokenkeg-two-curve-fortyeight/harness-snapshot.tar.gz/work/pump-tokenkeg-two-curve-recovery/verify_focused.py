"""Read-only saved two-curve receipt verification; no VM or harness import."""
from pathlib import Path
import base64,contextlib,gzip,hashlib,io,json,re,runpy
from solders.transaction import VersionedTransaction
W=Path(__file__).resolve().parent;R=next(p for p in W.parents if(p/'evidence/upstream/pump.json').is_file())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(gzip.decompress(p.read_bytes()))
# Reuse the preserved independent original arithmetic/account/authority check.
with contextlib.redirect_stdout(io.StringIO())as stdout:runpy.run_path(str(W/'verify_original_receipt.py'))
original_validation=json.loads(stdout.getvalue());assert original_validation['status']=='PASS'
a=read(W/'original-only-01.json.gz');d=read(W/'focused-01.json.gz')
assert len(a['cases'])==d['case_count']==len(d['cases'])==20
assert d['mode']=='original-versus-candidate'and d['inputs_unchanged']
prov=d['provenance'];assert sha(W/'harness-focused-01.py')==prov['repository_inputs'][str((W/'ordinary_two_curve.py').relative_to(R))]
for p,h in prov['repository_inputs'].items():assert sha(R/p)==h,p
for p,h in prov['runtime_files'].items():assert sha(Path(p))==h,p
binding=prov['compiled_candidate_binding'];report=R/binding['report'];build=json.loads(report.read_text())
assert sha(report)==binding['report_sha256']
assert binding['candidate_sha256']==d['candidate_sha256']==sha(W/'build-01/artifacts/pump_recovered.so')
assert binding['actual_source_sha256']==build['source_sha256']and len(build['source_sha256'])==36
for p,h in build['source_sha256'].items():assert sha(R/p)==h,p
fields=['error','events','inner','return_data','before','after','pump_calls','token_calls']
norm=lambda logs:[x for x in logs if not re.fullmatch(r'Program \S+ consumed \d+ of \d+ compute units',x)]
count=0;rows=[]
for before,row in zip(a['cases'],d['cases']):
 assert before['case']==row['case']and before['parameters']==row['parameters']
 assert not row['mismatches']
 for k in fields:assert before['original'][k]==row['original'][k]==row['candidate'][k],(row['case'],k)
 assert norm(row['original']['logs'])==norm(row['candidate']['logs']),row['case']
 for side in ['original','candidate']:
  v=row[side];raw=base64.b64decode(v['transaction_base64']);tx=VersionedTransaction.from_bytes(raw)
  assert bytes(tx)==raw and all(tx.verify_with_results())and len(tx.signatures)==1
  assert hashlib.sha256(raw).hexdigest()==v['transaction_sha256']
  assert v['fresh_vm']and v['verified_signature_count']==1;count+=1
  for pid,h in v['program_sha256'].items():
   if pid=='6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P':assert h==(sha(R/'evidence/original/pump/deployed.so')if side=='original'else d['candidate_sha256'])
   else:assert h==before['original']['program_sha256'][pid]
 rows.append({'case':row['case'],'comparison':'PASS','original_acceptance_state_reused_exactly':True,'verified_signatures':2})
assert count==d['verified_outer_signatures']==40
out={'status':'PASS','scope':'Same fixed 20 fixtures, both complete original/candidate receipt projections equal; logs equal after removing only compute consumption lines. Original arithmetic/state/authority verifier also passes. No runtime rerun.','receipt_sha256':sha(W/'focused-01.json.gz'),'candidate_sha256':d['candidate_sha256'],'source_count':36,'runtime_files':len(prov['runtime_files']),'cases':20,'verified_signatures':40,'successes':16,'genuine_pump_cpi_cases_per_side':18,'caller_rejections_per_side':2,'post_pump_slippage_rollbacks_per_side':2,'rows':rows}
print(json.dumps(out,indent=2))
