#!/usr/bin/env python3
"""Read existing signed receipts; no VM, program execution or candidate claim."""
from pathlib import Path
import base64,gzip,hashlib,json,struct,sys
sys.dont_write_bytecode=True
from solders.pubkey import Pubkey
from solders.transaction import VersionedTransaction
W=Path(__file__).resolve().parent;R=next(p for p in W.parents if(p/'evidence/upstream/pump.json').is_file())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
IDL=json.loads((R/'evidence/upstream/pump.json').read_text());types={t['name']:t['type']for t in IDL['types']}
def read_type(t,b,at):
 if t=='pubkey':return str(Pubkey(b[at:at+32])),at+32
 if isinstance(t,str)and t in ['u8','u16','u32','u64','i64','u128','bool']:
  n={'u8':1,'u16':2,'u32':4,'u64':8,'i64':8,'u128':16,'bool':1}[t];v=int.from_bytes(b[at:at+n],'little',signed=t=='i64');return bool(v)if t=='bool'else v,at+n
 if t=='string':n=int.from_bytes(b[at:at+4],'little');return b[at+4:at+4+n].decode(),at+4+n
 if 'vec'in t or'array'in t:
  if'vec'in t:n=int.from_bytes(b[at:at+4],'little');at+=4;inner=t['vec']
  else:inner,n=t['array']
  out=[]
  for _ in range(n):v,at=read_type(inner,b,at);out.append(v)
  return out,at
 if'defined'in t:
  out={}
  for f in types[t['defined']['name']]['fields']:out[f['name']],at=read_type(f['type'],b,at)
  return out,at
 raise ValueError(t)
def decode(name,b):return read_type({'defined':{'name':name}},b,8)
def blob(snapshot,key):return bytes.fromhex(snapshot[str(key)]['data_hex'])
def amount(snapshot,key):return struct.unpack_from('<Q',blob(snapshot,key),64)[0]
def fee_config(b):
 at=41;flat,at=read_type({'defined':{'name':'Fees'}},b,at);tiers,at=read_type({'vec':{'defined':{'name':'FeeTier'}}},b,at)
 if len(b)>=4073:_,at=read_type({'vec':{'defined':{'name':'FeeTier'}}},b,at)
 exotic={'lp_fee_bps':0,'protocol_fee_bps':0,'creator_fee_bps':0}
 if len(b)>=4097:exotic,at=read_type({'defined':{'name':'Fees'}},b,at)
 return flat,tiers,exotic
def assert_field(actual,name,expected,case):assert actual[name]==expected,(case,name,actual[name],expected)
packet=json.loads(gzip.decompress((W/'original-only-01.json.gz').read_bytes()));assert packet['mode'].startswith('original-only')and packet['candidate_sha256']is None
prov=packet['provenance'];assert sha(W/'harness-original-01.py')==prov['repository_inputs']['work/pump-tokenkeg-two-curve-recovery/ordinary_two_curve.py']
for rel,digest in prov['repository_inputs'].items():
 if not rel.endswith('ordinary_two_curve.py'):assert sha(R/rel)==digest,rel
for path,digest in prov['runtime_files'].items():assert sha(path)==digest,path
template=json.loads((W/'base-fixture.json').read_text());fixed=template['selected_outer_account_keys']
PUMP=Pubkey.from_string('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P');AMM=Pubkey.from_string('pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA');TOKEN=Pubkey.from_string('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');TOKEN22=Pubkey.from_string('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');ATA=Pubkey.from_string('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');WSOL=Pubkey.from_string('So11111111111111111111111111111111111111112')
A=Pubkey.from_string(fixed[16]);C_A=Pubkey.from_string(fixed[18]);B=Pubkey.from_bytes(bytes([84])*32);C_B=Pubkey.find_program_address([b'bonding-curve',bytes(B)],PUMP)[0];USER=Pubkey.from_string(fixed[0])
ata=lambda c,m:Pubkey.find_program_address([bytes(c),bytes(TOKEN),bytes(m)],ATA)[0]
VA=ata(C_A,A);VQA=ata(C_A,WSOL);VB=ata(C_B,B);VQB=ata(C_B,A);UB=ata(USER,B)
rows=[];signatures=0;successes=0;pump_cases=0
for row in packet['cases']:
 name=row['case'];p=row['parameters'];v=row['original'];assert row['candidate']is None and row['mismatches']is None
 tx=VersionedTransaction.from_bytes(base64.b64decode(v['transaction_base64']));assert all(tx.verify_with_results())and len(tx.signatures)==1;signatures+=1
 assert tx.message.header.num_required_signatures==1 and tx.message.account_keys[0]==USER
 outer=tx.message.instructions[0];assert tx.message.account_keys[outer.program_id_index]==AMM and len(outer.accounts)==26
 for group in v['inner']:
  for i in group:assert tx.message.account_keys[i['instruction']['programIdIndex']]!=TOKEN22
 before=v['before'];after=v['after'];sell=p['sell'];expected_flags=[2,1]if sell else[1,2]
 if p['amount']==0:
  assert '6002'in v['error']and not v['pump_calls'];assert not v['events']
 else:
  pump_cases+=1;assert len(v['pump_calls'])==1
  call=v['pump_calls'][0];assert call['flags']==expected_flags and len(call['accounts'])==23
  assert call['accounts'][2]==str(Pubkey.find_program_address([b'global_config'],AMM)[0])
  assert len(v['events'])==2
  events=[]
  for log in v['events']:
   raw=base64.b64decode(log.split()[-1]);event,at=decode('TradeEvent',raw);assert raw[at:]==bytes(8);events.append(event)
  global_state,_=decode('Global',blob(before,fixed[13]));flat,tiers,exotic=fee_config(blob(before,fixed[14]));current=p['amount'];buyback_sum=0;calculated=[]
  for idx,(mint,curve,native)in enumerate([(B,C_B,False),(A,C_A,True)]if sell else[(A,C_A,True),(B,C_B,False)]):
   state,_=decode('BondingCurve',blob(before,curve));ev=events[idx]
   if native:
    supply=struct.unpack_from('<Q',blob(before,mint),36)[0];cap=supply*state['virtual_quote_reserves']//state['virtual_token_reserves']
    rates=next((t['fees']for t in reversed(tiers)if t['market_cap_lamports_threshold']<=cap),tiers[0]['fees']).copy()
   else:rates=(exotic if any(exotic.values())else flat).copy()
   if global_state['creator_fee_configurable']and state['creator_fee_bps']:rates['creator_fee_bps']=state['creator_fee_bps']
   pb=rates['protocol_fee_bps']if expected_flags[idx]&1 else 0;cb=rates['creator_fee_bps']if expected_flags[idx]&2 else 0
   effective_cb=cb if state['creator']!=str(Pubkey.default())else 0
   ceil=lambda q,b:(q*b+9999)//10000
   if sell:q=current*state['virtual_quote_reserves']//(state['virtual_token_reserves']+current);base=current;pf=ceil(q,pb);cf=ceil(q,effective_cb);out=q-pf-cf
   else:
    estimate=current*10000//(10000+pb+effective_cb);pf=ceil(estimate,pb);cf=ceil(estimate,effective_cb);q=current-pf-cf;base=state['virtual_token_reserves']*(q-1)//(state['virtual_quote_reserves']+q-1);out=base
    assert 0<base<state['real_token_reserves']
   bb=pf*global_state['buyback_basis_points']//10000;buyback_sum+=bb
   vb=state['virtual_token_reserves']+(base if sell else-base);vq=state['virtual_quote_reserves']+(-q if sell else q);rb=state['real_token_reserves']+(base if sell else-base);rq=state['real_quote_reserves']+(-q if sell else q)
   values={'mint':str(mint),'is_buy':not sell,'sol_amount':q if native else 0,'quote_amount':q,'token_amount':base,'fee_basis_points':pb,'creator_fee_basis_points':cb,'fee':pf,'creator_fee':cf,'buyback_fee':bb,'virtual_token_reserves':vb,'virtual_sol_reserves':vq if native else 0,'real_token_reserves':rb,'real_sol_reserves':rq if native else 0,'virtual_quote_reserves':vq,'real_quote_reserves':rq,'creator_fee_unclaimed':state['creator_fee']+cf,'quote_mint':state['quote_mint']}
   for field,value in values.items():assert_field(ev,field,value,name)
   if v['error']is None:
    post,_=decode('BondingCurve',blob(after,curve));expected=state.copy();expected.update(virtual_token_reserves=vb,virtual_quote_reserves=vq,real_token_reserves=rb,real_quote_reserves=rq,creator_fee=state['creator_fee']+cf,protocol_fees=state['protocol_fees']+pf-bb);assert post==expected,(name,'curve state')
   calculated.append({'mint':str(mint),'amount_in':current,'amount_out':out,'protocol_fee':pf,'creator_fee':cf,'buyback':bb});current=out
  transfers=[t for t in v['token_calls']if bytes.fromhex(t['data_hex'])[0]==12];assert len(transfers)==2
  expected_accounts=[[str(UB),str(B),str(VB),str(USER)],[str(VQB),str(A),str(VA),str(C_B)]]if sell else[[str(VA),str(A),str(VQB),str(C_A)],[str(VB),str(B),str(UB),str(C_B)]]
  expected_amounts=[p['amount'],calculated[0]['amount_out']]if sell else[calculated[0]['amount_out'],current]
  for t,accounts,n in zip(transfers,expected_accounts,expected_amounts):assert t['accounts']==accounts and struct.unpack_from('<Q',bytes.fromhex(t['data_hex']),1)[0]==n,(name,'token transfer')
  if v['error']is None:
   successes+=1
   for key,delta in [(UB,-p['amount']if sell else current),(VB,p['amount']if sell else-current),(VQB,-calculated[0]['amount_out']if sell else calculated[0]['amount_out']),(VA,calculated[0]['amount_out']if sell else-calculated[0]['amount_out'])]:assert amount(after,key)==amount(before,key)+delta,(name,'token balance',str(key))
   assert after[str(C_B)]['lamports']==before[str(C_B)]['lamports']
   assert after[str(C_A)]['lamports']==before[str(C_A)]['lamports']+(-current-buyback_sum if sell else p['amount']-buyback_sum)
   assert after[str(USER)]['lamports']==before[str(USER)]['lamports']+(current if sell else-p['amount'])-5000
  else:assert '6004'in v['error']and p['limit']==2**64-1
  rows.append({'case':name,'calculated_hops':calculated,'genuine_pump_cpi':True,'previous_curve_token_authority_verified':True,'native_event_fields_zero_on_nested_quote':True,'success':v['error']is None})
 if v['error']is not None:
  for key,b in before.items():
   if key==str(USER):assert after[key]['lamports']==b['lamports']-5000 and after[key]['data_hex']==b['data_hex']
   else:assert after.get(key)==b,(name,'rollback',key)
assert len(packet['cases'])==20 and signatures==20 and successes==16 and pump_cases==18
print(json.dumps({'status':'PASS','scope':'Saved original-only receipts; arithmetic/source-intent checks do not establish candidate parity','receipt_sha256':sha(W/'original-only-01.json.gz'),'verified_signatures':signatures,'cases':20,'original_successes':successes,'genuine_pump_cpi_cases':pump_cases,'caller_zero_input_rejections':2,'post_pump_slippage_rollbacks':2,'runtime_files_bound':len(prov['runtime_files']),'rows':rows},indent=2))
