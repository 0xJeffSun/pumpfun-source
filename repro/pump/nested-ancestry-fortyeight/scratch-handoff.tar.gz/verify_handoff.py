#!/usr/bin/env python3
"""Verify a sealed saved correction package; no builds, VM, signing or network."""
from pathlib import Path,PurePosixPath
import argparse,base64,gzip,hashlib,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
from solders.transaction import VersionedTransaction
H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):
    p=PurePosixPath(n);assert not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json')
    f=H/p;assert not f.is_symlink();return f.read_bytes()
def obj(n):
    b=raw(n);return json.loads(gzip.decompress(b)if b.startswith(b'\x1f\x8b')else b)
def tar_map(n):
    rows={}
    with tarfile.open(H/n)as t:
        for m in t.getmembers():
            p=PurePosixPath(m.name);assert m.isfile()and not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json')and m.name not in rows
            rows[m.name]=sha(t.extractfile(m).read())
    return rows
def transactions(v):
    if isinstance(v,dict):
        if isinstance(v.get('transaction_base64'),str):yield v['transaction_base64']
        for k,x in v.items():
            if k!='transaction_base64':yield from transactions(x)
    elif isinstance(v,list):
        for x in v:yield from transactions(x)
def signatures(v):
    count=sigs=0
    for enc in transactions(v):
        b=base64.b64decode(enc);tx=VersionedTransaction.from_bytes(b);assert bytes(tx)==b and all(tx.verify_with_results());count+=1;sigs+=len(tx.signatures)
    return {'transactions':count,'signatures':sigs}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--current-source',type=Path);a=ap.parse_args()
    manifest=obj('manifest-sha256.json');actual=set()
    for f in H.rglob('*'):
        assert not f.is_symlink()
        if f.is_file()and f!=H/'manifest-sha256.json':actual.add(f.relative_to(H).as_posix())
    assert actual==set(manifest)
    for n,v in manifest.items():b=raw(n);assert v=={'sha256':sha(b),'bytes':len(b)},n
    pre=H/'prebuild/depth-guard-review';assert sha((pre/'manifest-sha256.json').read_bytes())=='ffd77e400306d23ad84a73f0c1b82af6bcfbfeb053c85a09aa171380933ba410'
    proc=subprocess.run([sys.executable,'-B',str(pre/'verify.py')],cwd='/',capture_output=True,text=True);assert proc.returncode==0,proc.stderr
    negative=json.loads(proc.stdout);assert negative['preserved_runtime']['focused_differential_result']=='FAIL_PRESERVED'
    source=obj('source-sha256.json');assert len(source)==37 and tar_map('source-snapshot.tar.gz')==source
    assert source==obj('prebuild/depth-guard-review/proposed-source-map.json')
    build=obj('build-comparison.json');attempt=obj('build-attempt.json');actualsource=build['source_sha256']
    assert attempt['returncode']==0 and attempt['source_unchanged']and actualsource==attempt['source_sha256']==attempt['source_after_sha256']
    assert {k[k.index('programs/pump/'):]:h for k,h in actualsource.items()}==source
    assert sha(raw('build.log'))==build['build_log_sha256']
    candidate=sha(raw('candidate.so'));original=sha(raw('evidence/original/pump/deployed.so'))
    assert candidate==build['comparison']['candidate_sha256']and original==build['comparison']['original_sha256']and not build['comparison']['full_byte_equality']
    phases=obj('toolchain-phases.json');assert phases['candidate']['sha256']==candidate and phases['compiled_unstripped']['sha256']==sha(raw('unstripped.so'))
    assert phases['compile']['selected_version']=='v1.44'and phases['compile']['tools']['bin/rustc']['sha256']=='1f26338cc2cabd0a6057dcbd0528bba262b23ca1296d357a55304ee31d1d9e5a'
    assert phases['strip']['tool']['sha256']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
    assert obj('tools-before.json')==obj('tools-after.json')
    inputs=obj('inputs-before.json');assert tar_map('harness-snapshot.tar.gz')==inputs['harness_sha256']
    assert tar_map('fixture-snapshot.tar.gz')==inputs['repository_fixture_snapshot_sha256']
    assert tar_map('baseline-source-snapshot.tar.gz')==inputs['baseline_main_source']
    em=obj('execution-harness-manifest.json')
    for n,h in em.items():assert sha(raw('execution-harness/'+n))==h
    old=H/'prebuild/depth-guard-review/retained-focused-01/execution-harness-v2'
    assert [n for n in em if raw('execution-harness/'+n)!=(old/n).read_bytes()]==['expected-source-map.json']
    assert obj('execution-harness/expected-source-map.json')==source
    before=raw('two-curve-predecessor/pump_tokenkeg_two_curve_differential.py').decode();after=raw('two-curve-harness/pump_tokenkeg_two_curve_differential.py').decode()
    assert after==before.replace("assert len(report['source_sha256'])==36","assert len(report['source_sha256'])==37")
    assert before!=after and before.count("assert len(report['source_sha256'])==36")==1
    v=obj('independent-verification.json');assert v['candidate_sha256']==candidate and not v['mismatches']
    assert len(v['differential_suites'])==38 and sum(x['case_count']for x in v['differential_suites'])==9237
    assert len(v['surfpool_suites'])==28 and sum(x['cases']for x in v['surfpool_suites'])==1024
    mapping=obj('receipt-copy-map.json');bindings=obj('receipt-build-bindings.json');assert len(bindings)==66
    expected={x['receipt_sha256']:x for x in v['differential_suites']+v['surfpool_suites']};assert len(expected)==66
    totals={k:{'transactions':0,'signatures':0}for k in ['differential','surfpool']}
    receipts={}
    for b in bindings:
        m=mapping[b['receipt']];payload=raw(m['path']);assert sha(payload)==m['packaged_sha256']
        data_bytes=gzip.decompress(payload)if m['transport']=='gzip-original-bytes'else payload
        assert sha(data_bytes)==m['source_sha256']==b['receipt_sha256']
        data=json.loads(gzip.decompress(data_bytes)if data_bytes.startswith(b'\x1f\x8b')else data_bytes)
        assert b['actual_compiler_inputs_sha256']==actualsource and b['build_report_sha256']==sha(raw('build-comparison.json'))
        assert b['executed_candidate_sha256']==candidate and b['executed_original_sha256']==original
        assert not data.get('mismatches',[])and not data.get('failures',[])
        assert not data.get('unexpected_original_errors',[])and not data.get('unexpected_errors',[])
        if isinstance(data.get('cases'),list):
            for row in data['cases']:
                if isinstance(row,dict):assert not row.get('mismatches',[])and not row.get('failures',[])
        count=signatures({'original':data['original'],'candidate':data['candidate']}if b['kind']=='surfpool'else data)
        assert count==expected[b['receipt_sha256']]['verified']
        for k,z in count.items():totals[b['kind']][k]+=z
        receipts[expected[b['receipt_sha256']]['suite']]=data
    qc=receipts['quote_control']['bound_inputs_sha256']
    for n,h in actualsource.items():assert qc[n]==h
    assert qc['work/pump-nested-correction-build/build-02/build-comparison.json']==sha(raw('build-comparison.json'))
    partial=receipts['multi_hop_curve_partial'];assert partial['case_count']==partial['passed']==56
    for row in partial['cases']:
        assert not row['mismatches']
        for k in ['error','events','inner','return_data','before','after']:assert row['original'][k]==row['candidate'][k]
    two=receipts['tokenkeg_two_curve'];assert two['provenance']['compiled_candidate_binding']['actual_source_sha256']==actualsource
    prior=obj('historical-two-curve-original.json.gz');norm=lambda logs:[x for x in logs if not re.fullmatch(r'Program \S+ consumed \d+ of \d+ compute units',x)]
    for old,row in zip(prior['cases'],two['cases']):
        assert old['case']==row['case']and old['parameters']==row['parameters']and not row['mismatches']
        for k in ['error','events','inner','return_data','before','after','pump_calls','token_calls']:assert old['original'][k]==row['original'][k]==row['candidate'][k]
        assert norm(row['original']['logs'])==norm(row['candidate']['logs'])
    focused=obj('focused-01.json.gz');fb=focused['provenance']['compiled_candidate_binding'];assert focused['candidate_sha256']==candidate and fb['actual_source_sha256']==actualsource
    assert fb['report_sha256']==sha(raw('build-comparison.json'))and fb['attempt_sha256']==sha(raw('build-attempt.json'))
    from verify_nested_portable import run as nested
    from verify_static_portable import run as static
    nv=nested();sv=static()
    if a.current_source:
        for n,h in inputs['baseline_main_source'].items():assert sha((a.current_source/n).read_bytes())==h,n
        for n,h in actualsource.items():assert sha((a.current_source/n).read_bytes())==h,n
        for group in ['harness_sha256','repository_fixture_snapshot_sha256']:
            for n,h in inputs[group].items():assert sha((a.current_source/n).read_bytes())==h,n
    print(json.dumps({'status':'PASS','payloads':len(manifest),'source_inputs':37,'candidate_sha256':candidate,'existing_cases':9237,'new_unique_nested_cases':16,'combined_differential_cases':9253,'surfpool_cases':1024,'existing_receipt_bindings':66,'fresh_nested_binding':True,'signature_counts':totals,'nested_saved':nv,'preserved_negative_signatures':96,'static':sv,'current_source_rebound':bool(a.current_source),'new_builds':0,'new_transactions':0},indent=2))
if __name__=='__main__':main()
