"""Verify the exact16 approved saved cases without importing any VM/fixture runner."""
from pathlib import Path
import ast,base64,gzip,hashlib,importlib.util,json,sys,types
sys.dont_write_bytecode=True
from solders.pubkey import Pubkey
from solders.transaction import Transaction
H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def run():
    f=H/'execution-harness';s=importlib.util.spec_from_file_location('saved_nested_common',f/'proposed/proposal_common.py');common=importlib.util.module_from_spec(s);s.loader.exec_module(common)
    ids=json.loads((H/'prebuild/depth-guard-review/saved-identities.json').read_text());idl=json.loads((H/'evidence/upstream/pump.json').read_text());h=types.SimpleNamespace(Pubkey=Pubkey,IDL=idl)
    for k,v in ids['public_keys'].items():
        key=Pubkey.from_string(v);setattr(h,k,types.SimpleNamespace(pubkey=lambda key=key:key)if k in ['USER','MINT','OTHER']else key)
    ns={'h':h,'struct':__import__('struct'),'event_bytes':common.event_bytes,'decode_event':common.decode_event,'ata':lambda a,m:Pubkey.find_program_address([bytes(a),bytes(h.TOKEN),bytes(m)],h.ATA)[0]}
    tree=ast.parse((f/'proposed/pump_nested_general_differential.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='assertions');exec(compile(ast.Module(body=[fn],type_ignores=[]),'<unchanged saved assertions>','exec'),ns)
    expected=json.loads((f/'cases.json').read_text())['cases'];total=0;rows={}
    for name in ['original-acceptance-01','focused-01']:
        j=json.loads(gzip.decompress((H/(name+'.json.gz')).read_bytes()));assert j['complete']and j['inputs_unchanged']and not j['failures']
        assert j['case_count']==j['new_unique_cases']==len(j['cases'])==16 and j['baseline_repeats_in_this_runner']==0
        count=0
        for case,row in zip(expected,j['cases']):
            assert row['case']==case and not row['mismatches']and not row['original_assertion_failures']and not row['candidate_assertion_failures']
            for side in ['original','candidate']:
                v=row[side]
                if v is None:assert name=='original-acceptance-01'and side=='candidate';continue
                assert not ns['assertions'](case,v,row['layout']);assert v['fresh_vm']and v['verified_signature_count']==2
                raw=base64.b64decode(v['transaction_base64']);tx=Transaction.from_bytes(raw);assert len(raw)<=1232 and len(tx.signatures)==2 and all(tx.verify_with_results())
                assert set(map(str,tx.message.account_keys[:2]))=={ids['public_keys']['USER'],ids['public_keys']['MINT']}
                assert sha(raw)==v['transaction_sha256'];count+=2
                journal=json.loads((H/(name+'.json.gz.case-journal')/(case['id']+'-'+side+'.json')).read_text());assert journal['stage']=='complete'and journal['result']==v and journal['fixture']==row['fixture']
            if row['candidate']:
                assert row['original']['transaction_base64']==row['candidate']['transaction_base64']
                for k in ['before','after','error','events','inner','return']:assert row['original'][k]==row['candidate'][k]
                assert common.logs_for_comparison(row['original']['logs'])==common.logs_for_comparison(row['candidate']['logs'])
                if case['id']=='depth-limit-rollback':
                    for side in ['original','candidate']:
                        assert row[side]['logs'].count('Program log: Left: 1')==row[side]['logs'].count('Program log: Right: 2')==1
        assert count==j['verified_signatures']==(32 if name=='original-acceptance-01'else 64);rows[name]=count;total+=count
    assert total==96
    return {'unique_cases':16,'original_acceptance_signatures':32,'focused_signatures':64,'focused_successes':15,'focused_expected_depth_rejections':1,'complete_journals':48}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
