"""Package named build/runtime evidence; never traverse a compiler target or read generated keys."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
W=Path(__file__).resolve().parent;R=next(p for p in W.parents if(p/'evidence/upstream/pump.json').is_file());H=W/'handoff'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,b):p=H/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def copy(src,n):assert not src.name.endswith('-keypair.json');put(n,src.read_bytes())
def obj(n,j):put(n,(json.dumps(j,indent=2,sort_keys=True)+'\n').encode())
def archive(n,rows,base=R):
    buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w')as t:
        for path,digest in sorted(rows.items()):
            assert not Path(path).is_absolute()and '..'not in Path(path).parts and not Path(path).name.endswith('-keypair.json')
            data=(base/path).read_bytes();assert sha(data)==digest;info=tarfile.TarInfo(path);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
    put(n,gzip.compress(buf.getvalue(),mtime=0))
assert not H.exists();H.mkdir()
v=json.loads((W/'independent-verification.json').read_text());assert v['differential_case_count']==9237 and v['surfpool_comparisons']==1024 and not v['mismatches']
shutil.copytree(W/'prebuild/depth-guard-review',H/'prebuild/depth-guard-review')
shutil.copytree(R/'work/pump-nested-source-build/attempt-01-preserved',H/'prebuild/initial-packet-failure')
for name in ['candidate.so','unstripped.so','source-sha256.json','tools-before.json','tools-after.json','toolchain-phases.json','dependency-integrity.json','dependency-integrity.log','baseline.json','authorization.json','inputs-before.json','execution-harness-manifest.json','execution-source-map.patch','two-curve-provenance-37.patch','two-curve-provenance-map.json','function-match.json','depth-guard-match.json','fresh-walk.asm','serializer-verification.log','serializer-check.log','receipt-verification.log','independent-verification.json','receipt-build-bindings.json','surfpool-executable-sha256.json','historical-two-curve-witness.json','elf_reader.py','verify_handoff.py','verify_static_portable.py','verify_nested_portable.py']:
    copy(W/name,name)
for name in ['build-attempt.json','build-comparison.json','build.log']:copy(W/'build-02'/name,name)
copy(W/'build-02/target/.rustc_info.json','cargo-rustc-info.json')
copy(R/'evidence/original/pump/deployed.so','evidence/original/pump/deployed.so');copy(R/'evidence/upstream/pump.json','evidence/upstream/pump.json')
for directory in ['execution-harness','two-curve-harness','two-curve-predecessor','build-helper-snapshot']:
    for f in (W/directory).rglob('*'):
        if f.is_file():copy(f,str(f.relative_to(W)))
for name in ['original-acceptance-01','focused-01']:
    for suffix in ['.json.gz','.log','.json.gz.partial.json.gz']:copy(W/(name+suffix),name+suffix)
    for f in (W/(name+'.json.gz.case-journal')).glob('*.json'):copy(f,str(f.relative_to(W)))
for name in ['record_phases.py','check_dependencies.py','match-serializer.py','match-depth-guard.py','run_regressions.py','run_surfpool.py','verify_receipts.py','package_handoff.py']:copy(W/name,'evidence-tools/'+name)
for f in ['regression-invocation.log','surfpool-invocation.log','build-invocation.log']:copy(W/f,'logs/'+f)
for d in ['differential','surfpool']:
    copy(W/d/'run.json',d+'-run.json')
    for f in (W/d).glob('*.log'):put('logs/'+d+'/'+f.name+'.gz',gzip.compress(f.read_bytes(),mtime=0))
copy(W/'differential/summary.json','differential-summary.json')
inputs=json.loads((W/'inputs-before.json').read_text());source=json.loads((W/'source-sha256.json').read_text())
archive('source-snapshot.tar.gz',source,W/'source');archive('harness-snapshot.tar.gz',inputs['harness_sha256']);archive('fixture-snapshot.tar.gz',inputs['repository_fixture_snapshot_sha256']);archive('baseline-source-snapshot.tar.gz',inputs['baseline_main_source'])
bindings=json.loads((W/'receipt-build-bindings.json').read_text());mapping={}
for i,b in enumerate(bindings):
    path=R/b['receipt'];data=path.read_bytes();assert sha(data)==b['receipt_sha256'];name=f'receipts/{i:02d}-{b["kind"]}-{path.name}'
    if data.startswith(b'\x1f\x8b'):payload=data;transport='original-bytes'
    else:payload=gzip.compress(data,mtime=0);transport='gzip-original-bytes';name+='.gz'
    put(name,payload);mapping[b['receipt']]={'path':name,'source_sha256':sha(data),'packaged_sha256':sha(payload),'transport':transport}
obj('receipt-copy-map.json',mapping)
copy(R/'work/pump-tokenkeg-two-curve-recovery/original-only-01.json.gz','historical-two-curve-original.json.gz')
f=json.loads(gzip.decompress((W/'focused-01.json.gz').read_bytes()));accept=json.loads(gzip.decompress((W/'original-acceptance-01.json.gz').read_bytes()));assert f['provenance']['runtime_files']==accept['provenance']['runtime_files']
runtime=f['provenance']['runtime_files']
for path,h in runtime.items():assert sha(Path(path).read_bytes())==h,path
obj('runtime-identities.json',{'python_solders_actual_loaded_files':runtime,'surfpool':{'path':inputs['surfpool_path'],'sha256':inputs['surfpool_sha256'],'bytes':(R/inputs['surfpool_path']).stat().st_size},'role':'Historical run-time identities; portable saved-evidence verification does not require the original local executables or load either program.'})
obj('summary.json',{'candidate_sha256':v['candidate_sha256'],'original_sha256':v['original_sha256'],'source_inputs':37,'fully_bounded_handlers':48,'partial_instruction_paths':5,'handler_count_change':0,'existing_differential_cases':9237,'new_unique_nested_cases':16,'combined_differential_cases':9253,'surfpool_comparisons':1024,'existing_differential_signatures':sum(x['verified']['signatures']for x in v['differential_suites']),'surfpool_signatures':v['surfpool_verified_signatures'],'nested_paired_signatures':64,'repeated_original_acceptance_signatures':32,'preserved_previous_negative_signatures':96,'accepted_comparison_signatures':sum(x['verified']['signatures']for x in v['differential_suites'])+v['surfpool_verified_signatures']+64,'full_original_byte_equality':False,'audit_complete':False,'main_modified':False})
print(json.dumps({'prepared':str(H.relative_to(R)),'receipt_bindings':len(bindings),'candidate':v['candidate_sha256']}))
