"""Negative/copy checks of saved evidence only; no target code execution."""
from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,sys,tempfile
W=Path(__file__).resolve().parent;H=W/'handoff';sha=lambda b:hashlib.sha256(b).hexdigest()
def seal(p):
    m={}
    for f in sorted(p.rglob('*')):
        if f.is_file()and f!=p/'manifest-sha256.json':
            assert not f.name.endswith('-keypair.json');b=f.read_bytes();m[f.relative_to(p).as_posix()]={'sha256':sha(b),'bytes':len(b)}
    (p/'manifest-sha256.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
def run(p):
    r=subprocess.run([sys.executable,'-B',str(p/'verify_handoff.py')],cwd='/',capture_output=True,text=True)
    return {'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
rows=[]
with tempfile.TemporaryDirectory(prefix='nested-correction-handoff-')as t:
    base=Path(t)
    p=base/'copied';shutil.copytree(H,p);r=run(p);assert r['returncode']==0,r;rows.append({'test':'copied outside repository, cwd root, no current-source','expected':'PASS',**r})
    p=base/'missing';shutil.copytree(H,p);(p/'unstripped.so').unlink();r=run(p);assert r['returncode']!=0 and 'actual==set(manifest)'in r['stderr'];rows.append({'test':'missing saved symbol ELF, without reading/modifying executable bytes','expected':'FAIL manifest set',**r})
    p=base/'wrong-source-map';shutil.copytree(H,p);f=p/'execution-harness/expected-source-map.json';j=json.loads(f.read_text());j['programs/pump/src/nested_create.rs']='3fcd0e75bd67fdc52784df17a4cf8ee2d532498faea41d2a428f294dfa099d0c';f.write_text(json.dumps(j,indent=2)+'\n');m=p/'execution-harness-manifest.json';jj=json.loads(m.read_text());jj['expected-source-map.json']=sha(f.read_bytes());m.write_text(json.dumps(jj,indent=2)+'\n');seal(p);r=run(p);assert r['returncode']!=0 and "expected-source-map.json')==source"in r['stderr'];rows.append({'test':'resealed execution map points to failed source while build stays corrected','expected':'FAIL actual source gate',**r})
    p=base/'missing-diagnostic';shutil.copytree(H,p);f=p/'focused-01.json.gz';j=json.loads(gzip.decompress(f.read_bytes()));row=j['cases'][-1];row['candidate']['logs'].remove('Program log: Right: 2');f.write_bytes(gzip.compress(json.dumps(j).encode(),mtime=0));journal=p/'focused-01.json.gz.case-journal/depth-limit-rollback-candidate.json';jj=json.loads(journal.read_text());jj['result']=row['candidate'];journal.write_text(json.dumps(jj)+'\n');seal(p);r=run(p);assert r['returncode']!=0 and 'verify_nested_portable.py'in r['stderr'];rows.append({'test':'resealed aggregate and journal omit candidate Right diagnostic, signatures untouched','expected':'FAIL saved semantic parity',**r})
result={'status':'PASS','scope':'Saved evidence/copy checks only, no new builds or transactions; no executable bytes modified.','checks':rows}
(H/'portability-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS','checks':len(rows)}))
