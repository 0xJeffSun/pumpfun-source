"""Static proposal integrity only: no proposed module import or runtime execution."""
from pathlib import Path
import argparse,ast,difflib,gzip,hashlib,json
W=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads((W/p).read_text())
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path);a=p.parse_args()
def safe(rel):
 p=Path(rel);assert not p.is_absolute()and '..'not in p.parts and not p.name.endswith('-keypair.json');q=W/p;assert not q.is_symlink()and q.resolve().is_relative_to(W);return q
sealed=False
if(W/'manifest.json').exists():
 m=read('manifest.json');actual=set()
 for f in W.rglob('*'):
  assert not f.is_symlink()and not f.name.endswith('-keypair.json')
  if f.is_file()and f!=W/'manifest.json':actual.add(str(f.relative_to(W)))
 assert actual==set(m['files'])
 for rel,row in m['files'].items():b=safe(rel).read_bytes();assert sha(b)==row['sha256']and len(b)==row['bytes'],rel
 sealed=True
inputs=read('input-manifest.json')
for rel,row in inputs.items():b=safe(row['copy']).read_bytes();assert sha(b)==row['sha256']and len(b)==row['bytes'],rel
old=safe('inputs/scripts/pump_create_nested_fixture.py').read_text();new=safe('proposed/pump_create_nested_fixture.py').read_text()
assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/scripts/pump_create_nested_fixture.py',tofile='b/scripts/pump_create_nested_fixture.py'))==safe('fixture.patch').read_text()
for f in (W/'proposed').glob('*.py'):ast.parse(f.read_text(),filename=f.name)
base=read('baseline-source-map.json');expected=read('expected-source-map.json');assert len(base)==36 and len(expected)==37
assert [p for p in base if base[p]!=expected[p]]==['programs/pump/src/create_v2.rs']
assert set(expected)-set(base)=={'programs/pump/src/nested_create.rs'}
for p in ['programs/pump/src/create_v2.rs','programs/pump/src/nested_create.rs']:
 rel='repro/parallel-work/2026-10-25/source-hypothesis-results/pump_nested_source_hypothesis/proposed/'+p;assert expected[p]==inputs[rel]['sha256']
cases=read('cases.json')['cases'];assert len(cases)==16 and len({c['id']for c in cases})==16 and all(c['unique_new_case']for c in cases)
assert sum(c['expected']=='success'for c in cases)==15 and sum(c['expected']=='error-6105'for c in cases)==1
assert set(c['depth']for c in cases)=={1,2,3,4,5}
for c in cases:assert all(0<=i<c['depth']for i in c['pool_positions'])and len(set(c['pool_positions']))==len(c['pool_positions'])
baseline=json.loads(gzip.decompress(safe('inputs/repro/pump/tokenkeg-two-curve-fortyeight/differential/nested_create.json.gz').read_bytes()));assert baseline['case_count']==48 and len(baseline['cases'])==48 and not baseline['mismatches']
if a.repo:
 root=a.repo.resolve()
 for rel,row in inputs.items():
  if rel.startswith('work/'):continue
  assert sha((root/rel).read_bytes())==row['sha256'],rel
 for rel,row in read('runtime-input-identities.json').items():assert sha((root/rel).read_bytes())==row['sha256'],rel
print(json.dumps({'status':'PASS','sealed':sealed,'source_inputs':37,'proposed_python_files':4,'copied_inputs':len(inputs),'prospective_unique_cases':16,'existing_nested_baseline_repeats':48,'new_cases_executed':0,'proposed_harness_imported':False,'candidate_equivalence_claim':False,'current_repository_verified':bool(a.repo)},indent=2))
