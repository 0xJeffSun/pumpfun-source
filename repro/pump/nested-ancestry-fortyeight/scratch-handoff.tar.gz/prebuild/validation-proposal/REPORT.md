# Ordinary nested-create validation proposal

This is a **draft harness and 16 prospective cases**, not runtime evidence. No proposed harness was imported, no fixture builder was invoked, and no transaction, signature, VM or network call was created by preparation or verification. Python syntax was checked with `ast.parse` only. The parent separately authorized and completed the exact nested-only source build; its existence does not establish these cases pass. Main source and prior packages are untouched.

The source under test is the published `f0c80ca` nested hypothesis: only `create_v2.rs` changes and `nested_create.rs` is added. `expected-source-map.json` binds the 37 resulting compiler inputs. The independent source review—including its supplemental original `0x61348..0x63940` pricing interval—is preserved with the build at `work/pump-nested-source-build/prebuild/independent-review`. This harness proposal does not repeat that semantic review. The general route proposal is excluded from this build while its missing bit-0 preflight call is corrected separately.

## Exact harness changes

`fixture.patch` is the minimal proposed change to the existing nested fixture. The full draft is `proposed/pump_create_nested_fixture.py`. It adds arbitrary **readonly remaining-account keys** after the first ancestor; observes all supplied ancestry and fixture accounts; records signature count/transaction hash/fresh VM; and enforces the ordinary 1,232-byte serialized transaction bound. A portable repository marker replaces the fixed parent-depth assumption. A new optional ordinary-unused-vault key avoids aliasing the immediate quote mint with the inherited, unused Mayhem-named writable slot. That account remains unused and no Mayhem instruction is requested or invoked. Existing calls without the options keep their old defaults. No maintained harness is edited.

`proposed/pump_nested_general_differential.py` supplies the exact case construction and assertions. New ancestors are **synthetic preexisting state**, not claimed genuine creation/migration history. Every curve uses its real Pump mint-derived PDA. Every migrated Pool uses the genuine Pump pool-authority, AMM index-zero Pool PDA, canonical stored vault keys and initialized ordinary Tokenkeg balances. No one signs as those PDAs. The tested final `create_v2` has ordinary test-owned payer and fresh-mint signatures, with actual captured Pump/token/ATA CPI behavior. The fixed inherited `create_v2` Token-2022 mint initialization remains unchanged; all new ancestor quote mints/vaults are ordinary Tokenkeg. There are no new extension layouts or extension semantics.

The builder consumes `4 + depth + 3 × Pool_count` remaining accounts, ordered nearest ancestor first. It supplies coherent stored ancestor depths and a native-zero terminal quote. Trading records use positive reserves with real-token capacity above the proposed conversion output; migrated records use all four zero reserves and canonical Pool/vault state. Asymmetric variants distinguish fold order. Pool quote adjustments are ±1,000,000 against positive 1,000,000,000,000-scale balances. All selected accounts are preexisting; no Pool creation or migration instruction is run. The child’s ordinary creation/ATA initialization is the only requested operation.

## New unique cases and repeated baselines

`cases.json` is the authoritative ordered list:

| New family | Cases | Intended observation |
|---|---:|---|
| All-Curve native ancestry at depth 2, 3, 4, 5 | 4 | Generic traversal and depth/store/event result |
| Asymmetric all-Curve depth 2 and 3 | 2 | Nearest-first admission, root-first pricing fold |
| Immediate migrated Pool at depth 1 | 1 | Pool branch without a trading ancestor |
| Immediate or terminal Pool at depth 2 | 2 | Variable-width cursor and canonical Pool ancestry |
| Immediate, intermediate or terminal Pool at depth 3 | 3 | Pool placement and subsequent ancestor position |
| Two Pools at depth 2 | 1 | Two separate four-account records |
| Middle Pool at depth 3 with positive/negative adjustment | 2 | Signed positive-result quote adjustment |
| Ordinary depth-2 request under max depth 1 | 1 | Error 6105 and complete rollback |
| **Total unique new specifications** | **16** | **15 intended successes and one ordinary rejection** |

The existing `scripts/pump_create_nested_differential.py` **48-case** suite is repeated unchanged, including its 33 historical successes and 15 rejection cases. It is not replaced by these fixtures. The existing ordinary create_v2/control families and full Pump corpus remain required before promotion. Existing one-curve (56) and two-curve (20) route suites are unchanged separate regression obligations; their saved receipts do not cover this new source. No count is incremented by this proposal or the build.

Original-only acceptance and the later fresh original/candidate run use the same 16 specifications. They are **16 unique new cases, not 32**. An accepted original-only file is required before candidate comparisons; the candidate run repeats the original freshly and requires identical frozen repository/harness inputs. The runner does not silently skip rejected prospective successes. It saves all observations and assertion failures, then exits nonzero. If a proposed case is not accepted by the original, preserve its failure and return for review rather than changing an initializer, signature, compiler flag or account guard to force it through.

## Assertions and evidence

Each side starts a fresh LiteSVM with ordinary signature checking and transaction history set to the same existing value. Both payer and mint signatures must verify; raw signed transactions and transaction SHA-256 are retained. No PDA is an outer signer. The actual new clean build report, its before/after source maps and all 37 source bytes must match `expected-source-map.json`; a candidate ELF alone is insufficient.

All cases compare complete before/after account bytes, owners and lamports; errors; raw event log payloads; complete inner instruction data/account order; and return data. All non-compute log lines are compared after removing only Anchor source-coordinate prefixes. Raw logs are retained; numeric errors/messages/Left/Right output and invocation/return order are not suppressed. Compute consumption is retained but is not an equality assertion.

On successful creation, additionally require the 166-byte curve owner/layout, requested stored depth, immediate quote key, positive derived virtual quote reserves and matching initial quote-reserve field; ordinary/noncomplete flags; exactly one completely decoded CreateEvent whose depth/quote/reserves/mint/curve/token program match persisted state; and the canonical initialized Tokenkeg quote ATA with zero amount and correct mint/authority. All supplied ancestor mints, curves, Pools, vaults and unused fixed-slot state remain unchanged. No Mayhem program invocation may appear.

For the depth rejection, require error 6105, no CreateEvent, and exact rollback of every observed account except the fee payer. Fee-payer before/after state is still compared completely between original and candidate; no guessed transaction fee is substituted. Intermediate CPI logs/return data remain recorded even for a failed transaction.

`proposed/verify_saved.py` is a future saved-receipt checker. It independently verifies every retained ordinary transaction signature and hash, the exact test-owned signer pair, the actual create_v2 discriminator, all semantic assertions, exact state/event/inner/return parity and normalized log parity. It never executes a program or signs a new transaction. It has only been syntax-checked at this stage, because no new receipt exists.

## Execution boundary and remaining limits

`commands.json` contains the exact proposed original-acceptance, candidate and saved-evidence commands. They are for parent review, **not already executed**. After review, the source build currently available is `work/pump-nested-source-build/build-01` (candidate `3c5feecfc6a009c4215169aef1d1e550abd613c48ff395e9d0d210ee5cfcf957`, 1,597,144 bytes). Its successful compilation and separate serializer gate do not predict fixture results.

This narrow first matrix does not cover every historical account-length cutoff, wide overflow boundary, nonnative terminal-root selector, new completion-pricing branch, token extension, Mayhem, holder, cashback, stopped trade-fee/incentive work, or privileged initializer. Existing relevant baselines remain regression obligations. The new Pool ancestry is synthetic canonical state, so it establishes no creation/migration reachability or authentic history. Full historical source, whole-original bytes, transitive runtime behavior and the security audit remain incomplete.

Run `python3 verify.py` for portable **static proposal integrity** checks, or `python3 verify.py --repo /path/to/repo` to rebind current baseline source, maintained harnesses, IDLs/capture and runtime ELF hashes. That verifier uses only the standard library and never imports proposed runtime code. Copied predecessor receipts remain explicitly historical.
