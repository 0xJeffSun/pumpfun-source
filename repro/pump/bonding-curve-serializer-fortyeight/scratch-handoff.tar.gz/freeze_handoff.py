#!/usr/bin/env python3
"""Freeze an explicit allowlist; generated deployment keypairs are never opened."""
from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];H=W/'handoff'
assert not H.exists();H.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification=json.loads((W/'independent-verification.json').read_text())
assert verification['differential_case_count']==9217 and verification['surfpool_comparisons']==1024 and verification['receipt_build_bindings']==65 and not verification['mismatches']
copy_map={}
def copy(source,destination):
 assert not source.name.endswith('-keypair.json') and not source.is_symlink()
 target=H/destination;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);copy_map[str(source.relative_to(R))]={'path':destination,'sha256':sha(source)}
for name in ['plan.json','source-snapshot.tar.gz','baseline-source-sha256.json','candidate-source-sha256.json','serializer.patch','helper-sha256.json','anchor-account-macro-reference.rs','function-match.json','match_serializer.py','dependency-provenance.json','toolchain-provenance.json','inputs-before.json','harness-snapshot.tar.gz','harness-snapshot-sha256.json','verify_receipts.py','verify_handoff.py','independent-verification.json','receipt-build-bindings.json','surfpool-executable-sha256.json','run_regressions.py','run_surfpool.py','differential-preflight-01.json','differential-preflight-01.log','freeze_handoff.py']:
 copy(W/name,name)
for name in ['build-attempt.json','build-comparison.json']:
 copy(W/'build-01'/name,name)
for name in ['build-launcher.log','differential-orchestration.log','surfpool-orchestration.log']:
 copy(W/name,name)
copy(W/'build-01/artifacts/pump_recovered.so','candidate.so')
copy(W/'build-01/target/sbf-solana-solana/release/pump_recovered.so','unstripped.so')
(H/'build.log.gz').write_bytes(gzip.compress((W/'build-01/build.log').read_bytes(),mtime=0))
copy(R/'work/pump-amm-current-body-inventory/elf_reader.py','elf_reader.py')
for file in sorted((W/'build-helper-snapshot').rglob('*.py')):copy(file,str(file.relative_to(W)))
for name in ['run.json','summary.json']:copy(W/'differential'/name,'differential/'+name)
aggregate={}
for row in json.loads((W/'differential/run.json').read_text()):
 name=row['suite'];path=W/'differential'/(name+'.json.gz');copy(path,'differential/'+path.name);copy(W/'differential'/(name+'.log'),'differential/'+name+'.log')
 raw=path.read_bytes();aggregate[name]=json.loads(gzip.decompress(raw)if raw.startswith(b'\x1f\x8b')else raw)
(H/'all-differential.json.gz').write_bytes(gzip.compress(json.dumps({'scope':'Unchanged 37-suite bounded corpus. Embedded legacy source maps are baseline checkout snapshots; receipt-build-bindings.json identifies the 36 actual compiler inputs.','candidate_sha256':verification['candidate_sha256'],'original_sha256':verification['original_sha256'],'case_count':9217,'mismatches':[],'suites':aggregate},separators=(',',':')).encode(),mtime=0))
copy(W/'surfpool/run.json','surfpool/run.json')
for row in json.loads((W/'surfpool/run.json').read_text()):
 directory=R/row['output'];name=row['name'];copy(W/'surfpool'/(name+'.log'),'surfpool/'+name+'.log')
 for file in directory.glob('pump-*-transactions.json'):
  data=json.loads(file.read_text())
  if 'candidate_sha256'in data and 'signed_transactions'in data:copy(file,'surfpool/'+name+'/'+file.name)
(H/'receipt-copy-map.json').write_text(json.dumps(copy_map,indent=2)+'\n')
summary={k:v for k,v in verification.items()if k not in ['differential_suites','surfpool_suites']};summary.update({'candidate_bytes':(H/'candidate.so').stat().st_size,'implemented_handler_count_change':0,'partial_handler_count_change':0,'source_change':'Only BondingCurve explicit serializer/error propagation; equivalent account traits retain existing logic.','full_body_match':'BondingCurve exit: 1,840 bytes, 25 direct callees and 8 discriminator bytes','build_attempts':1,'failed_builds':0,'preflight_failures_without_runtime':1,'new_runtime_fixture_cases':0})
(H/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(H/'README.md').write_text('''# Isolated Pump BondingCurve serializer checkpoint

Only `programs/pump/src/trade_types.rs` changes from the current 48-handler/five-partial baseline. The explicit account traits retain the prior discriminator, owner, Clone/Borsh derives and deserializer logic. Serialization now propagates ordinary I/O errors instead of wrapping them as Anchor error 3004. Source-location diagnostics from explicit boilerplate may move; historical source identity is not claimed.

One clean v1.44 build with unchanged locks/profile and 36 actual inputs produced the included candidate. Its complete 1,840-byte BondingCurve exit matches the captured original under strict relocation/internal-call normalization; all 25 direct callee bodies and the exact eight-byte discriminator match. Full original byte equality remains false, and transitive rodata/source identity is not established.

All 37 unchanged differential suites (9,217 cases) and 28 unchanged Surfpool runners (1,024 comparisons) pass on this executable. Their 65 receipts bind the actual 36 scratch build inputs. Legacy embedded source maps remain incidental baseline-main snapshots; quote-control directly binds the adjacent scratch build report. The 56 partial native-route cases retain their fixed scope, 50 Pump CPIs, six caller rejections and only 11 successes. No new fixture or stopped trade-fee/incentive/Mayhem/extension lane was introduced.

The old aggregate helper changed under root ownership during preparation. A preflight stopped before any runtime suite; its diagnostic and old/current hashes are retained. The unused aggregate is excluded from the executed helper closure. All 94 actual helper/reference files and 28 runtime files were frozen, and 98 helper/orchestration/verification files are snapshotted. Source, build helpers, compiler hashes and post-build public dependency archive/source observations are retained. No main edit or promotion is part of this package. Generated deployment keypair files are not read or packaged.

Run `python verify_handoff.py` with `solders` installed to verify the saved package, source archive, receipt bindings and transaction signatures. The other scripts retain the original workspace-relative paths as execution provenance; they are not standalone replay commands. `function-match.json` records the pre-runtime static acceptance; the subsequent runtime result is in `independent-verification.json`.
''')
manifest={str(p.relative_to(H)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(H.rglob('*'))if p.is_file()}
(H/'manifest-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest)+1,'manifest_sha256':sha(H/'manifest-sha256.json'),'candidate_sha256':sha(H/'candidate.so')},indent=2))
