#!/usr/bin/env python3
"""Verify the saved handoff, without executing transactions or build commands."""
from pathlib import Path, PurePosixPath
import base64
import gzip
import hashlib
import json
import tarfile
from solders.transaction import VersionedTransaction

HERE = Path(__file__).resolve().parent


def safe_name(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts, name
    assert not path.name.endswith('-keypair.json'), name
    return path


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    path = HERE / safe_name(name)
    assert not path.is_symlink(), name
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if raw.startswith(b'\x1f\x8b') else raw)


def archive_map(name):
    result = {}
    with tarfile.open(HERE / name) as archive:
        members = archive.getmembers()
        for member in members:
            safe_name(member.name)
            assert member.isfile() and member.name not in result, member.name
            result[member.name] = None
        for member in members:
            result[member.name] = digest(archive.extractfile(member).read())
    return result


def encoded_transactions(value):
    if isinstance(value, dict):
        if isinstance(value.get('transaction_base64'), str):
            yield value['transaction_base64']
        for key, child in value.items():
            if key != 'transaction_base64':
                yield from encoded_transactions(child)
    elif isinstance(value, list):
        for child in value:
            yield from encoded_transactions(child)


def verify_transactions(value):
    transactions = signatures = 0
    for encoded in encoded_transactions(value):
        raw = base64.b64decode(encoded)
        tx = VersionedTransaction.from_bytes(raw)
        assert bytes(tx) == raw and all(tx.verify_with_results())
        transactions += 1
        signatures += len(tx.signatures)
    return {'transactions': transactions, 'signatures': signatures}


manifest = read('manifest-sha256.json')
for name in manifest:
    safe_name(name)
for name, expected in manifest.items():
    path = HERE / name
    assert not path.is_symlink(), name
    raw = path.read_bytes()
    assert {'sha256': digest(raw), 'bytes': len(raw)} == expected, name

baseline = read('baseline-source-sha256.json')
source = read('candidate-source-sha256.json')
assert set(source) == set(baseline) and len(source) == 36
assert [p for p in source if source[p] != baseline[p]] == ['programs/pump/src/trade_types.rs']
assert archive_map('source-snapshot.tar.gz') == source
assert archive_map('harness-snapshot.tar.gz') == read('harness-snapshot-sha256.json')
attempt = read('build-attempt.json')
build = read('build-comparison.json')
assert attempt['returncode'] == 0 and attempt['source_unchanged']
actual_source = build['source_sha256']
assert actual_source == attempt['source_sha256'] == attempt['source_after_sha256']
prefix = 'work/pump-bonding-curve-serializer-recovery/source/'
assert all(p.startswith(prefix) for p in actual_source)
assert {p[len(prefix):]: h for p, h in actual_source.items()} == source
assert digest(gzip.decompress((HERE / 'build.log.gz').read_bytes())) == build['build_log_sha256']
candidate = manifest['candidate.so']['sha256']
assert candidate == build['comparison']['candidate_sha256']
verification = read('independent-verification.json')
assert verification['candidate_sha256'] == candidate
assert verification['original_sha256'] == build['comparison']['original_sha256']
assert not verification['mismatches'] and not verification['full_byte_equality']

copy_map = read('receipt-copy-map.json')
bindings = read('receipt-build-bindings.json')
assert len(bindings) == 65
diff_results = verification['differential_suites']
surf_results = verification['surfpool_suites']
assert len(diff_results) == 37 and sum(row['case_count'] for row in diff_results) == 9217
assert len(surf_results) == 28 and sum(row['cases'] for row in surf_results) == 1024
expected_receipts = {row['receipt_sha256']: row for row in diff_results + surf_results}
assert len(expected_receipts) == 65
counts = {'differential': {'transactions': 0, 'signatures': 0},
          'surfpool': {'transactions': 0, 'signatures': 0}}
for binding in bindings:
    mapped = copy_map[binding['receipt']]
    assert binding['receipt_sha256'] == mapped['sha256'] == manifest[mapped['path']]['sha256']
    assert binding['actual_compiler_inputs_sha256'] == actual_source
    assert binding['build_report_sha256'] == manifest['build-comparison.json']['sha256']
    assert binding['executed_candidate_sha256'] == candidate
    assert binding['executed_original_sha256'] == verification['original_sha256']
    data = read(mapped['path'])
    if binding['kind'] == 'surfpool':
        assert data['candidate_sha256'] == candidate and not data['mismatches']
        value = {'original': data['original'], 'candidate': data['candidate']}
    else:
        value = data
    verified = verify_transactions(value)
    assert verified == expected_receipts[binding['receipt_sha256']]['verified']
    for key, count in verified.items():
        counts[binding['kind']][key] += count

match = read('function-match.json')
assert match['normalized_body_equal'] and match['all_25_direct_target_bodies_match']
assert match['original_body']['bytes'] == match['candidate_body']['bytes'] == 1840
assert len(match['direct_target_checks']) == 25
assert all(row['full_target_body_matches'] for row in match['direct_target_checks'])
print(json.dumps({'manifest_files': len(manifest), 'source_inputs': len(source),
                  'candidate_sha256': candidate, 'receipt_bindings': len(bindings),
                  'differential_cases': 9217, 'surfpool_comparisons': 1024,
                  'verified_signed_receipts': counts, 'full_byte_equality': False}, indent=2))
