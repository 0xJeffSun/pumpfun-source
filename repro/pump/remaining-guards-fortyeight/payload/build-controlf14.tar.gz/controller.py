"""UNEXECUTED single build only; no target execution or active source writes."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,os,gzip,datetime,tempfile,ast
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[1]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
p=argparse.ArgumentParser();p.add_argument('--reviewed-control-sha256',required=True);p.add_argument('--launch-build',action='store_true');a=p.parse_args()
assert H(P/'manifest.json')==a.reviewed_control_sha256
assert not any(f.is_symlink() or f.name in ['__pycache__','.pytest_cache'] for f in P.rglob('*'))
m=J(P/'manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and f not in [P/'manifest.sha256',P/'manifest.json']},'complete manifest membership'
for n,h in m.items():assert not(P/n).is_symlink()and H(P/n)==h,n
g=J(P/'inputs.json');assert len(g['source'])==37
assert not any(x for x in os.environ if os.environ[x] and (x in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_RUSTFLAGS'] or x.startswith('CARGO_PROFILE_') or (x.startswith('CARGO_TARGET_') and x.endswith('_RUSTFLAGS')))), 'unreviewed flag/profile environment'
for n,h in g['source'].items():assert H(P/'baseline'/n)==h,n
assert H(P/'proof/manifest.json')==g['proof_seal']=='f61acc5173cb59236293984cd02fa98a9a082675738900e001417f07597080cb'
for n,h in J(P/'proof/manifest.json')['files'].items():assert H(P/'proof'/n)==h,n
assert H(P/'proof/source/admin_cto.combined.rs')==g['proposal_sha256']
for n,h in g['helpers'].items():assert H(P/'helpers'/n)==h,n
assert g['helpers']['scripts/build_partial_candidate.py']=='bb683621ffc4297c58f030cb03da54484b7370b786fd8eda965a37f4b3198ee9'
def external():
 t=g['tools'];cli=t['files']['cargo-build-sbf'];selected=shutil.which('cargo-build-sbf');assert selected and Path(selected).resolve()==Path(cli['path']).resolve(),'resolved CLI selection'
 for v in t['files'].values():assert H(Path(v['path']))==v['sha256'],v['path']
 sdk=Path(t['sdk_source']);actual={str(f.relative_to(sdk)):H(f)for f in sdk.rglob('*')if f.is_file()and 'dependencies'not in f.relative_to(sdk).parts and not f.name.endswith('-keypair.json')};assert actual==g['sdk_source'],'SDK template'
 dep=P/'baseline-dependency-provenance.json.gz';assert H(dep)==g['dependency_sha256'];d=json.loads(gzip.decompress(dep.read_bytes()));count=0
 for package in d['packages']:
  for f in package['archives']:
   assert H(R/f['path'])==f['sha256']==package['lock_checksum'];count+=1
  for tree in package['source_trees_observed']:
   for n,h in tree['source_files_sha256'].items():assert H(R/tree['path']/n)==h;count+=1
 assert count==14281 and len(d['packages'])==252
 return {'resolved_cli':str(Path(selected).resolve()),'cli_sha256':H(Path(selected)),'locked_packages':252,'retained_dependency_files':count,'sdk_files':len(actual)}
def import_preflight():
 # Exact standalone argparse invocation plus an audited module-witness harness.
 with tempfile.TemporaryDirectory(prefix='pump-import-only-')as temp:
  repo=Path(temp)/'repo';shutil.copytree(P/'helpers',repo)
  script=repo/'scripts/build_partial_candidate.py';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
  q=subprocess.run([sys.executable,'-B',str(script),'--help'],cwd=repo,env=env,capture_output=True,text=True)
  assert q.returncode==0,(q.returncode,q.stderr)
  r=subprocess.run([sys.executable,'-B',str(P/'import_help_probe.py'),str(script)],cwd=repo,env=env,capture_output=True,text=True)
  assert r.returncode==0,(r.returncode,r.stderr)
  witness=json.loads(r.stdout)
  for item in witness['local_modules'].values():
   n='scripts/'+Path(item['path']).name;assert item['sha256']==g['helpers'][n];item['path']='<isolated-repo>/'+n
  for item in witness['loaded_file_modules'].values():
   if item['local_helper']:item['path']='<isolated-repo>/scripts/'+Path(item['path']).name
  assert not list(repo.rglob('__pycache__'))
  return {'direct_help_exit':q.returncode,'direct_stdout':q.stdout,'direct_stderr':q.stderr,'harness_exit':r.returncode,'harness':witness}
checks=external();imports=import_preflight()
subprocess.run([sys.executable,'-B',str(P/'proof/verify.py'),'--check'],check=True)
assert H(P/'constant-proof/manifest.json')==g['constant_proof_seal']=='db17388ab0d3e3602603ebb3feb985011c21a7de6738d57a3e27d19ae66647cb'
subprocess.run([sys.executable,'-B',str(P/'constant-proof/verify_manifest.py'),'--seal',g['constant_proof_seal']],check=True)
subprocess.run([sys.executable,'-B',str(P/'constant-proof/verify.py')],check=True)
assert (P/'proof/source/admin_cto.before.rs').read_bytes()==(P/'constant-proof/source/admin_cto.combined.rs').read_bytes()
assert (P/'baseline/programs/pump/src/admin_cto.rs').read_bytes()==(P/'constant-proof/source/admin_cto.before.rs').read_bytes()
first=Path(g['first_build_root']);assert H(Path(g['first_control_path'])/'manifest.json')==g['first_control_seal']=='694022afe5778dcc5fc34894af1c01df355b8fc5a4f0274fb84e4a10dbdba824'
assert H(first/'static-review/manifest.json')==g['first_emitted_seal']
for n,h in J(first/'static-review/manifest.json').items():assert H(first/'static-review'/n)==h,n
subprocess.run([sys.executable,'-B',str(first/'static-review/verify_static.py'),'--check'],check=True)
assert J(first/'controller-exit.json')['returncode']==J(first/'build-exit.json')['returncode']==0
# The selected source is read only; source scanner covers the actual canonical root.
def current():
 M=Path(g['managed_repo']);package=M/g['main_package'];assert H(package/'manifest.json')==g['main_seal']
 for n,v in J(package/'manifest.json').items():
  expected=v['sha256'] if isinstance(v,dict) else v
  assert H(package/n)==expected,n
 for n,h in g['helpers'].items():assert H(M/n)==h,n
 import importlib.util
 spec=importlib.util.spec_from_file_location('actual_source_scanner',P/'helpers/scripts/build_source_manifest.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 actual=mod.source_manifest(M/'programs/pump',M/'programs/pump',M,[],cwd=M);assert actual==g['selected_source']
 index={n:hashlib.sha256(subprocess.check_output(['git','show',':'+n],cwd=M)).hexdigest()for n in actual}
 head={n:hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+n],cwd=M)).hexdigest()for n in actual}
 assert index==head==actual==g['selected_source']
 assert H(M/'programs/pump/README.md')==g['baseline_readme']
 return {'source37':actual,'index37':index,'HEAD37':head,'README':g['baseline_readme'],'main_seal':g['main_seal']}
selected=current()
baseline=Path(g['baseline_artifact_root']);assert H(baseline/'candidate.so')==g['baseline_candidate'] and H(baseline/'unstripped.so')==g['baseline_symbols']
if not a.launch_build:print(json.dumps({'preflight':'PASS','external':checks,'import_closure':imports,'build':'UNRUN','runtime_authorized':False}));raise SystemExit(0)
W=P.parent/'pump-admin-cto-remaining-corrective-build';W.mkdir(exist_ok=False)
def record(n,v):
 with(W/n).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def event(v):
 with(W/'events.jsonl').open('a')as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**v})+'\n')
try:
 repo=W/'repo';shutil.copytree(P/'baseline',repo)
 for n in g['helpers']:
  dest=repo/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'helpers'/n,dest)
 shutil.copy2(P/'proof/source/admin_cto.combined.rs',repo/'programs/pump/src/admin_cto.rs')
 dest=repo/'evidence/original/pump/deployed.so';dest.parent.mkdir(parents=True);shutil.copy2(P/'proof/numeric-proof/original.so',dest)
 source={n:H(repo/n)for n in g['source']};assert[n for n in source if source[n]!=g['source'][n]]==['programs/pump/src/admin_cto.rs']
 import importlib.util
 spec=importlib.util.spec_from_file_location('scratch_source_scanner',repo/'scripts/build_source_manifest.py');scanner=importlib.util.module_from_spec(spec);spec.loader.exec_module(scanner)
 assert scanner.source_manifest(repo/'programs/pump',repo/'programs/pump',repo,[],cwd=repo)==source
 record('source-before.json',source);record('preflight.json',{'source37':g['source'],'helpers':g['helpers'],'external':checks,'selected_current':selected,'first_emitted_review_seal':g['first_emitted_seal'],'constant_proof_seal':g['constant_proof_seal'],'chosen_delta':g['chosen_delta'],'unchanged_limits':g['unchanged_limits'],'immediate_source37':g['source'],'import_closure':imports,'baseline_artifact_gate':{'candidate':H(baseline/'candidate.so'),'symbols':H(baseline/'unstripped.so')},'control_seal':a.reviewed_control_sha256,'build_limit':1,'runtime_authorized':False})
 B=W/'build-01';cmd=[sys.executable,'-B',str(repo/'scripts/build_partial_candidate.py'),'--manifest',str(repo/'programs/pump/Cargo.toml'),'--program','pump','--artifact-name','pump_recovered.so','--tools-version','v1.44','--output',str(B)]
 env={**os.environ,'CARGO_HOME':g['cache'],'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
 record('launch.json',{'command':cmd,'cwd':str(repo),'environment':{n:env[n]for n in ['CARGO_HOME','CARGO_NET_OFFLINE','PYTHONDONTWRITEBYTECODE']},'attempt':1,'strip_version':'v1.52 unchanged recipe'});event({'phase':'build-start'})
 with(W/'build.stdout').open('x')as out,(W/'build.stderr').open('x')as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record('build-exit.json',{'returncode':r.returncode});event({'phase':'build-exit','returncode':r.returncode})
 after=scanner.source_manifest(repo/'programs/pump',repo/'programs/pump',repo,[],cwd=repo);record('source-after.json',after);assert after==source
 for n,h in g['helpers'].items():assert H(repo/n)==h,n
 record('external-after.json',external());record('selected-current-after.json',current());r.check_returncode()
 attempt=J(B/'build-attempt.json');assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['selected_toolchain']=='v1.44';assert attempt['source_sha256']==source==attempt['source_after_sha256']
 strip=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy';assert H(strip)==g['tools']['files']['stripper']['sha256']and(B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
 for n,h in g['sdk_source'].items():assert H(B/'sdk'/n)==h,n
 log=(B/'build.log').read_text().lower();bad=[x for x in ['stack offset','stack frame','stack size','stack overflow','llvm error','error: function']if x in log];record('stack-backend-gate.json',{'passed':not bad,'matches':bad});assert not bad
 # Byte-only inventory; does not execute targets or infer opaque ownership.
 A=W/'analysis';shutil.copytree(P/'method',A);(A/'static-inputs').mkdir()
 old=Path(g['baseline_artifact_root'])
 for src,name in [(P/'proof/numeric-proof/original.so','original.so'),(old/'candidate.so','candidate.so'),(old/'unstripped.so','symbols.so')]:shutil.copy2(src,A/'static-inputs'/name)
 assert H(A/'static-inputs/candidate.so')==g['baseline_candidate']and H(A/'static-inputs/symbols.so')==g['baseline_symbols']
 shutil.copy2(B/'artifacts/pump_recovered.so',A/'candidate.so');shutil.copy2(B/'target/sbf-solana-solana/release/pump_recovered.so',A/'unstripped.so')
 with(W/'inventory.stdout').open('x')as out,(W/'inventory.stderr').open('x')as err:q=subprocess.run([sys.executable,'-B',str(A/'full_inventory.py')],cwd=A,stdout=out,stderr=err,env=env)
 record('inventory-exit.json',{'returncode':q.returncode});q.check_returncode()
 record('bounded-static-review-required.json',{'passed':False,'status':'PENDING_ROOT_REVIEW','required':['full emitted CTO caller/parser/context and error return closure','WSOL uses same-type native_mint const and no runtime base58 call along admitted quote guard','6019 target holderPDA then sharing_config order and owned variant19 no compared tags','6091 default then WSOL then whitelist plus both holder/nonholder feeSome paths and owned variant91','unchanged6030/2006 comparedLeftRight; early6092 typed plainowned only; late6092 remains numeric; account types/wallet evaluation unchanged','complete converter/name/message/source coordinates and all callers','no runtime authorization until reviewed static evidence']})
 record('build-only-assessment.json',{'passed':True,'candidate_sha256':H(A/'candidate.so'),'symbols_sha256':H(A/'unstripped.so'),'runtime_executions':0,'semantic_acceptance':False,'next':'Root full emitted-body/error/tuple/call review required; separate runtime controller and authorization required.'})
except BaseException as exc:
 for name,check in [('failure-external-after.json',external),('failure-selected-current-after.json',current)]:
  try:record(name,check())
  except BaseException as gate:record(name,{'passed':False,'type':type(gate).__name__,'message':str(gate)})
 record('controller-exit.json',{'returncode':1,'error_type':type(exc).__name__,'message':str(exc)});event({'phase':'controller-failed'});raise
else:record('controller-exit.json',{'returncode':0});event({'phase':'awaiting-static-review-no-runtime'})
