# UNEXECUTED one combined corrective build

Root chose the combined supported source delta: existing same-type SDK native_mint::ID in the6091 WSOL guard plus EARLY-only plain owned CtoCreatorAccountNotWritable6092. This is a NEW control, not a compiler/flags/layout experiment.6940/f290/46a1 and const-only95b6 remain untouched;95b6 was never executed. No preflight, import-help subprocess, compiler, VM, active source/README/status/current/Git mutation has been performed during preparation.

## Exact source composition

Selected managed accepted source remains e949/04641/source37 with admin_cto1bd andREADME4df. Immediate scratch baseline is first successful f290/7504/source37, including reviewed6019 holderPDA/owned error and6091 explicitWSOL/owned error. Frozen baseline in this control is exactly that source37. Proposed37 changes only admin_cto by TWO expression substitutions, authenticated in source-composition.json: inline WSOL macro ->anchor_spl::token::spl_token::native_mint::ID; first walletreadonlyreturn ->error!(PumpError::CtoCreatorAccountNotWritable). The late6092 remains numeric. All account types and wallet owner-before-executable evaluation order remain unchanged. No artificial source coordinates, padding, flags, profiles, path/remap or dependency changes.

Full proof34ea and optionalearlyf61 are retained under proof; full consttypedvalue/reexport proofdb17 is independently retained underconstant-proof. Preflight reproduces both proofs read-only (`--check` forf61) and proves their exactsource composition against immediatef290. Native_mintID's Rust const initializer forces compile-time evaluation, with exact locked Pubkeytype and original32-byte value proven. Originalearlyreadonlypredicate and plainowned92error are bounded direct counterparts. Original executable-before-owner versus current owner-before-executable, original copiedownedheader versus borrowedheader, late-reload, partial parser cleanup and transitiveCPI/header gaps remain explicit. No fullABI or whole-original identity claim.

## Root review and one attempt only

Review command (UNEXECUTED):
`python3 -B controller.py --reviewed-control-sha256 SEAL`

Launch command (NOT YET AUTHORIZED / UNEXECUTED):
`python3 -B controller.py --reviewed-control-sha256 SEAL --launch-build`

Only fresh sibling output `pump-admin-cto-remaining-corrective-build` may be created; exclusive mkdir prevents reuse/retry. The controller writes actualcommand/environment and actualchild/controller exits exclusively and keepsfailurepostgates. Source/tool/dependency/backend failures are never suppressed or relabeled. No runtime launcher exists.

## Gates and review after build

Authenticates fullnewcontrol, f61/db17, first6940manifest, first46a1emittedmanifest+boundactualbuildinputs/verifier/exits, exactf290 executable/symbols. Source scanner/index/HEAD/readme use actual managed selected37, independently of immediate/proposed scratch37; before/after scratch scanner must match exactproposed37. Fourfrozenhelpers include bbcompilerhelper/canonicalanalyze importdd7f. Disposable standaloneargparsehelp and modulewitnesshelp checks run beforeCargo. ResolvedCLI and exactcompiler/linker/stripper tools,53SDK sourcefiles,252lockedpackages/14281archive+sourcewitnesses are checkedbefore/after. Explicitv1.44 compiler and existingv1.52strip/offlinecache only; prohibitunreviewedflag/profile/wrapperenvironment.

Cargo0 is insufficient: actualattempt/source maps/toolselection, exactstriptool/SDK and independentbackend/stack rejection must pass. Fullsame-method original/before/after function/call/branch/relocation/data inventory is produced, preserving opaque regions. The emitted semantic gate remains PENDING_ROOT_REVIEW: full CTO caller/parser/context/return/cleanup;6019 holderPDA→sharing and plainowned19; bothholder/nonholderfeeSome default→constantWSOL→whitelist and plainowned91; no runtimebase58 on thatguard; EARLY-only plainowned92 withlate numericguard unchanged; preserved6030/2006comparedkeys and allownershiplimits. No corpus authorization follows automatically. Root must review completeemittedevidence before separately authorizing existingadmittedcases; no new fixture/probe.
