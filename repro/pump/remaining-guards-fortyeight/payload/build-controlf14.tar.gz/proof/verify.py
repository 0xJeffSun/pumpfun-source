from pathlib import Path
import sys,struct,json,hashlib,gzip,subprocess
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P/'numeric-proof';sys.path.insert(0,str(Q/'method'))
from elf_reader import Elf
import metadata
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ins=lambda e,pc:struct.unpack_from('<BBhi',e.b,pc)
assert H(Q/'manifest.json')=='34eab9a5f3b9a1e049a297fbab0f1f188635be316053b690a4841994ed63b492';subprocess.run([sys.executable,'-B',str(Q/'verify_manifest.py'),'--seal',H(Q/'manifest.json')],check=True)
assert H(P/'const-proof-manifest.json')=='db17388ab0d3e3602603ebb3feb985011c21a7de6738d57a3e27d19ae66647cb';assert H(P/'source/admin_cto.before.rs')==json.loads((P/'const-proof-manifest.json').read_text())['files']['source/admin_cto.combined.rs']
o=Elf(Q/'original.so');c=Elf(P/'candidate.so');s=Elf(P/'symbols.so');assert H(P/'candidate.so')=='f2901021fde9354bf2d89098a3e8d8a425b60eda0faa856a2c8aef0d64e3f12f';assert H(P/'symbols.so')=='750456180883c72cc7e94692b75503043357f35222aebad6d67049af8ee2ed99'
# Original parser equality dominates successful aggregate return: current_creator.key == decoded-box bytes8..39.
assert ins(o,748240)==(0x7b,0x3a,-3784,0) and o.calls[748200]==15208
assert ins(o,756312)==(0x79,0xa2,-3808,0) and ins(o,756384)==(0x79,0xa2,-3784,0)
assert ins(o,756440)==(0x79,0x21,8,0) and o.calls[756496]==1783416
assert ins(o,756520)==(0x15,0,53,0) and ins(o,756544)==(0xb7,2,0,19) and o.calls[756552]==1432720
assert ins(o,770192)==(0x79,0xa1,-3784,0) and ins(o,770200)==(0x7b,0x16,56,0)
def reach(start,target,removed=()):
 seen=set();todo=[start]
 while todo:
  pc=todo.pop()
  if pc in removed or pc in seen:continue
  if pc==target:return True
  assert 746872<=pc<770312;seen.add(pc);op,r,off,im=ins(o,pc);n=pc+(16 if op==0x18 else 8)
  if op==0x95:continue
  if op==5:todo.append(pc+8+off*8)
  elif op&7 in(5,6)and op not in(0x85,0x8d):todo.extend([n,pc+8+off*8])
  else:todo.append(n)
 return False
assert not reach(746872,770304,[756496]) and not reach(756528,770304) and reach(756952,770304)
# Original application old32 comes from that same box+8; key-equivalence requires only successful parser, not guessed field name.
assert ins(o,142456)==(0x79,0x89,56,0) and ins(o,142696)==(7,9,0,8)
for load,off,store,slot in [(142968,0,142976,-56),(142984,8,142992,-48),(143000,16,143008,-40),(143016,24,143024,-32)]:assert ins(o,load)==(0x79,0x92,off,0) and ins(o,store)==(0x7b,0x2a,slot,0)
assert o.calls[148304]==1783416 and ins(o,148272)==(7,1,0,-56) and ins(o,148352)==(0xb7,6,0,0)
assert ins(o,149128)==(0x57,6,0,1) and ins(o,149160)==(0x71,0x61,210,0) and ins(o,149168)==(0x55,1,12,0)
assert ins(o,149176)==(0x79,0x61,192,0) and o.b[1792936:1792968]==bytes(32) and o.calls[149208]==1783416 and ins(o,149232)==(0x15,0,295,0)
assert ins(o,151600)==(0x71,0x61,209,0) and ins(o,151608)==(0x15,1,1521,0)
# Current exact same conjunction, preserving its owner-before-executable evaluation order.
assert ins(c,442648)==(0x79,0x71,64,0) and ins(c,442720)==(0x7b,0x1a,-1984,0)
assert c.calls[449000]==1454672 and ins(c,449032)==(0x15,0,472,0)
assert ins(c,449040)==(0x79,0x78,64,0) and ins(c,449048)==(0x79,0x81,24,0) and c.calls[449080]==1454672 and ins(c,449104)==(0x55,0,463,0)
assert ins(c,449112)==(0x71,0x81,42,0) and ins(c,449120)==(0x55,1,461,0) and ins(c,449128)==(0x71,0x81,41,0) and ins(c,449136)==(0x55,1,419,0)
# Whole original plain constructor; sharedreturn,error words and comparedNone are exact.
assert o.calls[163816]==1405824 and o.calls[163960]==1433224 and ins(o,163968)==(0x15,0,66,0)
assert ins(o,164624)[3]==6092 and ins(o,164632)==(0x72,10,-640,2) and ins(o,164640)[3]==556 and o.calls[164696]==1686320
assert ins(o,164728)==(5,0,-33,0) and ins(o,164496)==(0x95,0,0,0)
assert metadata.format_selector(o,1436840,92,'debug')['text']=='CtoCreatorAccountNotWritable'
message=metadata.format_selector(o,1433224,92,'display');assert message['text']==metadata.format_selector(c,1223568,92,'display')['text']
old=(P/'source/admin_cto.before.rs').read_text();new=(P/'source/admin_cto.combined.rs').read_text();needle='if wallet&&!a.current_creator.is_writable{return Err(err(6092));}let wallet_frozen';replacement='if wallet&&!a.current_creator.is_writable{return Err(error!(PumpError::CtoCreatorAccountNotWritable));}let wallet_frozen';assert old.count(needle)==1 and new==old.replace(needle,replacement) and new.count('return Err(err(6092));')==1
r={'passed':True,'optional_early_only':True,'original_error_domain':['parsed current_creator key nonzero','ownedheader executablefalse','ownedheader ownerSystem','ownedheader writablefalse'],'parser_key_equality_dominates_success':True,'candidate_domain_same_boolean':True,'preserved_evaluation_order_difference':'original executablebeforeowner;current ownerbeforeexecutable','owned_error':'plain CtoCreatorAccountNotWritable6092,comparedNone','late_guard_unchanged':True,'account_types_unchanged':True,'message':message,'builds':0,'runtime_executions':0}
w={label:metadata.window(e,a,z)for label,e,a,z in [('original_app',o,141840,169240),('original_parser',o,746872,770312),('candidate_app',c,441928,469728)]};payload=(json.dumps(w,separators=(',',':'))+'\n').encode()
if '--check'in sys.argv:assert json.loads((P/'result.json').read_text())==r and gzip.decompress((P/'full-windows.json.gz').read_bytes())==payload
else:(P/'result.json').write_text(json.dumps(r,indent=2)+'\n');(P/'full-windows.json.gz').write_bytes(gzip.compress(payload,mtime=0))
print(json.dumps({k:r[k]for k in ['passed','optional_early_only','late_guard_unchanged','account_types_unchanged','builds','runtime_executions']}))
