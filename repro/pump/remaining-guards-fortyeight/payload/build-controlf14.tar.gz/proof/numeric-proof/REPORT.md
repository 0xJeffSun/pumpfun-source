# Pump CTO remaining numeric guards: source-only proposal

The exact source baseline is admin_cto SHA256 `1bdc3c4a53d1742627e9411230a508f5d37af8a4317163022820188dd3debf5a`; candidate e9494060 / symbols04641cb6 are retained byte-exact. `bindings.json` records all37 historical compiled-input hashes, without inspecting stopped bodies. No build, VM, fixture, source application or active metadata change occurred.

## Proposed two-site correction

`combined.patch` changes only the6019 and6091 guards; independent patches and complete before/after source are included. The current four numeric returns are6019 once,6091 once,6092 twice. An earlier informal count of two6019 sites was incorrect.

6019: original target comparisons145184 and145256 compare against the holder-rewards PDA and named sharing_config key respectively. Equal branches145208 and145280 converge at146536. The PDA originates from142088 find_program_address with seed `holder-rewards` and mint, stored/copied into frame-1304. Named parser literal751560..751584 and cursor751784 ->770016/770024 ->context144 ->143192/143264 bind sharing_config. This is the non-holder target domain; the previous zero-target6030 check145112/145136 precedes these checks. Current source rejects only sharing_config. Proposal restores the missing holder_key disjunct first and returns `error!(PumpError::InvalidCreator)`.

Constructor146536..146712 selects enum ordinal19, name via1405824, owned message via43320, code6019, comparedNone2 and plain owned AnchorError converter1686320. It does not attach compared pubkeys or an account-name decorator. The source macro naturally produces current source coordinates; original312 is evidence, not a requested source layout.

6091: original142672,142768 and142848 compare quote against default, WSOL, and the Global whitelist member. The single Boolean is stored142896 at frame-2312. Holder flow144672/144704 and non-holder145344/147232/147288 combine that Boolean with the incoming fee Option tag and reach144720. Current source lacks the explicit WSOL arm. Proposal inserts it between default and whitelist and returns `error!(PumpError::CreatorFeeNotConfigurableForQuote)`.

The WSOL32 bytes at1793224 are `069b8857feab8184fb687f634618c035dac439dc1aeb3b5598a0f00000000001`, the existing source pubkey macro value. The Global chain is parser746992 ->78448 ->38608 ->1441232 ->1441960. Complete unchecked decoder1441960..1447344 matches candidate1190800..1196184 under normalized bytes and relocation pattern, with candidate typed symbol. Current bounded Global source declares whitelisted_quote_mints:[Pubkey;1]; emitted use is Global+936. The checked decoder has equal relocation pattern but different normalized bytes: no equality claim for that checked body. Complete helpers/windows are retained, rather than inferring the whitelist from an isolated offset.

The6091 constructor uses ordinal91/name1405824, Display1433224, aggregate6091 at146432, comparedNone2 and converter146504 ->1686320. Source326 is historical only. Enum Debug/Display selectors are independently checked for original and candidate for6019/6091/6092.

##6092 mapping and unresolved composition

The original parser's named current_creator literal1799910, call748272 ->11432, preserved cursor748784 and context store769976 identify the account. Full11432..11848 matches candidate7064..7480 and its typed AccountInfo::try_accounts symbol. This parses an owned48-byte AccountInfo with Rc ownership, while current source uses borrowed UncheckedAccount. Retained dependency source files are individually bound to the complete locked-source witness; their type layout is evidence of the candidate API, not proof of historical source text.

Original wallet guard: nonzero old creator149128, executable149160/149168, System owner149176/149208, then writable151600/151608. Context flags are packed at208: writable209 and executable210. Readonly151608 reaches the one shared6092 constructor163784. It constructs ordinal92/name/Display and code6092 with comparedNone2 then owned converter164696 ->1686320. Token predicate call151640 follows the successful writable check.

Both current source6092 guards reload the same named header: candidate448688/448776 and456432/456440 load context pointer+64 and writable+41, followed by numeric ProgramError construction. The early guard has the direct original predicate counterpart. No second original post-CPI writable check was found in the complete admitted application body. Immutability of the AccountInfo header makes the later check conditionally redundant under the ordinary Rust contract, but original owned AccountInfo versus current borrowed UncheckedAccount/context/drop differences prevent claiming raw ABI/borrow/reload equivalence. Both6092 sites remain unchanged. No blanket ok_or/error rewrite or ownership type change is proposed.

## Evidence bounds and verification

`full-admitted-windows.json.gz` includes complete original/candidate app and parser, original wrapper, Global decoder closure, enum name/Display, token predicate and complete matched helpers. `result.json` records helper matches and selected errors. `inherited-bcb` retains the preceding6030/2006 proof; these fixes remain unchanged. These are static direct-window/typed-role claims, not recursive equivalence of every transitive callee, full program byte identity, deployed vulnerability claims or new runtime coverage. No new case or signature is claimed.

Run `python3 -B verify.py --check` and `python3 -B verify_manifest.py --seal <manifest-sha256>` from any location. The first reproduces saved static assertions only. The second requires the external exact manifest seal, rejects symlinks/cache directories/extra files, and hashes every payload. No original work paths are needed.

Verifier authoring failures were a syntax typo, wrong call-PC transcription747000(correct746992), and an odd-length WSOL hex transcription. All occurred before any target execution; `authoring-failures.json` retains their exact nature. Assertions were corrected against original bytes, then the complete verifier passed. These are not compiler/runtime failures.
