"""Saved full-body/field/literal proof only; no ELF execution, build or fixture."""
from pathlib import Path
import sys,json,gzip,hashlib,struct,bisect
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'method'));from elf_reader import Elf
import metadata
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text());o=Elf(P/'original.so');c=Elf(P/'candidate.so');symbols=Elf(P/'symbols.so');binding=J(P/'bindings.json')
assert H(P/'candidate.so')==binding['baseline_candidate']=='e9494060904aad25f465efd93af9dd0bb09a5ded9f321747c789cbf0310bc6c5'and H(P/'symbols.so')==binding['symbols']
assert H(P/'original.so')==binding['original']=='7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d'
assert H(P/'source/admin_cto.before.rs')=='1bdc3c4a53d1742627e9411230a508f5d37af8a4317163022820188dd3debf5a'
def ins(e,pc):return struct.unpack_from('<BBhi',e.b,pc)
def call(pc,target):assert o.calls[pc]==target,(pc,target)
for pc,target in [(142088,1736376),(145112,1783416),(145184,1783416),(145256,1783416),(142672,1783416),(142768,1783416),(142848,1783416),(146568,1405824),(146608,43320),(146712,1686320),(144752,1405824),(144896,1433224),(146504,1686320),(163816,1405824),(163960,1433224),(164696,1686320),(748272,11432),(746992,78448),(78616,38608),(39264,1441232)]:call(pc,target)
assert 1441960 in [t for pc,t in o.calls.items() if 1441232<=pc<1441960]
# Named parsed sharing_config ->same preserved cursor slot ->context144 ->actualkey frame-1136.
assert o.b[1799323:1799337]==b'sharing_config'
assert ins(o,751576)[3]==14 and o.calls[751584]==10544
assert ins(o,751784)==(0x7b,0x1a,-3984,0)
assert ins(o,770016)==(0x79,0xa1,-3984,0)and ins(o,770024)==(0x7b,0x16,144,0)
assert ins(o,143192)==(0x79,0x62,144,0)and ins(o,143264)==(0x7b,0x2a,-1136,0)
# holder PDA result142088 ->frame-1696..-1672 ->frame-1304..-1280 at143272..143328.
assert o.b[1796286:1796300]==b'holder-rewards'
for pc,off in [(143280,-1280),(143296,-1288),(143312,-1296),(143328,-1304)]:assert ins(o,pc)[2]==off
assert ins(o,145168)[3]==-1304 and ins(o,145240)[3]==-1136
assert ins(o,145208)==(0x15,0,165,0)and ins(o,145280)==(0x15,0,156,0) # same6019 constructor entry146536
# Quote default/WSOL/global-whitelist comparisons form one Boolean stored142896.
assert o.b[1793224:1793256]==bytes.fromhex('069b8857feab8184fb687f634618c035dac439dc1aeb3b5598a0f00000000001')
assert ins(o,142816)[3]==936 and ins(o,142896)==(0x7b,0x3a,-2312,0)
assert ins(o,144672)==(0x79,0xa1,-2312,0)and ins(o,144704)[0]==0x55
assert ins(o,145344)==(0x79,0xa4,-2312,0)and ins(o,147232)==(0x57,4,0,1)
assert ins(o,147288)==(0x55,1,-322,0) # quote flag ->144720 name91
# Constructors are plain owned AnchorError, comparedNone2; no pubkey decorator on their direct paths.
for code,pc,tag,linepc,line,convert in [(6019,146672,146640,146648,312,146712),(6091,146432,146440,146448,326,146504),(6092,164624,164632,164640,556,164696)]:
 assert ins(o,pc)[3]==code and ins(o,tag)[0]==0x72 and ins(o,tag)[3]==2 and ins(o,linepc)[3]==line and o.calls[convert]==1686320
# Current_creator owned AccountInfo parser role and readonly header -> original6092 guard.
assert o.b[1799910:1799925]==b'current_creator'and ins(o,748352)[3]==15
assert ins(o,748784)==(0x7b,0x2a,-3808,0)and ins(o,769976)==(0x7b,0x16,168,0)
assert ins(o,769240)==(0x6b,0x16,208,0)and ins(o,151600)==(0x71,0x61,209,0)and ins(o,151608)==(0x15,1,1521,0)
assert ins(o,149168)[0]==0x55 and o.calls[149208]==1783416
# Both candidate guards reload SAME context pointer+64 and header bool+41, but only first has a direct original guard counterpart.
assert ins(c,448688)==(0x79,0x76,64,0)and ins(c,448776)==(0x71,0x61,41,0)
assert ins(c,456432)==(0x79,0x92,64,0)and ins(c,456440)==(0x71,0x21,41,0)
assert ins(c,448816)[3]==ins(c,456480)[3]==6092
# Full exact helper evidence; owned AccountInfo symbol is an ABI/type clue, not a guessed account offset.
pairs=[]
for label,oa,ca,size in [('Global_unchecked',1441960,1190800,5384),('AccountInfo_try_accounts',11432,7064,416),('AnchorError_from',1686320,1355384,136),('memcmp',1783416,1454688,64),('find_program_address',1736376,1401640,312)]:
 assert o.normalized[oa:oa+size]==c.normalized[ca:ca+size]and o.pattern(oa,size)==c.pattern(ca,size)
 f=[f for f in symbols.funcs if f['start']==ca];assert len(f)==1
 pairs.append({'role':label,'original':[oa,oa+size],'candidate':[ca,ca+size],'candidate_symbol':f[0]['name'],'full_normalized_and_relocation_equal':True})
assert 'AccountInfo' in pairs[1]['candidate_symbol']and'UncheckedAccount'not in pairs[1]['candidate_symbol']
selection=[]
for code in [6019,6091,6092]:
 n=metadata.format_selector(o,1436840,code-6000,'debug');m=metadata.format_selector(o,1433224,code-6000,'display');nn=metadata.format_selector(c,1227200,code-6000,'debug');mm=metadata.format_selector(c,1223584,code-6000,'display');assert n['text']==nn['text']and m['text']==mm['text'];selection.append({'code':code,'name':n,'message':m})
assert [x['name']['text']for x in selection]==['InvalidCreator','CreatorFeeNotConfigurableForQuote','CtoCreatorAccountNotWritable']
old=(P/'source/admin_cto.before.rs').read_text();combined=(P/'source/admin_cto.combined.rs').read_text()
a='if !holder && target==a.sharing_config.key(){return Err(err(6019));}';b='if !holder && (target==holder_key||target==a.sharing_config.key()){return Err(error!(PumpError::InvalidCreator));}'
x='if fee.is_some()&&(a.bonding_curve.quote_mint==Pubkey::default()||a.global.whitelisted_quote_mints.contains(&a.bonding_curve.quote_mint)){return Err(err(6091));}'
y='if fee.is_some()&&(a.bonding_curve.quote_mint==Pubkey::default()||a.bonding_curve.quote_mint==anchor_lang::solana_program::pubkey!("So11111111111111111111111111111111111111112")||a.global.whitelisted_quote_mints.contains(&a.bonding_curve.quote_mint)){return Err(error!(PumpError::CreatorFeeNotConfigurableForQuote));}'
assert old.count(a)==old.count(x)==1 and combined==old.replace(a,b).replace(x,y)and combined.count('return Err(err(6092));')==2
# All SDK type files are exact locked-dependency witness members, not invented historical source.
dep=json.loads(gzip.decompress((P/'dependencies/inventory.json.gz').read_bytes()))
for n,row in binding['dependency_files'].items():
 assert H(P/'dependencies'/n)==row['sha256'];matches=[h for p in dep['packages']for t in p['source_trees_observed']for name,h in t['source_files_sha256'].items()if t['path']+'/'+name==row['path']];assert matches==[row['sha256']]
windows={}
for label,e,a,z in [('original_app',o,141840,169240),('candidate_app',c,441928,469744),('original_parser',o,746872,770312),('candidate_parser',c,936472,957560),('original_wrapper',o,1235456,1237664),('original_Global_accounts',o,78448,78632),('original_Global_try_from',o,38608,39600),('original_Global_checked',o,1441232,1441960),('candidate_Global_checked',c,1190072,1190800),('original_Error_name',o,1405824,1432720),('original_Error_Display',o,1433224,1436840),('original_token_predicate',o,169240,169712)]:windows[label]=metadata.window(e,a,z)
for pair in pairs:
 for side,e in [('original',o),('candidate',c)]:a,z=pair[side];windows[side+'_'+pair['role']]=metadata.window(e,a,z)
result={'passed':True,'source_sites':{'6019':1,'6091':1,'6092':2},'proposed_changed_sites':[6019,6091],'6092_changed':False,'6019_contract':['nonholder target != holder_rewards_PDA','nonholder target != sharing_config','plain InvalidCreator owned error; comparedNone'],'6091_contract':['feeSome && (default || WSOL || whitelisted quote)','plain CreatorFeeNotConfigurableForQuote owned error; comparedNone'],'6092_mapping':'same named writable bool; early guard corresponds original151608. Late reload has no independent original predicate; immutable-header redundancy is conditional and ownership/context differ. No6092 patch.','selected_errors':selection,'full_helper_pairs':pairs,'whole_original_identity':False,'builds':0,'runtime_executions':0}
payload=(json.dumps(windows,separators=(',',':'))+'\n').encode()
if '--check'in sys.argv:assert J(P/'result.json')==result and gzip.decompress((P/'full-admitted-windows.json.gz').read_bytes())==payload
else:(P/'result.json').write_text(json.dumps(result,indent=2)+'\n');(P/'full-admitted-windows.json.gz').write_bytes(gzip.compress(payload,mtime=0))
print(json.dumps({k:result[k]for k in ['passed','proposed_changed_sites','6092_changed','builds','runtime_executions']}))
