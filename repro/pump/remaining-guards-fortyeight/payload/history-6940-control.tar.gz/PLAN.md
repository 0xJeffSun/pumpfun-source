# UNEXECUTED Pump CTO6019/6091 single-build control

Root must read this complete control and proof34ea before authorizing any launch. No preflight, import-help subprocess, compiler or VM was invoked by preparation. Static Python AST parsing and file hashing only were performed. The base58 pubkey value was independently decoded without SDK/runtime imports and equals the original literal32 bytes; controller recomputes this assertion.

Baseline is actual managed selected e949/04641, source37 with admin_cto1bd. `proof/` is byte-identical source-only34ea; only combined6019/6091 proposal is copied into a fresh scratch snapshot. Two6092 source checks, parser ownership,6030/2006 and every other source input remain unchanged. No README input/change, current/status/Git/index mutation is implemented.

Review command (not executed):
`python3 -B controller.py --reviewed-control-sha256 SEAL`

Single build launch (NOT AUTHORIZED, NOT EXECUTED):
`python3 -B controller.py --reviewed-control-sha256 SEAL --launch-build`

The exclusive fresh output is sibling `pump-admin-cto-remaining-build`; mkdir(exist_ok=False) prevents a second attempt under this control. Commands and actual child/controller exits are append-only/exclusive; failure postgates are retained independently and cannot turn a failed build into acceptance. The old fd733 failure, corrected dabc/v2,944e static,6dd runtime andC4 main remain untouched and are not relabeled as new results.

Preflight authenticates the control manifest and proof34ea, frozen37source map, managedC4 known seal and every payload, selected current37 via actual canonical source scanner plus index/HEAD blobs, README4df and four helpers. Compiler helperbb includes canonical analyze import dd7f. Standalone argparse --help and module-witness help run only in a disposable frozen-helper copy, before any Cargo; no compiler is reached. Resolved cargo-build-sbf path/hash must equal pinned CLI. Exact compiler/tools,53SDK sourcefiles,252locked packages/14281 retained archive+source witnesses and prohibited environment flags/profiles are checked before/after. Actual scratch source scanner must equal proposed37.

Build uses only the frozen existing helper with explicit v1.44, existing v1.52 strip phase and existing offline cache. No flags, profiles, remaps, metadata, dependency version search or retries. Build-attempt actual code/source map/tool version must agree; v1.52 stripper and all53SDK files are checked. Cargo0 does not imply acceptance: backend/stack error strings independently reject output. A failed old gate is never suppressed.

After success the complete original/current-before/current-after same-method function/call/branch/relocation/data inventories are generated using the admitted byte-only method. Stopped regions retain uninterpreted classifications. There is no whole-original identity claim. `bounded-static-review-required.json` deliberately remains PENDING_ROOT_REVIEW: complete emitted caller/parser/context roles, holderPDA-before-sharing order, default-before-WSOL-before-whitelist and both feeSome domains, enum19/91 plain owned construction, direct return/cleanup,6030/2006 compared tags and unchanged6092 must be reviewed before any separately authorized existing-corpus controller. No runtime launcher exists here.

Preparation checks source maps and AST validity, not environmental preflight or a build. Host/cache/workspace paths remain explicit build inputs; this build control is local. Proof34ea itself is portable saved evidence.
