# UNEXECUTED one corrective build: native-mint constant

This is a NEW plan. Root must review proofdb17 and exact const-only patch before authorizing launch. No preflight/help/compiler/VM has been executed during preparation. Existing f290/6940/static46a1 remain immutable, including their successful build and the documented runtime-base58 emitted mismatch; no failed globalgate is erased or relabeled.

The actual selected managed baseline remains accepted e949/04641/source37 with admin_cto1bd andREADME4df. The immediate scratch baseline is the completed first candidate f290/7504 and its exact37map. This control snapshots those37files and substitutes only the6091 inline pubkey macro with the already locked same-type `anchor_spl::token::spl_token::native_mint::ID`. Combined difference from selected remains one admin_cto file; no active source/README/current/status/Git mutation exists.6092 guards and parser types remain unchanged.

Commands (UNEXECUTED):
`python3 -B controller.py --reviewed-control-sha256 SEAL`
`python3 -B controller.py --reviewed-control-sha256 SEAL --launch-build`

Exactly one fresh sibling output `pump-admin-cto-wsol-const-build`, exclusive mkdir, no retry. New control authentications include6940 manifest, first46a1 fullstaticmanifest+boundbuildinputs/verifier+actualsuccessful exits, immediatef290 fullELF/symbol hashes, proofdb17 manifest and source/dependency/type/value assertions. Actual managed source scanner/index/HEAD/readme are compared against separately recorded SELECTED37, while scratch scanner and build sourcebefore/after are compared to IMMEDIATE37 plus only constproposal. This distinction prevents claiming f290 was promoted.

Reuse exact frozenbb fourhelper/import closure (canonical analyze dd7f), pinned resolvedCLI/tool hashes,53SDK sourcefiles and252lockedpackages/14281archive+sourcewitness gates before/after. Import-only standalonehelp and modulewitness run from disposable helpercopy before Cargo. Explicitv1.44 compiler/existingv1.52strip and offlinecache only; prohibited flag/profile/remap environment rejected. No alternate constsource, flags/layout/coordinates/dependency variation is tried. Every actual child/controller exit and failure postgate is retained; backend/stack rejection is independent of Cargo0.

Postcompile only byte-ledgers/fullsame-method original/current-before/current-after function/call/branch/relocation/data inventory. Pending emitted semantic review must confirm quote default→constantWSOL→whitelist and both holder/nonholderfeeSome domains, no runtimebase58 on this guard,6019 holderPDA→sharing order, plainowned6019/6091,6030/2006comparedkeys and unchanged6092. This plan grants NO runtime authorization and has no VM/corpus launcher. Root must review emitted evidence before any separately prepared existing-corpus controller. No whole-original identity claim.
