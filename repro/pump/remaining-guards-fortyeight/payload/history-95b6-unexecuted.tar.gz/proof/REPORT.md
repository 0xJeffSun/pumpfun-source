# One chosen refinement: existing typed native-mint const

The first candidate f290 and control6940 remain immutable; emitted review46a1 records the inline pubkey macro's runtimebase58 resource/order difference. This packet chooses ONE natural source refinement, not a sweep: replace only the6091 WSOL guard's inline macro with `anchor_spl::token::spl_token::native_mint::ID`.6019/6091 owned errors and all other predicates/order remain as first candidate; both6092 remain unchanged. No initializer/trade/incentive/stopped body is inspected. No build or target execution.

## Type, feature and const route

Frozen program Cargo.toml enables AnchorSPL0.31.1 with defaultfeatures (no default-features=false). Locked AnchorSPL's defaultfeatures include token; its lib exports token under that feature. token.rs reexports spl_token. Its dependency is spl-token7, and frozen Cargo.lock has exactly one spl-token7.0.0, solana-program2.3.0 and solana-pubkey2.4.0.

SPLToken7 lib exposes native_mint; native_mint.rs invokes solana_program::declare_id!(WSOLtoken). SolanaProgram2.3 reexports solana_pubkey::declare_id and aliases solana_pubkey as pubkey. The macro declares `pub const ID: $crate::Pubkey = $crate::Pubkey::from_str_const($address);`. Anchorprelude reexports that same solana_program::pubkey::Pubkey, so ID has the exact source-level type expected by the existing quote_mint comparison, without conversion/newdependency.

Pubkey::from_str_const is constfn and calls five8_const::decode_32_const, also constfn. ID's initializer is a Rust const context, so valid initialization is compile-time evaluated; using the already-declared typed ID does not request runtime base58 evaluation. In contrast, the original inline pubkey macro expands to the constfn call in an ordinary runtime expression, and firstcandidate emitted that call. No flags/profile/layout/source-coordinate change is involved.

Independent standard base58 positional decoding of the exact43-byte token produces `069b8857feab8184fb687f634618c035dac439dc1aeb3b5598a0f00000000001`, byte-identical to original object at1793224..1793256. All full dependency sources used to prove the export/type/const chain are copied and individually checked against the retained252-package locked-source witness. No dependency library is executed.

## Exact source and limits

`const-only.patch` is one expression substitution relative to f290 source, not relative to active selected source1bd. `bindings.json` explicitly carries actual selected baseline37 and immediate f290 baseline37. The combined proposed source therefore includes previously reviewed6019 holderPDA and6091 WSOL/owned-error changes plus this const-only refinement; active managed e949/source1bd remains untouched. The earlier source accountconstraint's own macro and other calls are unchanged. No artificial line/column directive or padding; source coordinates remain natural.

This proves source language/type/value intent, not resulting optimizer instructions or whole-original equivalence. A separately reviewed single build must confirm emitted WSOL comparison no longer traverses runtime base58 and retains the two guard/owned-error paths and6030/2006/6092 bounds. No alternate const implementation is prepared or tested. Run `python3 -B verify.py` and strict `verify_manifest.py --seal SEAL` using saved files only.
