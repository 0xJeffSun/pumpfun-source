from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--seal',required=True);a=p.parse_args();r=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(r/'manifest.json')==a.seal
m=json.loads((r/'manifest.json').read_text());actual={}
for p in r.rglob('*'):
 assert not p.is_symlink(),str(p)
 assert p.name not in {'__pycache__','.pytest_cache'},str(p)
 if p.is_file() and p.relative_to(r).as_posix() not in {'manifest.json','manifest.sha256'}:actual[p.relative_to(r).as_posix()]=h(p)
assert actual==m['files']
assert sorted(x.relative_to(r).as_posix() for x in r.rglob('*') if x.is_dir())==m['directories']
assert (r/'manifest.sha256').read_text()==a.seal+'  manifest.json\n'
print('strict manifest PASS',len(actual))
