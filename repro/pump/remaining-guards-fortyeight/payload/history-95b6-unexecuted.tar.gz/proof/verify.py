from pathlib import Path
import json,gzip,hashlib,tomllib,sys
P=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text());b=J(P/'bindings.json');D=P/'dependencies'
d=json.loads(gzip.decompress((P/'dependency-inventory.json.gz').read_bytes()))
for n,v in b['dependencies'].items():
 assert H(D/n)==v['sha256']
 assert [h for p in d['packages'] for t in p['source_trees_observed'] for name,h in t['source_files_sha256'].items() if t['path']+'/'+name==v['path']]==[v['sha256']]
lock=tomllib.loads((P/'source/Cargo.lock').read_text())
for n,v in [('anchor-spl','0.31.1'),('anchor-lang','0.31.1'),('spl-token','7.0.0'),('solana-program','2.3.0'),('solana-pubkey','2.4.0')]:assert [p['version'] for p in lock['package'] if p['name']==n]==[v]
pump=tomllib.loads((P/'source/Cargo.toml').read_text());assert pump['dependencies']['anchor-spl'].get('default-features',True)
anchor=tomllib.loads((D/'anchor-spl-0.31.1/Cargo.toml').read_text());assert 'token'in anchor['features']['default'] and anchor['dependencies']['spl-token']['version']=='7'
read=lambda n:(D/n).read_text()
assert '#[cfg(feature = "token")]' in read('anchor-spl-0.31.1/src/lib.rs') and 'pub mod token;' in read('anchor-spl-0.31.1/src/lib.rs')
assert 'pub use spl_token;' in read('anchor-spl-0.31.1/src/token.rs')
assert 'pub mod native_mint;'in read('spl-token-7.0.0/src/lib.rs')
token='So11111111111111111111111111111111111111112'
assert 'solana_program::declare_id!("'+token+'");'in read('spl-token-7.0.0/src/native_mint.rs')
assert 'pub const ID: $crate::Pubkey = $crate::Pubkey::from_str_const($address);'in read('solana-pubkey-2.4.0/src/lib.rs')
assert 'solana_pubkey as pubkey'in read('solana-program-2.3.0/src/lib.rs') and 'pub use solana_pubkey::{declare_deprecated_id, declare_id, pubkey};'in read('solana-program-2.3.0/src/lib.rs')
assert 'pub use solana_program::pubkey::Pubkey;'in read('anchor-lang-0.31.1/src/lib.rs')
assert 'pub const fn from_str_const(s: &str) -> Self'in read('solana-pubkey-2.4.0/src/lib.rs') and 'let id_array = five8_const::decode_32_const(s);'in read('solana-pubkey-2.4.0/src/lib.rs')
assert 'pub const fn decode_32_const(encoded: &str)'in read('five8_const-0.1.4/src/lib.rs')
v=0
for c in token:v=v*58+'123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'.index(c)
assert H(P/'original.so')=='7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d';assert v.to_bytes(32,'big')==(P/'original.so').read_bytes()[1793224:1793256]
old=(P/'source/admin_cto.before.rs').read_text();new=(P/'source/admin_cto.combined.rs').read_text();needle='||a.bonding_curve.quote_mint==anchor_lang::solana_program::pubkey!("'+token+'")';assert old.count(needle)==1 and new==old.replace(needle,'||a.bonding_curve.quote_mint==anchor_spl::token::spl_token::native_mint::ID')
assert H(P/'source/admin_cto.before.rs')==b['first_source'] and H(P/'source/admin_cto.combined.rs')==b['proposal']
assert new.count('return Err(err(6092));')==2
print(json.dumps({'passed':True,'chosen':'anchor_spl::token::spl_token::native_mint::ID','type':'same solana-pubkey2.4.0 Pubkey as Anchorprelude','const_context':True,'value_hex':v.to_bytes(32,'big').hex(),'changes':1,'builds':0,'runtime_executions':0}))
