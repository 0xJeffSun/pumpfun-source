# V4 original-only admission — all 16 cases pass

All16 frozen ordinary three-curve cases succeeded against the captured original Pump, invoked by the genuine captured AMM. This is **16 original transactions and16 ordinary verified signatures**, with **zero candidate transactions and zero paired comparisons**. Each packet is1,128 bytes and includes the exact standard600,000-CU instruction before the unchanged AMM call. Actual consumption ranged208,904–220,447 CU.

Every expected assertion passed: genuine AMM-produced `[1,0,2]` / `[2,0,1]`,28 Pump accounts, three TradeEvents in expected mint/direction order, both carried-token transfers under the previous curve's correct authority, valid single signature and packet limit. Each case used a fresh VM and the frozen driver's default signature/blockhash/history settings. No source, fixture, assertion or budget adaptation occurred during this run. The earlier V3 default-budget failure remains sealed separately and is not counted as accepted.

`summary.json` binds all48 per-case files: verified transaction/before state, raw VM result/logs/after state, and decoded receipt. Before/after evidence/harness/runtime binding files are identical. `saved-transaction-checks.json` independently decoded all16 saved messages, verified16 signatures and checked the exact compute instruction/program/data/indices without executing or signing another transaction. The full V4 proposal is archived unchanged with its original seal.

These are original-only fixture-admission results. Candidate behavior and whole-source/ELF equivalence remain untested by this run. Native/transitive/framework/excluded-mode limits remain those of the frozen proposal; no acceptance counts beyond these16 original normal cases are implied. Root review is required before a separate candidate-only comparison stage.

Run `python3 -B verify.py` for portable seal, receipt, metadata and input checks; use the recorded solders environment with `--signatures` to independently decode and verify the saved messages as well. Neither command executes a VM or creates a signature.
