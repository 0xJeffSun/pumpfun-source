#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,base64,tarfile
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((P/n).read_text());p=argparse.ArgumentParser();p.add_argument('--signatures',action='store_true');a=p.parse_args()
m=load('manifest-sha256.json');actual={str(q.relative_to(P))for q in P.rglob('*')if q.is_file()and q.name!='manifest-sha256.json'};assert actual==set(m)
for n,d in m.items():b=(P/n).read_bytes();assert sha(b)==d['sha256']and len(b)==d['bytes'],n
s=load('summary.json');ex=load('execution.json');sig=load('saved-transaction-checks.json');assert s['stage']=='original'and s['all_pass']and s['case_count']==s['transaction_executions']==s['verified_signatures']==16 and len(s['receipt_sha256'])==48
assert ex['returncode']==0 and ex['candidate_transactions']==ex['paired_comparisons']==ex['v4_retries']==0 and ex['original_cases_passed']==16
assert (P/'bindings-before.json').read_bytes()==(P/'bindings-after.json').read_bytes()
assert sha((P/'summary.json').read_bytes())==ex['summary_sha256']and sha((P/'bindings-after.json').read_bytes())==ex['after_binding_sha256']==ex['before_binding_sha256']
for n,h in s['receipt_sha256'].items():assert sha((P/n).read_bytes())==h
for index,r in enumerate(s['rows']):
 d=load(r['file']);prefix=r['file'][:-5];tx=load(prefix+'.transaction.json');raw=load(prefix+'.raw-result.json');b=base64.b64decode(d['transaction_base64'])
 assert d['case']==tx['case']==raw['case']and d['error']is None and d['all_assertions_pass']and all(d['assertions'].values())and not r['mismatches']
 assert d['transaction_base64']==tx['transaction_base64']and d['before']==tx['before']and d['after']==raw['after']and d['raw_metadata']==raw['raw_metadata']and d['logs']==raw['logs']
 assert sha(b)==d['transaction_sha256']==tx['transaction_sha256']==sig['cases'][index]['transaction_sha256']and len(b)==1128 and d['verified_signature_count']==1
 expected={'instruction_index':0,'amm_instruction_index':1,'program_id':'ComputeBudget111111111111111111111111111111','data_hex':'02c0270900','accounts':[],'compute_unit_limit':600000}
 assert d['compute_budget_instruction']==tx['compute_budget_instruction']==expected
 assert len(d['pump_calls'])==1 and d['pump_calls'][0]['flags']==d['case']['flags']and len(d['pump_calls'][0]['accounts'])==28
 assert sig['cases'][index]['signatures_valid']and sig['cases'][index]['compute_instruction_exact']
 if a.signatures:
  from solders.transaction import Transaction
  t=Transaction.from_bytes(b);assert len(t.signatures)==1 and all(t.verify_with_results())and len(t.message.instructions)==2
  first,second=t.message.instructions;assert str(t.message.account_keys[first.program_id_index])==expected['program_id']and bytes(first.data).hex()==expected['data_hex']and len(first.accounts)==0
  assert str(t.message.account_keys[second.program_id_index])=='pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA'
with tarfile.open(P/'frozen-v4-proposal.tar.gz')as t:
 raw=t.extractfile('proposal-v4/manifest-sha256.json').read();assert sha(raw)==ex['proposal_sha256'];inner=json.loads(raw)
 for n,d in inner.items():assert sha(t.extractfile('proposal-v4/'+n).read())==d['sha256']
print(json.dumps({'pass':True,'payloads':len(m),'original_cases_passed':16,'original_transactions':16,'signatures':16,'paired_comparisons':0,'candidate_transactions':0,'saved_signatures_rechecked':a.signatures}))
