029e38: r6 = r4
029e40: r9 = r3
029e48: r7 = r1
029e50: r8 = *(u64 *)(r6 + 0x8)
029e58: if r8 != 0x0 goto +0x4 ; branch 0x29e80
029e60: r1 = 0xa800000000 ll
029e70: *(u64 *)(r7 + 0x0) = r1
029e78: goto +0x82 ; branch 0x2a290
029e80: *(u64 *)(r10 - 0x5e8) = r2
029e88: r2 = *(u64 *)(r9 + 0x48)
029e90: r1 = r10
029e98: r1 += -0x328
029ea0: call 0x9904 ; call 0x766c8 / window 773
029ea8: w1 = *(u32 *)(r10 - 0x328)
029eb0: if r1 != 0x16 goto +0x4c ; branch 0x2a118
029eb8: r2 = *(u64 *)(r9 + 0x50)
029ec0: r1 = r10
029ec8: r1 += -0x328
029ed0: call 0x98fe ; call 0x766c8 / window 773
029ed8: w1 = *(u32 *)(r10 - 0x328)
029ee0: if r1 == 0x16 goto +0x1 ; branch 0x29ef0
029ee8: goto +0x45 ; branch 0x2a118
029ef0: *(u64 *)(r10 - 0x5f0) = r6
029ef8: r2 = *(u64 *)(r9 + 0x38)
029f00: r1 = r10
029f08: r1 += -0x328
029f10: *(u64 *)(r10 - 0x5f8) = r2
029f18: r6 = *(u64 *)(r10 - 0x5e8)
029f20: r3 = r6
029f28: call -0x3460 ; call 0xfc30 / window 275
029f30: w1 = *(u32 *)(r10 - 0x328)
029f38: if r1 == 0x16 goto +0x1 ; branch 0x29f48
029f40: goto +0x48 ; branch 0x2a188
029f48: *(u64 *)(r10 - 0x610) = r8
029f50: *(u64 *)(r10 - 0x600) = r7
029f58: r1 = r10
029f60: r1 += -0x570
029f68: r2 = r6
029f70: call 0xb85a ; call 0x86248 / window 990
029f78: *(u64 *)(r10 - 0x608) = r9
029f80: r9 = *(u64 *)(r9 + 0x40)
029f88: r2 = *(u64 *)(r9 + 0x0)
029f90: r8 = *(u64 *)(r10 - 0x570)
029f98: r7 = *(u64 *)(r10 - 0x568)
029fa0: r1 = r10
029fa8: r1 += -0x580
029fb0: call 0xb852 ; call 0x86248 / window 990
029fb8: *(u64 *)(r10 - 0x310) = r7
029fc0: *(u64 *)(r10 - 0x318) = r8
029fc8: r1 = 0x8
029fd0: *(u64 *)(r10 - 0x320) = r1
029fd8: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
029fe8: *(u64 *)(r10 - 0x328) = r1
029ff0: r1 = *(u64 *)(r10 - 0x578)
029ff8: *(u64 *)(r10 - 0x300) = r1
02a000: r1 = *(u64 *)(r10 - 0x580)
02a008: *(u64 *)(r10 - 0x308) = r1
02a010: r1 = r10
02a018: r1 += -0x560
02a020: r4 = r10
02a028: r4 += -0x328
02a030: r2 = r6
02a038: r6 = *(u64 *)(r10 - 0x5f8)
02a040: r3 = r6
02a048: r5 = 0x3
02a050: call -0x3491 ; call 0xfbd0 / window 273
02a058: w1 = *(u32 *)(r10 - 0x560)
02a060: if r1 == 0x16 goto +0x1 ; branch 0x2a070
02a068: goto +0x31 ; branch 0x2a1f8
02a070: r8 = r9
02a078: r1 = r10
02a080: r1 += -0x328
02a088: r2 = r6
02a090: call 0x3be5 ; call 0x47fc0 / window 419
02a098: w9 = *(u32 *)(r10 - 0x220)
02a0a0: r7 = *(u64 *)(r10 - 0x600)
02a0a8: if r9 != 0x2 goto +0x40 ; branch 0x2a2b0
02a0b0: r1 = *(u64 *)(r10 - 0x310)
02a0b8: *(u64 *)(r10 - 0x418) = r1
02a0c0: r2 = *(u64 *)(r10 - 0x318)
02a0c8: *(u64 *)(r10 - 0x420) = r2
02a0d0: r3 = *(u64 *)(r10 - 0x320)
02a0d8: *(u64 *)(r10 - 0x428) = r3
02a0e0: r4 = *(u64 *)(r10 - 0x328)
02a0e8: *(u64 *)(r10 - 0x430) = r4
02a0f0: *(u64 *)(r7 + 0x18) = r1
02a0f8: *(u64 *)(r7 + 0x10) = r2
02a100: *(u64 *)(r7 + 0x8) = r3
02a108: *(u64 *)(r7 + 0x0) = r4
02a110: goto +0x2e ; branch 0x2a288
02a118: w2 = *(u32 *)(r10 - 0x30c)
02a120: *(u32 *)(r10 - 0x548) = w2
02a128: r3 = *(u64 *)(r10 - 0x314)
02a130: *(u64 *)(r10 - 0x550) = r3
02a138: r4 = *(u64 *)(r10 - 0x31c)
02a140: *(u64 *)(r10 - 0x558) = r4
02a148: r5 = *(u64 *)(r10 - 0x324)
02a150: *(u64 *)(r10 - 0x560) = r5
02a158: *(u32 *)(r7 + 0x1c) = w2
02a160: *(u64 *)(r7 + 0x14) = r3
02a168: *(u64 *)(r7 + 0xc) = r4
02a170: *(u64 *)(r7 + 0x4) = r5
02a178: *(u32 *)(r7 + 0x0) = w1
02a180: goto +0x21 ; branch 0x2a290
02a188: w2 = *(u32 *)(r10 - 0x30c)
02a190: *(u32 *)(r10 - 0x548) = w2
02a198: r3 = *(u64 *)(r10 - 0x314)
02a1a0: *(u64 *)(r10 - 0x550) = r3
02a1a8: r4 = *(u64 *)(r10 - 0x31c)
02a1b0: *(u64 *)(r10 - 0x558) = r4
02a1b8: r5 = *(u64 *)(r10 - 0x324)
02a1c0: *(u64 *)(r10 - 0x560) = r5
02a1c8: *(u32 *)(r7 + 0x1c) = w2
02a1d0: *(u64 *)(r7 + 0x14) = r3
02a1d8: *(u64 *)(r7 + 0xc) = r4
02a1e0: *(u64 *)(r7 + 0x4) = r5
02a1e8: *(u32 *)(r7 + 0x0) = w1
02a1f0: goto +0x12 ; branch 0x2a288
02a1f8: w2 = *(u32 *)(r10 - 0x544)
02a200: *(u32 *)(r10 - 0x419) = w2
02a208: r2 = *(u64 *)(r10 - 0x54b)
02a210: *(u64 *)(r10 - 0x420) = r2
02a218: r2 = *(u64 *)(r10 - 0x55b)
02a220: *(u64 *)(r10 - 0x430) = r2
02a228: r3 = *(u64 *)(r10 - 0x553)
02a230: *(u64 *)(r10 - 0x428) = r3
02a238: w4 = *(u8 *)(r10 - 0x55c)
02a240: w5 = *(u32 *)(r10 - 0x419)
02a248: r0 = *(u64 *)(r10 - 0x600)
02a250: *(u32 *)(r0 + 0x1c) = w5
02a258: r5 = *(u64 *)(r10 - 0x420)
02a260: *(u64 *)(r0 + 0x15) = r5
02a268: *(u64 *)(r0 + 0xd) = r3
02a270: *(u64 *)(r0 + 0x5) = r2
02a278: *(u8 *)(r0 + 0x4) = w4
02a280: *(u32 *)(r0 + 0x0) = w1
02a288: r6 = *(u64 *)(r10 - 0x5f0)
02a290: r6 += 0x10
02a298: r1 = r6
02a2a0: call -0x4d50 ; call 0x3828 / window 85
02a2a8: exit
02a2b0: r6 = r10
02a2b8: r6 += -0x430
02a2c0: r2 = r10
02a2c8: r2 += -0x328
02a2d0: r1 = r6
02a2d8: r3 = 0x108
02a2e0: call 0xdd96 ; call 0x98f98 / window 1246
02a2e8: r1 = r10
02a2f0: r1 += -0x454
02a2f8: r2 = r10
02a300: r2 += -0x21c
02a308: r3 = 0x24
02a310: call 0xdd90 ; call 0x98f98 / window 1246
02a318: r1 = r10
02a320: r1 += -0x560
02a328: r2 = r6
02a330: r3 = 0x108
02a338: call 0xdd8b ; call 0x98f98 / window 1246
02a340: *(u32 *)(r10 - 0x458) = w9
02a348: r1 = r8
02a350: r2 = *(u64 *)(r1 + 0x0)
02a358: r1 = r10
02a360: r1 += -0x53c
02a368: call -0x4ecc ; call 0x2d10 / window 44
02a370: if r0 != 0x0 goto +0x1 ; branch 0x2a380
02a378: goto +0x5 ; branch 0x2a3a8
02a380: r1 = 0xf00000000 ll
02a390: *(u64 *)(r7 + 0x0) = r1
02a398: r6 = *(u64 *)(r10 - 0x5f0)
02a3a0: goto +0xa1 ; branch 0x2a8b0
02a3a8: r1 = *(u64 *)(r10 - 0x608)
02a3b0: r9 = *(u64 *)(r1 + 0x68)
02a3b8: r1 = r10
02a3c0: r1 += -0x328
02a3c8: r2 = r9
02a3d0: call -0x34de ; call 0xfce8 / window 277
02a3d8: w1 = *(u32 *)(r10 - 0x328)
02a3e0: r6 = *(u64 *)(r10 - 0x5f0)
02a3e8: if r1 == 0x16 goto +0x1 ; branch 0x2a3f8
02a3f0: goto +0x8a ; branch 0x2a848
02a3f8: r3 = *(u64 *)(r9 + 0x0)
02a400: r1 = r10
02a408: r1 += -0x328
02a410: r2 = r8
02a418: call -0x34fe ; call 0xfc30 / window 275
02a420: w1 = *(u32 *)(r10 - 0x328)
02a428: if r1 == 0x16 goto +0x1 ; branch 0x2a438
02a430: goto +0x82 ; branch 0x2a848
02a438: r2 = *(u64 *)(r8 + 0x10)
02a440: r2 += 0x10
02a448: r1 = r10
02a450: r1 += -0x590
02a458: r3 = 0x9f118 ll ; data b"\x00\x00\x00\x00\xe2\xa7\t\x00&\x00\x00\x00\x00\x00\x00\x00L\x00\x00\x00O\x00\x00\x00\x00\x00\x00\x00\xe2\xa7\t\x00&\x00\x00\x00\x00\x00\x00\x00\xa9\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x002\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x00/\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00"
02a468: call -0x4d72 ; call 0x38e0 / window 87
02a470: r1 = *(u64 *)(r10 - 0x590)
02a478: r2 = *(u64 *)(r1 + 0x0)
02a480: r3 = *(u64 *)(r1 + 0x8)
02a488: r8 = *(u64 *)(r10 - 0x588)
02a490: r1 = r10
02a498: r1 += -0x328
02a4a0: call 0x577f ; call 0x560a0 / window 451
02a4a8: w9 = *(u32 *)(r10 - 0x328)
02a4b0: if r9 == 0x2 goto +0x83 ; branch 0x2a8d0
02a4b8: r1 = r10
02a4c0: r1 += -0x430
02a4c8: *(u64 *)(r10 - 0x5f8) = r1
02a4d0: r2 = r10
02a4d8: r2 += -0x324
02a4e0: r3 = 0x24
02a4e8: call 0xdd55 ; call 0x98f98 / window 1246
02a4f0: r1 = r10
02a4f8: r1 += -0x1d0
02a500: r2 = r10
02a508: r2 += -0x300
02a510: r3 = 0x30
02a518: call 0xdd4f ; call 0x98f98 / window 1246
02a520: r1 = r10
02a528: r1 += -0x1f4
02a530: r2 = *(u64 *)(r10 - 0x5f8)
02a538: r3 = 0x24
02a540: call 0xdd4a ; call 0x98f98 / window 1246
02a548: *(u32 *)(r10 - 0x1f8) = w9
02a550: r1 = *(u64 *)(r8 + 0x0)
02a558: r1 += -0x1
02a560: *(u64 *)(r8 + 0x0) = r1
02a568: w1 = *(u32 *)(r10 - 0x4ac)
02a570: if r1 == 0x6 goto +0x2 ; branch 0x2a588
02a578: r1 |= 0x4
02a580: if r1 == 0x4 goto +0x79 ; branch 0x2a950
02a588: r8 = *(u64 *)(r10 - 0x608)
02a590: r3 = *(u64 *)(r8 + 0x48)
02a598: r1 = r10
02a5a0: r1 += -0x328
02a5a8: r2 = r10
02a5b0: r2 += -0x1f8
02a5b8: call -0x360c ; call 0xf560 / window 270
02a5c0: w1 = *(u32 *)(r10 - 0x328)
02a5c8: if r1 == 0x16 goto +0x1 ; branch 0x2a5d8
02a5d0: goto +0x4e ; branch 0x2a848
02a5d8: r9 = *(u64 *)(r8 + 0x30)
02a5e0: r1 = r9
02a5e8: call 0xb57e ; call 0x851e0 / window 981
02a5f0: if r0 != 0x0 goto +0x1 ; branch 0x2a600
02a5f8: goto +0xa4 ; branch 0x2ab20
02a600: *(u64 *)(r10 - 0x5f8) = r9
02a608: r9 = *(u64 *)(r8 + 0x0)
02a610: if r9 == 0x0 goto +0x117 ; branch 0x2aed0
02a618: r1 = *(u64 *)(r8 + 0x68)
02a620: r5 = *(u64 *)(r1 + 0x0)
02a628: r1 = *(u64 *)(r8 + 0x50)
02a630: *(u64 *)(r10 - 0x620) = r1
02a638: r8 = *(u64 *)(r8 + 0x40)
02a640: r3 = *(u64 *)(r9 + 0x0)
02a648: r4 = *(u64 *)(r8 + 0x0)
02a650: r2 = *(u64 *)(r1 + 0x0)
02a658: r1 = r10
02a660: r1 += -0x430
02a668: *(u64 *)(r10 - 0x618) = r1
02a670: call 0x8047 ; call 0x6a8b0 / window 591
02a678: r1 = r10
02a680: r1 += -0x60
02a688: *(u64 *)(r10 - 0x630) = r1
02a690: r2 = *(u64 *)(r10 - 0x620)
02a698: call -0x3fd9 ; call 0xa7d8 / window 217
02a6a0: r1 = r10
02a6a8: r1 += -0x30
02a6b0: *(u64 *)(r10 - 0x628) = r1
02a6b8: r2 = r9
02a6c0: call -0x3fde ; call 0xa7d8 / window 217
02a6c8: r9 = r10
02a6d0: r9 += -0x1a0
02a6d8: r1 = r9
02a6e0: r2 = r8
02a6e8: call -0x3fe3 ; call 0xa7d8 / window 217
02a6f0: r8 = r10
02a6f8: r8 += -0xb0
02a700: r1 = r8
02a708: r2 = *(u64 *)(r10 - 0x5f8)
02a710: call -0x3fe8 ; call 0xa7d8 / window 217
02a718: r1 = r10
02a720: r1 += -0x328
02a728: *(u64 *)(r10 - 0x620) = r1
02a730: r2 = *(u64 *)(r10 - 0x630)
02a738: r3 = 0x30
02a740: call 0xdd0a ; call 0x98f98 / window 1246
02a748: r1 = r10
02a750: r1 += -0x2f8
02a758: r2 = *(u64 *)(r10 - 0x628)
02a760: r3 = 0x30
02a768: call 0xdd05 ; call 0x98f98 / window 1246
02a770: r1 = r10
02a778: r1 += -0x2c8
02a780: r2 = r9
02a788: r3 = 0x30
02a790: call 0xdd00 ; call 0x98f98 / window 1246
02a798: r1 = r10
02a7a0: r1 += -0x298
02a7a8: r2 = r8
02a7b0: r3 = 0x30
02a7b8: call 0xdcfb ; call 0x98f98 / window 1246
02a7c0: r1 = r10
02a7c8: r1 += -0xe0
02a7d0: r2 = *(u64 *)(r10 - 0x618)
02a7d8: r3 = *(u64 *)(r10 - 0x620)
02a7e0: r4 = 0x4
02a7e8: call 0xb796 ; call 0x864a0 / window 996
02a7f0: w1 = *(u32 *)(r10 - 0xe0)
02a7f8: if r1 == 0x16 goto +0x1 ; branch 0x2a808
02a800: goto +0x11d ; branch 0x2b0f0
02a808: r1 = r10
02a810: r1 += -0x328
02a818: call -0x4e35 ; call 0x3678 / window 77
02a820: r1 = r10
02a828: r1 += -0x430
02a830: call -0x4ee2 ; call 0x3128 / window 61
02a838: r9 = *(u64 *)(r10 - 0x5f8)
02a840: goto +0xb0 ; branch 0x2adc8
02a848: w2 = *(u32 *)(r10 - 0x30c)
02a850: *(u32 *)(r10 - 0x418) = w2
02a858: r3 = *(u64 *)(r10 - 0x314)
02a860: *(u64 *)(r10 - 0x420) = r3
02a868: r4 = *(u64 *)(r10 - 0x31c)
02a870: *(u64 *)(r10 - 0x428) = r4
02a878: r5 = *(u64 *)(r10 - 0x324)
02a880: *(u64 *)(r10 - 0x430) = r5
02a888: *(u32 *)(r7 + 0x1c) = w2
02a890: *(u64 *)(r7 + 0x14) = r3
02a898: *(u64 *)(r7 + 0xc) = r4
02a8a0: *(u64 *)(r7 + 0x4) = r5
02a8a8: *(u32 *)(r7 + 0x0) = w1
02a8b0: r1 = r10
02a8b8: r1 += -0x518
02a8c0: call -0x4f05 ; call 0x30a0 / window 59
02a8c8: goto -0xc8 ; branch 0x2a290
02a8d0: r1 = *(u64 *)(r10 - 0x308)
02a8d8: *(u64 *)(r10 - 0x414) = r1
02a8e0: r2 = *(u64 *)(r10 - 0x310)
02a8e8: *(u64 *)(r10 - 0x41c) = r2
02a8f0: r3 = *(u64 *)(r10 - 0x318)
02a8f8: *(u64 *)(r10 - 0x424) = r3
02a900: r4 = *(u64 *)(r10 - 0x320)
02a908: *(u64 *)(r10 - 0x42c) = r4
02a910: *(u64 *)(r7 + 0x18) = r1
02a918: *(u64 *)(r7 + 0x10) = r2
02a920: *(u64 *)(r7 + 0x8) = r3
02a928: *(u64 *)(r7 + 0x0) = r4
02a930: r1 = *(u64 *)(r8 + 0x0)
02a938: r1 += -0x1
02a940: *(u64 *)(r8 + 0x0) = r1
02a948: goto -0x14 ; branch 0x2a8b0
02a950: r6 = *(u64 *)(r10 - 0x608)
02a958: r9 = *(u64 *)(r6 + 0x8)
02a960: if r9 == 0x0 goto +0x53 ; branch 0x2ac00
02a968: r1 = r10
02a970: r1 += -0x5a0
02a978: r7 = *(u64 *)(r10 - 0x5e8)
02a980: r2 = r7
02a988: call 0xb717 ; call 0x86248 / window 990
02a990: r1 = *(u64 *)(r6 + 0x40)
02a998: r2 = *(u64 *)(r1 + 0x0)
02a9a0: r6 = *(u64 *)(r10 - 0x5a0)
02a9a8: r8 = *(u64 *)(r10 - 0x598)
02a9b0: r1 = r10
02a9b8: r1 += -0x5b0
02a9c0: call 0xb710 ; call 0x86248 / window 990
02a9c8: r1 = 0x7
02a9d0: *(u64 *)(r10 - 0x2f0) = r1
02a9d8: r1 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
02a9e8: *(u64 *)(r10 - 0x2f8) = r1
02a9f0: *(u64 *)(r10 - 0x310) = r8
02a9f8: *(u64 *)(r10 - 0x318) = r6
02aa00: r1 = 0x8
02aa08: *(u64 *)(r10 - 0x320) = r1
02aa10: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
02aa20: *(u64 *)(r10 - 0x328) = r1
02aa28: r1 = *(u64 *)(r10 - 0x5a8)
02aa30: *(u64 *)(r10 - 0x300) = r1
02aa38: r1 = *(u64 *)(r10 - 0x5b0)
02aa40: *(u64 *)(r10 - 0x308) = r1
02aa48: r1 = r10
02aa50: r1 += -0x430
02aa58: r4 = r10
02aa60: r4 += -0x328
02aa68: r2 = r7
02aa70: r3 = r9
02aa78: r5 = 0x4
02aa80: call -0x35d7 ; call 0xfbd0 / window 273
02aa88: w1 = *(u32 *)(r10 - 0x430)
02aa90: if r1 == 0x16 goto +0x1 ; branch 0x2aaa0
02aa98: goto +0x2f ; branch 0x2ac18
02aaa0: r7 = *(u64 *)(r10 - 0x600)
02aaa8: r1 = *(u64 *)(r10 - 0x610)
02aab0: r6 = *(u64 *)(r10 - 0x5f0)
02aab8: if r1 > 0x1 goto +0xda ; branch 0x2b190
02aac0: r1 = *(u64 *)(r10 - 0x1d0)
02aac8: if r1 != 0x0 goto +0xd8 ; branch 0x2b190
02aad0: r8 = *(u64 *)(r10 - 0x608)
02aad8: r1 = *(u64 *)(r8 + 0x48)
02aae0: r2 = *(u64 *)(r1 + 0x0)
02aae8: r1 = r10
02aaf0: r1 += -0x55c
02aaf8: call 0x977f ; call 0x766f8 / window 774
02ab00: if r0 != 0x0 goto -0xa6 ; branch 0x2a5d8
02ab08: r1 = 0x700000000 ll
02ab18: goto +0xd0 ; branch 0x2b1a0
02ab20: r4 = *(u64 *)(r8 + 0x0)
02ab28: r2 = *(u64 *)(r8 + 0x40)
02ab30: r1 = *(u64 *)(r8 + 0x68)
02ab38: w3 = *(u32 *)(r10 - 0x4ac)
02ab40: *(u64 *)(r10 - 0xff8) = r3
02ab48: r3 = 0x0
02ab50: *(u64 *)(r10 - 0xff0) = r3
02ab58: *(u64 *)(r10 - 0x1000) = r1
02ab60: r1 = r10
02ab68: r1 += -0x328
02ab70: r5 = r10
02ab78: r3 = r9
02ab80: call 0x5566 ; call 0x556b8 / window 450
02ab88: w1 = *(u32 *)(r10 - 0x2e0)
02ab90: if r1 != 0x2 goto +0x23 ; branch 0x2acb0
02ab98: r1 = *(u64 *)(r10 - 0x310)
02aba0: *(u64 *)(r10 - 0x418) = r1
02aba8: r2 = *(u64 *)(r10 - 0x318)
02abb0: *(u64 *)(r10 - 0x420) = r2
02abb8: r3 = *(u64 *)(r10 - 0x320)
02abc0: *(u64 *)(r10 - 0x428) = r3
02abc8: r4 = *(u64 *)(r10 - 0x328)
02abd0: *(u64 *)(r10 - 0x430) = r4
02abd8: *(u64 *)(r7 + 0x18) = r1
02abe0: *(u64 *)(r7 + 0x10) = r2
02abe8: *(u64 *)(r7 + 0x8) = r3
02abf0: *(u64 *)(r7 + 0x0) = r4
02abf8: goto -0x6a ; branch 0x2a8b0
02ac00: r1 = 0xa700000000 ll
02ac10: goto -0x111 ; branch 0x2a390
02ac18: w2 = *(u32 *)(r10 - 0x414)
02ac20: *(u32 *)(r10 - 0x99) = w2
02ac28: r2 = *(u64 *)(r10 - 0x41b)
02ac30: *(u64 *)(r10 - 0xa0) = r2
02ac38: r2 = *(u64 *)(r10 - 0x42b)
02ac40: *(u64 *)(r10 - 0xb0) = r2
02ac48: r3 = *(u64 *)(r10 - 0x423)
02ac50: *(u64 *)(r10 - 0xa8) = r3
02ac58: w4 = *(u8 *)(r10 - 0x42c)
02ac60: w5 = *(u32 *)(r10 - 0x99)
02ac68: r0 = *(u64 *)(r10 - 0x600)
02ac70: *(u32 *)(r0 + 0x1c) = w5
02ac78: r5 = *(u64 *)(r10 - 0xa0)
02ac80: *(u64 *)(r0 + 0x15) = r5
02ac88: *(u64 *)(r0 + 0xd) = r3
02ac90: *(u64 *)(r0 + 0x5) = r2
02ac98: *(u8 *)(r0 + 0x4) = w4
02aca0: *(u32 *)(r0 + 0x0) = w1
02aca8: goto -0x123 ; branch 0x2a398
02acb0: r1 = *(u64 *)(r10 - 0x29c)
02acb8: *(u64 *)(r10 - 0xb0) = r1
02acc0: r1 = *(u64 *)(r10 - 0x294)
02acc8: *(u64 *)(r10 - 0xa8) = r1
02acd0: r1 = *(u64 *)(r10 - 0x28c)
02acd8: *(u64 *)(r10 - 0xa0) = r1
02ace0: r1 = *(u64 *)(r10 - 0x284)
02ace8: *(u64 *)(r10 - 0x98) = r1
02acf0: w1 = *(u32 *)(r10 - 0x4ac)
02acf8: if r1 != 0x4 goto +0x19 ; branch 0x2adc8
02ad00: w1 = *(u32 *)(r10 - 0x2a0)
02ad08: if r1 == 0x1 goto +0x1 ; branch 0x2ad18
02ad10: goto +0x16 ; branch 0x2adc8
02ad18: r1 = *(u64 *)(r10 - 0x98)
02ad20: *(u64 *)(r10 - 0x310) = r1
02ad28: r1 = *(u64 *)(r10 - 0xa0)
02ad30: *(u64 *)(r10 - 0x318) = r1
02ad38: r1 = *(u64 *)(r10 - 0xa8)
02ad40: *(u64 *)(r10 - 0x320) = r1
02ad48: r1 = *(u64 *)(r10 - 0xb0)
02ad50: *(u64 *)(r10 - 0x328) = r1
02ad58: r1 = 0xa7
02ad60: r2 = *(u64 *)(r8 + 0x8)
02ad68: if r2 == 0x0 goto +0x6 ; branch 0x2ada0
02ad70: r2 = *(u64 *)(r2 + 0x0)
02ad78: r1 = r10
02ad80: r1 += -0x328
02ad88: call -0x5010 ; call 0x2d10 / window 44
02ad90: r1 = 0xbc
02ad98: if r0 == 0x0 goto +0x5 ; branch 0x2adc8
02ada0: r2 = *(u64 *)(r10 - 0x600)
02ada8: *(u32 *)(r2 + 0x4) = w1
02adb0: r1 = 0x0
02adb8: *(u32 *)(r2 + 0x0) = w1
02adc0: goto -0x146 ; branch 0x2a398
02adc8: r2 = *(u64 *)(r9 + 0x10)
02add0: r2 += 0x10
02add8: r1 = r10
02ade0: r1 += -0x5c0
02ade8: r3 = 0x9f130 ll ; data b"\x00\x00\x00\x00\xe2\xa7\t\x00&\x00\x00\x00\x00\x00\x00\x00\xa9\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x002\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x00/\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00"
02adf8: call -0x4ea4 ; call 0x38e0 / window 87
02ae00: r1 = *(u64 *)(r10 - 0x5c0)
02ae08: r2 = *(u64 *)(r1 + 0x0)
02ae10: r3 = *(u64 *)(r1 + 0x8)
02ae18: r6 = *(u64 *)(r10 - 0x5b8)
02ae20: r1 = r10
02ae28: r1 += -0x328
02ae30: call 0x5693 ; call 0x562d0 / window 452
02ae38: w9 = *(u32 *)(r10 - 0x2e0)
02ae40: if r9 != 0x2 goto +0x14 ; branch 0x2aee8
02ae48: r1 = *(u64 *)(r10 - 0x310)
02ae50: *(u64 *)(r10 - 0x98) = r1
02ae58: r2 = *(u64 *)(r10 - 0x318)
02ae60: *(u64 *)(r10 - 0xa0) = r2
02ae68: r3 = *(u64 *)(r10 - 0x320)
02ae70: *(u64 *)(r10 - 0xa8) = r3
02ae78: r4 = *(u64 *)(r10 - 0x328)
02ae80: *(u64 *)(r10 - 0xb0) = r4
02ae88: r5 = *(u64 *)(r10 - 0x600)
02ae90: *(u64 *)(r5 + 0x18) = r1
02ae98: *(u64 *)(r5 + 0x10) = r2
02aea0: *(u64 *)(r5 + 0x8) = r3
02aea8: *(u64 *)(r5 + 0x0) = r4
02aeb0: r1 = *(u64 *)(r6 + 0x0)
02aeb8: r1 += -0x1
02aec0: *(u64 *)(r6 + 0x0) = r1
02aec8: goto -0x167 ; branch 0x2a398
02aed0: r1 = 0xa200000000 ll
02aee0: goto +0x57 ; branch 0x2b1a0
02aee8: r7 = r10
02aef0: r7 += -0xb0
02aef8: r2 = r10
02af00: r2 += -0x328
02af08: r1 = r7
02af10: r3 = 0x48
02af18: call 0xdc0f ; call 0x98f98 / window 1246
02af20: r1 = r10
02af28: r1 += -0x3e4
02af30: r2 = r10
02af38: r2 += -0x2dc
02af40: r3 = 0x64
02af48: call 0xdc09 ; call 0x98f98 / window 1246
02af50: r1 = r10
02af58: r1 += -0x430
02af60: r2 = r7
02af68: r3 = 0x48
02af70: call 0xdc04 ; call 0x98f98 / window 1246
02af78: *(u32 *)(r10 - 0x3e8) = w9
02af80: r1 = *(u64 *)(r6 + 0x0)
02af88: r1 += -0x1
02af90: *(u64 *)(r6 + 0x0) = r1
02af98: w1 = *(u32 *)(r10 - 0x4ac)
02afa0: if r1 == 0x6 goto +0x3 ; branch 0x2afc0
02afa8: r2 = r1
02afb0: r2 |= 0x4
02afb8: if r2 == 0x4 goto +0x89 ; branch 0x2b408
02afc0: r3 = *(u64 *)(r10 - 0x608)
02afc8: r1 = *(u64 *)(r3 + 0x68)
02afd0: r2 = *(u64 *)(r1 + 0x0)
02afd8: r6 = *(u64 *)(r3 + 0x48)
02afe0: r1 = *(u64 *)(r3 + 0x40)
02afe8: r7 = *(u64 *)(r3 + 0x30)
02aff0: r4 = *(u64 *)(r7 + 0x0)
02aff8: *(u64 *)(r10 - 0x5e8) = r1
02b000: r3 = *(u64 *)(r1 + 0x0)
02b008: r1 = *(u64 *)(r6 + 0x0)
02b010: r5 = 0x0
02b018: *(u64 *)(r10 - 0xff0) = r5
02b020: r5 = *(u64 *)(r10 - 0x610)
02b028: *(u64 *)(r10 - 0xfe8) = r5
02b030: r5 = 0x996b8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02b040: *(u64 *)(r10 - 0xff8) = r5
02b048: *(u64 *)(r10 - 0x1000) = r1
02b050: r1 = r10
02b058: r1 += -0x328
02b060: r5 = r10
02b068: call 0xa805 ; call 0x7f098 / window 864
02b070: r9 = *(u64 *)(r10 - 0x300)
02b078: if r9 != 0x0 goto +0x26 ; branch 0x2b1b0
02b080: r1 = *(u64 *)(r10 - 0x310)
02b088: *(u64 *)(r10 - 0xc8) = r1
02b090: r2 = *(u64 *)(r10 - 0x318)
02b098: *(u64 *)(r10 - 0xd0) = r2
02b0a0: r3 = *(u64 *)(r10 - 0x320)
02b0a8: *(u64 *)(r10 - 0xd8) = r3
02b0b0: r4 = *(u64 *)(r10 - 0x328)
02b0b8: *(u64 *)(r10 - 0xe0) = r4
02b0c0: r5 = *(u64 *)(r10 - 0x600)
02b0c8: *(u64 *)(r5 + 0x18) = r1
02b0d0: *(u64 *)(r5 + 0x10) = r2
02b0d8: *(u64 *)(r5 + 0x8) = r3
02b0e0: *(u64 *)(r5 + 0x0) = r4
02b0e8: goto -0x1ab ; branch 0x2a398
02b0f0: w2 = *(u32 *)(r10 - 0xc4)
02b0f8: *(u32 *)(r10 - 0xf0) = w2
02b100: r3 = *(u64 *)(r10 - 0xcc)
02b108: *(u64 *)(r10 - 0xf8) = r3
02b110: r4 = *(u64 *)(r10 - 0xd4)
02b118: *(u64 *)(r10 - 0x100) = r4
02b120: r5 = *(u64 *)(r10 - 0xdc)
02b128: *(u64 *)(r10 - 0x108) = r5
02b130: *(u32 *)(r7 + 0x1c) = w2
02b138: *(u64 *)(r7 + 0x14) = r3
02b140: *(u64 *)(r7 + 0xc) = r4
02b148: *(u64 *)(r7 + 0x4) = r5
02b150: *(u32 *)(r7 + 0x0) = w1
02b158: r1 = r10
02b160: r1 += -0x328
02b168: call -0x4f5f ; call 0x3678 / window 77
02b170: r1 = r10
02b178: r1 += -0x430
02b180: call -0x500c ; call 0x3128 / window 61
02b188: goto -0x11c ; branch 0x2a8b0
02b190: r1 = 0x1000000000 ll
02b1a0: *(u64 *)(r7 + 0x0) = r1
02b1a8: goto -0x120 ; branch 0x2a8b0
02b1b0: r8 = r10
02b1b8: r8 += -0xe0
02b1c0: r2 = r10
02b1c8: r2 += -0x328
02b1d0: r1 = r8
02b1d8: r3 = 0x28
02b1e0: call 0xdbb6 ; call 0x98f98 / window 1246
02b1e8: r1 = *(u64 *)(r10 - 0x2f8)
02b1f0: *(u64 *)(r10 - 0x80) = r1
02b1f8: r1 = *(u64 *)(r10 - 0x2f0)
02b200: *(u64 *)(r10 - 0x78) = r1
02b208: r1 = *(u64 *)(r10 - 0x2e8)
02b210: *(u64 *)(r10 - 0x70) = r1
02b218: r1 = *(u64 *)(r10 - 0x2e0)
02b220: *(u64 *)(r10 - 0x68) = r1
02b228: r1 = r10
02b230: r1 += -0xb0
02b238: *(u64 *)(r10 - 0x5f8) = r1
02b240: r2 = r8
02b248: r3 = 0x28
02b250: call 0xdba8 ; call 0x98f98 / window 1246
02b258: *(u64 *)(r10 - 0x88) = r9
02b260: r9 = r10
02b268: r9 += -0x60
02b270: r1 = r9
02b278: r2 = *(u64 *)(r10 - 0x5e8)
02b280: call -0x4156 ; call 0xa7d8 / window 217
02b288: r8 = r10
02b290: r8 += -0x30
02b298: r1 = r8
02b2a0: r2 = r7
02b2a8: call -0x415b ; call 0xa7d8 / window 217
02b2b0: r7 = r10
02b2b8: r7 += -0x1a0
02b2c0: r1 = r7
02b2c8: r2 = r6
02b2d0: call -0x4160 ; call 0xa7d8 / window 217
02b2d8: r6 = r10
02b2e0: r6 += -0x328
02b2e8: r1 = r6
02b2f0: r2 = r9
02b2f8: r3 = 0x30
02b300: call 0xdb92 ; call 0x98f98 / window 1246
02b308: r1 = r10
02b310: r1 += -0x2f8
02b318: r2 = r8
02b320: r3 = 0x30
02b328: call 0xdb8d ; call 0x98f98 / window 1246
02b330: r1 = r10
02b338: r1 += -0x2c8
02b340: r2 = r7
02b348: r3 = 0x30
02b350: call 0xdb88 ; call 0x98f98 / window 1246
02b358: r1 = r10
02b360: r1 += -0x108
02b368: r2 = *(u64 *)(r10 - 0x5f8)
02b370: r3 = r6
02b378: r4 = 0x3
02b380: call 0xb623 ; call 0x864a0 / window 996
02b388: w1 = *(u32 *)(r10 - 0x108)
02b390: if r1 == 0x16 goto +0x1 ; branch 0x2b3a0
02b398: goto +0x3c ; branch 0x2b580
02b3a0: r1 = r10
02b3a8: r1 += -0x328
02b3b0: call -0x4fb1 ; call 0x3630 / window 76
02b3b8: r1 = r10
02b3c0: r1 += -0xb0
02b3c8: call -0x5055 ; call 0x3128 / window 61
02b3d0: r1 = 0x16
02b3d8: r2 = *(u64 *)(r10 - 0x600)
02b3e0: *(u32 *)(r2 + 0x0) = w1
02b3e8: r1 = r10
02b3f0: r1 += -0x518
02b3f8: call -0x506c ; call 0x30a0 / window 59
02b400: goto -0x230 ; branch 0x2a288
02b408: if r1 == 0x4 goto +0x1 ; branch 0x2b418
02b410: goto +0x51 ; branch 0x2b6a0
02b418: r1 = *(u64 *)(r10 - 0x608)
02b420: r6 = *(u64 *)(r1 + 0x10)
02b428: if r6 == 0x0 goto +0x3f ; branch 0x2b628
02b430: r1 = *(u64 *)(r10 - 0x608)
02b438: r7 = *(u64 *)(r1 + 0x40)
02b440: r9 = *(u64 *)(r1 + 0x30)
02b448: r3 = *(u64 *)(r9 + 0x0)
02b450: r2 = *(u64 *)(r7 + 0x0)
02b458: r1 = r10
02b460: r1 += -0x328
02b468: call -0x3457 ; call 0x111b8 / window 294
02b470: r1 = *(u64 *)(r10 - 0x310)
02b478: *(u64 *)(r10 - 0x98) = r1
02b480: r1 = *(u64 *)(r10 - 0x318)
02b488: *(u64 *)(r10 - 0xa0) = r1
02b490: r1 = *(u64 *)(r10 - 0x320)
02b498: *(u64 *)(r10 - 0xa8) = r1
02b4a0: r1 = *(u64 *)(r10 - 0x328)
02b4a8: *(u64 *)(r10 - 0xb0) = r1
02b4b0: r2 = *(u64 *)(r6 + 0x0)
02b4b8: r1 = r10
02b4c0: r1 += -0xb0
02b4c8: call 0x9645 ; call 0x766f8 / window 774
02b4d0: if r0 != 0x0 goto +0x1 ; branch 0x2b4e0
02b4d8: goto +0x2c ; branch 0x2b640
02b4e0: r1 = r6
02b4e8: call 0xb39e ; call 0x851e0 / window 981
02b4f0: if r0 != 0x0 goto +0x1 ; branch 0x2b500
02b4f8: goto +0x2b ; branch 0x2b658
02b500: r2 = *(u64 *)(r10 - 0x608)
02b508: r1 = *(u64 *)(r2 + 0x58)
02b510: r2 = *(u64 *)(r2 + 0x50)
02b518: *(u64 *)(r10 - 0xff8) = r2
02b520: *(u64 *)(r10 - 0xff0) = r1
02b528: *(u64 *)(r10 - 0x1000) = r9
02b530: r1 = r10
02b538: r1 += -0x328
02b540: r5 = r10
02b548: r2 = *(u64 *)(r10 - 0x5e8)
02b550: r3 = r6
02b558: r4 = r7
02b560: call 0x4a7f ; call 0x50960 / window 441
02b568: w1 = *(u32 *)(r10 - 0x328)
02b570: if r1 != 0x16 goto +0x9c ; branch 0x2ba58
02b578: goto +0x24 ; branch 0x2b6a0
02b580: w2 = *(u32 *)(r10 - 0xec)
02b588: *(u32 *)(r10 - 0x110) = w2
02b590: r3 = *(u64 *)(r10 - 0xf4)
02b598: *(u64 *)(r10 - 0x118) = r3
02b5a0: r4 = *(u64 *)(r10 - 0xfc)
02b5a8: *(u64 *)(r10 - 0x120) = r4
02b5b0: r5 = *(u64 *)(r10 - 0x104)
02b5b8: *(u64 *)(r10 - 0x128) = r5
02b5c0: r0 = *(u64 *)(r10 - 0x600)
02b5c8: *(u32 *)(r0 + 0x1c) = w2
02b5d0: *(u64 *)(r0 + 0x14) = r3
02b5d8: *(u64 *)(r0 + 0xc) = r4
02b5e0: *(u64 *)(r0 + 0x4) = r5
02b5e8: *(u32 *)(r0 + 0x0) = w1
02b5f0: r1 = r10
02b5f8: r1 += -0x328
02b600: call -0x4ffb ; call 0x3630 / window 76
02b608: r1 = r10
02b610: r1 += -0xb0
02b618: call -0x509f ; call 0x3128 / window 61
02b620: goto -0x252 ; branch 0x2a398
02b628: r1 = 0x9f00000000 ll
02b638: goto +0x77 ; branch 0x2b9f8
02b640: r1 = 0x9a00000000 ll
02b650: goto +0x74 ; branch 0x2b9f8
02b658: r1 = r10
02b660: r1 += -0x328
02b668: r2 = r6
02b670: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02b680: call -0x374b ; call 0xfc30 / window 275
02b688: w1 = *(u32 *)(r10 - 0x328)
02b690: if r1 == 0x16 goto +0x1 ; branch 0x2b6a0
02b698: goto +0x77 ; branch 0x2ba58
02b6a0: r1 = r10
02b6a8: r1 += -0x5d0
02b6b0: r2 = *(u64 *)(r10 - 0x5e8)
02b6b8: call 0xb571 ; call 0x86248 / window 990
02b6c0: r1 = *(u64 *)(r10 - 0x608)
02b6c8: r7 = *(u64 *)(r1 + 0x40)
02b6d0: r2 = *(u64 *)(r7 + 0x0)
02b6d8: r6 = *(u64 *)(r10 - 0x5c8)
02b6e0: r9 = *(u64 *)(r10 - 0x5d0)
02b6e8: r1 = r10
02b6f0: r1 += -0x5e0
02b6f8: call 0xb569 ; call 0x86248 / window 990
02b700: r1 = 0x6d
02b708: w2 = *(u8 *)(r10 - 0x4ae)
02b710: if r2 == 0x0 goto +0x1 ; branch 0x2b720
02b718: w1 = *(u8 *)(r10 - 0x4ad)
02b720: if r2 == 0x1 goto +0x1 ; branch 0x2b730
02b728: goto +0x51 ; branch 0x2b9b8
02b730: r2 = *(u64 *)(r10 - 0x5d8)
02b738: r3 = *(u64 *)(r10 - 0x5e0)
02b740: r4 = 0x1
02b748: *(u64 *)(r10 - 0x158) = r4
02b750: r4 = r10
02b758: r4 += -0x149
02b760: *(u64 *)(r10 - 0x160) = r4
02b768: r4 = 0x7
02b770: *(u64 *)(r10 - 0x168) = r4
02b778: r4 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
02b788: *(u64 *)(r10 - 0x170) = r4
02b790: *(u64 *)(r10 - 0x180) = r3
02b798: *(u64 *)(r10 - 0x190) = r9
02b7a0: r3 = 0x8
02b7a8: *(u64 *)(r10 - 0x198) = r3
02b7b0: r3 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
02b7c0: *(u64 *)(r10 - 0x1a0) = r3
02b7c8: *(u8 *)(r10 - 0x149) = w1
02b7d0: *(u64 *)(r10 - 0x178) = r2
02b7d8: *(u64 *)(r10 - 0x188) = r6
02b7e0: r1 = *(u64 *)(r10 - 0x608)
02b7e8: r1 = *(u64 *)(r1 + 0x8)
02b7f0: r6 = r1
02b7f8: if r1 == 0x0 goto +0x3d ; branch 0x2b9e8
02b800: r1 = 0x5
02b808: *(u64 *)(r10 - 0x1000) = r1
02b810: r1 = 0x75
02b818: *(u64 *)(r10 - 0xff8) = r1
02b820: r1 = r10
02b828: r1 += -0x328
02b830: r4 = r10
02b838: r4 += -0x1a0
02b840: r5 = r10
02b848: r2 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02b858: r3 = r6
02b860: call -0x3d14 ; call 0xcfc8 / window 252
02b868: w1 = *(u32 *)(r10 - 0x328)
02b870: if r1 == 0x16 goto +0x1 ; branch 0x2b880
02b878: goto +0x32 ; branch 0x2ba10
02b880: w1 = *(u32 *)(r10 - 0x4ac)
02b888: if r1 == 0x4 goto +0x1 ; branch 0x2b898
02b890: goto +0x4 ; branch 0x2b8b8
02b898: r1 = r10
02b8a0: r1 += -0x430
02b8a8: call 0xabfc ; call 0x81890 / window 873
02b8b0: if r0 != 0x0 goto +0xc0 ; branch 0x2beb8
02b8b8: r3 = *(u64 *)(r7 + 0x0)
02b8c0: r1 = *(u64 *)(r6 + 0x0)
02b8c8: r2 = *(u64 *)(r10 - 0x608)
02b8d0: r5 = *(u64 *)(r2 + 0x68)
02b8d8: r2 = *(u64 *)(r2 + 0x30)
02b8e0: *(u64 *)(r10 - 0x5e8) = r2
02b8e8: r4 = *(u64 *)(r2 + 0x0)
02b8f0: *(u64 *)(r10 - 0x618) = r5
02b8f8: r2 = *(u64 *)(r5 + 0x0)
02b900: r5 = 0x0
02b908: *(u64 *)(r10 - 0xff0) = r5
02b910: r5 = *(u64 *)(r10 - 0x610)
02b918: *(u64 *)(r10 - 0xfe8) = r5
02b920: r5 = 0x996b8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02b930: *(u64 *)(r10 - 0xff8) = r5
02b938: *(u64 *)(r10 - 0x1000) = r1
02b940: r1 = r10
02b948: r1 += -0x328
02b950: r5 = r10
02b958: call 0xa6e7 ; call 0x7f098 / window 864
02b960: r9 = *(u64 *)(r10 - 0x300)
02b968: if r9 != 0x0 goto +0x2b ; branch 0x2bac8
02b970: r1 = *(u64 *)(r10 - 0x310)
02b978: *(u64 *)(r10 - 0xf0) = r1
02b980: r2 = *(u64 *)(r10 - 0x318)
02b988: *(u64 *)(r10 - 0xf8) = r2
02b990: r3 = *(u64 *)(r10 - 0x320)
02b998: *(u64 *)(r10 - 0x100) = r3
02b9a0: r4 = *(u64 *)(r10 - 0x328)
02b9a8: *(u64 *)(r10 - 0x108) = r4
02b9b0: goto -0x11f ; branch 0x2b0c0
02b9b8: r2 = 0x0
02b9c0: r3 = *(u64 *)(r10 - 0x600)
02b9c8: *(u32 *)(r3 + 0x0) = w2
02b9d0: r1 &= 0xff
02b9d8: *(u32 *)(r3 + 0x4) = w1
02b9e0: goto -0x2ca ; branch 0x2a398
02b9e8: r1 = 0xa700000000 ll
02b9f8: r2 = *(u64 *)(r10 - 0x600)
02ba00: *(u64 *)(r2 + 0x0) = r1
02ba08: goto -0x2cf ; branch 0x2a398
02ba10: w2 = *(u32 *)(r10 - 0x30c)
02ba18: *(u32 *)(r10 - 0x98) = w2
02ba20: r3 = *(u64 *)(r10 - 0x314)
02ba28: *(u64 *)(r10 - 0xa0) = r3
02ba30: r4 = *(u64 *)(r10 - 0x31c)
02ba38: *(u64 *)(r10 - 0xa8) = r4
02ba40: r5 = *(u64 *)(r10 - 0x324)
02ba48: *(u64 *)(r10 - 0xb0) = r5
02ba50: goto +0x8 ; branch 0x2ba98
02ba58: w2 = *(u32 *)(r10 - 0x30c)
02ba60: *(u32 *)(r10 - 0x188) = w2
02ba68: r3 = *(u64 *)(r10 - 0x314)
02ba70: *(u64 *)(r10 - 0x190) = r3
02ba78: r4 = *(u64 *)(r10 - 0x31c)
02ba80: *(u64 *)(r10 - 0x198) = r4
02ba88: r5 = *(u64 *)(r10 - 0x324)
02ba90: *(u64 *)(r10 - 0x1a0) = r5
02ba98: r0 = *(u64 *)(r10 - 0x600)
02baa0: *(u32 *)(r0 + 0x1c) = w2
02baa8: *(u64 *)(r0 + 0x14) = r3
02bab0: *(u64 *)(r0 + 0xc) = r4
02bab8: *(u64 *)(r0 + 0x4) = r5
02bac0: goto -0x1c5 ; branch 0x2aca0
02bac8: r8 = r10
02bad0: r8 += -0x108
02bad8: r2 = r10
02bae0: r2 += -0x328
02bae8: r1 = r8
02baf0: r3 = 0x28
02baf8: call 0xda93 ; call 0x98f98 / window 1246
02bb00: r1 = *(u64 *)(r10 - 0x2f8)
02bb08: *(u64 *)(r10 - 0x80) = r1
02bb10: r1 = *(u64 *)(r10 - 0x2f0)
02bb18: *(u64 *)(r10 - 0x78) = r1
02bb20: r1 = *(u64 *)(r10 - 0x2e8)
02bb28: *(u64 *)(r10 - 0x70) = r1
02bb30: r1 = *(u64 *)(r10 - 0x2e0)
02bb38: *(u64 *)(r10 - 0x68) = r1
02bb40: r1 = r10
02bb48: r1 += -0xb0
02bb50: *(u64 *)(r10 - 0x5f8) = r1
02bb58: r2 = r8
02bb60: r3 = 0x28
02bb68: call 0xda85 ; call 0x98f98 / window 1246
02bb70: *(u64 *)(r10 - 0x88) = r9
02bb78: r8 = r10
02bb80: r8 += -0xe0
02bb88: r1 = r8
02bb90: r2 = r7
02bb98: call -0x4279 ; call 0xa7d8 / window 217
02bba0: r1 = r10
02bba8: r1 += -0x60
02bbb0: *(u64 *)(r10 - 0x610) = r1
02bbb8: r2 = *(u64 *)(r10 - 0x5e8)
02bbc0: call -0x427e ; call 0xa7d8 / window 217
02bbc8: r1 = r10
02bbd0: r1 += -0x30
02bbd8: *(u64 *)(r10 - 0x608) = r1
02bbe0: r2 = r6
02bbe8: call -0x4283 ; call 0xa7d8 / window 217
02bbf0: r9 = r10
02bbf8: r9 += -0x328
02bc00: r1 = r9
02bc08: r2 = r8
02bc10: r3 = 0x30
02bc18: call 0xda6f ; call 0x98f98 / window 1246
02bc20: r1 = r10
02bc28: r1 += -0x2f8
02bc30: r2 = *(u64 *)(r10 - 0x610)
02bc38: r3 = 0x30
02bc40: call 0xda6a ; call 0x98f98 / window 1246
02bc48: r1 = r10
02bc50: r1 += -0x2c8
02bc58: r2 = *(u64 *)(r10 - 0x608)
02bc60: r3 = 0x30
02bc68: call 0xda65 ; call 0x98f98 / window 1246
02bc70: r1 = 0x5
02bc78: *(u64 *)(r10 - 0x28) = r1
02bc80: r1 = r10
02bc88: r1 += -0x1a0
02bc90: *(u64 *)(r10 - 0x30) = r1
02bc98: r1 = r10
02bca0: r1 += -0x30
02bca8: *(u64 *)(r10 - 0x1000) = r1
02bcb0: r1 = 0x1
02bcb8: *(u64 *)(r10 - 0xff8) = r1
02bcc0: r1 = r10
02bcc8: r1 += -0x128
02bcd0: r5 = r10
02bcd8: r2 = *(u64 *)(r10 - 0x5f8)
02bce0: r3 = r9
02bce8: r4 = 0x3
02bcf0: call 0xb4fd ; call 0x864e0 / window 997
02bcf8: w1 = *(u32 *)(r10 - 0x128)
02bd00: if r1 == 0x16 goto +0x1 ; branch 0x2bd10
02bd08: goto +0x2c ; branch 0x2be70
02bd10: r1 = r10
02bd18: r1 += -0x328
02bd20: call -0x50df ; call 0x3630 / window 76
02bd28: r1 = r10
02bd30: r1 += -0xb0
02bd38: call -0x5183 ; call 0x3128 / window 61
02bd40: w1 = *(u32 *)(r10 - 0x4ac)
02bd48: if r1 == 0x4 goto +0x1 ; branch 0x2bd58
02bd50: goto -0x131 ; branch 0x2b3d0
02bd58: r1 = r10
02bd60: r1 += -0x60
02bd68: *(u64 *)(r10 - 0x5f8) = r1
02bd70: r2 = r7
02bd78: call -0x42b5 ; call 0xa7d8 / window 217
02bd80: r7 = r10
02bd88: r7 += -0x30
02bd90: r1 = r7
02bd98: r2 = *(u64 *)(r10 - 0x5e8)
02bda0: call -0x42ba ; call 0xa7d8 / window 217
02bda8: r8 = r10
02bdb0: r8 += -0xb0
02bdb8: r1 = r8
02bdc0: r2 = r6
02bdc8: call -0x42bf ; call 0xa7d8 / window 217
02bdd0: r9 = r10
02bdd8: r9 += -0x328
02bde0: r1 = r9
02bde8: r2 = *(u64 *)(r10 - 0x618)
02bdf0: call -0x42c4 ; call 0xa7d8 / window 217
02bdf8: w1 = *(u8 *)(r10 - 0x4ad)
02be00: w2 = *(u8 *)(r10 - 0x4ae)
02be08: *(u64 *)(r10 - 0xff8) = r2
02be10: *(u64 *)(r10 - 0xff0) = r1
02be18: *(u64 *)(r10 - 0x1000) = r9
02be20: r1 = r10
02be28: r1 += -0xe0
02be30: r5 = r10
02be38: r2 = *(u64 *)(r10 - 0x5f8)
02be40: r3 = r7
02be48: r4 = r8
02be50: call 0x4a02 ; call 0x50e68 / window 442
02be58: w1 = *(u32 *)(r10 - 0xe0)
02be60: if r1 != 0x16 goto +0x2e ; branch 0x2bfd8
02be68: goto -0x154 ; branch 0x2b3d0
02be70: w2 = *(u32 *)(r10 - 0x10c)
02be78: *(u32 *)(r10 - 0x130) = w2
02be80: r3 = *(u64 *)(r10 - 0x114)
02be88: *(u64 *)(r10 - 0x138) = r3
02be90: r4 = *(u64 *)(r10 - 0x11c)
02be98: *(u64 *)(r10 - 0x140) = r4
02bea0: r5 = *(u64 *)(r10 - 0x124)
02bea8: *(u64 *)(r10 - 0x148) = r5
02beb0: goto -0x11f ; branch 0x2b5c0
02beb8: r9 = r10
02bec0: r9 += -0x60
02bec8: r1 = r9
02bed0: r2 = r7
02bed8: call -0x42e1 ; call 0xa7d8 / window 217
02bee0: r8 = *(u64 *)(r10 - 0x608)
02bee8: r2 = *(u64 *)(r8 + 0x30)
02bef0: r1 = r10
02bef8: r1 += -0x30
02bf00: *(u64 *)(r10 - 0x5e8) = r1
02bf08: call -0x42e7 ; call 0xa7d8 / window 217
02bf10: r1 = r10
02bf18: r1 += -0xb0
02bf20: *(u64 *)(r10 - 0x5f8) = r1
02bf28: r2 = r6
02bf30: call -0x42ec ; call 0xa7d8 / window 217
02bf38: r2 = *(u64 *)(r8 + 0x68)
02bf40: r8 = r10
02bf48: r8 += -0x328
02bf50: r1 = r8
02bf58: call -0x42f1 ; call 0xa7d8 / window 217
02bf60: w1 = *(u8 *)(r10 - 0x4ad)
02bf68: w2 = *(u8 *)(r10 - 0x4ae)
02bf70: *(u64 *)(r10 - 0xff8) = r2
02bf78: *(u64 *)(r10 - 0xff0) = r1
02bf80: *(u64 *)(r10 - 0x1000) = r8
02bf88: r1 = r10
02bf90: r1 += -0xe0
02bf98: r5 = r10
02bfa0: r2 = r9
02bfa8: r3 = *(u64 *)(r10 - 0x5e8)
02bfb0: r4 = *(u64 *)(r10 - 0x5f8)
02bfb8: call 0x4ad8 ; call 0x51680 / window 443
02bfc0: w1 = *(u32 *)(r10 - 0xe0)
02bfc8: if r1 != 0x16 goto +0x1 ; branch 0x2bfd8
02bfd0: goto -0xe4 ; branch 0x2b8b8
02bfd8: w2 = *(u32 *)(r10 - 0xc4)
02bfe0: *(u32 *)(r10 - 0xf0) = w2
02bfe8: r3 = *(u64 *)(r10 - 0xcc)
02bff0: *(u64 *)(r10 - 0xf8) = r3
02bff8: r4 = *(u64 *)(r10 - 0xd4)
02c000: *(u64 *)(r10 - 0x100) = r4
02c008: r5 = *(u64 *)(r10 - 0xdc)
02c010: *(u64 *)(r10 - 0x108) = r5
02c018: goto -0xb1 ; branch 0x2ba98
