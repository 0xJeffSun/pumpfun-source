00ed58: r7 = r3
00ed60: r3 = r2
00ed68: r6 = r1
00ed70: r2 = *(u64 *)(r7 + 0x0)
00ed78: r3 += 0x4
00ed80: r1 = r3
00ed88: call -0x1810 ; call 0x2d10 / window 44
00ed90: if r0 != 0x0 goto +0x5 ; branch 0xedc0
00ed98: w1 = *(u8 *)(r7 + 0x28)
00eda0: if r1 == 0x0 goto +0x6 ; branch 0xedd8
00eda8: r1 = 0x16
00edb0: *(u32 *)(r6 + 0x0) = w1
00edb8: goto +0x6 ; branch 0xedf0
00edc0: r1 = 0x700000000 ll
00edd0: goto +0x2 ; branch 0xede8
00edd8: r1 = 0x800000000 ll
00ede8: *(u64 *)(r6 + 0x0) = r1
00edf0: exit
