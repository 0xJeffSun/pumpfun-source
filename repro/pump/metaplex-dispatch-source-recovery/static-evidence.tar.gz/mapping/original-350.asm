03cce8: r9 = r3
03ccf0: r8 = r1
03ccf8: r3 = *(u64 *)(r5 - 0xff8)
03cd00: if r3 == 0x0 goto +0x1c ; branch 0x3cde8
03cd08: *(u64 *)(r10 - 0x920) = r4
03cd10: *(u64 *)(r10 - 0x928) = r2
03cd18: r6 = *(u64 *)(r5 - 0x1000)
03cd20: r1 = r10
03cd28: r1 += -0x6c8
03cd30: r2 = r6
03cd38: call -0x6ceb ; call 0x65e8 / window 154
03cd40: w7 = *(u32 *)(r10 - 0x6c8)
03cd48: if r7 == 0x3a goto +0x1 ; branch 0x3cd58
03cd50: goto +0x16 ; branch 0x3ce08
03cd58: r1 = 0x2
03cd60: w2 = *(u8 *)(r6 + 0x0)
03cd68: if r2 > 0x30 goto +0x8 ; branch 0x3cdb0
03cd70: r3 = 0x1
03cd78: r3 <<= r2
03cd80: r2 = 0x100000001036f ll
03cd90: r3 &= r2
03cd98: if r3 != 0x0 goto +0x1 ; branch 0x3cda8
03cda0: goto +0x1 ; branch 0x3cdb0
03cda8: r1 = 0x0
03cdb0: r2 = 0x4b
03cdb8: *(u32 *)(r8 + 0x4) = w2
03cdc0: *(u32 *)(r8 + 0x0) = w1
03cdc8: r1 = r10
03cdd0: r1 += -0x6c8
03cdd8: call -0x73d9 ; call 0x2f18 / window 52
03cde0: goto +0x3 ; branch 0x3ce00
03cde8: r1 = 0xbd00000000 ll
03cdf8: *(u64 *)(r8 + 0x0) = r1
03ce00: exit
03ce08: *(u64 *)(r10 - 0x930) = r8
03ce10: r1 = *(u64 *)(r10 - 0x6b8)
03ce18: *(u64 *)(r10 - 0x818) = r1
03ce20: r1 = *(u64 *)(r10 - 0x6b0)
03ce28: *(u64 *)(r10 - 0x810) = r1
03ce30: r1 = *(u64 *)(r10 - 0x6a8)
03ce38: *(u64 *)(r10 - 0x808) = r1
03ce40: r6 = *(u64 *)(r10 - 0x6c4)
03ce48: w8 = *(u32 *)(r10 - 0x6bc)
03ce50: r1 = r10
03ce58: r1 += -0x800
03ce60: r2 = r10
03ce68: r2 += -0x6a0
03ce70: r3 = 0x138
03ce78: call 0xb823 ; call 0x98f98 / window 1246
03ce80: *(u32 *)(r10 - 0x81c) = w8
03ce88: *(u64 *)(r10 - 0x824) = r6
03ce90: *(u32 *)(r10 - 0x828) = w7
03ce98: r1 = *(u64 *)(r10 - 0x928)
03cea0: *(u64 *)(r10 - 0x6c8) = r1
03cea8: r1 = r10
03ceb0: r1 += -0x838
03ceb8: *(u64 *)(r10 - 0x938) = r9
03cec0: r2 = r9
03cec8: r3 = *(u64 *)(r10 - 0x920)
03ced0: call 0x76f9 ; call 0x786a0 / window 802
03ced8: r1 = r10
03cee0: r1 += -0x820
03cee8: *(u64 *)(r10 - 0x940) = r1
03cef0: r1 = r10
03cef8: r1 += -0x818
03cf00: *(u64 *)(r10 - 0x948) = r1
03cf08: r9 = *(u64 *)(r10 - 0x838)
03cf10: r6 = *(u64 *)(r10 - 0x830)
03cf18: r6 += 0x18
03cf20: r8 = 0x3
03cf28: r7 = r6
03cf30: r7 += -0x18
03cf38: if r7 == r9 goto +0x23 ; branch 0x3d058
03cf40: r2 = r10
03cf48: r2 += -0x6c8
03cf50: r1 = r6
03cf58: call -0x7455 ; call 0x2cb8 / window 41
03cf60: if r0 == 0x0 goto +0x1c ; branch 0x3d048
03cf68: r1 = r7
03cf70: call 0x904d ; call 0x851e0 / window 981
03cf78: if r0 != 0x0 goto +0x19 ; branch 0x3d048
03cf80: r2 = *(u64 *)(r6 - 0x8)
03cf88: r2 += 0x10
03cf90: r1 = r10
03cf98: r1 += -0x848
03cfa0: r3 = 0x9f3d0 ll ; data b'\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x88\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00'
03cfb0: call -0x72db ; call 0x38e0 / window 87
03cfb8: r3 = *(u64 *)(r10 - 0x848)
03cfc0: r2 = *(u64 *)(r3 + 0x8)
03cfc8: if r2 == 0x0 goto +0x2b0 ; branch 0x3e550
03cfd0: r1 = *(u64 *)(r10 - 0x840)
03cfd8: r3 = *(u64 *)(r3 + 0x0)
03cfe0: w4 = *(u8 *)(r3 + 0x0)
03cfe8: if r4 == 0xb goto +0x1 ; branch 0x3cff8
03cff0: goto +0x7 ; branch 0x3d030
03cff8: if r8 > r2 goto +0x2af ; branch 0x3e578
03d000: w2 = *(u8 *)(r3 + 0x2)
03d008: r3 = *(u64 *)(r1 + 0x0)
03d010: r3 += -0x1
03d018: *(u64 *)(r1 + 0x0) = r3
03d020: if r2 == 0x1 goto +0x6 ; branch 0x3d058
03d028: goto +0x3 ; branch 0x3d048
03d030: r2 = *(u64 *)(r1 + 0x0)
03d038: r2 += -0x1
03d040: *(u64 *)(r1 + 0x0) = r2
03d048: r6 += 0x30
03d050: goto -0x26 ; branch 0x3cf28
03d058: w1 = *(u32 *)(r10 - 0x828)
03d060: if r7 == r9 goto +0x1 ; branch 0x3d070
03d068: if r1 != 0x2f goto +0x41 ; branch 0x3d278
03d070: if r1 == 0x29 goto +0xc4 ; branch 0x3d698
03d078: r8 = *(u64 *)(r10 - 0x930)
03d080: r9 = *(u64 *)(r10 - 0x938)
03d088: if r1 == 0x2a goto +0x50 ; branch 0x3d310
03d090: if r1 == 0x2b goto +0x1bf ; branch 0x3de90
03d098: if r1 == 0x2c goto +0x87 ; branch 0x3d4d8
03d0a0: if r1 == 0x2d goto +0x65 ; branch 0x3d3d0
03d0a8: if r1 == 0x2e goto +0x70 ; branch 0x3d430
03d0b0: if r1 == 0x2f goto +0x1d5 ; branch 0x3df60
03d0b8: if r1 == 0x30 goto +0x1d1 ; branch 0x3df48
03d0c0: if r1 == 0x31 goto +0xa7 ; branch 0x3d600
03d0c8: if r1 == 0x32 goto +0x1a5 ; branch 0x3ddf8
03d0d0: if r1 == 0x34 goto +0x18c ; branch 0x3dd38
03d0d8: if r1 == 0x35 goto +0x197 ; branch 0x3dd98
03d0e0: if r1 == 0x36 goto +0xcc ; branch 0x3d748
03d0e8: if r1 == 0x37 goto +0x93 ; branch 0x3d588
03d0f0: if r1 == 0x38 goto +0xc1 ; branch 0x3d700
03d0f8: if r1 == 0x39 goto +0x1 ; branch 0x3d108
03d100: goto +0x1df ; branch 0x3e000
03d108: r1 = 0x9a9ea ll ; data b'IX: Close AccountsIX: ResizeIX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: Revok'
03d118: r2 = 0x12
03d120: call -0x1 ; external sol_log_
03d128: r1 = 0x5
03d130: r2 = *(u64 *)(r10 - 0x920)
03d138: if r1 > r2 goto +0x265 ; branch 0x3e468
03d140: r1 = r10
03d148: r1 += -0x6c8
03d150: r2 = r9
03d158: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03d168: call -0x5aa8 ; call 0xfc30 / window 275
03d170: w1 = *(u32 *)(r10 - 0x6c8)
03d178: if r1 == 0x16 goto +0x1 ; branch 0x3d188
03d180: goto +0x252 ; branch 0x3e418
03d188: r6 = r9
03d190: r9 += 0x60
03d198: r1 = r9
03d1a0: call 0x9007 ; call 0x851e0 / window 981
03d1a8: if r0 != 0x0 goto +0x1 ; branch 0x3d1b8
03d1b0: goto +0x259 ; branch 0x3e480
03d1b8: r1 = r6
03d1c0: r1 += 0x78
03d1c8: r2 = 0x9ed68 ll ; data b'\x00\x00\x00\x00\xe8\x99\t\x00\x00\x00\x00\x00\xc8\x9a\t\x00\x00\x00\x00\x00\x18\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00H\x9a\t\x00\x00\x00\x00\x00:\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00`\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00'
03d1d8: call -0x74a5 ; call 0x2cb8 / window 41
03d1e0: r7 = 0x1
03d1e8: if r0 == 0x0 goto +0x252 ; branch 0x3e480
03d1f0: r6 += 0x90
03d1f8: r1 = r10
03d200: r1 += -0x6c8
03d208: r2 = r6
03d210: call 0x7296 ; call 0x766c8 / window 773
03d218: w1 = *(u32 *)(r10 - 0x6c8)
03d220: if r1 == 0x16 goto +0x1 ; branch 0x3d230
03d228: goto +0x256 ; branch 0x3e4e0
03d230: r1 = *(u64 *)(r6 + 0x0)
03d238: r2 = 0x99928 ll ; data b'\xa3\xa5\x8eL\x1e\xd7\x93y\x0eG\xa3\xfc\xb8\\\xa0\xebQ9\x1e\x8c"\x7f\xf8\r\xef\x94@\x97O\xf2\x83\xf8\x18\xbe5\xe8|\xe3DRal\x90\xe1\x06\xe9z\x00C\xaf\x8f\xc7\rAR\\4}\xfe\xb4\xbe\xe1\xdf\x89\x8c\x97%\x8fN$\x89\xf1\xbb=\x10)\x14\x8e\r\x83\x0bZ\x13\x99\xda\xff\x10\x84\x04\x8e{\xd8\xdb\xe9\xf8Y\x98\x8b\x80\xeb'
03d248: call -0x74a8 ; call 0x2d10 / window 44
03d250: if r0 != 0x0 goto +0x1 ; branch 0x3d260
03d258: goto +0x2e7 ; branch 0x3e998
03d260: r1 = 0xbc00000000 ll
03d270: goto +0x274 ; branch 0x3e618
03d278: r2 = 0x9b00000000 ll
03d288: r3 = *(u64 *)(r10 - 0x930)
03d290: *(u64 *)(r3 + 0x0) = r2
03d298: r2 = r1
03d2a0: r2 += -0x34
03d2a8: r3 = 0x2
03d2b0: if r3 > r2 goto -0x97 ; branch 0x3ce00
03d2b8: if r1 == 0x29 goto -0x98 ; branch 0x3ce00
03d2c0: if r1 == 0x2a goto +0x29a ; branch 0x3e798
03d2c8: if r1 == 0x2b goto +0x28b ; branch 0x3e728
03d2d0: if r1 == 0x2c goto +0x29d ; branch 0x3e7c0
03d2d8: if r1 == 0x2d goto -0x9c ; branch 0x3ce00
03d2e0: if r1 == 0x2e goto +0x291 ; branch 0x3e770
03d2e8: if r1 == 0x2f goto +0x290 ; branch 0x3e770
03d2f0: if r1 == 0x31 goto +0x286 ; branch 0x3e728
03d2f8: if r1 == 0x32 goto +0x289 ; branch 0x3e748
03d300: if r1 == 0x37 goto -0xa1 ; branch 0x3ce00
03d308: goto +0x279 ; branch 0x3e6d8
03d310: r1 = 0x9aa5b ll ; data b'IX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Editio'
03d320: r2 = 0xa
03d328: call -0x1 ; external sol_log_
03d330: r6 = r10
03d338: r6 += -0x6c8
03d340: r1 = r6
03d348: r2 = *(u64 *)(r10 - 0x940)
03d350: r3 = 0x108
03d358: call 0xb787 ; call 0x98f98 / window 1246
03d360: r1 = r8
03d368: r2 = *(u64 *)(r10 - 0x928)
03d370: r3 = r9
03d378: r4 = *(u64 *)(r10 - 0x920)
03d380: r5 = r6
03d388: call -0x2914 ; call 0x28af0 / window 321
03d390: r6 = 0x0
03d398: r1 = 0x1
03d3a0: r2 = 0x1
03d3a8: r3 = 0x1
03d3b0: r4 = 0x1
03d3b8: r5 = 0x1
03d3c0: r0 = 0x1
03d3c8: goto +0x252 ; branch 0x3e660
03d3d0: w6 = *(u32 *)(r10 - 0x820)
03d3d8: r1 = 0x9aa45 ll ; data b'IX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow '
03d3e8: r2 = 0xa
03d3f0: call -0x1 ; external sol_log_
03d3f8: r1 = r8
03d400: r2 = *(u64 *)(r10 - 0x928)
03d408: r3 = r9
03d410: r4 = *(u64 *)(r10 - 0x920)
03d418: r5 = r6
03d420: call -0x39bd ; call 0x20640 / window 313
03d428: goto +0x23f ; branch 0x3e628
03d430: r1 = 0x9a200 ll ; data b'IX: LockDelegatemetadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/'
03d440: r2 = 0x8
03d448: call -0x1 ; external sol_log_
03d450: r6 = r10
03d458: r6 += -0x6c8
03d460: r1 = r6
03d468: r2 = *(u64 *)(r10 - 0x940)
03d470: r3 = 0x38
03d478: call 0xb763 ; call 0x98f98 / window 1246
03d480: r1 = r8
03d488: r2 = *(u64 *)(r10 - 0x928)
03d490: r3 = r9
03d498: r4 = *(u64 *)(r10 - 0x920)
03d4a0: r5 = r6
03d4a8: call -0xe13 ; call 0x36418 / window 341
03d4b0: r4 = 0x0
03d4b8: r1 = 0x1
03d4c0: r2 = 0x1
03d4c8: r3 = 0x1
03d4d0: goto +0x22e ; branch 0x3e648
03d4d8: r1 = 0x9aa4f ll ; data b'IX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX:'
03d4e8: r2 = 0xc
03d4f0: call -0x1 ; external sol_log_
03d4f8: r6 = r10
03d500: r6 += -0x6c8
03d508: r1 = r6
03d510: r2 = *(u64 *)(r10 - 0x940)
03d518: r3 = 0x60
03d520: call 0xb74e ; call 0x98f98 / window 1246
03d528: r1 = r8
03d530: r2 = *(u64 *)(r10 - 0x928)
03d538: r3 = r9
03d540: r4 = *(u64 *)(r10 - 0x920)
03d548: r5 = r6
03d550: call -0x4027 ; call 0x1d420 / window 311
03d558: r5 = 0x0
03d560: r1 = 0x1
03d568: r2 = 0x1
03d570: r3 = 0x1
03d578: r4 = 0x1
03d580: goto +0x219 ; branch 0x3e650
03d588: r6 = *(u64 *)(r10 - 0x818)
03d590: w7 = *(u32 *)(r10 - 0x820)
03d598: r1 = 0x9aa06 ll ; data b'IX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: T'
03d5a8: r2 = 0x9
03d5b0: call -0x1 ; external sol_log_
03d5b8: *(u64 *)(r10 - 0x1000) = r7
03d5c0: *(u64 *)(r10 - 0xff8) = r6
03d5c8: r5 = r10
03d5d0: r1 = r8
03d5d8: r2 = *(u64 *)(r10 - 0x928)
03d5e0: r3 = r9
03d5e8: r4 = *(u64 *)(r10 - 0x920)
03d5f0: call -0x22bb ; call 0x2c020 / window 325
03d5f8: goto +0x205 ; branch 0x3e628
03d600: r1 = 0x9aa2f ll ; data b'IX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow Acc'
03d610: r2 = 0xc
03d618: call -0x1 ; external sol_log_
03d620: r6 = r10
03d628: r6 += -0x6c8
03d630: r1 = r6
03d638: r2 = *(u64 *)(r10 - 0x940)
03d640: r3 = 0x40
03d648: call 0xb729 ; call 0x98f98 / window 1246
03d650: r1 = r8
03d658: r2 = *(u64 *)(r10 - 0x928)
03d660: r3 = r9
03d668: r4 = *(u64 *)(r10 - 0x920)
03d670: r5 = r6
03d678: call -0x1c10 ; call 0x2f600 / window 335
03d680: r2 = 0x0
03d688: r1 = 0x1
03d690: goto +0x1f4 ; branch 0x3e638
03d698: r6 = *(u64 *)(r10 - 0x818)
03d6a0: r1 = 0x9a1b8 ll ; data b'IX: BurnCpiGuardDeadlockNotFound\x02\x00\x00\x00\x04\x00\x00\x00TransferTimedOut\xff\xff\xff\xff\xff\xff\xff\xff\x01\x00\x00\x00\x03\x00\x00\x00IX: LockDelegatemetadatadead'
03d6b0: r2 = 0x8
03d6b8: call -0x1 ; external sol_log_
03d6c0: *(u64 *)(r10 - 0xff8) = r6
03d6c8: r5 = r10
03d6d0: r1 = *(u64 *)(r10 - 0x930)
03d6d8: r2 = *(u64 *)(r10 - 0x928)
03d6e0: r3 = *(u64 *)(r10 - 0x938)
03d6e8: r4 = *(u64 *)(r10 - 0x920)
03d6f0: call -0x57e1 ; call 0x117f0 / window 296
03d6f8: goto +0x1e5 ; branch 0x3e628
03d700: r1 = 0x9a9fc ll ; data b'IX: ResizeIX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: C'
03d710: r2 = 0xa
03d718: call -0x1 ; external sol_log_
03d720: r1 = r8
03d728: r3 = r9
03d730: r4 = *(u64 *)(r10 - 0x920)
03d738: call -0x10aa ; call 0x351f0 / window 340
03d740: goto +0x1dc ; branch 0x3e628
03d748: r1 = *(u64 *)(r10 - 0x928)
03d750: *(u64 *)(r10 - 0x568) = r1
03d758: *(u64 *)(r10 - 0x360) = r9
03d760: r1 = *(u64 *)(r10 - 0x920)
03d768: r1 *= 0x30
03d770: r9 += r1
03d778: *(u64 *)(r10 - 0x368) = r9
03d780: r1 = r10
03d788: r1 += -0x6c8
03d790: r2 = r10
03d798: r2 += -0x368
03d7a0: call 0x89b8 ; call 0x82568 / window 881
03d7a8: w1 = *(u32 *)(r10 - 0x6c8)
03d7b0: if r1 != 0x16 goto +0x183 ; branch 0x3e3d0
03d7b8: r6 = *(u64 *)(r10 - 0x6c0)
03d7c0: r1 = r10
03d7c8: r1 += -0x6c8
03d7d0: r2 = r6
03d7d8: call 0x71dd ; call 0x766c8 / window 773
03d7e0: w1 = *(u32 *)(r10 - 0x6c8)
03d7e8: if r1 == 0x16 goto +0x1 ; branch 0x3d7f8
03d7f0: goto +0x184 ; branch 0x3e418
03d7f8: r1 = *(u64 *)(r6 + 0x0)
03d800: r2 = 0x99848 ll ; data b"\x05\x08\xec{r\xc5_\x8e\x93\xb1\xdd\xea\xa5C\nXjq\xdd\x99\xc90\xa3)\x17w\t$\xceq\x91\xea\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcInvalid Escrow Account Bump SeedAmou"
03d810: call -0x7561 ; call 0x2d10 / window 44
03d818: if r0 != 0x0 goto +0x1a3 ; branch 0x3e538
03d820: r1 = r10
03d828: r1 += -0x6c8
03d830: r2 = r10
03d838: r2 += -0x368
03d840: call 0x89a4 ; call 0x82568 / window 881
03d848: w1 = *(u32 *)(r10 - 0x6c8)
03d850: if r1 == 0x16 goto +0x1 ; branch 0x3d860
03d858: goto +0x16e ; branch 0x3e3d0
03d860: r1 = *(u64 *)(r10 - 0x6c0)
03d868: *(u64 *)(r10 - 0x938) = r1
03d870: r1 = *(u64 *)(r1 + 0x0)
03d878: r2 = 0x99948 ll ; data b'\x18\xbe5\xe8|\xe3DRal\x90\xe1\x06\xe9z\x00C\xaf\x8f\xc7\rAR\\4}\xfe\xb4\xbe\xe1\xdf\x89\x8c\x97%\x8fN$\x89\xf1\xbb=\x10)\x14\x8e\r\x83\x0bZ\x13\x99\xda\xff\x10\x84\x04\x8e{\xd8\xdb\xe9\xf8Y\x98\x8b\x80\xeby5(i\xb2$t_Y\xdd\xbf\x8a&X\xca\x13\xdch\x81!&5\x1c\xae\x07\xc1\xa5\xa5\xed\x03H\x1d'
03d888: call -0x7570 ; call 0x2d10 / window 44
03d890: if r0 != 0x0 goto +0x22c ; branch 0x3e9f8
03d898: r6 = *(u64 *)(r10 - 0x360)
03d8a0: r1 = *(u64 *)(r10 - 0x368)
03d8a8: if r6 != r1 goto +0x1 ; branch 0x3d8b8
03d8b0: goto +0x43a ; branch 0x3fa88
03d8b8: r1 = r6
03d8c0: r1 += 0x30
03d8c8: *(u64 *)(r10 - 0x360) = r1
03d8d0: r1 = r6
03d8d8: r1 += 0x18
03d8e0: r2 = r10
03d8e8: r2 += -0x568
03d8f0: call -0x7584 ; call 0x2cd8 / window 42
03d8f8: if r0 != 0x0 goto +0x21f ; branch 0x3e9f8
03d900: *(u64 *)(r10 - 0x920) = r6
03d908: r2 = *(u64 *)(r6 + 0x10)
03d910: r2 += 0x10
03d918: r1 = r10
03d920: r1 += -0x888
03d928: r3 = 0x9f088 ll ; data b'\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00*\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00H\x00\x00\x00\x1a\x00\x00\x00\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x1b\xa7\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00'
03d938: call -0x740c ; call 0x38e0 / window 87
03d940: r2 = *(u64 *)(r10 - 0x888)
03d948: r3 = *(u64 *)(r2 + 0x8)
03d950: r1 = 0x9a14d ll ; data b'\x00Invalid Option representation: . The first byte must be 0 or 1src/entrypoint.rs\x00\x00\x00IX: Mint (bytes D'
03d960: if r3 == 0x0 goto +0x1 ; branch 0x3d970
03d968: r1 = *(u64 *)(r2 + 0x0)
03d970: w1 = *(u8 *)(r1 + 0x0)
03d978: r6 = *(u64 *)(r10 - 0x880)
03d980: call -0x7a1c ; call 0x8a8 / window 11
03d988: r7 = r0
03d990: r1 = *(u64 *)(r6 + 0x0)
03d998: r1 += -0x1
03d9a0: *(u64 *)(r6 + 0x0) = r1
03d9a8: r8 = 0xbf
03d9b0: r9 = 0x0
03d9b8: r7 <<= 0x20
03d9c0: r7 >>= 0x20
03d9c8: if r7 == 0xf goto +0x3e9 ; branch 0x3f918
03d9d0: r1 = r10
03d9d8: r1 += -0x6c8
03d9e0: call 0x99a1 ; call 0x8a6f0 / window 1033
03d9e8: w9 = *(u32 *)(r10 - 0x6c8)
03d9f0: if r9 != 0x16 goto +0x3e0 ; branch 0x3f8f8
03d9f8: r1 = *(u64 *)(r10 - 0x6b0)
03da00: *(u64 *)(r10 - 0x120) = r1
03da08: r1 = *(u64 *)(r10 - 0x6b8)
03da10: *(u64 *)(r10 - 0x128) = r1
03da18: r1 = *(u64 *)(r10 - 0x6c0)
03da20: *(u64 *)(r10 - 0x130) = r1
03da28: r6 = *(u64 *)(r10 - 0x920)
03da30: r1 = r6
03da38: call 0x8ee6 ; call 0x85170 / window 980
03da40: r1 = r10
03da48: r1 += -0x130
03da50: r2 = r0
03da58: call 0x939e ; call 0x87750 / window 1009
03da60: *(u64 *)(r10 - 0x928) = r0
03da68: if r7 == 0x0 goto +0xd ; branch 0x3dad8
03da70: r8 = 0xbf
03da78: r9 = 0x0
03da80: if r7 == 0x4 goto +0x1 ; branch 0x3da90
03da88: goto +0x3d1 ; branch 0x3f918
03da90: r1 = *(u64 *)(r10 - 0x920)
03da98: call 0x8ec1 ; call 0x850a8 / window 979
03daa0: r6 = r0
03daa8: r8 = 0x33
03dab0: r4 = *(u64 *)(r10 - 0x928)
03dab8: if r4 > r6 goto +0x3cb ; branch 0x3f918
03dac0: r1 = *(u64 *)(r10 - 0x928)
03dac8: r6 -= r1
03dad0: goto +0x9 ; branch 0x3db20
03dad8: r1 = r6
03dae0: r2 = 0x999e8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
03daf0: call 0x8f84 ; call 0x85718 / window 988
03daf8: r1 = r6
03db00: call 0x8eb4 ; call 0x850a8 / window 979
03db08: r6 = r0
03db10: r1 = 0x0
03db18: *(u64 *)(r10 - 0x928) = r1
03db20: r1 = *(u64 *)(r10 - 0x938)
03db28: call 0x8eaf ; call 0x850a8 / window 979
03db30: r7 = r0
03db38: r7 += r6
03db40: r9 = 0x0
03db48: r4 = 0x1
03db50: if r0 > r7 goto +0x1 ; branch 0x3db60
03db58: r4 = 0x0
03db60: r8 = 0x33
03db68: r4 &= 0x1
03db70: if r4 != 0x0 goto +0x3b4 ; branch 0x3f918
03db78: r1 = *(u64 *)(r10 - 0x938)
03db80: r2 = *(u64 *)(r1 + 0x8)
03db88: r2 += 0x10
03db90: r1 = r10
03db98: r1 += -0x898
03dba0: r3 = 0x9f0a0 ll ; data b'\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00H\x00\x00\x00\x1a\x00\x00\x00\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x1b\xa7\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00S\xa7\t\x006\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00'
03dbb0: call -0x746d ; call 0x3850 / window 86
03dbb8: r1 = *(u64 *)(r10 - 0x898)
03dbc0: r1 = *(u64 *)(r1 + 0x0)
03dbc8: r2 = *(u64 *)(r10 - 0x890)
03dbd0: *(u64 *)(r1 + 0x0) = r7
03dbd8: r1 = *(u64 *)(r2 + 0x0)
03dbe0: r1 += 0x1
03dbe8: *(u64 *)(r2 + 0x0) = r1
03dbf0: r6 = *(u64 *)(r10 - 0x920)
03dbf8: r2 = *(u64 *)(r6 + 0x8)
03dc00: r2 += 0x10
03dc08: r1 = r10
03dc10: r1 += -0x8a8
03dc18: r3 = 0x9f0b8 ll ; data b'\x00\x00\x00\x00\x88\x9a\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x1b\xa7\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00S\xa7\t\x006\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00\x89\xa7\t\x00(\x00\x00\x00\x00\x00\x00\x00\x9f\x00\x00\x004\x00\x00\x00\x00\x00\x00\x00'
03dc28: call -0x747c ; call 0x3850 / window 86
03dc30: r1 = *(u64 *)(r10 - 0x8a8)
03dc38: r1 = *(u64 *)(r1 + 0x0)
03dc40: r2 = *(u64 *)(r10 - 0x8a0)
03dc48: r3 = *(u64 *)(r10 - 0x928)
03dc50: *(u64 *)(r1 + 0x0) = r3
03dc58: r1 = *(u64 *)(r2 + 0x0)
03dc60: r1 += 0x1
03dc68: *(u64 *)(r2 + 0x0) = r1
03dc70: r1 = r6
03dc78: call 0x8e9e ; call 0x85170 / window 980
03dc80: r6 = r0
03dc88: if r6 == 0x0 goto +0x391 ; branch 0x3f918
03dc90: r1 = r10
03dc98: r1 += -0x6c8
03dca0: r2 = *(u64 *)(r10 - 0x920)
03dca8: call 0x8f00 ; call 0x854b0 / window 986
03dcb0: w9 = *(u32 *)(r10 - 0x6c8)
03dcb8: if r9 != 0x16 goto +0x387 ; branch 0x3f8f8
03dcc0: r6 += -0x1
03dcc8: r1 = *(u64 *)(r10 - 0x6b8)
03dcd0: r2 = *(u64 *)(r10 - 0x6c0)
03dcd8: r3 = *(u64 *)(r2 + 0x8)
03dce0: if r3 > r6 goto +0x1 ; branch 0x3dcf0
03dce8: goto +0x4 ; branch 0x3dd10
03dcf0: r2 = *(u64 *)(r2 + 0x0)
03dcf8: r2 += r6
03dd00: r3 = 0x0
03dd08: *(u8 *)(r2 + 0x0) = w3
03dd10: r2 = *(u64 *)(r1 + 0x0)
03dd18: r2 += 0x1
03dd20: *(u64 *)(r1 + 0x0) = r2
03dd28: r8 = *(u64 *)(r10 - 0x930)
03dd30: goto -0x94 ; branch 0x3d898
03dd38: w6 = *(u32 *)(r10 - 0x820)
03dd40: r1 = 0x9aa1b ll ; data b'IX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of Escrow'
03dd50: r2 = 0xa
03dd58: call -0x1 ; external sol_log_
03dd60: r1 = r8
03dd68: r2 = *(u64 *)(r10 - 0x928)
03dd70: r3 = r9
03dd78: r4 = *(u64 *)(r10 - 0x920)
03dd80: r5 = r6
03dd88: call -0x58f ; call 0x3b118 / window 348
03dd90: goto +0x112 ; branch 0x3e628
03dd98: w6 = *(u32 *)(r10 - 0x820)
03dda0: r1 = 0x9aa0f ll ; data b'IX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer O'
03ddb0: r2 = 0xc
03ddb8: call -0x1 ; external sol_log_
03ddc0: r1 = r8
03ddc8: r2 = *(u64 *)(r10 - 0x928)
03ddd0: r3 = r9
03ddd8: r4 = *(u64 *)(r10 - 0x920)
03dde0: r5 = r6
03dde8: call -0x404 ; call 0x3bdd0 / window 349
03ddf0: goto +0x106 ; branch 0x3e628
03ddf8: r1 = 0x9aa25 ll ; data b'IX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close '
03de08: r2 = 0xa
03de10: call -0x1 ; external sol_log_
03de18: r6 = r10
03de20: r6 += -0x6c8
03de28: r1 = r6
03de30: r2 = *(u64 *)(r10 - 0x940)
03de38: r3 = 0x158
03de40: call 0xb62a ; call 0x98f98 / window 1246
03de48: r1 = r8
03de50: r2 = *(u64 *)(r10 - 0x928)
03de58: r3 = r9
03de60: r4 = *(u64 *)(r10 - 0x920)
03de68: r5 = r6
03de70: call -0x1788 ; call 0x32238 / window 337
03de78: r2 = 0x1
03de80: r1 = 0x0
03de88: goto +0xf5 ; branch 0x3e638
03de90: r1 = 0x9a1a0 ll ; data b'IX: Mint (bytes DataItemIX: BurnCpiGuardDeadlockNotFound\x02\x00\x00\x00\x04\x00\x00\x00TransferTimedOut\xff\xff\xff\xff\xff\xff\xff\xff\x01\x00\x00\x00\x03\x00\x00\x00IX: '
03dea0: r2 = 0x8
03dea8: call -0x1 ; external sol_log_
03deb0: r6 = r10
03deb8: r6 += -0x6c8
03dec0: r1 = r6
03dec8: r2 = *(u64 *)(r10 - 0x940)
03ded0: r3 = 0x40
03ded8: call 0xb617 ; call 0x98f98 / window 1246
03dee0: r1 = r8
03dee8: r2 = *(u64 *)(r10 - 0x928)
03def0: r3 = r9
03def8: r4 = *(u64 *)(r10 - 0x920)
03df00: r5 = r6
03df08: call -0x2864 ; call 0x29bf0 / window 323
03df10: r0 = 0x0
03df18: r1 = 0x1
03df20: r2 = 0x1
03df28: r3 = 0x1
03df30: r4 = 0x1
03df38: r5 = 0x1
03df40: goto +0xe2 ; branch 0x3e658
03df48: r1 = 0x4b00000000 ll
03df58: goto +0xa2 ; branch 0x3e470
03df60: r1 = 0x9aa3b ll ; data b'IX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Crea'
03df70: r2 = 0xa
03df78: call -0x1 ; external sol_log_
03df80: r6 = r10
03df88: r6 += -0x6c8
03df90: r1 = r6
03df98: r2 = *(u64 *)(r10 - 0x940)
03dfa0: r3 = 0x38
03dfa8: call 0xb5fd ; call 0x98f98 / window 1246
03dfb0: r1 = r8
03dfb8: r2 = *(u64 *)(r10 - 0x928)
03dfc0: r3 = r9
03dfc8: r4 = *(u64 *)(r10 - 0x920)
03dfd0: r5 = r6
03dfd8: call -0xf46 ; call 0x365b0 / window 342
03dfe0: r3 = 0x0
03dfe8: r1 = 0x1
03dff0: r2 = 0x1
03dff8: goto +0xc8 ; branch 0x3e640
03e000: r1 = *(u64 *)(r10 - 0x928)
03e008: *(u64 *)(r10 - 0x438) = r1
03e010: r1 = r10
03e018: r1 += -0x8b8
03e020: r2 = r9
03e028: r3 = *(u64 *)(r10 - 0x920)
03e030: call 0x74cd ; call 0x786a0 / window 802
03e038: r1 = r10
03e040: r1 += -0x110
03e048: *(u64 *)(r10 - 0x958) = r1
03e050: r1 = r10
03e058: r1 += -0x12b
03e060: *(u64 *)(r10 - 0x960) = r1
03e068: r1 = r10
03e070: r1 += -0x6a8
03e078: *(u64 *)(r10 - 0x968) = r1
03e080: r1 = r10
03e088: r1 += -0x6c3
03e090: *(u64 *)(r10 - 0x950) = r1
03e098: r1 = r10
03e0a0: r1 += -0xe8
03e0a8: *(u64 *)(r10 - 0x980) = r1
03e0b0: r1 = r10
03e0b8: r1 += -0x24
03e0c0: *(u64 *)(r10 - 0x970) = r1
03e0c8: r1 = r10
03e0d0: r1 += -0x5bc
03e0d8: *(u64 *)(r10 - 0x978) = r1
03e0e0: r8 = *(u64 *)(r10 - 0x8b8)
03e0e8: r7 = *(u64 *)(r10 - 0x8b0)
03e0f0: r7 += 0x18
03e0f8: *(u64 *)(r10 - 0x988) = r8
03e100: r9 = 0x0
03e108: r6 = r7
03e110: r6 += -0x18
03e118: if r6 == r8 goto +0x9b ; branch 0x3e5f8
03e120: r2 = r10
03e128: r2 += -0x438
03e130: r1 = r7
03e138: call -0x7691 ; call 0x2cb8 / window 41
03e140: if r0 == 0x0 goto +0x3 ; branch 0x3e160
03e148: r1 = r6
03e150: call 0x8e11 ; call 0x851e0 / window 981
03e158: if r0 == 0x0 goto +0xd ; branch 0x3e1c8
03e160: r1 = r6
03e168: r2 = 0x9f3c8 ll ; data b'\x00\x00\x00\x00h\x98\t\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x88\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
03e178: call -0x7699 ; call 0x2cb8 / window 41
03e180: r9 = 0x1
03e188: if r0 != 0x0 goto +0x8d ; branch 0x3e5f8
03e190: r1 = r7
03e198: r2 = 0x9f3c8 ll ; data b'\x00\x00\x00\x00h\x98\t\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x88\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
03e1a8: call -0x769f ; call 0x2cb8 / window 41
03e1b0: if r0 != 0x0 goto +0x88 ; branch 0x3e5f8
03e1b8: r7 += 0x30
03e1c0: goto -0x19 ; branch 0x3e100
03e1c8: r2 = *(u64 *)(r7 - 0x8)
03e1d0: r2 += 0x10
03e1d8: r1 = r10
03e1e0: r1 += -0x8c8
03e1e8: r3 = 0x9f398 ll ; data b'\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x003\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x00!\x00\x00\x00\x00\x00\x00\x00h\x98\t\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x88\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00'
03e1f8: call -0x7524 ; call 0x38e0 / window 87
03e200: r1 = *(u64 *)(r10 - 0x8c8)
03e208: r2 = *(u64 *)(r1 + 0x8)
03e210: if r2 == 0x0 goto +0x3f9 ; branch 0x401e0
03e218: r2 = *(u64 *)(r10 - 0x8c0)
03e220: r1 = *(u64 *)(r1 + 0x0)
03e228: w1 = *(u8 *)(r1 + 0x0)
03e230: r3 = *(u64 *)(r2 + 0x0)
03e238: r3 += -0x1
03e240: *(u64 *)(r2 + 0x0) = r3
03e248: if r1 == 0x4 goto +0x1 ; branch 0x3e258
03e250: goto -0x14 ; branch 0x3e1b8
03e258: r1 = r10
03e260: r1 += -0x6c8
03e268: r2 = r6
03e270: call 0x13a9 ; call 0x47fc0 / window 419
03e278: r2 = *(u64 *)(r10 - 0x950)
03e280: r1 = *(u64 *)(r2 + 0x0)
03e288: *(u64 *)(r10 - 0x368) = r1
03e290: r1 = *(u64 *)(r2 + 0x8)
03e298: *(u64 *)(r10 - 0x360) = r1
03e2a0: r1 = *(u64 *)(r2 + 0x10)
03e2a8: *(u64 *)(r10 - 0x358) = r1
03e2b0: w1 = *(u32 *)(r2 + 0x17)
03e2b8: *(u32 *)(r10 - 0x351) = w1
03e2c0: w9 = *(u8 *)(r10 - 0x6c4)
03e2c8: w6 = *(u32 *)(r10 - 0x6c8)
03e2d0: w8 = *(u32 *)(r10 - 0x5c0)
03e2d8: if r8 == 0x2 goto +0x58 ; branch 0x3e5a0
03e2e0: r1 = *(u64 *)(r10 - 0x958)
03e2e8: r2 = *(u64 *)(r10 - 0x968)
03e2f0: r3 = 0xe8
03e2f8: call 0xb593 ; call 0x98f98 / window 1246
03e300: r1 = *(u64 *)(r10 - 0x970)
03e308: r2 = *(u64 *)(r10 - 0x978)
03e310: r3 = 0x24
03e318: call 0xb58f ; call 0x98f98 / window 1246
03e320: *(u8 *)(r10 - 0x12c) = w9
03e328: *(u32 *)(r10 - 0x130) = w6
03e330: w1 = *(u32 *)(r10 - 0x351)
03e338: r2 = *(u64 *)(r10 - 0x960)
03e340: *(u32 *)(r2 + 0x17) = w1
03e348: r1 = *(u64 *)(r10 - 0x358)
03e350: *(u64 *)(r2 + 0x10) = r1
03e358: r1 = *(u64 *)(r10 - 0x360)
03e360: *(u64 *)(r2 + 0x8) = r1
03e368: r1 = *(u64 *)(r10 - 0x368)
03e370: *(u64 *)(r2 + 0x0) = r1
03e378: *(u32 *)(r10 - 0x28) = w8
03e380: w1 = *(u32 *)(r10 - 0x7c)
03e388: if r1 == 0x6 goto +0x4 ; branch 0x3e3b0
03e390: r2 = 0xfffffffe ll
03e3a0: r1 &= r2
03e3a8: if r1 == 0x4 goto +0xe4 ; branch 0x3ead0
03e3b0: r1 = *(u64 *)(r10 - 0x980)
03e3b8: call -0x7664 ; call 0x30a0 / window 59
03e3c0: r8 = *(u64 *)(r10 - 0x988)
03e3c8: goto -0x43 ; branch 0x3e1b8
03e3d0: w2 = *(u32 *)(r10 - 0x6c4)
03e3d8: r3 = *(u64 *)(r10 - 0x6c0)
03e3e0: r4 = *(u64 *)(r10 - 0x6b0)
03e3e8: *(u64 *)(r8 + 0x18) = r4
03e3f0: r4 = *(u64 *)(r10 - 0x6b8)
03e3f8: *(u64 *)(r8 + 0x10) = r4
03e400: *(u64 *)(r8 + 0x8) = r3
03e408: *(u32 *)(r8 + 0x4) = w2
03e410: goto +0x8 ; branch 0x3e458
03e418: w2 = *(u32 *)(r10 - 0x6ac)
03e420: *(u32 *)(r8 + 0x1c) = w2
03e428: r2 = *(u64 *)(r10 - 0x6b4)
03e430: *(u64 *)(r8 + 0x14) = r2
03e438: r2 = *(u64 *)(r10 - 0x6bc)
03e440: *(u64 *)(r8 + 0xc) = r2
03e448: r2 = *(u64 *)(r10 - 0x6c4)
03e450: *(u64 *)(r8 + 0x4) = r2
03e458: *(u32 *)(r8 + 0x0) = w1
03e460: goto +0x38 ; branch 0x3e628
03e468: r1 = 0xa
03e470: *(u64 *)(r8 + 0x0) = r1
03e478: goto +0x35 ; branch 0x3e628
03e480: r1 = r10
03e488: r1 += -0x6c8
03e490: r2 = r9
03e498: r3 = 0x9cc8e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
03e4a8: r4 = 0x2
03e4b0: call -0x5d0e ; call 0xfc48 / window 276
03e4b8: w1 = *(u32 *)(r10 - 0x6c8)
03e4c0: if r1 != 0x16 goto +0x3 ; branch 0x3e4e0
03e4c8: r7 = 0x0
03e4d0: r6 = *(u64 *)(r10 - 0x938)
03e4d8: goto -0x25e ; branch 0x3d1f0
03e4e0: w2 = *(u32 *)(r10 - 0x6ac)
03e4e8: r3 = *(u64 *)(r10 - 0x930)
03e4f0: *(u32 *)(r3 + 0x1c) = w2
03e4f8: r2 = *(u64 *)(r10 - 0x6b4)
03e500: *(u64 *)(r3 + 0x14) = r2
03e508: r2 = *(u64 *)(r10 - 0x6bc)
03e510: *(u64 *)(r3 + 0xc) = r2
03e518: r2 = *(u64 *)(r10 - 0x6c4)
03e520: *(u64 *)(r3 + 0x4) = r2
03e528: *(u32 *)(r3 + 0x0) = w1
03e530: goto +0x1e ; branch 0x3e628
03e538: r1 = 0x700000000 ll
03e548: goto -0x1c ; branch 0x3e470
03e550: r1 = 0x0
03e558: r2 = 0x0
03e560: r3 = 0x9f3e8 ll ; data b'\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00[\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00'
03e570: goto +0x3 ; branch 0x3e590
03e578: r1 = 0x2
03e580: r3 = 0x9f400 ll ; data b'\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00L\xad\t\x00#\x00\x00\x00\x00\x00\x00\x00[\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00o\xad\t\x00&\x00\x00\x00\x00\x00\x00\x00Y\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00'
03e590: call 0xa41c ; call 0x90678 / window 1172
03e598: call -0x1 ; external abort
03e5a0: r1 = *(u64 *)(r10 - 0x368)
03e5a8: *(u64 *)(r10 - 0x568) = r1
03e5b0: r1 = *(u64 *)(r10 - 0x360)
03e5b8: *(u64 *)(r10 - 0x560) = r1
03e5c0: r1 = *(u64 *)(r10 - 0x358)
03e5c8: *(u64 *)(r10 - 0x558) = r1
03e5d0: w1 = *(u32 *)(r10 - 0x351)
03e5d8: *(u32 *)(r10 - 0x551) = w1
03e5e0: r1 = r6
03e5e8: if r1 == 0x16 goto +0x1 ; branch 0x3e5f8
03e5f0: goto +0x88 ; branch 0x3ea38
03e5f8: r9 &= 0xff
03e600: if r9 == 0x0 goto +0x3a ; branch 0x3e7d8
03e608: r1 = 0x9900000000 ll
03e618: r2 = *(u64 *)(r10 - 0x930)
03e620: *(u64 *)(r2 + 0x0) = r1
03e628: r1 = 0x1
03e630: r2 = 0x1
03e638: r3 = 0x1
03e640: r4 = 0x1
03e648: r5 = 0x1
03e650: r0 = 0x1
03e658: r6 = 0x1
03e660: w7 = *(u32 *)(r10 - 0x828)
03e668: r8 = r7
03e670: r8 += -0x34
03e678: r9 = 0x2
03e680: if r9 > r8 goto -0x311 ; branch 0x3ce00
03e688: if r7 == 0x29 goto -0x312 ; branch 0x3ce00
03e690: if r7 == 0x2a goto +0x1e ; branch 0x3e788
03e698: if r7 == 0x2b goto +0xb ; branch 0x3e6f8
03e6a0: if r7 == 0x2c goto +0x21 ; branch 0x3e7b0
03e6a8: if r7 == 0x2d goto -0x316 ; branch 0x3ce00
03e6b0: if r7 == 0x2e goto +0x15 ; branch 0x3e760
03e6b8: if r7 == 0x2f goto +0x9 ; branch 0x3e708
03e6c0: if r7 == 0x31 goto +0xa ; branch 0x3e718
03e6c8: if r7 == 0x32 goto +0xe ; branch 0x3e740
03e6d0: if r7 == 0x37 goto -0x31b ; branch 0x3ce00
03e6d8: r1 = r10
03e6e0: r1 += -0x828
03e6e8: call -0x769b ; call 0x3218 / window 66
03e6f0: goto -0x31f ; branch 0x3ce00
03e6f8: if r0 != 0x0 goto +0x5 ; branch 0x3e728
03e700: goto -0x321 ; branch 0x3ce00
03e708: if r3 != 0x0 goto +0xc ; branch 0x3e770
03e710: goto -0x323 ; branch 0x3ce00
03e718: if r2 != 0x0 goto +0x1 ; branch 0x3e728
03e720: goto -0x325 ; branch 0x3ce00
03e728: r1 = r10
03e730: r1 += -0x810
03e738: goto +0x7 ; branch 0x3e778
03e740: if r1 == 0x0 goto -0x329 ; branch 0x3ce00
03e748: r1 = *(u64 *)(r10 - 0x940)
03e750: call -0x7679 ; call 0x3390 / window 68
03e758: goto -0x32c ; branch 0x3ce00
03e760: if r4 != 0x0 goto +0x1 ; branch 0x3e770
03e768: goto -0x32e ; branch 0x3ce00
03e770: r1 = *(u64 *)(r10 - 0x948)
03e778: call -0x75eb ; call 0x3828 / window 85
03e780: goto -0x331 ; branch 0x3ce00
03e788: if r6 != 0x0 goto +0x1 ; branch 0x3e798
03e790: goto -0x333 ; branch 0x3ce00
03e798: r1 = *(u64 *)(r10 - 0x948)
03e7a0: call -0x76e1 ; call 0x30a0 / window 59
03e7a8: goto -0x336 ; branch 0x3ce00
03e7b0: if r5 != 0x0 goto +0x1 ; branch 0x3e7c0
03e7b8: goto -0x338 ; branch 0x3ce00
03e7c0: r1 = *(u64 *)(r10 - 0x940)
03e7c8: call -0x7670 ; call 0x3450 / window 69
03e7d0: goto -0x33b ; branch 0x3ce00
03e7d8: r1 = r10
03e7e0: r1 += -0x6c8
03e7e8: r2 = r10
03e7f0: r2 += -0x828
03e7f8: r3 = 0x160
03e800: call 0xb4f2 ; call 0x98f98 / window 1246
03e808: w1 = *(u32 *)(r10 - 0x6c8)
03e810: if r1 == 0x0 goto +0x3f ; branch 0x3ea10
03e818: if r1 == 0x1 goto +0x3e ; branch 0x3ea10
03e820: if r1 == 0x2 goto +0x3d ; branch 0x3ea10
03e828: r9 = *(u64 *)(r10 - 0x930)
03e830: if r1 == 0x3 goto +0x28 ; branch 0x3e978
03e838: if r1 == 0x4 goto +0xa6 ; branch 0x3ed70
03e840: if r1 == 0x5 goto +0x26 ; branch 0x3e978
03e848: if r1 == 0x6 goto +0x25 ; branch 0x3e978
03e850: if r1 == 0x7 goto +0xad ; branch 0x3edc0
03e858: if r1 == 0x8 goto +0x23 ; branch 0x3e978
03e860: if r1 == 0x9 goto +0x22 ; branch 0x3e978
03e868: if r1 == 0xa goto +0x21 ; branch 0x3e978
03e870: if r1 == 0xb goto +0x1d3 ; branch 0x3f710
03e878: if r1 == 0xc goto +0x1cb ; branch 0x3f6d8
03e880: if r1 == 0xd goto +0x1e ; branch 0x3e978
03e888: if r1 == 0xe goto +0xb0 ; branch 0x3ee10
03e890: if r1 == 0xf goto +0x1e5 ; branch 0x3f7c0
03e898: if r1 == 0x10 goto +0x1b ; branch 0x3e978
03e8a0: if r1 == 0x11 goto +0xdf ; branch 0x3efa0
03e8a8: if r1 == 0x12 goto +0x1d8 ; branch 0x3f770
03e8b0: if r1 == 0x13 goto +0x1ae ; branch 0x3f628
03e8b8: if r1 == 0x14 goto +0x12e ; branch 0x3f230
03e8c0: if r1 == 0x15 goto +0x139 ; branch 0x3f290
03e8c8: if r1 == 0x16 goto +0x1b7 ; branch 0x3f688
03e8d0: if r1 == 0x17 goto +0x141 ; branch 0x3f2e0
03e8d8: if r1 == 0x18 goto +0x14a ; branch 0x3f330
03e8e0: if r1 == 0x19 goto +0xaf ; branch 0x3ee60
03e8e8: if r1 == 0x1a goto +0xe1 ; branch 0x3eff8
03e8f0: if r1 == 0x1b goto +0xb7 ; branch 0x3eeb0
03e8f8: if r1 == 0x1c goto +0x150 ; branch 0x3f380
03e900: if r1 == 0x1d goto +0xe8 ; branch 0x3f048
03e908: if r1 == 0x1e goto +0xbe ; branch 0x3ef00
03e910: if r1 == 0x1f goto +0x157 ; branch 0x3f3d0
03e918: if r1 == 0x20 goto +0xef ; branch 0x3f098
03e920: if r1 == 0x21 goto +0x15f ; branch 0x3f420
03e928: if r1 == 0x22 goto +0xf7 ; branch 0x3f0e8
03e930: if r1 == 0x23 goto +0x188 ; branch 0x3f578
03e938: if r1 == 0x24 goto +0x191 ; branch 0x3f5c8
03e940: if r1 == 0x25 goto +0xc1 ; branch 0x3ef50
03e948: if r1 == 0x26 goto +0xff ; branch 0x3f148
03e950: if r1 == 0x27 goto +0x107 ; branch 0x3f190
03e958: if r1 == 0x28 goto +0x10f ; branch 0x3f1d8
03e960: r1 = 0x2
03e968: *(u32 *)(r9 + 0x0) = w1
03e970: goto +0x3ab ; branch 0x406d0
03e978: r1 = 0x4b00000000 ll
03e988: *(u64 *)(r9 + 0x0) = r1
03e990: goto +0x3a7 ; branch 0x406d0
03e998: r6 = *(u64 *)(r10 - 0x938)
03e9a0: r8 = r6
03e9a8: r8 += 0xc0
03e9b0: r1 = *(u64 *)(r8 + 0x0)
03e9b8: r2 = 0x999a8 ll ; data b"\xed\x03H\x1d\x8d\xf7w\xac\xe7Uv\x9e:\x84\xe6\xde\xedH\xa8\x7f322\xb4\xb74\x96\xde'y\x87\x86\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00prog"
03e9c8: call -0x7798 ; call 0x2d10 / window 44
03e9d0: if r0 != 0x0 goto +0x1 ; branch 0x3e9e0
03e9d8: goto +0x21 ; branch 0x3eae8
03e9e0: r1 = 0xbf00000000 ll
03e9f0: goto -0x7c ; branch 0x3e618
03e9f8: r1 = 0xbf00000000 ll
03ea08: goto -0xb4 ; branch 0x3e470
03ea10: r1 = 0x4b00000000 ll
03ea20: r2 = *(u64 *)(r10 - 0x930)
03ea28: *(u64 *)(r2 + 0x0) = r1
03ea30: goto +0x393 ; branch 0x406d0
03ea38: w1 = *(u32 *)(r10 - 0x551)
03ea40: *(u32 *)(r10 - 0x221) = w1
03ea48: r1 = *(u64 *)(r10 - 0x558)
03ea50: *(u64 *)(r10 - 0x228) = r1
03ea58: r1 = *(u64 *)(r10 - 0x560)
03ea60: *(u64 *)(r10 - 0x230) = r1
03ea68: r2 = *(u64 *)(r10 - 0x568)
03ea70: *(u64 *)(r10 - 0x238) = r2
03ea78: w3 = *(u32 *)(r10 - 0x221)
03ea80: r4 = *(u64 *)(r10 - 0x930)
03ea88: *(u32 *)(r4 + 0x1c) = w3
03ea90: r3 = *(u64 *)(r10 - 0x228)
03ea98: *(u64 *)(r4 + 0x15) = r3
03eaa0: *(u64 *)(r4 + 0xd) = r1
03eaa8: *(u64 *)(r4 + 0x5) = r2
03eab0: *(u8 *)(r4 + 0x4) = w9
03eab8: *(u32 *)(r4 + 0x0) = w6
03eac0: w1 = *(u32 *)(r10 - 0x828)
03eac8: goto -0x307 ; branch 0x3d298
03ead0: r1 = *(u64 *)(r10 - 0x980)
03ead8: call -0x7748 ; call 0x30a0 / window 59
03eae0: goto -0x9c ; branch 0x3e608
03eae8: *(u64 *)(r10 - 0x928) = r8
03eaf0: r6 += 0x30
03eaf8: r1 = r10
03eb00: r1 += -0x858
03eb08: r2 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03eb18: call 0x8ee5 ; call 0x86248 / window 990
03eb20: r2 = *(u64 *)(r9 + 0x0)
03eb28: r1 = *(u64 *)(r10 - 0x858)
03eb30: *(u64 *)(r10 - 0x920) = r1
03eb38: r8 = *(u64 *)(r10 - 0x850)
03eb40: r1 = r10
03eb48: r1 += -0x868
03eb50: call 0x8ede ; call 0x86248 / window 990
03eb58: r1 = 0x7
03eb60: *(u64 *)(r10 - 0x690) = r1
03eb68: r1 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
03eb78: *(u64 *)(r10 - 0x698) = r1
03eb80: *(u64 *)(r10 - 0x6b0) = r8
03eb88: r1 = *(u64 *)(r10 - 0x920)
03eb90: *(u64 *)(r10 - 0x6b8) = r1
03eb98: r1 = 0x8
03eba0: *(u64 *)(r10 - 0x6c0) = r1
03eba8: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
03ebb8: *(u64 *)(r10 - 0x6c8) = r1
03ebc0: r1 = *(u64 *)(r10 - 0x860)
03ebc8: *(u64 *)(r10 - 0x6a0) = r1
03ebd0: r1 = *(u64 *)(r10 - 0x868)
03ebd8: *(u64 *)(r10 - 0x6a8) = r1
03ebe0: r1 = r10
03ebe8: r1 += -0x438
03ebf0: r2 = r10
03ebf8: r2 += -0x6c8
03ec00: call -0x6814 ; call 0xab68 / window 226
03ec08: r4 = *(u64 *)(r10 - 0x430)
03ec10: r5 = *(u64 *)(r10 - 0x428)
03ec18: r1 = r10
03ec20: r1 += -0x6c8
03ec28: r2 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03ec38: *(u64 *)(r10 - 0x920) = r6
03ec40: r3 = r6
03ec48: call -0x5e10 ; call 0xfbd0 / window 273
03ec50: w1 = *(u32 *)(r10 - 0x6c8)
03ec58: if r1 == 0x16 goto +0x1 ; branch 0x3ec68
03ec60: goto +0x14 ; branch 0x3ed08
03ec68: r1 = r10
03ec70: r1 += -0x6c8
03ec78: r2 = *(u64 *)(r10 - 0x938)
03ec80: call 0x1267 ; call 0x47fc0 / window 419
03ec88: w6 = *(u32 *)(r10 - 0x5c0)
03ec90: if r6 != 0x2 goto +0x197 ; branch 0x3f950
03ec98: r1 = *(u64 *)(r10 - 0x6b0)
03eca0: *(u64 *)(r10 - 0x350) = r1
03eca8: r2 = *(u64 *)(r10 - 0x6b8)
03ecb0: *(u64 *)(r10 - 0x358) = r2
03ecb8: r3 = *(u64 *)(r10 - 0x6c0)
03ecc0: *(u64 *)(r10 - 0x360) = r3
03ecc8: r4 = *(u64 *)(r10 - 0x6c8)
03ecd0: *(u64 *)(r10 - 0x368) = r4
03ecd8: r5 = *(u64 *)(r10 - 0x930)
03ece0: *(u64 *)(r5 + 0x18) = r1
03ece8: *(u64 *)(r5 + 0x10) = r2
03ecf0: *(u64 *)(r5 + 0x8) = r3
03ecf8: *(u64 *)(r5 + 0x0) = r4
03ed00: goto +0x1ac ; branch 0x3fa68
03ed08: w2 = *(u8 *)(r10 - 0x6c4)
03ed10: w3 = *(u32 *)(r10 - 0x6ac)
03ed18: r4 = *(u64 *)(r10 - 0x930)
03ed20: *(u32 *)(r4 + 0x1c) = w3
03ed28: r3 = *(u64 *)(r10 - 0x6b3)
03ed30: *(u64 *)(r4 + 0x15) = r3
03ed38: r3 = *(u64 *)(r10 - 0x6bb)
03ed40: *(u64 *)(r4 + 0xd) = r3
03ed48: r3 = *(u64 *)(r10 - 0x6c3)
03ed50: *(u64 *)(r4 + 0x5) = r3
03ed58: *(u8 *)(r4 + 0x4) = w2
03ed60: *(u32 *)(r4 + 0x0) = w1
03ed68: goto +0x19f ; branch 0x3fa68
03ed70: r1 = 0x9ad2b ll ; data b'IX: Update primary sale via tokenprogram/src/state/edition_marker.rsprogram/src/state/edition_marker'
03ed80: r2 = 0x21
03ed88: call -0x1 ; external sol_log_
03ed90: r1 = r9
03ed98: r2 = *(u64 *)(r10 - 0x928)
03eda0: r3 = *(u64 *)(r10 - 0x938)
03eda8: r4 = *(u64 *)(r10 - 0x920)
03edb0: call -0x142f ; call 0x34c40 / window 339
03edb8: goto +0x322 ; branch 0x406d0
03edc0: r1 = 0x9ad1a ll ; data b'IX: Sign MetadataIX: Update primary sale via tokenprogram/src/state/edition_marker.rsprogram/src/sta'
03edd0: r2 = 0x11
03edd8: call -0x1 ; external sol_log_
03ede0: r1 = r9
03ede8: r2 = *(u64 *)(r10 - 0x928)
03edf0: r3 = *(u64 *)(r10 - 0x938)
03edf8: r4 = *(u64 *)(r10 - 0x920)
03ee00: call -0x1fc7 ; call 0x2efd0 / window 332
03ee08: goto +0x318 ; branch 0x406d0
03ee10: r1 = 0x9acb4 ll ; data b'IX: Puff MetadataIX: Convert Master Edition V1 to V2IX: Mint New Edition from Master Edition Via Tok'
03ee20: r2 = 0x11
03ee28: call -0x1 ; external sol_log_
03ee30: r1 = r9
03ee38: r2 = *(u64 *)(r10 - 0x928)
03ee40: r3 = *(u64 *)(r10 - 0x938)
03ee48: r4 = *(u64 *)(r10 - 0x920)
03ee50: call -0x2219 ; call 0x2dd90 / window 329
03ee58: goto +0x30e ; branch 0x406d0
03ee60: r1 = 0x9ab39 ll ; data b'IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Re'
03ee70: r2 = 0x1d
03ee78: call -0x1 ; external sol_log_
03ee80: r1 = r9
03ee88: r2 = *(u64 *)(r10 - 0x928)
03ee90: r3 = *(u64 *)(r10 - 0x938)
03ee98: r4 = *(u64 *)(r10 - 0x920)
03eea0: call -0x4c1d ; call 0x18dc0 / window 303
03eea8: goto +0x304 ; branch 0x406d0
03eeb0: r1 = 0x9abb6 ll ; data b'IX: Thaw Delegated AccountIX: Freeze Delegated AccountIX: Revoke Collection AuthorityIX: Unverify Co'
03eec0: r2 = 0x1a
03eec8: call -0x1 ; external sol_log_
03eed0: r1 = r9
03eed8: r2 = *(u64 *)(r10 - 0x928)
03eee0: r3 = *(u64 *)(r10 - 0x938)
03eee8: r4 = *(u64 *)(r10 - 0x920)
03eef0: call -0x2dbb ; call 0x28120 / window 320
03eef8: goto +0x2fa ; branch 0x406d0
03ef00: r1 = 0x9ab73 ll ; data b'IX: Verify Collection V2IX: Burn NFTIX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Fre'
03ef10: r2 = 0x18
03ef18: call -0x1 ; external sol_log_
03ef20: r1 = r9
03ef28: r2 = *(u64 *)(r10 - 0x928)
03ef30: r3 = *(u64 *)(r10 - 0x938)
03ef38: r4 = *(u64 *)(r10 - 0x920)
03ef40: call -0x451d ; call 0x1c660 / window 309
03ef48: goto +0x2f0 ; branch 0x406d0
03ef50: r1 = 0x9aab0 ll ; data b'IX: Burn Edition NFTIX: Bubblegum Program Set Collection SizeIX: Set Token StandardIX: Set Collectio'
03ef60: r2 = 0x14
03ef68: call -0x1 ; external sol_log_
03ef70: r1 = r9
03ef78: r2 = *(u64 *)(r10 - 0x928)
03ef80: r3 = *(u64 *)(r10 - 0x938)
03ef88: r4 = *(u64 *)(r10 - 0x920)
03ef90: call -0x56e7 ; call 0x13860 / window 297
03ef98: goto +0x2e6 ; branch 0x406d0
03efa0: r1 = *(u64 *)(r10 - 0x6b8)
03efa8: *(u64 *)(r10 - 0x948) = r1
03efb0: r1 = *(u64 *)(r10 - 0x6c0)
03efb8: *(u64 *)(r10 - 0x940) = r1
03efc0: r1 = 0x9ac7d ll ; data b'V3 Create Master EditionIX: Update Metadata Accounts v2IX: Puff MetadataIX: Convert Master Edition V'
03efd0: r2 = 0x18
03efd8: call -0x1 ; external sol_log_
03efe0: r1 = *(u64 *)(r10 - 0x920)
03efe8: if r1 > 0x7 goto +0x155 ; branch 0x3fa98
03eff0: goto +0xeb ; branch 0x3f750
03eff8: r1 = 0x9abd0 ll ; data b'IX: Freeze Delegated AccountIX: Revoke Collection AuthorityIX: Unverify CollectionIX: Revoke Use Aut'
03f008: r2 = 0x1c
03f010: call -0x1 ; external sol_log_
03f018: r1 = r9
03f020: r2 = *(u64 *)(r10 - 0x928)
03f028: r3 = *(u64 *)(r10 - 0x938)
03f030: r4 = *(u64 *)(r10 - 0x920)
03f038: call -0x2f1e ; call 0x27750 / window 319
03f040: goto +0x2d1 ; branch 0x406d0
03f048: r1 = 0x9ab8b ll ; data b'IX: Burn NFTIX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Freeze Delegated AccountIX:'
03f058: r2 = 0xc
03f060: call -0x1 ; external sol_log_
03f068: r1 = r9
03f070: r2 = *(u64 *)(r10 - 0x928)
03f078: r3 = *(u64 *)(r10 - 0x938)
03f080: r4 = *(u64 *)(r10 - 0x920)
03f088: call -0x5606 ; call 0x14060 / window 298
03f090: goto +0x2c7 ; branch 0x406d0
03f098: r1 = 0x9ab39 ll ; data b'IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Re'
03f0a8: r2 = 0x1d
03f0b0: call -0x1 ; external sol_log_
03f0b8: r1 = r9
03f0c0: r2 = *(u64 *)(r10 - 0x928)
03f0c8: r3 = *(u64 *)(r10 - 0x938)
03f0d0: r4 = *(u64 *)(r10 - 0x920)
03f0d8: call -0x4b18 ; call 0x19820 / window 304
03f0e0: goto +0x2bd ; branch 0x406d0
03f0e8: r6 = *(u64 *)(r10 - 0x6c0)
03f0f0: r1 = 0x9ab03 ll ; data b'IX: Set Collection SizeIX: Create Metadata Accounts v3IX: Set and Verify CollectionIX: Unverify Size'
03f100: r2 = 0x17
03f108: call -0x1 ; external sol_log_
03f110: r1 = r9
03f118: r2 = *(u64 *)(r10 - 0x928)
03f120: r3 = *(u64 *)(r10 - 0x938)
03f128: r4 = *(u64 *)(r10 - 0x920)
03f130: r5 = r6
03f138: call -0x49e1 ; call 0x1a238 / window 305
03f140: goto +0x2b1 ; branch 0x406d0
03f148: r1 = 0x9aa97 ll ; data b'IX: Create Escrow AccountIX: Burn Edition NFTIX: Bubblegum Program Set Collection SizeIX: Set Token '
03f158: r2 = 0x19
03f160: call -0x1 ; external sol_log_
03f168: r1 = r9
03f170: r3 = *(u64 *)(r10 - 0x938)
03f178: r4 = *(u64 *)(r10 - 0x920)
03f180: call -0x368a ; call 0x23d38 / window 316
03f188: goto +0x2a8 ; branch 0x406d0
03f190: r1 = 0x9aa7f ll ; data b'IX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Edition NFTIX: Bubblegum Program Set Colle'
03f1a0: r2 = 0x18
03f1a8: call -0x1 ; external sol_log_
03f1b0: r1 = r9
03f1b8: r3 = *(u64 *)(r10 - 0x938)
03f1c0: r4 = *(u64 *)(r10 - 0x920)
03f1c8: call -0x3851 ; call 0x22f48 / window 315
03f1d0: goto +0x29f ; branch 0x406d0
03f1d8: r6 = *(u64 *)(r10 - 0x6c0)
03f1e0: r1 = 0x9aa65 ll ; data b'IX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Edition NFTIX: B'
03f1f0: r2 = 0x1a
03f1f8: call -0x1 ; external sol_log_
03f200: r1 = r9
03f208: r3 = *(u64 *)(r10 - 0x938)
03f210: r4 = *(u64 *)(r10 - 0x920)
03f218: r5 = r6
03f220: call -0x33e2 ; call 0x25318 / window 318
03f228: goto +0x294 ; branch 0x406d0
03f230: r6 = *(u64 *)(r10 - 0x6c0)
03f238: r1 = 0x9ac3a ll ; data b'IX: Approve Use AuthorityIX: Use/Utilize TokenIX: Verify CollectionV3 Create Master EditionIX: Updat'
03f248: r2 = 0x19
03f250: call -0x1 ; external sol_log_
03f258: r1 = r9
03f260: r2 = *(u64 *)(r10 - 0x928)
03f268: r3 = *(u64 *)(r10 - 0x938)
03f270: r4 = *(u64 *)(r10 - 0x920)
03f278: r5 = r6
03f280: call -0xe09 ; call 0x38240 / window 344
03f288: goto +0x288 ; branch 0x406d0
03f290: r1 = 0x9ac22 ll ; data b'IX: Revoke Use AuthorityIX: Approve Use AuthorityIX: Use/Utilize TokenIX: Verify CollectionV3 Create'
03f2a0: r2 = 0x18
03f2a8: call -0x1 ; external sol_log_
03f2b0: r1 = r9
03f2b8: r2 = *(u64 *)(r10 - 0x928)
03f2c0: r3 = *(u64 *)(r10 - 0x938)
03f2c8: r4 = *(u64 *)(r10 - 0x920)
03f2d0: call -0xc3b ; call 0x39100 / window 345
03f2d8: goto +0x27e ; branch 0x406d0
03f2e0: r1 = 0x99b08 ll ; data b'IX: Approve Collection AuthorityInsufficient tokens for transferAccount has already been resizedErro'
03f2f0: r2 = 0x20
03f2f8: call -0x1 ; external sol_log_
03f300: r1 = r9
03f308: r2 = *(u64 *)(r10 - 0x928)
03f310: r3 = *(u64 *)(r10 - 0x938)
03f318: r4 = *(u64 *)(r10 - 0x920)
03f320: call -0x4ed9 ; call 0x17c60 / window 301
03f328: goto +0x274 ; branch 0x406d0
03f330: r1 = 0x9abec ll ; data b'IX: Revoke Collection AuthorityIX: Unverify CollectionIX: Revoke Use AuthorityIX: Approve Use Author'
03f340: r2 = 0x1f
03f348: call -0x1 ; external sol_log_
03f350: r1 = r9
03f358: r2 = *(u64 *)(r10 - 0x928)
03f360: r3 = *(u64 *)(r10 - 0x938)
03f368: r4 = *(u64 *)(r10 - 0x920)
03f370: call -0x4d69 ; call 0x18830 / window 302
03f378: goto +0x26a ; branch 0x406d0
03f380: r1 = 0x9ab97 ll ; data b'IX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Freeze Delegated AccountIX: Revoke Coll'
03f390: r2 = 0x1f
03f398: call -0x1 ; external sol_log_
03f3a0: r1 = r9
03f3a8: r2 = *(u64 *)(r10 - 0x928)
03f3b0: r3 = *(u64 *)(r10 - 0x938)
03f3b8: r4 = *(u64 *)(r10 - 0x920)
03f3c0: call -0x2232 ; call 0x2e238 / window 330
03f3c8: goto +0x260 ; branch 0x406d0
03f3d0: r1 = 0x9ab56 ll ; data b'IX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Remove Creator VerificationIX: '
03f3e0: r2 = 0x1d
03f3e8: call -0x1 ; external sol_log_
03f3f0: r1 = r9
03f3f8: r2 = *(u64 *)(r10 - 0x928)
03f400: r3 = *(u64 *)(r10 - 0x938)
03f408: r4 = *(u64 *)(r10 - 0x920)
03f410: call -0x483a ; call 0x1b248 / window 307
03f418: goto +0x256 ; branch 0x406d0
03f420: r6 = r10
03f428: r6 += -0x368
03f430: r2 = r10
03f438: r2 += -0x6c0
03f440: r1 = r6
03f448: r3 = 0xa8
03f450: call 0xb368 ; call 0x98f98 / window 1246
03f458: r1 = *(u64 *)(r10 - 0x617)
03f460: *(u64 *)(r10 - 0x568) = r1
03f468: r1 = *(u64 *)(r10 - 0x60f)
03f470: *(u64 *)(r10 - 0x560) = r1
03f478: r1 = *(u64 *)(r10 - 0x608)
03f480: *(u64 *)(r10 - 0x559) = r1
03f488: w8 = *(u8 *)(r10 - 0x618)
03f490: r1 = 0x9ab1a ll ; data b'IX: Create Metadata Accounts v3IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify '
03f4a0: r2 = 0x1f
03f4a8: call -0x1 ; external sol_log_
03f4b0: r7 = r10
03f4b8: r7 += -0x130
03f4c0: r1 = r7
03f4c8: r2 = r6
03f4d0: r3 = 0xa8
03f4d8: call 0xb357 ; call 0x98f98 / window 1246
03f4e0: r1 = *(u64 *)(r10 - 0x559)
03f4e8: *(u64 *)(r10 - 0x230) = r1
03f4f0: r1 = *(u64 *)(r10 - 0x561)
03f4f8: *(u64 *)(r10 - 0x238) = r1
03f500: r8 &= 0x1
03f508: *(u64 *)(r10 - 0xff8) = r8
03f510: r1 = r10
03f518: r1 += -0x238
03f520: *(u64 *)(r10 - 0xff0) = r1
03f528: *(u64 *)(r10 - 0x1000) = r7
03f530: r5 = r10
03f538: r1 = r9
03f540: r2 = *(u64 *)(r10 - 0x928)
03f548: r3 = *(u64 *)(r10 - 0x938)
03f550: r4 = *(u64 *)(r10 - 0x920)
03f558: call -0x2b98 ; call 0x298a0 / window 322
03f560: r2 = 0x0
03f568: r1 = 0x1
03f570: goto +0x22d ; branch 0x406e0
03f578: r1 = 0x9aaed ll ; data b'IX: Set Token StandardIX: Set Collection SizeIX: Create Metadata Accounts v3IX: Set and Verify Colle'
03f588: r2 = 0x16
03f590: call -0x1 ; external sol_log_
03f598: r1 = r9
03f5a0: r2 = *(u64 *)(r10 - 0x928)
03f5a8: r3 = *(u64 *)(r10 - 0x938)
03f5b0: r4 = *(u64 *)(r10 - 0x920)
03f5b8: call -0x21ea ; call 0x2e670 / window 331
03f5c0: goto +0x221 ; branch 0x406d0
03f5c8: r6 = *(u64 *)(r10 - 0x6c0)
03f5d0: r1 = 0x9aac4 ll ; data b'IX: Bubblegum Program Set Collection SizeIX: Set Token StandardIX: Set Collection SizeIX: Create Met'
03f5e0: r2 = 0x29
03f5e8: call -0x1 ; external sol_log_
03f5f0: r1 = r9
03f5f8: r2 = *(u64 *)(r10 - 0x928)
03f600: r3 = *(u64 *)(r10 - 0x938)
03f608: r4 = *(u64 *)(r10 - 0x920)
03f610: r5 = r6
03f618: call -0x5c5d ; call 0x11338 / window 295
03f620: goto +0x215 ; branch 0x406d0
03f628: r6 = *(u64 *)(r10 - 0x6c0)
03f630: r1 = 0x9ac53 ll ; data b'IX: Use/Utilize TokenIX: Verify CollectionV3 Create Master EditionIX: Update Metadata Accounts v2IX:'
03f640: r2 = 0x15
03f648: call -0x1 ; external sol_log_
03f650: r1 = r9
03f658: r2 = *(u64 *)(r10 - 0x928)
03f660: r3 = *(u64 *)(r10 - 0x938)
03f668: r4 = *(u64 *)(r10 - 0x920)
03f670: r5 = r6
03f678: call -0xb45 ; call 0x39c58 / window 346
03f680: goto +0x209 ; branch 0x406d0
03f688: r1 = 0x9ac0b ll ; data b'IX: Unverify CollectionIX: Revoke Use AuthorityIX: Approve Use AuthorityIX: Use/Utilize TokenIX: Ver'
03f698: r2 = 0x17
03f6a0: call -0x1 ; external sol_log_
03f6a8: r1 = r9
03f6b0: r2 = *(u64 *)(r10 - 0x928)
03f6b8: r3 = *(u64 *)(r10 - 0x938)
03f6c0: r4 = *(u64 *)(r10 - 0x920)
03f6c8: call -0x49e7 ; call 0x1a798 / window 306
03f6d0: goto +0x1ff ; branch 0x406d0
03f6d8: r1 = 0x9acc5 ll ; data b'IX: Convert Master Edition V1 to V2IX: Mint New Edition from Master Edition Via TokenIX: Sign Metada'
03f6e8: r2 = 0x23
03f6f0: call -0x1 ; external sol_log_
03f6f8: r1 = *(u64 *)(r10 - 0x920)
03f700: if r1 > 0x2 goto +0xd5 ; branch 0x3fdb0
03f708: goto +0x8 ; branch 0x3f750
03f710: r1 = *(u64 *)(r10 - 0x6c0)
03f718: *(u64 *)(r10 - 0x940) = r1
03f720: r1 = 0x9ace8 ll ; data b'IX: Mint New Edition from Master Edition Via TokenIX: Sign MetadataIX: Update primary sale via token'
03f730: r2 = 0x32
03f738: call -0x1 ; external sol_log_
03f740: r1 = *(u64 *)(r10 - 0x920)
03f748: if r1 > 0xc goto +0x7f ; branch 0x3fb48
03f750: r1 = 0xa
03f758: r2 = *(u64 *)(r10 - 0x930)
03f760: *(u32 *)(r2 + 0x0) = w1
03f768: goto +0x1ec ; branch 0x406d0
03f770: r1 = 0x9ac68 ll ; data b'IX: Verify CollectionV3 Create Master EditionIX: Update Metadata Accounts v2IX: Puff MetadataIX: Con'
03f780: r2 = 0x15
03f788: call -0x1 ; external sol_log_
03f790: r1 = r9
03f798: r2 = *(u64 *)(r10 - 0x928)
03f7a0: r3 = *(u64 *)(r10 - 0x938)
03f7a8: r4 = *(u64 *)(r10 - 0x920)
03f7b0: call -0x4747 ; call 0x1bd80 / window 308
03f7b8: goto +0x1e2 ; branch 0x406d0
03f7c0: r6 = r10
03f7c8: r6 += -0x130
03f7d0: r2 = r10
03f7d8: r2 += -0x6c0
03f7e0: r1 = r6
03f7e8: r3 = 0xc9
03f7f0: call 0xb2f4 ; call 0x98f98 / window 1246
03f7f8: w8 = *(u8 *)(r10 - 0x5f6)
03f800: w9 = *(u8 *)(r10 - 0x5f7)
03f808: r1 = 0x9ac95 ll ; data b'IX: Update Metadata Accounts v2IX: Puff MetadataIX: Convert Master Edition V1 to V2IX: Mint New Edit'
03f818: r2 = 0x1f
03f820: call -0x1 ; external sol_log_
03f828: r7 = r10
03f830: r7 += -0x368
03f838: r1 = r7
03f840: r2 = r6
03f848: r3 = 0xa8
03f850: call 0xb2e8 ; call 0x98f98 / window 1246
03f858: r6 = r10
03f860: r6 += -0x568
03f868: r2 = r10
03f870: r2 += -0x88
03f878: r1 = r6
03f880: r3 = 0x21
03f888: call 0xb2e1 ; call 0x98f98 / window 1246
03f890: *(u64 *)(r10 - 0xff0) = r9
03f898: *(u64 *)(r10 - 0xfe8) = r8
03f8a0: *(u64 *)(r10 - 0xff8) = r6
03f8a8: *(u64 *)(r10 - 0x1000) = r7
03f8b0: r5 = r10
03f8b8: r1 = *(u64 *)(r10 - 0x930)
03f8c0: r2 = *(u64 *)(r10 - 0x928)
03f8c8: r3 = *(u64 *)(r10 - 0x938)
03f8d0: r4 = *(u64 *)(r10 - 0x920)
03f8d8: call -0x16dd ; call 0x341f8 / window 338
03f8e0: r2 = 0x1
03f8e8: r1 = 0x0
03f8f0: goto +0x1bd ; branch 0x406e0
03f8f8: r3 = *(u64 *)(r10 - 0x6b0)
03f900: r2 = *(u64 *)(r10 - 0x6b8)
03f908: r1 = *(u64 *)(r10 - 0x6c0)
03f910: w8 = *(u32 *)(r10 - 0x6c4)
03f918: r4 = *(u64 *)(r10 - 0x930)
03f920: *(u64 *)(r4 + 0x18) = r3
03f928: *(u64 *)(r4 + 0x10) = r2
03f930: *(u64 *)(r4 + 0x8) = r1
03f938: *(u32 *)(r4 + 0x4) = w8
03f940: *(u32 *)(r4 + 0x0) = w9
03f948: goto -0x265 ; branch 0x3e628
03f950: r8 = r10
03f958: r8 += -0x368
03f960: r2 = r10
03f968: r2 += -0x6c8
03f970: r1 = r8
03f978: r3 = 0x108
03f980: call 0xb2c2 ; call 0x98f98 / window 1246
03f988: r1 = r10
03f990: r1 += -0x24
03f998: r2 = r10
03f9a0: r2 += -0x5bc
03f9a8: r3 = 0x24
03f9b0: call 0xb2bc ; call 0x98f98 / window 1246
03f9b8: r1 = r10
03f9c0: r1 += -0x130
03f9c8: r2 = r8
03f9d0: r3 = 0x108
03f9d8: call 0xb2b7 ; call 0x98f98 / window 1246
03f9e0: *(u32 *)(r10 - 0x28) = w6
03f9e8: r1 = r10
03f9f0: r1 += -0x10c
03f9f8: *(u64 *)(r10 - 0x6c8) = r1
03fa00: r1 = r10
03fa08: r1 += -0x6c8
03fa10: r2 = r9
03fa18: call -0x79a9 ; call 0x2cd8 / window 42
03fa20: if r0 != 0x0 goto +0x1 ; branch 0x3fa30
03fa28: goto +0xa7 ; branch 0x3ff68
03fa30: r1 = 0xf00000000 ll
03fa40: r2 = *(u64 *)(r10 - 0x930)
03fa48: *(u64 *)(r2 + 0x0) = r1
03fa50: r1 = r10
03fa58: r1 += -0xe8
03fa60: call -0x7939 ; call 0x30a0 / window 59
03fa68: r1 = r10
03fa70: r1 += -0x438
03fa78: call -0x7930 ; call 0x3100 / window 60
03fa80: goto -0x28c ; branch 0x3e628
03fa88: r1 = 0x16
03fa90: goto -0x2c8 ; branch 0x3e458
03fa98: r2 = *(u64 *)(r10 - 0x938)
03faa0: r2 += 0xf0
03faa8: r1 = r10
03fab0: r1 += -0x130
03fab8: *(u64 *)(r10 - 0x920) = r2
03fac0: call 0x109f ; call 0x47fc0 / window 419
03fac8: w9 = *(u32 *)(r10 - 0x28)
03fad0: if r9 != 0x2 goto +0xa8 ; branch 0x40018
03fad8: r1 = *(u64 *)(r10 - 0x118)
03fae0: *(u64 *)(r10 - 0x350) = r1
03fae8: r2 = *(u64 *)(r10 - 0x120)
03faf0: *(u64 *)(r10 - 0x358) = r2
03faf8: r3 = *(u64 *)(r10 - 0x128)
03fb00: *(u64 *)(r10 - 0x360) = r3
03fb08: r4 = *(u64 *)(r10 - 0x130)
03fb10: *(u64 *)(r10 - 0x368) = r4
03fb18: r5 = *(u64 *)(r10 - 0x930)
03fb20: *(u64 *)(r5 + 0x18) = r1
03fb28: *(u64 *)(r5 + 0x10) = r2
03fb30: *(u64 *)(r5 + 0x8) = r3
03fb38: *(u64 *)(r5 + 0x0) = r4
03fb40: goto +0x171 ; branch 0x406d0
03fb48: r1 = *(u64 *)(r10 - 0x938)
03fb50: r1 = *(u64 *)(r1 + 0x210)
03fb58: r2 = 0x99a48 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fb68: call -0x79cc ; call 0x2d10 / window 44
03fb70: if r0 != 0x0 goto +0xca ; branch 0x401c8
03fb78: r3 = *(u64 *)(r10 - 0x938)
03fb80: r6 = r3
03fb88: r6 += 0x120
03fb90: r1 = r10
03fb98: r1 += -0x130
03fba0: r2 = r6
03fba8: call 0x123f ; call 0x48da8 / window 427
03fbb0: w1 = *(u32 *)(r10 - 0x130)
03fbb8: if r1 == 0x16 goto +0x1 ; branch 0x3fbc8
03fbc0: goto +0x69 ; branch 0x3ff10
03fbc8: r1 = *(u64 *)(r10 - 0x938)
03fbd0: r2 = r1
03fbd8: r2 += 0x240
03fbe0: *(u64 *)(r10 - 0x920) = r2
03fbe8: r2 = r1
03fbf0: r2 += 0x210
03fbf8: *(u64 *)(r10 - 0x948) = r2
03fc00: r2 = r1
03fc08: r2 += 0x1e0
03fc10: *(u64 *)(r10 - 0x950) = r2
03fc18: r2 = r1
03fc20: r2 += 0x1b0
03fc28: *(u64 *)(r10 - 0x958) = r2
03fc30: r5 = r1
03fc38: r5 += 0x180
03fc40: r0 = r1
03fc48: r0 += 0x150
03fc50: r8 = r1
03fc58: r8 += 0xf0
03fc60: r9 = r1
03fc68: r9 += 0xc0
03fc70: r3 = r1
03fc78: r3 += 0x90
03fc80: r7 = r1
03fc88: r7 += 0x60
03fc90: r2 = r1
03fc98: r2 += 0x30
03fca0: r4 = *(u64 *)(r10 - 0x920)
03fca8: *(u64 *)(r10 - 0xc0) = r4
03fcb0: r4 = *(u64 *)(r10 - 0x948)
03fcb8: *(u64 *)(r10 - 0xc8) = r4
03fcc0: r4 = *(u64 *)(r10 - 0x950)
03fcc8: *(u64 *)(r10 - 0xd0) = r4
03fcd0: r4 = *(u64 *)(r10 - 0x958)
03fcd8: *(u64 *)(r10 - 0xd8) = r4
03fce0: *(u64 *)(r10 - 0xe0) = r5
03fce8: *(u64 *)(r10 - 0xe8) = r0
03fcf0: *(u64 *)(r10 - 0xf0) = r6
03fcf8: *(u64 *)(r10 - 0xf8) = r8
03fd00: *(u64 *)(r10 - 0x100) = r9
03fd08: *(u64 *)(r10 - 0x108) = r3
03fd10: *(u64 *)(r10 - 0x110) = r7
03fd18: *(u64 *)(r10 - 0x118) = r2
03fd20: *(u64 *)(r10 - 0x120) = r1
03fd28: r1 = 0x0
03fd30: *(u64 *)(r10 - 0x130) = r1
03fd38: *(u64 *)(r10 - 0x128) = r1
03fd40: r1 = r10
03fd48: r1 += -0x368
03fd50: r3 = r10
03fd58: r3 += -0x130
03fd60: r2 = *(u64 *)(r10 - 0x928)
03fd68: r4 = *(u64 *)(r10 - 0x940)
03fd70: call 0x12a5 ; call 0x492a0 / window 429
03fd78: w1 = *(u32 *)(r10 - 0x368)
03fd80: if r1 == 0x16 goto +0x1 ; branch 0x3fd90
03fd88: goto +0x110 ; branch 0x40610
03fd90: r1 = *(u64 *)(r10 - 0x930)
03fd98: r2 = *(u64 *)(r10 - 0x938)
03fda0: call 0x126f ; call 0x49120 / window 428
03fda8: goto +0x124 ; branch 0x406d0
03fdb0: r1 = r10
03fdb8: r1 += -0x130
03fdc0: r2 = *(u64 *)(r10 - 0x938)
03fdc8: r3 = *(u64 *)(r10 - 0x928)
03fdd0: call -0x6035 ; call 0xfc30 / window 275
03fdd8: w1 = *(u32 *)(r10 - 0x130)
03fde0: if r1 != 0x16 goto +0x25 ; branch 0x3ff10
03fde8: r7 = *(u64 *)(r10 - 0x938)
03fdf0: r7 += 0x30
03fdf8: r1 = r10
03fe00: r1 += -0x130
03fe08: r2 = r7
03fe10: r3 = 0x99a48 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fe20: call -0x603f ; call 0xfc30 / window 275
03fe28: w1 = *(u32 *)(r10 - 0x130)
03fe30: if r1 == 0x16 goto +0x1 ; branch 0x3fe40
03fe38: goto +0x1a ; branch 0x3ff10
03fe40: r8 = *(u64 *)(r10 - 0x938)
03fe48: r8 += 0x60
03fe50: r1 = r10
03fe58: r1 += -0x130
03fe60: r2 = r8
03fe68: r3 = 0x99a48 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fe78: call -0x604a ; call 0xfc30 / window 275
03fe80: w1 = *(u32 *)(r10 - 0x130)
03fe88: if r1 == 0x16 goto +0x1 ; branch 0x3fe98
03fe90: goto +0xf ; branch 0x3ff10
03fe98: r1 = r10
03fea0: r1 += -0x130
03fea8: r2 = *(u64 *)(r10 - 0x938)
03feb0: call 0xdcf ; call 0x46d30 / window 412
03feb8: r6 = *(u64 *)(r10 - 0x120)
03fec0: if r6 != 0x2 goto +0x11a ; branch 0x40798
03fec8: r1 = *(u64 *)(r10 - 0x100)
03fed0: *(u64 *)(r10 - 0x550) = r1
03fed8: r2 = *(u64 *)(r10 - 0x108)
03fee0: *(u64 *)(r10 - 0x558) = r2
03fee8: r3 = *(u64 *)(r10 - 0x110)
03fef0: *(u64 *)(r10 - 0x560) = r3
03fef8: r4 = *(u64 *)(r10 - 0x118)
03ff00: *(u64 *)(r10 - 0x568) = r4
03ff08: goto -0x7f ; branch 0x3fb18
03ff10: w2 = *(u32 *)(r10 - 0x114)
03ff18: r3 = *(u64 *)(r10 - 0x930)
03ff20: *(u32 *)(r3 + 0x1c) = w2
03ff28: r2 = *(u64 *)(r10 - 0x11c)
03ff30: *(u64 *)(r3 + 0x14) = r2
03ff38: r2 = *(u64 *)(r10 - 0x124)
03ff40: *(u64 *)(r3 + 0xc) = r2
03ff48: r2 = *(u64 *)(r10 - 0x12c)
03ff50: *(u64 *)(r3 + 0x4) = r2
03ff58: *(u32 *)(r3 + 0x0) = w1
03ff60: goto +0xed ; branch 0x406d0
03ff68: if r7 != 0x0 goto +0x1 ; branch 0x3ff78
03ff70: goto +0x52 ; branch 0x40208
03ff78: r1 = r10
03ff80: r1 += -0x6c8
03ff88: r2 = *(u64 *)(r10 - 0x928)
03ff90: r3 = *(u64 *)(r10 - 0x938)
03ff98: call 0x6c8b ; call 0x763f8 / window 772
03ffa0: w1 = *(u32 *)(r10 - 0x6c8)
03ffa8: if r1 != 0x16 goto +0x137 ; branch 0x40968
03ffb0: r1 = *(u64 *)(r10 - 0x920)
03ffb8: call 0x8a36 ; call 0x85170 / window 980
03ffc0: if r0 == 0x0 goto +0x6 ; branch 0x3fff8
03ffc8: r1 = *(u64 *)(r10 - 0x938)
03ffd0: r1 += 0x48
03ffd8: r2 = 0x9eee8 ll ; data b'\x00\x00\x00\x00\xc8\x99\t\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00'
03ffe8: call -0x7a67 ; call 0x2cb8 / window 41
03fff0: if r0 != 0x0 goto +0x126 ; branch 0x40928
03fff8: r1 = 0x16
040000: r2 = *(u64 *)(r10 - 0x930)
040008: *(u32 *)(r2 + 0x0) = w1
040010: goto -0xb9 ; branch 0x3fa50
040018: r6 = r10
040020: r6 += -0x368
040028: r2 = r10
040030: r2 += -0x130
040038: r1 = r6
040040: r3 = 0x108
040048: call 0xb1e9 ; call 0x98f98 / window 1246
040050: r1 = r10
040058: r1 += -0x45c
040060: r2 = r10
040068: r2 += -0x24
040070: r3 = 0x24
040078: call 0xb1e3 ; call 0x98f98 / window 1246
040080: r1 = r10
040088: r1 += -0x568
040090: r2 = r6
040098: r3 = 0x108
0400a0: call 0xb1de ; call 0x98f98 / window 1246
0400a8: *(u32 *)(r10 - 0x460) = w9
0400b0: r1 = *(u64 *)(r10 - 0x938)
0400b8: r2 = *(u64 *)(r1 + 0x40)
0400c0: r2 += 0x10
0400c8: r1 = r10
0400d0: r1 += -0x8d8
0400d8: r3 = 0x9eff0 ll ; data b'\x00\x00\x00\x00\xb0\xa6\t\x009\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00h\x99\t\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00D\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00\x81\x00\x00\x00'
0400e8: call -0x7902 ; call 0x38e0 / window 87
0400f0: r1 = *(u64 *)(r10 - 0x8d8)
0400f8: r2 = *(u64 *)(r1 + 0x0)
040100: r3 = *(u64 *)(r1 + 0x8)
040108: r9 = *(u64 *)(r10 - 0x8d0)
040110: r1 = r10
040118: r1 += -0x130
040120: call 0x2bef ; call 0x560a0 / window 451
040128: w7 = *(u32 *)(r10 - 0x130)
040130: if r7 == 0x2 goto +0x1 ; branch 0x40140
040138: goto +0x3d ; branch 0x40328
040140: r1 = *(u64 *)(r10 - 0x110)
040148: *(u64 *)(r10 - 0x34c) = r1
040150: r2 = *(u64 *)(r10 - 0x118)
040158: *(u64 *)(r10 - 0x354) = r2
040160: r3 = *(u64 *)(r10 - 0x120)
040168: *(u64 *)(r10 - 0x35c) = r3
040170: r4 = *(u64 *)(r10 - 0x128)
040178: *(u64 *)(r10 - 0x364) = r4
040180: r5 = *(u64 *)(r10 - 0x930)
040188: *(u64 *)(r5 + 0x18) = r1
040190: *(u64 *)(r5 + 0x10) = r2
040198: *(u64 *)(r5 + 0x8) = r3
0401a0: *(u64 *)(r5 + 0x0) = r4
0401a8: r1 = *(u64 *)(r9 + 0x0)
0401b0: r1 += -0x1
0401b8: *(u64 *)(r9 + 0x0) = r1
0401c0: goto +0x9e ; branch 0x406b8
0401c8: r1 = 0x3e00000000 ll
0401d8: goto -0x2f8 ; branch 0x3ea20
0401e0: r1 = 0x0
0401e8: r2 = 0x0
0401f0: r3 = 0x9f3b0 ll ; data b'\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x00!\x00\x00\x00\x00\x00\x00\x00h\x98\t\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x88\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8b\x01\x00\x00'
040200: goto -0x38f ; branch 0x3e590
040208: r1 = *(u64 *)(r10 - 0x938)
040210: r2 = *(u64 *)(r1 + 0x70)
040218: r2 += 0x10
040220: r1 = r10
040228: r1 += -0x878
040230: r3 = 0x9eea0 ll ; data b'\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00=\x00\x00\x00O\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00$\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xc8\x99\t\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
040240: call -0x792d ; call 0x38e0 / window 87
040248: r1 = *(u64 *)(r10 - 0x878)
040250: r2 = *(u64 *)(r1 + 0x0)
040258: r3 = *(u64 *)(r1 + 0x8)
040260: r1 = *(u64 *)(r10 - 0x870)
040268: *(u64 *)(r10 - 0x958) = r1
040270: r1 = r10
040278: r1 += -0x6c8
040280: call 0x776a ; call 0x7bdd8 / window 850
040288: w1 = *(u32 *)(r10 - 0x6b8)
040290: *(u64 *)(r10 - 0x950) = r1
040298: if r1 != 0x2 goto +0x28e ; branch 0x41710
0402a0: r1 = *(u64 *)(r10 - 0x698)
0402a8: *(u64 *)(r10 - 0x21c) = r1
0402b0: r2 = *(u64 *)(r10 - 0x6a0)
0402b8: *(u64 *)(r10 - 0x224) = r2
0402c0: r3 = *(u64 *)(r10 - 0x6a8)
0402c8: *(u64 *)(r10 - 0x22c) = r3
0402d0: r4 = *(u64 *)(r10 - 0x6b0)
0402d8: *(u64 *)(r10 - 0x234) = r4
0402e0: r5 = *(u64 *)(r10 - 0x930)
0402e8: *(u64 *)(r5 + 0x18) = r1
0402f0: *(u64 *)(r5 + 0x10) = r2
0402f8: *(u64 *)(r5 + 0x8) = r3
040300: *(u64 *)(r5 + 0x0) = r4
040308: r2 = *(u64 *)(r10 - 0x958)
040310: r1 = *(u64 *)(r2 + 0x0)
040318: r1 += -0x1
040320: goto -0x11c ; branch 0x3fa48
040328: r6 = r10
040330: r6 += -0x368
040338: r2 = r10
040340: r2 += -0x12c
040348: r1 = r6
040350: r3 = 0x24
040358: call 0xb187 ; call 0x98f98 / window 1246
040360: r1 = r10
040368: r1 += -0x410
040370: r2 = r10
040378: r2 += -0x108
040380: r3 = 0x30
040388: call 0xb181 ; call 0x98f98 / window 1246
040390: r1 = r10
040398: r1 += -0x434
0403a0: r2 = r6
0403a8: r3 = 0x24
0403b0: call 0xb17c ; call 0x98f98 / window 1246
0403b8: *(u32 *)(r10 - 0x438) = w7
0403c0: r1 = *(u64 *)(r9 + 0x0)
0403c8: r1 += -0x1
0403d0: *(u64 *)(r9 + 0x0) = r1
0403d8: r1 = r10
0403e0: r1 += -0x8e8
0403e8: r8 = *(u64 *)(r10 - 0x928)
0403f0: r2 = r8
0403f8: call 0x8bc9 ; call 0x86248 / window 990
040400: r9 = *(u64 *)(r10 - 0x938)
040408: r2 = *(u64 *)(r9 + 0x30)
040410: r6 = *(u64 *)(r10 - 0x8e8)
040418: r7 = *(u64 *)(r10 - 0x8e0)
040420: r1 = r10
040428: r1 += -0x8f8
040430: *(u64 *)(r10 - 0x950) = r2
040438: call 0x8bc1 ; call 0x86248 / window 990
040440: r1 = 0x7
040448: *(u64 *)(r10 - 0xf8) = r1
040450: r1 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
040460: *(u64 *)(r10 - 0x100) = r1
040468: *(u64 *)(r10 - 0x118) = r7
040470: *(u64 *)(r10 - 0x120) = r6
040478: r1 = 0x8
040480: *(u64 *)(r10 - 0x128) = r1
040488: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
040498: *(u64 *)(r10 - 0x130) = r1
0404a0: r1 = *(u64 *)(r10 - 0x8f0)
0404a8: *(u64 *)(r10 - 0x108) = r1
0404b0: r1 = *(u64 *)(r10 - 0x8f8)
0404b8: *(u64 *)(r10 - 0x110) = r1
0404c0: r1 = r10
0404c8: r1 += -0x368
0404d0: r4 = r10
0404d8: r4 += -0x130
0404e0: r2 = r8
0404e8: r3 = r9
0404f0: r5 = 0x4
0404f8: call -0x6126 ; call 0xfbd0 / window 273
040500: w1 = *(u32 *)(r10 - 0x368)
040508: if r1 == 0x16 goto +0x1 ; branch 0x40518
040510: goto +0x28 ; branch 0x40658
040518: r2 = *(u64 *)(r10 - 0x938)
040520: r2 += 0x120
040528: w6 = *(u8 *)(r10 - 0x364)
040530: r1 = r10
040538: r1 += -0x130
040540: r8 = r2
040548: call -0x610d ; call 0xfce8 / window 277
040550: w1 = *(u32 *)(r10 - 0x130)
040558: if r1 == 0x16 goto +0x1 ; branch 0x40568
040560: goto +0xa ; branch 0x405b8
040568: r3 = *(u64 *)(r10 - 0x938)
040570: r3 += 0x90
040578: r1 = r10
040580: r1 += -0x130
040588: r2 = r10
040590: r2 += -0x438
040598: r9 = r3
0405a0: call -0x6209 ; call 0xf560 / window 270
0405a8: w1 = *(u32 *)(r10 - 0x130)
0405b0: if r1 == 0x16 goto +0x8a ; branch 0x40a08
0405b8: w2 = *(u32 *)(r10 - 0x114)
0405c0: r3 = *(u64 *)(r10 - 0x930)
0405c8: *(u32 *)(r3 + 0x1c) = w2
0405d0: r2 = *(u64 *)(r10 - 0x11c)
0405d8: *(u64 *)(r3 + 0x14) = r2
0405e0: r2 = *(u64 *)(r10 - 0x124)
0405e8: *(u64 *)(r3 + 0xc) = r2
0405f0: r2 = *(u64 *)(r10 - 0x12c)
0405f8: *(u64 *)(r3 + 0x4) = r2
040600: *(u32 *)(r3 + 0x0) = w1
040608: goto +0x15 ; branch 0x406b8
040610: w2 = *(u32 *)(r10 - 0x34c)
040618: r3 = *(u64 *)(r10 - 0x930)
040620: *(u32 *)(r3 + 0x1c) = w2
040628: r2 = *(u64 *)(r10 - 0x354)
040630: *(u64 *)(r3 + 0x14) = r2
040638: r2 = *(u64 *)(r10 - 0x35c)
040640: *(u64 *)(r3 + 0xc) = r2
040648: r2 = *(u64 *)(r10 - 0x364)
040650: goto -0xe1 ; branch 0x3ff50
040658: w2 = *(u8 *)(r10 - 0x364)
040660: w3 = *(u32 *)(r10 - 0x34c)
040668: r4 = *(u64 *)(r10 - 0x930)
040670: *(u32 *)(r4 + 0x1c) = w3
040678: r3 = *(u64 *)(r10 - 0x353)
040680: *(u64 *)(r4 + 0x15) = r3
040688: r3 = *(u64 *)(r10 - 0x35b)
040690: *(u64 *)(r4 + 0xd) = r3
040698: r3 = *(u64 *)(r10 - 0x363)
0406a0: *(u64 *)(r4 + 0x5) = r3
0406a8: *(u8 *)(r4 + 0x4) = w2
0406b0: *(u32 *)(r4 + 0x0) = w1
0406b8: r1 = r10
0406c0: r1 += -0x520
0406c8: call -0x7ac6 ; call 0x30a0 / window 59
0406d0: r1 = 0x1
0406d8: r2 = 0x1
0406e0: w3 = *(u32 *)(r10 - 0x6c8)
0406e8: if r3 > 0x28 goto +0x8 ; branch 0x40730
0406f0: r4 = 0x1
0406f8: r4 <<= r3
040700: r5 = 0x114001a2800 ll
040710: r4 &= r5
040718: if r4 != 0x0 goto -0x724 ; branch 0x3ce00
040720: if r3 == 0xf goto +0x4 ; branch 0x40748
040728: if r3 == 0x21 goto +0x9 ; branch 0x40778
040730: r1 = r10
040738: r1 += -0x6c8
040740: goto -0x40c ; branch 0x3e6e8
040748: if r1 != 0x0 goto +0x1 ; branch 0x40758
040750: goto -0x72b ; branch 0x3ce00
040758: r1 = r10
040760: r1 += -0x6c0
040768: call -0x7a03 ; call 0x3758 / window 81
040770: goto -0x72f ; branch 0x3ce00
040778: if r2 == 0x0 goto -0x730 ; branch 0x3ce00
040780: r1 = r10
040788: r1 += -0x6c0
040790: goto -0x3ff ; branch 0x3e7a0
040798: r1 = *(u64 *)(r10 - 0x128)
0407a0: *(u64 *)(r10 - 0x360) = r1
0407a8: r1 = *(u64 *)(r10 - 0x130)
0407b0: *(u64 *)(r10 - 0x368) = r1
0407b8: r1 = *(u64 *)(r10 - 0x118)
0407c0: *(u64 *)(r10 - 0x568) = r1
0407c8: r1 = *(u64 *)(r10 - 0x110)
0407d0: *(u64 *)(r10 - 0x560) = r1
0407d8: r1 = *(u64 *)(r10 - 0x108)
0407e0: *(u64 *)(r10 - 0x558) = r1
0407e8: r1 = *(u64 *)(r10 - 0x100)
0407f0: *(u64 *)(r10 - 0x550) = r1
0407f8: r1 = r10
040800: r1 += -0x330
040808: r2 = r10
040810: r2 += -0xf8
040818: r3 = 0x28
040820: call 0xb0ee ; call 0x98f98 / window 1246
040828: *(u64 *)(r10 - 0x358) = r6
040830: r1 = *(u64 *)(r10 - 0x568)
040838: *(u64 *)(r10 - 0x350) = r1
040840: r1 = *(u64 *)(r10 - 0x560)
040848: *(u64 *)(r10 - 0x348) = r1
040850: r1 = *(u64 *)(r10 - 0x558)
040858: *(u64 *)(r10 - 0x340) = r1
040860: r1 = *(u64 *)(r10 - 0x550)
040868: *(u64 *)(r10 - 0x338) = r1
040870: r1 = r10
040878: r1 += -0x130
040880: r2 = r8
040888: call -0x6269 ; call 0xf548 / window 269
040890: w1 = *(u32 *)(r10 - 0x130)
040898: if r1 == 0x2 goto +0x24 ; branch 0x409c0
0408a0: r6 = *(u64 *)(r10 - 0x108)
0408a8: r1 = r10
0408b0: r1 += -0x130
0408b8: r2 = r7
0408c0: call -0x6270 ; call 0xf548 / window 269
0408c8: w1 = *(u32 *)(r10 - 0x130)
0408d0: if r1 == 0x2 goto +0x1d ; branch 0x409c0
0408d8: r9 = *(u64 *)(r10 - 0x108)
0408e0: r2 = *(u64 *)(r7 + 0x0)
0408e8: r1 = r10
0408f0: r1 += -0x328
0408f8: call -0x7b7e ; call 0x2d10 / window 44
040900: if r0 != 0x0 goto +0x1 ; branch 0x40910
040908: goto +0x3b ; branch 0x40ae8
040910: r1 = 0x1d00000000 ll
040920: goto -0x3e1 ; branch 0x3ea20
040928: r1 = r10
040930: r1 += -0x6c8
040938: r2 = *(u64 *)(r10 - 0x928)
040940: r3 = *(u64 *)(r10 - 0x920)
040948: call 0x6b55 ; call 0x763f8 / window 772
040950: w1 = *(u32 *)(r10 - 0x6c8)
040958: if r1 != 0x16 goto +0x1 ; branch 0x40968
040960: goto -0x12e ; branch 0x3fff8
040968: w2 = *(u32 *)(r10 - 0x6ac)
040970: r3 = *(u64 *)(r10 - 0x930)
040978: *(u32 *)(r3 + 0x1c) = w2
040980: r2 = *(u64 *)(r10 - 0x6b4)
040988: *(u64 *)(r3 + 0x14) = r2
040990: r2 = *(u64 *)(r10 - 0x6bc)
040998: *(u64 *)(r3 + 0xc) = r2
0409a0: r2 = *(u64 *)(r10 - 0x6c4)
0409a8: *(u64 *)(r3 + 0x4) = r2
0409b0: *(u32 *)(r3 + 0x0) = w1
0409b8: goto -0x1ee ; branch 0x3fa50
0409c0: r1 = *(u64 *)(r10 - 0x110)
0409c8: *(u64 *)(r10 - 0x54c) = r1
0409d0: r2 = *(u64 *)(r10 - 0x118)
0409d8: *(u64 *)(r10 - 0x554) = r2
0409e0: r3 = *(u64 *)(r10 - 0x120)
0409e8: *(u64 *)(r10 - 0x55c) = r3
0409f0: r4 = *(u64 *)(r10 - 0x128)
0409f8: *(u64 *)(r10 - 0x564) = r4
040a00: goto -0x1de ; branch 0x3fb18
040a08: r1 = r10
040a10: r1 += -0x130
040a18: r2 = *(u64 *)(r10 - 0x920)
040a20: r3 = *(u64 *)(r10 - 0x928)
040a28: call -0x61c0 ; call 0xfc30 / window 275
040a30: w1 = *(u32 *)(r10 - 0x130)
040a38: if r1 == 0x16 goto +0x1 ; branch 0x40a48
040a40: goto -0x92 ; branch 0x405b8
040a48: r2 = *(u64 *)(r10 - 0x938)
040a50: r2 += 0x30
040a58: r3 = *(u64 *)(r8 + 0x0)
040a60: r1 = r10
040a68: r1 += -0x130
040a70: r7 = r2
040a78: call -0x61ca ; call 0xfc30 / window 275
040a80: w1 = *(u32 *)(r10 - 0x130)
040a88: if r1 == 0x16 goto +0x1 ; branch 0x40a98
040a90: goto -0x9c ; branch 0x405b8
040a98: r1 = r10
040aa0: r1 += -0x544
040aa8: r2 = *(u64 *)(r10 - 0x950)
040ab0: call -0x7bb5 ; call 0x2d10 / window 44
040ab8: if r0 != 0x0 goto +0xe ; branch 0x40b30
040ac0: w1 = *(u8 *)(r10 - 0x408)
040ac8: if r1 == 0x0 goto +0x15 ; branch 0x40b78
040ad0: r1 = 0x1800000000 ll
040ae0: goto +0xb ; branch 0x40b40
040ae8: r2 = *(u64 *)(r8 + 0x0)
040af0: r1 = r10
040af8: r1 += -0x348
040b00: call -0x7bbf ; call 0x2d10 / window 44
040b08: if r0 != 0x0 goto +0x1 ; branch 0x40b18
040b10: goto +0x8 ; branch 0x40b58
040b18: r1 = 0x1c00000000 ll
040b28: goto -0x422 ; branch 0x3ea20
040b30: r1 = 0xf00000000 ll
040b40: r2 = *(u64 *)(r10 - 0x930)
040b48: *(u64 *)(r2 + 0x0) = r1
040b50: goto -0x94 ; branch 0x406b8
040b58: if r6 == 0x0 goto +0xe ; branch 0x40bd0
040b60: r1 = 0x4500000000 ll
040b70: goto -0x42b ; branch 0x3ea20
040b78: r1 = *(u64 *)(r10 - 0x938)
040b80: r1 += 0x150
040b88: *(u64 *)(r10 - 0x958) = r1
040b90: r2 = 0x9ed68 ll ; data b'\x00\x00\x00\x00\xe8\x99\t\x00\x00\x00\x00\x00\xc8\x9a\t\x00\x00\x00\x00\x00\x18\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00H\x9a\t\x00\x00\x00\x00\x00:\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00`\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00'
040ba0: call -0x7bda ; call 0x2cd8 / window 42
040ba8: if r0 != 0x0 goto +0x1 ; branch 0x40bb8
040bb0: goto +0x7 ; branch 0x40bf0
040bb8: r1 = 0x7e00000000 ll
040bc8: goto -0x12 ; branch 0x40b40
040bd0: if r9 == 0x0 goto +0x64 ; branch 0x40ef8
040bd8: r1 = 0x4600000000 ll
040be8: goto -0x43a ; branch 0x3ea20
040bf0: r3 = *(u64 *)(r10 - 0x938)
040bf8: r3 += 0x60
040c00: r1 = r10
040c08: r1 += -0x130
040c10: r2 = r10
040c18: r2 += -0x568
040c20: call -0x63da ; call 0xed58 / window 263
040c28: w1 = *(u32 *)(r10 - 0x130)
040c30: if r1 == 0x16 goto +0x1 ; branch 0x40c40
040c38: goto -0xd1 ; branch 0x405b8
040c40: r1 = *(u64 *)(r10 - 0x410)
040c48: if r1 == 0x1 goto +0x1 ; branch 0x40c58
040c50: goto +0x76 ; branch 0x41008
040c58: r1 = *(u64 *)(r10 - 0x938)
040c60: r1 += 0xc0
040c68: *(u64 *)(r10 - 0x960) = r1
040c70: r1 = r10
040c78: r1 += -0x908
040c80: r2 = *(u64 *)(r10 - 0x928)
040c88: call 0x8ab7 ; call 0x86248 / window 990
040c90: r1 = *(u64 *)(r10 - 0x908)
040c98: *(u64 *)(r10 - 0x968) = r1
040ca0: r1 = *(u64 *)(r10 - 0x900)
040ca8: *(u64 *)(r10 - 0x970) = r1
040cb0: r1 = r10
040cb8: r1 += -0x918
040cc0: r2 = *(u64 *)(r10 - 0x950)
040cc8: call 0x8aaf ; call 0x86248 / window 990
040cd0: r1 = 0x1
040cd8: *(u64 *)(r10 - 0x398) = r1
040ce0: r1 = r10
040ce8: r1 += -0x389
040cf0: *(u64 *)(r10 - 0x3a0) = r1
040cf8: r1 = 0x7
040d00: *(u64 *)(r10 - 0x3a8) = r1
040d08: r1 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
040d18: *(u64 *)(r10 - 0x3b0) = r1
040d20: r1 = *(u64 *)(r10 - 0x970)
040d28: *(u64 *)(r10 - 0x3c8) = r1
040d30: r1 = *(u64 *)(r10 - 0x968)
040d38: *(u64 *)(r10 - 0x3d0) = r1
040d40: r1 = 0x8
040d48: *(u64 *)(r10 - 0x3d8) = r1
040d50: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
040d60: *(u64 *)(r10 - 0x3e0) = r1
040d68: r1 = *(u64 *)(r10 - 0x910)
040d70: *(u64 *)(r10 - 0x3b8) = r1
040d78: r1 = *(u64 *)(r10 - 0x918)
040d80: *(u64 *)(r10 - 0x3c0) = r1
040d88: *(u8 *)(r10 - 0x389) = w6
040d90: r2 = *(u64 *)(r10 - 0x928)
040d98: r1 = *(u64 *)(r2 + 0x18)
040da0: *(u64 *)(r10 - 0x118) = r1
040da8: r1 = *(u64 *)(r2 + 0x10)
040db0: *(u64 *)(r10 - 0x120) = r1
040db8: r1 = *(u64 *)(r2 + 0x8)
040dc0: *(u64 *)(r10 - 0x128) = r1
040dc8: r1 = *(u64 *)(r2 + 0x0)
040dd0: *(u64 *)(r10 - 0x130) = r1
040dd8: r1 = r10
040de0: r1 += -0x3e0
040de8: *(u64 *)(r10 - 0xff0) = r1
040df0: r1 = 0x5
040df8: *(u64 *)(r10 - 0xfe8) = r1
040e00: r1 = 0x14
040e08: *(u64 *)(r10 - 0xff8) = r1
040e10: r1 = *(u64 *)(r10 - 0x960)
040e18: *(u64 *)(r10 - 0x1000) = r1
040e20: r1 = r10
040e28: r1 += -0x368
040e30: r2 = r10
040e38: r2 += -0x130
040e40: r5 = r10
040e48: r3 = *(u64 *)(r10 - 0x938)
040e50: r4 = *(u64 *)(r10 - 0x958)
040e58: call 0x68b0 ; call 0x753e0 / window 770
040e60: w1 = *(u32 *)(r10 - 0x368)
040e68: if r1 == 0x16 goto +0x1 ; branch 0x40e78
040e70: goto +0x65 ; branch 0x411a0
040e78: r1 = r10
040e80: r1 += -0x130
040e88: r2 = *(u64 *)(r10 - 0x938)
040e90: call 0xb87 ; call 0x46ad0 / window 411
040e98: r1 = *(u64 *)(r10 - 0x130)
040ea0: if r1 == 0x0 goto +0x68 ; branch 0x411e8
040ea8: r1 = *(u64 *)(r10 - 0x128)
040eb0: r2 = *(u64 *)(r10 - 0x110)
040eb8: r3 = *(u64 *)(r10 - 0x930)
040ec0: *(u64 *)(r3 + 0x18) = r2
040ec8: r2 = *(u64 *)(r10 - 0x118)
040ed0: *(u64 *)(r3 + 0x10) = r2
040ed8: r2 = *(u64 *)(r10 - 0x120)
040ee0: *(u64 *)(r3 + 0x8) = r2
040ee8: *(u64 *)(r3 + 0x0) = r1
040ef0: goto -0x108 ; branch 0x406b8
040ef8: r6 = *(u64 *)(r10 - 0x938)
040f00: r1 = r6
040f08: call 0x884c ; call 0x85170 / window 980
040f10: r7 = r0
040f18: r1 = r10
040f20: r1 += -0x130
040f28: r2 = r6
040f30: call 0x88af ; call 0x854b0 / window 986
040f38: w1 = *(u32 *)(r10 - 0x130)
040f40: if r1 == 0x16 goto +0x1 ; branch 0x40f50
040f48: goto +0x3f ; branch 0x41148
040f50: r6 = *(u64 *)(r10 - 0x120)
040f58: r1 = *(u64 *)(r10 - 0x128)
040f60: r2 = *(u64 *)(r1 + 0x8)
040f68: r1 = *(u64 *)(r1 + 0x0)
040f70: r3 = *(u64 *)(r10 - 0x350)
040f78: *(u64 *)(r10 - 0x118) = r3
040f80: r3 = *(u64 *)(r10 - 0x358)
040f88: *(u64 *)(r10 - 0x120) = r3
040f90: r3 = *(u64 *)(r10 - 0x360)
040f98: *(u64 *)(r10 - 0x128) = r3
040fa0: r3 = 0x6
040fa8: *(u32 *)(r10 - 0x130) = w3
040fb0: r3 = r10
040fb8: r3 += -0x130
040fc0: call -0x7449 ; call 0x6d80 / window 166
040fc8: if r0 == 0x0 goto +0xa ; branch 0x41020
040fd0: r1 = *(u64 *)(r10 - 0x930)
040fd8: r2 = r0
040fe0: call 0x8c07 ; call 0x87020 / window 1002
040fe8: r1 = *(u64 *)(r6 + 0x0)
040ff0: r1 += 0x1
040ff8: *(u64 *)(r6 + 0x0) = r1
041000: goto -0x127 ; branch 0x406d0
041008: r1 = 0x1000000000 ll
041018: goto -0x9c ; branch 0x40b40
041020: r1 = *(u64 *)(r6 + 0x0)
041028: r1 += 0x1
041030: *(u64 *)(r6 + 0x0) = r1
041038: r1 = r10
041040: r1 += -0x130
041048: r2 = *(u64 *)(r10 - 0x938)
041050: call 0x888b ; call 0x854b0 / window 986
041058: w1 = *(u32 *)(r10 - 0x130)
041060: if r1 == 0x16 goto +0x1 ; branch 0x41070
041068: goto +0x1b ; branch 0x41148
041070: r1 = 0x2
041078: if r1 > r7 goto +0xc4 ; branch 0x416a0
041080: r4 = *(u64 *)(r10 - 0x128)
041088: r1 = r7
041090: r1 += -0x2
041098: r2 = *(u64 *)(r4 + 0x8)
0410a0: if r2 > r1 goto +0x1 ; branch 0x410b0
0410a8: goto +0xc5 ; branch 0x416d8
0410b0: r3 = *(u64 *)(r10 - 0x120)
0410b8: r2 = *(u64 *)(r4 + 0x0)
0410c0: r2 += r1
0410c8: r1 = 0x0
0410d0: *(u8 *)(r2 + 0x0) = w1
0410d8: r7 += -0x1
0410e0: r2 = *(u64 *)(r4 + 0x8)
0410e8: if r2 > r7 goto +0x1 ; branch 0x410f8
0410f0: goto +0xbf ; branch 0x416f0
0410f8: r2 = *(u64 *)(r4 + 0x0)
041100: r2 += r7
041108: *(u8 *)(r2 + 0x0) = w1
041110: r1 = 0x16
041118: r2 = *(u64 *)(r10 - 0x930)
041120: *(u32 *)(r2 + 0x0) = w1
041128: r1 = *(u64 *)(r3 + 0x0)
041130: r1 += 0x1
041138: *(u64 *)(r3 + 0x0) = r1
041140: goto -0x14f ; branch 0x406d0
041148: w2 = *(u32 *)(r10 - 0x12c)
041150: r3 = *(u64 *)(r10 - 0x128)
041158: r4 = *(u64 *)(r10 - 0x120)
041160: r5 = *(u64 *)(r10 - 0x118)
041168: r0 = *(u64 *)(r10 - 0x930)
041170: *(u64 *)(r0 + 0x18) = r5
041178: *(u64 *)(r0 + 0x10) = r4
041180: *(u64 *)(r0 + 0x8) = r3
041188: *(u32 *)(r0 + 0x4) = w2
041190: *(u32 *)(r0 + 0x0) = w1
041198: goto -0x15a ; branch 0x406d0
0411a0: w2 = *(u32 *)(r10 - 0x34c)
0411a8: r3 = *(u64 *)(r10 - 0x930)
0411b0: *(u32 *)(r3 + 0x1c) = w2
0411b8: r2 = *(u64 *)(r10 - 0x354)
0411c0: *(u64 *)(r3 + 0x14) = r2
0411c8: r2 = *(u64 *)(r10 - 0x35c)
0411d0: *(u64 *)(r3 + 0xc) = r2
0411d8: r2 = *(u64 *)(r10 - 0x364)
0411e0: goto -0x17e ; branch 0x405f8
0411e8: r1 = *(u64 *)(r10 - 0x128)
0411f0: *(u64 *)(r10 - 0x388) = r1
0411f8: r1 = *(u64 *)(r10 - 0x948)
041200: *(u64 *)(r10 - 0x370) = r1
041208: r1 = *(u64 *)(r10 - 0x940)
041210: *(u64 *)(r10 - 0x378) = r1
041218: r1 = 0x0
041220: *(u64 *)(r10 - 0x380) = r1
041228: r1 = 0x6
041230: *(u32 *)(r10 - 0x388) = w1
041238: r1 = r10
041240: r1 += -0x130
041248: r2 = *(u64 *)(r10 - 0x938)
041250: call 0x884b ; call 0x854b0 / window 986
041258: w1 = *(u32 *)(r10 - 0x130)
041260: if r1 == 0x16 goto +0x1 ; branch 0x41270
041268: goto +0xf ; branch 0x412e8
041270: r6 = *(u64 *)(r10 - 0x120)
041278: r1 = *(u64 *)(r10 - 0x128)
041280: r2 = *(u64 *)(r1 + 0x8)
041288: r1 = *(u64 *)(r1 + 0x0)
041290: r3 = r10
041298: r3 += -0x388
0412a0: call -0x74a5 ; call 0x6d80 / window 166
0412a8: if r0 == 0x0 goto +0x12 ; branch 0x41340
0412b0: r1 = *(u64 *)(r10 - 0x930)
0412b8: r2 = r0
0412c0: call 0x8bab ; call 0x87020 / window 1002
0412c8: r1 = *(u64 *)(r6 + 0x0)
0412d0: r1 += 0x1
0412d8: *(u64 *)(r6 + 0x0) = r1
0412e0: goto -0x186 ; branch 0x406b8
0412e8: w2 = *(u32 *)(r10 - 0x12c)
0412f0: r3 = *(u64 *)(r10 - 0x128)
0412f8: r4 = *(u64 *)(r10 - 0x120)
041300: r5 = *(u64 *)(r10 - 0x118)
041308: r0 = *(u64 *)(r10 - 0x930)
041310: *(u64 *)(r0 + 0x18) = r5
041318: *(u64 *)(r0 + 0x10) = r4
041320: *(u64 *)(r0 + 0x8) = r3
041328: *(u32 *)(r0 + 0x4) = w2
041330: *(u32 *)(r0 + 0x0) = w1
041338: goto -0x191 ; branch 0x406b8
041340: r1 = *(u64 *)(r6 + 0x0)
041348: r1 += 0x1
041350: *(u64 *)(r6 + 0x0) = r1
041358: r1 = *(u64 *)(r10 - 0x938)
041360: w1 = *(u8 *)(r1 + 0x119)
041368: if r1 == 0x0 goto +0x14 ; branch 0x41410
041370: r1 = r10
041378: r1 += -0x130
041380: r2 = *(u64 *)(r10 - 0x920)
041388: call 0xd86 ; call 0x47fc0 / window 419
041390: w6 = *(u32 *)(r10 - 0x28)
041398: if r6 != 0x2 goto +0x11 ; branch 0x41428
0413a0: r1 = *(u64 *)(r10 - 0x118)
0413a8: *(u64 *)(r10 - 0x220) = r1
0413b0: r2 = *(u64 *)(r10 - 0x120)
0413b8: *(u64 *)(r10 - 0x228) = r2
0413c0: r3 = *(u64 *)(r10 - 0x128)
0413c8: *(u64 *)(r10 - 0x230) = r3
0413d0: r4 = *(u64 *)(r10 - 0x130)
0413d8: *(u64 *)(r10 - 0x238) = r4
0413e0: r5 = *(u64 *)(r10 - 0x930)
0413e8: *(u64 *)(r5 + 0x18) = r1
0413f0: *(u64 *)(r5 + 0x10) = r2
0413f8: *(u64 *)(r5 + 0x8) = r3
041400: *(u64 *)(r5 + 0x0) = r4
041408: goto -0x1ab ; branch 0x406b8
041410: r1 = 0xcb00000000 ll
041420: goto -0x11d ; branch 0x40b40
041428: r1 = r10
041430: r1 += -0x238
041438: *(u64 *)(r10 - 0x928) = r1
041440: r2 = r10
041448: r2 += -0x130
041450: r3 = 0x108
041458: call 0xaf67 ; call 0x98f98 / window 1246
041460: r1 = r10
041468: r1 += -0x25c
041470: r2 = r10
041478: r2 += -0x24
041480: r3 = 0x24
041488: call 0xaf61 ; call 0x98f98 / window 1246
041490: r1 = r10
041498: r1 += -0x368
0414a0: r2 = *(u64 *)(r10 - 0x928)
0414a8: r3 = 0x108
0414b0: call 0xaf5c ; call 0x98f98 / window 1246
0414b8: *(u32 *)(r10 - 0x260) = w6
0414c0: r1 = 0x0
0414c8: *(u32 *)(r10 - 0x2b4) = w1
0414d0: r1 = r10
0414d8: r1 += -0x130
0414e0: r2 = *(u64 *)(r10 - 0x920)
0414e8: call 0x87f8 ; call 0x854b0 / window 986
0414f0: w1 = *(u32 *)(r10 - 0x130)
0414f8: if r1 == 0x16 goto +0x1 ; branch 0x41508
041500: goto +0xf ; branch 0x41580
041508: r6 = *(u64 *)(r10 - 0x120)
041510: r1 = *(u64 *)(r10 - 0x128)
041518: r2 = *(u64 *)(r1 + 0x8)
041520: r1 = *(u64 *)(r1 + 0x0)
041528: r3 = r10
041530: r3 += -0x368
041538: call -0x7514 ; call 0x6ca0 / window 162
041540: if r0 == 0x0 goto +0x15 ; branch 0x415f0
041548: r1 = *(u64 *)(r10 - 0x930)
041550: r2 = r0
041558: call 0x8b58 ; call 0x87020 / window 1002
041560: r1 = *(u64 *)(r6 + 0x0)
041568: r1 += 0x1
041570: *(u64 *)(r6 + 0x0) = r1
041578: goto +0xa ; branch 0x415d0
041580: w2 = *(u32 *)(r10 - 0x12c)
041588: r3 = *(u64 *)(r10 - 0x128)
041590: r4 = *(u64 *)(r10 - 0x120)
041598: r5 = *(u64 *)(r10 - 0x118)
0415a0: r0 = *(u64 *)(r10 - 0x930)
0415a8: *(u64 *)(r0 + 0x18) = r5
0415b0: *(u64 *)(r0 + 0x10) = r4
0415b8: *(u64 *)(r0 + 0x8) = r3
0415c0: *(u32 *)(r0 + 0x4) = w2
0415c8: *(u32 *)(r0 + 0x0) = w1
0415d0: r1 = r10
0415d8: r1 += -0x320
0415e0: call -0x7ca9 ; call 0x30a0 / window 59
0415e8: goto -0x1e7 ; branch 0x406b8
0415f0: r1 = *(u64 *)(r6 + 0x0)
0415f8: r1 += 0x1
041600: *(u64 *)(r6 + 0x0) = r1
041608: r1 = r10
041610: r1 += -0x320
041618: call -0x7cb0 ; call 0x30a0 / window 59
041620: r3 = *(u64 *)(r10 - 0x938)
041628: r2 = *(u64 *)(r3 + 0x0)
041630: *(u64 *)(r10 - 0x1000) = r9
041638: *(u64 *)(r10 - 0xff8) = r8
041640: r1 = r10
041648: r1 += -0x130
041650: r5 = r10
041658: r4 = r7
041660: call 0x2ac8 ; call 0x56ca8 / window 458
041668: w1 = *(u32 *)(r10 - 0x130)
041670: if r1 == 0x16 goto +0x1 ; branch 0x41680
041678: goto -0x219 ; branch 0x405b8
041680: r1 = 0x16
041688: r2 = *(u64 *)(r10 - 0x930)
041690: *(u32 *)(r2 + 0x0) = w1
041698: goto -0x1fd ; branch 0x406b8
0416a0: r1 = 0x9a280 ll ; data b'attempt to subtract with overflowprogram/src/assertions/metadata.rsprogram/src/assertions/misc.rs\x00\x00\x00'
0416b0: r2 = 0x21
0416b8: r3 = 0x9efa8 ll ; data b'\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00<\x00\x00\x00\x1e\x00\x00\x00\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00<\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00=\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xb0\xa6\t\x009\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00'
0416c8: call 0x9dc9 ; call 0x90518 / window 1169
0416d0: call -0x1 ; external abort
0416d8: r3 = 0x9efc0 ll ; data b'\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00<\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00=\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xb0\xa6\t\x009\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00h\x99\t\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x00'
0416e8: goto -0x62c ; branch 0x3e590
0416f0: r1 = r7
0416f8: r3 = 0x9efd8 ll ; data b'\x00\x00\x00\x00p\xa6\t\x00@\x00\x00\x00\x00\x00\x00\x00=\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xb0\xa6\t\x009\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00h\x99\t\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00'
041708: goto -0x630 ; branch 0x3e590
041710: r6 = r10
041718: r6 += -0x238
041720: r2 = r10
041728: r2 += -0x6b4
041730: r1 = r6
041738: r3 = 0x24
041740: call 0xaf0a ; call 0x98f98 / window 1246
041748: r7 = r10
041750: r7 += -0x368
041758: r2 = r10
041760: r2 += -0x690
041768: r1 = r7
041770: r3 = 0x30
041778: call 0xaf03 ; call 0x98f98 / window 1246
041780: r9 = r10
041788: r9 += -0x6c8
041790: r1 = r9
041798: r2 = r6
0417a0: r3 = 0x24
0417a8: call 0xaefd ; call 0x98f98 / window 1246
0417b0: r1 = r10
0417b8: r1 += -0x6a4
0417c0: r2 = r7
0417c8: r3 = 0x30
0417d0: call 0xaef8 ; call 0x98f98 / window 1246
0417d8: r6 = r10
0417e0: r6 += -0x568
0417e8: r1 = r6
0417f0: r2 = r9
0417f8: r3 = 0x54
041800: call 0xaef2 ; call 0x98f98 / window 1246
041808: r2 = *(u64 *)(r10 - 0x958)
041810: r1 = *(u64 *)(r2 + 0x0)
041818: r1 += -0x1
041820: *(u64 *)(r2 + 0x0) = r1
041828: r1 = *(u64 *)(r10 - 0x950)
041830: *(u32 *)(r10 - 0x6c8) = w1
041838: r1 = r10
041840: r1 += -0x6c4
041848: r2 = r6
041850: r3 = 0x54
041858: call 0xaee7 ; call 0x98f98 / window 1246
041860: r1 = r10
041868: r1 += -0x368
041870: r2 = r10
041878: r2 += -0x6c8
041880: r3 = 0x9eeb8 ll ; data b'\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00$\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xc8\x99\t\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00'
041890: call -0x7ac5 ; call 0x4270 / window 95
041898: r1 = *(u64 *)(r10 - 0x340)
0418a0: if r1 == 0x0 goto +0x14 ; branch 0x41948
0418a8: r1 = *(u64 *)(r10 - 0x950)
0418b0: *(u32 *)(r10 - 0x6c8) = w1
0418b8: r1 = r10
0418c0: r1 += -0x6c4
0418c8: r2 = r10
0418d0: r2 += -0x568
0418d8: r3 = 0x54
0418e0: call 0xaed6 ; call 0x98f98 / window 1246
0418e8: r1 = r10
0418f0: r1 += -0x368
0418f8: r2 = r10
041900: r2 += -0x6c8
041908: r3 = 0x9eef0 ll ; data b'\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00'
041918: call -0x7ad6 ; call 0x4270 / window 95
041920: r1 = *(u64 *)(r10 - 0x340)
041928: if r1 == 0x0 goto +0x2c ; branch 0x41a90
041930: r1 = 0xa000000000 ll
041940: goto -0x3e1 ; branch 0x3fa40
041948: r1 = *(u64 *)(r10 - 0x950)
041950: *(u32 *)(r10 - 0x6c8) = w1
041958: r1 = r10
041960: r1 += -0x6c4
041968: r2 = r10
041970: r2 += -0x568
041978: r3 = 0x54
041980: call 0xaec2 ; call 0x98f98 / window 1246
041988: r1 = r10
041990: r1 += -0x368
041998: r2 = r10
0419a0: r2 += -0x6c8
0419a8: r3 = 0x9eed0 ll ; data b'\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xc8\x99\t\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00'
0419b8: call -0x7aea ; call 0x4270 / window 95
0419c0: w1 = *(u32 *)(r10 - 0x368)
0419c8: if r1 == 0x0 goto -0x34b ; branch 0x3ff78
0419d0: r1 = *(u64 *)(r10 - 0x34c)
0419d8: *(u64 *)(r10 - 0x220) = r1
0419e0: r1 = *(u64 *)(r10 - 0x354)
0419e8: *(u64 *)(r10 - 0x228) = r1
0419f0: r1 = *(u64 *)(r10 - 0x35c)
0419f8: *(u64 *)(r10 - 0x230) = r1
041a00: r1 = *(u64 *)(r10 - 0x364)
041a08: *(u64 *)(r10 - 0x238) = r1
041a10: r1 = *(u64 *)(r10 - 0x920)
041a18: r2 = *(u64 *)(r1 + 0x0)
041a20: r1 = r10
041a28: r1 += -0x238
041a30: call 0x8567 ; call 0x84570 / window 955
041a38: if r0 != 0x0 goto -0x359 ; branch 0x3ff78
041a40: r6 = r10
041a48: r6 += -0x6c8
041a50: r1 = r6
041a58: call 0x8310 ; call 0x832e0 / window 915
041a60: r1 = r10
041a68: r1 += -0x238
041a70: r2 = r6
041a78: call 0x855e ; call 0x84570 / window 955
041a80: if r0 != 0x0 goto -0x362 ; branch 0x3ff78
041a88: goto -0x3d ; branch 0x418a8
041a90: r1 = *(u64 *)(r10 - 0x950)
041a98: *(u32 *)(r10 - 0x6c8) = w1
041aa0: r1 = r10
041aa8: r1 += -0x6c4
041ab0: r2 = r10
041ab8: r2 += -0x568
041ac0: r3 = 0x54
041ac8: call 0xae99 ; call 0x98f98 / window 1246
041ad0: r1 = r10
041ad8: r1 += -0x368
041ae0: r2 = r10
041ae8: r2 += -0x6c8
041af0: r3 = 0x9ef08 ll ; data b'\x00\x00\x00\x00\xe6\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\x08\xa5\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00?\xa5\t\x00B\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00'
041b00: call -0x7b13 ; call 0x4270 / window 95
041b08: w1 = *(u32 *)(r10 - 0x368)
041b10: r2 = 0x0
041b18: r3 = *(u64 *)(r10 - 0x930)
041b20: *(u32 *)(r3 + 0x0) = w2
041b28: if r1 != 0x0 goto +0x2 ; branch 0x41b40
041b30: r1 = 0xca
041b38: goto +0x1 ; branch 0x41b48
041b40: r1 = 0xa
041b48: r2 = *(u64 *)(r10 - 0x930)
041b50: *(u32 *)(r2 + 0x4) = w1
041b58: goto -0x422 ; branch 0x3fa50
