01f538: r9 = r5
01f540: *(u64 *)(r10 - 0x450) = r4
01f548: r7 = r3
01f550: *(u64 *)(r10 - 0x448) = r2
01f558: r6 = r1
01f560: r8 = *(u64 *)(r7 + 0x58)
01f568: r1 = r10
01f570: r1 += -0x1c8
01f578: r2 = r8
01f580: call 0xae07 ; call 0x765c0 / window 773
01f588: w1 = *(u32 *)(r10 - 0x1c8)
01f590: if r1 != 0x16 goto +0x7 ; branch 0x1f5d0
01f598: r2 = *(u64 *)(r7 + 0x50)
01f5a0: r1 = r10
01f5a8: r1 += -0x1c8
01f5b0: *(u64 *)(r10 - 0x458) = r2
01f5b8: call 0xae00 ; call 0x765c0 / window 773
01f5c0: w1 = *(u32 *)(r10 - 0x1c8)
01f5c8: if r1 == 0x16 goto +0xe ; branch 0x1f640
01f5d0: w2 = *(u32 *)(r10 - 0x1ac)
01f5d8: *(u32 *)(r10 - 0x3e8) = w2
01f5e0: r3 = *(u64 *)(r10 - 0x1b4)
01f5e8: *(u64 *)(r10 - 0x3f0) = r3
01f5f0: r4 = *(u64 *)(r10 - 0x1bc)
01f5f8: *(u64 *)(r10 - 0x3f8) = r4
01f600: r5 = *(u64 *)(r10 - 0x1c4)
01f608: *(u64 *)(r10 - 0x400) = r5
01f610: *(u32 *)(r6 + 0x1c) = w2
01f618: *(u64 *)(r6 + 0x14) = r3
01f620: *(u64 *)(r6 + 0xc) = r4
01f628: *(u64 *)(r6 + 0x4) = r5
01f630: *(u32 *)(r6 + 0x0) = w1
01f638: exit
01f640: r2 = *(u64 *)(r7 + 0x40)
01f648: r1 = r10
01f650: r1 += -0x1c8
01f658: *(u64 *)(r10 - 0x460) = r2
01f660: r3 = *(u64 *)(r10 - 0x448)
01f668: call -0x1f48 ; call 0xfc30 / window 275
01f670: w1 = *(u32 *)(r10 - 0x1c8)
01f678: if r1 == 0x16 goto +0x1 ; branch 0x1f688
01f680: goto -0x17 ; branch 0x1f5d0
01f688: r2 = *(u64 *)(r7 + 0x48)
01f690: r1 = r10
01f698: r1 += -0x1c8
01f6a0: *(u64 *)(r10 - 0x468) = r2
01f6a8: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
01f6b8: r4 = 0x2
01f6c0: call -0x1f50 ; call 0xfc48 / window 276
01f6c8: w1 = *(u32 *)(r10 - 0x1c8)
01f6d0: if r1 == 0x16 goto +0x1 ; branch 0x1f6e0
01f6d8: goto -0x22 ; branch 0x1f5d0
01f6e0: r1 = *(u64 *)(r7 + 0x60)
01f6e8: *(u64 *)(r10 - 0x470) = r1
01f6f0: r1 = *(u64 *)(r1 + 0x0)
01f6f8: r2 = 0x998d8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
01f708: call 0xaddc ; call 0x765f0 / window 774
01f710: if r0 != 0x0 goto +0x1 ; branch 0x1f720
01f718: goto +0x1a ; branch 0x1f7f0
01f720: r1 = *(u64 *)(r7 + 0x68)
01f728: r1 = *(u64 *)(r1 + 0x0)
01f730: r2 = 0x999b8 ll ; data b"\x06\xa7\xd5\x17\x18{\xd1f5\xda\xd4\x04U\xfd\xc2\xc0\xc1$\xc6\x8f!Vu\xa5\xdb\xba\xcb_\x08\x00\x00\x00\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsu"
01f740: call 0xadd5 ; call 0x765f0 / window 774
01f748: if r0 != 0x0 goto +0x1 ; branch 0x1f758
01f750: goto +0x13 ; branch 0x1f7f0
01f758: r1 = r10
01f760: r1 += -0x1c8
01f768: r2 = *(u64 *)(r10 - 0x460)
01f770: call 0x50e8 ; call 0x47eb8 / window 419
01f778: w3 = *(u32 *)(r10 - 0xc0)
01f780: if r3 != 0x2 goto +0x11 ; branch 0x1f810
01f788: r1 = *(u64 *)(r10 - 0x1b0)
01f790: *(u64 *)(r10 - 0x2b8) = r1
01f798: r2 = *(u64 *)(r10 - 0x1b8)
01f7a0: *(u64 *)(r10 - 0x2c0) = r2
01f7a8: r3 = *(u64 *)(r10 - 0x1c0)
01f7b0: *(u64 *)(r10 - 0x2c8) = r3
01f7b8: r4 = *(u64 *)(r10 - 0x1c8)
01f7c0: *(u64 *)(r10 - 0x2d0) = r4
01f7c8: *(u64 *)(r6 + 0x18) = r1
01f7d0: *(u64 *)(r6 + 0x10) = r2
01f7d8: *(u64 *)(r6 + 0x8) = r3
01f7e0: *(u64 *)(r6 + 0x0) = r4
01f7e8: goto -0x37 ; branch 0x1f638
01f7f0: r1 = 0x9a00000000 ll
01f800: *(u64 *)(r6 + 0x0) = r1
01f808: goto -0x3b ; branch 0x1f638
01f810: r1 = r10
01f818: r1 += -0x2d0
01f820: *(u64 *)(r10 - 0x480) = r1
01f828: r2 = r10
01f830: r2 += -0x1c8
01f838: *(u64 *)(r10 - 0x478) = r3
01f840: r3 = 0x108
01f848: call 0xf2c8 ; call 0x98e90 / window 1246
01f850: r1 = r10
01f858: r1 += -0x2f4
01f860: r2 = r10
01f868: r2 += -0xbc
01f870: r3 = 0x24
01f878: call 0xf2c2 ; call 0x98e90 / window 1246
01f880: r1 = r10
01f888: r1 += -0x400
01f890: r2 = *(u64 *)(r10 - 0x480)
01f898: r3 = 0x108
01f8a0: call 0xf2bd ; call 0x98e90 / window 1246
01f8a8: r1 = *(u64 *)(r10 - 0x478)
01f8b0: *(u32 *)(r10 - 0x2f8) = w1
01f8b8: r1 = *(u64 *)(r10 - 0x468)
01f8c0: r2 = *(u64 *)(r1 + 0x0)
01f8c8: r1 = r10
01f8d0: r1 += -0x3dc
01f8d8: call -0x397a ; call 0x2d10 / window 44
01f8e0: if r0 != 0x0 goto +0x1 ; branch 0x1f8f0
01f8e8: goto +0x3 ; branch 0x1f908
01f8f0: r1 = 0xf00000000 ll
01f900: goto +0x40 ; branch 0x1fb08
01f908: r1 = *(u64 *)(r10 - 0x450)
01f910: r1 <<= 0x20
01f918: r1 >>= 0x20
01f920: if r1 == 0x0 goto +0x7 ; branch 0x1f960
01f928: if r1 == 0x1 goto +0x1 ; branch 0x1f938
01f930: goto +0x35 ; branch 0x1fae0
01f938: r1 = *(u64 *)(r7 + 0x18)
01f940: if r1 != 0x0 goto +0x19 ; branch 0x1fa10
01f948: r1 = 0x9400000000 ll
01f958: goto +0x35 ; branch 0x1fb08
01f960: r1 = r10
01f968: r1 += -0x1c8
01f970: r2 = r10
01f978: r2 += -0x400
01f980: r3 = *(u64 *)(r10 - 0x458)
01f988: call -0x2187 ; call 0xed58 / window 263
01f990: w1 = *(u32 *)(r10 - 0x1c8)
01f998: if r1 == 0x16 goto +0x1f ; branch 0x1fa98
01f9a0: w2 = *(u32 *)(r10 - 0x1ac)
01f9a8: *(u32 *)(r10 - 0x2b8) = w2
01f9b0: r3 = *(u64 *)(r10 - 0x1b4)
01f9b8: *(u64 *)(r10 - 0x2c0) = r3
01f9c0: r4 = *(u64 *)(r10 - 0x1bc)
01f9c8: *(u64 *)(r10 - 0x2c8) = r4
01f9d0: r5 = *(u64 *)(r10 - 0x1c4)
01f9d8: *(u64 *)(r10 - 0x2d0) = r5
01f9e0: *(u32 *)(r6 + 0x1c) = w2
01f9e8: *(u64 *)(r6 + 0x14) = r3
01f9f0: *(u64 *)(r6 + 0xc) = r4
01f9f8: *(u64 *)(r6 + 0x4) = r5
01fa00: *(u32 *)(r6 + 0x0) = w1
01fa08: goto +0x20 ; branch 0x1fb10
01fa10: *(u64 *)(r10 - 0xff0) = r1
01fa18: r1 = 0x1
01fa20: *(u64 *)(r10 - 0xfe8) = r1
01fa28: r1 = *(u64 *)(r10 - 0x468)
01fa30: *(u64 *)(r10 - 0xff8) = r1
01fa38: r1 = r10
01fa40: r1 += -0x400
01fa48: *(u64 *)(r10 - 0x1000) = r1
01fa50: r1 = r10
01fa58: r1 += -0x1c8
01fa60: r5 = r10
01fa68: r2 = *(u64 *)(r10 - 0x448)
01fa70: r3 = *(u64 *)(r10 - 0x458)
01fa78: r4 = *(u64 *)(r10 - 0x460)
01fa80: call -0x2187 ; call 0xee50 / window 265
01fa88: w1 = *(u32 *)(r10 - 0x1c8)
01fa90: if r1 != 0x16 goto -0x1f ; branch 0x1f9a0
01fa98: r1 = *(u64 *)(r7 + 0x0)
01faa0: *(u64 *)(r10 - 0x460) = r1
01faa8: if r1 == 0x0 goto +0x9 ; branch 0x1faf8
01fab0: r7 = *(u64 *)(r7 + 0x38)
01fab8: r1 = *(u64 *)(r10 - 0x450)
01fac0: r1 <<= 0x20
01fac8: r1 >>= 0x20
01fad0: if r1 == 0x0 goto +0xb ; branch 0x1fb30
01fad8: if r1 == 0x1 goto +0x11 ; branch 0x1fb68
01fae0: r1 = 0xa500000000 ll
01faf0: goto +0x2 ; branch 0x1fb08
01faf8: r1 = 0xbe00000000 ll
01fb08: *(u64 *)(r6 + 0x0) = r1
01fb10: r1 = r10
01fb18: r1 += -0x3b8
01fb20: call -0x3951 ; call 0x30a0 / window 59
01fb28: goto -0x9f ; branch 0x1f638
01fb30: *(u32 *)(r10 - 0x1c8) = w9
01fb38: r1 = r10
01fb40: r1 += -0x98
01fb48: r2 = r10
01fb50: r2 += -0x1c8
01fb58: call -0x3a37 ; call 0x29a8 / window 35
01fb60: goto +0x6 ; branch 0x1fb98
01fb68: *(u32 *)(r10 - 0x1c8) = w9
01fb70: r1 = r10
01fb78: r1 += -0x98
01fb80: r2 = r10
01fb88: r2 += -0x1c8
01fb90: call -0x3a59 ; call 0x28d0 / window 34
01fb98: r1 = 0x60
01fba0: r2 = 0x8
01fba8: call -0x33e5 ; call 0x5c88 / window 138
01fbb0: r9 = r0
01fbb8: r1 = r10
01fbc0: r1 += -0x410
01fbc8: r2 = *(u64 *)(r10 - 0x448)
01fbd0: call 0xccad ; call 0x86140 / window 990
01fbd8: r1 = *(u64 *)(r10 - 0x468)
01fbe0: r2 = *(u64 *)(r1 + 0x0)
01fbe8: r1 = *(u64 *)(r10 - 0x410)
01fbf0: *(u64 *)(r10 - 0x468) = r1
01fbf8: r1 = *(u64 *)(r10 - 0x408)
01fc00: *(u64 *)(r10 - 0x478) = r1
01fc08: r1 = r10
01fc10: r1 += -0x420
01fc18: *(u64 *)(r10 - 0x4a8) = r2
01fc20: call 0xcca3 ; call 0x86140 / window 990
01fc28: r1 = *(u64 *)(r10 - 0x458)
01fc30: r2 = *(u64 *)(r1 + 0x0)
01fc38: r1 = *(u64 *)(r10 - 0x420)
01fc40: *(u64 *)(r10 - 0x458) = r1
01fc48: r1 = *(u64 *)(r10 - 0x418)
01fc50: *(u64 *)(r10 - 0x480) = r1
01fc58: r1 = *(u64 *)(r10 - 0x90)
01fc60: *(u64 *)(r10 - 0x488) = r1
01fc68: r1 = *(u64 *)(r10 - 0x88)
01fc70: *(u64 *)(r10 - 0x490) = r1
01fc78: r1 = r10
01fc80: r1 += -0x430
01fc88: *(u64 *)(r10 - 0x4a0) = r2
01fc90: call 0xcc95 ; call 0x86140 / window 990
01fc98: r2 = *(u64 *)(r7 + 0x0)
01fca0: r1 = *(u64 *)(r10 - 0x430)
01fca8: *(u64 *)(r10 - 0x498) = r1
01fcb0: r7 = *(u64 *)(r10 - 0x428)
01fcb8: r1 = r10
01fcc0: r1 += -0x440
01fcc8: *(u64 *)(r10 - 0x4b0) = r2
01fcd0: call 0xcc8d ; call 0x86140 / window 990
01fcd8: r1 = *(u64 *)(r10 - 0x440)
01fce0: r2 = *(u64 *)(r10 - 0x438)
01fce8: *(u64 *)(r9 + 0x58) = r2
01fcf0: *(u64 *)(r9 + 0x50) = r1
01fcf8: *(u64 *)(r9 + 0x48) = r7
01fd00: r1 = *(u64 *)(r10 - 0x498)
01fd08: *(u64 *)(r9 + 0x40) = r1
01fd10: r1 = *(u64 *)(r10 - 0x490)
01fd18: *(u64 *)(r9 + 0x38) = r1
01fd20: r1 = *(u64 *)(r10 - 0x488)
01fd28: *(u64 *)(r9 + 0x30) = r1
01fd30: r1 = *(u64 *)(r10 - 0x480)
01fd38: *(u64 *)(r9 + 0x28) = r1
01fd40: r1 = *(u64 *)(r10 - 0x458)
01fd48: *(u64 *)(r9 + 0x20) = r1
01fd50: r1 = *(u64 *)(r10 - 0x478)
01fd58: *(u64 *)(r9 + 0x18) = r1
01fd60: r1 = *(u64 *)(r10 - 0x468)
01fd68: *(u64 *)(r9 + 0x10) = r1
01fd70: r1 = 0x8
01fd78: *(u64 *)(r9 + 0x8) = r1
01fd80: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
01fd90: *(u64 *)(r9 + 0x0) = r1
01fd98: r1 = 0x6
01fda0: *(u64 *)(r10 - 0x70) = r1
01fda8: *(u64 *)(r10 - 0x78) = r9
01fdb0: *(u64 *)(r10 - 0x80) = r1
01fdb8: r1 = r10
01fdc0: r1 += -0x1c8
01fdc8: r2 = *(u64 *)(r10 - 0x448)
01fdd0: r7 = *(u64 *)(r10 - 0x460)
01fdd8: r3 = r7
01fde0: r4 = r9
01fde8: r5 = 0x6
01fdf0: call -0x2045 ; call 0xfbd0 / window 273
01fdf8: w1 = *(u32 *)(r10 - 0x1c8)
01fe00: if r1 != 0x16 goto +0x7d ; branch 0x201f0
01fe08: w1 = *(u8 *)(r10 - 0x1c4)
01fe10: *(u8 *)(r10 - 0x61) = w1
01fe18: r1 = r10
01fe20: r1 += -0x80
01fe28: r2 = r10
01fe30: r2 += -0x61
01fe38: r3 = 0x1
01fe40: call -0x3494 ; call 0x59a8 / window 131
01fe48: r1 = r7
01fe50: call 0xca50 ; call 0x850d8 / window 981
01fe58: if r0 != 0x0 goto +0x1 ; branch 0x1fe68
01fe60: goto +0x7d ; branch 0x20250
01fe68: r2 = *(u64 *)(r10 - 0x448)
01fe70: r1 = *(u64 *)(r2 + 0x18)
01fe78: *(u64 *)(r10 - 0x1b0) = r1
01fe80: r1 = *(u64 *)(r2 + 0x10)
01fe88: *(u64 *)(r10 - 0x1b8) = r1
01fe90: r1 = *(u64 *)(r2 + 0x8)
01fe98: *(u64 *)(r10 - 0x1c0) = r1
01fea0: r1 = *(u64 *)(r2 + 0x0)
01fea8: *(u64 *)(r10 - 0x1c8) = r1
01feb0: r1 = *(u64 *)(r10 - 0x70)
01feb8: r2 = *(u64 *)(r10 - 0x78)
01fec0: *(u64 *)(r10 - 0xff0) = r2
01fec8: *(u64 *)(r10 - 0xfe8) = r1
01fed0: r1 = 0x62
01fed8: *(u64 *)(r10 - 0xff8) = r1
01fee0: *(u64 *)(r10 - 0x1000) = r8
01fee8: r1 = r10
01fef0: r1 += -0x2d0
01fef8: r2 = r10
01ff00: r2 += -0x1c8
01ff08: r5 = r10
01ff10: r3 = r7
01ff18: r4 = *(u64 *)(r10 - 0x470)
01ff20: call 0xaa76 ; call 0x752d8 / window 770
01ff28: w1 = *(u32 *)(r10 - 0x2d0)
01ff30: if r1 == 0x16 goto +0x1 ; branch 0x1ff40
01ff38: goto +0x6c ; branch 0x202a0
01ff40: r2 = *(u64 *)(r10 - 0x450)
01ff48: r2 <<= 0x20
01ff50: r2 >>= 0x20
01ff58: r1 = r2
01ff60: if r2 == 0x0 goto +0x70 ; branch 0x202e8
01ff68: if r1 == 0x1 goto +0x1 ; branch 0x1ff78
01ff70: goto +0xbd ; branch 0x20560
01ff78: w7 = *(u8 *)(r10 - 0x61)
01ff80: r2 = *(u64 *)(r10 - 0x4a8)
01ff88: r1 = *(u64 *)(r2 + 0x18)
01ff90: *(u64 *)(r10 - 0x48) = r1
01ff98: r1 = *(u64 *)(r2 + 0x10)
01ffa0: *(u64 *)(r10 - 0x50) = r1
01ffa8: r1 = *(u64 *)(r2 + 0x8)
01ffb0: *(u64 *)(r10 - 0x58) = r1
01ffb8: r1 = *(u64 *)(r2 + 0x0)
01ffc0: *(u64 *)(r10 - 0x60) = r1
01ffc8: r2 = *(u64 *)(r10 - 0x4b0)
01ffd0: r1 = *(u64 *)(r2 + 0x18)
01ffd8: *(u64 *)(r10 - 0x28) = r1
01ffe0: r1 = *(u64 *)(r2 + 0x10)
01ffe8: *(u64 *)(r10 - 0x30) = r1
01fff0: r1 = *(u64 *)(r2 + 0x8)
01fff8: *(u64 *)(r10 - 0x38) = r1
020000: r1 = *(u64 *)(r2 + 0x0)
020008: *(u64 *)(r10 - 0x40) = r1
020010: r2 = *(u64 *)(r10 - 0x4a0)
020018: r1 = *(u64 *)(r2 + 0x18)
020020: *(u64 *)(r10 - 0x8) = r1
020028: r1 = *(u64 *)(r2 + 0x10)
020030: *(u64 *)(r10 - 0x10) = r1
020038: r1 = *(u64 *)(r2 + 0x8)
020040: *(u64 *)(r10 - 0x18) = r1
020048: r1 = *(u64 *)(r2 + 0x0)
020050: *(u64 *)(r10 - 0x20) = r1
020058: r1 = r10
020060: r1 += -0x1c8
020068: call 0x43f1 ; call 0x41ff8 / window 355
020070: *(u8 *)(r10 - 0x2cc) = w7
020078: w1 = *(u32 *)(r10 - 0x1c8)
020080: *(u32 *)(r10 - 0x2d0) = w1
020088: r1 = *(u64 *)(r10 - 0x60)
020090: *(u64 *)(r10 - 0x2cb) = r1
020098: r1 = *(u64 *)(r10 - 0x58)
0200a0: *(u64 *)(r10 - 0x2c3) = r1
0200a8: r1 = *(u64 *)(r10 - 0x50)
0200b0: *(u64 *)(r10 - 0x2bb) = r1
0200b8: r1 = *(u64 *)(r10 - 0x48)
0200c0: *(u64 *)(r10 - 0x2b3) = r1
0200c8: r1 = *(u64 *)(r10 - 0x40)
0200d0: *(u64 *)(r10 - 0x2ab) = r1
0200d8: r1 = *(u64 *)(r10 - 0x38)
0200e0: *(u64 *)(r10 - 0x2a3) = r1
0200e8: r1 = *(u64 *)(r10 - 0x30)
0200f0: *(u64 *)(r10 - 0x29b) = r1
0200f8: r1 = *(u64 *)(r10 - 0x28)
020100: *(u64 *)(r10 - 0x293) = r1
020108: r1 = *(u64 *)(r10 - 0x8)
020110: *(u64 *)(r10 - 0x273) = r1
020118: r1 = *(u64 *)(r10 - 0x10)
020120: *(u64 *)(r10 - 0x27b) = r1
020128: r1 = *(u64 *)(r10 - 0x18)
020130: *(u64 *)(r10 - 0x283) = r1
020138: r1 = *(u64 *)(r10 - 0x20)
020140: *(u64 *)(r10 - 0x28b) = r1
020148: r1 = r10
020150: r1 += -0x1c8
020158: r2 = *(u64 *)(r10 - 0x460)
020160: call 0xca48 ; call 0x853a8 / window 986
020168: w1 = *(u32 *)(r10 - 0x1c8)
020170: if r1 != 0x16 goto +0x80 ; branch 0x20578
020178: r7 = *(u64 *)(r10 - 0x1b8)
020180: r1 = *(u64 *)(r10 - 0x1c0)
020188: r2 = *(u64 *)(r1 + 0x8)
020190: r1 = *(u64 *)(r1 + 0x0)
020198: r3 = r10
0201a0: r3 += -0x2d0
0201a8: call -0x32a9 ; call 0x6c68 / window 161
0201b0: if r0 == 0x0 goto +0x70 ; branch 0x20538
0201b8: r1 = r6
0201c0: r2 = r0
0201c8: call 0xcda9 ; call 0x86f18 / window 1002
0201d0: r1 = *(u64 *)(r7 + 0x0)
0201d8: r1 += 0x1
0201e0: *(u64 *)(r7 + 0x0) = r1
0201e8: goto +0xf ; branch 0x20268
0201f0: w2 = *(u8 *)(r10 - 0x1c4)
0201f8: w3 = *(u32 *)(r10 - 0x1ac)
020200: *(u32 *)(r6 + 0x1c) = w3
020208: r3 = *(u64 *)(r10 - 0x1b3)
020210: *(u64 *)(r6 + 0x15) = r3
020218: r3 = *(u64 *)(r10 - 0x1bb)
020220: *(u64 *)(r6 + 0xd) = r3
020228: r3 = *(u64 *)(r10 - 0x1c3)
020230: *(u64 *)(r6 + 0x5) = r3
020238: *(u8 *)(r6 + 0x4) = w2
020240: *(u32 *)(r6 + 0x0) = w1
020248: goto +0x3 ; branch 0x20268
020250: r1 = 0x8d00000000 ll
020260: *(u64 *)(r6 + 0x0) = r1
020268: r1 = r10
020270: r1 += -0x80
020278: call -0x3a30 ; call 0x3100 / window 60
020280: r1 = r10
020288: r1 += -0x98
020290: call -0x3a44 ; call 0x3078 / window 58
020298: goto -0xf2 ; branch 0x1fb10
0202a0: w2 = *(u32 *)(r10 - 0x2b4)
0202a8: *(u32 *)(r6 + 0x1c) = w2
0202b0: r2 = *(u64 *)(r10 - 0x2bc)
0202b8: *(u64 *)(r6 + 0x14) = r2
0202c0: r2 = *(u64 *)(r10 - 0x2c4)
0202c8: *(u64 *)(r6 + 0xc) = r2
0202d0: r2 = *(u64 *)(r10 - 0x2cc)
0202d8: *(u64 *)(r6 + 0x4) = r2
0202e0: goto -0x15 ; branch 0x20240
0202e8: w7 = *(u8 *)(r10 - 0x61)
0202f0: r2 = *(u64 *)(r10 - 0x4a8)
0202f8: r1 = *(u64 *)(r2 + 0x18)
020300: *(u64 *)(r10 - 0x48) = r1
020308: r1 = *(u64 *)(r2 + 0x10)
020310: *(u64 *)(r10 - 0x50) = r1
020318: r1 = *(u64 *)(r2 + 0x8)
020320: *(u64 *)(r10 - 0x58) = r1
020328: r1 = *(u64 *)(r2 + 0x0)
020330: *(u64 *)(r10 - 0x60) = r1
020338: r2 = *(u64 *)(r10 - 0x4b0)
020340: r1 = *(u64 *)(r2 + 0x18)
020348: *(u64 *)(r10 - 0x28) = r1
020350: r1 = *(u64 *)(r2 + 0x10)
020358: *(u64 *)(r10 - 0x30) = r1
020360: r1 = *(u64 *)(r2 + 0x8)
020368: *(u64 *)(r10 - 0x38) = r1
020370: r1 = *(u64 *)(r2 + 0x0)
020378: *(u64 *)(r10 - 0x40) = r1
020380: r2 = *(u64 *)(r10 - 0x4a0)
020388: r1 = *(u64 *)(r2 + 0x18)
020390: *(u64 *)(r10 - 0x8) = r1
020398: r1 = *(u64 *)(r2 + 0x10)
0203a0: *(u64 *)(r10 - 0x10) = r1
0203a8: r1 = *(u64 *)(r2 + 0x8)
0203b0: *(u64 *)(r10 - 0x18) = r1
0203b8: r1 = *(u64 *)(r2 + 0x0)
0203c0: *(u64 *)(r10 - 0x20) = r1
0203c8: r1 = r10
0203d0: r1 += -0x1c8
0203d8: call 0x4375 ; call 0x41f88 / window 354
0203e0: *(u8 *)(r10 - 0x2cc) = w7
0203e8: w1 = *(u32 *)(r10 - 0x1c8)
0203f0: *(u32 *)(r10 - 0x2d0) = w1
0203f8: r1 = *(u64 *)(r10 - 0x60)
020400: *(u64 *)(r10 - 0x2cb) = r1
020408: r1 = *(u64 *)(r10 - 0x58)
020410: *(u64 *)(r10 - 0x2c3) = r1
020418: r1 = *(u64 *)(r10 - 0x50)
020420: *(u64 *)(r10 - 0x2bb) = r1
020428: r1 = *(u64 *)(r10 - 0x48)
020430: *(u64 *)(r10 - 0x2b3) = r1
020438: r1 = *(u64 *)(r10 - 0x40)
020440: *(u64 *)(r10 - 0x2ab) = r1
020448: r1 = *(u64 *)(r10 - 0x38)
020450: *(u64 *)(r10 - 0x2a3) = r1
020458: r1 = *(u64 *)(r10 - 0x30)
020460: *(u64 *)(r10 - 0x29b) = r1
020468: r1 = *(u64 *)(r10 - 0x28)
020470: *(u64 *)(r10 - 0x293) = r1
020478: r1 = *(u64 *)(r10 - 0x8)
020480: *(u64 *)(r10 - 0x273) = r1
020488: r1 = *(u64 *)(r10 - 0x10)
020490: *(u64 *)(r10 - 0x27b) = r1
020498: r1 = *(u64 *)(r10 - 0x18)
0204a0: *(u64 *)(r10 - 0x283) = r1
0204a8: r1 = *(u64 *)(r10 - 0x20)
0204b0: *(u64 *)(r10 - 0x28b) = r1
0204b8: r1 = r10
0204c0: r1 += -0x1c8
0204c8: r2 = *(u64 *)(r10 - 0x460)
0204d0: call 0xc9da ; call 0x853a8 / window 986
0204d8: w1 = *(u32 *)(r10 - 0x1c8)
0204e0: if r1 == 0x16 goto +0x1 ; branch 0x204f0
0204e8: goto +0x11 ; branch 0x20578
0204f0: r7 = *(u64 *)(r10 - 0x1b8)
0204f8: r1 = *(u64 *)(r10 - 0x1c0)
020500: r2 = *(u64 *)(r1 + 0x8)
020508: r1 = *(u64 *)(r1 + 0x0)
020510: r3 = r10
020518: r3 += -0x2d0
020520: call -0x3318 ; call 0x6c68 / window 161
020528: if r0 == 0x0 goto +0x1 ; branch 0x20538
020530: goto -0x70 ; branch 0x201b8
020538: r1 = *(u64 *)(r7 + 0x0)
020540: r1 += 0x1
020548: *(u64 *)(r7 + 0x0) = r1
020550: r1 = 0x16
020558: goto -0x64 ; branch 0x20240
020560: r1 = 0xa500000000 ll
020570: goto -0x63 ; branch 0x20260
020578: w2 = *(u32 *)(r10 - 0x1c4)
020580: r3 = *(u64 *)(r10 - 0x1c0)
020588: r4 = *(u64 *)(r10 - 0x1b8)
020590: r5 = *(u64 *)(r10 - 0x1b0)
020598: *(u64 *)(r6 + 0x18) = r5
0205a0: *(u64 *)(r6 + 0x10) = r4
0205a8: *(u64 *)(r6 + 0x8) = r3
0205b0: *(u32 *)(r6 + 0x4) = w2
0205b8: goto -0x70 ; branch 0x20240
