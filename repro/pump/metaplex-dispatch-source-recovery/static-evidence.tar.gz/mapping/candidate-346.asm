039b88: r9 = r5
039b90: r7 = r4
039b98: r8 = r2
039ba0: r6 = r1
039ba8: r1 = 0x0
039bb0: *(u64 *)(r10 - 0x568) = r1
039bb8: *(u64 *)(r10 - 0x570) = r3
039bc0: r1 = r7
039bc8: r1 *= 0x30
039bd0: r3 += r1
039bd8: *(u64 *)(r10 - 0x578) = r3
039be0: r1 = r10
039be8: r1 += -0x1f0
039bf0: r2 = r10
039bf8: r2 += -0x578
039c00: call -0x7155 ; call 0x1160 / window 20
039c08: w1 = *(u32 *)(r10 - 0x1f0)
039c10: if r1 != 0x16 goto +0x64 ; branch 0x39f38
039c18: r1 = *(u64 *)(r10 - 0x1e8)
039c20: *(u64 *)(r10 - 0x598) = r1
039c28: r1 = r10
039c30: r1 += -0x1f0
039c38: r2 = r10
039c40: r2 += -0x578
039c48: call -0x715e ; call 0x1160 / window 20
039c50: w1 = *(u32 *)(r10 - 0x1f0)
039c58: if r1 == 0x16 goto +0x1 ; branch 0x39c68
039c60: goto +0x5a ; branch 0x39f38
039c68: r1 = *(u64 *)(r10 - 0x1e8)
039c70: *(u64 *)(r10 - 0x5a0) = r1
039c78: r1 = r10
039c80: r1 += -0x1f0
039c88: r2 = r10
039c90: r2 += -0x578
039c98: call -0x7168 ; call 0x1160 / window 20
039ca0: w1 = *(u32 *)(r10 - 0x1f0)
039ca8: if r1 == 0x16 goto +0x1 ; branch 0x39cb8
039cb0: goto +0x50 ; branch 0x39f38
039cb8: r1 = *(u64 *)(r10 - 0x1e8)
039cc0: *(u64 *)(r10 - 0x5a8) = r1
039cc8: r1 = r10
039cd0: r1 += -0x1f0
039cd8: r2 = r10
039ce0: r2 += -0x578
039ce8: call -0x7172 ; call 0x1160 / window 20
039cf0: w1 = *(u32 *)(r10 - 0x1f0)
039cf8: if r1 == 0x16 goto +0x1 ; branch 0x39d08
039d00: goto +0x46 ; branch 0x39f38
039d08: r1 = *(u64 *)(r10 - 0x1e8)
039d10: *(u64 *)(r10 - 0x5b0) = r1
039d18: r1 = r10
039d20: r1 += -0x1f0
039d28: r2 = r10
039d30: r2 += -0x578
039d38: call -0x717c ; call 0x1160 / window 20
039d40: w1 = *(u32 *)(r10 - 0x1f0)
039d48: if r1 == 0x16 goto +0x1 ; branch 0x39d58
039d50: goto +0x3c ; branch 0x39f38
039d58: r1 = *(u64 *)(r10 - 0x1e8)
039d60: *(u64 *)(r10 - 0x5b8) = r1
039d68: r1 = r10
039d70: r1 += -0x1f0
039d78: r2 = r10
039d80: r2 += -0x578
039d88: call -0x7186 ; call 0x1160 / window 20
039d90: w1 = *(u32 *)(r10 - 0x1f0)
039d98: if r1 == 0x16 goto +0x1 ; branch 0x39da8
039da0: goto +0x32 ; branch 0x39f38
039da8: r1 = *(u64 *)(r10 - 0x1e8)
039db0: *(u64 *)(r10 - 0x5c0) = r1
039db8: r1 = r10
039dc0: r1 += -0x1f0
039dc8: r2 = r10
039dd0: r2 += -0x578
039dd8: call -0x7190 ; call 0x1160 / window 20
039de0: w1 = *(u32 *)(r10 - 0x1f0)
039de8: if r1 == 0x16 goto +0x1 ; branch 0x39df8
039df0: goto +0x28 ; branch 0x39f38
039df8: r1 = r10
039e00: r1 += -0x1f0
039e08: r2 = r10
039e10: r2 += -0x578
039e18: call -0x7198 ; call 0x1160 / window 20
039e20: w1 = *(u32 *)(r10 - 0x1f0)
039e28: if r1 == 0x16 goto +0x1 ; branch 0x39e38
039e30: goto +0x20 ; branch 0x39f38
039e38: r1 = r10
039e40: r1 += -0x578
039e48: call -0x6bde ; call 0x3f60 / window 89
039e50: *(u64 *)(r10 - 0x5c8) = r0
039e58: r1 = r10
039e60: r1 += -0x1f0
039e68: r2 = *(u64 *)(r10 - 0x598)
039e70: call 0x1c08 ; call 0x47eb8 / window 419
039e78: r2 = 0x1
039e80: r1 = 0x1
039e88: if r7 == 0xb goto +0x1 ; branch 0x39e98
039e90: r1 = 0x0
039e98: if r7 == 0xa goto +0x1 ; branch 0x39ea8
039ea0: r2 = 0x0
039ea8: r3 = *(u64 *)(r10 - 0x5c8)
039eb0: if r3 == 0x0 goto +0x1 ; branch 0x39ec0
039eb8: r2 = r1
039ec0: w7 = *(u32 *)(r10 - 0xe8)
039ec8: if r7 != 0x2 goto +0x19 ; branch 0x39f98
039ed0: r1 = *(u64 *)(r10 - 0x1d8)
039ed8: *(u64 *)(r10 - 0x410) = r1
039ee0: r2 = *(u64 *)(r10 - 0x1e0)
039ee8: *(u64 *)(r10 - 0x418) = r2
039ef0: r3 = *(u64 *)(r10 - 0x1e8)
039ef8: *(u64 *)(r10 - 0x420) = r3
039f00: r4 = *(u64 *)(r10 - 0x1f0)
039f08: *(u64 *)(r10 - 0x428) = r4
039f10: *(u64 *)(r6 + 0x18) = r1
039f18: *(u64 *)(r6 + 0x10) = r2
039f20: *(u64 *)(r6 + 0x8) = r3
039f28: *(u64 *)(r6 + 0x0) = r4
039f30: goto +0xb ; branch 0x39f90
039f38: r2 = *(u64 *)(r10 - 0x1e0)
039f40: *(u64 *)(r10 - 0x428) = r2
039f48: r3 = *(u64 *)(r10 - 0x1d8)
039f50: *(u64 *)(r10 - 0x420) = r3
039f58: w4 = *(u32 *)(r10 - 0x1ec)
039f60: r5 = *(u64 *)(r10 - 0x1e8)
039f68: *(u64 *)(r6 + 0x18) = r3
039f70: *(u64 *)(r6 + 0x10) = r2
039f78: *(u64 *)(r6 + 0x8) = r5
039f80: *(u32 *)(r6 + 0x4) = w4
039f88: *(u32 *)(r6 + 0x0) = w1
039f90: exit
039f98: *(u64 *)(r10 - 0x5d0) = r2
039fa0: r1 = r10
039fa8: r1 += -0x428
039fb0: *(u64 *)(r10 - 0x5c8) = r1
039fb8: r2 = r10
039fc0: r2 += -0x1f0
039fc8: r3 = 0x108
039fd0: call 0xbdd7 ; call 0x98e90 / window 1246
039fd8: r1 = r10
039fe0: r1 += -0x44c
039fe8: r2 = r10
039ff0: r2 += -0xe4
039ff8: r3 = 0x24
03a000: call 0xbdd1 ; call 0x98e90 / window 1246
03a008: r1 = r10
03a010: r1 += -0x558
03a018: r2 = *(u64 *)(r10 - 0x5c8)
03a020: r3 = 0x108
03a028: call 0xbdcc ; call 0x98e90 / window 1246
03a030: *(u32 *)(r10 - 0x450) = w7
03a038: w1 = *(u32 *)(r10 - 0x478)
03a040: if r1 == 0x3 goto +0x6 ; branch 0x3a078
03a048: w1 = *(u32 *)(r10 - 0x4a4)
03a050: if r1 == 0x6 goto +0x1 ; branch 0x3a060
03a058: goto +0xa ; branch 0x3a0b0
03a060: r1 = 0x8700000000 ll
03a070: goto +0x2 ; branch 0x3a088
03a078: r1 = 0x5500000000 ll
03a088: *(u64 *)(r6 + 0x0) = r1
03a090: r1 = r10
03a098: r1 += -0x510
03a0a0: call -0x6e01 ; call 0x30a0 / window 59
03a0a8: goto -0x24 ; branch 0x39f90
03a0b0: if r1 > 0x5 goto -0xb ; branch 0x3a060
03a0b8: r2 = 0x1
03a0c0: r2 <<= r1
03a0c8: r2 &= 0x39
03a0d0: if r2 != 0x0 goto +0x1 ; branch 0x3a0e0
03a0d8: goto -0x10 ; branch 0x3a060
03a0e0: r1 = *(u64 *)(r10 - 0x5c0)
03a0e8: r1 = *(u64 *)(r1 + 0x0)
03a0f0: r2 = 0x99938 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03a100: call -0x6e7f ; call 0x2d10 / window 44
03a108: if r0 != 0x0 goto +0x1 ; branch 0x3a118
03a110: goto +0x3 ; branch 0x3a130
03a118: r1 = 0x3e00000000 ll
03a128: goto -0x15 ; branch 0x3a088
03a130: r1 = r10
03a138: r1 += -0x1f0
03a140: r2 = *(u64 *)(r10 - 0x5b0)
03a148: call 0x788e ; call 0x765c0 / window 773
03a150: w1 = *(u32 *)(r10 - 0x1f0)
03a158: if r1 == 0x16 goto +0x1 ; branch 0x3a168
03a160: goto +0x25 ; branch 0x3a290
03a168: r1 = *(u64 *)(r10 - 0x5a8)
03a170: *(u64 *)(r10 - 0xff8) = r1
03a178: r1 = *(u64 *)(r10 - 0x5a0)
03a180: *(u64 *)(r10 - 0xff0) = r1
03a188: r1 = r10
03a190: r1 += -0x558
03a198: *(u64 *)(r10 - 0x1000) = r1
03a1a0: r1 = r10
03a1a8: r1 += -0x1f0
03a1b0: r5 = r10
03a1b8: r2 = r8
03a1c0: r3 = *(u64 *)(r10 - 0x5b8)
03a1c8: r7 = *(u64 *)(r10 - 0x598)
03a1d0: r4 = r7
03a1d8: call -0x567d ; call 0xedf8 / window 264
03a1e0: w1 = *(u32 *)(r10 - 0x1f0)
03a1e8: if r1 == 0x16 goto +0x1 ; branch 0x3a1f8
03a1f0: goto +0x13 ; branch 0x3a290
03a1f8: r1 = r10
03a200: r1 += -0x1f0
03a208: r2 = r7
03a210: call 0x1b94 ; call 0x47eb8 / window 419
03a218: w7 = *(u32 *)(r10 - 0xe8)
03a220: if r7 != 0x2 goto +0x1b ; branch 0x3a300
03a228: r1 = *(u64 *)(r10 - 0x1d8)
03a230: *(u64 *)(r10 - 0x2e0) = r1
03a238: r2 = *(u64 *)(r10 - 0x1e0)
03a240: *(u64 *)(r10 - 0x2e8) = r2
03a248: r3 = *(u64 *)(r10 - 0x1e8)
03a250: *(u64 *)(r10 - 0x2f0) = r3
03a258: r4 = *(u64 *)(r10 - 0x1f0)
03a260: *(u64 *)(r10 - 0x2f8) = r4
03a268: *(u64 *)(r6 + 0x18) = r1
03a270: *(u64 *)(r6 + 0x10) = r2
03a278: *(u64 *)(r6 + 0x8) = r3
03a280: *(u64 *)(r6 + 0x0) = r4
03a288: goto -0x40 ; branch 0x3a090
03a290: w2 = *(u32 *)(r10 - 0x1d4)
03a298: *(u32 *)(r10 - 0x410) = w2
03a2a0: r3 = *(u64 *)(r10 - 0x1dc)
03a2a8: *(u64 *)(r10 - 0x418) = r3
03a2b0: r4 = *(u64 *)(r10 - 0x1e4)
03a2b8: *(u64 *)(r10 - 0x420) = r4
03a2c0: r5 = *(u64 *)(r10 - 0x1ec)
03a2c8: *(u64 *)(r10 - 0x428) = r5
03a2d0: *(u32 *)(r6 + 0x1c) = w2
03a2d8: *(u64 *)(r6 + 0x14) = r3
03a2e0: *(u64 *)(r6 + 0xc) = r4
03a2e8: *(u64 *)(r6 + 0x4) = r5
03a2f0: *(u32 *)(r6 + 0x0) = w1
03a2f8: goto -0x4e ; branch 0x3a090
03a300: r1 = r10
03a308: r1 += -0x2f8
03a310: *(u64 *)(r10 - 0x5c8) = r1
03a318: r2 = r10
03a320: r2 += -0x1f0
03a328: r3 = 0x108
03a330: call 0xbd6b ; call 0x98e90 / window 1246
03a338: r1 = r10
03a340: r1 += -0x31c
03a348: r2 = r10
03a350: r2 += -0xe4
03a358: r3 = 0x24
03a360: call 0xbd65 ; call 0x98e90 / window 1246
03a368: r1 = r10
03a370: r1 += -0x428
03a378: r2 = *(u64 *)(r10 - 0x5c8)
03a380: r3 = 0x108
03a388: call 0xbd60 ; call 0x98e90 / window 1246
03a390: *(u32 *)(r10 - 0x320) = w7
03a398: r1 = *(u64 *)(r10 - 0x338)
03a3a0: *(u64 *)(r10 - 0x1e0) = r1
03a3a8: r1 = *(u64 *)(r10 - 0x340)
03a3b0: *(u64 *)(r10 - 0x1e8) = r1
03a3b8: r1 = *(u64 *)(r10 - 0x348)
03a3c0: *(u64 *)(r10 - 0x1f0) = r1
03a3c8: r1 = r10
03a3d0: r1 += -0xc0
03a3d8: r2 = r10
03a3e0: r2 += -0x1f0
03a3e8: r3 = 0x9f240 ll ; data b"\x00\x00\x00\x00i\xa8\t\x00%\x00\x00\x00\x00\x00\x00\x00Q\x00\x00\x00'\x00\x00\x00\x00\x00\x00\x00\x8e\xa8\t\x000\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\x8e\xa8\t\x000\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x003\x00\x00\x00\x00\x00\x00\x00"
03a3f8: call -0x6c28 ; call 0x42c0 / window 96
03a400: r1 = *(u64 *)(r10 - 0xb0)
03a408: if r9 > r1 goto +0x14 ; branch 0x3a4b0
03a410: r7 = *(u64 *)(r10 - 0xb8)
03a418: if r9 > r7 goto +0x12 ; branch 0x3a4b0
03a420: w2 = *(u32 *)(r10 - 0xc0)
03a428: *(u64 *)(r10 - 0x338) = r1
03a430: *(u64 *)(r10 - 0x5c8) = r2
03a438: *(u32 *)(r10 - 0x348) = w2
03a440: r1 = r7
03a448: r1 -= r9
03a450: *(u64 *)(r10 - 0x340) = r1
03a458: r1 = *(u64 *)(r10 - 0x5d0)
03a460: r1 &= 0x1
03a468: if r1 != 0x0 goto +0xc ; branch 0x3a4d0
03a470: r1 = *(u64 *)(r10 - 0x5b0)
03a478: r2 = *(u64 *)(r10 - 0x5b8)
03a480: call -0x6ef6 ; call 0x2cd8 / window 42
03a488: if r0 != 0x0 goto +0x1 ; branch 0x3a498
03a490: goto +0x89 ; branch 0x3a8e0
03a498: r1 = 0x6200000000 ll
03a4a8: goto +0x2 ; branch 0x3a4c0
03a4b0: r1 = 0x5600000000 ll
03a4c0: *(u64 *)(r6 + 0x0) = r1
03a4c8: goto +0x13e ; branch 0x3aec0
03a4d0: r1 = r10
03a4d8: r1 += -0x1f0
03a4e0: r2 = r10
03a4e8: r2 += -0x578
03a4f0: call -0x7273 ; call 0x1160 / window 20
03a4f8: w1 = *(u32 *)(r10 - 0x1f0)
03a500: if r1 != 0x16 goto +0x12c ; branch 0x3ae68
03a508: r2 = *(u64 *)(r10 - 0x1e8)
03a510: r1 = r10
03a518: r1 += -0x1f0
03a520: *(u64 *)(r10 - 0x5d8) = r2
03a528: call 0x95cf ; call 0x853a8 / window 986
03a530: w1 = *(u32 *)(r10 - 0x1f0)
03a538: if r1 == 0x16 goto +0x1 ; branch 0x3a548
03a540: goto +0x8b ; branch 0x3a9a0
03a548: r1 = *(u64 *)(r10 - 0x1e0)
03a550: *(u64 *)(r10 - 0x5e0) = r1
03a558: r1 = *(u64 *)(r10 - 0x1e8)
03a560: *(u64 *)(r10 - 0x5e8) = r1
03a568: r1 = *(u64 *)(r1 + 0x8)
03a570: if r1 == 0x0 goto +0x39 ; branch 0x3a740
03a578: r1 = r10
03a580: r1 += -0x1f0
03a588: r2 = *(u64 *)(r10 - 0x5d8)
03a590: r3 = r8
03a598: call -0x552e ; call 0xfc30 / window 275
03a5a0: w1 = *(u32 *)(r10 - 0x1f0)
03a5a8: if r1 == 0x16 goto +0x1 ; branch 0x3a5b8
03a5b0: goto +0x24 ; branch 0x3a6d8
03a5b8: r1 = r10
03a5c0: r1 += -0x1f0
03a5c8: r2 = r8
03a5d0: r3 = *(u64 *)(r10 - 0x5d8)
03a5d8: r4 = *(u64 *)(r10 - 0x5b0)
03a5e0: r5 = *(u64 *)(r10 - 0x5a8)
03a5e8: call -0x54c6 ; call 0xffc0 / window 281
03a5f0: w1 = *(u32 *)(r10 - 0x1f0)
03a5f8: if r1 == 0x16 goto +0x1 ; branch 0x3a608
03a600: goto +0x2b ; branch 0x3a760
03a608: w1 = *(u8 *)(r10 - 0x1ec)
03a610: *(u64 *)(r10 - 0x5b0) = r1
03a618: r1 = *(u64 *)(r10 - 0x5e8)
03a620: r3 = *(u64 *)(r1 + 0x8)
03a628: r2 = *(u64 *)(r1 + 0x0)
03a630: r1 = r10
03a638: r1 += -0x1f0
03a640: call 0x15d3 ; call 0x454e0 / window 396
03a648: w1 = *(u32 *)(r10 - 0x1f0)
03a650: if r1 == 0x16 goto +0x1 ; branch 0x3a660
03a658: goto +0xf ; branch 0x3a6d8
03a660: r1 = *(u64 *)(r10 - 0x1e0)
03a668: *(u64 *)(r10 - 0x28) = r1
03a670: r2 = *(u64 *)(r10 - 0x1e8)
03a678: *(u64 *)(r10 - 0x30) = r2
03a680: r1 = *(u64 *)(r10 - 0x1d8)
03a688: *(u64 *)(r10 - 0x20) = r1
03a690: r1 &= 0xff
03a698: if r1 != 0x0 goto +0x2b ; branch 0x3a7f8
03a6a0: r2 <<= 0x20
03a6a8: r2 >>= 0x20
03a6b0: if r2 == 0x8 goto +0x1 ; branch 0x3a6c0
03a6b8: goto +0x27 ; branch 0x3a7f8
03a6c0: r1 = *(u64 *)(r10 - 0x5b0)
03a6c8: *(u8 *)(r10 - 0x20) = w1
03a6d0: goto +0x27 ; branch 0x3a810
03a6d8: w2 = *(u32 *)(r10 - 0x1d4)
03a6e0: *(u32 *)(r10 - 0x2e0) = w2
03a6e8: r3 = *(u64 *)(r10 - 0x1dc)
03a6f0: *(u64 *)(r10 - 0x2e8) = r3
03a6f8: r4 = *(u64 *)(r10 - 0x1e4)
03a700: *(u64 *)(r10 - 0x2f0) = r4
03a708: r5 = *(u64 *)(r10 - 0x1ec)
03a710: *(u64 *)(r10 - 0x2f8) = r5
03a718: *(u32 *)(r6 + 0x1c) = w2
03a720: *(u64 *)(r6 + 0x14) = r3
03a728: *(u64 *)(r6 + 0xc) = r4
03a730: *(u64 *)(r6 + 0x4) = r5
03a738: goto +0x14 ; branch 0x3a7e0
03a740: r1 = 0x5400000000 ll
03a750: *(u64 *)(r6 + 0x0) = r1
03a758: goto +0x11 ; branch 0x3a7e8
03a760: w2 = *(u32 *)(r10 - 0x1d4)
03a768: *(u32 *)(r10 - 0x2e1) = w2
03a770: r2 = *(u64 *)(r10 - 0x1db)
03a778: *(u64 *)(r10 - 0x2e8) = r2
03a780: r2 = *(u64 *)(r10 - 0x1eb)
03a788: *(u64 *)(r10 - 0x2f8) = r2
03a790: r3 = *(u64 *)(r10 - 0x1e3)
03a798: *(u64 *)(r10 - 0x2f0) = r3
03a7a0: w4 = *(u8 *)(r10 - 0x1ec)
03a7a8: w5 = *(u32 *)(r10 - 0x2e1)
03a7b0: *(u32 *)(r6 + 0x1c) = w5
03a7b8: r5 = *(u64 *)(r10 - 0x2e8)
03a7c0: *(u64 *)(r6 + 0x15) = r5
03a7c8: *(u64 *)(r6 + 0xd) = r3
03a7d0: *(u64 *)(r6 + 0x5) = r2
03a7d8: *(u8 *)(r6 + 0x4) = w4
03a7e0: *(u32 *)(r6 + 0x0) = w1
03a7e8: r2 = *(u64 *)(r10 - 0x5e0)
03a7f0: goto +0x31 ; branch 0x3a980
03a7f8: r2 = *(u64 *)(r10 - 0x5b0)
03a800: if r1 == r2 goto +0x1 ; branch 0x3a810
03a808: goto +0x13 ; branch 0x3a8a8
03a810: r1 = *(u64 *)(r10 - 0x28)
03a818: if r9 > r1 goto +0x1 ; branch 0x3a828
03a820: goto +0x3 ; branch 0x3a840
03a828: r1 = 0x5600000000 ll
03a838: goto -0x1e ; branch 0x3a750
03a840: r1 -= r9
03a848: *(u64 *)(r10 - 0x28) = r1
03a850: r1 = *(u64 *)(r10 - 0x5e8)
03a858: r2 = *(u64 *)(r1 + 0x8)
03a860: r1 = *(u64 *)(r1 + 0x0)
03a868: r3 = r10
03a870: r3 += -0x30
03a878: call -0x674b ; call 0x6e28 / window 169
03a880: if r0 == 0x0 goto +0x7 ; branch 0x3a8c0
03a888: r1 = r6
03a890: r2 = r0
03a898: call 0x98cf ; call 0x86f18 / window 1002
03a8a0: goto -0x18 ; branch 0x3a7e8
03a8a8: r1 = 0x5900000000 ll
03a8b8: goto -0x2e ; branch 0x3a750
03a8c0: r2 = *(u64 *)(r10 - 0x5e0)
03a8c8: r1 = *(u64 *)(r2 + 0x0)
03a8d0: r1 += 0x1
03a8d8: *(u64 *)(r2 + 0x0) = r1
03a8e0: r1 = r10
03a8e8: r1 += -0x1f0
03a8f0: r2 = *(u64 *)(r10 - 0x598)
03a8f8: call 0x9555 ; call 0x853a8 / window 986
03a900: w1 = *(u32 *)(r10 - 0x1f0)
03a908: if r1 == 0x16 goto +0x1 ; branch 0x3a918
03a910: goto +0x11 ; branch 0x3a9a0
03a918: r1 = *(u64 *)(r10 - 0x1e0)
03a920: *(u64 *)(r10 - 0x598) = r1
03a928: r1 = *(u64 *)(r10 - 0x1e8)
03a930: r3 = *(u64 *)(r1 + 0x8)
03a938: r2 = *(u64 *)(r1 + 0x0)
03a940: r1 = r10
03a948: r1 += -0x428
03a950: call 0x107d ; call 0x42d40 / window 365
03a958: if r0 == 0x0 goto +0x11 ; branch 0x3a9e8
03a960: r1 = r6
03a968: r2 = r0
03a970: call 0x98b4 ; call 0x86f18 / window 1002
03a978: r2 = *(u64 *)(r10 - 0x598)
03a980: r1 = *(u64 *)(r2 + 0x0)
03a988: r1 += 0x1
03a990: *(u64 *)(r2 + 0x0) = r1
03a998: goto +0xa4 ; branch 0x3aec0
03a9a0: w2 = *(u32 *)(r10 - 0x1ec)
03a9a8: r3 = *(u64 *)(r10 - 0x1e8)
03a9b0: r4 = *(u64 *)(r10 - 0x1e0)
03a9b8: r5 = *(u64 *)(r10 - 0x1d8)
03a9c0: *(u64 *)(r6 + 0x18) = r5
03a9c8: *(u64 *)(r6 + 0x10) = r4
03a9d0: *(u64 *)(r6 + 0x8) = r3
03a9d8: *(u32 *)(r6 + 0x4) = w2
03a9e0: goto +0x9a ; branch 0x3aeb8
03a9e8: r2 = *(u64 *)(r10 - 0x598)
03a9f0: r1 = *(u64 *)(r2 + 0x0)
03a9f8: r1 += 0x1
03aa00: *(u64 *)(r2 + 0x0) = r1
03aa08: r1 = *(u64 *)(r10 - 0x5c8)
03aa10: if r1 != 0x0 goto +0x88 ; branch 0x3ae58
03aa18: if r7 == r9 goto +0x1 ; branch 0x3aa28
03aa20: goto +0x86 ; branch 0x3ae58
03aa28: r1 = *(u64 *)(r10 - 0x5d0)
03aa30: r1 &= 0x1
03aa38: if r1 != 0x0 goto +0x30 ; branch 0x3abc0
03aa40: r1 = r10
03aa48: r1 += -0x1e0
03aa50: r2 = *(u64 *)(r10 - 0x5a8)
03aa58: call -0x6051 ; call 0xa7d8 / window 217
03aa60: r8 = r10
03aa68: r8 += -0x30
03aa70: r1 = r8
03aa78: r2 = *(u64 *)(r10 - 0x5b8)
03aa80: call -0x6056 ; call 0xa7d8 / window 217
03aa88: r7 = r10
03aa90: r7 += -0x2f8
03aa98: r1 = r7
03aaa0: r2 = *(u64 *)(r10 - 0x5c0)
03aaa8: call -0x605b ; call 0xa7d8 / window 217
03aab0: r1 = r10
03aab8: r1 += -0x1b0
03aac0: r2 = *(u64 *)(r10 - 0x5a0)
03aac8: call -0x605f ; call 0xa7d8 / window 217
03aad0: r1 = 0x1
03aad8: *(u64 *)(r10 - 0x120) = r1
03aae0: r1 = r10
03aae8: r1 += -0x180
03aaf0: r2 = r8
03aaf8: r3 = 0x30
03ab00: call 0xbc71 ; call 0x98e90 / window 1246
03ab08: r1 = 0x0
03ab10: *(u64 *)(r10 - 0x1f0) = r1
03ab18: r1 = r10
03ab20: r1 += -0x150
03ab28: r2 = r7
03ab30: r3 = 0x30
03ab38: call 0xbc6a ; call 0x98e90 / window 1246
03ab40: r1 = r10
03ab48: r1 += -0x60
03ab50: r2 = r10
03ab58: r2 += -0x1f0
03ab60: call 0x7768 ; call 0x766a8 / window 775
03ab68: w1 = *(u32 *)(r10 - 0x60)
03ab70: if r1 == 0x16 goto +0x5c ; branch 0x3ae58
03ab78: w2 = *(u32 *)(r10 - 0x44)
03ab80: *(u32 *)(r10 - 0x68) = w2
03ab88: r3 = *(u64 *)(r10 - 0x4c)
03ab90: *(u64 *)(r10 - 0x70) = r3
03ab98: r4 = *(u64 *)(r10 - 0x54)
03aba0: *(u64 *)(r10 - 0x78) = r4
03aba8: r5 = *(u64 *)(r10 - 0x5c)
03abb0: *(u64 *)(r10 - 0x80) = r5
03abb8: goto +0x71 ; branch 0x3af48
03abc0: r1 = r10
03abc8: r1 += -0x1f0
03abd0: r2 = r10
03abd8: r2 += -0x578
03abe0: call -0x7351 ; call 0x1160 / window 20
03abe8: w1 = *(u32 *)(r10 - 0x1f0)
03abf0: if r1 != 0x16 goto +0x4e ; branch 0x3ae68
03abf8: r7 = *(u64 *)(r10 - 0x1e8)
03ac00: r2 = *(u64 *)(r7 + 0x0)
03ac08: r1 = r10
03ac10: r1 += -0x580
03ac18: call -0x55a4 ; call 0xff00 / window 280
03ac20: w9 = *(u8 *)(r10 - 0x57f)
03ac28: w1 = *(u8 *)(r10 - 0x580)
03ac30: r1 &= 0x1
03ac38: if r1 == 0x0 goto +0x1 ; branch 0x3ac48
03ac40: goto +0x53 ; branch 0x3aee0
03ac48: r1 = r10
03ac50: r1 += -0x590
03ac58: r2 = r8
03ac60: call 0x969b ; call 0x86140 / window 990
03ac68: r1 = r10
03ac70: r1 += -0xa1
03ac78: *(u64 *)(r10 - 0x2c8) = r1
03ac80: r1 = 0x9a030 ll ; data b'burnKindNone\x01\x00Invalid Option representation: . The first byte must be 0 or 1src/entrypoint.rs\x00\x00\x00IX: '
03ac90: *(u64 *)(r10 - 0x2d8) = r1
03ac98: r1 = 0x8
03aca0: *(u64 *)(r10 - 0x2f0) = r1
03aca8: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
03acb8: *(u64 *)(r10 - 0x2f8) = r1
03acc0: r1 = *(u64 *)(r10 - 0x588)
03acc8: *(u64 *)(r10 - 0x2e0) = r1
03acd0: r1 = *(u64 *)(r10 - 0x590)
03acd8: *(u64 *)(r10 - 0x2e8) = r1
03ace0: *(u8 *)(r10 - 0xa1) = w9
03ace8: r9 = 0x1
03acf0: *(u64 *)(r10 - 0x2c0) = r9
03acf8: r1 = 0x4
03ad00: *(u64 *)(r10 - 0x2d0) = r1
03ad08: r1 = r10
03ad10: r1 += -0x1e0
03ad18: r2 = *(u64 *)(r10 - 0x5a8)
03ad20: call -0x60aa ; call 0xa7d8 / window 217
03ad28: r8 = r10
03ad30: r8 += -0x60
03ad38: r1 = r8
03ad40: r2 = r7
03ad48: call -0x60af ; call 0xa7d8 / window 217
03ad50: r7 = r10
03ad58: r7 += -0x30
03ad60: r1 = r7
03ad68: r2 = *(u64 *)(r10 - 0x5c0)
03ad70: call -0x60b4 ; call 0xa7d8 / window 217
03ad78: r1 = r10
03ad80: r1 += -0x1b0
03ad88: r2 = *(u64 *)(r10 - 0x5a0)
03ad90: call -0x60b8 ; call 0xa7d8 / window 217
03ad98: *(u64 *)(r10 - 0x120) = r9
03ada0: r1 = r10
03ada8: r1 += -0x180
03adb0: r2 = r8
03adb8: r3 = 0x30
03adc0: call 0xbc19 ; call 0x98e90 / window 1246
03adc8: r1 = 0x4
03add0: *(u64 *)(r10 - 0x1e8) = r1
03add8: r1 = r10
03ade0: r1 += -0x2f8
03ade8: *(u64 *)(r10 - 0x1f0) = r1
03adf0: r1 = r10
03adf8: r1 += -0x150
03ae00: r2 = r7
03ae08: r3 = 0x30
03ae10: call 0xbc0f ; call 0x98e90 / window 1246
03ae18: r1 = r10
03ae20: r1 += -0x80
03ae28: r2 = r10
03ae30: r2 += -0x1f0
03ae38: call 0x770d ; call 0x766a8 / window 775
03ae40: w1 = *(u32 *)(r10 - 0x80)
03ae48: if r1 == 0x16 goto +0x1 ; branch 0x3ae58
03ae50: goto +0x16 ; branch 0x3af08
03ae58: r1 = 0x16
03ae60: goto +0xa ; branch 0x3aeb8
03ae68: r2 = *(u64 *)(r10 - 0x1e0)
03ae70: *(u64 *)(r10 - 0x2f8) = r2
03ae78: r3 = *(u64 *)(r10 - 0x1d8)
03ae80: *(u64 *)(r10 - 0x2f0) = r3
03ae88: w4 = *(u32 *)(r10 - 0x1ec)
03ae90: r5 = *(u64 *)(r10 - 0x1e8)
03ae98: *(u64 *)(r6 + 0x18) = r3
03aea0: *(u64 *)(r6 + 0x10) = r2
03aea8: *(u64 *)(r6 + 0x8) = r5
03aeb0: *(u32 *)(r6 + 0x4) = w4
03aeb8: *(u32 *)(r6 + 0x0) = w1
03aec0: r1 = r10
03aec8: r1 += -0x3e0
03aed0: call -0x6fc7 ; call 0x30a0 / window 59
03aed8: goto -0x1ca ; branch 0x3a090
03aee0: r1 = 0x0
03aee8: *(u32 *)(r6 + 0x0) = w1
03aef0: r1 = r9
03aef8: *(u32 *)(r6 + 0x4) = w1
03af00: goto -0x9 ; branch 0x3aec0
03af08: w2 = *(u32 *)(r10 - 0x64)
03af10: *(u32 *)(r10 - 0x88) = w2
03af18: r3 = *(u64 *)(r10 - 0x6c)
03af20: *(u64 *)(r10 - 0x90) = r3
03af28: r4 = *(u64 *)(r10 - 0x74)
03af30: *(u64 *)(r10 - 0x98) = r4
03af38: r5 = *(u64 *)(r10 - 0x7c)
03af40: *(u64 *)(r10 - 0xa0) = r5
03af48: *(u32 *)(r6 + 0x1c) = w2
03af50: *(u64 *)(r6 + 0x14) = r3
03af58: *(u64 *)(r6 + 0xc) = r4
03af60: *(u64 *)(r6 + 0x4) = r5
03af68: goto -0x17 ; branch 0x3aeb8
