00fce8: r3 = 0x3e
00fcf0: call -0x57d ; call 0xd110 / window 253
00fcf8: exit
