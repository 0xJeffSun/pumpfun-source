#!/usr/bin/env python3
"""Read-only analysis of frozen ELF inputs. Writes diagnostic JSON/text only."""
from pathlib import Path
import hashlib,json,struct,sys,re,difflib,subprocess
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'))
from elf_reader import Elf
TARGETS=[311,312,314,324,328,335,337,344,346,350]
paths={'original':'evidence/dependencies/token_metadata/deployed.so','candidate':'repro/pump/metaplex-candidate-build-8/token_metadata.so'}
E={side:Elf(ROOT/path)for side,path in paths.items()}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for ordinal in TARGETS:
 row={'ordinal':ordinal}
 for side,e in E.items():
  start,end=e.entries[ordinal:ordinal+2];idx={x:i for i,x in enumerate(e.entries)}
  callers=[{'at':at,'caller_ordinal':next((i for i in range(len(e.entries)-1)if e.entries[i]<=at<e.entries[i+1]),None),'target':target}for at,target in e.calls.items()if target==start]
  calls=[{'at':start+x['offset'],'target':x['target'],'ordinal':idx.get(x['target'])}for x in e.callsites(start,end-start)]
  row[side]={'start':start,'end':end,'size':end-start,'window_sha256':hashlib.sha256(e.b[start:end]).hexdigest(),'normalized_sha256':hashlib.sha256(e.normalized[start:end]).hexdigest(),'callers':callers,'calls':calls}
 a=[x['ordinal']for x in row['original']['calls']];b=[x['ordinal']for x in row['candidate']['calls']]
 row['call_sequence_differences']=[{'op':op,'original':a[i:j],'candidate':b[k:l]}for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes()if op!='equal']
 row['linear_diff_limit']='Relocation/call address and branch displacement normalization assists human alignment only; no CFG or semantic equality claim.'
 AB=[]
 for side in ['original','candidate']:
  lines=[]
  for line in (W/f'{side}-{ordinal}.asm').read_text().splitlines():
   at,rest=line.split(': ',1);txt=rest.split(' ; ')[0]
   if ' / window 'in rest:txt='call window '+rest.rsplit(' / window ',1)[1]
   elif '; external 'in rest:txt='call external '+rest.rsplit('; external ',1)[1]
   elif '; branch 'in rest:txt=re.sub(r'goto .*','goto <branch>',txt)
   elif '; data 'in rest:txt=re.sub(r'0x[0-9a-f]+ ll','<rodata> ll',txt)
   lines.append((at,txt))
  AB.append(lines)
 A,B=AB;out=[]
 for group in difflib.SequenceMatcher(None,[x[1]for x in A],[x[1]for x in B],autojunk=False).get_grouped_opcodes(3):
  out.append('@@')
  for op,i,j,k,l in group:
   if op=='equal':out.extend(' '+at+': '+txt for at,txt in A[i:j])
   else:out.extend('-'+at+': '+txt for at,txt in A[i:j]);out.extend('+'+at+': '+txt for at,txt in B[k:l])
 (W/f'diff-{ordinal}.txt').write_text('\n'.join(out)+'\n');rows.append(row)
(W/'call-map.json').write_text(json.dumps(rows,indent=2)+'\n')
e=E['original'];idx={x:i for i,x in enumerate(e.entries)};dispatch=[]
for name,lddw,log,call in [('Delegate',0x3d4d8,0x3d4f0,0x3d550),('Revoke',0x3d3d8,0x3d3f0,0x3d420),('Mint',0x3de90,0x3dea8,0x3df08),('Print',0x3d598,0x3d5b0,0x3d5f0),('Transfer',0x3d600,0x3d618,0x3d678),('Update',0x3ddf8,0x3de10,0x3de70),('ApproveUseAuthority',0x3f238,0x3f250,0x3f280),('Utilize',0x3f630,0x3f648,0x3f678)]:
 ptr=struct.unpack_from('<I',e.b,lddw+4)[0]|struct.unpack_from('<I',e.b,lddw+12)[0]<<32;length=struct.unpack_from('<i',e.b,lddw+20)[0]
 assert e.b[lddw]==0x18 and e.b[lddw+16:lddw+18]==b'\xb7\x02' and e.relocations[log]['symbol']=='sol_log_'
 dispatch.append({'variant':name,'log_pointer_instruction':hex(lddw),'exact_log':e.b[ptr:ptr+length].decode(),'length':length,'log_call':hex(log),'handler_call':hex(call),'target':hex(e.calls[call]),'target_ordinal':idx[e.calls[call]]})
(W/'dispatch-evidence.json').write_text(json.dumps(dispatch,indent=2)+'\n')
rev='17e99434af5ead3e989c08f32af33609821d0bc0';C=ROOT/'work/pump-recovery/metaplex-source';source=[]
for p in sorted((W/'public-source').rglob('*.rs')):
 rel=str(p.relative_to(W/'public-source'));b=p.read_bytes();expected=subprocess.check_output(['git','-C',str(C),'show',f'{rev}:{rel}'])
 assert b==expected
 source.append({'path':rel,'bytes':len(b),'sha256':sha(p),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(W/'public-source-manifest.json').write_text(json.dumps({'revision':rev,'all_bytes_verified_against_git_show':True,'files':source},indent=2)+'\n')
refs=['repro/pump_fees/framework-matching/elf_reader.py','repro/pump/metaplex-candidate-build-8/function-analysis.json','repro/pump/metaplex-candidate-build-8/source.patch','repro/pump/metaplex-candidate-build-8/source-manifest.json','repro/pump/metaplex-candidate-build-8/upstream-source-manifest.json','repro/pump/metaplex-candidate-build-8/patch-source-inputs.json']
inputs={'source_revision':rev,'checkout_HEAD_observed':subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip(),'elfs':{side:{**e.identity(),'bytes':len(e.b),'entrypoint':hex(struct.unpack_from('<Q',e.b,24)[0]),'inferred_windows':len(e.entries)}for side,e in E.items()},'references':[{'path':p,'sha256':sha(ROOT/p)}for p in refs], 'scope':{'read_only_ELF_and_public_source':True,'builds':0,'runtime_probes':0,'source_edits':0,'executables_patched':False,'full_byte_equality':False}}
(W/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps({'windows':len(rows),'verified_public_source_files':len(source),'dispatch_links':len(dispatch),'inputs':inputs['elfs']},indent=2))
