029b40: r6 = r5
029b48: r9 = r2
029b50: r8 = r1
029b58: r1 = r10
029b60: r1 += -0xb8
029b68: r2 = r3
029b70: r3 = r4
029b78: call 0x6ebd ; call 0x61168 / window 492
029b80: r7 = *(u64 *)(r10 - 0x88)
029b88: if r7 != 0x0 goto +0x10 ; branch 0x29c10
029b90: r1 = *(u64 *)(r10 - 0xa0)
029b98: *(u64 *)(r10 - 0x28) = r1
029ba0: r2 = *(u64 *)(r10 - 0xa8)
029ba8: *(u64 *)(r10 - 0x30) = r2
029bb0: r3 = *(u64 *)(r10 - 0xb0)
029bb8: *(u64 *)(r10 - 0x38) = r3
029bc0: r4 = *(u64 *)(r10 - 0xb8)
029bc8: *(u64 *)(r10 - 0x40) = r4
029bd0: *(u64 *)(r8 + 0x18) = r1
029bd8: *(u64 *)(r8 + 0x10) = r2
029be0: *(u64 *)(r8 + 0x8) = r3
029be8: *(u64 *)(r8 + 0x0) = r4
029bf0: r6 += 0x10
029bf8: r1 = r6
029c00: call -0x4c7c ; call 0x3828 / window 85
029c08: goto +0x2e ; branch 0x29d80
029c10: *(u64 *)(r10 - 0x130) = r8
029c18: r8 = r10
029c20: r8 += -0x40
029c28: r2 = r10
029c30: r2 += -0xb8
029c38: r1 = r8
029c40: r3 = 0x30
029c48: call 0xde48 ; call 0x98e90 / window 1246
029c50: *(u64 *)(r10 - 0x138) = r9
029c58: r9 = r10
029c60: r9 += -0x128
029c68: r2 = r10
029c70: r2 += -0x80
029c78: r1 = r9
029c80: r3 = 0x40
029c88: call 0xde40 ; call 0x98e90 / window 1246
029c90: *(u64 *)(r10 - 0x140) = r6
029c98: r6 = r10
029ca0: r6 += -0xe8
029ca8: r1 = r6
029cb0: r2 = r8
029cb8: r3 = 0x30
029cc0: call 0xde39 ; call 0x98e90 / window 1246
029cc8: r8 = r10
029cd0: r8 += -0xb8
029cd8: r1 = r8
029ce0: r2 = r6
029ce8: r3 = 0x30
029cf0: call 0xde33 ; call 0x98e90 / window 1246
029cf8: *(u64 *)(r10 - 0x88) = r7
029d00: r1 = r10
029d08: r1 += -0x80
029d10: r2 = r9
029d18: r3 = 0x40
029d20: call 0xde2d ; call 0x98e90 / window 1246
029d28: r6 = r10
029d30: r6 += -0x40
029d38: r1 = r6
029d40: r2 = *(u64 *)(r10 - 0x140)
029d48: r3 = 0x40
029d50: call 0xde27 ; call 0x98e90 / window 1246
029d58: r1 = *(u64 *)(r10 - 0x130)
029d60: r2 = *(u64 *)(r10 - 0x138)
029d68: r3 = r8
029d70: r4 = r6
029d78: call 0x1 ; call 0x29d88 / window 324
029d80: exit
