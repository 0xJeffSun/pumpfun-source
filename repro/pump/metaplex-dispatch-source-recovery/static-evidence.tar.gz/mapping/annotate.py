from pathlib import Path
import sys,re,json,struct,hashlib,difflib
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'));from elf_reader import Elf
selected=[41,42,44,59,77,263,265,275,276,277,311,312,313,314,323,324,325,326,327,328,335,337,344,346,350,463,492,493,495,496,499,955]
for side,path in [('original','evidence/dependencies/token_metadata/deployed.so'),('candidate','repro/pump/metaplex-candidate-build-8/token_metadata.so')]:
 e=Elf(ROOT/path);indices={x:i for i,x in enumerate(e.entries)};asm={}
 for line in (W/(side+'-disassembly.asm')).read_text().splitlines():
  m=re.match(r'\s*(\d+):\s*(.+)',line)
  if m:asm[int(m[1])*8]=m[2]
 rows=[]
 for i in selected:
  start,end=e.entries[i:i+2];lines=[]
  for at in range(start,end,8):
   if at not in asm:continue
   mn=re.sub(r' <[^>]*>','',asm[at]);extra=[]
   if at in e.calls:extra.append(f'call {e.calls[at]:#x} / window {indices.get(e.calls[at])}')
   if at in e.relocations and e.relocations[at]['type']==10:extra.append('external '+e.relocations[at]['symbol'])
   if e.b[at]&7==5 and e.b[at] not in [0x85,0x8d,0x95]:extra.append('branch '+hex(at+8+8*struct.unpack_from('<h',e.b,at+2)[0]))
   if e.b[at]==0x18 and at in e.relocations:
    ptr=struct.unpack_from('<I',e.b,at+4)[0]|(struct.unpack_from('<I',e.b,at+12)[0]<<32)
    if e.hi<=ptr<len(e.b):extra.append('data '+repr(e.b[ptr:ptr+100]))
   lines.append(f'{at:06x}: {mn}'+(' ; '+' ; '.join(extra)if extra else''))
  (W/f'{side}-{i}.asm').write_text('\n'.join(lines)+'\n')
