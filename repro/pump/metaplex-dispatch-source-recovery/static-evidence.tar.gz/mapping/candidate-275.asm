00fc30: r4 = 0x39
00fc38: call -0x65f ; call 0xc948 / window 248
00fc40: exit
