032238: r9 = r5
032240: *(u64 *)(r10 - 0x6f8) = r2
032248: r6 = r1
032250: r1 = r10
032258: r1 += -0x1b0
032260: r2 = r3
032268: r3 = r4
032270: call 0x5f9b ; call 0x61f50 / window 496
032278: r8 = *(u64 *)(r10 - 0x198)
032280: r1 = *(u64 *)(r10 - 0x1a0)
032288: r3 = *(u64 *)(r10 - 0x1a8)
032290: r2 = *(u64 *)(r10 - 0x1b0)
032298: r7 = *(u64 *)(r10 - 0x188)
0322a0: if r7 != 0x0 goto +0x6 ; branch 0x322d8
0322a8: *(u64 *)(r6 + 0x18) = r8
0322b0: *(u64 *)(r6 + 0x10) = r1
0322b8: *(u64 *)(r6 + 0x8) = r3
0322c0: *(u64 *)(r6 + 0x0) = r2
0322c8: r1 = r9
0322d0: goto +0x71 ; branch 0x32660
0322d8: *(u64 *)(r10 - 0x708) = r3
0322e0: *(u64 *)(r10 - 0x700) = r2
0322e8: *(u64 *)(r10 - 0x720) = r1
0322f0: *(u64 *)(r10 - 0x6f0) = r6
0322f8: r1 = *(u64 *)(r10 - 0x160)
032300: *(u64 *)(r10 - 0x730) = r1
032308: r1 = *(u64 *)(r10 - 0x168)
032310: *(u64 *)(r10 - 0x728) = r1
032318: r6 = *(u64 *)(r10 - 0x170)
032320: r1 = *(u64 *)(r10 - 0x178)
032328: *(u64 *)(r10 - 0x718) = r1
032330: r1 = *(u64 *)(r10 - 0x180)
032338: *(u64 *)(r10 - 0x710) = r1
032340: r1 = *(u64 *)(r10 - 0x190)
032348: *(u64 *)(r10 - 0x738) = r1
032350: r1 = r10
032358: r1 += -0x6c8
032360: r2 = r9
032368: r3 = 0x158
032370: call 0xcd84 ; call 0x98f98 / window 1246
032378: r1 = r10
032380: r1 += -0x1b0
032388: r2 = r7
032390: call 0x8866 ; call 0x766c8 / window 773
032398: w1 = *(u32 *)(r10 - 0x1b0)
0323a0: r9 = r7
0323a8: if r1 != 0x16 goto +0x40 ; branch 0x325b0
0323b0: r1 = r10
0323b8: r1 += -0x1b0
0323c0: r2 = r6
0323c8: call 0x885f ; call 0x766c8 / window 773
0323d0: w1 = *(u32 *)(r10 - 0x1b0)
0323d8: if r1 == 0x16 goto +0x1 ; branch 0x323e8
0323e0: goto +0x39 ; branch 0x325b0
0323e8: r6 = *(u64 *)(r10 - 0x6f0)
0323f0: r2 = *(u64 *)(r10 - 0x700)
0323f8: if r2 == 0x0 goto +0x8 ; branch 0x32440
032400: r1 = r10
032408: r1 += -0x1b0
032410: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
032420: call -0x44ff ; call 0xfc30 / window 275
032428: w1 = *(u32 *)(r10 - 0x1b0)
032430: if r1 == 0x16 goto +0x1 ; branch 0x32440
032438: goto +0x39 ; branch 0x32608
032440: r2 = *(u64 *)(r10 - 0x708)
032448: if r2 == 0x0 goto +0x9 ; branch 0x32498
032450: r1 = r10
032458: r1 += -0x1b0
032460: r3 = 0x9cc8e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
032470: r4 = 0x2
032478: call -0x4507 ; call 0xfc48 / window 276
032480: w1 = *(u32 *)(r10 - 0x1b0)
032488: if r1 == 0x16 goto +0x1 ; branch 0x32498
032490: goto +0x2e ; branch 0x32608
032498: r1 = r10
0324a0: r1 += -0x1b0
0324a8: r2 = *(u64 *)(r10 - 0x710)
0324b0: r3 = 0x9cc8e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
0324c0: r4 = 0x2
0324c8: call -0x4511 ; call 0xfc48 / window 276
0324d0: w1 = *(u32 *)(r10 - 0x1b0)
0324d8: if r1 == 0x16 goto +0x1 ; branch 0x324e8
0324e0: goto +0x24 ; branch 0x32608
0324e8: r1 = r10
0324f0: r1 += -0x1b0
0324f8: r2 = *(u64 *)(r10 - 0x718)
032500: r3 = *(u64 *)(r10 - 0x6f8)
032508: call -0x451c ; call 0xfc30 / window 275
032510: w1 = *(u32 *)(r10 - 0x1b0)
032518: if r1 == 0x16 goto +0x1 ; branch 0x32528
032520: goto +0x1c ; branch 0x32608
032528: r2 = *(u64 *)(r10 - 0x720)
032530: if r2 == 0x0 goto +0x7 ; branch 0x32570
032538: r1 = r10
032540: r1 += -0x1b0
032548: r3 = *(u64 *)(r10 - 0x6f8)
032550: call -0x4525 ; call 0xfc30 / window 275
032558: w1 = *(u32 *)(r10 - 0x1b0)
032560: if r1 == 0x16 goto +0x1 ; branch 0x32570
032568: goto +0x13 ; branch 0x32608
032570: r1 = *(u64 *)(r10 - 0x728)
032578: r2 = 0x9ed68 ll ; data b'\x00\x00\x00\x00\xe8\x99\t\x00\x00\x00\x00\x00\xc8\x9a\t\x00\x00\x00\x00\x00\x18\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00H\x9a\t\x00\x00\x00\x00\x00:\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00`\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00'
032588: call -0x5f17 ; call 0x2cd8 / window 42
032590: if r0 != 0x0 goto +0x1 ; branch 0x325a0
032598: goto +0x1a ; branch 0x32670
0325a0: r1 = 0x6
0325a8: goto +0x13 ; branch 0x32648
0325b0: w2 = *(u32 *)(r10 - 0x194)
0325b8: r3 = *(u64 *)(r10 - 0x6f0)
0325c0: *(u32 *)(r3 + 0x1c) = w2
0325c8: r2 = *(u64 *)(r10 - 0x19c)
0325d0: *(u64 *)(r3 + 0x14) = r2
0325d8: r2 = *(u64 *)(r10 - 0x1a4)
0325e0: *(u64 *)(r3 + 0xc) = r2
0325e8: r2 = *(u64 *)(r10 - 0x1ac)
0325f0: *(u64 *)(r3 + 0x4) = r2
0325f8: *(u32 *)(r3 + 0x0) = w1
032600: goto +0x9 ; branch 0x32650
032608: w2 = *(u32 *)(r10 - 0x194)
032610: *(u32 *)(r6 + 0x1c) = w2
032618: r2 = *(u64 *)(r10 - 0x19c)
032620: *(u64 *)(r6 + 0x14) = r2
032628: r2 = *(u64 *)(r10 - 0x1a4)
032630: *(u64 *)(r6 + 0xc) = r2
032638: r2 = *(u64 *)(r10 - 0x1ac)
032640: *(u64 *)(r6 + 0x4) = r2
032648: *(u32 *)(r6 + 0x0) = w1
032650: r1 = r10
032658: r1 += -0x6c8
032660: call -0x5e5b ; call 0x3390 / window 68
032668: exit
032670: r1 = *(u64 *)(r10 - 0x730)
032678: r2 = 0x9ed70 ll ; data b'\x00\x00\x00\x00\xc8\x9a\t\x00\x00\x00\x00\x00\x18\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00H\x9a\t\x00\x00\x00\x00\x00:\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00`\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00\x86\xa4\t\x00)\x00\x00\x00'
032688: call -0x5f37 ; call 0x2cd8 / window 42
032690: if r0 != 0x0 goto -0x1f ; branch 0x325a0
032698: r1 = *(u64 *)(r10 - 0x738)
0326a0: if r1 == 0x0 goto +0x6 ; branch 0x326d8
0326a8: if r8 == 0x0 goto +0x30 ; branch 0x32830
0326b0: r1 = r8
0326b8: r2 = 0x9f200 ll ; data b'\x00\x00\x00\x00\xe8\x9a\t\x00\x00\x00\x00\x00Q\xa8\t\x00*\x00\x00\x00\x00\x00\x00\x00\xd7\x00\x00\x00<\x00\x00\x00\x00\x00\x00\x00Q\xa8\t\x00*\x00\x00\x00\x00\x00\x00\x00\x02\x01\x00\x00T\x00\x00\x00\x00\x00\x00\x00Q\xa8\t\x00*\x00\x00\x00\x00\x00\x00\x00\xd8\x01\x00\x00R\x00\x00\x00\x00\x00\x00\x00Q\xa8\t\x00*\x00\x00\x00\x00\x00\x00\x00V\x01\x00\x00'
0326c8: call -0x5f3f ; call 0x2cd8 / window 42
0326d0: if r0 != 0x0 goto -0x27 ; branch 0x325a0
0326d8: r8 = 0x0
0326e0: r6 = 0x2
0326e8: r2 = *(u64 *)(r10 - 0x708)
0326f0: if r2 == 0x0 goto +0x7b ; branch 0x32ad0
0326f8: r1 = r10
032700: r1 += -0x1b0
032708: call 0xa5a5 ; call 0x85438 / window 985
032710: w1 = *(u32 *)(r10 - 0x1b0)
032718: if r1 == 0x16 goto +0x1 ; branch 0x32728
032720: goto +0x25 ; branch 0x32850
032728: r7 = *(u64 *)(r10 - 0x1a0)
032730: r1 = *(u64 *)(r10 - 0x1a8)
032738: r3 = *(u64 *)(r1 + 0x8)
032740: r2 = *(u64 *)(r1 + 0x0)
032748: r1 = r10
032750: r1 += -0x1b0
032758: call 0x936a ; call 0x7c2b0 / window 851
032760: w6 = *(u32 *)(r10 - 0x158)
032768: if r6 == 0x2 goto +0x1 ; branch 0x32778
032770: goto +0x26 ; branch 0x328a8
032778: r1 = *(u64 *)(r10 - 0x198)
032780: *(u64 *)(r10 - 0x460) = r1
032788: r1 = *(u64 *)(r10 - 0x1a0)
032790: *(u64 *)(r10 - 0x468) = r1
032798: r1 = *(u64 *)(r10 - 0x1a8)
0327a0: *(u64 *)(r10 - 0x428) = r1
0327a8: *(u64 *)(r10 - 0x470) = r1
0327b0: r1 = *(u64 *)(r10 - 0x1b0)
0327b8: *(u64 *)(r10 - 0x430) = r1
0327c0: *(u64 *)(r10 - 0x478) = r1
0327c8: r1 = *(u64 *)(r10 - 0x460)
0327d0: r2 = *(u64 *)(r10 - 0x6f0)
0327d8: *(u64 *)(r2 + 0x18) = r1
0327e0: r1 = *(u64 *)(r10 - 0x468)
0327e8: *(u64 *)(r2 + 0x10) = r1
0327f0: r1 = *(u64 *)(r10 - 0x470)
0327f8: *(u64 *)(r2 + 0x8) = r1
032800: r1 = *(u64 *)(r10 - 0x478)
032808: *(u64 *)(r2 + 0x0) = r1
032810: r1 = *(u64 *)(r7 + 0x0)
032818: r1 += -0x1
032820: *(u64 *)(r7 + 0x0) = r1
032828: goto -0x3c ; branch 0x32650
032830: r1 = 0x9600000000 ll
032840: *(u64 *)(r6 + 0x0) = r1
032848: goto -0x40 ; branch 0x32650
032850: w2 = *(u32 *)(r10 - 0x1ac)
032858: r3 = *(u64 *)(r10 - 0x1a8)
032860: r4 = *(u64 *)(r10 - 0x1a0)
032868: r5 = *(u64 *)(r10 - 0x198)
032870: r0 = *(u64 *)(r10 - 0x6f0)
032878: *(u64 *)(r0 + 0x18) = r5
032880: *(u64 *)(r0 + 0x10) = r4
032888: *(u64 *)(r0 + 0x8) = r3
032890: *(u32 *)(r0 + 0x4) = w2
032898: *(u32 *)(r0 + 0x0) = w1
0328a0: goto -0x4b ; branch 0x32650
0328a8: *(u64 *)(r10 - 0x728) = r9
0328b0: r8 = r10
0328b8: r8 += -0x570
0328c0: r2 = r10
0328c8: r2 += -0x1b0
0328d0: r1 = r8
0328d8: r3 = 0x58
0328e0: call 0xccd6 ; call 0x98f98 / window 1246
0328e8: r1 = r10
0328f0: r1 += -0x39c
0328f8: r2 = r10
032900: r2 += -0x154
032908: *(u64 *)(r10 - 0x730) = r1
032910: r3 = 0x64
032918: call 0xcccf ; call 0x98f98 / window 1246
032920: r1 = r10
032928: r1 += -0x58
032930: r2 = r8
032938: r3 = 0x58
032940: call 0xccca ; call 0x98f98 / window 1246
032948: r8 = r10
032950: r8 += -0x430
032958: r2 = r10
032960: r2 += -0x48
032968: r1 = r8
032970: r3 = 0x48
032978: call 0xccc3 ; call 0x98f98 / window 1246
032980: r9 = r10
032988: r9 += -0x478
032990: r1 = r9
032998: r2 = r8
0329a0: r3 = 0x48
0329a8: call 0xccbd ; call 0x98f98 / window 1246
0329b0: r8 = r10
0329b8: r8 += -0x3e8
0329c0: r1 = r8
0329c8: r2 = r9
0329d0: r3 = 0x48
0329d8: call 0xccb7 ; call 0x98f98 / window 1246
0329e0: *(u32 *)(r10 - 0x3a0) = w6
0329e8: r1 = *(u64 *)(r7 + 0x0)
0329f0: r1 += -0x1
0329f8: *(u64 *)(r7 + 0x0) = r1
032a00: r1 = *(u64 *)(r10 - 0x710)
032a08: r2 = *(u64 *)(r1 + 0x0)
032a10: r1 = r8
032a18: call -0x5fa2 ; call 0x2d10 / window 44
032a20: if r0 != 0x0 goto +0x1 ; branch 0x32a30
032a28: goto +0x3 ; branch 0x32a48
032a30: r1 = 0xf00000000 ll
032a40: goto +0x12e ; branch 0x333b8
032a48: r1 = *(u64 *)(r10 - 0x3a8)
032a50: if r1 == 0x0 goto +0x12a ; branch 0x333a8
032a58: r1 = *(u64 *)(r10 - 0x708)
032a60: r8 = *(u64 *)(r1 + 0x0)
032a68: r1 = r10
032a70: r1 += -0x4c0
032a78: r2 = r10
032a80: r2 += -0x3e8
032a88: r3 = 0x48
032a90: call 0xcca0 ; call 0x98f98 / window 1246
032a98: w6 = *(u32 *)(r10 - 0x3a0)
032aa0: r1 = r10
032aa8: r1 += -0x2b8
032ab0: r2 = *(u64 *)(r10 - 0x730)
032ab8: r3 = 0x64
032ac0: call 0xcc9a ; call 0x98f98 / window 1246
032ac8: r9 = *(u64 *)(r10 - 0x728)
032ad0: r1 = r10
032ad8: r1 += -0x570
032ae0: r2 = r10
032ae8: r2 += -0x4c0
032af0: r3 = 0x48
032af8: call 0xcc93 ; call 0x98f98 / window 1246
032b00: *(u32 *)(r10 - 0x528) = w6
032b08: r1 = r10
032b10: r1 += -0x524
032b18: r2 = r10
032b20: r2 += -0x2b8
032b28: r3 = 0x64
032b30: call 0xcc8c ; call 0x98f98 / window 1246
032b38: r1 = r10
032b40: r1 += -0x1b0
032b48: r2 = *(u64 *)(r10 - 0x718)
032b50: call 0x2a8d ; call 0x47fc0 / window 419
032b58: w7 = *(u32 *)(r10 - 0xa8)
032b60: if r7 != 0x2 goto +0xe ; branch 0x32bd8
032b68: r1 = *(u64 *)(r10 - 0x198)
032b70: *(u64 *)(r10 - 0x2a0) = r1
032b78: r2 = *(u64 *)(r10 - 0x1a0)
032b80: *(u64 *)(r10 - 0x2a8) = r2
032b88: r3 = *(u64 *)(r10 - 0x1a8)
032b90: *(u64 *)(r10 - 0x2b0) = r3
032b98: r4 = *(u64 *)(r10 - 0x1b0)
032ba0: *(u64 *)(r10 - 0x2b8) = r4
032ba8: r5 = *(u64 *)(r10 - 0x6f0)
032bb0: *(u64 *)(r5 + 0x18) = r1
032bb8: *(u64 *)(r5 + 0x10) = r2
032bc0: *(u64 *)(r5 + 0x8) = r3
032bc8: *(u64 *)(r5 + 0x0) = r4
032bd0: goto -0xb1 ; branch 0x32650
032bd8: r6 = r10
032be0: r6 += -0x2b8
032be8: r2 = r10
032bf0: r2 += -0x1b0
032bf8: r1 = r6
032c00: r3 = 0x108
032c08: call 0xcc71 ; call 0x98f98 / window 1246
032c10: r1 = r10
032c18: r1 += -0x2dc
032c20: r2 = r10
032c28: r2 += -0xa4
032c30: r3 = 0x24
032c38: call 0xcc6b ; call 0x98f98 / window 1246
032c40: r1 = r10
032c48: r1 += -0x3e8
032c50: r2 = r6
032c58: r3 = 0x108
032c60: call 0xcc66 ; call 0x98f98 / window 1246
032c68: *(u32 *)(r10 - 0x2e0) = w7
032c70: r1 = *(u64 *)(r10 - 0x710)
032c78: r2 = *(u64 *)(r1 + 0x0)
032c80: r1 = r10
032c88: r1 += -0x3c4
032c90: call -0x5ff1 ; call 0x2d10 / window 44
032c98: if r0 != 0x0 goto +0x1 ; branch 0x32ca8
032ca0: goto +0x5 ; branch 0x32cd0
032ca8: r1 = 0xf00000000 ll
032cb8: r2 = *(u64 *)(r10 - 0x6f0)
032cc0: *(u64 *)(r2 + 0x0) = r1
032cc8: goto +0xd7 ; branch 0x33388
032cd0: r1 = *(u64 *)(r10 - 0x720)
032cd8: if r1 == 0x0 goto +0x29 ; branch 0x32e28
032ce0: r1 = r10
032ce8: r1 += -0x6d8
032cf0: r6 = *(u64 *)(r10 - 0x6f8)
032cf8: r2 = r6
032d00: call 0xa6a8 ; call 0x86248 / window 990
032d08: r1 = *(u64 *)(r10 - 0x710)
032d10: r2 = *(u64 *)(r1 + 0x0)
032d18: r1 = *(u64 *)(r10 - 0x6d8)
032d20: *(u64 *)(r10 - 0x708) = r1
032d28: r7 = *(u64 *)(r10 - 0x6d0)
032d30: r1 = r10
032d38: r1 += -0x6e8
032d40: call 0xa6a0 ; call 0x86248 / window 990
032d48: r1 = 0x7
032d50: *(u64 *)(r10 - 0x178) = r1
032d58: r1 = 0x9a255 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
032d68: *(u64 *)(r10 - 0x180) = r1
032d70: *(u64 *)(r10 - 0x198) = r7
032d78: r1 = *(u64 *)(r10 - 0x708)
032d80: *(u64 *)(r10 - 0x1a0) = r1
032d88: r1 = 0x8
032d90: *(u64 *)(r10 - 0x1a8) = r1
032d98: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
032da8: *(u64 *)(r10 - 0x1b0) = r1
032db0: r1 = *(u64 *)(r10 - 0x6e0)
032db8: *(u64 *)(r10 - 0x188) = r1
032dc0: r1 = *(u64 *)(r10 - 0x6e8)
032dc8: *(u64 *)(r10 - 0x190) = r1
032dd0: r1 = r10
032dd8: r1 += -0x2b8
032de0: r4 = r10
032de8: r4 += -0x1b0
032df0: r2 = r6
032df8: r3 = *(u64 *)(r10 - 0x720)
032e00: r5 = 0x4
032e08: call -0x4648 ; call 0xfbd0 / window 273
032e10: w1 = *(u32 *)(r10 - 0x2b8)
032e18: if r1 == 0x16 goto +0x1 ; branch 0x32e28
032e20: goto +0xa0 ; branch 0x33328
032e28: r3 = 0x0
032e30: w1 = *(u8 *)(r10 - 0x330)
032e38: if r1 == 0x2 goto +0x2 ; branch 0x32e50
032e40: r3 = r10
032e48: r3 += -0x32f
032e50: w2 = *(u32 *)(r10 - 0x6c8)
032e58: r1 = r10
032e60: r1 += -0x62c
032e68: *(u64 *)(r10 - 0x6f8) = r3
032e70: if r2 == 0x0 goto +0x7 ; branch 0x32eb0
032e78: if r2 == 0x1 goto +0x6 ; branch 0x32eb0
032e80: r1 = r10
032e88: r1 += -0x6c0
032e90: if r2 == 0x3 goto +0x3 ; branch 0x32eb0
032e98: r3 = r9
032ea0: if r2 == 0x7 goto +0x1 ; branch 0x32eb0
032ea8: goto +0x6 ; branch 0x32ee0
032eb0: w2 = *(u32 *)(r1 + 0x0)
032eb8: r1 += 0x5
032ec0: if r2 == 0x2 goto +0x1 ; branch 0x32ed0
032ec8: r1 = *(u64 *)(r10 - 0x6f8)
032ed0: *(u64 *)(r10 - 0x6f8) = r1
032ed8: r3 = r9
032ee0: *(u64 *)(r10 - 0x728) = r3
032ee8: r1 = *(u64 *)(r3 + 0x0)
032ef0: *(u64 *)(r10 - 0x730) = r1
032ef8: r1 = *(u64 *)(r10 - 0x710)
032f00: r1 = *(u64 *)(r1 + 0x0)
032f08: *(u64 *)(r10 - 0x740) = r1
032f10: w9 = *(u32 *)(r10 - 0x528)
032f18: r1 = 0x1c
032f20: r2 = 0x4
032f28: call -0x5a55 ; call 0x5c88 / window 138
032f30: r6 = r0
032f38: r1 = 0x400000006 ll
032f48: *(u64 *)(r6 + 0x10) = r1
032f50: r1 = 0x100000005 ll
032f60: *(u64 *)(r6 + 0x8) = r1
032f68: r1 = 0x300000000 ll
032f78: *(u64 *)(r6 + 0x0) = r1
032f80: r1 = r10
032f88: r1 += -0x570
032f90: r7 = 0x0
032f98: r2 = 0x0
032fa0: *(u64 *)(r10 - 0x708) = r2
032fa8: if r9 == 0x2 goto +0x1 ; branch 0x32fb8
032fb0: *(u64 *)(r10 - 0x708) = r1
032fb8: r9 = 0x7
032fc0: *(u32 *)(r6 + 0x18) = w9
032fc8: r1 = 0xc
032fd0: r2 = 0x4
032fd8: call -0x5a6b ; call 0x5c88 / window 138
032fe0: r1 = 0x100000003 ll
032ff0: *(u64 *)(r0 + 0x0) = r1
032ff8: r2 = 0x4
033000: *(u32 *)(r0 + 0x8) = w2
033008: r1 = 0x999e8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
033018: *(u64 *)(r10 - 0x168) = r1
033020: *(u64 *)(r10 - 0x170) = r1
033028: *(u64 *)(r10 - 0x178) = r1
033030: r1 = 0x99eb4 ll ; data b'\x04\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00host unreachablerange end index already mutably borrowed/home/runner/work/platform-t'
033040: *(u64 *)(r10 - 0x1b0) = r1
033048: *(u64 *)(r10 - 0x160) = r7
033050: *(u64 *)(r10 - 0x1a8) = r2
033058: *(u64 *)(r10 - 0x1a0) = r7
033060: *(u64 *)(r10 - 0x198) = r7
033068: *(u64 *)(r10 - 0x190) = r7
033070: *(u64 *)(r10 - 0x188) = r7
033078: *(u64 *)(r10 - 0x150) = r7
033080: *(u64 *)(r10 - 0x158) = r2
033088: *(u64 *)(r10 - 0x148) = r7
033090: *(u64 *)(r10 - 0x140) = r2
033098: *(u64 *)(r10 - 0x138) = r7
0330a0: *(u64 *)(r10 - 0x180) = r7
0330a8: *(u64 *)(r10 - 0x130) = r7
0330b0: *(u64 *)(r10 - 0x128) = r2
0330b8: *(u64 *)(r10 - 0x120) = r7
0330c0: r1 = *(u64 *)(r10 - 0x740)
0330c8: *(u64 *)(r10 - 0x270) = r1
0330d0: r1 = *(u64 *)(r10 - 0x730)
0330d8: *(u64 *)(r10 - 0x280) = r1
0330e0: r1 = 0x9a88c ll ; data b'\x01\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00Auth type: DelegateAuth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.'
0330f0: *(u64 *)(r10 - 0x2b8) = r1
0330f8: *(u64 *)(r10 - 0x248) = r0
033100: r1 = 0x3
033108: *(u64 *)(r10 - 0x2b0) = r1
033110: *(u64 *)(r10 - 0x240) = r1
033118: *(u64 *)(r10 - 0x250) = r1
033120: *(u64 *)(r10 - 0x260) = r6
033128: *(u64 *)(r10 - 0x258) = r9
033130: *(u64 *)(r10 - 0x268) = r9
033138: r1 = *(u64 *)(r10 - 0x700)
033140: *(u64 *)(r10 - 0x290) = r1
033148: *(u64 *)(r10 - 0x2a0) = r8
033150: r1 = *(u64 *)(r10 - 0x6f8)
033158: *(u64 *)(r10 - 0x2a8) = r1
033160: r1 = *(u64 *)(r10 - 0x708)
033168: *(u64 *)(r10 - 0x298) = r1
033170: *(u64 *)(r10 - 0x288) = r7
033178: *(u64 *)(r10 - 0x228) = r7
033180: *(u64 *)(r10 - 0x230) = r2
033188: r1 = *(u64 *)(r10 - 0x130)
033190: *(u64 *)(r10 - 0x238) = r1
033198: r6 = r10
0331a0: r6 += -0x3e4
0331a8: *(u64 *)(r10 - 0x278) = r6
0331b0: r1 = r10
0331b8: r1 += -0x58
0331c0: r2 = r10
0331c8: r2 += -0x2b8
0331d0: call 0x20a1 ; call 0x436e0 / window 370
0331d8: r1 = r10
0331e0: r1 += -0x160
0331e8: w2 = *(u32 *)(r10 - 0x58)
0331f0: if r2 == 0x16 goto +0x1 ; branch 0x33200
0331f8: goto +0x16 ; branch 0x332b0
033200: w8 = *(u32 *)(r10 - 0x4c)
033208: w7 = *(u32 *)(r10 - 0x50)
033210: call -0x55de ; call 0x8328 / window 199
033218: r1 = r10
033220: r1 += -0x148
033228: call -0x55e1 ; call 0x8328 / window 199
033230: r1 = 0x9a8bc ll ; data b'Auth type: Metadataprogram/src/processor/resize/mod.rsprogram/src/processor/state/mod.rsprogram/src/'
033240: if r8 == 0x1 goto +0x33 ; branch 0x333e0
033248: if r8 == 0x3 goto +0x30 ; branch 0x333d0
033250: r1 = 0x9e
033258: if r8 != 0x2 goto +0x5 ; branch 0x33288
033260: r1 = 0x9a8ab ll ; data b'Auth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.rsprogram/src/processor/state/m'
033270: r2 = 0x11
033278: call -0x1 ; external sol_log_
033280: r1 = 0x91
033288: r2 = *(u64 *)(r10 - 0x6f0)
033290: *(u32 *)(r2 + 0x4) = w1
033298: r1 = 0x0
0332a0: *(u32 *)(r2 + 0x0) = w1
0332a8: goto +0x1b ; branch 0x33388
0332b0: r3 = *(u64 *)(r10 - 0x54)
0332b8: w4 = *(u32 *)(r10 - 0x4c)
0332c0: r5 = *(u64 *)(r10 - 0x48)
0332c8: r0 = *(u64 *)(r10 - 0x6f0)
0332d0: *(u64 *)(r0 + 0x10) = r5
0332d8: r5 = *(u64 *)(r10 - 0x40)
0332e0: *(u64 *)(r0 + 0x18) = r5
0332e8: *(u32 *)(r0 + 0xc) = w4
0332f0: *(u64 *)(r0 + 0x4) = r3
0332f8: *(u32 *)(r0 + 0x0) = w2
033300: call -0x55fc ; call 0x8328 / window 199
033308: r1 = r10
033310: r1 += -0x148
033318: call -0x55ff ; call 0x8328 / window 199
033320: goto +0xc ; branch 0x33388
033328: w2 = *(u8 *)(r10 - 0x2b4)
033330: w3 = *(u32 *)(r10 - 0x29c)
033338: r4 = *(u64 *)(r10 - 0x6f0)
033340: *(u32 *)(r4 + 0x1c) = w3
033348: r3 = *(u64 *)(r10 - 0x2a3)
033350: *(u64 *)(r4 + 0x15) = r3
033358: r3 = *(u64 *)(r10 - 0x2ab)
033360: *(u64 *)(r4 + 0xd) = r3
033368: r3 = *(u64 *)(r10 - 0x2b3)
033370: *(u64 *)(r4 + 0x5) = r3
033378: *(u8 *)(r4 + 0x4) = w2
033380: *(u32 *)(r4 + 0x0) = w1
033388: r1 = r10
033390: r1 += -0x3a0
033398: call -0x6060 ; call 0x30a0 / window 59
0333a0: goto -0x1ab ; branch 0x32650
0333a8: r1 = 0xa800000000 ll
0333b8: r2 = *(u64 *)(r10 - 0x6f0)
0333c0: *(u64 *)(r2 + 0x0) = r1
0333c8: goto -0x1b0 ; branch 0x32650
0333d0: r1 = 0x9a898 ll ; data b'Auth type: DelegateAuth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.rsprogram/sr'
0333e0: r2 = 0x13
0333e8: call -0x1 ; external sol_log_
0333f0: r1 = 0xb7
0333f8: if r7 == 0x0 goto +0x9 ; branch 0x33448
033400: if r7 == 0x1 goto +0xb ; branch 0x33460
033408: if r7 == 0x3 goto +0xe ; branch 0x33480
033410: if r7 == 0x4 goto +0x11 ; branch 0x334a0
033418: if r7 == 0x5 goto +0x14 ; branch 0x334c0
033420: if r7 == 0x6 goto +0x17 ; branch 0x334e0
033428: if r7 == 0x7 goto +0x1a ; branch 0x33500
033430: if r7 != 0x8 goto -0x36 ; branch 0x33288
033438: w2 = *(u32 *)(r10 - 0x6c8)
033440: goto +0x2a ; branch 0x33598
033448: w2 = *(u32 *)(r10 - 0x6c8)
033450: if r2 == 0x2 goto +0x2d ; branch 0x335c0
033458: goto -0x3b ; branch 0x33288
033460: r7 = 0x6
033468: w2 = *(u32 *)(r10 - 0x6c8)
033470: if r2 == 0x3 goto +0x2f ; branch 0x335f0
033478: goto -0x3f ; branch 0x33288
033480: r7 = 0x6
033488: w2 = *(u32 *)(r10 - 0x6c8)
033490: if r2 == 0x4 goto +0x2b ; branch 0x335f0
033498: goto -0x43 ; branch 0x33288
0334a0: w2 = *(u32 *)(r10 - 0x6c8)
0334a8: if r2 == 0x0 goto +0xe ; branch 0x33520
0334b0: if r2 == 0x5 goto +0x1c ; branch 0x33598
0334b8: goto -0x47 ; branch 0x33288
0334c0: r7 = 0x6
0334c8: w2 = *(u32 *)(r10 - 0x6c8)
0334d0: if r2 == 0x6 goto +0x23 ; branch 0x335f0
0334d8: goto -0x4b ; branch 0x33288
0334e0: r7 = 0x6
0334e8: w2 = *(u32 *)(r10 - 0x6c8)
0334f0: if r2 == 0x7 goto +0x1f ; branch 0x335f0
0334f8: goto -0x4f ; branch 0x33288
033500: r7 = 0x6
033508: w2 = *(u32 *)(r10 - 0x6c8)
033510: if r2 == 0x8 goto +0x1b ; branch 0x335f0
033518: goto -0x53 ; branch 0x33288
033520: w3 = *(u8 *)(r10 - 0x6c0)
033528: if r3 != 0x0 goto -0x55 ; branch 0x33288
033530: r3 = *(u64 *)(r10 - 0x690)
033538: if r3 != 0x0 goto -0x57 ; branch 0x33288
033540: w3 = *(u8 *)(r10 - 0x630)
033548: if r3 != 0x2 goto -0x59 ; branch 0x33288
033550: w3 = *(u8 *)(r10 - 0x62f)
033558: if r3 != 0x2 goto -0x5b ; branch 0x33288
033560: w3 = *(u32 *)(r10 - 0x62c)
033568: if r3 != 0x0 goto -0x5d ; branch 0x33288
033570: w3 = *(u32 *)(r10 - 0x600)
033578: if r3 != 0x0 goto -0x5f ; branch 0x33288
033580: w3 = *(u32 *)(r10 - 0x5e8)
033588: if r3 == 0x0 goto +0x1 ; branch 0x33598
033590: goto -0x62 ; branch 0x33288
033598: r1 = r2
0335a0: if r1 == 0x1 goto +0x6 ; branch 0x335d8
0335a8: r7 = 0x6
0335b0: if r1 == 0x2 goto +0x1 ; branch 0x335c0
0335b8: goto +0x6 ; branch 0x335f0
0335c0: r1 = r10
0335c8: r1 += -0x69c
0335d0: goto +0x2 ; branch 0x335e8
0335d8: r1 = r10
0335e0: r1 += -0x5a4
0335e8: w7 = *(u32 *)(r1 + 0x0)
0335f0: w9 = *(u32 *)(r10 - 0x334)
0335f8: if r9 == 0x6 goto +0x1 ; branch 0x33608
033600: goto +0x8 ; branch 0x33648
033608: r1 = r10
033610: r1 += -0x1b0
033618: r2 = *(u64 *)(r10 - 0x710)
033620: r3 = *(u64 *)(r10 - 0x720)
033628: call 0x45e0 ; call 0x56530 / window 453
033630: w1 = *(u32 *)(r10 - 0x1b0)
033638: if r1 != 0x16 goto +0xb ; branch 0x33698
033640: w9 = *(u32 *)(r10 - 0x1ac)
033648: r1 = r7
033650: r1 <<= 0x20
033658: r1 >>= 0x20
033660: if r1 == 0x6 goto +0x10 ; branch 0x336e8
033668: r2 = r9
033670: r9 = r7
033678: if r2 == r1 goto +0xd ; branch 0x336e8
033680: r1 = 0x8700000000 ll
033690: goto -0x13c ; branch 0x32cb8
033698: w2 = *(u32 *)(r10 - 0x1ac)
0336a0: r3 = *(u64 *)(r10 - 0x198)
0336a8: r4 = *(u64 *)(r10 - 0x6f0)
0336b0: *(u64 *)(r4 + 0x18) = r3
0336b8: r3 = *(u64 *)(r10 - 0x1a0)
0336c0: *(u64 *)(r4 + 0x10) = r3
0336c8: r3 = *(u64 *)(r10 - 0x1a8)
0336d0: *(u64 *)(r4 + 0x8) = r3
0336d8: *(u32 *)(r4 + 0x4) = w2
0336e0: goto -0x6d ; branch 0x33380
0336e8: r1 = 0xfffffffe ll
0336f8: r2 = r9
033700: r2 &= r1
033708: if r2 == 0x4 goto +0x64 ; branch 0x33a30
033710: r1 = r10
033718: r1 += -0x1b0
033720: r2 = r10
033728: r2 += -0x6c8
033730: r3 = 0x158
033738: call 0xcb0b ; call 0x98f98 / window 1246
033740: *(u32 *)(r10 - 0x334) = w9
033748: w1 = *(u32 *)(r10 - 0x528)
033750: *(u64 *)(r10 - 0x6f8) = r1
033758: w3 = *(u32 *)(r10 - 0x1b0)
033760: r1 = r10
033768: r1 += -0x1a8
033770: r8 = r10
033778: r8 += -0xe8
033780: r2 = r10
033788: r2 += -0xd0
033790: if r3 == 0x0 goto +0x3b ; branch 0x33970
033798: if r3 == 0x1 goto +0x3a ; branch 0x33970
0337a0: w1 = *(u32 *)(r10 - 0x1b0)
0337a8: r6 = r10
0337b0: r6 += -0x180
0337b8: if r1 == 0x0 goto +0x6 ; branch 0x337f0
0337c0: if r1 == 0x1 goto +0x5 ; branch 0x337f0
0337c8: if r1 == 0x4 goto +0x2 ; branch 0x337e0
0337d0: if r1 == 0x6 goto +0x1 ; branch 0x337e0
0337d8: goto +0x24 ; branch 0x33900
0337e0: r6 = r10
0337e8: r6 += -0x1a8
0337f0: r2 = *(u64 *)(r6 + 0x8)
0337f8: if r2 == 0x0 goto +0x20 ; branch 0x33900
033800: w1 = *(u8 *)(r10 - 0x337)
033808: if r1 == 0x0 goto +0x7f ; branch 0x33c08
033810: r1 = *(u64 *)(r10 - 0x728)
033818: r3 = *(u64 *)(r1 + 0x0)
033820: w1 = *(u8 *)(r1 + 0x28)
033828: r2 = 0x0
033830: *(u64 *)(r10 - 0x1000) = r2
033838: *(u64 *)(r10 - 0xff8) = r1
033840: r1 = r10
033848: r1 += -0x2b8
033850: r4 = r10
033858: r4 += -0x3e8
033860: r5 = r10
033868: r2 = r6
033870: call -0x4a56 ; call 0xe5c8 / window 262
033878: w7 = *(u32 *)(r10 - 0x2b8)
033880: if r7 == 0x16 goto +0x1 ; branch 0x33890
033888: goto +0xb4 ; branch 0x33e30
033890: r7 = r10
033898: r7 += -0x2b8
0338a0: r1 = r7
0338a8: r2 = r6
0338b0: call 0x61c6 ; call 0x646e8 / window 521
0338b8: r6 = r10
0338c0: r6 += -0x3a0
0338c8: r1 = r6
0338d0: call -0x6107 ; call 0x30a0 / window 59
0338d8: r1 = r6
0338e0: r2 = r7
0338e8: r3 = 0x68
0338f0: call 0xcad4 ; call 0x98f98 / window 1246
0338f8: w1 = *(u32 *)(r10 - 0x1b0)
033900: r4 = r1
033908: r2 = r10
033910: r2 += -0x117
033918: r3 = r10
033920: r3 += -0x118
033928: if r4 == 0x0 goto +0x65 ; branch 0x33c58
033930: if r4 == 0x1 goto +0x64 ; branch 0x33c58
033938: if r4 == 0x2 goto +0x5f ; branch 0x33c38
033940: if r4 == 0x3 goto +0x2 ; branch 0x33958
033948: if r4 == 0x7 goto +0x1 ; branch 0x33958
033950: goto +0xae ; branch 0x33ec8
033958: r2 = r10
033960: r2 += -0x1a8
033968: goto +0x7b ; branch 0x33d48
033970: w3 = *(u8 *)(r10 - 0x1a8)
033978: if r3 == 0x0 goto +0x8 ; branch 0x339c0
033980: r3 = *(u64 *)(r1 + 0x19)
033988: *(u64 *)(r6 + 0x18) = r3
033990: r3 = *(u64 *)(r1 + 0x11)
033998: *(u64 *)(r6 + 0x10) = r3
0339a0: r3 = *(u64 *)(r1 + 0x9)
0339a8: *(u64 *)(r6 + 0x8) = r3
0339b0: r1 = *(u64 *)(r1 + 0x1)
0339b8: *(u64 *)(r6 + 0x0) = r1
0339c0: w1 = *(u32 *)(r10 - 0xd0)
0339c8: r1 += -0x1
0339d0: r3 = 0x2
0339d8: if r3 > r1 goto +0x17 ; branch 0x33a98
0339e0: w1 = *(u32 *)(r10 - 0xe8)
0339e8: if r1 == 0x2 goto +0x1 ; branch 0x339f8
0339f0: goto -0x4b ; branch 0x337a0
0339f8: w1 = *(u32 *)(r10 - 0x2f0)
033a00: if r1 != 0x2 goto +0x43 ; branch 0x33c20
033a08: w1 = *(u32 *)(r8 + 0x8)
033a10: r2 = *(u64 *)(r8 + 0x10)
033a18: *(u64 *)(r10 - 0x2e8) = r2
033a20: *(u32 *)(r10 - 0x2f0) = w1
033a28: goto -0x52 ; branch 0x337a0
033a30: w1 = *(u32 *)(r10 - 0x2e0)
033a38: if r1 != 0x0 goto -0x66 ; branch 0x33710
033a40: w1 = *(u8 *)(r10 - 0x2dc)
033a48: if r1 == 0x0 goto -0x68 ; branch 0x33710
033a50: r3 = r10
033a58: r3 += -0x2e0
033a60: r1 = r10
033a68: r1 += -0x1b0
033a70: r2 = *(u64 *)(r10 - 0x738)
033a78: call -0x47b0 ; call 0xfd00 / window 278
033a80: w1 = *(u32 *)(r10 - 0x1b0)
033a88: if r1 != 0x16 goto +0x24 ; branch 0x33bb0
033a90: goto -0x71 ; branch 0x33710
033a98: r6 = r10
033aa0: r6 += -0x2b8
033aa8: r1 = r6
033ab0: call 0x5512 ; call 0x5e348 / window 480
033ab8: r7 = r10
033ac0: r7 += -0x58
033ac8: r1 = r7
033ad0: r2 = r6
033ad8: call -0x4682 ; call 0x106d0 / window 286
033ae0: r1 = r10
033ae8: r1 += -0x2b8
033af0: r6 = r10
033af8: r6 += -0x308
033b00: r2 = r7
033b08: r3 = r6
033b10: call -0x47b0 ; call 0xfd98 / window 279
033b18: w7 = *(u32 *)(r10 - 0x2b8)
033b20: if r7 != 0x16 goto +0x7 ; branch 0x33b60
033b28: r1 = *(u64 *)(r10 - 0x48)
033b30: *(u64 *)(r6 + 0x10) = r1
033b38: r1 = *(u64 *)(r10 - 0x50)
033b40: *(u64 *)(r6 + 0x8) = r1
033b48: r1 = *(u64 *)(r10 - 0x58)
033b50: *(u64 *)(r6 + 0x0) = r1
033b58: goto -0x30 ; branch 0x339e0
033b60: w1 = *(u32 *)(r10 - 0x29c)
033b68: *(u32 *)(r10 - 0x414) = w1
033b70: r1 = *(u64 *)(r10 - 0x2a4)
033b78: *(u64 *)(r10 - 0x41c) = r1
033b80: r1 = *(u64 *)(r10 - 0x2ac)
033b88: *(u64 *)(r10 - 0x424) = r1
033b90: r1 = *(u64 *)(r10 - 0x2b4)
033b98: *(u64 *)(r10 - 0x42c) = r1
033ba0: *(u32 *)(r10 - 0x430) = w7
033ba8: goto +0xaf ; branch 0x34128
033bb0: w2 = *(u32 *)(r10 - 0x194)
033bb8: r3 = *(u64 *)(r10 - 0x6f0)
033bc0: *(u32 *)(r3 + 0x1c) = w2
033bc8: r2 = *(u64 *)(r10 - 0x19c)
033bd0: *(u64 *)(r3 + 0x14) = r2
033bd8: r2 = *(u64 *)(r10 - 0x1a4)
033be0: *(u64 *)(r3 + 0xc) = r2
033be8: r2 = *(u64 *)(r10 - 0x1ac)
033bf0: *(u64 *)(r3 + 0x4) = r2
033bf8: *(u32 *)(r3 + 0x0) = w1
033c00: goto -0x110 ; branch 0x33388
033c08: r1 = 0x3b00000000 ll
033c18: goto +0x9f ; branch 0x34118
033c20: r1 = 0x6600000000 ll
033c30: goto +0x9c ; branch 0x34118
033c38: r2 = r10
033c40: r2 += -0x186
033c48: r3 = r10
033c50: r3 += -0x187
033c58: w3 = *(u8 *)(r3 + 0x0)
033c60: if r3 == 0x2 goto +0x7 ; branch 0x33ca0
033c68: if r3 != 0x0 goto +0x5 ; branch 0x33c98
033c70: w4 = *(u8 *)(r10 - 0x338)
033c78: if r4 != 0x1 goto +0x3 ; branch 0x33c98
033c80: r1 = 0x2a00000000 ll
033c90: goto +0x90 ; branch 0x34118
033c98: *(u8 *)(r10 - 0x338) = w3
033ca0: w2 = *(u8 *)(r2 + 0x0)
033ca8: if r2 == 0x2 goto +0x7 ; branch 0x33ce8
033cb0: if r2 == 0x0 goto +0x5 ; branch 0x33ce0
033cb8: w3 = *(u8 *)(r10 - 0x337)
033cc0: if r3 != 0x0 goto +0x3 ; branch 0x33ce0
033cc8: r1 = 0x4900000000 ll
033cd8: goto +0x87 ; branch 0x34118
033ce0: *(u8 *)(r10 - 0x337) = w2
033ce8: r2 = r1
033cf0: if r2 == 0x0 goto +0x8 ; branch 0x33d38
033cf8: if r2 == 0x1 goto +0x7 ; branch 0x33d38
033d00: if r2 == 0x2 goto +0x1 ; branch 0x33d10
033d08: goto +0x74 ; branch 0x340b0
033d10: w1 = *(u8 *)(r10 - 0x1a8)
033d18: if r1 == 0x0 goto +0x72 ; branch 0x340b0
033d20: r1 = 0xc100000000 ll
033d30: goto +0x7c ; branch 0x34118
033d38: r2 = r10
033d40: r2 += -0x114
033d48: w3 = *(u32 *)(r2 + 0x0)
033d50: if r3 == 0x0 goto +0x2e ; branch 0x33ec8
033d58: if r3 == 0x1 goto +0x23 ; branch 0x33e78
033d60: r6 = r10
033d68: r6 += -0x330
033d70: r7 = r10
033d78: r7 += -0x2b8
033d80: r1 = r7
033d88: call 0x545c ; call 0x5e070 / window 478
033d90: r8 = r10
033d98: r8 += -0x58
033da0: r1 = r8
033da8: r2 = r7
033db0: call -0x46f8 ; call 0x105f8 / window 285
033db8: r1 = r10
033dc0: r1 += -0x2b8
033dc8: r2 = 0x0
033dd0: r3 = r6
033dd8: r4 = r8
033de0: call -0x4d83 ; call 0xd1d0 / window 254
033de8: w7 = *(u32 *)(r10 - 0x2b8)
033df0: if r7 != 0x16 goto +0x7 ; branch 0x33e30
033df8: r2 = r10
033e00: r2 += -0x58
033e08: r1 = r6
033e10: r3 = 0x21
033e18: call 0xca2f ; call 0x98f98 / window 1246
033e20: w1 = *(u32 *)(r10 - 0x1b0)
033e28: goto +0x13 ; branch 0x33ec8
033e30: w1 = *(u32 *)(r10 - 0x29c)
033e38: *(u32 *)(r10 - 0x414) = w1
033e40: r1 = *(u64 *)(r10 - 0x2a4)
033e48: *(u64 *)(r10 - 0x41c) = r1
033e50: r1 = *(u64 *)(r10 - 0x2ac)
033e58: *(u64 *)(r10 - 0x424) = r1
033e60: r1 = *(u64 *)(r10 - 0x2b4)
033e68: *(u64 *)(r10 - 0x42c) = r1
033e70: goto +0x56 ; branch 0x34128
033e78: w2 = *(u8 *)(r10 - 0x330)
033e80: r3 = r2
033e88: r3 &= 0x3
033e90: if r3 == 0x0 goto +0x4 ; branch 0x33eb8
033e98: if r2 == 0x2 goto +0x5 ; branch 0x33ec8
033ea0: r1 = 0x7000000000 ll
033eb0: goto +0x4c ; branch 0x34118
033eb8: r2 = 0x2
033ec0: *(u8 *)(r10 - 0x330) = w2
033ec8: r1 <<= 0x20
033ed0: r1 >>= 0x20
033ed8: if r1 == 0x0 goto +0x7 ; branch 0x33f18
033ee0: if r1 == 0x1 goto +0x6 ; branch 0x33f18
033ee8: if r1 == 0x5 goto +0x2 ; branch 0x33f00
033ef0: if r1 == 0x8 goto +0x1 ; branch 0x33f00
033ef8: goto +0x36 ; branch 0x340b0
033f00: r2 = r10
033f08: r2 += -0x1a8
033f10: goto +0x2 ; branch 0x33f28
033f18: r2 = r10
033f20: r2 += -0xb0
033f28: w1 = *(u32 *)(r2 + 0x0)
033f30: r1 += -0x1
033f38: if r1 > 0x1 goto +0x2e ; branch 0x340b0
033f40: r9 &= -0x2
033f48: r9 <<= 0x20
033f50: r9 >>= 0x20
033f58: if r9 != 0x4 goto +0x8 ; branch 0x33fa0
033f60: r1 = *(u64 *)(r10 - 0x6f8)
033f68: if r1 == 0x0 goto +0x9 ; branch 0x33fb8
033f70: r1 = *(u64 *)(r10 - 0x6f8)
033f78: if r1 == 0x2 goto +0x1 ; branch 0x33f88
033f80: goto +0x30 ; branch 0x34108
033f88: r1 = 0x9400000000 ll
033f98: goto +0x2f ; branch 0x34118
033fa0: r1 = 0x8700000000 ll
033fb0: goto +0x2c ; branch 0x34118
033fb8: r6 = r10
033fc0: r6 += -0x2b8
033fc8: r1 = r6
033fd0: call 0x551a ; call 0x5e8a8 / window 483
033fd8: r1 = r10
033fe0: r1 += -0x58
033fe8: r2 = r6
033ff0: call -0x4707 ; call 0x107c0 / window 287
033ff8: r1 = 0x1
034000: w3 = *(u8 *)(r10 - 0x58)
034008: r2 = 0x1
034010: if r3 == 0x0 goto +0x9 ; branch 0x34060
034018: r2 = *(u64 *)(r10 - 0x3f)
034020: *(u64 *)(r10 - 0x2a0) = r2
034028: r2 = *(u64 *)(r10 - 0x47)
034030: *(u64 *)(r10 - 0x2a8) = r2
034038: r2 = *(u64 *)(r10 - 0x4f)
034040: *(u64 *)(r10 - 0x2b0) = r2
034048: r2 = *(u64 *)(r10 - 0x57)
034050: *(u64 *)(r10 - 0x2b8) = r2
034058: r2 = 0x0
034060: *(u8 *)(r10 - 0x2dc) = w1
034068: *(u32 *)(r10 - 0x2e0) = w2
034070: r1 = *(u64 *)(r10 - 0x2b8)
034078: *(u64 *)(r10 - 0x2db) = r1
034080: r1 = *(u64 *)(r10 - 0x2b0)
034088: *(u64 *)(r10 - 0x2d3) = r1
034090: r1 = *(u64 *)(r10 - 0x2a8)
034098: *(u64 *)(r10 - 0x2cb) = r1
0340a0: r1 = *(u64 *)(r10 - 0x2a0)
0340a8: *(u64 *)(r10 - 0x2c3) = r1
0340b0: r6 = r10
0340b8: r6 += -0x3e8
0340c0: r1 = r6
0340c8: call 0x4513 ; call 0x56968 / window 456
0340d0: r1 = r10
0340d8: r1 += -0x430
0340e0: r2 = r6
0340e8: r3 = *(u64 *)(r10 - 0x718)
0340f0: call 0x38d1 ; call 0x50780 / window 440
0340f8: w7 = *(u32 *)(r10 - 0x430)
034100: goto +0x4 ; branch 0x34128
034108: r1 = 0xad00000000 ll
034118: *(u64 *)(r10 - 0x430) = r1
034120: r7 = 0x0
034128: r1 = r10
034130: r1 += -0x1b0
034138: call -0x61b6 ; call 0x3390 / window 68
034140: r1 = r7
034148: r1 <<= 0x20
034150: r1 >>= 0x20
034158: if r1 == 0x16 goto +0x1 ; branch 0x34168
034160: goto +0x4 ; branch 0x34188
034168: r1 = 0x16
034170: r2 = *(u64 *)(r10 - 0x6f0)
034178: *(u32 *)(r2 + 0x0) = w1
034180: goto +0xa ; branch 0x341d8
034188: w1 = *(u32 *)(r10 - 0x414)
034190: r2 = *(u64 *)(r10 - 0x6f0)
034198: *(u32 *)(r2 + 0x1c) = w1
0341a0: r1 = *(u64 *)(r10 - 0x41c)
0341a8: *(u64 *)(r2 + 0x14) = r1
0341b0: r1 = *(u64 *)(r10 - 0x424)
0341b8: *(u64 *)(r2 + 0xc) = r1
0341c0: r1 = *(u64 *)(r10 - 0x42c)
0341c8: *(u64 *)(r2 + 0x4) = r1
0341d0: *(u32 *)(r2 + 0x0) = w7
0341d8: r1 = r10
0341e0: r1 += -0x3a0
0341e8: call -0x622a ; call 0x30a0 / window 59
0341f0: goto -0x372 ; branch 0x32668
