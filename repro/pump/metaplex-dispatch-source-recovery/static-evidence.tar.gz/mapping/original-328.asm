02c758: r7 = r5
02c760: *(u64 *)(r10 - 0x4e0) = r4
02c768: r6 = r1
02c770: r1 = *(u64 *)(r2 + 0x88)
02c778: *(u64 *)(r10 - 0x4d8) = r1
02c780: r1 = *(u64 *)(r2 + 0x80)
02c788: *(u64 *)(r10 - 0x4c0) = r1
02c790: r1 = *(u64 *)(r2 + 0x78)
02c798: *(u64 *)(r10 - 0x4b0) = r1
02c7a0: r1 = *(u64 *)(r2 + 0x70)
02c7a8: *(u64 *)(r10 - 0x488) = r1
02c7b0: r1 = *(u64 *)(r2 + 0x68)
02c7b8: *(u64 *)(r10 - 0x4c8) = r1
02c7c0: r9 = *(u64 *)(r2 + 0x60)
02c7c8: r1 = *(u64 *)(r2 + 0x58)
02c7d0: *(u64 *)(r10 - 0x500) = r1
02c7d8: r1 = *(u64 *)(r2 + 0x50)
02c7e0: *(u64 *)(r10 - 0x4f8) = r1
02c7e8: r1 = *(u64 *)(r2 + 0x40)
02c7f0: *(u64 *)(r10 - 0x4f0) = r1
02c7f8: r1 = *(u64 *)(r2 + 0x38)
02c800: *(u64 *)(r10 - 0x4e8) = r1
02c808: r1 = *(u64 *)(r2 + 0x0)
02c810: *(u64 *)(r10 - 0x4d0) = r1
02c818: r1 = *(u64 *)(r2 + 0x30)
02c820: *(u64 *)(r10 - 0x498) = r1
02c828: r1 = *(u64 *)(r2 + 0x28)
02c830: *(u64 *)(r10 - 0x4a0) = r1
02c838: r1 = *(u64 *)(r2 + 0x20)
02c840: *(u64 *)(r10 - 0x4a8) = r1
02c848: r1 = *(u64 *)(r2 + 0x18)
02c850: *(u64 *)(r10 - 0x480) = r1
02c858: r1 = *(u64 *)(r2 + 0x10)
02c860: *(u64 *)(r10 - 0x4b8) = r1
02c868: r3 = *(u64 *)(r2 + 0x48)
02c870: r8 = *(u64 *)(r2 + 0x8)
02c878: r1 = r10
02c880: r1 += -0x230
02c888: *(u64 *)(r10 - 0x490) = r3
02c890: r2 = r3
02c898: r3 = r8
02c8a0: call 0x38a0 ; call 0x48da8 / window 427
02c8a8: w1 = *(u32 *)(r10 - 0x230)
02c8b0: if r1 != 0x16 goto +0x17 ; branch 0x2c970
02c8b8: *(u64 *)(r10 - 0x508) = r8
02c8c0: r1 = *(u64 *)(r7 - 0xff8)
02c8c8: *(u64 *)(r10 - 0x510) = r1
02c8d0: r7 = *(u64 *)(r7 - 0x1000)
02c8d8: r1 = r10
02c8e0: r1 += -0x230
02c8e8: r2 = r9
02c8f0: call 0x36d9 ; call 0x47fc0 / window 419
02c8f8: w8 = *(u32 *)(r10 - 0x128)
02c900: if r8 != 0x2 goto +0x1b ; branch 0x2c9e0
02c908: r1 = *(u64 *)(r10 - 0x218)
02c910: *(u64 *)(r10 - 0x320) = r1
02c918: r2 = *(u64 *)(r10 - 0x220)
02c920: *(u64 *)(r10 - 0x328) = r2
02c928: r3 = *(u64 *)(r10 - 0x228)
02c930: *(u64 *)(r10 - 0x330) = r3
02c938: r4 = *(u64 *)(r10 - 0x230)
02c940: *(u64 *)(r10 - 0x338) = r4
02c948: *(u64 *)(r6 + 0x18) = r1
02c950: *(u64 *)(r6 + 0x10) = r2
02c958: *(u64 *)(r6 + 0x8) = r3
02c960: *(u64 *)(r6 + 0x0) = r4
02c968: goto +0xc3 ; branch 0x2cf88
02c970: w2 = *(u32 *)(r10 - 0x214)
02c978: *(u32 *)(r10 - 0x450) = w2
02c980: r3 = *(u64 *)(r10 - 0x21c)
02c988: *(u64 *)(r10 - 0x458) = r3
02c990: r4 = *(u64 *)(r10 - 0x224)
02c998: *(u64 *)(r10 - 0x460) = r4
02c9a0: r5 = *(u64 *)(r10 - 0x22c)
02c9a8: *(u64 *)(r10 - 0x468) = r5
02c9b0: *(u32 *)(r6 + 0x1c) = w2
02c9b8: *(u64 *)(r6 + 0x14) = r3
02c9c0: *(u64 *)(r6 + 0xc) = r4
02c9c8: *(u64 *)(r6 + 0x4) = r5
02c9d0: *(u32 *)(r6 + 0x0) = w1
02c9d8: goto +0xb5 ; branch 0x2cf88
02c9e0: *(u64 *)(r10 - 0x518) = r7
02c9e8: *(u64 *)(r10 - 0x520) = r9
02c9f0: r7 = r10
02c9f8: r7 += -0x338
02ca00: r2 = r10
02ca08: r2 += -0x230
02ca10: r1 = r7
02ca18: r3 = 0x108
02ca20: call 0xd8ae ; call 0x98f98 / window 1246
02ca28: r1 = r10
02ca30: r1 += -0x35c
02ca38: r2 = r10
02ca40: r2 += -0x124
02ca48: r3 = 0x24
02ca50: call 0xd8a8 ; call 0x98f98 / window 1246
02ca58: r1 = r10
02ca60: r1 += -0x468
02ca68: r2 = r7
02ca70: r3 = 0x108
02ca78: call 0xd8a3 ; call 0x98f98 / window 1246
02ca80: *(u32 *)(r10 - 0x360) = w8
02ca88: r9 = 0x0
02ca90: w7 = *(u32 *)(r10 - 0x3b4)
02ca98: if r7 == 0x6 goto +0x1 ; branch 0x2caa8
02caa0: r9 = r7
02caa8: r8 = *(u64 *)(r10 - 0x480)
02cab0: r1 = r8
02cab8: call 0xb0e4 ; call 0x851e0 / window 981
02cac0: r3 = *(u64 *)(r10 - 0x508)
02cac8: if r0 != 0x0 goto +0x11 ; branch 0x2cb58
02cad0: r1 = r10
02cad8: r1 += -0x230
02cae0: r2 = r8
02cae8: r4 = r9
02caf0: call 0x504f ; call 0x54d70 / window 449
02caf8: w1 = *(u32 *)(r10 - 0x230)
02cb00: if r1 == 0x2 goto +0x1 ; branch 0x2cb10
02cb08: goto +0x27 ; branch 0x2cc48
02cb10: r1 = *(u64 *)(r10 - 0x210)
02cb18: *(u64 *)(r10 - 0x31c) = r1
02cb20: r2 = *(u64 *)(r10 - 0x218)
02cb28: *(u64 *)(r10 - 0x324) = r2
02cb30: r3 = *(u64 *)(r10 - 0x220)
02cb38: *(u64 *)(r10 - 0x32c) = r3
02cb40: r4 = *(u64 *)(r10 - 0x228)
02cb48: *(u64 *)(r10 - 0x334) = r4
02cb50: goto +0x4c ; branch 0x2cdb8
02cb58: w1 = *(u8 *)(r8 + 0x28)
02cb60: if r1 == 0x0 goto +0x31 ; branch 0x2ccf0
02cb68: r1 = 0x0
02cb70: *(u64 *)(r10 - 0xff0) = r1
02cb78: r1 = *(u64 *)(r10 - 0x488)
02cb80: *(u64 *)(r10 - 0xfe0) = r1
02cb88: *(u64 *)(r10 - 0xff8) = r9
02cb90: r1 = *(u64 *)(r10 - 0x490)
02cb98: *(u64 *)(r10 - 0x1000) = r1
02cba0: r1 = r10
02cba8: r1 += -0x230
02cbb0: r5 = r10
02cbb8: r2 = r8
02cbc0: r4 = *(u64 *)(r10 - 0x498)
02cbc8: call 0x4e3e ; call 0x53dc0 / window 448
02cbd0: w1 = *(u32 *)(r10 - 0x230)
02cbd8: if r1 == 0x16 goto +0x11 ; branch 0x2cc68
02cbe0: w2 = *(u32 *)(r10 - 0x214)
02cbe8: *(u32 *)(r10 - 0x320) = w2
02cbf0: r3 = *(u64 *)(r10 - 0x21c)
02cbf8: *(u64 *)(r10 - 0x328) = r3
02cc00: r4 = *(u64 *)(r10 - 0x224)
02cc08: *(u64 *)(r10 - 0x330) = r4
02cc10: r5 = *(u64 *)(r10 - 0x22c)
02cc18: *(u64 *)(r10 - 0x338) = r5
02cc20: *(u32 *)(r6 + 0x1c) = w2
02cc28: *(u64 *)(r6 + 0x14) = r3
02cc30: *(u64 *)(r6 + 0xc) = r4
02cc38: *(u64 *)(r6 + 0x4) = r5
02cc40: goto +0x64 ; branch 0x2cf68
02cc48: w1 = *(u8 *)(r10 - 0x200)
02cc50: if r1 != 0x0 goto +0x31 ; branch 0x2cde0
02cc58: r1 = *(u64 *)(r10 - 0x208)
02cc60: if r1 > 0x1 goto +0x2f ; branch 0x2cde0
02cc68: r8 = *(u64 *)(r10 - 0x4a0)
02cc70: r1 = r8
02cc78: call 0xb0ac ; call 0x851e0 / window 981
02cc80: if r0 != 0x0 goto +0x1 ; branch 0x2cc90
02cc88: goto +0xf ; branch 0x2cd08
02cc90: r1 = r10
02cc98: r1 += -0x230
02cca0: r8 = *(u64 *)(r10 - 0x480)
02cca8: r2 = r8
02ccb0: call 0x9584 ; call 0x778d8 / window 781
02ccb8: w1 = *(u32 *)(r10 - 0x230)
02ccc0: if r1 != 0x16 goto +0x27 ; branch 0x2ce00
02ccc8: r1 = *(u64 *)(r10 - 0x228)
02ccd0: if r1 == 0x0 goto +0x9c ; branch 0x2d1b8
02ccd8: r1 = 0xa000000000 ll
02cce8: goto +0x20 ; branch 0x2cdf0
02ccf0: r1 = 0x8600000000 ll
02cd00: goto +0x1d ; branch 0x2cdf0
02cd08: *(u64 *)(r10 - 0xff8) = r9
02cd10: r1 = 0x1
02cd18: *(u64 *)(r10 - 0xff0) = r1
02cd20: r1 = *(u64 *)(r10 - 0x488)
02cd28: *(u64 *)(r10 - 0x1000) = r1
02cd30: r1 = r10
02cd38: r1 += -0x230
02cd40: r5 = r10
02cd48: r2 = *(u64 *)(r10 - 0x480)
02cd50: r3 = r8
02cd58: r4 = *(u64 *)(r10 - 0x4a8)
02cd60: call 0x512a ; call 0x556b8 / window 450
02cd68: w1 = *(u32 *)(r10 - 0x1e8)
02cd70: if r1 != 0x2 goto +0x1c ; branch 0x2ce58
02cd78: r1 = *(u64 *)(r10 - 0x218)
02cd80: *(u64 *)(r10 - 0x320) = r1
02cd88: r2 = *(u64 *)(r10 - 0x220)
02cd90: *(u64 *)(r10 - 0x328) = r2
02cd98: r3 = *(u64 *)(r10 - 0x228)
02cda0: *(u64 *)(r10 - 0x330) = r3
02cda8: r4 = *(u64 *)(r10 - 0x230)
02cdb0: *(u64 *)(r10 - 0x338) = r4
02cdb8: *(u64 *)(r6 + 0x18) = r1
02cdc0: *(u64 *)(r6 + 0x10) = r2
02cdc8: *(u64 *)(r6 + 0x8) = r3
02cdd0: *(u64 *)(r6 + 0x0) = r4
02cdd8: goto +0x32 ; branch 0x2cf70
02cde0: r1 = 0x8800000000 ll
02cdf0: *(u64 *)(r6 + 0x0) = r1
02cdf8: goto +0x2e ; branch 0x2cf70
02ce00: r2 = *(u64 *)(r10 - 0x220)
02ce08: *(u64 *)(r10 - 0x338) = r2
02ce10: r3 = *(u64 *)(r10 - 0x218)
02ce18: *(u64 *)(r10 - 0x330) = r3
02ce20: w4 = *(u32 *)(r10 - 0x22c)
02ce28: r5 = *(u64 *)(r10 - 0x228)
02ce30: *(u64 *)(r6 + 0x18) = r3
02ce38: *(u64 *)(r6 + 0x10) = r2
02ce40: *(u64 *)(r6 + 0x8) = r5
02ce48: *(u32 *)(r6 + 0x4) = w4
02ce50: goto +0x22 ; branch 0x2cf68
02ce58: r1 = *(u64 *)(r10 - 0x1a4)
02ce60: *(u64 *)(r10 - 0x30) = r1
02ce68: r1 = *(u64 *)(r10 - 0x19c)
02ce70: *(u64 *)(r10 - 0x28) = r1
02ce78: r1 = *(u64 *)(r10 - 0x194)
02ce80: *(u64 *)(r10 - 0x20) = r1
02ce88: r1 = *(u64 *)(r10 - 0x18c)
02ce90: *(u64 *)(r10 - 0x18) = r1
02ce98: r8 = *(u64 *)(r10 - 0x480)
02cea0: if r7 != 0x4 goto +0x11 ; branch 0x2cf30
02cea8: w1 = *(u32 *)(r10 - 0x1a8)
02ceb0: if r1 == 0x1 goto +0x1 ; branch 0x2cec0
02ceb8: goto +0xe ; branch 0x2cf30
02cec0: r1 = *(u64 *)(r10 - 0x18)
02cec8: *(u64 *)(r10 - 0x218) = r1
02ced0: r1 = *(u64 *)(r10 - 0x20)
02ced8: *(u64 *)(r10 - 0x220) = r1
02cee0: r1 = *(u64 *)(r10 - 0x28)
02cee8: *(u64 *)(r10 - 0x228) = r1
02cef0: r1 = *(u64 *)(r10 - 0x30)
02cef8: *(u64 *)(r10 - 0x230) = r1
02cf00: r1 = *(u64 *)(r10 - 0x4b8)
02cf08: r2 = *(u64 *)(r1 + 0x0)
02cf10: r1 = r10
02cf18: r1 += -0x230
02cf20: call -0x5443 ; call 0x2d10 / window 44
02cf28: if r0 != 0x0 goto +0xb3 ; branch 0x2d4c8
02cf30: r1 = *(u64 *)(r10 - 0x4b0)
02cf38: r2 = 0x9f008 ll ; data b'\x00\x00\x00\x00h\x99\t\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00D\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00\x81\x00\x00\x00F\x00\x00\x00\x00\x00\x00\x00\xef\xa6\t\x00,\x00\x00\x00\x00\x00\x00\x00\x96\x00\x00\x00'
02cf48: call -0x544f ; call 0x2cd8 / window 42
02cf50: if r0 != 0x0 goto +0x1 ; branch 0x2cf60
02cf58: goto +0x6 ; branch 0x2cf90
02cf60: r1 = 0x6
02cf68: *(u32 *)(r6 + 0x0) = w1
02cf70: r1 = r10
02cf78: r1 += -0x420
02cf80: call -0x53dd ; call 0x30a0 / window 59
02cf88: exit
02cf90: r1 = *(u64 *)(r10 - 0x4c0)
02cf98: r2 = 0x9ed70 ll ; data b'\x00\x00\x00\x00\xc8\x9a\t\x00\x00\x00\x00\x00\x18\xa4\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00H\x9a\t\x00\x00\x00\x00\x00:\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00`\xa4\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00\x86\xa4\t\x00)\x00\x00\x00'
02cfa8: call -0x545b ; call 0x2cd8 / window 42
02cfb0: if r0 != 0x0 goto -0xb ; branch 0x2cf60
02cfb8: r2 = r9
02cfc0: r2 <<= 0x20
02cfc8: r2 >>= 0x20
02cfd0: r3 = *(u64 *)(r10 - 0x4b8)
02cfd8: r7 = *(u64 *)(r10 - 0x4c8)
02cfe0: if r2 == 0x0 goto +0x2e ; branch 0x2d158
02cfe8: if r2 == 0x4 goto +0x1 ; branch 0x2cff8
02cff0: goto +0xf5 ; branch 0x2d7a0
02cff8: r7 = *(u64 *)(r10 - 0x4d0)
02d000: if r7 == 0x0 goto +0x16d ; branch 0x2db70
02d008: r1 = *(u64 *)(r10 - 0x4a0)
02d010: r3 = *(u64 *)(r1 + 0x0)
02d018: r2 = *(u64 *)(r8 + 0x0)
02d020: r1 = r10
02d028: r1 += -0x230
02d030: call -0x37d0 ; call 0x111b8 / window 294
02d038: r1 = *(u64 *)(r10 - 0x218)
02d040: *(u64 *)(r10 - 0x320) = r1
02d048: r1 = *(u64 *)(r10 - 0x220)
02d050: *(u64 *)(r10 - 0x328) = r1
02d058: r1 = *(u64 *)(r10 - 0x228)
02d060: *(u64 *)(r10 - 0x330) = r1
02d068: r1 = *(u64 *)(r10 - 0x230)
02d070: *(u64 *)(r10 - 0x338) = r1
02d078: r2 = *(u64 *)(r7 + 0x0)
02d080: r1 = r10
02d088: r1 += -0x338
02d090: call 0x92cc ; call 0x766f8 / window 774
02d098: if r0 != 0x0 goto +0x1 ; branch 0x2d0a8
02d0a0: goto +0x15c ; branch 0x2db88
02d0a8: r1 = r7
02d0b0: call 0xb025 ; call 0x851e0 / window 981
02d0b8: if r0 != 0x0 goto +0x1 ; branch 0x2d0c8
02d0c0: goto +0x163 ; branch 0x2dbe0
02d0c8: r1 = *(u64 *)(r10 - 0x490)
02d0d0: *(u64 *)(r10 - 0xff8) = r1
02d0d8: r1 = *(u64 *)(r10 - 0x4d8)
02d0e0: *(u64 *)(r10 - 0xff0) = r1
02d0e8: r1 = *(u64 *)(r10 - 0x4a0)
02d0f0: *(u64 *)(r10 - 0x1000) = r1
02d0f8: r1 = r10
02d100: r1 += -0x230
02d108: r5 = r10
02d110: r2 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02d120: r3 = r7
02d128: r4 = r8
02d130: call 0x4705 ; call 0x50960 / window 441
02d138: w1 = *(u32 *)(r10 - 0x230)
02d140: if r1 != 0x16 goto +0x15b ; branch 0x2dc20
02d148: r7 = *(u64 *)(r10 - 0x4c8)
02d150: r3 = *(u64 *)(r10 - 0x4b8)
02d158: r2 = r10
02d160: r2 += -0x464
02d168: *(u64 *)(r10 - 0x230) = r2
02d170: r2 = r10
02d178: r2 += -0x230
02d180: r1 = r7
02d188: call -0x5497 ; call 0x2cd8 / window 42
02d190: if r0 != 0x0 goto +0x1 ; branch 0x2d1a0
02d198: goto +0xd7 ; branch 0x2d858
02d1a0: r1 = 0x700000000 ll
02d1b0: goto -0x79 ; branch 0x2cdf0
02d1b8: r1 = *(u64 *)(r10 - 0x488)
02d1c0: r5 = *(u64 *)(r1 + 0x0)
02d1c8: r4 = *(u64 *)(r8 + 0x0)
02d1d0: r1 = *(u64 *)(r10 - 0x4a8)
02d1d8: r3 = *(u64 *)(r1 + 0x0)
02d1e0: r7 = *(u64 *)(r10 - 0x490)
02d1e8: r2 = *(u64 *)(r7 + 0x0)
02d1f0: r1 = r10
02d1f8: r1 += -0x338
02d200: *(u64 *)(r10 - 0x528) = r1
02d208: call 0x7ad4 ; call 0x6a8b0 / window 591
02d210: r1 = r10
02d218: r1 += -0x100
02d220: *(u64 *)(r10 - 0x538) = r1
02d228: r2 = r7
02d230: call -0x454c ; call 0xa7d8 / window 217
02d238: r7 = r10
02d240: r7 += -0x90
02d248: r1 = r7
02d250: r2 = *(u64 *)(r10 - 0x4a8)
02d258: call -0x4551 ; call 0xa7d8 / window 217
02d260: r1 = r10
02d268: r1 += -0x60
02d270: *(u64 *)(r10 - 0x530) = r1
02d278: r2 = r8
02d280: call -0x4556 ; call 0xa7d8 / window 217
02d288: r1 = r10
02d290: r1 += -0x30
02d298: *(u64 *)(r10 - 0x4a8) = r1
02d2a0: r2 = *(u64 *)(r10 - 0x4a0)
02d2a8: call -0x455b ; call 0xa7d8 / window 217
02d2b0: r8 = r10
02d2b8: r8 += -0x230
02d2c0: r1 = r8
02d2c8: r2 = *(u64 *)(r10 - 0x538)
02d2d0: r3 = 0x30
02d2d8: call 0xd797 ; call 0x98f98 / window 1246
02d2e0: r1 = r10
02d2e8: r1 += -0x200
02d2f0: r2 = r7
02d2f8: r3 = 0x30
02d300: call 0xd792 ; call 0x98f98 / window 1246
02d308: r1 = r10
02d310: r1 += -0x1d0
02d318: r2 = *(u64 *)(r10 - 0x530)
02d320: r3 = 0x30
02d328: call 0xd78d ; call 0x98f98 / window 1246
02d330: r1 = r10
02d338: r1 += -0x1a0
02d340: r2 = *(u64 *)(r10 - 0x4a8)
02d348: r3 = 0x30
02d350: call 0xd788 ; call 0x98f98 / window 1246
02d358: r1 = r10
02d360: r1 += -0xb0
02d368: r2 = *(u64 *)(r10 - 0x528)
02d370: r3 = r8
02d378: r4 = 0x4
02d380: call 0xb223 ; call 0x864a0 / window 996
02d388: w1 = *(u32 *)(r10 - 0xb0)
02d390: if r1 == 0x16 goto +0x1 ; branch 0x2d3a0
02d398: goto +0x28 ; branch 0x2d4e0
02d3a0: r1 = r10
02d3a8: r1 += -0x230
02d3b0: call -0x53a8 ; call 0x3678 / window 77
02d3b8: r1 = r10
02d3c0: r1 += -0x338
02d3c8: call -0x5455 ; call 0x3128 / window 61
02d3d0: r8 = *(u64 *)(r10 - 0x4a0)
02d3d8: r4 = *(u64 *)(r8 + 0x0)
02d3e0: r1 = *(u64 *)(r10 - 0x480)
02d3e8: r3 = *(u64 *)(r1 + 0x0)
02d3f0: r1 = *(u64 *)(r10 - 0x488)
02d3f8: r2 = *(u64 *)(r1 + 0x0)
02d400: r1 = *(u64 *)(r10 - 0x498)
02d408: r1 = *(u64 *)(r1 + 0x0)
02d410: r5 = 0x0
02d418: *(u64 *)(r10 - 0xff0) = r5
02d420: r5 = 0x1
02d428: *(u64 *)(r10 - 0xfe8) = r5
02d430: r5 = 0x996b8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02d440: *(u64 *)(r10 - 0xff8) = r5
02d448: *(u64 *)(r10 - 0x1000) = r1
02d450: r1 = r10
02d458: r1 += -0x230
02d460: r5 = r10
02d468: call 0xa385 ; call 0x7f098 / window 864
02d470: r7 = *(u64 *)(r10 - 0x208)
02d478: if r7 != 0x0 goto +0x1d ; branch 0x2d568
02d480: r1 = *(u64 *)(r10 - 0x218)
02d488: *(u64 *)(r10 - 0xe8) = r1
02d490: r2 = *(u64 *)(r10 - 0x220)
02d498: *(u64 *)(r10 - 0xf0) = r2
02d4a0: r3 = *(u64 *)(r10 - 0x228)
02d4a8: *(u64 *)(r10 - 0xf8) = r3
02d4b0: r4 = *(u64 *)(r10 - 0x230)
02d4b8: *(u64 *)(r10 - 0x100) = r4
02d4c0: goto -0xe2 ; branch 0x2cdb8
02d4c8: r1 = 0xbc00000000 ll
02d4d8: goto -0xde ; branch 0x2cdf0
02d4e0: w2 = *(u32 *)(r10 - 0x94)
02d4e8: *(u32 *)(r10 - 0xb8) = w2
02d4f0: r3 = *(u64 *)(r10 - 0x9c)
02d4f8: *(u64 *)(r10 - 0xc0) = r3
02d500: r4 = *(u64 *)(r10 - 0xa4)
02d508: *(u64 *)(r10 - 0xc8) = r4
02d510: r5 = *(u64 *)(r10 - 0xac)
02d518: *(u64 *)(r10 - 0xd0) = r5
02d520: *(u32 *)(r6 + 0x1c) = w2
02d528: *(u64 *)(r6 + 0x14) = r3
02d530: *(u64 *)(r6 + 0xc) = r4
02d538: *(u64 *)(r6 + 0x4) = r5
02d540: *(u32 *)(r6 + 0x0) = w1
02d548: r1 = r10
02d550: r1 += -0x230
02d558: call -0x53dd ; call 0x3678 / window 77
02d560: goto +0x5a ; branch 0x2d838
02d568: r8 = r10
02d570: r8 += -0x100
02d578: r2 = r10
02d580: r2 += -0x230
02d588: r1 = r8
02d590: r3 = 0x28
02d598: call 0xd73f ; call 0x98f98 / window 1246
02d5a0: r1 = *(u64 *)(r10 - 0x200)
02d5a8: *(u64 *)(r10 - 0x308) = r1
02d5b0: r1 = *(u64 *)(r10 - 0x1f8)
02d5b8: *(u64 *)(r10 - 0x300) = r1
02d5c0: r1 = *(u64 *)(r10 - 0x1f0)
02d5c8: *(u64 *)(r10 - 0x2f8) = r1
02d5d0: r1 = *(u64 *)(r10 - 0x1e8)
02d5d8: *(u64 *)(r10 - 0x2f0) = r1
02d5e0: r1 = r10
02d5e8: r1 += -0x338
02d5f0: *(u64 *)(r10 - 0x4a8) = r1
02d5f8: r2 = r8
02d600: r3 = 0x28
02d608: call 0xd731 ; call 0x98f98 / window 1246
02d610: *(u64 *)(r10 - 0x310) = r7
02d618: r8 = r10
02d620: r8 += -0x90
02d628: r1 = r8
02d630: r2 = *(u64 *)(r10 - 0x480)
02d638: call -0x45cd ; call 0xa7d8 / window 217
02d640: r7 = r10
02d648: r7 += -0x60
02d650: r1 = r7
02d658: r2 = *(u64 *)(r10 - 0x4a0)
02d660: call -0x45d2 ; call 0xa7d8 / window 217
02d668: r1 = r10
02d670: r1 += -0x30
02d678: *(u64 *)(r10 - 0x530) = r1
02d680: r2 = *(u64 *)(r10 - 0x498)
02d688: call -0x45d7 ; call 0xa7d8 / window 217
02d690: r1 = r10
02d698: r1 += -0x230
02d6a0: *(u64 *)(r10 - 0x528) = r1
02d6a8: r2 = r8
02d6b0: r3 = 0x30
02d6b8: call 0xd71b ; call 0x98f98 / window 1246
02d6c0: r1 = r10
02d6c8: r1 += -0x200
02d6d0: r2 = r7
02d6d8: r3 = 0x30
02d6e0: call 0xd716 ; call 0x98f98 / window 1246
02d6e8: r1 = r10
02d6f0: r1 += -0x1d0
02d6f8: r2 = *(u64 *)(r10 - 0x530)
02d700: r3 = 0x30
02d708: call 0xd711 ; call 0x98f98 / window 1246
02d710: r1 = r10
02d718: r1 += -0xb0
02d720: r2 = *(u64 *)(r10 - 0x4a8)
02d728: r3 = *(u64 *)(r10 - 0x528)
02d730: r4 = 0x3
02d738: call 0xb1ac ; call 0x864a0 / window 996
02d740: w1 = *(u32 *)(r10 - 0xb0)
02d748: if r1 == 0x16 goto +0x1 ; branch 0x2d758
02d750: goto +0xc ; branch 0x2d7b8
02d758: r1 = r10
02d760: r1 += -0x230
02d768: call -0x5428 ; call 0x3630 / window 76
02d770: r1 = r10
02d778: r1 += -0x338
02d780: call -0x54cc ; call 0x3128 / window 61
02d788: r1 = *(u64 *)(r10 - 0x508)
02d790: r8 = *(u64 *)(r10 - 0x480)
02d798: goto -0x10e ; branch 0x2cf30
02d7a0: r1 = 0x8700000000 ll
02d7b0: goto -0x139 ; branch 0x2cdf0
02d7b8: w2 = *(u32 *)(r10 - 0x94)
02d7c0: *(u32 *)(r10 - 0xb8) = w2
02d7c8: r3 = *(u64 *)(r10 - 0x9c)
02d7d0: *(u64 *)(r10 - 0xc0) = r3
02d7d8: r4 = *(u64 *)(r10 - 0xa4)
02d7e0: *(u64 *)(r10 - 0xc8) = r4
02d7e8: r5 = *(u64 *)(r10 - 0xac)
02d7f0: *(u64 *)(r10 - 0xd0) = r5
02d7f8: *(u32 *)(r6 + 0x1c) = w2
02d800: *(u64 *)(r6 + 0x14) = r3
02d808: *(u64 *)(r6 + 0xc) = r4
02d810: *(u64 *)(r6 + 0x4) = r5
02d818: *(u32 *)(r6 + 0x0) = w1
02d820: r1 = r10
02d828: r1 += -0x230
02d830: call -0x5441 ; call 0x3630 / window 76
02d838: r1 = r10
02d840: r1 += -0x338
02d848: call -0x54e5 ; call 0x3128 / window 61
02d850: goto -0x11d ; branch 0x2cf70
02d858: r1 = *(u64 *)(r10 - 0x4d8)
02d860: *(u64 *)(r10 - 0x1c0) = r1
02d868: r1 = *(u64 *)(r10 - 0x488)
02d870: *(u64 *)(r10 - 0x1c8) = r1
02d878: r1 = *(u64 *)(r10 - 0x520)
02d880: *(u64 *)(r10 - 0x1d0) = r1
02d888: *(u64 *)(r10 - 0x1d8) = r7
02d890: r1 = *(u64 *)(r10 - 0x500)
02d898: *(u64 *)(r10 - 0x1e0) = r1
02d8a0: r1 = *(u64 *)(r10 - 0x4f8)
02d8a8: *(u64 *)(r10 - 0x1e8) = r1
02d8b0: r1 = *(u64 *)(r10 - 0x490)
02d8b8: *(u64 *)(r10 - 0x1f0) = r1
02d8c0: r1 = *(u64 *)(r10 - 0x498)
02d8c8: *(u64 *)(r10 - 0x1f8) = r1
02d8d0: r1 = *(u64 *)(r10 - 0x4f0)
02d8d8: *(u64 *)(r10 - 0x200) = r1
02d8e0: *(u64 *)(r10 - 0x208) = r8
02d8e8: r1 = *(u64 *)(r10 - 0x4e8)
02d8f0: *(u64 *)(r10 - 0x210) = r1
02d8f8: r7 = *(u64 *)(r10 - 0x4b8)
02d900: *(u64 *)(r10 - 0x218) = r7
02d908: r1 = *(u64 *)(r10 - 0x508)
02d910: *(u64 *)(r10 - 0x220) = r1
02d918: r1 = *(u64 *)(r10 - 0x510)
02d920: *(u64 *)(r10 - 0x228) = r1
02d928: r1 = *(u64 *)(r10 - 0x518)
02d930: *(u64 *)(r10 - 0x230) = r1
02d938: r1 = r10
02d940: r1 += -0x338
02d948: r3 = r10
02d950: r3 += -0x230
02d958: r2 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02d968: r4 = *(u64 *)(r10 - 0x4e0)
02d970: call 0x3725 ; call 0x492a0 / window 429
02d978: w1 = *(u32 *)(r10 - 0x338)
02d980: if r1 == 0x16 goto +0x1 ; branch 0x2d990
02d988: goto +0x42 ; branch 0x2dba0
02d990: r9 <<= 0x20
02d998: r9 >>= 0x20
02d9a0: if r9 == 0x4 goto +0x1 ; branch 0x2d9b0
02d9a8: goto +0x6c ; branch 0x2dd10
02d9b0: r1 = r10
02d9b8: r1 += -0x60
02d9c0: *(u64 *)(r10 - 0x490) = r1
02d9c8: r2 = r8
02d9d0: call -0x4640 ; call 0xa7d8 / window 217
02d9d8: r8 = r10
02d9e0: r8 += -0x30
02d9e8: r1 = r8
02d9f0: r2 = *(u64 *)(r10 - 0x4a0)
02d9f8: call -0x4645 ; call 0xa7d8 / window 217
02da00: r9 = r10
02da08: r9 += -0x338
02da10: r1 = r9
02da18: r2 = r7
02da20: call -0x464a ; call 0xa7d8 / window 217
02da28: r7 = r10
02da30: r7 += -0x230
02da38: r1 = r7
02da40: r2 = *(u64 *)(r10 - 0x488)
02da48: call -0x464f ; call 0xa7d8 / window 217
02da50: *(u64 *)(r10 - 0x1000) = r7
02da58: r1 = 0x0
02da60: *(u64 *)(r10 - 0xff8) = r1
02da68: r1 = r10
02da70: r1 += -0x90
02da78: r5 = r10
02da80: r2 = *(u64 *)(r10 - 0x490)
02da88: r3 = r8
02da90: r4 = r9
02da98: call 0x4679 ; call 0x50e68 / window 442
02daa0: w1 = *(u32 *)(r10 - 0x90)
02daa8: if r1 != 0x16 goto +0x37 ; branch 0x2dc68
02dab0: r8 = *(u64 *)(r10 - 0x4b8)
02dab8: r1 = r8
02dac0: call 0xaed5 ; call 0x85170 / window 980
02dac8: r7 = r0
02dad0: r2 = *(u64 *)(r8 + 0x10)
02dad8: r2 += 0x10
02dae0: r1 = r10
02dae8: r1 += -0x478
02daf0: r3 = 0x9f160 ll ; data b"\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x00/\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00/\xa8\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\xa8\t\x00\x0c\x00\x00\x00"
02db00: call -0x5457 ; call 0x3850 / window 86
02db08: r1 = *(u64 *)(r10 - 0x470)
02db10: r3 = *(u64 *)(r10 - 0x478)
02db18: r2 = *(u64 *)(r3 + 0x8)
02db20: r4 = 0x2a
02db28: if r4 > r2 goto +0x1 ; branch 0x2db38
02db30: goto +0x2f ; branch 0x2dcb0
02db38: r2 = 0xc800000000 ll
02db48: *(u64 *)(r6 + 0x0) = r2
02db50: r2 = *(u64 *)(r1 + 0x0)
02db58: r2 += 0x1
02db60: *(u64 *)(r1 + 0x0) = r2
02db68: goto -0x180 ; branch 0x2cf70
02db70: r1 = 0x9f00000000 ll
02db80: goto -0x1b3 ; branch 0x2cdf0
02db88: r1 = 0x9a00000000 ll
02db98: goto -0x1b6 ; branch 0x2cdf0
02dba0: w2 = *(u32 *)(r10 - 0x31c)
02dba8: *(u32 *)(r10 - 0x18) = w2
02dbb0: r3 = *(u64 *)(r10 - 0x324)
02dbb8: *(u64 *)(r10 - 0x20) = r3
02dbc0: r4 = *(u64 *)(r10 - 0x32c)
02dbc8: *(u64 *)(r10 - 0x28) = r4
02dbd0: r5 = *(u64 *)(r10 - 0x334)
02dbd8: goto +0xf ; branch 0x2dc58
02dbe0: r1 = r10
02dbe8: r1 += -0x230
02dbf0: r2 = r7
02dbf8: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02dc08: call -0x3bfc ; call 0xfc30 / window 275
02dc10: w1 = *(u32 *)(r10 - 0x230)
02dc18: if r1 == 0x16 goto -0x15b ; branch 0x2d148
02dc20: w2 = *(u32 *)(r10 - 0x214)
02dc28: *(u32 *)(r10 - 0x18) = w2
02dc30: r3 = *(u64 *)(r10 - 0x21c)
02dc38: *(u64 *)(r10 - 0x20) = r3
02dc40: r4 = *(u64 *)(r10 - 0x224)
02dc48: *(u64 *)(r10 - 0x28) = r4
02dc50: r5 = *(u64 *)(r10 - 0x22c)
02dc58: *(u64 *)(r10 - 0x30) = r5
02dc60: goto -0x209 ; branch 0x2cc20
02dc68: w2 = *(u32 *)(r10 - 0x74)
02dc70: *(u32 *)(r10 - 0xe8) = w2
02dc78: r3 = *(u64 *)(r10 - 0x7c)
02dc80: *(u64 *)(r10 - 0xf0) = r3
02dc88: r4 = *(u64 *)(r10 - 0x84)
02dc90: *(u64 *)(r10 - 0xf8) = r4
02dc98: r5 = *(u64 *)(r10 - 0x8c)
02dca0: *(u64 *)(r10 - 0x100) = r5
02dca8: goto -0x212 ; branch 0x2cc20
02dcb0: if r7 == 0x0 goto +0xf ; branch 0x2dd30
02dcb8: r7 += -0x1
02dcc0: if r2 > r7 goto +0x1 ; branch 0x2dcd0
02dcc8: goto +0x13 ; branch 0x2dd68
02dcd0: r2 = *(u64 *)(r3 + 0x0)
02dcd8: r2 += r7
02dce0: r3 = 0x4
02dce8: *(u8 *)(r2 + 0x0) = w3
02dcf0: r2 = *(u64 *)(r1 + 0x0)
02dcf8: r2 += 0x1
02dd00: *(u64 *)(r1 + 0x0) = r2
02dd08: r1 = *(u64 *)(r10 - 0x508)
02dd10: r1 = r6
02dd18: r2 = *(u64 *)(r10 - 0x508)
02dd20: call 0x367f ; call 0x49120 / window 428
02dd28: goto -0x1b8 ; branch 0x2cf70
02dd30: r1 = 0x9a280 ll ; data b'attempt to subtract with overflowprogram/src/assertions/metadata.rsprogram/src/assertions/misc.rs\x00\x00\x00'
02dd40: r2 = 0x21
02dd48: r3 = 0x9f178 ll ; data b"\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00/\xa8\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\xa8\t\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf4\x9d\t\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
02dd58: call 0xc4f7 ; call 0x90518 / window 1169
02dd60: call -0x1 ; external abort
02dd68: r1 = r7
02dd70: r3 = 0x9f190 ll ; data b"\x00\x00\x00\x00\x08\xa8\t\x00'\x00\x00\x00\x00\x00\x00\x005\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00/\xa8\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\xa8\t\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf4\x9d\t\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00L\xa8\t\x00\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00Q\xa8\t\x00*\x00\x00\x00"
02dd80: call 0xc51e ; call 0x90678 / window 1172
02dd88: call -0x1 ; external abort
