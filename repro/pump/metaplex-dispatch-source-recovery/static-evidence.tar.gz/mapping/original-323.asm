029bf0: r6 = r5
029bf8: r9 = r2
029c00: r8 = r1
029c08: r1 = r10
029c10: r1 += -0xb8
029c18: r2 = r3
029c20: r3 = r4
029c28: call 0x6ec8 ; call 0x61270 / window 492
029c30: r7 = *(u64 *)(r10 - 0x88)
029c38: if r7 != 0x0 goto +0x10 ; branch 0x29cc0
029c40: r1 = *(u64 *)(r10 - 0xa0)
029c48: *(u64 *)(r10 - 0x28) = r1
029c50: r2 = *(u64 *)(r10 - 0xa8)
029c58: *(u64 *)(r10 - 0x30) = r2
029c60: r3 = *(u64 *)(r10 - 0xb0)
029c68: *(u64 *)(r10 - 0x38) = r3
029c70: r4 = *(u64 *)(r10 - 0xb8)
029c78: *(u64 *)(r10 - 0x40) = r4
029c80: *(u64 *)(r8 + 0x18) = r1
029c88: *(u64 *)(r8 + 0x10) = r2
029c90: *(u64 *)(r8 + 0x8) = r3
029c98: *(u64 *)(r8 + 0x0) = r4
029ca0: r6 += 0x10
029ca8: r1 = r6
029cb0: call -0x4c92 ; call 0x3828 / window 85
029cb8: goto +0x2e ; branch 0x29e30
029cc0: *(u64 *)(r10 - 0x130) = r8
029cc8: r8 = r10
029cd0: r8 += -0x40
029cd8: r2 = r10
029ce0: r2 += -0xb8
029ce8: r1 = r8
029cf0: r3 = 0x30
029cf8: call 0xde53 ; call 0x98f98 / window 1246
029d00: *(u64 *)(r10 - 0x138) = r9
029d08: r9 = r10
029d10: r9 += -0x128
029d18: r2 = r10
029d20: r2 += -0x80
029d28: r1 = r9
029d30: r3 = 0x40
029d38: call 0xde4b ; call 0x98f98 / window 1246
029d40: *(u64 *)(r10 - 0x140) = r6
029d48: r6 = r10
029d50: r6 += -0xe8
029d58: r1 = r6
029d60: r2 = r8
029d68: r3 = 0x30
029d70: call 0xde44 ; call 0x98f98 / window 1246
029d78: r8 = r10
029d80: r8 += -0xb8
029d88: r1 = r8
029d90: r2 = r6
029d98: r3 = 0x30
029da0: call 0xde3e ; call 0x98f98 / window 1246
029da8: *(u64 *)(r10 - 0x88) = r7
029db0: r1 = r10
029db8: r1 += -0x80
029dc0: r2 = r9
029dc8: r3 = 0x40
029dd0: call 0xde38 ; call 0x98f98 / window 1246
029dd8: r6 = r10
029de0: r6 += -0x40
029de8: r1 = r6
029df0: r2 = *(u64 *)(r10 - 0x140)
029df8: r3 = 0x40
029e00: call 0xde32 ; call 0x98f98 / window 1246
029e08: r1 = *(u64 *)(r10 - 0x130)
029e10: r2 = *(u64 *)(r10 - 0x138)
029e18: r3 = r8
029e20: r4 = r6
029e28: call 0x1 ; call 0x29e38 / window 324
029e30: exit
