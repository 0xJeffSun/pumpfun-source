01d420: r7 = r5
01d428: r9 = r2
01d430: r6 = r1
01d438: r1 = r10
01d440: r1 += -0x2f0
01d448: r2 = r3
01d450: r3 = r4
01d458: call 0x882a ; call 0x615b0 / window 493
01d460: r0 = *(u64 *)(r10 - 0x2d8)
01d468: r2 = *(u64 *)(r10 - 0x2e0)
01d470: r4 = *(u64 *)(r10 - 0x2e8)
01d478: r3 = *(u64 *)(r10 - 0x2f0)
01d480: r1 = *(u64 *)(r10 - 0x2b8)
01d488: if r1 != 0x0 goto +0x6 ; branch 0x1d4c0
01d490: *(u64 *)(r6 + 0x18) = r0
01d498: *(u64 *)(r6 + 0x10) = r2
01d4a0: *(u64 *)(r6 + 0x8) = r4
01d4a8: *(u64 *)(r6 + 0x0) = r3
01d4b0: r1 = r7
01d4b8: goto +0x10c ; branch 0x1dd20
01d4c0: *(u64 *)(r10 - 0x568) = r2
01d4c8: *(u64 *)(r10 - 0x560) = r1
01d4d0: *(u64 *)(r10 - 0x530) = r6
01d4d8: r5 = 0x1
01d4e0: r8 = *(u64 *)(r10 - 0x288)
01d4e8: r1 = *(u64 *)(r10 - 0x290)
01d4f0: *(u64 *)(r10 - 0x558) = r1
01d4f8: r1 = *(u64 *)(r10 - 0x298)
01d500: *(u64 *)(r10 - 0x540) = r1
01d508: r1 = *(u64 *)(r10 - 0x2a0)
01d510: *(u64 *)(r10 - 0x548) = r1
01d518: r1 = *(u64 *)(r10 - 0x2a8)
01d520: *(u64 *)(r10 - 0x550) = r1
01d528: r6 = *(u64 *)(r10 - 0x2b0)
01d530: r1 = *(u64 *)(r10 - 0x2c0)
01d538: *(u64 *)(r10 - 0x570) = r1
01d540: r1 = *(u64 *)(r10 - 0x2c8)
01d548: *(u64 *)(r10 - 0x578) = r1
01d550: r1 = *(u64 *)(r10 - 0x2d0)
01d558: *(u64 *)(r10 - 0x538) = r1
01d560: w2 = *(u32 *)(r7 + 0x0)
01d568: r1 = r7
01d570: if r2 == 0x0 goto +0xd1 ; branch 0x1dc00
01d578: if r2 == 0x1 goto +0x10 ; branch 0x1d600
01d580: if r2 == 0x2 goto +0xd ; branch 0x1d5f0
01d588: if r2 == 0x3 goto +0x4d ; branch 0x1d7f8
01d590: if r2 == 0x4 goto +0x17 ; branch 0x1d650
01d598: if r2 == 0x5 goto +0x4d ; branch 0x1d808
01d5a0: if r2 == 0x6 goto +0x1c ; branch 0x1d688
01d5a8: if r2 == 0x7 goto +0xbf ; branch 0x1dba8
01d5b0: if r2 == 0x8 goto +0xc8 ; branch 0x1dbf8
01d5b8: if r2 == 0x9 goto +0x21 ; branch 0x1d6c8
01d5c0: if r2 == 0xa goto +0x22 ; branch 0x1d6d8
01d5c8: if r2 == 0xb goto +0x23 ; branch 0x1d6e8
01d5d0: if r2 == 0xc goto +0x1 ; branch 0x1d5e0
01d5d8: goto +0x23 ; branch 0x1d6f8
01d5e0: r5 = 0x7
01d5e8: goto +0xc2 ; branch 0x1dc00
01d5f0: r7 = 0x1
01d5f8: goto +0x42 ; branch 0x1d810
01d600: r5 = 0x2
01d608: r2 = 0x0
01d610: *(u64 *)(r10 - 0x580) = r2
01d618: r2 = r1
01d620: r2 += 0x10
01d628: *(u64 *)(r10 - 0x588) = r2
01d630: r3 = 0x0
01d638: r2 = 0x0
01d640: r7 = 0x0
01d648: goto +0x40 ; branch 0x1d850
01d650: r7 = 0x2
01d658: r3 = 0x1
01d660: r2 = 0x0
01d668: *(u64 *)(r10 - 0x580) = r2
01d670: r2 = r1
01d678: r2 += 0x10
01d680: goto +0x6 ; branch 0x1d6b8
01d688: r7 = 0x4
01d690: r3 = 0x0
01d698: r2 = 0x1
01d6a0: *(u64 *)(r10 - 0x580) = r2
01d6a8: r2 = 0x9a640 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/processor/edition/convert_master_edition'
01d6b8: *(u64 *)(r10 - 0x588) = r2
01d6c0: goto +0x2f ; branch 0x1d840
01d6c8: r5 = 0x0
01d6d0: goto +0xa5 ; branch 0x1dc00
01d6d8: r5 = 0x5
01d6e0: goto +0xa3 ; branch 0x1dc00
01d6e8: r5 = 0x6
01d6f0: goto +0xa1 ; branch 0x1dc00
01d6f8: if r2 != 0xd goto +0xc0 ; branch 0x1dd00
01d700: *(u64 *)(r10 - 0x288) = r8
01d708: r2 = *(u64 *)(r10 - 0x558)
01d710: *(u64 *)(r10 - 0x290) = r2
01d718: r2 = *(u64 *)(r10 - 0x540)
01d720: *(u64 *)(r10 - 0x298) = r2
01d728: r2 = *(u64 *)(r10 - 0x548)
01d730: *(u64 *)(r10 - 0x2a0) = r2
01d738: r2 = *(u64 *)(r10 - 0x550)
01d740: *(u64 *)(r10 - 0x2a8) = r2
01d748: *(u64 *)(r10 - 0x2b0) = r6
01d750: r2 = *(u64 *)(r10 - 0x560)
01d758: *(u64 *)(r10 - 0x2b8) = r2
01d760: r2 = *(u64 *)(r10 - 0x570)
01d768: *(u64 *)(r10 - 0x2c0) = r2
01d770: r2 = *(u64 *)(r10 - 0x578)
01d778: *(u64 *)(r10 - 0x2c8) = r2
01d780: r2 = *(u64 *)(r10 - 0x538)
01d788: *(u64 *)(r10 - 0x2d0) = r2
01d790: *(u64 *)(r10 - 0x2d8) = r0
01d798: r2 = *(u64 *)(r10 - 0x568)
01d7a0: *(u64 *)(r10 - 0x2e0) = r2
01d7a8: *(u64 *)(r10 - 0x2e8) = r4
01d7b0: *(u64 *)(r10 - 0x2f0) = r3
01d7b8: r6 = r1
01d7c0: r3 = r10
01d7c8: r3 += -0x2f0
01d7d0: r1 = *(u64 *)(r10 - 0x530)
01d7d8: r2 = r9
01d7e0: r4 = 0x1
01d7e8: r5 = 0x0
01d7f0: goto +0x9e ; branch 0x1dce8
01d7f8: r5 = 0x3
01d800: goto +0x7f ; branch 0x1dc00
01d808: r7 = 0x3
01d810: r2 = 0x0
01d818: *(u64 *)(r10 - 0x580) = r2
01d820: r2 = r1
01d828: r2 += 0x10
01d830: *(u64 *)(r10 - 0x588) = r2
01d838: r3 = 0x0
01d840: r5 = 0x0
01d848: r2 = 0x0
01d850: if r0 != 0x0 goto +0x3 ; branch 0x1d870
01d858: r2 = 0x9400000000 ll
01d868: goto +0x94 ; branch 0x1dd10
01d870: *(u64 *)(r10 - 0x598) = r2
01d878: r2 = *(u64 *)(r10 - 0x538)
01d880: if r2 != 0x0 goto +0x3 ; branch 0x1d8a0
01d888: r2 = 0x9500000000 ll
01d898: goto +0x8e ; branch 0x1dd10
01d8a0: *(u64 *)(r10 - 0x5c0) = r5
01d8a8: *(u64 *)(r10 - 0x5b8) = r3
01d8b0: *(u64 *)(r10 - 0x5a0) = r0
01d8b8: *(u64 *)(r10 - 0x5b0) = r4
01d8c0: *(u64 *)(r10 - 0x590) = r1
01d8c8: r1 = *(u64 *)(r1 + 0x8)
01d8d0: *(u64 *)(r10 - 0x5a8) = r1
01d8d8: r1 = r10
01d8e0: r1 += -0x2f0
01d8e8: r2 = *(u64 *)(r10 - 0x540)
01d8f0: call 0xb1ba ; call 0x766c8 / window 773
01d8f8: w1 = *(u32 *)(r10 - 0x2f0)
01d900: if r1 != 0x16 goto +0x48 ; branch 0x1db48
01d908: r1 = r10
01d910: r1 += -0x2f0
01d918: r2 = *(u64 *)(r10 - 0x548)
01d920: call 0xb1b4 ; call 0x766c8 / window 773
01d928: w1 = *(u32 *)(r10 - 0x2f0)
01d930: if r1 == 0x16 goto +0x1 ; branch 0x1d940
01d938: goto +0x41 ; branch 0x1db48
01d940: r1 = r10
01d948: r1 += -0x2f0
01d950: r2 = r6
01d958: r3 = r9
01d960: call -0x1ba7 ; call 0xfc30 / window 275
01d968: w1 = *(u32 *)(r10 - 0x2f0)
01d970: if r1 == 0x16 goto +0x1 ; branch 0x1d980
01d978: goto +0x39 ; branch 0x1db48
01d980: r9 = *(u64 *)(r10 - 0x538)
01d988: r3 = *(u64 *)(r9 + 0x0)
01d990: r1 = r10
01d998: r1 += -0x2f0
01d9a0: r2 = *(u64 *)(r10 - 0x550)
01d9a8: call -0x1bb0 ; call 0xfc30 / window 275
01d9b0: w1 = *(u32 *)(r10 - 0x2f0)
01d9b8: if r1 == 0x16 goto +0x1 ; branch 0x1d9c8
01d9c0: goto +0x30 ; branch 0x1db48
01d9c8: r3 = *(u64 *)(r9 + 0x0)
01d9d0: r1 = r10
01d9d8: r1 += -0x2f0
01d9e0: r2 = *(u64 *)(r10 - 0x5a0)
01d9e8: call -0x1bb8 ; call 0xfc30 / window 275
01d9f0: w1 = *(u32 *)(r10 - 0x2f0)
01d9f8: if r1 == 0x16 goto +0x1 ; branch 0x1da08
01da00: goto +0x28 ; branch 0x1db48
01da08: r1 = *(u64 *)(r10 - 0x558)
01da10: r1 = *(u64 *)(r1 + 0x0)
01da18: r2 = 0x999e8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
01da28: call 0xb199 ; call 0x766f8 / window 774
01da30: if r0 != 0x0 goto +0x1 ; branch 0x1da40
01da38: goto +0x5e ; branch 0x1dd30
01da40: r1 = *(u64 *)(r8 + 0x0)
01da48: r2 = 0x99ac8 ll ; data b"\x06\xa7\xd5\x17\x18{\xd1f5\xda\xd4\x04U\xfd\xc2\xc0\xc1$\xc6\x8f!Vu\xa5\xdb\xba\xcb_\x08\x00\x00\x00\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsu"
01da58: call 0xb193 ; call 0x766f8 / window 774
01da60: if r0 != 0x0 goto +0x1 ; branch 0x1da70
01da68: goto +0x58 ; branch 0x1dd30
01da70: r1 = r10
01da78: r1 += -0x2f0
01da80: r2 = r9
01da88: call -0x1bb5 ; call 0xfce8 / window 277
01da90: w1 = *(u32 *)(r10 - 0x2f0)
01da98: if r1 == 0x16 goto +0x1 ; branch 0x1daa8
01daa0: goto +0x14 ; branch 0x1db48
01daa8: r1 = r10
01dab0: r1 += -0x2f0
01dab8: r2 = r6
01dac0: call 0x549f ; call 0x47fc0 / window 419
01dac8: w8 = *(u32 *)(r10 - 0x1e8)
01dad0: if r8 != 0x2 goto +0x50 ; branch 0x1dd58
01dad8: r1 = *(u64 *)(r10 - 0x2d8)
01dae0: *(u64 *)(r10 - 0x3e0) = r1
01dae8: r2 = *(u64 *)(r10 - 0x2e0)
01daf0: *(u64 *)(r10 - 0x3e8) = r2
01daf8: r3 = *(u64 *)(r10 - 0x2e8)
01db00: *(u64 *)(r10 - 0x3f0) = r3
01db08: r4 = *(u64 *)(r10 - 0x2f0)
01db10: *(u64 *)(r10 - 0x3f8) = r4
01db18: r5 = *(u64 *)(r10 - 0x530)
01db20: *(u64 *)(r5 + 0x18) = r1
01db28: *(u64 *)(r5 + 0x10) = r2
01db30: *(u64 *)(r5 + 0x8) = r3
01db38: *(u64 *)(r5 + 0x0) = r4
01db40: goto +0xa ; branch 0x1db98
01db48: w2 = *(u32 *)(r10 - 0x2d4)
01db50: r3 = *(u64 *)(r10 - 0x530)
01db58: *(u32 *)(r3 + 0x1c) = w2
01db60: r2 = *(u64 *)(r10 - 0x2dc)
01db68: *(u64 *)(r3 + 0x14) = r2
01db70: r2 = *(u64 *)(r10 - 0x2e4)
01db78: *(u64 *)(r3 + 0xc) = r2
01db80: r2 = *(u64 *)(r10 - 0x2ec)
01db88: *(u64 *)(r3 + 0x4) = r2
01db90: *(u32 *)(r3 + 0x0) = w1
01db98: r1 = *(u64 *)(r10 - 0x590)
01dba0: goto +0x2f ; branch 0x1dd20
01dba8: r7 = 0x5
01dbb0: r2 = 0x1
01dbb8: r3 = 0x0
01dbc0: *(u64 *)(r10 - 0x580) = r3
01dbc8: r3 = r1
01dbd0: r3 += 0x30
01dbd8: *(u64 *)(r10 - 0x588) = r3
01dbe0: r3 = 0x0
01dbe8: r5 = 0x0
01dbf0: goto -0x75 ; branch 0x1d850
01dbf8: r5 = 0x4
01dc00: *(u64 *)(r10 - 0x288) = r8
01dc08: r2 = *(u64 *)(r10 - 0x558)
01dc10: *(u64 *)(r10 - 0x290) = r2
01dc18: r2 = *(u64 *)(r10 - 0x540)
01dc20: *(u64 *)(r10 - 0x298) = r2
01dc28: r2 = *(u64 *)(r10 - 0x548)
01dc30: *(u64 *)(r10 - 0x2a0) = r2
01dc38: r2 = *(u64 *)(r10 - 0x550)
01dc40: *(u64 *)(r10 - 0x2a8) = r2
01dc48: *(u64 *)(r10 - 0x2b0) = r6
01dc50: r2 = *(u64 *)(r10 - 0x560)
01dc58: *(u64 *)(r10 - 0x2b8) = r2
01dc60: r2 = *(u64 *)(r10 - 0x570)
01dc68: *(u64 *)(r10 - 0x2c0) = r2
01dc70: r2 = *(u64 *)(r10 - 0x578)
01dc78: *(u64 *)(r10 - 0x2c8) = r2
01dc80: r2 = *(u64 *)(r10 - 0x538)
01dc88: *(u64 *)(r10 - 0x2d0) = r2
01dc90: *(u64 *)(r10 - 0x2d8) = r0
01dc98: r2 = *(u64 *)(r10 - 0x568)
01dca0: *(u64 *)(r10 - 0x2e0) = r2
01dca8: *(u64 *)(r10 - 0x2e8) = r4
01dcb0: *(u64 *)(r10 - 0x2f0) = r3
01dcb8: r6 = r1
01dcc0: r3 = r10
01dcc8: r3 += -0x2f0
01dcd0: r1 = *(u64 *)(r10 - 0x530)
01dcd8: r2 = r9
01dce0: r4 = 0x0
01dce8: call 0x30f ; call 0x1f568 / window 312
01dcf0: r1 = r6
01dcf8: goto +0x4 ; branch 0x1dd20
01dd00: r2 = 0xa900000000 ll
01dd10: r3 = *(u64 *)(r10 - 0x530)
01dd18: *(u64 *)(r3 + 0x0) = r2
01dd20: call -0x351b ; call 0x3450 / window 69
01dd28: exit
01dd30: r1 = 0x9a00000000 ll
01dd40: r2 = *(u64 *)(r10 - 0x530)
01dd48: *(u64 *)(r2 + 0x0) = r1
01dd50: goto -0x38 ; branch 0x1db98
01dd58: r6 = r10
01dd60: r6 += -0x3f8
01dd68: r2 = r10
01dd70: r2 += -0x2f0
01dd78: r1 = r6
01dd80: r3 = 0x108
01dd88: call 0xf641 ; call 0x98f98 / window 1246
01dd90: r1 = r10
01dd98: r1 += -0x41c
01dda0: r2 = r10
01dda8: r2 += -0x1e4
01ddb0: r3 = 0x24
01ddb8: call 0xf63b ; call 0x98f98 / window 1246
01ddc0: r1 = r10
01ddc8: r1 += -0x528
01ddd0: r2 = r6
01ddd8: r3 = 0x108
01dde0: call 0xf636 ; call 0x98f98 / window 1246
01dde8: *(u32 *)(r10 - 0x420) = w8
01ddf0: r1 = *(u64 *)(r10 - 0x550)
01ddf8: r2 = *(u64 *)(r1 + 0x0)
01de00: r1 = r10
01de08: r1 += -0x504
01de10: call -0x3621 ; call 0x2d10 / window 44
01de18: if r0 != 0x0 goto +0x1 ; branch 0x1de28
01de20: goto +0x5 ; branch 0x1de50
01de28: r1 = 0xf00000000 ll
01de38: r2 = *(u64 *)(r10 - 0x530)
01de40: *(u64 *)(r2 + 0x0) = r1
01de48: goto +0x298 ; branch 0x1f310
01de50: r1 = r10
01de58: r1 += -0x2f0
01de60: r2 = *(u64 *)(r10 - 0x5a0)
01de68: call 0xceb9 ; call 0x85438 / window 985
01de70: w1 = *(u32 *)(r10 - 0x2f0)
01de78: if r1 == 0x16 goto +0x1 ; branch 0x1de88
01de80: goto +0x287 ; branch 0x1f2c0
01de88: r1 = *(u64 *)(r10 - 0x2e0)
01de90: *(u64 *)(r10 - 0x5c8) = r1
01de98: r1 = *(u64 *)(r10 - 0x2e8)
01dea0: r3 = *(u64 *)(r1 + 0x8)
01dea8: r2 = *(u64 *)(r1 + 0x0)
01deb0: r1 = r10
01deb8: r1 += -0x2f0
01dec0: call 0xbc7d ; call 0x7c2b0 / window 851
01dec8: w8 = *(u32 *)(r10 - 0x298)
01ded0: if r8 == 0x2 goto +0x33 ; branch 0x1e070
01ded8: r6 = r10
01dee0: r6 += -0x130
01dee8: r2 = r10
01def0: r2 += -0x2f0
01def8: r1 = r6
01df00: r3 = 0x58
01df08: call 0xf611 ; call 0x98f98 / window 1246
01df10: r1 = r10
01df18: r1 += -0x3ac
01df20: r2 = r10
01df28: r2 += -0x294
01df30: r3 = 0x64
01df38: call 0xf60b ; call 0x98f98 / window 1246
01df40: r1 = r10
01df48: r1 += -0x58
01df50: r2 = r6
01df58: r3 = 0x58
01df60: call 0xf606 ; call 0x98f98 / window 1246
01df68: r6 = r10
01df70: r6 += -0x178
01df78: r2 = r10
01df80: r2 += -0x48
01df88: r1 = r6
01df90: r3 = 0x48
01df98: call 0xf5ff ; call 0x98f98 / window 1246
01dfa0: r9 = r10
01dfa8: r9 += -0x1c0
01dfb0: r1 = r9
01dfb8: r2 = r6
01dfc0: r3 = 0x48
01dfc8: call 0xf5f9 ; call 0x98f98 / window 1246
01dfd0: r1 = r10
01dfd8: r1 += -0x3f8
01dfe0: r2 = r9
01dfe8: r3 = 0x48
01dff0: call 0xf5f4 ; call 0x98f98 / window 1246
01dff8: *(u32 *)(r10 - 0x3b0) = w8
01e000: r2 = *(u64 *)(r10 - 0x5c8)
01e008: r1 = *(u64 *)(r2 + 0x0)
01e010: r1 += -0x1
01e018: *(u64 *)(r2 + 0x0) = r1
01e020: r1 = *(u64 *)(r10 - 0x548)
01e028: r2 = *(u64 *)(r1 + 0x0)
01e030: r1 = r10
01e038: r1 += -0x3d8
01e040: call -0x3667 ; call 0x2d10 / window 44
01e048: if r0 != 0x0 goto +0x1 ; branch 0x1e058
01e050: goto +0x1a ; branch 0x1e128
01e058: r1 = 0x3900000000 ll
01e068: goto -0x47 ; branch 0x1de38
01e070: r1 = *(u64 *)(r10 - 0x2d8)
01e078: *(u64 *)(r10 - 0x1a8) = r1
01e080: r1 = *(u64 *)(r10 - 0x2e0)
01e088: *(u64 *)(r10 - 0x1b0) = r1
01e090: r1 = *(u64 *)(r10 - 0x2e8)
01e098: *(u64 *)(r10 - 0x170) = r1
01e0a0: *(u64 *)(r10 - 0x1b8) = r1
01e0a8: r1 = *(u64 *)(r10 - 0x2f0)
01e0b0: *(u64 *)(r10 - 0x178) = r1
01e0b8: *(u64 *)(r10 - 0x1c0) = r1
01e0c0: r1 = *(u64 *)(r10 - 0x1a8)
01e0c8: r2 = *(u64 *)(r10 - 0x530)
01e0d0: *(u64 *)(r2 + 0x18) = r1
01e0d8: r1 = *(u64 *)(r10 - 0x1b0)
01e0e0: *(u64 *)(r2 + 0x10) = r1
01e0e8: r1 = *(u64 *)(r10 - 0x1b8)
01e0f0: *(u64 *)(r2 + 0x8) = r1
01e0f8: r1 = *(u64 *)(r10 - 0x1c0)
01e100: *(u64 *)(r2 + 0x0) = r1
01e108: r2 = *(u64 *)(r10 - 0x5c8)
01e110: r1 = *(u64 *)(r2 + 0x0)
01e118: r1 += -0x1
01e120: goto -0x5d ; branch 0x1de40
01e128: w1 = *(u32 *)(r10 - 0x474)
01e130: if r1 == 0x6 goto +0x4 ; branch 0x1e158
01e138: r2 = 0xfffffffe ll
01e148: r1 &= r2
01e150: if r1 == 0x4 goto +0x27 ; branch 0x1e290
01e158: r1 = *(u64 *)(r10 - 0x580)
01e160: if r1 != 0x0 goto +0x1 ; branch 0x1e170
01e168: goto +0x27 ; branch 0x1e2a8
01e170: r1 = *(u64 *)(r10 - 0x560)
01e178: r4 = *(u64 *)(r1 + 0x0)
01e180: r1 = *(u64 *)(r10 - 0x5a0)
01e188: r3 = *(u64 *)(r1 + 0x0)
01e190: r1 = *(u64 *)(r10 - 0x538)
01e198: r2 = *(u64 *)(r1 + 0x0)
01e1a0: r1 = *(u64 *)(r10 - 0x548)
01e1a8: r1 = *(u64 *)(r1 + 0x0)
01e1b0: r5 = 0x0
01e1b8: *(u64 *)(r10 - 0xff0) = r5
01e1c0: r5 = *(u64 *)(r10 - 0x5a8)
01e1c8: *(u64 *)(r10 - 0xfe8) = r5
01e1d0: r5 = 0x996b8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
01e1e0: *(u64 *)(r10 - 0xff8) = r5
01e1e8: *(u64 *)(r10 - 0x1000) = r1
01e1f0: r1 = r10
01e1f8: r1 += -0x2f0
01e200: r5 = r10
01e208: call 0xbfd2 ; call 0x7e0a0 / window 861
01e210: r8 = *(u64 *)(r10 - 0x2c8)
01e218: if r8 != 0x0 goto +0x14 ; branch 0x1e2c0
01e220: r1 = *(u64 *)(r10 - 0x2d8)
01e228: *(u64 *)(r10 - 0x68) = r1
01e230: r2 = *(u64 *)(r10 - 0x2e0)
01e238: *(u64 *)(r10 - 0x70) = r2
01e240: r3 = *(u64 *)(r10 - 0x2e8)
01e248: *(u64 *)(r10 - 0x78) = r3
01e250: r4 = *(u64 *)(r10 - 0x2f0)
01e258: *(u64 *)(r10 - 0x80) = r4
01e260: r5 = *(u64 *)(r10 - 0x530)
01e268: *(u64 *)(r5 + 0x18) = r1
01e270: *(u64 *)(r5 + 0x10) = r2
01e278: *(u64 *)(r5 + 0x8) = r3
01e280: *(u64 *)(r5 + 0x0) = r4
01e288: goto +0x210 ; branch 0x1f310
01e290: r1 = *(u64 *)(r10 - 0x580)
01e298: if r1 != 0x0 goto +0x1 ; branch 0x1e2a8
01e2a0: goto +0x53 ; branch 0x1e540
01e2a8: r1 = 0xa500000000 ll
01e2b8: goto -0x91 ; branch 0x1de38
01e2c0: r6 = r10
01e2c8: r6 += -0x80
01e2d0: r2 = r10
01e2d8: r2 += -0x2f0
01e2e0: r1 = r6
01e2e8: r3 = 0x28
01e2f0: call 0xf594 ; call 0x98f98 / window 1246
01e2f8: r1 = *(u64 *)(r10 - 0x2c0)
01e300: *(u64 *)(r10 - 0x100) = r1
01e308: r1 = *(u64 *)(r10 - 0x2b8)
01e310: *(u64 *)(r10 - 0xf8) = r1
01e318: r1 = *(u64 *)(r10 - 0x2b0)
01e320: *(u64 *)(r10 - 0xf0) = r1
01e328: r1 = *(u64 *)(r10 - 0x2a8)
01e330: *(u64 *)(r10 - 0xe8) = r1
01e338: r1 = r10
01e340: r1 += -0x130
01e348: *(u64 *)(r10 - 0x540) = r1
01e350: r2 = r6
01e358: r3 = 0x28
01e360: call 0xf586 ; call 0x98f98 / window 1246
01e368: *(u64 *)(r10 - 0x108) = r8
01e370: r6 = r10
01e378: r6 += -0x1c0
01e380: r1 = r6
01e388: r2 = *(u64 *)(r10 - 0x5a0)
01e390: call -0x2778 ; call 0xa7d8 / window 217
01e398: r9 = r10
01e3a0: r9 += -0x178
01e3a8: r1 = r9
01e3b0: r2 = *(u64 *)(r10 - 0x560)
01e3b8: call -0x277d ; call 0xa7d8 / window 217
01e3c0: r7 = r10
01e3c8: r7 += -0x58
01e3d0: r1 = r7
01e3d8: r2 = *(u64 *)(r10 - 0x548)
01e3e0: call -0x2782 ; call 0xa7d8 / window 217
01e3e8: r8 = r10
01e3f0: r8 += -0x2f0
01e3f8: r1 = r8
01e400: r2 = r6
01e408: r3 = 0x30
01e410: call 0xf570 ; call 0x98f98 / window 1246
01e418: r1 = r10
01e420: r1 += -0x2c0
01e428: r2 = r9
01e430: r3 = 0x30
01e438: call 0xf56b ; call 0x98f98 / window 1246
01e440: r1 = r10
01e448: r1 += -0x290
01e450: r2 = r7
01e458: r3 = 0x30
01e460: call 0xf566 ; call 0x98f98 / window 1246
01e468: r1 = r10
01e470: r1 += -0xa0
01e478: r2 = *(u64 *)(r10 - 0x540)
01e480: r3 = r8
01e488: r4 = 0x3
01e490: call 0xd001 ; call 0x864a0 / window 996
01e498: w1 = *(u32 *)(r10 - 0xa0)
01e4a0: if r1 == 0x16 goto +0x1 ; branch 0x1e4b0
01e4a8: goto +0xb9 ; branch 0x1ea78
01e4b0: r1 = r10
01e4b8: r1 += -0x2f0
01e4c0: call -0x35d3 ; call 0x3630 / window 76
01e4c8: r1 = r10
01e4d0: r1 += -0x130
01e4d8: call -0x3677 ; call 0x3128 / window 61
01e4e0: r1 = *(u64 *)(r10 - 0x5b8)
01e4e8: if r1 != 0x0 goto +0x39 ; branch 0x1e6b8
01e4f0: w1 = *(u32 *)(r10 - 0x474)
01e4f8: if r1 == 0x6 goto +0x4 ; branch 0x1e520
01e500: r2 = 0xfffffffe ll
01e510: r1 &= r2
01e518: if r1 == 0x4 goto +0x1ce ; branch 0x1f390
01e520: r1 = 0x16
01e528: r2 = *(u64 *)(r10 - 0x530)
01e530: *(u32 *)(r2 + 0x0) = w1
01e538: goto +0x1ba ; branch 0x1f310
01e540: r1 = *(u64 *)(r10 - 0x568)
01e548: if r1 == 0x0 goto +0x46 ; branch 0x1e780
01e550: r1 = *(u64 *)(r10 - 0x5a0)
01e558: r3 = *(u64 *)(r1 + 0x0)
01e560: r1 = *(u64 *)(r10 - 0x550)
01e568: r2 = *(u64 *)(r1 + 0x0)
01e570: r1 = r10
01e578: r1 += -0x2f0
01e580: call -0x1a7a ; call 0x111b8 / window 294
01e588: r1 = *(u64 *)(r10 - 0x2d8)
01e590: *(u64 *)(r10 - 0x160) = r1
01e598: r1 = *(u64 *)(r10 - 0x2e0)
01e5a0: *(u64 *)(r10 - 0x168) = r1
01e5a8: r1 = *(u64 *)(r10 - 0x2e8)
01e5b0: *(u64 *)(r10 - 0x170) = r1
01e5b8: r1 = *(u64 *)(r10 - 0x2f0)
01e5c0: *(u64 *)(r10 - 0x178) = r1
01e5c8: r1 = *(u64 *)(r10 - 0x568)
01e5d0: r2 = *(u64 *)(r1 + 0x0)
01e5d8: r1 = r10
01e5e0: r1 += -0x178
01e5e8: call 0xb021 ; call 0x766f8 / window 774
01e5f0: if r0 == 0x0 goto +0x1a7 ; branch 0x1f330
01e5f8: r1 = r10
01e600: r1 += -0x2f0
01e608: r2 = *(u64 *)(r10 - 0x568)
01e610: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
01e620: call -0x1d3f ; call 0xfc30 / window 275
01e628: w1 = *(u32 *)(r10 - 0x2f0)
01e630: if r1 == 0x16 goto +0x1 ; branch 0x1e640
01e638: goto +0x1a1 ; branch 0x1f348
01e640: r1 = r10
01e648: r1 += -0x2f0
01e650: r2 = *(u64 *)(r10 - 0x568)
01e658: call 0x4948 ; call 0x430a0 / window 368
01e660: r8 = *(u64 *)(r10 - 0x2e0)
01e668: if r8 != 0x2 goto +0x92 ; branch 0x1eb00
01e670: r1 = *(u64 *)(r10 - 0x2c0)
01e678: *(u64 *)(r10 - 0x118) = r1
01e680: r2 = *(u64 *)(r10 - 0x2c8)
01e688: *(u64 *)(r10 - 0x120) = r2
01e690: r3 = *(u64 *)(r10 - 0x2d0)
01e698: *(u64 *)(r10 - 0x128) = r3
01e6a0: r4 = *(u64 *)(r10 - 0x2d8)
01e6a8: *(u64 *)(r10 - 0x130) = r4
01e6b0: goto -0x8b ; branch 0x1e260
01e6b8: r1 = *(u64 *)(r10 - 0x5b0)
01e6c0: if r1 == 0x0 goto +0x1c8 ; branch 0x1f508
01e6c8: w1 = *(u32 *)(r10 - 0x370)
01e6d0: if r1 == 0x1 goto +0x1 ; branch 0x1e6e0
01e6d8: goto +0x17 ; branch 0x1e798
01e6e0: r1 = *(u64 *)(r10 - 0x354)
01e6e8: *(u64 *)(r10 - 0x2d8) = r1
01e6f0: r1 = *(u64 *)(r10 - 0x35c)
01e6f8: *(u64 *)(r10 - 0x2e0) = r1
01e700: r1 = *(u64 *)(r10 - 0x364)
01e708: *(u64 *)(r10 - 0x2e8) = r1
01e710: r1 = *(u64 *)(r10 - 0x36c)
01e718: *(u64 *)(r10 - 0x2f0) = r1
01e720: r1 = r10
01e728: r1 += -0x2f0
01e730: *(u64 *)(r10 - 0x130) = r1
01e738: r1 = r10
01e740: r1 += -0x130
01e748: r2 = *(u64 *)(r10 - 0x5b0)
01e750: call -0x3750 ; call 0x2cd8 / window 42
01e758: if r0 != 0x0 goto +0x1 ; branch 0x1e768
01e760: goto -0x4f ; branch 0x1e4f0
01e768: r1 = 0xbc00000000 ll
01e778: goto -0x129 ; branch 0x1de38
01e780: r1 = 0x9f00000000 ll
01e790: goto -0x12c ; branch 0x1de38
01e798: r1 = *(u64 *)(r10 - 0x5b0)
01e7a0: r4 = *(u64 *)(r1 + 0x0)
01e7a8: r1 = *(u64 *)(r10 - 0x5a0)
01e7b0: r3 = *(u64 *)(r1 + 0x0)
01e7b8: r1 = *(u64 *)(r10 - 0x538)
01e7c0: r2 = *(u64 *)(r1 + 0x0)
01e7c8: r1 = *(u64 *)(r10 - 0x548)
01e7d0: r1 = *(u64 *)(r1 + 0x0)
01e7d8: r5 = 0x996b8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
01e7e8: *(u64 *)(r10 - 0xff0) = r5
01e7f0: r5 = 0x0
01e7f8: *(u64 *)(r10 - 0xfe8) = r5
01e800: *(u64 *)(r10 - 0xff8) = r1
01e808: r1 = 0x3
01e810: *(u64 *)(r10 - 0x1000) = r1
01e818: r1 = r10
01e820: r1 += -0x2f0
01e828: r5 = r10
01e830: call 0xc059 ; call 0x7eb00 / window 863
01e838: r8 = *(u64 *)(r10 - 0x2c8)
01e840: if r8 != 0x0 goto +0x1 ; branch 0x1e850
01e848: goto -0xc6 ; branch 0x1e220
01e850: r6 = r10
01e858: r6 += -0x80
01e860: r2 = r10
01e868: r2 += -0x2f0
01e870: r1 = r6
01e878: r3 = 0x28
01e880: call 0xf4e2 ; call 0x98f98 / window 1246
01e888: r1 = *(u64 *)(r10 - 0x2c0)
01e890: *(u64 *)(r10 - 0x100) = r1
01e898: r1 = *(u64 *)(r10 - 0x2b8)
01e8a0: *(u64 *)(r10 - 0xf8) = r1
01e8a8: r1 = *(u64 *)(r10 - 0x2b0)
01e8b0: *(u64 *)(r10 - 0xf0) = r1
01e8b8: r1 = *(u64 *)(r10 - 0x2a8)
01e8c0: *(u64 *)(r10 - 0xe8) = r1
01e8c8: r1 = r10
01e8d0: r1 += -0x130
01e8d8: *(u64 *)(r10 - 0x540) = r1
01e8e0: r2 = r6
01e8e8: r3 = 0x28
01e8f0: call 0xf4d4 ; call 0x98f98 / window 1246
01e8f8: *(u64 *)(r10 - 0x108) = r8
01e900: r9 = r10
01e908: r9 += -0x1c0
01e910: r1 = r9
01e918: r2 = *(u64 *)(r10 - 0x5a0)
01e920: call -0x282a ; call 0xa7d8 / window 217
01e928: r6 = r10
01e930: r6 += -0x178
01e938: r1 = r6
01e940: r2 = *(u64 *)(r10 - 0x560)
01e948: call -0x282f ; call 0xa7d8 / window 217
01e950: r8 = r10
01e958: r8 += -0x58
01e960: r1 = r8
01e968: r2 = *(u64 *)(r10 - 0x548)
01e970: call -0x2834 ; call 0xa7d8 / window 217
01e978: r7 = r10
01e980: r7 += -0x2f0
01e988: r1 = r7
01e990: r2 = r9
01e998: r3 = 0x30
01e9a0: call 0xf4be ; call 0x98f98 / window 1246
01e9a8: r1 = r10
01e9b0: r1 += -0x2c0
01e9b8: r2 = r6
01e9c0: r3 = 0x30
01e9c8: call 0xf4b9 ; call 0x98f98 / window 1246
01e9d0: r1 = r10
01e9d8: r1 += -0x290
01e9e0: r2 = r8
01e9e8: r3 = 0x30
01e9f0: call 0xf4b4 ; call 0x98f98 / window 1246
01e9f8: r1 = r10
01ea00: r1 += -0xa0
01ea08: r2 = *(u64 *)(r10 - 0x540)
01ea10: r3 = r7
01ea18: r4 = 0x3
01ea20: call 0xcf4f ; call 0x864a0 / window 996
01ea28: w1 = *(u32 *)(r10 - 0xa0)
01ea30: if r1 == 0x16 goto +0x1 ; branch 0x1ea40
01ea38: goto +0x7 ; branch 0x1ea78
01ea40: r1 = r10
01ea48: r1 += -0x2f0
01ea50: call -0x3685 ; call 0x3630 / window 76
01ea58: r1 = r10
01ea60: r1 += -0x130
01ea68: call -0x3729 ; call 0x3128 / window 61
01ea70: goto -0xb1 ; branch 0x1e4f0
01ea78: w2 = *(u32 *)(r10 - 0x84)
01ea80: r3 = *(u64 *)(r10 - 0x530)
01ea88: *(u32 *)(r3 + 0x1c) = w2
01ea90: r2 = *(u64 *)(r10 - 0x8c)
01ea98: *(u64 *)(r3 + 0x14) = r2
01eaa0: r2 = *(u64 *)(r10 - 0x94)
01eaa8: *(u64 *)(r3 + 0xc) = r2
01eab0: r2 = *(u64 *)(r10 - 0x9c)
01eab8: *(u64 *)(r3 + 0x4) = r2
01eac0: *(u32 *)(r3 + 0x0) = w1
01eac8: r1 = r10
01ead0: r1 += -0x2f0
01ead8: call -0x3696 ; call 0x3630 / window 76
01eae0: r1 = r10
01eae8: r1 += -0x130
01eaf0: call -0x373a ; call 0x3128 / window 61
01eaf8: goto +0x102 ; branch 0x1f310
01eb00: r1 = *(u64 *)(r10 - 0x2e8)
01eb08: *(u64 *)(r10 - 0x78) = r1
01eb10: r1 = *(u64 *)(r10 - 0x2f0)
01eb18: *(u64 *)(r10 - 0x80) = r1
01eb20: r1 = *(u64 *)(r10 - 0x2d8)
01eb28: *(u64 *)(r10 - 0x130) = r1
01eb30: r1 = *(u64 *)(r10 - 0x2d0)
01eb38: *(u64 *)(r10 - 0x128) = r1
01eb40: r1 = *(u64 *)(r10 - 0x2c8)
01eb48: *(u64 *)(r10 - 0x120) = r1
01eb50: r1 = *(u64 *)(r10 - 0x2c0)
01eb58: *(u64 *)(r10 - 0x118) = r1
01eb60: r6 = r10
01eb68: r6 += -0x58
01eb70: r2 = r10
01eb78: r2 += -0x2b8
01eb80: r1 = r6
01eb88: r3 = 0x38
01eb90: call 0xf480 ; call 0x98f98 / window 1246
01eb98: r1 = *(u64 *)(r10 - 0x118)
01eba0: *(u64 *)(r10 - 0x1a8) = r1
01eba8: r2 = *(u64 *)(r10 - 0x120)
01ebb0: *(u64 *)(r10 - 0x1b0) = r2
01ebb8: r3 = *(u64 *)(r10 - 0x128)
01ebc0: *(u64 *)(r10 - 0x1b8) = r3
01ebc8: r4 = *(u64 *)(r10 - 0x130)
01ebd0: *(u64 *)(r10 - 0x1c0) = r4
01ebd8: r5 = *(u64 *)(r10 - 0x78)
01ebe0: *(u64 *)(r10 - 0x128) = r5
01ebe8: r5 = *(u64 *)(r10 - 0x80)
01ebf0: *(u64 *)(r10 - 0x130) = r5
01ebf8: *(u64 *)(r10 - 0x120) = r8
01ec00: *(u64 *)(r10 - 0x118) = r4
01ec08: *(u64 *)(r10 - 0x110) = r3
01ec10: *(u64 *)(r10 - 0x108) = r2
01ec18: *(u64 *)(r10 - 0x100) = r1
01ec20: r1 = r10
01ec28: r1 += -0xf8
01ec30: r2 = r6
01ec38: r3 = 0x38
01ec40: call 0xf46a ; call 0x98f98 / window 1246
01ec48: w1 = *(u32 *)(r10 - 0x420)
01ec50: if r1 != 0x0 goto +0x64 ; branch 0x1ef78
01ec58: w1 = *(u8 *)(r10 - 0x41c)
01ec60: if r1 == 0x0 goto +0x62 ; branch 0x1ef78
01ec68: r1 = *(u64 *)(r10 - 0x403)
01ec70: *(u64 *)(r10 - 0x68) = r1
01ec78: r1 = *(u64 *)(r10 - 0x40b)
01ec80: *(u64 *)(r10 - 0x70) = r1
01ec88: r1 = *(u64 *)(r10 - 0x413)
01ec90: *(u64 *)(r10 - 0x78) = r1
01ec98: r1 = *(u64 *)(r10 - 0x41b)
01eca0: *(u64 *)(r10 - 0x80) = r1
01eca8: r1 = *(u64 *)(r10 - 0x570)
01ecb0: if r1 == 0x0 goto +0x10d ; branch 0x1f520
01ecb8: r1 = *(u64 *)(r10 - 0x570)
01ecc0: r1 = *(u64 *)(r1 + 0x0)
01ecc8: r2 = r10
01ecd0: r2 += -0x80
01ecd8: call 0xaf43 ; call 0x766f8 / window 774
01ece0: if r0 != 0x0 goto +0x1 ; branch 0x1ecf0
01ece8: goto +0xc8 ; branch 0x1f330
01ecf0: r1 = r10
01ecf8: r1 += -0x2f0
01ed00: r2 = *(u64 *)(r10 - 0x570)
01ed08: r3 = 0x99ae8 ll ; data b"\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsufficient tokens for transferAcco"
01ed18: call -0x1e1e ; call 0xfc30 / window 275
01ed20: w1 = *(u32 *)(r10 - 0x2f0)
01ed28: if r1 == 0x16 goto +0x1 ; branch 0x1ed38
01ed30: goto +0xc2 ; branch 0x1f348
01ed38: r1 = *(u64 *)(r10 - 0x578)
01ed40: if r1 == 0x0 goto +0x101 ; branch 0x1f550
01ed48: r1 = *(u64 *)(r10 - 0x578)
01ed50: r1 = *(u64 *)(r1 + 0x0)
01ed58: r2 = 0x99ae8 ll ; data b"\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsufficient tokens for transferAcco"
01ed68: call 0xaf31 ; call 0x766f8 / window 774
01ed70: if r0 != 0x0 goto +0x1 ; branch 0x1ed80
01ed78: goto +0xb6 ; branch 0x1f330
01ed80: r2 = r10
01ed88: r2 += -0x420
01ed90: r1 = r10
01ed98: r1 += -0x178
01eda0: *(u64 *)(r10 - 0x578) = r1
01eda8: r3 = 0x28
01edb0: call 0xf43c ; call 0x98f98 / window 1246
01edb8: r6 = r10
01edc0: r6 += -0x58
01edc8: r1 = r6
01edd0: r2 = *(u64 *)(r10 - 0x588)
01edd8: call -0x2f25 ; call 0x74b8 / window 182
01ede0: r1 = *(u64 *)(r10 - 0x120)
01ede8: *(u64 *)(r10 - 0x580) = r1
01edf0: r8 = *(u64 *)(r10 - 0x118)
01edf8: r9 = r10
01ee00: r9 += -0x2f0
01ee08: r1 = r9
01ee10: r2 = r6
01ee18: r3 = 0x30
01ee20: call 0xf42e ; call 0x98f98 / window 1246
01ee28: r1 = *(u64 *)(r10 - 0x560)
01ee30: *(u64 *)(r10 - 0x2a8) = r1
01ee38: *(u64 *)(r10 - 0x2b8) = r8
01ee40: r1 = *(u64 *)(r10 - 0x580)
01ee48: *(u64 *)(r10 - 0x2c0) = r1
01ee50: *(u32 *)(r10 - 0x274) = w7
01ee58: r1 = 0x2
01ee60: *(u32 *)(r10 - 0x278) = w1
01ee68: r1 = *(u64 *)(r10 - 0x550)
01ee70: *(u64 *)(r10 - 0x280) = r1
01ee78: r1 = *(u64 *)(r10 - 0x570)
01ee80: *(u64 *)(r10 - 0x288) = r1
01ee88: r1 = *(u64 *)(r10 - 0x5a8)
01ee90: *(u64 *)(r10 - 0x290) = r1
01ee98: r6 = 0x0
01eea0: *(u64 *)(r10 - 0x2a0) = r6
01eea8: *(u64 *)(r10 - 0x2b0) = r6
01eeb0: *(u64 *)(r10 - 0x298) = r6
01eeb8: r1 = r10
01eec0: r1 += -0x270
01eec8: r2 = *(u64 *)(r10 - 0x578)
01eed0: r3 = 0x28
01eed8: call 0xf417 ; call 0x98f98 / window 1246
01eee0: *(u8 *)(r10 - 0x248) = w6
01eee8: r1 = r10
01eef0: r1 += -0x1c0
01eef8: r2 = r9
01ef00: call 0x66b9 ; call 0x524d0 / window 445
01ef08: w1 = *(u32 *)(r10 - 0x1c0)
01ef10: if r1 == 0x16 goto +0x1 ; branch 0x1ef20
01ef18: goto +0xb2 ; branch 0x1f4b0
01ef20: r1 = r10
01ef28: r1 += -0x2f0
01ef30: r2 = *(u64 *)(r10 - 0x570)
01ef38: call 0xa67a ; call 0x72310 / window 729
01ef40: w1 = *(u32 *)(r10 - 0x2f0)
01ef48: if r1 == 0x16 goto +0x1 ; branch 0x1ef58
01ef50: goto +0x6d ; branch 0x1f2c0
01ef58: r1 = *(u64 *)(r10 - 0x2e0)
01ef60: *(u64 *)(r10 - 0x118) = r1
01ef68: r1 = *(u64 *)(r10 - 0x2e8)
01ef70: *(u64 *)(r10 - 0x120) = r1
01ef78: r1 = *(u64 *)(r10 - 0x5c0)
01ef80: *(u32 *)(r10 - 0x128) = w1
01ef88: r1 = 0x0
01ef90: r2 = *(u64 *)(r10 - 0x598)
01ef98: if r2 != 0x0 goto +0x1 ; branch 0x1efa8
01efa0: goto +0xd ; branch 0x1f010
01efa8: r1 = *(u64 *)(r10 - 0x590)
01efb0: w1 = *(u32 *)(r1 + 0x0)
01efb8: if r1 != 0x7 goto +0xaf ; branch 0x1f538
01efc0: r2 = *(u64 *)(r10 - 0x590)
01efc8: r1 = *(u64 *)(r2 + 0x28)
01efd0: *(u64 *)(r10 - 0x2d8) = r1
01efd8: r1 = *(u64 *)(r2 + 0x20)
01efe0: *(u64 *)(r10 - 0x2e0) = r1
01efe8: r1 = *(u64 *)(r2 + 0x18)
01eff0: *(u64 *)(r10 - 0x2e8) = r1
01eff8: r1 = *(u64 *)(r2 + 0x10)
01f000: *(u64 *)(r10 - 0x2f0) = r1
01f008: r1 = 0x1
01f010: *(u8 *)(r10 - 0xe8) = w1
01f018: r1 = *(u64 *)(r10 - 0x2f0)
01f020: *(u64 *)(r10 - 0xe7) = r1
01f028: r1 = *(u64 *)(r10 - 0x2e8)
01f030: *(u64 *)(r10 - 0xdf) = r1
01f038: r1 = *(u64 *)(r10 - 0x2e0)
01f040: *(u64 *)(r10 - 0xd7) = r1
01f048: r1 = *(u64 *)(r10 - 0x2d8)
01f050: *(u64 *)(r10 - 0xcf) = r1
01f058: r1 = *(u64 *)(r10 - 0x560)
01f060: r1 = *(u64 *)(r1 + 0x0)
01f068: r2 = *(u64 *)(r1 + 0x18)
01f070: r3 = *(u64 *)(r1 + 0x10)
01f078: r4 = *(u64 *)(r1 + 0x8)
01f080: r1 = *(u64 *)(r1 + 0x0)
01f088: r5 = 0x1
01f090: *(u8 *)(r10 - 0x110) = w5
01f098: *(u64 *)(r10 - 0x10f) = r1
01f0a0: *(u64 *)(r10 - 0x107) = r4
01f0a8: *(u64 *)(r10 - 0xff) = r3
01f0b0: *(u64 *)(r10 - 0xf7) = r2
01f0b8: *(u32 *)(r10 - 0xec) = w7
01f0c0: r1 = r10
01f0c8: r1 += -0x2f0
01f0d0: r2 = r10
01f0d8: r2 += -0x130
01f0e0: r3 = *(u64 *)(r10 - 0x568)
01f0e8: r4 = *(u64 *)(r10 - 0x540)
01f0f0: r5 = *(u64 *)(r10 - 0x558)
01f0f8: call 0x52cb ; call 0x48758 / window 422
01f100: w1 = *(u32 *)(r10 - 0x2f0)
01f108: if r1 != 0x16 goto +0x47 ; branch 0x1f348
01f110: r1 = *(u64 *)(r10 - 0x5b0)
01f118: if r1 == 0x0 goto +0x7d ; branch 0x1f508
01f120: r1 = r10
01f128: r1 += -0x2f0
01f130: r2 = *(u64 *)(r10 - 0x5b0)
01f138: r3 = 0x999c8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
01f148: call -0x1ea4 ; call 0xfc30 / window 275
01f150: w1 = *(u32 *)(r10 - 0x2f0)
01f158: if r1 == 0x16 goto +0x1 ; branch 0x1f168
01f160: goto +0x3c ; branch 0x1f348
01f168: r7 = r10
01f170: r7 += -0x1c0
01f178: r1 = r7
01f180: r2 = *(u64 *)(r10 - 0x550)
01f188: call -0x2937 ; call 0xa7d8 / window 217
01f190: r8 = r10
01f198: r8 += -0x178
01f1a0: r1 = r8
01f1a8: r2 = *(u64 *)(r10 - 0x5a0)
01f1b0: call -0x293c ; call 0xa7d8 / window 217
01f1b8: r6 = r10
01f1c0: r6 += -0x58
01f1c8: r1 = r6
01f1d0: r2 = *(u64 *)(r10 - 0x5b0)
01f1d8: call -0x2941 ; call 0xa7d8 / window 217
01f1e0: r9 = r10
01f1e8: r9 += -0x2f0
01f1f0: r1 = r9
01f1f8: r2 = *(u64 *)(r10 - 0x538)
01f200: call -0x2946 ; call 0xa7d8 / window 217
01f208: w1 = *(u8 *)(r10 - 0x475)
01f210: w2 = *(u8 *)(r10 - 0x476)
01f218: *(u64 *)(r10 - 0xff8) = r2
01f220: *(u64 *)(r10 - 0xff0) = r1
01f228: *(u64 *)(r10 - 0x1000) = r9
01f230: r1 = r10
01f238: r1 += -0x80
01f240: r5 = r10
01f248: r2 = r7
01f250: r3 = r8
01f258: r4 = r6
01f260: call 0x6483 ; call 0x51680 / window 443
01f268: w1 = *(u32 *)(r10 - 0x80)
01f270: if r1 == 0x16 goto -0x221 ; branch 0x1e170
01f278: w2 = *(u32 *)(r10 - 0x64)
01f280: r3 = *(u64 *)(r10 - 0x530)
01f288: *(u32 *)(r3 + 0x1c) = w2
01f290: r2 = *(u64 *)(r10 - 0x6c)
01f298: *(u64 *)(r3 + 0x14) = r2
01f2a0: r2 = *(u64 *)(r10 - 0x74)
01f2a8: *(u64 *)(r3 + 0xc) = r2
01f2b0: r2 = *(u64 *)(r10 - 0x7c)
01f2b8: goto +0x46 ; branch 0x1f4f0
01f2c0: w2 = *(u32 *)(r10 - 0x2ec)
01f2c8: r3 = *(u64 *)(r10 - 0x2e8)
01f2d0: r4 = *(u64 *)(r10 - 0x2e0)
01f2d8: r5 = *(u64 *)(r10 - 0x2d8)
01f2e0: r0 = *(u64 *)(r10 - 0x530)
01f2e8: *(u64 *)(r0 + 0x18) = r5
01f2f0: *(u64 *)(r0 + 0x10) = r4
01f2f8: *(u64 *)(r0 + 0x8) = r3
01f300: *(u32 *)(r0 + 0x4) = w2
01f308: *(u32 *)(r0 + 0x0) = w1
01f310: r1 = r10
01f318: r1 += -0x4e0
01f320: call -0x3851 ; call 0x30a0 / window 59
01f328: goto -0x2f3 ; branch 0x1db98
01f330: r1 = 0x9a00000000 ll
01f340: goto -0x2a2 ; branch 0x1de38
01f348: w2 = *(u32 *)(r10 - 0x2d4)
01f350: r3 = *(u64 *)(r10 - 0x530)
01f358: *(u32 *)(r3 + 0x1c) = w2
01f360: r2 = *(u64 *)(r10 - 0x2dc)
01f368: *(u64 *)(r3 + 0x14) = r2
01f370: r2 = *(u64 *)(r10 - 0x2e4)
01f378: *(u64 *)(r3 + 0xc) = r2
01f380: r2 = *(u64 *)(r10 - 0x2ec)
01f388: goto +0x2c ; branch 0x1f4f0
01f390: r1 = *(u64 *)(r10 - 0x5b0)
01f398: if r1 == 0x0 goto +0x2d ; branch 0x1f508
01f3a0: r7 = r10
01f3a8: r7 += -0x178
01f3b0: r1 = r7
01f3b8: r2 = *(u64 *)(r10 - 0x550)
01f3c0: call -0x297e ; call 0xa7d8 / window 217
01f3c8: r8 = r10
01f3d0: r8 += -0x58
01f3d8: r1 = r8
01f3e0: r2 = *(u64 *)(r10 - 0x5a0)
01f3e8: call -0x2983 ; call 0xa7d8 / window 217
01f3f0: r9 = r10
01f3f8: r9 += -0x130
01f400: r1 = r9
01f408: r2 = *(u64 *)(r10 - 0x5b0)
01f410: call -0x2988 ; call 0xa7d8 / window 217
01f418: r6 = r10
01f420: r6 += -0x2f0
01f428: r1 = r6
01f430: r2 = *(u64 *)(r10 - 0x538)
01f438: call -0x298d ; call 0xa7d8 / window 217
01f440: w1 = *(u8 *)(r10 - 0x475)
01f448: w2 = *(u8 *)(r10 - 0x476)
01f450: *(u64 *)(r10 - 0xff8) = r2
01f458: *(u64 *)(r10 - 0xff0) = r1
01f460: *(u64 *)(r10 - 0x1000) = r6
01f468: r1 = r10
01f470: r1 += -0x1c0
01f478: r5 = r10
01f480: r2 = r7
01f488: r3 = r8
01f490: r4 = r9
01f498: call 0x6339 ; call 0x50e68 / window 442
01f4a0: w1 = *(u32 *)(r10 - 0x1c0)
01f4a8: if r1 == 0x16 goto -0x1f2 ; branch 0x1e520
01f4b0: w2 = *(u32 *)(r10 - 0x1a4)
01f4b8: r3 = *(u64 *)(r10 - 0x530)
01f4c0: *(u32 *)(r3 + 0x1c) = w2
01f4c8: r2 = *(u64 *)(r10 - 0x1ac)
01f4d0: *(u64 *)(r3 + 0x14) = r2
01f4d8: r2 = *(u64 *)(r10 - 0x1b4)
01f4e0: *(u64 *)(r3 + 0xc) = r2
01f4e8: r2 = *(u64 *)(r10 - 0x1bc)
01f4f0: *(u64 *)(r3 + 0x4) = r2
01f4f8: *(u32 *)(r3 + 0x0) = w1
01f500: goto -0x3f ; branch 0x1f310
01f508: r1 = 0x6c00000000 ll
01f518: goto -0x2dd ; branch 0x1de38
01f520: r1 = 0x8a00000000 ll
01f530: goto -0x2e0 ; branch 0x1de38
01f538: r1 = 0xa900000000 ll
01f548: goto -0x2e3 ; branch 0x1de38
01f550: r1 = 0x9600000000 ll
01f560: goto -0x2e6 ; branch 0x1de38
