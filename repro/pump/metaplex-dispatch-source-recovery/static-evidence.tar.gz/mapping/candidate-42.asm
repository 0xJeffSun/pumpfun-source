002cd8: r2 = *(u64 *)(r2 + 0x0)
002ce0: r1 = *(u64 *)(r1 + 0x0)
002ce8: call 0x4 ; call 0x2d10 / window 44
002cf0: exit
