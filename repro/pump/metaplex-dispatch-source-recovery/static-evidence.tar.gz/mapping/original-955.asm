084570: r3 = 0x20
084578: call 0x29cd ; call 0x993e8 / window 1249
084580: r1 = r0
084588: r0 = 0x1
084590: if r1 == 0x0 goto +0x1 ; branch 0x845a0
084598: r0 = 0x0
0845a0: exit
