02c020: r2 = *(u64 *)(r5 - 0xff8)
02c028: r5 = *(u64 *)(r5 - 0x1000)
02c030: r0 = r5
02c038: r0 <<= 0x20
02c040: r0 >>= 0x20
02c048: if r0 != 0x0 goto +0x6 ; branch 0x2c080
02c050: r5 = 0x0
02c058: *(u64 *)(r10 - 0x1000) = r5
02c060: *(u64 *)(r10 - 0xff8) = r2
02c068: r5 = r10
02c070: call 0x6 ; call 0x2c0a8 / window 326
02c078: goto +0x4 ; branch 0x2c0a0
02c080: *(u64 *)(r10 - 0x1000) = r5
02c088: *(u64 *)(r10 - 0xff8) = r2
02c090: r5 = r10
02c098: call 0x49 ; call 0x2c2e8 / window 327
02c0a0: exit
