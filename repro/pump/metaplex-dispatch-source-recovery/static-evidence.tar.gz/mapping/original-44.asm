002d10: call 0x1030b ; call 0x84570 / window 955
002d18: r0 ^= 0x1
002d20: exit
