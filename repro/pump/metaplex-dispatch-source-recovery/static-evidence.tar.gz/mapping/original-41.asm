002cb8: r2 = *(u64 *)(r2 + 0x0)
002cc0: r1 = *(u64 *)(r1 + 0x0)
002cc8: call 0x10314 ; call 0x84570 / window 955
002cd0: exit
