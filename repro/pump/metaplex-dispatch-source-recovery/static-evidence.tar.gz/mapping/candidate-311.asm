01d3d8: r7 = r5
01d3e0: r9 = r2
01d3e8: r6 = r1
01d3f0: r1 = r10
01d3f8: r1 += -0x2f0
01d400: r2 = r3
01d408: r3 = r4
01d410: call 0x8812 ; call 0x614a8 / window 493
01d418: r0 = *(u64 *)(r10 - 0x2d8)
01d420: r2 = *(u64 *)(r10 - 0x2e0)
01d428: r4 = *(u64 *)(r10 - 0x2e8)
01d430: r3 = *(u64 *)(r10 - 0x2f0)
01d438: r1 = *(u64 *)(r10 - 0x2b8)
01d440: if r1 != 0x0 goto +0x6 ; branch 0x1d478
01d448: *(u64 *)(r6 + 0x18) = r0
01d450: *(u64 *)(r6 + 0x10) = r2
01d458: *(u64 *)(r6 + 0x8) = r4
01d460: *(u64 *)(r6 + 0x0) = r3
01d468: r1 = r7
01d470: goto +0x110 ; branch 0x1dcf8
01d478: *(u64 *)(r10 - 0x568) = r2
01d480: *(u64 *)(r10 - 0x560) = r1
01d488: *(u64 *)(r10 - 0x530) = r6
01d490: r5 = 0x1
01d498: r8 = *(u64 *)(r10 - 0x288)
01d4a0: r1 = *(u64 *)(r10 - 0x290)
01d4a8: *(u64 *)(r10 - 0x558) = r1
01d4b0: r1 = *(u64 *)(r10 - 0x298)
01d4b8: *(u64 *)(r10 - 0x540) = r1
01d4c0: r1 = *(u64 *)(r10 - 0x2a0)
01d4c8: *(u64 *)(r10 - 0x548) = r1
01d4d0: r1 = *(u64 *)(r10 - 0x2a8)
01d4d8: *(u64 *)(r10 - 0x550) = r1
01d4e0: r6 = *(u64 *)(r10 - 0x2b0)
01d4e8: r1 = *(u64 *)(r10 - 0x2c0)
01d4f0: *(u64 *)(r10 - 0x570) = r1
01d4f8: r1 = *(u64 *)(r10 - 0x2c8)
01d500: *(u64 *)(r10 - 0x578) = r1
01d508: r1 = *(u64 *)(r10 - 0x2d0)
01d510: *(u64 *)(r10 - 0x538) = r1
01d518: w2 = *(u32 *)(r7 + 0x0)
01d520: r1 = r7
01d528: if r2 == 0x0 goto +0xd5 ; branch 0x1dbd8
01d530: if r2 == 0x1 goto +0x10 ; branch 0x1d5b8
01d538: if r2 == 0x2 goto +0xd ; branch 0x1d5a8
01d540: if r2 == 0x3 goto +0x4d ; branch 0x1d7b0
01d548: if r2 == 0x4 goto +0x17 ; branch 0x1d608
01d550: if r2 == 0x5 goto +0x4d ; branch 0x1d7c0
01d558: if r2 == 0x6 goto +0x1c ; branch 0x1d640
01d560: if r2 == 0x7 goto +0xc3 ; branch 0x1db80
01d568: if r2 == 0x8 goto +0xcc ; branch 0x1dbd0
01d570: if r2 == 0x9 goto +0x21 ; branch 0x1d680
01d578: if r2 == 0xa goto +0x22 ; branch 0x1d690
01d580: if r2 == 0xb goto +0x23 ; branch 0x1d6a0
01d588: if r2 == 0xc goto +0x1 ; branch 0x1d598
01d590: goto +0x23 ; branch 0x1d6b0
01d598: r5 = 0x7
01d5a0: goto +0xc6 ; branch 0x1dbd8
01d5a8: r7 = 0x1
01d5b0: goto +0x42 ; branch 0x1d7c8
01d5b8: r5 = 0x2
01d5c0: r2 = 0x0
01d5c8: *(u64 *)(r10 - 0x580) = r2
01d5d0: r2 = r1
01d5d8: r2 += 0x10
01d5e0: *(u64 *)(r10 - 0x588) = r2
01d5e8: r3 = 0x0
01d5f0: r2 = 0x0
01d5f8: r7 = 0x0
01d600: goto +0x40 ; branch 0x1d808
01d608: r7 = 0x2
01d610: r3 = 0x1
01d618: r2 = 0x0
01d620: *(u64 *)(r10 - 0x580) = r2
01d628: r2 = r1
01d630: r2 += 0x10
01d638: goto +0x6 ; branch 0x1d670
01d640: r7 = 0x4
01d648: r3 = 0x0
01d650: r2 = 0x1
01d658: *(u64 *)(r10 - 0x580) = r2
01d660: r2 = 0x9a530 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/processor/edition/convert_master_edition'
01d670: *(u64 *)(r10 - 0x588) = r2
01d678: goto +0x2f ; branch 0x1d7f8
01d680: r5 = 0x0
01d688: goto +0xa9 ; branch 0x1dbd8
01d690: r5 = 0x5
01d698: goto +0xa7 ; branch 0x1dbd8
01d6a0: r5 = 0x6
01d6a8: goto +0xa5 ; branch 0x1dbd8
01d6b0: if r2 != 0xd goto +0xc4 ; branch 0x1dcd8
01d6b8: *(u64 *)(r10 - 0x288) = r8
01d6c0: r2 = *(u64 *)(r10 - 0x558)
01d6c8: *(u64 *)(r10 - 0x290) = r2
01d6d0: r2 = *(u64 *)(r10 - 0x540)
01d6d8: *(u64 *)(r10 - 0x298) = r2
01d6e0: r2 = *(u64 *)(r10 - 0x548)
01d6e8: *(u64 *)(r10 - 0x2a0) = r2
01d6f0: r2 = *(u64 *)(r10 - 0x550)
01d6f8: *(u64 *)(r10 - 0x2a8) = r2
01d700: *(u64 *)(r10 - 0x2b0) = r6
01d708: r2 = *(u64 *)(r10 - 0x560)
01d710: *(u64 *)(r10 - 0x2b8) = r2
01d718: r2 = *(u64 *)(r10 - 0x570)
01d720: *(u64 *)(r10 - 0x2c0) = r2
01d728: r2 = *(u64 *)(r10 - 0x578)
01d730: *(u64 *)(r10 - 0x2c8) = r2
01d738: r2 = *(u64 *)(r10 - 0x538)
01d740: *(u64 *)(r10 - 0x2d0) = r2
01d748: *(u64 *)(r10 - 0x2d8) = r0
01d750: r2 = *(u64 *)(r10 - 0x568)
01d758: *(u64 *)(r10 - 0x2e0) = r2
01d760: *(u64 *)(r10 - 0x2e8) = r4
01d768: *(u64 *)(r10 - 0x2f0) = r3
01d770: r6 = r1
01d778: r3 = r10
01d780: r3 += -0x2f0
01d788: r1 = *(u64 *)(r10 - 0x530)
01d790: r2 = r9
01d798: r4 = 0x1
01d7a0: r5 = 0x0
01d7a8: goto +0xa2 ; branch 0x1dcc0
01d7b0: r5 = 0x3
01d7b8: goto +0x83 ; branch 0x1dbd8
01d7c0: r7 = 0x3
01d7c8: r2 = 0x0
01d7d0: *(u64 *)(r10 - 0x580) = r2
01d7d8: r2 = r1
01d7e0: r2 += 0x10
01d7e8: *(u64 *)(r10 - 0x588) = r2
01d7f0: r3 = 0x0
01d7f8: r5 = 0x0
01d800: r2 = 0x0
01d808: if r0 != 0x0 goto +0x3 ; branch 0x1d828
01d810: r2 = 0x9400000000 ll
01d820: goto +0x98 ; branch 0x1dce8
01d828: *(u64 *)(r10 - 0x598) = r2
01d830: r2 = *(u64 *)(r10 - 0x538)
01d838: if r2 != 0x0 goto +0x3 ; branch 0x1d858
01d840: r2 = 0x9500000000 ll
01d850: goto +0x92 ; branch 0x1dce8
01d858: *(u64 *)(r10 - 0x5c0) = r5
01d860: *(u64 *)(r10 - 0x5b8) = r3
01d868: *(u64 *)(r10 - 0x5a0) = r0
01d870: *(u64 *)(r10 - 0x5b0) = r4
01d878: *(u64 *)(r10 - 0x590) = r1
01d880: r1 = *(u64 *)(r1 + 0x8)
01d888: *(u64 *)(r10 - 0x5a8) = r1
01d890: r1 = r10
01d898: r1 += -0x2f0
01d8a0: r2 = *(u64 *)(r10 - 0x540)
01d8a8: call 0xb1a2 ; call 0x765c0 / window 773
01d8b0: w1 = *(u32 *)(r10 - 0x2f0)
01d8b8: if r1 != 0x16 goto +0x4c ; branch 0x1db20
01d8c0: r1 = r10
01d8c8: r1 += -0x2f0
01d8d0: r2 = *(u64 *)(r10 - 0x548)
01d8d8: call 0xb19c ; call 0x765c0 / window 773
01d8e0: w1 = *(u32 *)(r10 - 0x2f0)
01d8e8: if r1 == 0x16 goto +0x1 ; branch 0x1d8f8
01d8f0: goto +0x45 ; branch 0x1db20
01d8f8: r1 = r10
01d900: r1 += -0x2f0
01d908: r2 = r6
01d910: r3 = r9
01d918: call -0x1b9e ; call 0xfc30 / window 275
01d920: w1 = *(u32 *)(r10 - 0x2f0)
01d928: if r1 == 0x16 goto +0x1 ; branch 0x1d938
01d930: goto +0x3d ; branch 0x1db20
01d938: r1 = r10
01d940: r1 += -0x2f0
01d948: r9 = *(u64 *)(r10 - 0x550)
01d950: r2 = r9
01d958: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
01d968: r4 = 0x2
01d970: call -0x1ba6 ; call 0xfc48 / window 276
01d978: w1 = *(u32 *)(r10 - 0x2f0)
01d980: if r1 == 0x16 goto +0x1 ; branch 0x1d990
01d988: goto +0x32 ; branch 0x1db20
01d990: r1 = r10
01d998: r1 += -0x2f0
01d9a0: r2 = *(u64 *)(r10 - 0x5a0)
01d9a8: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
01d9b8: r4 = 0x2
01d9c0: call -0x1bb0 ; call 0xfc48 / window 276
01d9c8: w1 = *(u32 *)(r10 - 0x2f0)
01d9d0: if r1 == 0x16 goto +0x1 ; branch 0x1d9e0
01d9d8: goto +0x28 ; branch 0x1db20
01d9e0: r1 = *(u64 *)(r10 - 0x558)
01d9e8: r1 = *(u64 *)(r1 + 0x0)
01d9f0: r2 = 0x998d8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
01da00: call 0xb17d ; call 0x765f0 / window 774
01da08: if r0 != 0x0 goto +0x1 ; branch 0x1da18
01da10: goto +0x5e ; branch 0x1dd08
01da18: r1 = *(u64 *)(r8 + 0x0)
01da20: r2 = 0x999b8 ll ; data b"\x06\xa7\xd5\x17\x18{\xd1f5\xda\xd4\x04U\xfd\xc2\xc0\xc1$\xc6\x8f!Vu\xa5\xdb\xba\xcb_\x08\x00\x00\x00\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsu"
01da30: call 0xb177 ; call 0x765f0 / window 774
01da38: if r0 != 0x0 goto +0x1 ; branch 0x1da48
01da40: goto +0x58 ; branch 0x1dd08
01da48: r1 = r10
01da50: r1 += -0x2f0
01da58: r2 = *(u64 *)(r10 - 0x538)
01da60: call -0x1bb0 ; call 0xfce8 / window 277
01da68: w1 = *(u32 *)(r10 - 0x2f0)
01da70: if r1 == 0x16 goto +0x1 ; branch 0x1da80
01da78: goto +0x14 ; branch 0x1db20
01da80: r1 = r10
01da88: r1 += -0x2f0
01da90: r2 = r6
01da98: call 0x5483 ; call 0x47eb8 / window 419
01daa0: w8 = *(u32 *)(r10 - 0x1e8)
01daa8: if r8 != 0x2 goto +0x50 ; branch 0x1dd30
01dab0: r1 = *(u64 *)(r10 - 0x2d8)
01dab8: *(u64 *)(r10 - 0x3e0) = r1
01dac0: r2 = *(u64 *)(r10 - 0x2e0)
01dac8: *(u64 *)(r10 - 0x3e8) = r2
01dad0: r3 = *(u64 *)(r10 - 0x2e8)
01dad8: *(u64 *)(r10 - 0x3f0) = r3
01dae0: r4 = *(u64 *)(r10 - 0x2f0)
01dae8: *(u64 *)(r10 - 0x3f8) = r4
01daf0: r5 = *(u64 *)(r10 - 0x530)
01daf8: *(u64 *)(r5 + 0x18) = r1
01db00: *(u64 *)(r5 + 0x10) = r2
01db08: *(u64 *)(r5 + 0x8) = r3
01db10: *(u64 *)(r5 + 0x0) = r4
01db18: goto +0xa ; branch 0x1db70
01db20: w2 = *(u32 *)(r10 - 0x2d4)
01db28: r3 = *(u64 *)(r10 - 0x530)
01db30: *(u32 *)(r3 + 0x1c) = w2
01db38: r2 = *(u64 *)(r10 - 0x2dc)
01db40: *(u64 *)(r3 + 0x14) = r2
01db48: r2 = *(u64 *)(r10 - 0x2e4)
01db50: *(u64 *)(r3 + 0xc) = r2
01db58: r2 = *(u64 *)(r10 - 0x2ec)
01db60: *(u64 *)(r3 + 0x4) = r2
01db68: *(u32 *)(r3 + 0x0) = w1
01db70: r1 = *(u64 *)(r10 - 0x590)
01db78: goto +0x2f ; branch 0x1dcf8
01db80: r7 = 0x5
01db88: r2 = 0x1
01db90: r3 = 0x0
01db98: *(u64 *)(r10 - 0x580) = r3
01dba0: r3 = r1
01dba8: r3 += 0x30
01dbb0: *(u64 *)(r10 - 0x588) = r3
01dbb8: r3 = 0x0
01dbc0: r5 = 0x0
01dbc8: goto -0x79 ; branch 0x1d808
01dbd0: r5 = 0x4
01dbd8: *(u64 *)(r10 - 0x288) = r8
01dbe0: r2 = *(u64 *)(r10 - 0x558)
01dbe8: *(u64 *)(r10 - 0x290) = r2
01dbf0: r2 = *(u64 *)(r10 - 0x540)
01dbf8: *(u64 *)(r10 - 0x298) = r2
01dc00: r2 = *(u64 *)(r10 - 0x548)
01dc08: *(u64 *)(r10 - 0x2a0) = r2
01dc10: r2 = *(u64 *)(r10 - 0x550)
01dc18: *(u64 *)(r10 - 0x2a8) = r2
01dc20: *(u64 *)(r10 - 0x2b0) = r6
01dc28: r2 = *(u64 *)(r10 - 0x560)
01dc30: *(u64 *)(r10 - 0x2b8) = r2
01dc38: r2 = *(u64 *)(r10 - 0x570)
01dc40: *(u64 *)(r10 - 0x2c0) = r2
01dc48: r2 = *(u64 *)(r10 - 0x578)
01dc50: *(u64 *)(r10 - 0x2c8) = r2
01dc58: r2 = *(u64 *)(r10 - 0x538)
01dc60: *(u64 *)(r10 - 0x2d0) = r2
01dc68: *(u64 *)(r10 - 0x2d8) = r0
01dc70: r2 = *(u64 *)(r10 - 0x568)
01dc78: *(u64 *)(r10 - 0x2e0) = r2
01dc80: *(u64 *)(r10 - 0x2e8) = r4
01dc88: *(u64 *)(r10 - 0x2f0) = r3
01dc90: r6 = r1
01dc98: r3 = r10
01dca0: r3 += -0x2f0
01dca8: r1 = *(u64 *)(r10 - 0x530)
01dcb0: r2 = r9
01dcb8: r4 = 0x0
01dcc0: call 0x30e ; call 0x1f538 / window 312
01dcc8: r1 = r6
01dcd0: goto +0x4 ; branch 0x1dcf8
01dcd8: r2 = 0xa900000000 ll
01dce8: r3 = *(u64 *)(r10 - 0x530)
01dcf0: *(u64 *)(r3 + 0x0) = r2
01dcf8: call -0x3516 ; call 0x3450 / window 69
01dd00: exit
01dd08: r1 = 0x9a00000000 ll
01dd18: r2 = *(u64 *)(r10 - 0x530)
01dd20: *(u64 *)(r2 + 0x0) = r1
01dd28: goto -0x38 ; branch 0x1db70
01dd30: r6 = r10
01dd38: r6 += -0x3f8
01dd40: r2 = r10
01dd48: r2 += -0x2f0
01dd50: r1 = r6
01dd58: r3 = 0x108
01dd60: call 0xf625 ; call 0x98e90 / window 1246
01dd68: r1 = r10
01dd70: r1 += -0x41c
01dd78: r2 = r10
01dd80: r2 += -0x1e4
01dd88: r3 = 0x24
01dd90: call 0xf61f ; call 0x98e90 / window 1246
01dd98: r1 = r10
01dda0: r1 += -0x528
01dda8: r2 = r6
01ddb0: r3 = 0x108
01ddb8: call 0xf61a ; call 0x98e90 / window 1246
01ddc0: *(u32 *)(r10 - 0x420) = w8
01ddc8: r2 = *(u64 *)(r9 + 0x0)
01ddd0: r1 = r10
01ddd8: r1 += -0x504
01dde0: call -0x361b ; call 0x2d10 / window 44
01dde8: if r0 != 0x0 goto +0x1 ; branch 0x1ddf8
01ddf0: goto +0x5 ; branch 0x1de20
01ddf8: r1 = 0xf00000000 ll
01de08: r2 = *(u64 *)(r10 - 0x530)
01de10: *(u64 *)(r2 + 0x0) = r1
01de18: goto +0x298 ; branch 0x1f2e0
01de20: r1 = r10
01de28: r1 += -0x2f0
01de30: r2 = *(u64 *)(r10 - 0x5a0)
01de38: call 0xce9e ; call 0x85330 / window 985
01de40: w1 = *(u32 *)(r10 - 0x2f0)
01de48: if r1 == 0x16 goto +0x1 ; branch 0x1de58
01de50: goto +0x287 ; branch 0x1f290
01de58: r1 = *(u64 *)(r10 - 0x2e0)
01de60: *(u64 *)(r10 - 0x5c8) = r1
01de68: r1 = *(u64 *)(r10 - 0x2e8)
01de70: r3 = *(u64 *)(r1 + 0x8)
01de78: r2 = *(u64 *)(r1 + 0x0)
01de80: r1 = r10
01de88: r1 += -0x2f0
01de90: call 0xbc62 ; call 0x7c1a8 / window 851
01de98: w8 = *(u32 *)(r10 - 0x298)
01dea0: if r8 == 0x2 goto +0x33 ; branch 0x1e040
01dea8: r6 = r10
01deb0: r6 += -0x130
01deb8: r2 = r10
01dec0: r2 += -0x2f0
01dec8: r1 = r6
01ded0: r3 = 0x58
01ded8: call 0xf5f6 ; call 0x98e90 / window 1246
01dee0: r1 = r10
01dee8: r1 += -0x3ac
01def0: r2 = r10
01def8: r2 += -0x294
01df00: r3 = 0x64
01df08: call 0xf5f0 ; call 0x98e90 / window 1246
01df10: r1 = r10
01df18: r1 += -0x58
01df20: r2 = r6
01df28: r3 = 0x58
01df30: call 0xf5eb ; call 0x98e90 / window 1246
01df38: r6 = r10
01df40: r6 += -0x178
01df48: r2 = r10
01df50: r2 += -0x48
01df58: r1 = r6
01df60: r3 = 0x48
01df68: call 0xf5e4 ; call 0x98e90 / window 1246
01df70: r9 = r10
01df78: r9 += -0x1c0
01df80: r1 = r9
01df88: r2 = r6
01df90: r3 = 0x48
01df98: call 0xf5de ; call 0x98e90 / window 1246
01dfa0: r1 = r10
01dfa8: r1 += -0x3f8
01dfb0: r2 = r9
01dfb8: r3 = 0x48
01dfc0: call 0xf5d9 ; call 0x98e90 / window 1246
01dfc8: *(u32 *)(r10 - 0x3b0) = w8
01dfd0: r2 = *(u64 *)(r10 - 0x5c8)
01dfd8: r1 = *(u64 *)(r2 + 0x0)
01dfe0: r1 += -0x1
01dfe8: *(u64 *)(r2 + 0x0) = r1
01dff0: r1 = *(u64 *)(r10 - 0x548)
01dff8: r2 = *(u64 *)(r1 + 0x0)
01e000: r1 = r10
01e008: r1 += -0x3d8
01e010: call -0x3661 ; call 0x2d10 / window 44
01e018: if r0 != 0x0 goto +0x1 ; branch 0x1e028
01e020: goto +0x1a ; branch 0x1e0f8
01e028: r1 = 0x3900000000 ll
01e038: goto -0x47 ; branch 0x1de08
01e040: r1 = *(u64 *)(r10 - 0x2d8)
01e048: *(u64 *)(r10 - 0x1a8) = r1
01e050: r1 = *(u64 *)(r10 - 0x2e0)
01e058: *(u64 *)(r10 - 0x1b0) = r1
01e060: r1 = *(u64 *)(r10 - 0x2e8)
01e068: *(u64 *)(r10 - 0x170) = r1
01e070: *(u64 *)(r10 - 0x1b8) = r1
01e078: r1 = *(u64 *)(r10 - 0x2f0)
01e080: *(u64 *)(r10 - 0x178) = r1
01e088: *(u64 *)(r10 - 0x1c0) = r1
01e090: r1 = *(u64 *)(r10 - 0x1a8)
01e098: r2 = *(u64 *)(r10 - 0x530)
01e0a0: *(u64 *)(r2 + 0x18) = r1
01e0a8: r1 = *(u64 *)(r10 - 0x1b0)
01e0b0: *(u64 *)(r2 + 0x10) = r1
01e0b8: r1 = *(u64 *)(r10 - 0x1b8)
01e0c0: *(u64 *)(r2 + 0x8) = r1
01e0c8: r1 = *(u64 *)(r10 - 0x1c0)
01e0d0: *(u64 *)(r2 + 0x0) = r1
01e0d8: r2 = *(u64 *)(r10 - 0x5c8)
01e0e0: r1 = *(u64 *)(r2 + 0x0)
01e0e8: r1 += -0x1
01e0f0: goto -0x5d ; branch 0x1de10
01e0f8: w1 = *(u32 *)(r10 - 0x474)
01e100: if r1 == 0x6 goto +0x4 ; branch 0x1e128
01e108: r2 = 0xfffffffe ll
01e118: r1 &= r2
01e120: if r1 == 0x4 goto +0x27 ; branch 0x1e260
01e128: r1 = *(u64 *)(r10 - 0x580)
01e130: if r1 != 0x0 goto +0x1 ; branch 0x1e140
01e138: goto +0x27 ; branch 0x1e278
01e140: r1 = *(u64 *)(r10 - 0x560)
01e148: r4 = *(u64 *)(r1 + 0x0)
01e150: r1 = *(u64 *)(r10 - 0x5a0)
01e158: r3 = *(u64 *)(r1 + 0x0)
01e160: r1 = *(u64 *)(r10 - 0x538)
01e168: r2 = *(u64 *)(r1 + 0x0)
01e170: r1 = *(u64 *)(r10 - 0x548)
01e178: r1 = *(u64 *)(r1 + 0x0)
01e180: r5 = 0x0
01e188: *(u64 *)(r10 - 0xff0) = r5
01e190: r5 = *(u64 *)(r10 - 0x5a8)
01e198: *(u64 *)(r10 - 0xfe8) = r5
01e1a0: r5 = 0x995a8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
01e1b0: *(u64 *)(r10 - 0xff8) = r5
01e1b8: *(u64 *)(r10 - 0x1000) = r1
01e1c0: r1 = r10
01e1c8: r1 += -0x2f0
01e1d0: r5 = r10
01e1d8: call 0xbfb7 ; call 0x7df98 / window 861
01e1e0: r8 = *(u64 *)(r10 - 0x2c8)
01e1e8: if r8 != 0x0 goto +0x14 ; branch 0x1e290
01e1f0: r1 = *(u64 *)(r10 - 0x2d8)
01e1f8: *(u64 *)(r10 - 0x68) = r1
01e200: r2 = *(u64 *)(r10 - 0x2e0)
01e208: *(u64 *)(r10 - 0x70) = r2
01e210: r3 = *(u64 *)(r10 - 0x2e8)
01e218: *(u64 *)(r10 - 0x78) = r3
01e220: r4 = *(u64 *)(r10 - 0x2f0)
01e228: *(u64 *)(r10 - 0x80) = r4
01e230: r5 = *(u64 *)(r10 - 0x530)
01e238: *(u64 *)(r5 + 0x18) = r1
01e240: *(u64 *)(r5 + 0x10) = r2
01e248: *(u64 *)(r5 + 0x8) = r3
01e250: *(u64 *)(r5 + 0x0) = r4
01e258: goto +0x210 ; branch 0x1f2e0
01e260: r1 = *(u64 *)(r10 - 0x580)
01e268: if r1 != 0x0 goto +0x1 ; branch 0x1e278
01e270: goto +0x53 ; branch 0x1e510
01e278: r1 = 0xa500000000 ll
01e288: goto -0x91 ; branch 0x1de08
01e290: r6 = r10
01e298: r6 += -0x80
01e2a0: r2 = r10
01e2a8: r2 += -0x2f0
01e2b0: r1 = r6
01e2b8: r3 = 0x28
01e2c0: call 0xf579 ; call 0x98e90 / window 1246
01e2c8: r1 = *(u64 *)(r10 - 0x2c0)
01e2d0: *(u64 *)(r10 - 0x100) = r1
01e2d8: r1 = *(u64 *)(r10 - 0x2b8)
01e2e0: *(u64 *)(r10 - 0xf8) = r1
01e2e8: r1 = *(u64 *)(r10 - 0x2b0)
01e2f0: *(u64 *)(r10 - 0xf0) = r1
01e2f8: r1 = *(u64 *)(r10 - 0x2a8)
01e300: *(u64 *)(r10 - 0xe8) = r1
01e308: r1 = r10
01e310: r1 += -0x130
01e318: *(u64 *)(r10 - 0x540) = r1
01e320: r2 = r6
01e328: r3 = 0x28
01e330: call 0xf56b ; call 0x98e90 / window 1246
01e338: *(u64 *)(r10 - 0x108) = r8
01e340: r6 = r10
01e348: r6 += -0x1c0
01e350: r1 = r6
01e358: r2 = *(u64 *)(r10 - 0x5a0)
01e360: call -0x2772 ; call 0xa7d8 / window 217
01e368: r9 = r10
01e370: r9 += -0x178
01e378: r1 = r9
01e380: r2 = *(u64 *)(r10 - 0x560)
01e388: call -0x2777 ; call 0xa7d8 / window 217
01e390: r7 = r10
01e398: r7 += -0x58
01e3a0: r1 = r7
01e3a8: r2 = *(u64 *)(r10 - 0x548)
01e3b0: call -0x277c ; call 0xa7d8 / window 217
01e3b8: r8 = r10
01e3c0: r8 += -0x2f0
01e3c8: r1 = r8
01e3d0: r2 = r6
01e3d8: r3 = 0x30
01e3e0: call 0xf555 ; call 0x98e90 / window 1246
01e3e8: r1 = r10
01e3f0: r1 += -0x2c0
01e3f8: r2 = r9
01e400: r3 = 0x30
01e408: call 0xf550 ; call 0x98e90 / window 1246
01e410: r1 = r10
01e418: r1 += -0x290
01e420: r2 = r7
01e428: r3 = 0x30
01e430: call 0xf54b ; call 0x98e90 / window 1246
01e438: r1 = r10
01e440: r1 += -0xa0
01e448: r2 = *(u64 *)(r10 - 0x540)
01e450: r3 = r8
01e458: r4 = 0x3
01e460: call 0xcfe6 ; call 0x86398 / window 996
01e468: w1 = *(u32 *)(r10 - 0xa0)
01e470: if r1 == 0x16 goto +0x1 ; branch 0x1e480
01e478: goto +0xb9 ; branch 0x1ea48
01e480: r1 = r10
01e488: r1 += -0x2f0
01e490: call -0x35cd ; call 0x3630 / window 76
01e498: r1 = r10
01e4a0: r1 += -0x130
01e4a8: call -0x3671 ; call 0x3128 / window 61
01e4b0: r1 = *(u64 *)(r10 - 0x5b8)
01e4b8: if r1 != 0x0 goto +0x39 ; branch 0x1e688
01e4c0: w1 = *(u32 *)(r10 - 0x474)
01e4c8: if r1 == 0x6 goto +0x4 ; branch 0x1e4f0
01e4d0: r2 = 0xfffffffe ll
01e4e0: r1 &= r2
01e4e8: if r1 == 0x4 goto +0x1ce ; branch 0x1f360
01e4f0: r1 = 0x16
01e4f8: r2 = *(u64 *)(r10 - 0x530)
01e500: *(u32 *)(r2 + 0x0) = w1
01e508: goto +0x1ba ; branch 0x1f2e0
01e510: r1 = *(u64 *)(r10 - 0x568)
01e518: if r1 == 0x0 goto +0x46 ; branch 0x1e750
01e520: r1 = *(u64 *)(r10 - 0x5a0)
01e528: r3 = *(u64 *)(r1 + 0x0)
01e530: r1 = *(u64 *)(r10 - 0x550)
01e538: r2 = *(u64 *)(r1 + 0x0)
01e540: r1 = r10
01e548: r1 += -0x2f0
01e550: call -0x1a74 ; call 0x111b8 / window 294
01e558: r1 = *(u64 *)(r10 - 0x2d8)
01e560: *(u64 *)(r10 - 0x160) = r1
01e568: r1 = *(u64 *)(r10 - 0x2e0)
01e570: *(u64 *)(r10 - 0x168) = r1
01e578: r1 = *(u64 *)(r10 - 0x2e8)
01e580: *(u64 *)(r10 - 0x170) = r1
01e588: r1 = *(u64 *)(r10 - 0x2f0)
01e590: *(u64 *)(r10 - 0x178) = r1
01e598: r1 = *(u64 *)(r10 - 0x568)
01e5a0: r2 = *(u64 *)(r1 + 0x0)
01e5a8: r1 = r10
01e5b0: r1 += -0x178
01e5b8: call 0xb006 ; call 0x765f0 / window 774
01e5c0: if r0 == 0x0 goto +0x1a7 ; branch 0x1f300
01e5c8: r1 = r10
01e5d0: r1 += -0x2f0
01e5d8: r2 = *(u64 *)(r10 - 0x568)
01e5e0: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
01e5f0: call -0x1d39 ; call 0xfc30 / window 275
01e5f8: w1 = *(u32 *)(r10 - 0x2f0)
01e600: if r1 == 0x16 goto +0x1 ; branch 0x1e610
01e608: goto +0x1a1 ; branch 0x1f318
01e610: r1 = r10
01e618: r1 += -0x2f0
01e620: r2 = *(u64 *)(r10 - 0x568)
01e628: call 0x492d ; call 0x42f98 / window 368
01e630: r8 = *(u64 *)(r10 - 0x2e0)
01e638: if r8 != 0x2 goto +0x92 ; branch 0x1ead0
01e640: r1 = *(u64 *)(r10 - 0x2c0)
01e648: *(u64 *)(r10 - 0x118) = r1
01e650: r2 = *(u64 *)(r10 - 0x2c8)
01e658: *(u64 *)(r10 - 0x120) = r2
01e660: r3 = *(u64 *)(r10 - 0x2d0)
01e668: *(u64 *)(r10 - 0x128) = r3
01e670: r4 = *(u64 *)(r10 - 0x2d8)
01e678: *(u64 *)(r10 - 0x130) = r4
01e680: goto -0x8b ; branch 0x1e230
01e688: r1 = *(u64 *)(r10 - 0x5b0)
01e690: if r1 == 0x0 goto +0x1c8 ; branch 0x1f4d8
01e698: w1 = *(u32 *)(r10 - 0x370)
01e6a0: if r1 == 0x1 goto +0x1 ; branch 0x1e6b0
01e6a8: goto +0x17 ; branch 0x1e768
01e6b0: r1 = *(u64 *)(r10 - 0x354)
01e6b8: *(u64 *)(r10 - 0x2d8) = r1
01e6c0: r1 = *(u64 *)(r10 - 0x35c)
01e6c8: *(u64 *)(r10 - 0x2e0) = r1
01e6d0: r1 = *(u64 *)(r10 - 0x364)
01e6d8: *(u64 *)(r10 - 0x2e8) = r1
01e6e0: r1 = *(u64 *)(r10 - 0x36c)
01e6e8: *(u64 *)(r10 - 0x2f0) = r1
01e6f0: r1 = r10
01e6f8: r1 += -0x2f0
01e700: *(u64 *)(r10 - 0x130) = r1
01e708: r1 = r10
01e710: r1 += -0x130
01e718: r2 = *(u64 *)(r10 - 0x5b0)
01e720: call -0x374a ; call 0x2cd8 / window 42
01e728: if r0 != 0x0 goto +0x1 ; branch 0x1e738
01e730: goto -0x4f ; branch 0x1e4c0
01e738: r1 = 0xbc00000000 ll
01e748: goto -0x129 ; branch 0x1de08
01e750: r1 = 0x9f00000000 ll
01e760: goto -0x12c ; branch 0x1de08
01e768: r1 = *(u64 *)(r10 - 0x5b0)
01e770: r4 = *(u64 *)(r1 + 0x0)
01e778: r1 = *(u64 *)(r10 - 0x5a0)
01e780: r3 = *(u64 *)(r1 + 0x0)
01e788: r1 = *(u64 *)(r10 - 0x538)
01e790: r2 = *(u64 *)(r1 + 0x0)
01e798: r1 = *(u64 *)(r10 - 0x548)
01e7a0: r1 = *(u64 *)(r1 + 0x0)
01e7a8: r5 = 0x995a8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
01e7b8: *(u64 *)(r10 - 0xff0) = r5
01e7c0: r5 = 0x0
01e7c8: *(u64 *)(r10 - 0xfe8) = r5
01e7d0: *(u64 *)(r10 - 0xff8) = r1
01e7d8: r1 = 0x3
01e7e0: *(u64 *)(r10 - 0x1000) = r1
01e7e8: r1 = r10
01e7f0: r1 += -0x2f0
01e7f8: r5 = r10
01e800: call 0xc03e ; call 0x7e9f8 / window 863
01e808: r8 = *(u64 *)(r10 - 0x2c8)
01e810: if r8 != 0x0 goto +0x1 ; branch 0x1e820
01e818: goto -0xc6 ; branch 0x1e1f0
01e820: r6 = r10
01e828: r6 += -0x80
01e830: r2 = r10
01e838: r2 += -0x2f0
01e840: r1 = r6
01e848: r3 = 0x28
01e850: call 0xf4c7 ; call 0x98e90 / window 1246
01e858: r1 = *(u64 *)(r10 - 0x2c0)
01e860: *(u64 *)(r10 - 0x100) = r1
01e868: r1 = *(u64 *)(r10 - 0x2b8)
01e870: *(u64 *)(r10 - 0xf8) = r1
01e878: r1 = *(u64 *)(r10 - 0x2b0)
01e880: *(u64 *)(r10 - 0xf0) = r1
01e888: r1 = *(u64 *)(r10 - 0x2a8)
01e890: *(u64 *)(r10 - 0xe8) = r1
01e898: r1 = r10
01e8a0: r1 += -0x130
01e8a8: *(u64 *)(r10 - 0x540) = r1
01e8b0: r2 = r6
01e8b8: r3 = 0x28
01e8c0: call 0xf4b9 ; call 0x98e90 / window 1246
01e8c8: *(u64 *)(r10 - 0x108) = r8
01e8d0: r9 = r10
01e8d8: r9 += -0x1c0
01e8e0: r1 = r9
01e8e8: r2 = *(u64 *)(r10 - 0x5a0)
01e8f0: call -0x2824 ; call 0xa7d8 / window 217
01e8f8: r6 = r10
01e900: r6 += -0x178
01e908: r1 = r6
01e910: r2 = *(u64 *)(r10 - 0x560)
01e918: call -0x2829 ; call 0xa7d8 / window 217
01e920: r8 = r10
01e928: r8 += -0x58
01e930: r1 = r8
01e938: r2 = *(u64 *)(r10 - 0x548)
01e940: call -0x282e ; call 0xa7d8 / window 217
01e948: r7 = r10
01e950: r7 += -0x2f0
01e958: r1 = r7
01e960: r2 = r9
01e968: r3 = 0x30
01e970: call 0xf4a3 ; call 0x98e90 / window 1246
01e978: r1 = r10
01e980: r1 += -0x2c0
01e988: r2 = r6
01e990: r3 = 0x30
01e998: call 0xf49e ; call 0x98e90 / window 1246
01e9a0: r1 = r10
01e9a8: r1 += -0x290
01e9b0: r2 = r8
01e9b8: r3 = 0x30
01e9c0: call 0xf499 ; call 0x98e90 / window 1246
01e9c8: r1 = r10
01e9d0: r1 += -0xa0
01e9d8: r2 = *(u64 *)(r10 - 0x540)
01e9e0: r3 = r7
01e9e8: r4 = 0x3
01e9f0: call 0xcf34 ; call 0x86398 / window 996
01e9f8: w1 = *(u32 *)(r10 - 0xa0)
01ea00: if r1 == 0x16 goto +0x1 ; branch 0x1ea10
01ea08: goto +0x7 ; branch 0x1ea48
01ea10: r1 = r10
01ea18: r1 += -0x2f0
01ea20: call -0x367f ; call 0x3630 / window 76
01ea28: r1 = r10
01ea30: r1 += -0x130
01ea38: call -0x3723 ; call 0x3128 / window 61
01ea40: goto -0xb1 ; branch 0x1e4c0
01ea48: w2 = *(u32 *)(r10 - 0x84)
01ea50: r3 = *(u64 *)(r10 - 0x530)
01ea58: *(u32 *)(r3 + 0x1c) = w2
01ea60: r2 = *(u64 *)(r10 - 0x8c)
01ea68: *(u64 *)(r3 + 0x14) = r2
01ea70: r2 = *(u64 *)(r10 - 0x94)
01ea78: *(u64 *)(r3 + 0xc) = r2
01ea80: r2 = *(u64 *)(r10 - 0x9c)
01ea88: *(u64 *)(r3 + 0x4) = r2
01ea90: *(u32 *)(r3 + 0x0) = w1
01ea98: r1 = r10
01eaa0: r1 += -0x2f0
01eaa8: call -0x3690 ; call 0x3630 / window 76
01eab0: r1 = r10
01eab8: r1 += -0x130
01eac0: call -0x3734 ; call 0x3128 / window 61
01eac8: goto +0x102 ; branch 0x1f2e0
01ead0: r1 = *(u64 *)(r10 - 0x2e8)
01ead8: *(u64 *)(r10 - 0x78) = r1
01eae0: r1 = *(u64 *)(r10 - 0x2f0)
01eae8: *(u64 *)(r10 - 0x80) = r1
01eaf0: r1 = *(u64 *)(r10 - 0x2d8)
01eaf8: *(u64 *)(r10 - 0x130) = r1
01eb00: r1 = *(u64 *)(r10 - 0x2d0)
01eb08: *(u64 *)(r10 - 0x128) = r1
01eb10: r1 = *(u64 *)(r10 - 0x2c8)
01eb18: *(u64 *)(r10 - 0x120) = r1
01eb20: r1 = *(u64 *)(r10 - 0x2c0)
01eb28: *(u64 *)(r10 - 0x118) = r1
01eb30: r6 = r10
01eb38: r6 += -0x58
01eb40: r2 = r10
01eb48: r2 += -0x2b8
01eb50: r1 = r6
01eb58: r3 = 0x38
01eb60: call 0xf465 ; call 0x98e90 / window 1246
01eb68: r1 = *(u64 *)(r10 - 0x118)
01eb70: *(u64 *)(r10 - 0x1a8) = r1
01eb78: r2 = *(u64 *)(r10 - 0x120)
01eb80: *(u64 *)(r10 - 0x1b0) = r2
01eb88: r3 = *(u64 *)(r10 - 0x128)
01eb90: *(u64 *)(r10 - 0x1b8) = r3
01eb98: r4 = *(u64 *)(r10 - 0x130)
01eba0: *(u64 *)(r10 - 0x1c0) = r4
01eba8: r5 = *(u64 *)(r10 - 0x78)
01ebb0: *(u64 *)(r10 - 0x128) = r5
01ebb8: r5 = *(u64 *)(r10 - 0x80)
01ebc0: *(u64 *)(r10 - 0x130) = r5
01ebc8: *(u64 *)(r10 - 0x120) = r8
01ebd0: *(u64 *)(r10 - 0x118) = r4
01ebd8: *(u64 *)(r10 - 0x110) = r3
01ebe0: *(u64 *)(r10 - 0x108) = r2
01ebe8: *(u64 *)(r10 - 0x100) = r1
01ebf0: r1 = r10
01ebf8: r1 += -0xf8
01ec00: r2 = r6
01ec08: r3 = 0x38
01ec10: call 0xf44f ; call 0x98e90 / window 1246
01ec18: w1 = *(u32 *)(r10 - 0x420)
01ec20: if r1 != 0x0 goto +0x64 ; branch 0x1ef48
01ec28: w1 = *(u8 *)(r10 - 0x41c)
01ec30: if r1 == 0x0 goto +0x62 ; branch 0x1ef48
01ec38: r1 = *(u64 *)(r10 - 0x403)
01ec40: *(u64 *)(r10 - 0x68) = r1
01ec48: r1 = *(u64 *)(r10 - 0x40b)
01ec50: *(u64 *)(r10 - 0x70) = r1
01ec58: r1 = *(u64 *)(r10 - 0x413)
01ec60: *(u64 *)(r10 - 0x78) = r1
01ec68: r1 = *(u64 *)(r10 - 0x41b)
01ec70: *(u64 *)(r10 - 0x80) = r1
01ec78: r1 = *(u64 *)(r10 - 0x570)
01ec80: if r1 == 0x0 goto +0x10d ; branch 0x1f4f0
01ec88: r1 = *(u64 *)(r10 - 0x570)
01ec90: r1 = *(u64 *)(r1 + 0x0)
01ec98: r2 = r10
01eca0: r2 += -0x80
01eca8: call 0xaf28 ; call 0x765f0 / window 774
01ecb0: if r0 != 0x0 goto +0x1 ; branch 0x1ecc0
01ecb8: goto +0xc8 ; branch 0x1f300
01ecc0: r1 = r10
01ecc8: r1 += -0x2f0
01ecd0: r2 = *(u64 *)(r10 - 0x570)
01ecd8: r3 = 0x999d8 ll ; data b"\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsufficient tokens for transferAcco"
01ece8: call -0x1e18 ; call 0xfc30 / window 275
01ecf0: w1 = *(u32 *)(r10 - 0x2f0)
01ecf8: if r1 == 0x16 goto +0x1 ; branch 0x1ed08
01ed00: goto +0xc2 ; branch 0x1f318
01ed08: r1 = *(u64 *)(r10 - 0x578)
01ed10: if r1 == 0x0 goto +0x101 ; branch 0x1f520
01ed18: r1 = *(u64 *)(r10 - 0x578)
01ed20: r1 = *(u64 *)(r1 + 0x0)
01ed28: r2 = 0x999d8 ll ; data b"\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsufficient tokens for transferAcco"
01ed38: call 0xaf16 ; call 0x765f0 / window 774
01ed40: if r0 != 0x0 goto +0x1 ; branch 0x1ed50
01ed48: goto +0xb6 ; branch 0x1f300
01ed50: r2 = r10
01ed58: r2 += -0x420
01ed60: r1 = r10
01ed68: r1 += -0x178
01ed70: *(u64 *)(r10 - 0x578) = r1
01ed78: r3 = 0x28
01ed80: call 0xf421 ; call 0x98e90 / window 1246
01ed88: r6 = r10
01ed90: r6 += -0x58
01ed98: r1 = r6
01eda0: r2 = *(u64 *)(r10 - 0x588)
01eda8: call -0x2f1f ; call 0x74b8 / window 182
01edb0: r1 = *(u64 *)(r10 - 0x120)
01edb8: *(u64 *)(r10 - 0x580) = r1
01edc0: r8 = *(u64 *)(r10 - 0x118)
01edc8: r9 = r10
01edd0: r9 += -0x2f0
01edd8: r1 = r9
01ede0: r2 = r6
01ede8: r3 = 0x30
01edf0: call 0xf413 ; call 0x98e90 / window 1246
01edf8: r1 = *(u64 *)(r10 - 0x560)
01ee00: *(u64 *)(r10 - 0x2a8) = r1
01ee08: *(u64 *)(r10 - 0x2b8) = r8
01ee10: r1 = *(u64 *)(r10 - 0x580)
01ee18: *(u64 *)(r10 - 0x2c0) = r1
01ee20: *(u32 *)(r10 - 0x274) = w7
01ee28: r1 = 0x2
01ee30: *(u32 *)(r10 - 0x278) = w1
01ee38: r1 = *(u64 *)(r10 - 0x550)
01ee40: *(u64 *)(r10 - 0x280) = r1
01ee48: r1 = *(u64 *)(r10 - 0x570)
01ee50: *(u64 *)(r10 - 0x288) = r1
01ee58: r1 = *(u64 *)(r10 - 0x5a8)
01ee60: *(u64 *)(r10 - 0x290) = r1
01ee68: r6 = 0x0
01ee70: *(u64 *)(r10 - 0x2a0) = r6
01ee78: *(u64 *)(r10 - 0x2b0) = r6
01ee80: *(u64 *)(r10 - 0x298) = r6
01ee88: r1 = r10
01ee90: r1 += -0x270
01ee98: r2 = *(u64 *)(r10 - 0x578)
01eea0: r3 = 0x28
01eea8: call 0xf3fc ; call 0x98e90 / window 1246
01eeb0: *(u8 *)(r10 - 0x248) = w6
01eeb8: r1 = r10
01eec0: r1 += -0x1c0
01eec8: r2 = r9
01eed0: call 0x669e ; call 0x523c8 / window 445
01eed8: w1 = *(u32 *)(r10 - 0x1c0)
01eee0: if r1 == 0x16 goto +0x1 ; branch 0x1eef0
01eee8: goto +0xb2 ; branch 0x1f480
01eef0: r1 = r10
01eef8: r1 += -0x2f0
01ef00: r2 = *(u64 *)(r10 - 0x570)
01ef08: call 0xa65f ; call 0x72208 / window 729
01ef10: w1 = *(u32 *)(r10 - 0x2f0)
01ef18: if r1 == 0x16 goto +0x1 ; branch 0x1ef28
01ef20: goto +0x6d ; branch 0x1f290
01ef28: r1 = *(u64 *)(r10 - 0x2e0)
01ef30: *(u64 *)(r10 - 0x118) = r1
01ef38: r1 = *(u64 *)(r10 - 0x2e8)
01ef40: *(u64 *)(r10 - 0x120) = r1
01ef48: r1 = *(u64 *)(r10 - 0x5c0)
01ef50: *(u32 *)(r10 - 0x128) = w1
01ef58: r1 = 0x0
01ef60: r2 = *(u64 *)(r10 - 0x598)
01ef68: if r2 != 0x0 goto +0x1 ; branch 0x1ef78
01ef70: goto +0xd ; branch 0x1efe0
01ef78: r1 = *(u64 *)(r10 - 0x590)
01ef80: w1 = *(u32 *)(r1 + 0x0)
01ef88: if r1 != 0x7 goto +0xaf ; branch 0x1f508
01ef90: r2 = *(u64 *)(r10 - 0x590)
01ef98: r1 = *(u64 *)(r2 + 0x28)
01efa0: *(u64 *)(r10 - 0x2d8) = r1
01efa8: r1 = *(u64 *)(r2 + 0x20)
01efb0: *(u64 *)(r10 - 0x2e0) = r1
01efb8: r1 = *(u64 *)(r2 + 0x18)
01efc0: *(u64 *)(r10 - 0x2e8) = r1
01efc8: r1 = *(u64 *)(r2 + 0x10)
01efd0: *(u64 *)(r10 - 0x2f0) = r1
01efd8: r1 = 0x1
01efe0: *(u8 *)(r10 - 0xe8) = w1
01efe8: r1 = *(u64 *)(r10 - 0x2f0)
01eff0: *(u64 *)(r10 - 0xe7) = r1
01eff8: r1 = *(u64 *)(r10 - 0x2e8)
01f000: *(u64 *)(r10 - 0xdf) = r1
01f008: r1 = *(u64 *)(r10 - 0x2e0)
01f010: *(u64 *)(r10 - 0xd7) = r1
01f018: r1 = *(u64 *)(r10 - 0x2d8)
01f020: *(u64 *)(r10 - 0xcf) = r1
01f028: r1 = *(u64 *)(r10 - 0x560)
01f030: r1 = *(u64 *)(r1 + 0x0)
01f038: r2 = *(u64 *)(r1 + 0x18)
01f040: r3 = *(u64 *)(r1 + 0x10)
01f048: r4 = *(u64 *)(r1 + 0x8)
01f050: r1 = *(u64 *)(r1 + 0x0)
01f058: r5 = 0x1
01f060: *(u8 *)(r10 - 0x110) = w5
01f068: *(u64 *)(r10 - 0x10f) = r1
01f070: *(u64 *)(r10 - 0x107) = r4
01f078: *(u64 *)(r10 - 0xff) = r3
01f080: *(u64 *)(r10 - 0xf7) = r2
01f088: *(u32 *)(r10 - 0xec) = w7
01f090: r1 = r10
01f098: r1 += -0x2f0
01f0a0: r2 = r10
01f0a8: r2 += -0x130
01f0b0: r3 = *(u64 *)(r10 - 0x568)
01f0b8: r4 = *(u64 *)(r10 - 0x540)
01f0c0: r5 = *(u64 *)(r10 - 0x558)
01f0c8: call 0x52b0 ; call 0x48650 / window 422
01f0d0: w1 = *(u32 *)(r10 - 0x2f0)
01f0d8: if r1 != 0x16 goto +0x47 ; branch 0x1f318
01f0e0: r1 = *(u64 *)(r10 - 0x5b0)
01f0e8: if r1 == 0x0 goto +0x7d ; branch 0x1f4d8
01f0f0: r1 = r10
01f0f8: r1 += -0x2f0
01f100: r2 = *(u64 *)(r10 - 0x5b0)
01f108: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
01f118: call -0x1e9e ; call 0xfc30 / window 275
01f120: w1 = *(u32 *)(r10 - 0x2f0)
01f128: if r1 == 0x16 goto +0x1 ; branch 0x1f138
01f130: goto +0x3c ; branch 0x1f318
01f138: r7 = r10
01f140: r7 += -0x1c0
01f148: r1 = r7
01f150: r2 = *(u64 *)(r10 - 0x550)
01f158: call -0x2931 ; call 0xa7d8 / window 217
01f160: r8 = r10
01f168: r8 += -0x178
01f170: r1 = r8
01f178: r2 = *(u64 *)(r10 - 0x5a0)
01f180: call -0x2936 ; call 0xa7d8 / window 217
01f188: r6 = r10
01f190: r6 += -0x58
01f198: r1 = r6
01f1a0: r2 = *(u64 *)(r10 - 0x5b0)
01f1a8: call -0x293b ; call 0xa7d8 / window 217
01f1b0: r9 = r10
01f1b8: r9 += -0x2f0
01f1c0: r1 = r9
01f1c8: r2 = *(u64 *)(r10 - 0x538)
01f1d0: call -0x2940 ; call 0xa7d8 / window 217
01f1d8: w1 = *(u8 *)(r10 - 0x475)
01f1e0: w2 = *(u8 *)(r10 - 0x476)
01f1e8: *(u64 *)(r10 - 0xff8) = r2
01f1f0: *(u64 *)(r10 - 0xff0) = r1
01f1f8: *(u64 *)(r10 - 0x1000) = r9
01f200: r1 = r10
01f208: r1 += -0x80
01f210: r5 = r10
01f218: r2 = r7
01f220: r3 = r8
01f228: r4 = r6
01f230: call 0x6468 ; call 0x51578 / window 443
01f238: w1 = *(u32 *)(r10 - 0x80)
01f240: if r1 == 0x16 goto -0x221 ; branch 0x1e140
01f248: w2 = *(u32 *)(r10 - 0x64)
01f250: r3 = *(u64 *)(r10 - 0x530)
01f258: *(u32 *)(r3 + 0x1c) = w2
01f260: r2 = *(u64 *)(r10 - 0x6c)
01f268: *(u64 *)(r3 + 0x14) = r2
01f270: r2 = *(u64 *)(r10 - 0x74)
01f278: *(u64 *)(r3 + 0xc) = r2
01f280: r2 = *(u64 *)(r10 - 0x7c)
01f288: goto +0x46 ; branch 0x1f4c0
01f290: w2 = *(u32 *)(r10 - 0x2ec)
01f298: r3 = *(u64 *)(r10 - 0x2e8)
01f2a0: r4 = *(u64 *)(r10 - 0x2e0)
01f2a8: r5 = *(u64 *)(r10 - 0x2d8)
01f2b0: r0 = *(u64 *)(r10 - 0x530)
01f2b8: *(u64 *)(r0 + 0x18) = r5
01f2c0: *(u64 *)(r0 + 0x10) = r4
01f2c8: *(u64 *)(r0 + 0x8) = r3
01f2d0: *(u32 *)(r0 + 0x4) = w2
01f2d8: *(u32 *)(r0 + 0x0) = w1
01f2e0: r1 = r10
01f2e8: r1 += -0x4e0
01f2f0: call -0x384b ; call 0x30a0 / window 59
01f2f8: goto -0x2f2 ; branch 0x1db70
01f300: r1 = 0x9a00000000 ll
01f310: goto -0x2a2 ; branch 0x1de08
01f318: w2 = *(u32 *)(r10 - 0x2d4)
01f320: r3 = *(u64 *)(r10 - 0x530)
01f328: *(u32 *)(r3 + 0x1c) = w2
01f330: r2 = *(u64 *)(r10 - 0x2dc)
01f338: *(u64 *)(r3 + 0x14) = r2
01f340: r2 = *(u64 *)(r10 - 0x2e4)
01f348: *(u64 *)(r3 + 0xc) = r2
01f350: r2 = *(u64 *)(r10 - 0x2ec)
01f358: goto +0x2c ; branch 0x1f4c0
01f360: r1 = *(u64 *)(r10 - 0x5b0)
01f368: if r1 == 0x0 goto +0x2d ; branch 0x1f4d8
01f370: r7 = r10
01f378: r7 += -0x178
01f380: r1 = r7
01f388: r2 = *(u64 *)(r10 - 0x550)
01f390: call -0x2978 ; call 0xa7d8 / window 217
01f398: r8 = r10
01f3a0: r8 += -0x58
01f3a8: r1 = r8
01f3b0: r2 = *(u64 *)(r10 - 0x5a0)
01f3b8: call -0x297d ; call 0xa7d8 / window 217
01f3c0: r9 = r10
01f3c8: r9 += -0x130
01f3d0: r1 = r9
01f3d8: r2 = *(u64 *)(r10 - 0x5b0)
01f3e0: call -0x2982 ; call 0xa7d8 / window 217
01f3e8: r6 = r10
01f3f0: r6 += -0x2f0
01f3f8: r1 = r6
01f400: r2 = *(u64 *)(r10 - 0x538)
01f408: call -0x2987 ; call 0xa7d8 / window 217
01f410: w1 = *(u8 *)(r10 - 0x475)
01f418: w2 = *(u8 *)(r10 - 0x476)
01f420: *(u64 *)(r10 - 0xff8) = r2
01f428: *(u64 *)(r10 - 0xff0) = r1
01f430: *(u64 *)(r10 - 0x1000) = r6
01f438: r1 = r10
01f440: r1 += -0x1c0
01f448: r5 = r10
01f450: r2 = r7
01f458: r3 = r8
01f460: r4 = r9
01f468: call 0x631e ; call 0x50d60 / window 442
01f470: w1 = *(u32 *)(r10 - 0x1c0)
01f478: if r1 == 0x16 goto -0x1f2 ; branch 0x1e4f0
01f480: w2 = *(u32 *)(r10 - 0x1a4)
01f488: r3 = *(u64 *)(r10 - 0x530)
01f490: *(u32 *)(r3 + 0x1c) = w2
01f498: r2 = *(u64 *)(r10 - 0x1ac)
01f4a0: *(u64 *)(r3 + 0x14) = r2
01f4a8: r2 = *(u64 *)(r10 - 0x1b4)
01f4b0: *(u64 *)(r3 + 0xc) = r2
01f4b8: r2 = *(u64 *)(r10 - 0x1bc)
01f4c0: *(u64 *)(r3 + 0x4) = r2
01f4c8: *(u32 *)(r3 + 0x0) = w1
01f4d0: goto -0x3f ; branch 0x1f2e0
01f4d8: r1 = 0x6c00000000 ll
01f4e8: goto -0x2dd ; branch 0x1de08
01f4f0: r1 = 0x8a00000000 ll
01f500: goto -0x2e0 ; branch 0x1de08
01f508: r1 = 0xa900000000 ll
01f518: goto -0x2e3 ; branch 0x1de08
01f520: r1 = 0x9600000000 ll
01f530: goto -0x2e6 ; branch 0x1de08
