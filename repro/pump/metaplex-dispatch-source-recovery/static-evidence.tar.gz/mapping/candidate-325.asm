02bf88: r2 = *(u64 *)(r5 - 0xff8)
02bf90: r5 = *(u64 *)(r5 - 0x1000)
02bf98: r0 = r5
02bfa0: r0 <<= 0x20
02bfa8: r0 >>= 0x20
02bfb0: if r0 != 0x0 goto +0x6 ; branch 0x2bfe8
02bfb8: r5 = 0x0
02bfc0: *(u64 *)(r10 - 0x1000) = r5
02bfc8: *(u64 *)(r10 - 0xff8) = r2
02bfd0: r5 = r10
02bfd8: call 0x6 ; call 0x2c010 / window 326
02bfe0: goto +0x4 ; branch 0x2c008
02bfe8: *(u64 *)(r10 - 0x1000) = r5
02bff0: *(u64 *)(r10 - 0xff8) = r2
02bff8: r5 = r10
02c000: call 0x49 ; call 0x2c250 / window 327
02c008: exit
