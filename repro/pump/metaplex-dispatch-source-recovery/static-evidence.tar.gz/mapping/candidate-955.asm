084468: r3 = 0x20
084470: call 0x29cd ; call 0x992e0 / window 1249
084478: r1 = r0
084480: r0 = 0x1
084488: if r1 == 0x0 goto +0x1 ; branch 0x84498
084490: r0 = 0x0
084498: exit
