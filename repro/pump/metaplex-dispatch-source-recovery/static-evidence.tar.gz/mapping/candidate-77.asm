003678: r6 = r1
003680: r7 = 0x0
003688: if r7 == 0xc0 goto +0x5 ; branch 0x36b8
003690: r1 = r6
003698: r1 += r7
0036a0: call -0xa9 ; call 0x3160 / window 62
0036a8: r7 += 0x30
0036b0: goto -0x6 ; branch 0x3688
0036b8: exit
