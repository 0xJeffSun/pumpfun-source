029d88: r6 = r4
029d90: r9 = r3
029d98: r7 = r1
029da0: r8 = *(u64 *)(r6 + 0x8)
029da8: if r8 != 0x0 goto +0x4 ; branch 0x29dd0
029db0: r1 = 0xa800000000 ll
029dc0: *(u64 *)(r7 + 0x0) = r1
029dc8: goto +0x82 ; branch 0x2a1e0
029dd0: *(u64 *)(r10 - 0x5e8) = r2
029dd8: r2 = *(u64 *)(r9 + 0x48)
029de0: r1 = r10
029de8: r1 += -0x328
029df0: call 0x98f9 ; call 0x765c0 / window 773
029df8: w1 = *(u32 *)(r10 - 0x328)
029e00: if r1 != 0x16 goto +0x4c ; branch 0x2a068
029e08: r2 = *(u64 *)(r9 + 0x50)
029e10: r1 = r10
029e18: r1 += -0x328
029e20: call 0x98f3 ; call 0x765c0 / window 773
029e28: w1 = *(u32 *)(r10 - 0x328)
029e30: if r1 == 0x16 goto +0x1 ; branch 0x29e40
029e38: goto +0x45 ; branch 0x2a068
029e40: *(u64 *)(r10 - 0x5f0) = r6
029e48: r2 = *(u64 *)(r9 + 0x38)
029e50: r1 = r10
029e58: r1 += -0x328
029e60: *(u64 *)(r10 - 0x5f8) = r2
029e68: r6 = *(u64 *)(r10 - 0x5e8)
029e70: r3 = r6
029e78: call -0x344a ; call 0xfc30 / window 275
029e80: w1 = *(u32 *)(r10 - 0x328)
029e88: if r1 == 0x16 goto +0x1 ; branch 0x29e98
029e90: goto +0x48 ; branch 0x2a0d8
029e98: *(u64 *)(r10 - 0x610) = r8
029ea0: *(u64 *)(r10 - 0x600) = r7
029ea8: r1 = r10
029eb0: r1 += -0x570
029eb8: r2 = r6
029ec0: call 0xb84f ; call 0x86140 / window 990
029ec8: *(u64 *)(r10 - 0x608) = r9
029ed0: r9 = *(u64 *)(r9 + 0x40)
029ed8: r2 = *(u64 *)(r9 + 0x0)
029ee0: r8 = *(u64 *)(r10 - 0x570)
029ee8: r7 = *(u64 *)(r10 - 0x568)
029ef0: r1 = r10
029ef8: r1 += -0x580
029f00: call 0xb847 ; call 0x86140 / window 990
029f08: *(u64 *)(r10 - 0x310) = r7
029f10: *(u64 *)(r10 - 0x318) = r8
029f18: r1 = 0x8
029f20: *(u64 *)(r10 - 0x320) = r1
029f28: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
029f38: *(u64 *)(r10 - 0x328) = r1
029f40: r1 = *(u64 *)(r10 - 0x578)
029f48: *(u64 *)(r10 - 0x300) = r1
029f50: r1 = *(u64 *)(r10 - 0x580)
029f58: *(u64 *)(r10 - 0x308) = r1
029f60: r1 = r10
029f68: r1 += -0x560
029f70: r4 = r10
029f78: r4 += -0x328
029f80: r2 = r6
029f88: r6 = *(u64 *)(r10 - 0x5f8)
029f90: r3 = r6
029f98: r5 = 0x3
029fa0: call -0x347b ; call 0xfbd0 / window 273
029fa8: w1 = *(u32 *)(r10 - 0x560)
029fb0: if r1 == 0x16 goto +0x1 ; branch 0x29fc0
029fb8: goto +0x31 ; branch 0x2a148
029fc0: r8 = r9
029fc8: r1 = r10
029fd0: r1 += -0x328
029fd8: r2 = r6
029fe0: call 0x3bda ; call 0x47eb8 / window 419
029fe8: w9 = *(u32 *)(r10 - 0x220)
029ff0: r7 = *(u64 *)(r10 - 0x600)
029ff8: if r9 != 0x2 goto +0x40 ; branch 0x2a200
02a000: r1 = *(u64 *)(r10 - 0x310)
02a008: *(u64 *)(r10 - 0x418) = r1
02a010: r2 = *(u64 *)(r10 - 0x318)
02a018: *(u64 *)(r10 - 0x420) = r2
02a020: r3 = *(u64 *)(r10 - 0x320)
02a028: *(u64 *)(r10 - 0x428) = r3
02a030: r4 = *(u64 *)(r10 - 0x328)
02a038: *(u64 *)(r10 - 0x430) = r4
02a040: *(u64 *)(r7 + 0x18) = r1
02a048: *(u64 *)(r7 + 0x10) = r2
02a050: *(u64 *)(r7 + 0x8) = r3
02a058: *(u64 *)(r7 + 0x0) = r4
02a060: goto +0x2e ; branch 0x2a1d8
02a068: w2 = *(u32 *)(r10 - 0x30c)
02a070: *(u32 *)(r10 - 0x548) = w2
02a078: r3 = *(u64 *)(r10 - 0x314)
02a080: *(u64 *)(r10 - 0x550) = r3
02a088: r4 = *(u64 *)(r10 - 0x31c)
02a090: *(u64 *)(r10 - 0x558) = r4
02a098: r5 = *(u64 *)(r10 - 0x324)
02a0a0: *(u64 *)(r10 - 0x560) = r5
02a0a8: *(u32 *)(r7 + 0x1c) = w2
02a0b0: *(u64 *)(r7 + 0x14) = r3
02a0b8: *(u64 *)(r7 + 0xc) = r4
02a0c0: *(u64 *)(r7 + 0x4) = r5
02a0c8: *(u32 *)(r7 + 0x0) = w1
02a0d0: goto +0x21 ; branch 0x2a1e0
02a0d8: w2 = *(u32 *)(r10 - 0x30c)
02a0e0: *(u32 *)(r10 - 0x548) = w2
02a0e8: r3 = *(u64 *)(r10 - 0x314)
02a0f0: *(u64 *)(r10 - 0x550) = r3
02a0f8: r4 = *(u64 *)(r10 - 0x31c)
02a100: *(u64 *)(r10 - 0x558) = r4
02a108: r5 = *(u64 *)(r10 - 0x324)
02a110: *(u64 *)(r10 - 0x560) = r5
02a118: *(u32 *)(r7 + 0x1c) = w2
02a120: *(u64 *)(r7 + 0x14) = r3
02a128: *(u64 *)(r7 + 0xc) = r4
02a130: *(u64 *)(r7 + 0x4) = r5
02a138: *(u32 *)(r7 + 0x0) = w1
02a140: goto +0x12 ; branch 0x2a1d8
02a148: w2 = *(u32 *)(r10 - 0x544)
02a150: *(u32 *)(r10 - 0x419) = w2
02a158: r2 = *(u64 *)(r10 - 0x54b)
02a160: *(u64 *)(r10 - 0x420) = r2
02a168: r2 = *(u64 *)(r10 - 0x55b)
02a170: *(u64 *)(r10 - 0x430) = r2
02a178: r3 = *(u64 *)(r10 - 0x553)
02a180: *(u64 *)(r10 - 0x428) = r3
02a188: w4 = *(u8 *)(r10 - 0x55c)
02a190: w5 = *(u32 *)(r10 - 0x419)
02a198: r0 = *(u64 *)(r10 - 0x600)
02a1a0: *(u32 *)(r0 + 0x1c) = w5
02a1a8: r5 = *(u64 *)(r10 - 0x420)
02a1b0: *(u64 *)(r0 + 0x15) = r5
02a1b8: *(u64 *)(r0 + 0xd) = r3
02a1c0: *(u64 *)(r0 + 0x5) = r2
02a1c8: *(u8 *)(r0 + 0x4) = w4
02a1d0: *(u32 *)(r0 + 0x0) = w1
02a1d8: r6 = *(u64 *)(r10 - 0x5f0)
02a1e0: r6 += 0x10
02a1e8: r1 = r6
02a1f0: call -0x4d3a ; call 0x3828 / window 85
02a1f8: exit
02a200: r6 = r10
02a208: r6 += -0x430
02a210: r2 = r10
02a218: r2 += -0x328
02a220: r1 = r6
02a228: r3 = 0x108
02a230: call 0xdd8b ; call 0x98e90 / window 1246
02a238: r1 = r10
02a240: r1 += -0x454
02a248: r2 = r10
02a250: r2 += -0x21c
02a258: r3 = 0x24
02a260: call 0xdd85 ; call 0x98e90 / window 1246
02a268: r1 = r10
02a270: r1 += -0x560
02a278: r2 = r6
02a280: r3 = 0x108
02a288: call 0xdd80 ; call 0x98e90 / window 1246
02a290: *(u32 *)(r10 - 0x458) = w9
02a298: r1 = r8
02a2a0: r2 = *(u64 *)(r1 + 0x0)
02a2a8: r1 = r10
02a2b0: r1 += -0x53c
02a2b8: call -0x4eb6 ; call 0x2d10 / window 44
02a2c0: if r0 != 0x0 goto +0x1 ; branch 0x2a2d0
02a2c8: goto +0x5 ; branch 0x2a2f8
02a2d0: r1 = 0xf00000000 ll
02a2e0: *(u64 *)(r7 + 0x0) = r1
02a2e8: r6 = *(u64 *)(r10 - 0x5f0)
02a2f0: goto +0xa1 ; branch 0x2a800
02a2f8: r1 = *(u64 *)(r10 - 0x608)
02a300: r9 = *(u64 *)(r1 + 0x68)
02a308: r1 = r10
02a310: r1 += -0x328
02a318: r2 = r9
02a320: call -0x34c8 ; call 0xfce8 / window 277
02a328: w1 = *(u32 *)(r10 - 0x328)
02a330: r6 = *(u64 *)(r10 - 0x5f0)
02a338: if r1 == 0x16 goto +0x1 ; branch 0x2a348
02a340: goto +0x8a ; branch 0x2a798
02a348: r3 = *(u64 *)(r9 + 0x0)
02a350: r1 = r10
02a358: r1 += -0x328
02a360: r2 = r8
02a368: call -0x34e8 ; call 0xfc30 / window 275
02a370: w1 = *(u32 *)(r10 - 0x328)
02a378: if r1 == 0x16 goto +0x1 ; branch 0x2a388
02a380: goto +0x82 ; branch 0x2a798
02a388: r2 = *(u64 *)(r8 + 0x10)
02a390: r2 += 0x10
02a398: r1 = r10
02a3a0: r1 += -0x590
02a3a8: r3 = 0x9f008 ll ; data b"\x00\x00\x00\x00\xd2\xa6\t\x00&\x00\x00\x00\x00\x00\x00\x00L\x00\x00\x00O\x00\x00\x00\x00\x00\x00\x00\xd2\xa6\t\x00&\x00\x00\x00\x00\x00\x00\x00\xaa\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x002\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x000\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00"
02a3b8: call -0x4d5c ; call 0x38e0 / window 87
02a3c0: r1 = *(u64 *)(r10 - 0x590)
02a3c8: r2 = *(u64 *)(r1 + 0x0)
02a3d0: r3 = *(u64 *)(r1 + 0x8)
02a3d8: r8 = *(u64 *)(r10 - 0x588)
02a3e0: r1 = r10
02a3e8: r1 += -0x328
02a3f0: call 0x5774 ; call 0x55f98 / window 451
02a3f8: w9 = *(u32 *)(r10 - 0x328)
02a400: if r9 == 0x2 goto +0x83 ; branch 0x2a820
02a408: r1 = r10
02a410: r1 += -0x430
02a418: *(u64 *)(r10 - 0x5f8) = r1
02a420: r2 = r10
02a428: r2 += -0x324
02a430: r3 = 0x24
02a438: call 0xdd4a ; call 0x98e90 / window 1246
02a440: r1 = r10
02a448: r1 += -0x1d0
02a450: r2 = r10
02a458: r2 += -0x300
02a460: r3 = 0x30
02a468: call 0xdd44 ; call 0x98e90 / window 1246
02a470: r1 = r10
02a478: r1 += -0x1f4
02a480: r2 = *(u64 *)(r10 - 0x5f8)
02a488: r3 = 0x24
02a490: call 0xdd3f ; call 0x98e90 / window 1246
02a498: *(u32 *)(r10 - 0x1f8) = w9
02a4a0: r1 = *(u64 *)(r8 + 0x0)
02a4a8: r1 += -0x1
02a4b0: *(u64 *)(r8 + 0x0) = r1
02a4b8: w1 = *(u32 *)(r10 - 0x4ac)
02a4c0: if r1 == 0x6 goto +0x2 ; branch 0x2a4d8
02a4c8: r1 |= 0x4
02a4d0: if r1 == 0x4 goto +0x79 ; branch 0x2a8a0
02a4d8: r8 = *(u64 *)(r10 - 0x608)
02a4e0: r3 = *(u64 *)(r8 + 0x48)
02a4e8: r1 = r10
02a4f0: r1 += -0x328
02a4f8: r2 = r10
02a500: r2 += -0x1f8
02a508: call -0x35f6 ; call 0xf560 / window 270
02a510: w1 = *(u32 *)(r10 - 0x328)
02a518: if r1 == 0x16 goto +0x1 ; branch 0x2a528
02a520: goto +0x4e ; branch 0x2a798
02a528: r9 = *(u64 *)(r8 + 0x30)
02a530: r1 = r9
02a538: call 0xb573 ; call 0x850d8 / window 981
02a540: if r0 != 0x0 goto +0x1 ; branch 0x2a550
02a548: goto +0xa4 ; branch 0x2aa70
02a550: *(u64 *)(r10 - 0x5f8) = r9
02a558: r9 = *(u64 *)(r8 + 0x0)
02a560: if r9 == 0x0 goto +0xd3 ; branch 0x2ac00
02a568: r1 = *(u64 *)(r8 + 0x68)
02a570: r5 = *(u64 *)(r1 + 0x0)
02a578: r1 = *(u64 *)(r8 + 0x50)
02a580: *(u64 *)(r10 - 0x620) = r1
02a588: r8 = *(u64 *)(r8 + 0x40)
02a590: r3 = *(u64 *)(r9 + 0x0)
02a598: r4 = *(u64 *)(r8 + 0x0)
02a5a0: r2 = *(u64 *)(r1 + 0x0)
02a5a8: r1 = r10
02a5b0: r1 += -0x430
02a5b8: *(u64 *)(r10 - 0x618) = r1
02a5c0: call 0x803c ; call 0x6a7a8 / window 591
02a5c8: r1 = r10
02a5d0: r1 += -0x60
02a5d8: *(u64 *)(r10 - 0x630) = r1
02a5e0: r2 = *(u64 *)(r10 - 0x620)
02a5e8: call -0x3fc3 ; call 0xa7d8 / window 217
02a5f0: r1 = r10
02a5f8: r1 += -0x30
02a600: *(u64 *)(r10 - 0x628) = r1
02a608: r2 = r9
02a610: call -0x3fc8 ; call 0xa7d8 / window 217
02a618: r9 = r10
02a620: r9 += -0x1a0
02a628: r1 = r9
02a630: r2 = r8
02a638: call -0x3fcd ; call 0xa7d8 / window 217
02a640: r8 = r10
02a648: r8 += -0xb0
02a650: r1 = r8
02a658: r2 = *(u64 *)(r10 - 0x5f8)
02a660: call -0x3fd2 ; call 0xa7d8 / window 217
02a668: r1 = r10
02a670: r1 += -0x328
02a678: *(u64 *)(r10 - 0x620) = r1
02a680: r2 = *(u64 *)(r10 - 0x630)
02a688: r3 = 0x30
02a690: call 0xdcff ; call 0x98e90 / window 1246
02a698: r1 = r10
02a6a0: r1 += -0x2f8
02a6a8: r2 = *(u64 *)(r10 - 0x628)
02a6b0: r3 = 0x30
02a6b8: call 0xdcfa ; call 0x98e90 / window 1246
02a6c0: r1 = r10
02a6c8: r1 += -0x2c8
02a6d0: r2 = r9
02a6d8: r3 = 0x30
02a6e0: call 0xdcf5 ; call 0x98e90 / window 1246
02a6e8: r1 = r10
02a6f0: r1 += -0x298
02a6f8: r2 = r8
02a700: r3 = 0x30
02a708: call 0xdcf0 ; call 0x98e90 / window 1246
02a710: r1 = r10
02a718: r1 += -0xe0
02a720: r2 = *(u64 *)(r10 - 0x618)
02a728: r3 = *(u64 *)(r10 - 0x620)
02a730: r4 = 0x4
02a738: call 0xb78b ; call 0x86398 / window 996
02a740: w1 = *(u32 *)(r10 - 0xe0)
02a748: if r1 == 0x16 goto +0x1 ; branch 0x2a758
02a750: goto +0x98 ; branch 0x2ac18
02a758: r1 = r10
02a760: r1 += -0x328
02a768: call -0x4e1f ; call 0x3678 / window 77
02a770: r1 = r10
02a778: r1 += -0x430
02a780: call -0x4ecc ; call 0x3128 / window 61
02a788: r9 = *(u64 *)(r10 - 0x5f8)
02a790: goto +0xb8 ; branch 0x2ad58
02a798: w2 = *(u32 *)(r10 - 0x30c)
02a7a0: *(u32 *)(r10 - 0x418) = w2
02a7a8: r3 = *(u64 *)(r10 - 0x314)
02a7b0: *(u64 *)(r10 - 0x420) = r3
02a7b8: r4 = *(u64 *)(r10 - 0x31c)
02a7c0: *(u64 *)(r10 - 0x428) = r4
02a7c8: r5 = *(u64 *)(r10 - 0x324)
02a7d0: *(u64 *)(r10 - 0x430) = r5
02a7d8: *(u32 *)(r7 + 0x1c) = w2
02a7e0: *(u64 *)(r7 + 0x14) = r3
02a7e8: *(u64 *)(r7 + 0xc) = r4
02a7f0: *(u64 *)(r7 + 0x4) = r5
02a7f8: *(u32 *)(r7 + 0x0) = w1
02a800: r1 = r10
02a808: r1 += -0x518
02a810: call -0x4eef ; call 0x30a0 / window 59
02a818: goto -0xc8 ; branch 0x2a1e0
02a820: r1 = *(u64 *)(r10 - 0x308)
02a828: *(u64 *)(r10 - 0x414) = r1
02a830: r2 = *(u64 *)(r10 - 0x310)
02a838: *(u64 *)(r10 - 0x41c) = r2
02a840: r3 = *(u64 *)(r10 - 0x318)
02a848: *(u64 *)(r10 - 0x424) = r3
02a850: r4 = *(u64 *)(r10 - 0x320)
02a858: *(u64 *)(r10 - 0x42c) = r4
02a860: *(u64 *)(r7 + 0x18) = r1
02a868: *(u64 *)(r7 + 0x10) = r2
02a870: *(u64 *)(r7 + 0x8) = r3
02a878: *(u64 *)(r7 + 0x0) = r4
02a880: r1 = *(u64 *)(r8 + 0x0)
02a888: r1 += -0x1
02a890: *(u64 *)(r8 + 0x0) = r1
02a898: goto -0x14 ; branch 0x2a800
02a8a0: r6 = *(u64 *)(r10 - 0x608)
02a8a8: r9 = *(u64 *)(r6 + 0x8)
02a8b0: if r9 == 0x0 goto +0x53 ; branch 0x2ab50
02a8b8: r1 = r10
02a8c0: r1 += -0x5a0
02a8c8: r7 = *(u64 *)(r10 - 0x5e8)
02a8d0: r2 = r7
02a8d8: call 0xb70c ; call 0x86140 / window 990
02a8e0: r1 = *(u64 *)(r6 + 0x40)
02a8e8: r2 = *(u64 *)(r1 + 0x0)
02a8f0: r6 = *(u64 *)(r10 - 0x5a0)
02a8f8: r8 = *(u64 *)(r10 - 0x598)
02a900: r1 = r10
02a908: r1 += -0x5b0
02a910: call 0xb705 ; call 0x86140 / window 990
02a918: r1 = 0x7
02a920: *(u64 *)(r10 - 0x2f0) = r1
02a928: r1 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
02a938: *(u64 *)(r10 - 0x2f8) = r1
02a940: *(u64 *)(r10 - 0x310) = r8
02a948: *(u64 *)(r10 - 0x318) = r6
02a950: r1 = 0x8
02a958: *(u64 *)(r10 - 0x320) = r1
02a960: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
02a970: *(u64 *)(r10 - 0x328) = r1
02a978: r1 = *(u64 *)(r10 - 0x5a8)
02a980: *(u64 *)(r10 - 0x300) = r1
02a988: r1 = *(u64 *)(r10 - 0x5b0)
02a990: *(u64 *)(r10 - 0x308) = r1
02a998: r1 = r10
02a9a0: r1 += -0x430
02a9a8: r4 = r10
02a9b0: r4 += -0x328
02a9b8: r2 = r7
02a9c0: r3 = r9
02a9c8: r5 = 0x4
02a9d0: call -0x35c1 ; call 0xfbd0 / window 273
02a9d8: w1 = *(u32 *)(r10 - 0x430)
02a9e0: if r1 == 0x16 goto +0x1 ; branch 0x2a9f0
02a9e8: goto +0x2f ; branch 0x2ab68
02a9f0: r7 = *(u64 *)(r10 - 0x600)
02a9f8: r1 = *(u64 *)(r10 - 0x610)
02aa00: r6 = *(u64 *)(r10 - 0x5f0)
02aa08: if r1 > 0x1 goto +0x55 ; branch 0x2acb8
02aa10: r1 = *(u64 *)(r10 - 0x1d0)
02aa18: if r1 != 0x0 goto +0x53 ; branch 0x2acb8
02aa20: r8 = *(u64 *)(r10 - 0x608)
02aa28: r1 = *(u64 *)(r8 + 0x48)
02aa30: r2 = *(u64 *)(r1 + 0x0)
02aa38: r1 = r10
02aa40: r1 += -0x55c
02aa48: call 0x9774 ; call 0x765f0 / window 774
02aa50: if r0 != 0x0 goto -0xa6 ; branch 0x2a528
02aa58: r1 = 0x700000000 ll
02aa68: goto +0x4b ; branch 0x2acc8
02aa70: r4 = *(u64 *)(r8 + 0x0)
02aa78: r2 = *(u64 *)(r8 + 0x40)
02aa80: r1 = *(u64 *)(r8 + 0x68)
02aa88: w3 = *(u32 *)(r10 - 0x4ac)
02aa90: *(u64 *)(r10 - 0xff8) = r3
02aa98: r3 = 0x0
02aaa0: *(u64 *)(r10 - 0xff0) = r3
02aaa8: *(u64 *)(r10 - 0x1000) = r1
02aab0: r1 = r10
02aab8: r1 += -0x328
02aac0: r5 = r10
02aac8: r3 = r9
02aad0: call 0x555b ; call 0x555b0 / window 450
02aad8: w1 = *(u32 *)(r10 - 0x2e0)
02aae0: if r1 != 0x2 goto +0x3e ; branch 0x2acd8
02aae8: r1 = *(u64 *)(r10 - 0x310)
02aaf0: *(u64 *)(r10 - 0x418) = r1
02aaf8: r2 = *(u64 *)(r10 - 0x318)
02ab00: *(u64 *)(r10 - 0x420) = r2
02ab08: r3 = *(u64 *)(r10 - 0x320)
02ab10: *(u64 *)(r10 - 0x428) = r3
02ab18: r4 = *(u64 *)(r10 - 0x328)
02ab20: *(u64 *)(r10 - 0x430) = r4
02ab28: *(u64 *)(r7 + 0x18) = r1
02ab30: *(u64 *)(r7 + 0x10) = r2
02ab38: *(u64 *)(r7 + 0x8) = r3
02ab40: *(u64 *)(r7 + 0x0) = r4
02ab48: goto -0x6a ; branch 0x2a800
02ab50: r1 = 0xa700000000 ll
02ab60: goto -0x111 ; branch 0x2a2e0
02ab68: w2 = *(u32 *)(r10 - 0x414)
02ab70: *(u32 *)(r10 - 0x99) = w2
02ab78: r2 = *(u64 *)(r10 - 0x41b)
02ab80: *(u64 *)(r10 - 0xa0) = r2
02ab88: r2 = *(u64 *)(r10 - 0x42b)
02ab90: *(u64 *)(r10 - 0xb0) = r2
02ab98: r3 = *(u64 *)(r10 - 0x423)
02aba0: *(u64 *)(r10 - 0xa8) = r3
02aba8: w4 = *(u8 *)(r10 - 0x42c)
02abb0: w5 = *(u32 *)(r10 - 0x99)
02abb8: r0 = *(u64 *)(r10 - 0x600)
02abc0: *(u32 *)(r0 + 0x1c) = w5
02abc8: r5 = *(u64 *)(r10 - 0xa0)
02abd0: *(u64 *)(r0 + 0x15) = r5
02abd8: *(u64 *)(r0 + 0xd) = r3
02abe0: *(u64 *)(r0 + 0x5) = r2
02abe8: *(u8 *)(r0 + 0x4) = w4
02abf0: *(u32 *)(r0 + 0x0) = w1
02abf8: goto -0x123 ; branch 0x2a2e8
02ac00: r1 = 0xa200000000 ll
02ac10: goto +0x16 ; branch 0x2acc8
02ac18: w2 = *(u32 *)(r10 - 0xc4)
02ac20: *(u32 *)(r10 - 0xf0) = w2
02ac28: r3 = *(u64 *)(r10 - 0xcc)
02ac30: *(u64 *)(r10 - 0xf8) = r3
02ac38: r4 = *(u64 *)(r10 - 0xd4)
02ac40: *(u64 *)(r10 - 0x100) = r4
02ac48: r5 = *(u64 *)(r10 - 0xdc)
02ac50: *(u64 *)(r10 - 0x108) = r5
02ac58: *(u32 *)(r7 + 0x1c) = w2
02ac60: *(u64 *)(r7 + 0x14) = r3
02ac68: *(u64 *)(r7 + 0xc) = r4
02ac70: *(u64 *)(r7 + 0x4) = r5
02ac78: *(u32 *)(r7 + 0x0) = w1
02ac80: r1 = r10
02ac88: r1 += -0x328
02ac90: call -0x4ec4 ; call 0x3678 / window 77
02ac98: r1 = r10
02aca0: r1 += -0x430
02aca8: call -0x4f71 ; call 0x3128 / window 61
02acb0: goto -0x97 ; branch 0x2a800
02acb8: r1 = 0x1000000000 ll
02acc8: *(u64 *)(r7 + 0x0) = r1
02acd0: goto -0x9b ; branch 0x2a800
02acd8: r1 = *(u64 *)(r10 - 0x29c)
02ace0: *(u64 *)(r10 - 0xb0) = r1
02ace8: r1 = *(u64 *)(r10 - 0x294)
02acf0: *(u64 *)(r10 - 0xa8) = r1
02acf8: r1 = *(u64 *)(r10 - 0x28c)
02ad00: *(u64 *)(r10 - 0xa0) = r1
02ad08: r1 = *(u64 *)(r10 - 0x284)
02ad10: *(u64 *)(r10 - 0x98) = r1
02ad18: w1 = *(u32 *)(r10 - 0x4ac)
02ad20: if r1 == 0x6 goto +0x6 ; branch 0x2ad58
02ad28: r2 = 0xfffffffe ll
02ad38: r1 &= r2
02ad40: if r1 != 0x4 goto +0x2 ; branch 0x2ad58
02ad48: w1 = *(u32 *)(r10 - 0x2a0)
02ad50: if r1 == 0x1 goto +0xad ; branch 0x2b2c0
02ad58: r2 = *(u64 *)(r9 + 0x10)
02ad60: r2 += 0x10
02ad68: r1 = r10
02ad70: r1 += -0x5c0
02ad78: r3 = 0x9f020 ll ; data b"\x00\x00\x00\x00\xd2\xa6\t\x00&\x00\x00\x00\x00\x00\x00\x00\xaa\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x002\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x000\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00"
02ad88: call -0x4e96 ; call 0x38e0 / window 87
02ad90: r1 = *(u64 *)(r10 - 0x5c0)
02ad98: r2 = *(u64 *)(r1 + 0x0)
02ada0: r3 = *(u64 *)(r1 + 0x8)
02ada8: r6 = *(u64 *)(r10 - 0x5b8)
02adb0: r1 = r10
02adb8: r1 += -0x328
02adc0: call 0x5680 ; call 0x561c8 / window 452
02adc8: w9 = *(u32 *)(r10 - 0x2e0)
02add0: if r9 != 0x2 goto +0x11 ; branch 0x2ae60
02add8: r1 = *(u64 *)(r10 - 0x310)
02ade0: *(u64 *)(r10 - 0x98) = r1
02ade8: r2 = *(u64 *)(r10 - 0x318)
02adf0: *(u64 *)(r10 - 0xa0) = r2
02adf8: r3 = *(u64 *)(r10 - 0x320)
02ae00: *(u64 *)(r10 - 0xa8) = r3
02ae08: r4 = *(u64 *)(r10 - 0x328)
02ae10: *(u64 *)(r10 - 0xb0) = r4
02ae18: r5 = *(u64 *)(r10 - 0x600)
02ae20: *(u64 *)(r5 + 0x18) = r1
02ae28: *(u64 *)(r5 + 0x10) = r2
02ae30: *(u64 *)(r5 + 0x8) = r3
02ae38: *(u64 *)(r5 + 0x0) = r4
02ae40: r1 = *(u64 *)(r6 + 0x0)
02ae48: r1 += -0x1
02ae50: *(u64 *)(r6 + 0x0) = r1
02ae58: goto -0x16f ; branch 0x2a2e8
02ae60: r7 = r10
02ae68: r7 += -0xb0
02ae70: r2 = r10
02ae78: r2 += -0x328
02ae80: r1 = r7
02ae88: r3 = 0x48
02ae90: call 0xdbff ; call 0x98e90 / window 1246
02ae98: r1 = r10
02aea0: r1 += -0x3e4
02aea8: r2 = r10
02aeb0: r2 += -0x2dc
02aeb8: r3 = 0x64
02aec0: call 0xdbf9 ; call 0x98e90 / window 1246
02aec8: r1 = r10
02aed0: r1 += -0x430
02aed8: r2 = r7
02aee0: r3 = 0x48
02aee8: call 0xdbf4 ; call 0x98e90 / window 1246
02aef0: *(u32 *)(r10 - 0x3e8) = w9
02aef8: r1 = *(u64 *)(r6 + 0x0)
02af00: r1 += -0x1
02af08: *(u64 *)(r6 + 0x0) = r1
02af10: w1 = *(u32 *)(r10 - 0x4ac)
02af18: if r1 == 0x6 goto +0x3 ; branch 0x2af38
02af20: r2 = r1
02af28: r2 |= 0x4
02af30: if r2 == 0x4 goto +0x87 ; branch 0x2b370
02af38: r3 = *(u64 *)(r10 - 0x608)
02af40: r1 = *(u64 *)(r3 + 0x68)
02af48: r2 = *(u64 *)(r1 + 0x0)
02af50: r6 = *(u64 *)(r3 + 0x48)
02af58: r1 = *(u64 *)(r3 + 0x40)
02af60: r7 = *(u64 *)(r3 + 0x30)
02af68: r4 = *(u64 *)(r7 + 0x0)
02af70: *(u64 *)(r10 - 0x5e8) = r1
02af78: r3 = *(u64 *)(r1 + 0x0)
02af80: r1 = *(u64 *)(r6 + 0x0)
02af88: r5 = 0x0
02af90: *(u64 *)(r10 - 0xff0) = r5
02af98: r5 = *(u64 *)(r10 - 0x610)
02afa0: *(u64 *)(r10 - 0xfe8) = r5
02afa8: r5 = 0x995a8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02afb8: *(u64 *)(r10 - 0xff8) = r5
02afc0: *(u64 *)(r10 - 0x1000) = r1
02afc8: r1 = r10
02afd0: r1 += -0x328
02afd8: r5 = r10
02afe0: call 0xa7f5 ; call 0x7ef90 / window 864
02afe8: r9 = *(u64 *)(r10 - 0x300)
02aff0: if r9 != 0x0 goto +0xe ; branch 0x2b068
02aff8: r1 = *(u64 *)(r10 - 0x310)
02b000: *(u64 *)(r10 - 0xc8) = r1
02b008: r2 = *(u64 *)(r10 - 0x318)
02b010: *(u64 *)(r10 - 0xd0) = r2
02b018: r3 = *(u64 *)(r10 - 0x320)
02b020: *(u64 *)(r10 - 0xd8) = r3
02b028: r4 = *(u64 *)(r10 - 0x328)
02b030: *(u64 *)(r10 - 0xe0) = r4
02b038: r5 = *(u64 *)(r10 - 0x600)
02b040: *(u64 *)(r5 + 0x18) = r1
02b048: *(u64 *)(r5 + 0x10) = r2
02b050: *(u64 *)(r5 + 0x8) = r3
02b058: *(u64 *)(r5 + 0x0) = r4
02b060: goto -0x1b0 ; branch 0x2a2e8
02b068: r8 = r10
02b070: r8 += -0xe0
02b078: r2 = r10
02b080: r2 += -0x328
02b088: r1 = r8
02b090: r3 = 0x28
02b098: call 0xdbbe ; call 0x98e90 / window 1246
02b0a0: r1 = *(u64 *)(r10 - 0x2f8)
02b0a8: *(u64 *)(r10 - 0x80) = r1
02b0b0: r1 = *(u64 *)(r10 - 0x2f0)
02b0b8: *(u64 *)(r10 - 0x78) = r1
02b0c0: r1 = *(u64 *)(r10 - 0x2e8)
02b0c8: *(u64 *)(r10 - 0x70) = r1
02b0d0: r1 = *(u64 *)(r10 - 0x2e0)
02b0d8: *(u64 *)(r10 - 0x68) = r1
02b0e0: r1 = r10
02b0e8: r1 += -0xb0
02b0f0: *(u64 *)(r10 - 0x5f8) = r1
02b0f8: r2 = r8
02b100: r3 = 0x28
02b108: call 0xdbb0 ; call 0x98e90 / window 1246
02b110: *(u64 *)(r10 - 0x88) = r9
02b118: r9 = r10
02b120: r9 += -0x60
02b128: r1 = r9
02b130: r2 = *(u64 *)(r10 - 0x5e8)
02b138: call -0x412d ; call 0xa7d8 / window 217
02b140: r8 = r10
02b148: r8 += -0x30
02b150: r1 = r8
02b158: r2 = r7
02b160: call -0x4132 ; call 0xa7d8 / window 217
02b168: r7 = r10
02b170: r7 += -0x1a0
02b178: r1 = r7
02b180: r2 = r6
02b188: call -0x4137 ; call 0xa7d8 / window 217
02b190: r6 = r10
02b198: r6 += -0x328
02b1a0: r1 = r6
02b1a8: r2 = r9
02b1b0: r3 = 0x30
02b1b8: call 0xdb9a ; call 0x98e90 / window 1246
02b1c0: r1 = r10
02b1c8: r1 += -0x2f8
02b1d0: r2 = r8
02b1d8: r3 = 0x30
02b1e0: call 0xdb95 ; call 0x98e90 / window 1246
02b1e8: r1 = r10
02b1f0: r1 += -0x2c8
02b1f8: r2 = r7
02b200: r3 = 0x30
02b208: call 0xdb90 ; call 0x98e90 / window 1246
02b210: r1 = r10
02b218: r1 += -0x108
02b220: r2 = *(u64 *)(r10 - 0x5f8)
02b228: r3 = r6
02b230: r4 = 0x3
02b238: call 0xb62b ; call 0x86398 / window 996
02b240: w1 = *(u32 *)(r10 - 0x108)
02b248: if r1 == 0x16 goto +0x1 ; branch 0x2b258
02b250: goto +0x52 ; branch 0x2b4e8
02b258: r1 = r10
02b260: r1 += -0x328
02b268: call -0x4f88 ; call 0x3630 / window 76
02b270: r1 = r10
02b278: r1 += -0xb0
02b280: call -0x502c ; call 0x3128 / window 61
02b288: r1 = 0x16
02b290: r2 = *(u64 *)(r10 - 0x600)
02b298: *(u32 *)(r2 + 0x0) = w1
02b2a0: r1 = r10
02b2a8: r1 += -0x518
02b2b0: call -0x5043 ; call 0x30a0 / window 59
02b2b8: goto -0x21d ; branch 0x2a1d8
02b2c0: r1 = *(u64 *)(r10 - 0x98)
02b2c8: *(u64 *)(r10 - 0x310) = r1
02b2d0: r1 = *(u64 *)(r10 - 0xa0)
02b2d8: *(u64 *)(r10 - 0x318) = r1
02b2e0: r1 = *(u64 *)(r10 - 0xa8)
02b2e8: *(u64 *)(r10 - 0x320) = r1
02b2f0: r1 = *(u64 *)(r10 - 0xb0)
02b2f8: *(u64 *)(r10 - 0x328) = r1
02b300: r1 = 0xa7
02b308: r2 = *(u64 *)(r8 + 0x8)
02b310: if r2 == 0x0 goto +0x6 ; branch 0x2b348
02b318: r2 = *(u64 *)(r2 + 0x0)
02b320: r1 = r10
02b328: r1 += -0x328
02b330: call -0x50c5 ; call 0x2d10 / window 44
02b338: r1 = 0xbc
02b340: if r0 == 0x0 goto -0xbe ; branch 0x2ad58
02b348: r2 = *(u64 *)(r10 - 0x600)
02b350: *(u32 *)(r2 + 0x4) = w1
02b358: r1 = 0x0
02b360: *(u32 *)(r2 + 0x0) = w1
02b368: goto -0x211 ; branch 0x2a2e8
02b370: if r1 == 0x4 goto +0x1 ; branch 0x2b380
02b378: goto +0x51 ; branch 0x2b608
02b380: r1 = *(u64 *)(r10 - 0x608)
02b388: r6 = *(u64 *)(r1 + 0x10)
02b390: if r6 == 0x0 goto +0x3f ; branch 0x2b590
02b398: r1 = *(u64 *)(r10 - 0x608)
02b3a0: r7 = *(u64 *)(r1 + 0x40)
02b3a8: r9 = *(u64 *)(r1 + 0x30)
02b3b0: r3 = *(u64 *)(r9 + 0x0)
02b3b8: r2 = *(u64 *)(r7 + 0x0)
02b3c0: r1 = r10
02b3c8: r1 += -0x328
02b3d0: call -0x3444 ; call 0x111b8 / window 294
02b3d8: r1 = *(u64 *)(r10 - 0x310)
02b3e0: *(u64 *)(r10 - 0x98) = r1
02b3e8: r1 = *(u64 *)(r10 - 0x318)
02b3f0: *(u64 *)(r10 - 0xa0) = r1
02b3f8: r1 = *(u64 *)(r10 - 0x320)
02b400: *(u64 *)(r10 - 0xa8) = r1
02b408: r1 = *(u64 *)(r10 - 0x328)
02b410: *(u64 *)(r10 - 0xb0) = r1
02b418: r2 = *(u64 *)(r6 + 0x0)
02b420: r1 = r10
02b428: r1 += -0xb0
02b430: call 0x9637 ; call 0x765f0 / window 774
02b438: if r0 != 0x0 goto +0x1 ; branch 0x2b448
02b440: goto +0x2c ; branch 0x2b5a8
02b448: r1 = r6
02b450: call 0xb390 ; call 0x850d8 / window 981
02b458: if r0 != 0x0 goto +0x1 ; branch 0x2b468
02b460: goto +0x2b ; branch 0x2b5c0
02b468: r2 = *(u64 *)(r10 - 0x608)
02b470: r1 = *(u64 *)(r2 + 0x58)
02b478: r2 = *(u64 *)(r2 + 0x50)
02b480: *(u64 *)(r10 - 0xff8) = r2
02b488: *(u64 *)(r10 - 0xff0) = r1
02b490: *(u64 *)(r10 - 0x1000) = r9
02b498: r1 = r10
02b4a0: r1 += -0x328
02b4a8: r5 = r10
02b4b0: r2 = *(u64 *)(r10 - 0x5e8)
02b4b8: r3 = r6
02b4c0: r4 = r7
02b4c8: call 0x4a71 ; call 0x50858 / window 441
02b4d0: w1 = *(u32 *)(r10 - 0x328)
02b4d8: if r1 != 0x16 goto +0x9c ; branch 0x2b9c0
02b4e0: goto +0x24 ; branch 0x2b608
02b4e8: w2 = *(u32 *)(r10 - 0xec)
02b4f0: *(u32 *)(r10 - 0x110) = w2
02b4f8: r3 = *(u64 *)(r10 - 0xf4)
02b500: *(u64 *)(r10 - 0x118) = r3
02b508: r4 = *(u64 *)(r10 - 0xfc)
02b510: *(u64 *)(r10 - 0x120) = r4
02b518: r5 = *(u64 *)(r10 - 0x104)
02b520: *(u64 *)(r10 - 0x128) = r5
02b528: r0 = *(u64 *)(r10 - 0x600)
02b530: *(u32 *)(r0 + 0x1c) = w2
02b538: *(u64 *)(r0 + 0x14) = r3
02b540: *(u64 *)(r0 + 0xc) = r4
02b548: *(u64 *)(r0 + 0x4) = r5
02b550: *(u32 *)(r0 + 0x0) = w1
02b558: r1 = r10
02b560: r1 += -0x328
02b568: call -0x4fe8 ; call 0x3630 / window 76
02b570: r1 = r10
02b578: r1 += -0xb0
02b580: call -0x508c ; call 0x3128 / window 61
02b588: goto -0x255 ; branch 0x2a2e8
02b590: r1 = 0x9f00000000 ll
02b5a0: goto +0x77 ; branch 0x2b960
02b5a8: r1 = 0x9a00000000 ll
02b5b8: goto +0x74 ; branch 0x2b960
02b5c0: r1 = r10
02b5c8: r1 += -0x328
02b5d0: r2 = r6
02b5d8: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02b5e8: call -0x3738 ; call 0xfc30 / window 275
02b5f0: w1 = *(u32 *)(r10 - 0x328)
02b5f8: if r1 == 0x16 goto +0x1 ; branch 0x2b608
02b600: goto +0x77 ; branch 0x2b9c0
02b608: r1 = r10
02b610: r1 += -0x5d0
02b618: r2 = *(u64 *)(r10 - 0x5e8)
02b620: call 0xb563 ; call 0x86140 / window 990
02b628: r1 = *(u64 *)(r10 - 0x608)
02b630: r7 = *(u64 *)(r1 + 0x40)
02b638: r2 = *(u64 *)(r7 + 0x0)
02b640: r6 = *(u64 *)(r10 - 0x5c8)
02b648: r9 = *(u64 *)(r10 - 0x5d0)
02b650: r1 = r10
02b658: r1 += -0x5e0
02b660: call 0xb55b ; call 0x86140 / window 990
02b668: r1 = 0x6d
02b670: w2 = *(u8 *)(r10 - 0x4ae)
02b678: if r2 == 0x0 goto +0x1 ; branch 0x2b688
02b680: w1 = *(u8 *)(r10 - 0x4ad)
02b688: if r2 == 0x1 goto +0x1 ; branch 0x2b698
02b690: goto +0x51 ; branch 0x2b920
02b698: r2 = *(u64 *)(r10 - 0x5d8)
02b6a0: r3 = *(u64 *)(r10 - 0x5e0)
02b6a8: r4 = 0x1
02b6b0: *(u64 *)(r10 - 0x158) = r4
02b6b8: r4 = r10
02b6c0: r4 += -0x149
02b6c8: *(u64 *)(r10 - 0x160) = r4
02b6d0: r4 = 0x7
02b6d8: *(u64 *)(r10 - 0x168) = r4
02b6e0: r4 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
02b6f0: *(u64 *)(r10 - 0x170) = r4
02b6f8: *(u64 *)(r10 - 0x180) = r3
02b700: *(u64 *)(r10 - 0x190) = r9
02b708: r3 = 0x8
02b710: *(u64 *)(r10 - 0x198) = r3
02b718: r3 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
02b728: *(u64 *)(r10 - 0x1a0) = r3
02b730: *(u8 *)(r10 - 0x149) = w1
02b738: *(u64 *)(r10 - 0x178) = r2
02b740: *(u64 *)(r10 - 0x188) = r6
02b748: r1 = *(u64 *)(r10 - 0x608)
02b750: r1 = *(u64 *)(r1 + 0x8)
02b758: r6 = r1
02b760: if r1 == 0x0 goto +0x3d ; branch 0x2b950
02b768: r1 = 0x5
02b770: *(u64 *)(r10 - 0x1000) = r1
02b778: r1 = 0x75
02b780: *(u64 *)(r10 - 0xff8) = r1
02b788: r1 = r10
02b790: r1 += -0x328
02b798: r4 = r10
02b7a0: r4 += -0x1a0
02b7a8: r5 = r10
02b7b0: r2 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02b7c0: r3 = r6
02b7c8: call -0x3d01 ; call 0xcfc8 / window 252
02b7d0: w1 = *(u32 *)(r10 - 0x328)
02b7d8: if r1 == 0x16 goto +0x1 ; branch 0x2b7e8
02b7e0: goto +0x32 ; branch 0x2b978
02b7e8: w1 = *(u32 *)(r10 - 0x4ac)
02b7f0: if r1 == 0x4 goto +0x1 ; branch 0x2b800
02b7f8: goto +0x4 ; branch 0x2b820
02b800: r1 = r10
02b808: r1 += -0x430
02b810: call 0xabee ; call 0x81788 / window 873
02b818: if r0 != 0x0 goto +0xc0 ; branch 0x2be20
02b820: r3 = *(u64 *)(r7 + 0x0)
02b828: r1 = *(u64 *)(r6 + 0x0)
02b830: r2 = *(u64 *)(r10 - 0x608)
02b838: r5 = *(u64 *)(r2 + 0x68)
02b840: r2 = *(u64 *)(r2 + 0x30)
02b848: *(u64 *)(r10 - 0x5e8) = r2
02b850: r4 = *(u64 *)(r2 + 0x0)
02b858: *(u64 *)(r10 - 0x618) = r5
02b860: r2 = *(u64 *)(r5 + 0x0)
02b868: r5 = 0x0
02b870: *(u64 *)(r10 - 0xff0) = r5
02b878: r5 = *(u64 *)(r10 - 0x610)
02b880: *(u64 *)(r10 - 0xfe8) = r5
02b888: r5 = 0x995a8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02b898: *(u64 *)(r10 - 0xff8) = r5
02b8a0: *(u64 *)(r10 - 0x1000) = r1
02b8a8: r1 = r10
02b8b0: r1 += -0x328
02b8b8: r5 = r10
02b8c0: call 0xa6d9 ; call 0x7ef90 / window 864
02b8c8: r9 = *(u64 *)(r10 - 0x300)
02b8d0: if r9 != 0x0 goto +0x2b ; branch 0x2ba30
02b8d8: r1 = *(u64 *)(r10 - 0x310)
02b8e0: *(u64 *)(r10 - 0xf0) = r1
02b8e8: r2 = *(u64 *)(r10 - 0x318)
02b8f0: *(u64 *)(r10 - 0xf8) = r2
02b8f8: r3 = *(u64 *)(r10 - 0x320)
02b900: *(u64 *)(r10 - 0x100) = r3
02b908: r4 = *(u64 *)(r10 - 0x328)
02b910: *(u64 *)(r10 - 0x108) = r4
02b918: goto -0x11d ; branch 0x2b038
02b920: r2 = 0x0
02b928: r3 = *(u64 *)(r10 - 0x600)
02b930: *(u32 *)(r3 + 0x0) = w2
02b938: r1 &= 0xff
02b940: *(u32 *)(r3 + 0x4) = w1
02b948: goto -0x2cd ; branch 0x2a2e8
02b950: r1 = 0xa700000000 ll
02b960: r2 = *(u64 *)(r10 - 0x600)
02b968: *(u64 *)(r2 + 0x0) = r1
02b970: goto -0x2d2 ; branch 0x2a2e8
02b978: w2 = *(u32 *)(r10 - 0x30c)
02b980: *(u32 *)(r10 - 0x98) = w2
02b988: r3 = *(u64 *)(r10 - 0x314)
02b990: *(u64 *)(r10 - 0xa0) = r3
02b998: r4 = *(u64 *)(r10 - 0x31c)
02b9a0: *(u64 *)(r10 - 0xa8) = r4
02b9a8: r5 = *(u64 *)(r10 - 0x324)
02b9b0: *(u64 *)(r10 - 0xb0) = r5
02b9b8: goto +0x8 ; branch 0x2ba00
02b9c0: w2 = *(u32 *)(r10 - 0x30c)
02b9c8: *(u32 *)(r10 - 0x188) = w2
02b9d0: r3 = *(u64 *)(r10 - 0x314)
02b9d8: *(u64 *)(r10 - 0x190) = r3
02b9e0: r4 = *(u64 *)(r10 - 0x31c)
02b9e8: *(u64 *)(r10 - 0x198) = r4
02b9f0: r5 = *(u64 *)(r10 - 0x324)
02b9f8: *(u64 *)(r10 - 0x1a0) = r5
02ba00: r0 = *(u64 *)(r10 - 0x600)
02ba08: *(u32 *)(r0 + 0x1c) = w2
02ba10: *(u64 *)(r0 + 0x14) = r3
02ba18: *(u64 *)(r0 + 0xc) = r4
02ba20: *(u64 *)(r0 + 0x4) = r5
02ba28: goto -0x1c8 ; branch 0x2abf0
02ba30: r8 = r10
02ba38: r8 += -0x108
02ba40: r2 = r10
02ba48: r2 += -0x328
02ba50: r1 = r8
02ba58: r3 = 0x28
02ba60: call 0xda85 ; call 0x98e90 / window 1246
02ba68: r1 = *(u64 *)(r10 - 0x2f8)
02ba70: *(u64 *)(r10 - 0x80) = r1
02ba78: r1 = *(u64 *)(r10 - 0x2f0)
02ba80: *(u64 *)(r10 - 0x78) = r1
02ba88: r1 = *(u64 *)(r10 - 0x2e8)
02ba90: *(u64 *)(r10 - 0x70) = r1
02ba98: r1 = *(u64 *)(r10 - 0x2e0)
02baa0: *(u64 *)(r10 - 0x68) = r1
02baa8: r1 = r10
02bab0: r1 += -0xb0
02bab8: *(u64 *)(r10 - 0x5f8) = r1
02bac0: r2 = r8
02bac8: r3 = 0x28
02bad0: call 0xda77 ; call 0x98e90 / window 1246
02bad8: *(u64 *)(r10 - 0x88) = r9
02bae0: r8 = r10
02bae8: r8 += -0xe0
02baf0: r1 = r8
02baf8: r2 = r7
02bb00: call -0x4266 ; call 0xa7d8 / window 217
02bb08: r1 = r10
02bb10: r1 += -0x60
02bb18: *(u64 *)(r10 - 0x610) = r1
02bb20: r2 = *(u64 *)(r10 - 0x5e8)
02bb28: call -0x426b ; call 0xa7d8 / window 217
02bb30: r1 = r10
02bb38: r1 += -0x30
02bb40: *(u64 *)(r10 - 0x608) = r1
02bb48: r2 = r6
02bb50: call -0x4270 ; call 0xa7d8 / window 217
02bb58: r9 = r10
02bb60: r9 += -0x328
02bb68: r1 = r9
02bb70: r2 = r8
02bb78: r3 = 0x30
02bb80: call 0xda61 ; call 0x98e90 / window 1246
02bb88: r1 = r10
02bb90: r1 += -0x2f8
02bb98: r2 = *(u64 *)(r10 - 0x610)
02bba0: r3 = 0x30
02bba8: call 0xda5c ; call 0x98e90 / window 1246
02bbb0: r1 = r10
02bbb8: r1 += -0x2c8
02bbc0: r2 = *(u64 *)(r10 - 0x608)
02bbc8: r3 = 0x30
02bbd0: call 0xda57 ; call 0x98e90 / window 1246
02bbd8: r1 = 0x5
02bbe0: *(u64 *)(r10 - 0x28) = r1
02bbe8: r1 = r10
02bbf0: r1 += -0x1a0
02bbf8: *(u64 *)(r10 - 0x30) = r1
02bc00: r1 = r10
02bc08: r1 += -0x30
02bc10: *(u64 *)(r10 - 0x1000) = r1
02bc18: r1 = 0x1
02bc20: *(u64 *)(r10 - 0xff8) = r1
02bc28: r1 = r10
02bc30: r1 += -0x128
02bc38: r5 = r10
02bc40: r2 = *(u64 *)(r10 - 0x5f8)
02bc48: r3 = r9
02bc50: r4 = 0x3
02bc58: call 0xb4ef ; call 0x863d8 / window 997
02bc60: w1 = *(u32 *)(r10 - 0x128)
02bc68: if r1 == 0x16 goto +0x1 ; branch 0x2bc78
02bc70: goto +0x2c ; branch 0x2bdd8
02bc78: r1 = r10
02bc80: r1 += -0x328
02bc88: call -0x50cc ; call 0x3630 / window 76
02bc90: r1 = r10
02bc98: r1 += -0xb0
02bca0: call -0x5170 ; call 0x3128 / window 61
02bca8: w1 = *(u32 *)(r10 - 0x4ac)
02bcb0: if r1 == 0x4 goto +0x1 ; branch 0x2bcc0
02bcb8: goto -0x147 ; branch 0x2b288
02bcc0: r1 = r10
02bcc8: r1 += -0x60
02bcd0: *(u64 *)(r10 - 0x5f8) = r1
02bcd8: r2 = r7
02bce0: call -0x42a2 ; call 0xa7d8 / window 217
02bce8: r7 = r10
02bcf0: r7 += -0x30
02bcf8: r1 = r7
02bd00: r2 = *(u64 *)(r10 - 0x5e8)
02bd08: call -0x42a7 ; call 0xa7d8 / window 217
02bd10: r8 = r10
02bd18: r8 += -0xb0
02bd20: r1 = r8
02bd28: r2 = r6
02bd30: call -0x42ac ; call 0xa7d8 / window 217
02bd38: r9 = r10
02bd40: r9 += -0x328
02bd48: r1 = r9
02bd50: r2 = *(u64 *)(r10 - 0x618)
02bd58: call -0x42b1 ; call 0xa7d8 / window 217
02bd60: w1 = *(u8 *)(r10 - 0x4ad)
02bd68: w2 = *(u8 *)(r10 - 0x4ae)
02bd70: *(u64 *)(r10 - 0xff8) = r2
02bd78: *(u64 *)(r10 - 0xff0) = r1
02bd80: *(u64 *)(r10 - 0x1000) = r9
02bd88: r1 = r10
02bd90: r1 += -0xe0
02bd98: r5 = r10
02bda0: r2 = *(u64 *)(r10 - 0x5f8)
02bda8: r3 = r7
02bdb0: r4 = r8
02bdb8: call 0x49f4 ; call 0x50d60 / window 442
02bdc0: w1 = *(u32 *)(r10 - 0xe0)
02bdc8: if r1 != 0x16 goto +0x2e ; branch 0x2bf40
02bdd0: goto -0x16a ; branch 0x2b288
02bdd8: w2 = *(u32 *)(r10 - 0x10c)
02bde0: *(u32 *)(r10 - 0x130) = w2
02bde8: r3 = *(u64 *)(r10 - 0x114)
02bdf0: *(u64 *)(r10 - 0x138) = r3
02bdf8: r4 = *(u64 *)(r10 - 0x11c)
02be00: *(u64 *)(r10 - 0x140) = r4
02be08: r5 = *(u64 *)(r10 - 0x124)
02be10: *(u64 *)(r10 - 0x148) = r5
02be18: goto -0x11f ; branch 0x2b528
02be20: r9 = r10
02be28: r9 += -0x60
02be30: r1 = r9
02be38: r2 = r7
02be40: call -0x42ce ; call 0xa7d8 / window 217
02be48: r8 = *(u64 *)(r10 - 0x608)
02be50: r2 = *(u64 *)(r8 + 0x30)
02be58: r1 = r10
02be60: r1 += -0x30
02be68: *(u64 *)(r10 - 0x5e8) = r1
02be70: call -0x42d4 ; call 0xa7d8 / window 217
02be78: r1 = r10
02be80: r1 += -0xb0
02be88: *(u64 *)(r10 - 0x5f8) = r1
02be90: r2 = r6
02be98: call -0x42d9 ; call 0xa7d8 / window 217
02bea0: r2 = *(u64 *)(r8 + 0x68)
02bea8: r8 = r10
02beb0: r8 += -0x328
02beb8: r1 = r8
02bec0: call -0x42de ; call 0xa7d8 / window 217
02bec8: w1 = *(u8 *)(r10 - 0x4ad)
02bed0: w2 = *(u8 *)(r10 - 0x4ae)
02bed8: *(u64 *)(r10 - 0xff8) = r2
02bee0: *(u64 *)(r10 - 0xff0) = r1
02bee8: *(u64 *)(r10 - 0x1000) = r8
02bef0: r1 = r10
02bef8: r1 += -0xe0
02bf00: r5 = r10
02bf08: r2 = r9
02bf10: r3 = *(u64 *)(r10 - 0x5e8)
02bf18: r4 = *(u64 *)(r10 - 0x5f8)
02bf20: call 0x4aca ; call 0x51578 / window 443
02bf28: w1 = *(u32 *)(r10 - 0xe0)
02bf30: if r1 != 0x16 goto +0x1 ; branch 0x2bf40
02bf38: goto -0xe4 ; branch 0x2b820
02bf40: w2 = *(u32 *)(r10 - 0xc4)
02bf48: *(u32 *)(r10 - 0xf0) = w2
02bf50: r3 = *(u64 *)(r10 - 0xcc)
02bf58: *(u64 *)(r10 - 0xf8) = r3
02bf60: r4 = *(u64 *)(r10 - 0xd4)
02bf68: *(u64 *)(r10 - 0x100) = r4
02bf70: r5 = *(u64 *)(r10 - 0xdc)
02bf78: *(u64 *)(r10 - 0x108) = r5
02bf80: goto -0xb1 ; branch 0x2ba00
