01f568: r9 = r5
01f570: *(u64 *)(r10 - 0x450) = r4
01f578: r7 = r3
01f580: *(u64 *)(r10 - 0x448) = r2
01f588: r6 = r1
01f590: r8 = *(u64 *)(r7 + 0x58)
01f598: r1 = r10
01f5a0: r1 += -0x1c8
01f5a8: r2 = r8
01f5b0: call 0xae22 ; call 0x766c8 / window 773
01f5b8: w1 = *(u32 *)(r10 - 0x1c8)
01f5c0: if r1 != 0x16 goto +0x7 ; branch 0x1f600
01f5c8: r2 = *(u64 *)(r7 + 0x50)
01f5d0: r1 = r10
01f5d8: r1 += -0x1c8
01f5e0: *(u64 *)(r10 - 0x458) = r2
01f5e8: call 0xae1b ; call 0x766c8 / window 773
01f5f0: w1 = *(u32 *)(r10 - 0x1c8)
01f5f8: if r1 == 0x16 goto +0xe ; branch 0x1f670
01f600: w2 = *(u32 *)(r10 - 0x1ac)
01f608: *(u32 *)(r10 - 0x3e8) = w2
01f610: r3 = *(u64 *)(r10 - 0x1b4)
01f618: *(u64 *)(r10 - 0x3f0) = r3
01f620: r4 = *(u64 *)(r10 - 0x1bc)
01f628: *(u64 *)(r10 - 0x3f8) = r4
01f630: r5 = *(u64 *)(r10 - 0x1c4)
01f638: *(u64 *)(r10 - 0x400) = r5
01f640: *(u32 *)(r6 + 0x1c) = w2
01f648: *(u64 *)(r6 + 0x14) = r3
01f650: *(u64 *)(r6 + 0xc) = r4
01f658: *(u64 *)(r6 + 0x4) = r5
01f660: *(u32 *)(r6 + 0x0) = w1
01f668: exit
01f670: r2 = *(u64 *)(r7 + 0x40)
01f678: r1 = r10
01f680: r1 += -0x1c8
01f688: *(u64 *)(r10 - 0x460) = r2
01f690: r3 = *(u64 *)(r10 - 0x448)
01f698: call -0x1f4e ; call 0xfc30 / window 275
01f6a0: w1 = *(u32 *)(r10 - 0x1c8)
01f6a8: if r1 == 0x16 goto +0x1 ; branch 0x1f6b8
01f6b0: goto -0x17 ; branch 0x1f600
01f6b8: r2 = *(u64 *)(r7 + 0x48)
01f6c0: r1 = r10
01f6c8: r1 += -0x1c8
01f6d0: *(u64 *)(r10 - 0x468) = r2
01f6d8: r3 = 0x9cc8e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
01f6e8: r4 = 0x2
01f6f0: call -0x1f56 ; call 0xfc48 / window 276
01f6f8: w1 = *(u32 *)(r10 - 0x1c8)
01f700: if r1 == 0x16 goto +0x1 ; branch 0x1f710
01f708: goto -0x22 ; branch 0x1f600
01f710: r1 = *(u64 *)(r7 + 0x60)
01f718: *(u64 *)(r10 - 0x470) = r1
01f720: r1 = *(u64 *)(r1 + 0x0)
01f728: r2 = 0x999e8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
01f738: call 0xadf7 ; call 0x766f8 / window 774
01f740: if r0 != 0x0 goto +0x1 ; branch 0x1f750
01f748: goto +0x1a ; branch 0x1f820
01f750: r1 = *(u64 *)(r7 + 0x68)
01f758: r1 = *(u64 *)(r1 + 0x0)
01f760: r2 = 0x99ac8 ll ; data b"\x06\xa7\xd5\x17\x18{\xd1f5\xda\xd4\x04U\xfd\xc2\xc0\xc1$\xc6\x8f!Vu\xa5\xdb\xba\xcb_\x08\x00\x00\x00\x08\xaf\xf8\x94\xc3\xfag\xc0\x16:0\xf24\xa3=4g\xf0:\xa1d\x171^\xb4\xb8\x14'\xbd\x9b\xa6\xedIX: Approve Collection AuthorityInsu"
01f770: call 0xadf0 ; call 0x766f8 / window 774
01f778: if r0 != 0x0 goto +0x1 ; branch 0x1f788
01f780: goto +0x13 ; branch 0x1f820
01f788: r1 = r10
01f790: r1 += -0x1c8
01f798: r2 = *(u64 *)(r10 - 0x460)
01f7a0: call 0x5103 ; call 0x47fc0 / window 419
01f7a8: w3 = *(u32 *)(r10 - 0xc0)
01f7b0: if r3 != 0x2 goto +0x11 ; branch 0x1f840
01f7b8: r1 = *(u64 *)(r10 - 0x1b0)
01f7c0: *(u64 *)(r10 - 0x2b8) = r1
01f7c8: r2 = *(u64 *)(r10 - 0x1b8)
01f7d0: *(u64 *)(r10 - 0x2c0) = r2
01f7d8: r3 = *(u64 *)(r10 - 0x1c0)
01f7e0: *(u64 *)(r10 - 0x2c8) = r3
01f7e8: r4 = *(u64 *)(r10 - 0x1c8)
01f7f0: *(u64 *)(r10 - 0x2d0) = r4
01f7f8: *(u64 *)(r6 + 0x18) = r1
01f800: *(u64 *)(r6 + 0x10) = r2
01f808: *(u64 *)(r6 + 0x8) = r3
01f810: *(u64 *)(r6 + 0x0) = r4
01f818: goto -0x37 ; branch 0x1f668
01f820: r1 = 0x9a00000000 ll
01f830: *(u64 *)(r6 + 0x0) = r1
01f838: goto -0x3b ; branch 0x1f668
01f840: r1 = r10
01f848: r1 += -0x2d0
01f850: *(u64 *)(r10 - 0x480) = r1
01f858: r2 = r10
01f860: r2 += -0x1c8
01f868: *(u64 *)(r10 - 0x478) = r3
01f870: r3 = 0x108
01f878: call 0xf2e3 ; call 0x98f98 / window 1246
01f880: r1 = r10
01f888: r1 += -0x2f4
01f890: r2 = r10
01f898: r2 += -0xbc
01f8a0: r3 = 0x24
01f8a8: call 0xf2dd ; call 0x98f98 / window 1246
01f8b0: r1 = r10
01f8b8: r1 += -0x400
01f8c0: r2 = *(u64 *)(r10 - 0x480)
01f8c8: r3 = 0x108
01f8d0: call 0xf2d8 ; call 0x98f98 / window 1246
01f8d8: r1 = *(u64 *)(r10 - 0x478)
01f8e0: *(u32 *)(r10 - 0x2f8) = w1
01f8e8: r1 = *(u64 *)(r10 - 0x468)
01f8f0: r2 = *(u64 *)(r1 + 0x0)
01f8f8: r1 = r10
01f900: r1 += -0x3dc
01f908: call -0x3980 ; call 0x2d10 / window 44
01f910: if r0 != 0x0 goto +0x1 ; branch 0x1f920
01f918: goto +0x3 ; branch 0x1f938
01f920: r1 = 0xf00000000 ll
01f930: goto +0x1f ; branch 0x1fa30
01f938: r1 = *(u64 *)(r10 - 0x450)
01f940: r1 <<= 0x20
01f948: r1 >>= 0x20
01f950: if r1 == 0x0 goto +0x7 ; branch 0x1f990
01f958: if r1 == 0x1 goto +0x1 ; branch 0x1f968
01f960: goto +0x17 ; branch 0x1fa20
01f968: r1 = *(u64 *)(r7 + 0x18)
01f970: if r1 != 0x0 goto +0x1c ; branch 0x1fa58
01f978: r1 = 0x9400000000 ll
01f988: goto +0x14 ; branch 0x1fa30
01f990: r1 = r10
01f998: r1 += -0x1c8
01f9a0: r2 = r10
01f9a8: r2 += -0x400
01f9b0: r3 = *(u64 *)(r10 - 0x458)
01f9b8: call -0x218d ; call 0xed58 / window 263
01f9c0: w1 = *(u32 *)(r10 - 0x1c8)
01f9c8: if r1 == 0x16 goto +0x1 ; branch 0x1f9d8
01f9d0: goto +0x2a ; branch 0x1fb28
01f9d8: r1 = *(u64 *)(r7 + 0x0)
01f9e0: *(u64 *)(r10 - 0x460) = r1
01f9e8: if r1 == 0x0 goto +0x35 ; branch 0x1fb98
01f9f0: r7 = *(u64 *)(r7 + 0x38)
01f9f8: r1 = *(u64 *)(r10 - 0x450)
01fa00: r1 <<= 0x20
01fa08: r1 >>= 0x20
01fa10: if r1 == 0x0 goto +0x33 ; branch 0x1fbb0
01fa18: if r1 == 0x1 goto +0x39 ; branch 0x1fbe8
01fa20: r1 = 0xa500000000 ll
01fa30: *(u64 *)(r6 + 0x0) = r1
01fa38: r1 = r10
01fa40: r1 += -0x3b8
01fa48: call -0x3936 ; call 0x30a0 / window 59
01fa50: goto -0x7e ; branch 0x1f668
01fa58: *(u64 *)(r10 - 0xff0) = r1
01fa60: r1 = 0x1
01fa68: *(u64 *)(r10 - 0xfe8) = r1
01fa70: r1 = *(u64 *)(r10 - 0x468)
01fa78: *(u64 *)(r10 - 0xff8) = r1
01fa80: r1 = r10
01fa88: r1 += -0x400
01fa90: *(u64 *)(r10 - 0x1000) = r1
01fa98: r1 = r10
01faa0: r1 += -0x1c8
01faa8: r5 = r10
01fab0: r2 = *(u64 *)(r10 - 0x448)
01fab8: r3 = *(u64 *)(r10 - 0x458)
01fac0: r4 = *(u64 *)(r10 - 0x460)
01fac8: call -0x2190 ; call 0xee50 / window 265
01fad0: w1 = *(u32 *)(r10 - 0x1c8)
01fad8: if r1 != 0x16 goto +0x9 ; branch 0x1fb28
01fae0: w1 = *(u32 *)(r10 - 0x34c)
01fae8: if r1 == 0x6 goto -0x23 ; branch 0x1f9d8
01faf0: r2 = 0xfffffffb ll
01fb00: r1 &= r2
01fb08: if r1 == 0x0 goto -0x27 ; branch 0x1f9d8
01fb10: r1 = 0x8700000000 ll
01fb20: goto -0x1f ; branch 0x1fa30
01fb28: w2 = *(u32 *)(r10 - 0x1ac)
01fb30: *(u32 *)(r10 - 0x2b8) = w2
01fb38: r3 = *(u64 *)(r10 - 0x1b4)
01fb40: *(u64 *)(r10 - 0x2c0) = r3
01fb48: r4 = *(u64 *)(r10 - 0x1bc)
01fb50: *(u64 *)(r10 - 0x2c8) = r4
01fb58: r5 = *(u64 *)(r10 - 0x1c4)
01fb60: *(u64 *)(r10 - 0x2d0) = r5
01fb68: *(u32 *)(r6 + 0x1c) = w2
01fb70: *(u64 *)(r6 + 0x14) = r3
01fb78: *(u64 *)(r6 + 0xc) = r4
01fb80: *(u64 *)(r6 + 0x4) = r5
01fb88: *(u32 *)(r6 + 0x0) = w1
01fb90: goto -0x2c ; branch 0x1fa38
01fb98: r1 = 0xbe00000000 ll
01fba8: goto -0x30 ; branch 0x1fa30
01fbb0: *(u32 *)(r10 - 0x1c8) = w9
01fbb8: r1 = r10
01fbc0: r1 += -0x98
01fbc8: r2 = r10
01fbd0: r2 += -0x1c8
01fbd8: call -0x3a47 ; call 0x29a8 / window 35
01fbe0: goto +0x6 ; branch 0x1fc18
01fbe8: *(u32 *)(r10 - 0x1c8) = w9
01fbf0: r1 = r10
01fbf8: r1 += -0x98
01fc00: r2 = r10
01fc08: r2 += -0x1c8
01fc10: call -0x3a69 ; call 0x28d0 / window 34
01fc18: r1 = 0x60
01fc20: r2 = 0x8
01fc28: call -0x33f5 ; call 0x5c88 / window 138
01fc30: r9 = r0
01fc38: r1 = r10
01fc40: r1 += -0x410
01fc48: r2 = *(u64 *)(r10 - 0x448)
01fc50: call 0xccbe ; call 0x86248 / window 990
01fc58: r1 = *(u64 *)(r10 - 0x468)
01fc60: r2 = *(u64 *)(r1 + 0x0)
01fc68: r1 = *(u64 *)(r10 - 0x410)
01fc70: *(u64 *)(r10 - 0x468) = r1
01fc78: r1 = *(u64 *)(r10 - 0x408)
01fc80: *(u64 *)(r10 - 0x478) = r1
01fc88: r1 = r10
01fc90: r1 += -0x420
01fc98: *(u64 *)(r10 - 0x4a8) = r2
01fca0: call 0xccb4 ; call 0x86248 / window 990
01fca8: r1 = *(u64 *)(r10 - 0x458)
01fcb0: r2 = *(u64 *)(r1 + 0x0)
01fcb8: r1 = *(u64 *)(r10 - 0x420)
01fcc0: *(u64 *)(r10 - 0x458) = r1
01fcc8: r1 = *(u64 *)(r10 - 0x418)
01fcd0: *(u64 *)(r10 - 0x480) = r1
01fcd8: r1 = *(u64 *)(r10 - 0x90)
01fce0: *(u64 *)(r10 - 0x488) = r1
01fce8: r1 = *(u64 *)(r10 - 0x88)
01fcf0: *(u64 *)(r10 - 0x490) = r1
01fcf8: r1 = r10
01fd00: r1 += -0x430
01fd08: *(u64 *)(r10 - 0x4a0) = r2
01fd10: call 0xcca6 ; call 0x86248 / window 990
01fd18: r2 = *(u64 *)(r7 + 0x0)
01fd20: r1 = *(u64 *)(r10 - 0x430)
01fd28: *(u64 *)(r10 - 0x498) = r1
01fd30: r7 = *(u64 *)(r10 - 0x428)
01fd38: r1 = r10
01fd40: r1 += -0x440
01fd48: *(u64 *)(r10 - 0x4b0) = r2
01fd50: call 0xcc9e ; call 0x86248 / window 990
01fd58: r1 = *(u64 *)(r10 - 0x440)
01fd60: r2 = *(u64 *)(r10 - 0x438)
01fd68: *(u64 *)(r9 + 0x58) = r2
01fd70: *(u64 *)(r9 + 0x50) = r1
01fd78: *(u64 *)(r9 + 0x48) = r7
01fd80: r1 = *(u64 *)(r10 - 0x498)
01fd88: *(u64 *)(r9 + 0x40) = r1
01fd90: r1 = *(u64 *)(r10 - 0x490)
01fd98: *(u64 *)(r9 + 0x38) = r1
01fda0: r1 = *(u64 *)(r10 - 0x488)
01fda8: *(u64 *)(r9 + 0x30) = r1
01fdb0: r1 = *(u64 *)(r10 - 0x480)
01fdb8: *(u64 *)(r9 + 0x28) = r1
01fdc0: r1 = *(u64 *)(r10 - 0x458)
01fdc8: *(u64 *)(r9 + 0x20) = r1
01fdd0: r1 = *(u64 *)(r10 - 0x478)
01fdd8: *(u64 *)(r9 + 0x18) = r1
01fde0: r1 = *(u64 *)(r10 - 0x468)
01fde8: *(u64 *)(r9 + 0x10) = r1
01fdf0: r1 = 0x8
01fdf8: *(u64 *)(r9 + 0x8) = r1
01fe00: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
01fe10: *(u64 *)(r9 + 0x0) = r1
01fe18: r1 = 0x6
01fe20: *(u64 *)(r10 - 0x70) = r1
01fe28: *(u64 *)(r10 - 0x78) = r9
01fe30: *(u64 *)(r10 - 0x80) = r1
01fe38: r1 = r10
01fe40: r1 += -0x1c8
01fe48: r2 = *(u64 *)(r10 - 0x448)
01fe50: r7 = *(u64 *)(r10 - 0x460)
01fe58: r3 = r7
01fe60: r4 = r9
01fe68: r5 = 0x6
01fe70: call -0x2055 ; call 0xfbd0 / window 273
01fe78: w1 = *(u32 *)(r10 - 0x1c8)
01fe80: if r1 != 0x16 goto +0x7d ; branch 0x20270
01fe88: w1 = *(u8 *)(r10 - 0x1c4)
01fe90: *(u8 *)(r10 - 0x61) = w1
01fe98: r1 = r10
01fea0: r1 += -0x80
01fea8: r2 = r10
01feb0: r2 += -0x61
01feb8: r3 = 0x1
01fec0: call -0x34a4 ; call 0x59a8 / window 131
01fec8: r1 = r7
01fed0: call 0xca61 ; call 0x851e0 / window 981
01fed8: if r0 != 0x0 goto +0x1 ; branch 0x1fee8
01fee0: goto +0x7d ; branch 0x202d0
01fee8: r2 = *(u64 *)(r10 - 0x448)
01fef0: r1 = *(u64 *)(r2 + 0x18)
01fef8: *(u64 *)(r10 - 0x1b0) = r1
01ff00: r1 = *(u64 *)(r2 + 0x10)
01ff08: *(u64 *)(r10 - 0x1b8) = r1
01ff10: r1 = *(u64 *)(r2 + 0x8)
01ff18: *(u64 *)(r10 - 0x1c0) = r1
01ff20: r1 = *(u64 *)(r2 + 0x0)
01ff28: *(u64 *)(r10 - 0x1c8) = r1
01ff30: r1 = *(u64 *)(r10 - 0x70)
01ff38: r2 = *(u64 *)(r10 - 0x78)
01ff40: *(u64 *)(r10 - 0xff0) = r2
01ff48: *(u64 *)(r10 - 0xfe8) = r1
01ff50: r1 = 0x62
01ff58: *(u64 *)(r10 - 0xff8) = r1
01ff60: *(u64 *)(r10 - 0x1000) = r8
01ff68: r1 = r10
01ff70: r1 += -0x2d0
01ff78: r2 = r10
01ff80: r2 += -0x1c8
01ff88: r5 = r10
01ff90: r3 = r7
01ff98: r4 = *(u64 *)(r10 - 0x470)
01ffa0: call 0xaa87 ; call 0x753e0 / window 770
01ffa8: w1 = *(u32 *)(r10 - 0x2d0)
01ffb0: if r1 == 0x16 goto +0x1 ; branch 0x1ffc0
01ffb8: goto +0x6c ; branch 0x20320
01ffc0: r2 = *(u64 *)(r10 - 0x450)
01ffc8: r2 <<= 0x20
01ffd0: r2 >>= 0x20
01ffd8: r1 = r2
01ffe0: if r2 == 0x0 goto +0x70 ; branch 0x20368
01ffe8: if r1 == 0x1 goto +0x1 ; branch 0x1fff8
01fff0: goto +0xbd ; branch 0x205e0
01fff8: w7 = *(u8 *)(r10 - 0x61)
020000: r2 = *(u64 *)(r10 - 0x4a8)
020008: r1 = *(u64 *)(r2 + 0x18)
020010: *(u64 *)(r10 - 0x48) = r1
020018: r1 = *(u64 *)(r2 + 0x10)
020020: *(u64 *)(r10 - 0x50) = r1
020028: r1 = *(u64 *)(r2 + 0x8)
020030: *(u64 *)(r10 - 0x58) = r1
020038: r1 = *(u64 *)(r2 + 0x0)
020040: *(u64 *)(r10 - 0x60) = r1
020048: r2 = *(u64 *)(r10 - 0x4b0)
020050: r1 = *(u64 *)(r2 + 0x18)
020058: *(u64 *)(r10 - 0x28) = r1
020060: r1 = *(u64 *)(r2 + 0x10)
020068: *(u64 *)(r10 - 0x30) = r1
020070: r1 = *(u64 *)(r2 + 0x8)
020078: *(u64 *)(r10 - 0x38) = r1
020080: r1 = *(u64 *)(r2 + 0x0)
020088: *(u64 *)(r10 - 0x40) = r1
020090: r2 = *(u64 *)(r10 - 0x4a0)
020098: r1 = *(u64 *)(r2 + 0x18)
0200a0: *(u64 *)(r10 - 0x8) = r1
0200a8: r1 = *(u64 *)(r2 + 0x10)
0200b0: *(u64 *)(r10 - 0x10) = r1
0200b8: r1 = *(u64 *)(r2 + 0x8)
0200c0: *(u64 *)(r10 - 0x18) = r1
0200c8: r1 = *(u64 *)(r2 + 0x0)
0200d0: *(u64 *)(r10 - 0x20) = r1
0200d8: r1 = r10
0200e0: r1 += -0x1c8
0200e8: call 0x4402 ; call 0x42100 / window 355
0200f0: *(u8 *)(r10 - 0x2cc) = w7
0200f8: w1 = *(u32 *)(r10 - 0x1c8)
020100: *(u32 *)(r10 - 0x2d0) = w1
020108: r1 = *(u64 *)(r10 - 0x60)
020110: *(u64 *)(r10 - 0x2cb) = r1
020118: r1 = *(u64 *)(r10 - 0x58)
020120: *(u64 *)(r10 - 0x2c3) = r1
020128: r1 = *(u64 *)(r10 - 0x50)
020130: *(u64 *)(r10 - 0x2bb) = r1
020138: r1 = *(u64 *)(r10 - 0x48)
020140: *(u64 *)(r10 - 0x2b3) = r1
020148: r1 = *(u64 *)(r10 - 0x40)
020150: *(u64 *)(r10 - 0x2ab) = r1
020158: r1 = *(u64 *)(r10 - 0x38)
020160: *(u64 *)(r10 - 0x2a3) = r1
020168: r1 = *(u64 *)(r10 - 0x30)
020170: *(u64 *)(r10 - 0x29b) = r1
020178: r1 = *(u64 *)(r10 - 0x28)
020180: *(u64 *)(r10 - 0x293) = r1
020188: r1 = *(u64 *)(r10 - 0x8)
020190: *(u64 *)(r10 - 0x273) = r1
020198: r1 = *(u64 *)(r10 - 0x10)
0201a0: *(u64 *)(r10 - 0x27b) = r1
0201a8: r1 = *(u64 *)(r10 - 0x18)
0201b0: *(u64 *)(r10 - 0x283) = r1
0201b8: r1 = *(u64 *)(r10 - 0x20)
0201c0: *(u64 *)(r10 - 0x28b) = r1
0201c8: r1 = r10
0201d0: r1 += -0x1c8
0201d8: r2 = *(u64 *)(r10 - 0x460)
0201e0: call 0xca59 ; call 0x854b0 / window 986
0201e8: w1 = *(u32 *)(r10 - 0x1c8)
0201f0: if r1 != 0x16 goto +0x80 ; branch 0x205f8
0201f8: r7 = *(u64 *)(r10 - 0x1b8)
020200: r1 = *(u64 *)(r10 - 0x1c0)
020208: r2 = *(u64 *)(r1 + 0x8)
020210: r1 = *(u64 *)(r1 + 0x0)
020218: r3 = r10
020220: r3 += -0x2d0
020228: call -0x32b9 ; call 0x6c68 / window 161
020230: if r0 == 0x0 goto +0x70 ; branch 0x205b8
020238: r1 = r6
020240: r2 = r0
020248: call 0xcdba ; call 0x87020 / window 1002
020250: r1 = *(u64 *)(r7 + 0x0)
020258: r1 += 0x1
020260: *(u64 *)(r7 + 0x0) = r1
020268: goto +0xf ; branch 0x202e8
020270: w2 = *(u8 *)(r10 - 0x1c4)
020278: w3 = *(u32 *)(r10 - 0x1ac)
020280: *(u32 *)(r6 + 0x1c) = w3
020288: r3 = *(u64 *)(r10 - 0x1b3)
020290: *(u64 *)(r6 + 0x15) = r3
020298: r3 = *(u64 *)(r10 - 0x1bb)
0202a0: *(u64 *)(r6 + 0xd) = r3
0202a8: r3 = *(u64 *)(r10 - 0x1c3)
0202b0: *(u64 *)(r6 + 0x5) = r3
0202b8: *(u8 *)(r6 + 0x4) = w2
0202c0: *(u32 *)(r6 + 0x0) = w1
0202c8: goto +0x3 ; branch 0x202e8
0202d0: r1 = 0x8d00000000 ll
0202e0: *(u64 *)(r6 + 0x0) = r1
0202e8: r1 = r10
0202f0: r1 += -0x80
0202f8: call -0x3a40 ; call 0x3100 / window 60
020300: r1 = r10
020308: r1 += -0x98
020310: call -0x3a54 ; call 0x3078 / window 58
020318: goto -0x11d ; branch 0x1fa38
020320: w2 = *(u32 *)(r10 - 0x2b4)
020328: *(u32 *)(r6 + 0x1c) = w2
020330: r2 = *(u64 *)(r10 - 0x2bc)
020338: *(u64 *)(r6 + 0x14) = r2
020340: r2 = *(u64 *)(r10 - 0x2c4)
020348: *(u64 *)(r6 + 0xc) = r2
020350: r2 = *(u64 *)(r10 - 0x2cc)
020358: *(u64 *)(r6 + 0x4) = r2
020360: goto -0x15 ; branch 0x202c0
020368: w7 = *(u8 *)(r10 - 0x61)
020370: r2 = *(u64 *)(r10 - 0x4a8)
020378: r1 = *(u64 *)(r2 + 0x18)
020380: *(u64 *)(r10 - 0x48) = r1
020388: r1 = *(u64 *)(r2 + 0x10)
020390: *(u64 *)(r10 - 0x50) = r1
020398: r1 = *(u64 *)(r2 + 0x8)
0203a0: *(u64 *)(r10 - 0x58) = r1
0203a8: r1 = *(u64 *)(r2 + 0x0)
0203b0: *(u64 *)(r10 - 0x60) = r1
0203b8: r2 = *(u64 *)(r10 - 0x4b0)
0203c0: r1 = *(u64 *)(r2 + 0x18)
0203c8: *(u64 *)(r10 - 0x28) = r1
0203d0: r1 = *(u64 *)(r2 + 0x10)
0203d8: *(u64 *)(r10 - 0x30) = r1
0203e0: r1 = *(u64 *)(r2 + 0x8)
0203e8: *(u64 *)(r10 - 0x38) = r1
0203f0: r1 = *(u64 *)(r2 + 0x0)
0203f8: *(u64 *)(r10 - 0x40) = r1
020400: r2 = *(u64 *)(r10 - 0x4a0)
020408: r1 = *(u64 *)(r2 + 0x18)
020410: *(u64 *)(r10 - 0x8) = r1
020418: r1 = *(u64 *)(r2 + 0x10)
020420: *(u64 *)(r10 - 0x10) = r1
020428: r1 = *(u64 *)(r2 + 0x8)
020430: *(u64 *)(r10 - 0x18) = r1
020438: r1 = *(u64 *)(r2 + 0x0)
020440: *(u64 *)(r10 - 0x20) = r1
020448: r1 = r10
020450: r1 += -0x1c8
020458: call 0x4386 ; call 0x42090 / window 354
020460: *(u8 *)(r10 - 0x2cc) = w7
020468: w1 = *(u32 *)(r10 - 0x1c8)
020470: *(u32 *)(r10 - 0x2d0) = w1
020478: r1 = *(u64 *)(r10 - 0x60)
020480: *(u64 *)(r10 - 0x2cb) = r1
020488: r1 = *(u64 *)(r10 - 0x58)
020490: *(u64 *)(r10 - 0x2c3) = r1
020498: r1 = *(u64 *)(r10 - 0x50)
0204a0: *(u64 *)(r10 - 0x2bb) = r1
0204a8: r1 = *(u64 *)(r10 - 0x48)
0204b0: *(u64 *)(r10 - 0x2b3) = r1
0204b8: r1 = *(u64 *)(r10 - 0x40)
0204c0: *(u64 *)(r10 - 0x2ab) = r1
0204c8: r1 = *(u64 *)(r10 - 0x38)
0204d0: *(u64 *)(r10 - 0x2a3) = r1
0204d8: r1 = *(u64 *)(r10 - 0x30)
0204e0: *(u64 *)(r10 - 0x29b) = r1
0204e8: r1 = *(u64 *)(r10 - 0x28)
0204f0: *(u64 *)(r10 - 0x293) = r1
0204f8: r1 = *(u64 *)(r10 - 0x8)
020500: *(u64 *)(r10 - 0x273) = r1
020508: r1 = *(u64 *)(r10 - 0x10)
020510: *(u64 *)(r10 - 0x27b) = r1
020518: r1 = *(u64 *)(r10 - 0x18)
020520: *(u64 *)(r10 - 0x283) = r1
020528: r1 = *(u64 *)(r10 - 0x20)
020530: *(u64 *)(r10 - 0x28b) = r1
020538: r1 = r10
020540: r1 += -0x1c8
020548: r2 = *(u64 *)(r10 - 0x460)
020550: call 0xc9eb ; call 0x854b0 / window 986
020558: w1 = *(u32 *)(r10 - 0x1c8)
020560: if r1 == 0x16 goto +0x1 ; branch 0x20570
020568: goto +0x11 ; branch 0x205f8
020570: r7 = *(u64 *)(r10 - 0x1b8)
020578: r1 = *(u64 *)(r10 - 0x1c0)
020580: r2 = *(u64 *)(r1 + 0x8)
020588: r1 = *(u64 *)(r1 + 0x0)
020590: r3 = r10
020598: r3 += -0x2d0
0205a0: call -0x3328 ; call 0x6c68 / window 161
0205a8: if r0 == 0x0 goto +0x1 ; branch 0x205b8
0205b0: goto -0x70 ; branch 0x20238
0205b8: r1 = *(u64 *)(r7 + 0x0)
0205c0: r1 += 0x1
0205c8: *(u64 *)(r7 + 0x0) = r1
0205d0: r1 = 0x16
0205d8: goto -0x64 ; branch 0x202c0
0205e0: r1 = 0xa500000000 ll
0205f0: goto -0x63 ; branch 0x202e0
0205f8: w2 = *(u32 *)(r10 - 0x1c4)
020600: r3 = *(u64 *)(r10 - 0x1c0)
020608: r4 = *(u64 *)(r10 - 0x1b8)
020610: r5 = *(u64 *)(r10 - 0x1b0)
020618: *(u64 *)(r6 + 0x18) = r5
020620: *(u64 *)(r6 + 0x10) = r4
020628: *(u64 *)(r6 + 0x8) = r3
020630: *(u32 *)(r6 + 0x4) = w2
020638: goto -0x70 ; branch 0x202c0
