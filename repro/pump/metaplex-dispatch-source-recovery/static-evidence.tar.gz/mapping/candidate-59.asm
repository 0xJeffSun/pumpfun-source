0030a0: r6 = r1
0030a8: call -0x7 ; call 0x3078 / window 58
0030b0: r1 = r6
0030b8: r1 += 0x18
0030c0: call -0xa ; call 0x3078 / window 58
0030c8: r1 = r6
0030d0: r1 += 0x30
0030d8: call -0xd ; call 0x3078 / window 58
0030e0: r6 += 0x50
0030e8: r1 = r6
0030f0: call -0x41 ; call 0x2ef0 / window 51
0030f8: exit
