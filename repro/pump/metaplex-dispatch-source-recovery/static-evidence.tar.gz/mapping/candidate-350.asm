03cc10: r9 = r3
03cc18: r8 = r1
03cc20: r3 = *(u64 *)(r5 - 0xff8)
03cc28: if r3 == 0x0 goto +0x1c ; branch 0x3cd10
03cc30: *(u64 *)(r10 - 0x920) = r4
03cc38: *(u64 *)(r10 - 0x928) = r2
03cc40: r6 = *(u64 *)(r5 - 0x1000)
03cc48: r1 = r10
03cc50: r1 += -0x6c8
03cc58: r2 = r6
03cc60: call -0x6cd0 ; call 0x65e8 / window 154
03cc68: w7 = *(u32 *)(r10 - 0x6c8)
03cc70: if r7 == 0x3a goto +0x1 ; branch 0x3cc80
03cc78: goto +0x16 ; branch 0x3cd30
03cc80: r1 = 0x2
03cc88: w2 = *(u8 *)(r6 + 0x0)
03cc90: if r2 > 0x30 goto +0x8 ; branch 0x3ccd8
03cc98: r3 = 0x1
03cca0: r3 <<= r2
03cca8: r2 = 0x100000001036f ll
03ccb8: r3 &= r2
03ccc0: if r3 != 0x0 goto +0x1 ; branch 0x3ccd0
03ccc8: goto +0x1 ; branch 0x3ccd8
03ccd0: r1 = 0x0
03ccd8: r2 = 0x4b
03cce0: *(u32 *)(r8 + 0x4) = w2
03cce8: *(u32 *)(r8 + 0x0) = w1
03ccf0: r1 = r10
03ccf8: r1 += -0x6c8
03cd00: call -0x73be ; call 0x2f18 / window 52
03cd08: goto +0x3 ; branch 0x3cd28
03cd10: r1 = 0xbd00000000 ll
03cd20: *(u64 *)(r8 + 0x0) = r1
03cd28: exit
03cd30: *(u64 *)(r10 - 0x930) = r8
03cd38: r1 = *(u64 *)(r10 - 0x6b8)
03cd40: *(u64 *)(r10 - 0x818) = r1
03cd48: r1 = *(u64 *)(r10 - 0x6b0)
03cd50: *(u64 *)(r10 - 0x810) = r1
03cd58: r1 = *(u64 *)(r10 - 0x6a8)
03cd60: *(u64 *)(r10 - 0x808) = r1
03cd68: r6 = *(u64 *)(r10 - 0x6c4)
03cd70: w8 = *(u32 *)(r10 - 0x6bc)
03cd78: r1 = r10
03cd80: r1 += -0x800
03cd88: r2 = r10
03cd90: r2 += -0x6a0
03cd98: r3 = 0x138
03cda0: call 0xb81d ; call 0x98e90 / window 1246
03cda8: *(u32 *)(r10 - 0x81c) = w8
03cdb0: *(u64 *)(r10 - 0x824) = r6
03cdb8: *(u32 *)(r10 - 0x828) = w7
03cdc0: r1 = *(u64 *)(r10 - 0x928)
03cdc8: *(u64 *)(r10 - 0x6c8) = r1
03cdd0: r1 = r10
03cdd8: r1 += -0x838
03cde0: *(u64 *)(r10 - 0x938) = r9
03cde8: r2 = r9
03cdf0: r3 = *(u64 *)(r10 - 0x920)
03cdf8: call 0x76f3 ; call 0x78598 / window 802
03ce00: r1 = r10
03ce08: r1 += -0x820
03ce10: *(u64 *)(r10 - 0x940) = r1
03ce18: r1 = r10
03ce20: r1 += -0x818
03ce28: *(u64 *)(r10 - 0x948) = r1
03ce30: r9 = *(u64 *)(r10 - 0x838)
03ce38: r6 = *(u64 *)(r10 - 0x830)
03ce40: r6 += 0x18
03ce48: r8 = 0x3
03ce50: r7 = r6
03ce58: r7 += -0x18
03ce60: if r7 == r9 goto +0x23 ; branch 0x3cf80
03ce68: r2 = r10
03ce70: r2 += -0x6c8
03ce78: r1 = r6
03ce80: call -0x743a ; call 0x2cb8 / window 41
03ce88: if r0 == 0x0 goto +0x1c ; branch 0x3cf70
03ce90: r1 = r7
03ce98: call 0x9047 ; call 0x850d8 / window 981
03cea0: if r0 != 0x0 goto +0x19 ; branch 0x3cf70
03cea8: r2 = *(u64 *)(r6 - 0x8)
03ceb0: r2 += 0x10
03ceb8: r1 = r10
03cec0: r1 += -0x848
03cec8: r3 = 0x9f2c0 ll ; data b'\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00'
03ced8: call -0x72c0 ; call 0x38e0 / window 87
03cee0: r3 = *(u64 *)(r10 - 0x848)
03cee8: r2 = *(u64 *)(r3 + 0x8)
03cef0: if r2 == 0x0 goto +0x2b0 ; branch 0x3e478
03cef8: r1 = *(u64 *)(r10 - 0x840)
03cf00: r3 = *(u64 *)(r3 + 0x0)
03cf08: w4 = *(u8 *)(r3 + 0x0)
03cf10: if r4 == 0xb goto +0x1 ; branch 0x3cf20
03cf18: goto +0x7 ; branch 0x3cf58
03cf20: if r8 > r2 goto +0x2af ; branch 0x3e4a0
03cf28: w2 = *(u8 *)(r3 + 0x2)
03cf30: r3 = *(u64 *)(r1 + 0x0)
03cf38: r3 += -0x1
03cf40: *(u64 *)(r1 + 0x0) = r3
03cf48: if r2 == 0x1 goto +0x6 ; branch 0x3cf80
03cf50: goto +0x3 ; branch 0x3cf70
03cf58: r2 = *(u64 *)(r1 + 0x0)
03cf60: r2 += -0x1
03cf68: *(u64 *)(r1 + 0x0) = r2
03cf70: r6 += 0x30
03cf78: goto -0x26 ; branch 0x3ce50
03cf80: w1 = *(u32 *)(r10 - 0x828)
03cf88: if r7 == r9 goto +0x1 ; branch 0x3cf98
03cf90: if r1 != 0x2f goto +0x41 ; branch 0x3d1a0
03cf98: if r1 == 0x29 goto +0xc4 ; branch 0x3d5c0
03cfa0: r8 = *(u64 *)(r10 - 0x930)
03cfa8: r9 = *(u64 *)(r10 - 0x938)
03cfb0: if r1 == 0x2a goto +0x50 ; branch 0x3d238
03cfb8: if r1 == 0x2b goto +0x1bf ; branch 0x3ddb8
03cfc0: if r1 == 0x2c goto +0x87 ; branch 0x3d400
03cfc8: if r1 == 0x2d goto +0x65 ; branch 0x3d2f8
03cfd0: if r1 == 0x2e goto +0x70 ; branch 0x3d358
03cfd8: if r1 == 0x2f goto +0x1d5 ; branch 0x3de88
03cfe0: if r1 == 0x30 goto +0x1d1 ; branch 0x3de70
03cfe8: if r1 == 0x31 goto +0xa7 ; branch 0x3d528
03cff0: if r1 == 0x32 goto +0x1a5 ; branch 0x3dd20
03cff8: if r1 == 0x34 goto +0x18c ; branch 0x3dc60
03d000: if r1 == 0x35 goto +0x197 ; branch 0x3dcc0
03d008: if r1 == 0x36 goto +0xcc ; branch 0x3d670
03d010: if r1 == 0x37 goto +0x93 ; branch 0x3d4b0
03d018: if r1 == 0x38 goto +0xc1 ; branch 0x3d628
03d020: if r1 == 0x39 goto +0x1 ; branch 0x3d030
03d028: goto +0x1df ; branch 0x3df28
03d030: r1 = 0x9a8da ll ; data b'IX: Close AccountsIX: ResizeIX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: Revok'
03d040: r2 = 0x12
03d048: call -0x1 ; external sol_log_
03d050: r1 = 0x5
03d058: r2 = *(u64 *)(r10 - 0x920)
03d060: if r1 > r2 goto +0x265 ; branch 0x3e390
03d068: r1 = r10
03d070: r1 += -0x6c8
03d078: r2 = r9
03d080: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03d090: call -0x5a8d ; call 0xfc30 / window 275
03d098: w1 = *(u32 *)(r10 - 0x6c8)
03d0a0: if r1 == 0x16 goto +0x1 ; branch 0x3d0b0
03d0a8: goto +0x252 ; branch 0x3e340
03d0b0: r6 = r9
03d0b8: r9 += 0x60
03d0c0: r1 = r9
03d0c8: call 0x9001 ; call 0x850d8 / window 981
03d0d0: if r0 != 0x0 goto +0x1 ; branch 0x3d0e0
03d0d8: goto +0x259 ; branch 0x3e3a8
03d0e0: r1 = r6
03d0e8: r1 += 0x78
03d0f0: r2 = 0x9ec58 ll ; data b'\x00\x00\x00\x00\xd8\x98\t\x00\x00\x00\x00\x00\xb8\x99\t\x00\x00\x00\x00\x00\x08\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x008\x99\t\x00\x00\x00\x00\x00*\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00P\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00'
03d100: call -0x748a ; call 0x2cb8 / window 41
03d108: r7 = 0x1
03d110: if r0 == 0x0 goto +0x252 ; branch 0x3e3a8
03d118: r6 += 0x90
03d120: r1 = r10
03d128: r1 += -0x6c8
03d130: r2 = r6
03d138: call 0x7290 ; call 0x765c0 / window 773
03d140: w1 = *(u32 *)(r10 - 0x6c8)
03d148: if r1 == 0x16 goto +0x1 ; branch 0x3d158
03d150: goto +0x256 ; branch 0x3e408
03d158: r1 = *(u64 *)(r6 + 0x0)
03d160: r2 = 0x99818 ll ; data b'\xa3\xa5\x8eL\x1e\xd7\x93y\x0eG\xa3\xfc\xb8\\\xa0\xebQ9\x1e\x8c"\x7f\xf8\r\xef\x94@\x97O\xf2\x83\xf8\x18\xbe5\xe8|\xe3DRal\x90\xe1\x06\xe9z\x00C\xaf\x8f\xc7\rAR\\4}\xfe\xb4\xbe\xe1\xdf\x89\x8c\x97%\x8fN$\x89\xf1\xbb=\x10)\x14\x8e\r\x83\x0bZ\x13\x99\xda\xff\x10\x84\x04\x8e{\xd8\xdb\xe9\xf8Y\x98\x8b\x80\xeb'
03d170: call -0x748d ; call 0x2d10 / window 44
03d178: if r0 != 0x0 goto +0x1 ; branch 0x3d188
03d180: goto +0x2e7 ; branch 0x3e8c0
03d188: r1 = 0xbc00000000 ll
03d198: goto +0x274 ; branch 0x3e540
03d1a0: r2 = 0x9b00000000 ll
03d1b0: r3 = *(u64 *)(r10 - 0x930)
03d1b8: *(u64 *)(r3 + 0x0) = r2
03d1c0: r2 = r1
03d1c8: r2 += -0x34
03d1d0: r3 = 0x2
03d1d8: if r3 > r2 goto -0x97 ; branch 0x3cd28
03d1e0: if r1 == 0x29 goto -0x98 ; branch 0x3cd28
03d1e8: if r1 == 0x2a goto +0x29a ; branch 0x3e6c0
03d1f0: if r1 == 0x2b goto +0x28b ; branch 0x3e650
03d1f8: if r1 == 0x2c goto +0x29d ; branch 0x3e6e8
03d200: if r1 == 0x2d goto -0x9c ; branch 0x3cd28
03d208: if r1 == 0x2e goto +0x291 ; branch 0x3e698
03d210: if r1 == 0x2f goto +0x290 ; branch 0x3e698
03d218: if r1 == 0x31 goto +0x286 ; branch 0x3e650
03d220: if r1 == 0x32 goto +0x289 ; branch 0x3e670
03d228: if r1 == 0x37 goto -0xa1 ; branch 0x3cd28
03d230: goto +0x279 ; branch 0x3e600
03d238: r1 = 0x9a94b ll ; data b'IX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Editio'
03d248: r2 = 0xa
03d250: call -0x1 ; external sol_log_
03d258: r6 = r10
03d260: r6 += -0x6c8
03d268: r1 = r6
03d270: r2 = *(u64 *)(r10 - 0x940)
03d278: r3 = 0x108
03d280: call 0xb781 ; call 0x98e90 / window 1246
03d288: r1 = r8
03d290: r2 = *(u64 *)(r10 - 0x928)
03d298: r3 = r9
03d2a0: r4 = *(u64 *)(r10 - 0x920)
03d2a8: r5 = r6
03d2b0: call -0x290f ; call 0x28a40 / window 321
03d2b8: r6 = 0x0
03d2c0: r1 = 0x1
03d2c8: r2 = 0x1
03d2d0: r3 = 0x1
03d2d8: r4 = 0x1
03d2e0: r5 = 0x1
03d2e8: r0 = 0x1
03d2f0: goto +0x252 ; branch 0x3e588
03d2f8: w6 = *(u32 *)(r10 - 0x820)
03d300: r1 = 0x9a935 ll ; data b'IX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow '
03d310: r2 = 0xa
03d318: call -0x1 ; external sol_log_
03d320: r1 = r8
03d328: r2 = *(u64 *)(r10 - 0x928)
03d330: r3 = r9
03d338: r4 = *(u64 *)(r10 - 0x920)
03d340: r5 = r6
03d348: call -0x39b2 ; call 0x205c0 / window 313
03d350: goto +0x23f ; branch 0x3e550
03d358: r1 = 0x9a0f0 ll ; data b'IX: LockDelegatemetadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/'
03d368: r2 = 0x8
03d370: call -0x1 ; external sol_log_
03d378: r6 = r10
03d380: r6 += -0x6c8
03d388: r1 = r6
03d390: r2 = *(u64 *)(r10 - 0x940)
03d398: r3 = 0x38
03d3a0: call 0xb75d ; call 0x98e90 / window 1246
03d3a8: r1 = r8
03d3b0: r2 = *(u64 *)(r10 - 0x928)
03d3b8: r3 = r9
03d3c0: r4 = *(u64 *)(r10 - 0x920)
03d3c8: r5 = r6
03d3d0: call -0xe07 ; call 0x363a0 / window 341
03d3d8: r4 = 0x0
03d3e0: r1 = 0x1
03d3e8: r2 = 0x1
03d3f0: r3 = 0x1
03d3f8: goto +0x22e ; branch 0x3e570
03d400: r1 = 0x9a93f ll ; data b'IX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX:'
03d410: r2 = 0xc
03d418: call -0x1 ; external sol_log_
03d420: r6 = r10
03d428: r6 += -0x6c8
03d430: r1 = r6
03d438: r2 = *(u64 *)(r10 - 0x940)
03d440: r3 = 0x60
03d448: call 0xb748 ; call 0x98e90 / window 1246
03d450: r1 = r8
03d458: r2 = *(u64 *)(r10 - 0x928)
03d460: r3 = r9
03d468: r4 = *(u64 *)(r10 - 0x920)
03d470: r5 = r6
03d478: call -0x4015 ; call 0x1d3d8 / window 311
03d480: r5 = 0x0
03d488: r1 = 0x1
03d490: r2 = 0x1
03d498: r3 = 0x1
03d4a0: r4 = 0x1
03d4a8: goto +0x219 ; branch 0x3e578
03d4b0: r6 = *(u64 *)(r10 - 0x818)
03d4b8: w7 = *(u32 *)(r10 - 0x820)
03d4c0: r1 = 0x9a8f6 ll ; data b'IX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: T'
03d4d0: r2 = 0x9
03d4d8: call -0x1 ; external sol_log_
03d4e0: *(u64 *)(r10 - 0x1000) = r7
03d4e8: *(u64 *)(r10 - 0xff8) = r6
03d4f0: r5 = r10
03d4f8: r1 = r8
03d500: r2 = *(u64 *)(r10 - 0x928)
03d508: r3 = r9
03d510: r4 = *(u64 *)(r10 - 0x920)
03d518: call -0x22b3 ; call 0x2bf88 / window 325
03d520: goto +0x205 ; branch 0x3e550
03d528: r1 = 0x9a91f ll ; data b'IX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow Acc'
03d538: r2 = 0xc
03d540: call -0x1 ; external sol_log_
03d548: r6 = r10
03d550: r6 += -0x6c8
03d558: r1 = r6
03d560: r2 = *(u64 *)(r10 - 0x940)
03d568: r3 = 0x40
03d570: call 0xb723 ; call 0x98e90 / window 1246
03d578: r1 = r8
03d580: r2 = *(u64 *)(r10 - 0x928)
03d588: r3 = r9
03d590: r4 = *(u64 *)(r10 - 0x920)
03d598: r5 = r6
03d5a0: call -0x1c0e ; call 0x2f538 / window 335
03d5a8: r2 = 0x0
03d5b0: r1 = 0x1
03d5b8: goto +0x1f4 ; branch 0x3e560
03d5c0: r6 = *(u64 *)(r10 - 0x818)
03d5c8: r1 = 0x9a0a8 ll ; data b'IX: BurnCpiGuardDeadlockNotFound\x02\x00\x00\x00\x04\x00\x00\x00TransferTimedOut\xff\xff\xff\xff\xff\xff\xff\xff\x01\x00\x00\x00\x03\x00\x00\x00IX: LockDelegatemetadatadead'
03d5d8: r2 = 0x8
03d5e0: call -0x1 ; external sol_log_
03d5e8: *(u64 *)(r10 - 0xff8) = r6
03d5f0: r5 = r10
03d5f8: r1 = *(u64 *)(r10 - 0x930)
03d600: r2 = *(u64 *)(r10 - 0x928)
03d608: r3 = *(u64 *)(r10 - 0x938)
03d610: r4 = *(u64 *)(r10 - 0x920)
03d618: call -0x57c6 ; call 0x117f0 / window 296
03d620: goto +0x1e5 ; branch 0x3e550
03d628: r1 = 0x9a8ec ll ; data b'IX: ResizeIX: PrintIX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: C'
03d638: r2 = 0xa
03d640: call -0x1 ; external sol_log_
03d648: r1 = r8
03d650: r3 = r9
03d658: r4 = *(u64 *)(r10 - 0x920)
03d660: call -0x109e ; call 0x35178 / window 340
03d668: goto +0x1dc ; branch 0x3e550
03d670: r1 = *(u64 *)(r10 - 0x928)
03d678: *(u64 *)(r10 - 0x568) = r1
03d680: *(u64 *)(r10 - 0x360) = r9
03d688: r1 = *(u64 *)(r10 - 0x920)
03d690: r1 *= 0x30
03d698: r9 += r1
03d6a0: *(u64 *)(r10 - 0x368) = r9
03d6a8: r1 = r10
03d6b0: r1 += -0x6c8
03d6b8: r2 = r10
03d6c0: r2 += -0x368
03d6c8: call 0x89b2 ; call 0x82460 / window 881
03d6d0: w1 = *(u32 *)(r10 - 0x6c8)
03d6d8: if r1 != 0x16 goto +0x183 ; branch 0x3e2f8
03d6e0: r6 = *(u64 *)(r10 - 0x6c0)
03d6e8: r1 = r10
03d6f0: r1 += -0x6c8
03d6f8: r2 = r6
03d700: call 0x71d7 ; call 0x765c0 / window 773
03d708: w1 = *(u32 *)(r10 - 0x6c8)
03d710: if r1 == 0x16 goto +0x1 ; branch 0x3d720
03d718: goto +0x184 ; branch 0x3e340
03d720: r1 = *(u64 *)(r6 + 0x0)
03d728: r2 = 0x99738 ll ; data b"\x05\x08\xec{r\xc5_\x8e\x93\xb1\xdd\xea\xa5C\nXjq\xdd\x99\xc90\xa3)\x17w\t$\xceq\x91\xea\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcInvalid Escrow Account Bump SeedAmou"
03d738: call -0x7546 ; call 0x2d10 / window 44
03d740: if r0 != 0x0 goto +0x1a3 ; branch 0x3e460
03d748: r1 = r10
03d750: r1 += -0x6c8
03d758: r2 = r10
03d760: r2 += -0x368
03d768: call 0x899e ; call 0x82460 / window 881
03d770: w1 = *(u32 *)(r10 - 0x6c8)
03d778: if r1 == 0x16 goto +0x1 ; branch 0x3d788
03d780: goto +0x16e ; branch 0x3e2f8
03d788: r1 = *(u64 *)(r10 - 0x6c0)
03d790: *(u64 *)(r10 - 0x938) = r1
03d798: r1 = *(u64 *)(r1 + 0x0)
03d7a0: r2 = 0x99838 ll ; data b'\x18\xbe5\xe8|\xe3DRal\x90\xe1\x06\xe9z\x00C\xaf\x8f\xc7\rAR\\4}\xfe\xb4\xbe\xe1\xdf\x89\x8c\x97%\x8fN$\x89\xf1\xbb=\x10)\x14\x8e\r\x83\x0bZ\x13\x99\xda\xff\x10\x84\x04\x8e{\xd8\xdb\xe9\xf8Y\x98\x8b\x80\xeby5(i\xb2$t_Y\xdd\xbf\x8a&X\xca\x13\xdch\x81!&5\x1c\xae\x07\xc1\xa5\xa5\xed\x03H\x1d'
03d7b0: call -0x7555 ; call 0x2d10 / window 44
03d7b8: if r0 != 0x0 goto +0x22c ; branch 0x3e920
03d7c0: r6 = *(u64 *)(r10 - 0x360)
03d7c8: r1 = *(u64 *)(r10 - 0x368)
03d7d0: if r6 != r1 goto +0x1 ; branch 0x3d7e0
03d7d8: goto +0x43a ; branch 0x3f9b0
03d7e0: r1 = r6
03d7e8: r1 += 0x30
03d7f0: *(u64 *)(r10 - 0x360) = r1
03d7f8: r1 = r6
03d800: r1 += 0x18
03d808: r2 = r10
03d810: r2 += -0x568
03d818: call -0x7569 ; call 0x2cd8 / window 42
03d820: if r0 != 0x0 goto +0x21f ; branch 0x3e920
03d828: *(u64 *)(r10 - 0x920) = r6
03d830: r2 = *(u64 *)(r6 + 0x10)
03d838: r2 += 0x10
03d840: r1 = r10
03d848: r1 += -0x888
03d850: r3 = 0x9ef78 ll ; data b'\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00*\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00H\x00\x00\x00\x1a\x00\x00\x00\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x0b\xa6\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00'
03d860: call -0x73f1 ; call 0x38e0 / window 87
03d868: r2 = *(u64 *)(r10 - 0x888)
03d870: r3 = *(u64 *)(r2 + 0x8)
03d878: r1 = 0x9a03d ll ; data b'\x00Invalid Option representation: . The first byte must be 0 or 1src/entrypoint.rs\x00\x00\x00IX: Mint (bytes D'
03d888: if r3 == 0x0 goto +0x1 ; branch 0x3d898
03d890: r1 = *(u64 *)(r2 + 0x0)
03d898: w1 = *(u8 *)(r1 + 0x0)
03d8a0: r6 = *(u64 *)(r10 - 0x880)
03d8a8: call -0x7a01 ; call 0x8a8 / window 11
03d8b0: r7 = r0
03d8b8: r1 = *(u64 *)(r6 + 0x0)
03d8c0: r1 += -0x1
03d8c8: *(u64 *)(r6 + 0x0) = r1
03d8d0: r8 = 0xbf
03d8d8: r9 = 0x0
03d8e0: r7 <<= 0x20
03d8e8: r7 >>= 0x20
03d8f0: if r7 == 0xf goto +0x3e9 ; branch 0x3f840
03d8f8: r1 = r10
03d900: r1 += -0x6c8
03d908: call 0x999b ; call 0x8a5e8 / window 1033
03d910: w9 = *(u32 *)(r10 - 0x6c8)
03d918: if r9 != 0x16 goto +0x3e0 ; branch 0x3f820
03d920: r1 = *(u64 *)(r10 - 0x6b0)
03d928: *(u64 *)(r10 - 0x120) = r1
03d930: r1 = *(u64 *)(r10 - 0x6b8)
03d938: *(u64 *)(r10 - 0x128) = r1
03d940: r1 = *(u64 *)(r10 - 0x6c0)
03d948: *(u64 *)(r10 - 0x130) = r1
03d950: r6 = *(u64 *)(r10 - 0x920)
03d958: r1 = r6
03d960: call 0x8ee0 ; call 0x85068 / window 980
03d968: r1 = r10
03d970: r1 += -0x130
03d978: r2 = r0
03d980: call 0x9398 ; call 0x87648 / window 1009
03d988: *(u64 *)(r10 - 0x928) = r0
03d990: if r7 == 0x0 goto +0xd ; branch 0x3da00
03d998: r8 = 0xbf
03d9a0: r9 = 0x0
03d9a8: if r7 == 0x4 goto +0x1 ; branch 0x3d9b8
03d9b0: goto +0x3d1 ; branch 0x3f840
03d9b8: r1 = *(u64 *)(r10 - 0x920)
03d9c0: call 0x8ebb ; call 0x84fa0 / window 979
03d9c8: r6 = r0
03d9d0: r8 = 0x33
03d9d8: r4 = *(u64 *)(r10 - 0x928)
03d9e0: if r4 > r6 goto +0x3cb ; branch 0x3f840
03d9e8: r1 = *(u64 *)(r10 - 0x928)
03d9f0: r6 -= r1
03d9f8: goto +0x9 ; branch 0x3da48
03da00: r1 = r6
03da08: r2 = 0x998d8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
03da18: call 0x8f7e ; call 0x85610 / window 988
03da20: r1 = r6
03da28: call 0x8eae ; call 0x84fa0 / window 979
03da30: r6 = r0
03da38: r1 = 0x0
03da40: *(u64 *)(r10 - 0x928) = r1
03da48: r1 = *(u64 *)(r10 - 0x938)
03da50: call 0x8ea9 ; call 0x84fa0 / window 979
03da58: r7 = r0
03da60: r7 += r6
03da68: r9 = 0x0
03da70: r4 = 0x1
03da78: if r0 > r7 goto +0x1 ; branch 0x3da88
03da80: r4 = 0x0
03da88: r8 = 0x33
03da90: r4 &= 0x1
03da98: if r4 != 0x0 goto +0x3b4 ; branch 0x3f840
03daa0: r1 = *(u64 *)(r10 - 0x938)
03daa8: r2 = *(u64 *)(r1 + 0x8)
03dab0: r2 += 0x10
03dab8: r1 = r10
03dac0: r1 += -0x898
03dac8: r3 = 0x9ef90 ll ; data b'\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00H\x00\x00\x00\x1a\x00\x00\x00\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x0b\xa6\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00C\xa6\t\x006\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00'
03dad8: call -0x7452 ; call 0x3850 / window 86
03dae0: r1 = *(u64 *)(r10 - 0x898)
03dae8: r1 = *(u64 *)(r1 + 0x0)
03daf0: r2 = *(u64 *)(r10 - 0x890)
03daf8: *(u64 *)(r1 + 0x0) = r7
03db00: r1 = *(u64 *)(r2 + 0x0)
03db08: r1 += 0x1
03db10: *(u64 *)(r2 + 0x0) = r1
03db18: r6 = *(u64 *)(r10 - 0x920)
03db20: r2 = *(u64 *)(r6 + 0x8)
03db28: r2 += 0x10
03db30: r1 = r10
03db38: r1 += -0x8a8
03db40: r3 = 0x9efa8 ll ; data b'\x00\x00\x00\x00x\x99\t\x00 \x00\x00\x00\x00\x00\x00\x00K\x00\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x0b\xa6\t\x008\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00C\xa6\t\x006\x00\x00\x00\x00\x00\x00\x00J\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00y\xa6\t\x00(\x00\x00\x00\x00\x00\x00\x00\x9f\x00\x00\x004\x00\x00\x00\x00\x00\x00\x00'
03db50: call -0x7461 ; call 0x3850 / window 86
03db58: r1 = *(u64 *)(r10 - 0x8a8)
03db60: r1 = *(u64 *)(r1 + 0x0)
03db68: r2 = *(u64 *)(r10 - 0x8a0)
03db70: r3 = *(u64 *)(r10 - 0x928)
03db78: *(u64 *)(r1 + 0x0) = r3
03db80: r1 = *(u64 *)(r2 + 0x0)
03db88: r1 += 0x1
03db90: *(u64 *)(r2 + 0x0) = r1
03db98: r1 = r6
03dba0: call 0x8e98 ; call 0x85068 / window 980
03dba8: r6 = r0
03dbb0: if r6 == 0x0 goto +0x391 ; branch 0x3f840
03dbb8: r1 = r10
03dbc0: r1 += -0x6c8
03dbc8: r2 = *(u64 *)(r10 - 0x920)
03dbd0: call 0x8efa ; call 0x853a8 / window 986
03dbd8: w9 = *(u32 *)(r10 - 0x6c8)
03dbe0: if r9 != 0x16 goto +0x387 ; branch 0x3f820
03dbe8: r6 += -0x1
03dbf0: r1 = *(u64 *)(r10 - 0x6b8)
03dbf8: r2 = *(u64 *)(r10 - 0x6c0)
03dc00: r3 = *(u64 *)(r2 + 0x8)
03dc08: if r3 > r6 goto +0x1 ; branch 0x3dc18
03dc10: goto +0x4 ; branch 0x3dc38
03dc18: r2 = *(u64 *)(r2 + 0x0)
03dc20: r2 += r6
03dc28: r3 = 0x0
03dc30: *(u8 *)(r2 + 0x0) = w3
03dc38: r2 = *(u64 *)(r1 + 0x0)
03dc40: r2 += 0x1
03dc48: *(u64 *)(r1 + 0x0) = r2
03dc50: r8 = *(u64 *)(r10 - 0x930)
03dc58: goto -0x94 ; branch 0x3d7c0
03dc60: w6 = *(u32 *)(r10 - 0x820)
03dc68: r1 = 0x9a90b ll ; data b'IX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of Escrow'
03dc78: r2 = 0xa
03dc80: call -0x1 ; external sol_log_
03dc88: r1 = r8
03dc90: r2 = *(u64 *)(r10 - 0x928)
03dc98: r3 = r9
03dca0: r4 = *(u64 *)(r10 - 0x920)
03dca8: r5 = r6
03dcb0: call -0x58f ; call 0x3b040 / window 348
03dcb8: goto +0x112 ; branch 0x3e550
03dcc0: w6 = *(u32 *)(r10 - 0x820)
03dcc8: r1 = 0x9a8ff ll ; data b'IX: UnverifyIX: VerifyIX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer O'
03dcd8: r2 = 0xc
03dce0: call -0x1 ; external sol_log_
03dce8: r1 = r8
03dcf0: r2 = *(u64 *)(r10 - 0x928)
03dcf8: r3 = r9
03dd00: r4 = *(u64 *)(r10 - 0x920)
03dd08: r5 = r6
03dd10: call -0x404 ; call 0x3bcf8 / window 349
03dd18: goto +0x106 ; branch 0x3e550
03dd20: r1 = 0x9a915 ll ; data b'IX: UpdateIX: TransferIX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close '
03dd30: r2 = 0xa
03dd38: call -0x1 ; external sol_log_
03dd40: r6 = r10
03dd48: r6 += -0x6c8
03dd50: r1 = r6
03dd58: r2 = *(u64 *)(r10 - 0x940)
03dd60: r3 = 0x158
03dd68: call 0xb624 ; call 0x98e90 / window 1246
03dd70: r1 = r8
03dd78: r2 = *(u64 *)(r10 - 0x928)
03dd80: r3 = r9
03dd88: r4 = *(u64 *)(r10 - 0x920)
03dd90: r5 = r6
03dd98: call -0x178f ; call 0x32128 / window 337
03dda0: r2 = 0x1
03dda8: r1 = 0x0
03ddb0: goto +0xf5 ; branch 0x3e560
03ddb8: r1 = 0x9a090 ll ; data b'IX: Mint (bytes DataItemIX: BurnCpiGuardDeadlockNotFound\x02\x00\x00\x00\x04\x00\x00\x00TransferTimedOut\xff\xff\xff\xff\xff\xff\xff\xff\x01\x00\x00\x00\x03\x00\x00\x00IX: '
03ddc8: r2 = 0x8
03ddd0: call -0x1 ; external sol_log_
03ddd8: r6 = r10
03dde0: r6 += -0x6c8
03dde8: r1 = r6
03ddf0: r2 = *(u64 *)(r10 - 0x940)
03ddf8: r3 = 0x40
03de00: call 0xb611 ; call 0x98e90 / window 1246
03de08: r1 = r8
03de10: r2 = *(u64 *)(r10 - 0x928)
03de18: r3 = r9
03de20: r4 = *(u64 *)(r10 - 0x920)
03de28: r5 = r6
03de30: call -0x285f ; call 0x29b40 / window 323
03de38: r0 = 0x0
03de40: r1 = 0x1
03de48: r2 = 0x1
03de50: r3 = 0x1
03de58: r4 = 0x1
03de60: r5 = 0x1
03de68: goto +0xe2 ; branch 0x3e580
03de70: r1 = 0x4b00000000 ll
03de80: goto +0xa2 ; branch 0x3e398
03de88: r1 = 0x9a92b ll ; data b'IX: UnlockIX: RevokeIX: DelegateIX: CreateIX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Crea'
03de98: r2 = 0xa
03dea0: call -0x1 ; external sol_log_
03dea8: r6 = r10
03deb0: r6 += -0x6c8
03deb8: r1 = r6
03dec0: r2 = *(u64 *)(r10 - 0x940)
03dec8: r3 = 0x38
03ded0: call 0xb5f7 ; call 0x98e90 / window 1246
03ded8: r1 = r8
03dee0: r2 = *(u64 *)(r10 - 0x928)
03dee8: r3 = r9
03def0: r4 = *(u64 *)(r10 - 0x920)
03def8: r5 = r6
03df00: call -0xf3a ; call 0x36538 / window 342
03df08: r3 = 0x0
03df10: r1 = 0x1
03df18: r2 = 0x1
03df20: goto +0xc8 ; branch 0x3e568
03df28: r1 = *(u64 *)(r10 - 0x928)
03df30: *(u64 *)(r10 - 0x438) = r1
03df38: r1 = r10
03df40: r1 += -0x8b8
03df48: r2 = r9
03df50: r3 = *(u64 *)(r10 - 0x920)
03df58: call 0x74c7 ; call 0x78598 / window 802
03df60: r1 = r10
03df68: r1 += -0x110
03df70: *(u64 *)(r10 - 0x958) = r1
03df78: r1 = r10
03df80: r1 += -0x12b
03df88: *(u64 *)(r10 - 0x960) = r1
03df90: r1 = r10
03df98: r1 += -0x6a8
03dfa0: *(u64 *)(r10 - 0x968) = r1
03dfa8: r1 = r10
03dfb0: r1 += -0x6c3
03dfb8: *(u64 *)(r10 - 0x950) = r1
03dfc0: r1 = r10
03dfc8: r1 += -0xe8
03dfd0: *(u64 *)(r10 - 0x980) = r1
03dfd8: r1 = r10
03dfe0: r1 += -0x24
03dfe8: *(u64 *)(r10 - 0x970) = r1
03dff0: r1 = r10
03dff8: r1 += -0x5bc
03e000: *(u64 *)(r10 - 0x978) = r1
03e008: r8 = *(u64 *)(r10 - 0x8b8)
03e010: r7 = *(u64 *)(r10 - 0x8b0)
03e018: r7 += 0x18
03e020: *(u64 *)(r10 - 0x988) = r8
03e028: r9 = 0x0
03e030: r6 = r7
03e038: r6 += -0x18
03e040: if r6 == r8 goto +0x9b ; branch 0x3e520
03e048: r2 = r10
03e050: r2 += -0x438
03e058: r1 = r7
03e060: call -0x7676 ; call 0x2cb8 / window 41
03e068: if r0 == 0x0 goto +0x3 ; branch 0x3e088
03e070: r1 = r6
03e078: call 0x8e0b ; call 0x850d8 / window 981
03e080: if r0 == 0x0 goto +0xd ; branch 0x3e0f0
03e088: r1 = r6
03e090: r2 = 0x9f2b8 ll ; data b'\x00\x00\x00\x00X\x97\t\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
03e0a0: call -0x767e ; call 0x2cb8 / window 41
03e0a8: r9 = 0x1
03e0b0: if r0 != 0x0 goto +0x8d ; branch 0x3e520
03e0b8: r1 = r7
03e0c0: r2 = 0x9f2b8 ll ; data b'\x00\x00\x00\x00X\x97\t\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
03e0d0: call -0x7684 ; call 0x2cb8 / window 41
03e0d8: if r0 != 0x0 goto +0x88 ; branch 0x3e520
03e0e0: r7 += 0x30
03e0e8: goto -0x19 ; branch 0x3e028
03e0f0: r2 = *(u64 *)(r7 - 0x8)
03e0f8: r2 += 0x10
03e100: r1 = r10
03e108: r1 += -0x8c8
03e110: r3 = 0x9f288 ll ; data b'\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x003\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x00!\x00\x00\x00\x00\x00\x00\x00X\x97\t\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00'
03e120: call -0x7509 ; call 0x38e0 / window 87
03e128: r1 = *(u64 *)(r10 - 0x8c8)
03e130: r2 = *(u64 *)(r1 + 0x8)
03e138: if r2 == 0x0 goto +0x3f9 ; branch 0x40108
03e140: r2 = *(u64 *)(r10 - 0x8c0)
03e148: r1 = *(u64 *)(r1 + 0x0)
03e150: w1 = *(u8 *)(r1 + 0x0)
03e158: r3 = *(u64 *)(r2 + 0x0)
03e160: r3 += -0x1
03e168: *(u64 *)(r2 + 0x0) = r3
03e170: if r1 == 0x4 goto +0x1 ; branch 0x3e180
03e178: goto -0x14 ; branch 0x3e0e0
03e180: r1 = r10
03e188: r1 += -0x6c8
03e190: r2 = r6
03e198: call 0x13a3 ; call 0x47eb8 / window 419
03e1a0: r2 = *(u64 *)(r10 - 0x950)
03e1a8: r1 = *(u64 *)(r2 + 0x0)
03e1b0: *(u64 *)(r10 - 0x368) = r1
03e1b8: r1 = *(u64 *)(r2 + 0x8)
03e1c0: *(u64 *)(r10 - 0x360) = r1
03e1c8: r1 = *(u64 *)(r2 + 0x10)
03e1d0: *(u64 *)(r10 - 0x358) = r1
03e1d8: w1 = *(u32 *)(r2 + 0x17)
03e1e0: *(u32 *)(r10 - 0x351) = w1
03e1e8: w9 = *(u8 *)(r10 - 0x6c4)
03e1f0: w6 = *(u32 *)(r10 - 0x6c8)
03e1f8: w8 = *(u32 *)(r10 - 0x5c0)
03e200: if r8 == 0x2 goto +0x58 ; branch 0x3e4c8
03e208: r1 = *(u64 *)(r10 - 0x958)
03e210: r2 = *(u64 *)(r10 - 0x968)
03e218: r3 = 0xe8
03e220: call 0xb58d ; call 0x98e90 / window 1246
03e228: r1 = *(u64 *)(r10 - 0x970)
03e230: r2 = *(u64 *)(r10 - 0x978)
03e238: r3 = 0x24
03e240: call 0xb589 ; call 0x98e90 / window 1246
03e248: *(u8 *)(r10 - 0x12c) = w9
03e250: *(u32 *)(r10 - 0x130) = w6
03e258: w1 = *(u32 *)(r10 - 0x351)
03e260: r2 = *(u64 *)(r10 - 0x960)
03e268: *(u32 *)(r2 + 0x17) = w1
03e270: r1 = *(u64 *)(r10 - 0x358)
03e278: *(u64 *)(r2 + 0x10) = r1
03e280: r1 = *(u64 *)(r10 - 0x360)
03e288: *(u64 *)(r2 + 0x8) = r1
03e290: r1 = *(u64 *)(r10 - 0x368)
03e298: *(u64 *)(r2 + 0x0) = r1
03e2a0: *(u32 *)(r10 - 0x28) = w8
03e2a8: w1 = *(u32 *)(r10 - 0x7c)
03e2b0: if r1 == 0x6 goto +0x4 ; branch 0x3e2d8
03e2b8: r2 = 0xfffffffe ll
03e2c8: r1 &= r2
03e2d0: if r1 == 0x4 goto +0xe4 ; branch 0x3e9f8
03e2d8: r1 = *(u64 *)(r10 - 0x980)
03e2e0: call -0x7649 ; call 0x30a0 / window 59
03e2e8: r8 = *(u64 *)(r10 - 0x988)
03e2f0: goto -0x43 ; branch 0x3e0e0
03e2f8: w2 = *(u32 *)(r10 - 0x6c4)
03e300: r3 = *(u64 *)(r10 - 0x6c0)
03e308: r4 = *(u64 *)(r10 - 0x6b0)
03e310: *(u64 *)(r8 + 0x18) = r4
03e318: r4 = *(u64 *)(r10 - 0x6b8)
03e320: *(u64 *)(r8 + 0x10) = r4
03e328: *(u64 *)(r8 + 0x8) = r3
03e330: *(u32 *)(r8 + 0x4) = w2
03e338: goto +0x8 ; branch 0x3e380
03e340: w2 = *(u32 *)(r10 - 0x6ac)
03e348: *(u32 *)(r8 + 0x1c) = w2
03e350: r2 = *(u64 *)(r10 - 0x6b4)
03e358: *(u64 *)(r8 + 0x14) = r2
03e360: r2 = *(u64 *)(r10 - 0x6bc)
03e368: *(u64 *)(r8 + 0xc) = r2
03e370: r2 = *(u64 *)(r10 - 0x6c4)
03e378: *(u64 *)(r8 + 0x4) = r2
03e380: *(u32 *)(r8 + 0x0) = w1
03e388: goto +0x38 ; branch 0x3e550
03e390: r1 = 0xa
03e398: *(u64 *)(r8 + 0x0) = r1
03e3a0: goto +0x35 ; branch 0x3e550
03e3a8: r1 = r10
03e3b0: r1 += -0x6c8
03e3b8: r2 = r9
03e3c0: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
03e3d0: r4 = 0x2
03e3d8: call -0x5cf3 ; call 0xfc48 / window 276
03e3e0: w1 = *(u32 *)(r10 - 0x6c8)
03e3e8: if r1 != 0x16 goto +0x3 ; branch 0x3e408
03e3f0: r7 = 0x0
03e3f8: r6 = *(u64 *)(r10 - 0x938)
03e400: goto -0x25e ; branch 0x3d118
03e408: w2 = *(u32 *)(r10 - 0x6ac)
03e410: r3 = *(u64 *)(r10 - 0x930)
03e418: *(u32 *)(r3 + 0x1c) = w2
03e420: r2 = *(u64 *)(r10 - 0x6b4)
03e428: *(u64 *)(r3 + 0x14) = r2
03e430: r2 = *(u64 *)(r10 - 0x6bc)
03e438: *(u64 *)(r3 + 0xc) = r2
03e440: r2 = *(u64 *)(r10 - 0x6c4)
03e448: *(u64 *)(r3 + 0x4) = r2
03e450: *(u32 *)(r3 + 0x0) = w1
03e458: goto +0x1e ; branch 0x3e550
03e460: r1 = 0x700000000 ll
03e470: goto -0x1c ; branch 0x3e398
03e478: r1 = 0x0
03e480: r2 = 0x0
03e488: r3 = 0x9f2d8 ll ; data b'\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00[\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00'
03e498: goto +0x3 ; branch 0x3e4b8
03e4a0: r1 = 0x2
03e4a8: r3 = 0x9f2f0 ll ; data b'\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00<\xac\t\x00#\x00\x00\x00\x00\x00\x00\x00[\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00_\xac\t\x00&\x00\x00\x00\x00\x00\x00\x00Y\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00'
03e4b8: call 0xa416 ; call 0x90570 / window 1172
03e4c0: call -0x1 ; external abort
03e4c8: r1 = *(u64 *)(r10 - 0x368)
03e4d0: *(u64 *)(r10 - 0x568) = r1
03e4d8: r1 = *(u64 *)(r10 - 0x360)
03e4e0: *(u64 *)(r10 - 0x560) = r1
03e4e8: r1 = *(u64 *)(r10 - 0x358)
03e4f0: *(u64 *)(r10 - 0x558) = r1
03e4f8: w1 = *(u32 *)(r10 - 0x351)
03e500: *(u32 *)(r10 - 0x551) = w1
03e508: r1 = r6
03e510: if r1 == 0x16 goto +0x1 ; branch 0x3e520
03e518: goto +0x88 ; branch 0x3e960
03e520: r9 &= 0xff
03e528: if r9 == 0x0 goto +0x3a ; branch 0x3e700
03e530: r1 = 0x9900000000 ll
03e540: r2 = *(u64 *)(r10 - 0x930)
03e548: *(u64 *)(r2 + 0x0) = r1
03e550: r1 = 0x1
03e558: r2 = 0x1
03e560: r3 = 0x1
03e568: r4 = 0x1
03e570: r5 = 0x1
03e578: r0 = 0x1
03e580: r6 = 0x1
03e588: w7 = *(u32 *)(r10 - 0x828)
03e590: r8 = r7
03e598: r8 += -0x34
03e5a0: r9 = 0x2
03e5a8: if r9 > r8 goto -0x311 ; branch 0x3cd28
03e5b0: if r7 == 0x29 goto -0x312 ; branch 0x3cd28
03e5b8: if r7 == 0x2a goto +0x1e ; branch 0x3e6b0
03e5c0: if r7 == 0x2b goto +0xb ; branch 0x3e620
03e5c8: if r7 == 0x2c goto +0x21 ; branch 0x3e6d8
03e5d0: if r7 == 0x2d goto -0x316 ; branch 0x3cd28
03e5d8: if r7 == 0x2e goto +0x15 ; branch 0x3e688
03e5e0: if r7 == 0x2f goto +0x9 ; branch 0x3e630
03e5e8: if r7 == 0x31 goto +0xa ; branch 0x3e640
03e5f0: if r7 == 0x32 goto +0xe ; branch 0x3e668
03e5f8: if r7 == 0x37 goto -0x31b ; branch 0x3cd28
03e600: r1 = r10
03e608: r1 += -0x828
03e610: call -0x7680 ; call 0x3218 / window 66
03e618: goto -0x31f ; branch 0x3cd28
03e620: if r0 != 0x0 goto +0x5 ; branch 0x3e650
03e628: goto -0x321 ; branch 0x3cd28
03e630: if r3 != 0x0 goto +0xc ; branch 0x3e698
03e638: goto -0x323 ; branch 0x3cd28
03e640: if r2 != 0x0 goto +0x1 ; branch 0x3e650
03e648: goto -0x325 ; branch 0x3cd28
03e650: r1 = r10
03e658: r1 += -0x810
03e660: goto +0x7 ; branch 0x3e6a0
03e668: if r1 == 0x0 goto -0x329 ; branch 0x3cd28
03e670: r1 = *(u64 *)(r10 - 0x940)
03e678: call -0x765e ; call 0x3390 / window 68
03e680: goto -0x32c ; branch 0x3cd28
03e688: if r4 != 0x0 goto +0x1 ; branch 0x3e698
03e690: goto -0x32e ; branch 0x3cd28
03e698: r1 = *(u64 *)(r10 - 0x948)
03e6a0: call -0x75d0 ; call 0x3828 / window 85
03e6a8: goto -0x331 ; branch 0x3cd28
03e6b0: if r6 != 0x0 goto +0x1 ; branch 0x3e6c0
03e6b8: goto -0x333 ; branch 0x3cd28
03e6c0: r1 = *(u64 *)(r10 - 0x948)
03e6c8: call -0x76c6 ; call 0x30a0 / window 59
03e6d0: goto -0x336 ; branch 0x3cd28
03e6d8: if r5 != 0x0 goto +0x1 ; branch 0x3e6e8
03e6e0: goto -0x338 ; branch 0x3cd28
03e6e8: r1 = *(u64 *)(r10 - 0x940)
03e6f0: call -0x7655 ; call 0x3450 / window 69
03e6f8: goto -0x33b ; branch 0x3cd28
03e700: r1 = r10
03e708: r1 += -0x6c8
03e710: r2 = r10
03e718: r2 += -0x828
03e720: r3 = 0x160
03e728: call 0xb4ec ; call 0x98e90 / window 1246
03e730: w1 = *(u32 *)(r10 - 0x6c8)
03e738: if r1 == 0x0 goto +0x3f ; branch 0x3e938
03e740: if r1 == 0x1 goto +0x3e ; branch 0x3e938
03e748: if r1 == 0x2 goto +0x3d ; branch 0x3e938
03e750: r9 = *(u64 *)(r10 - 0x930)
03e758: if r1 == 0x3 goto +0x28 ; branch 0x3e8a0
03e760: if r1 == 0x4 goto +0xa6 ; branch 0x3ec98
03e768: if r1 == 0x5 goto +0x26 ; branch 0x3e8a0
03e770: if r1 == 0x6 goto +0x25 ; branch 0x3e8a0
03e778: if r1 == 0x7 goto +0xad ; branch 0x3ece8
03e780: if r1 == 0x8 goto +0x23 ; branch 0x3e8a0
03e788: if r1 == 0x9 goto +0x22 ; branch 0x3e8a0
03e790: if r1 == 0xa goto +0x21 ; branch 0x3e8a0
03e798: if r1 == 0xb goto +0x1d3 ; branch 0x3f638
03e7a0: if r1 == 0xc goto +0x1cb ; branch 0x3f600
03e7a8: if r1 == 0xd goto +0x1e ; branch 0x3e8a0
03e7b0: if r1 == 0xe goto +0xb0 ; branch 0x3ed38
03e7b8: if r1 == 0xf goto +0x1e5 ; branch 0x3f6e8
03e7c0: if r1 == 0x10 goto +0x1b ; branch 0x3e8a0
03e7c8: if r1 == 0x11 goto +0xdf ; branch 0x3eec8
03e7d0: if r1 == 0x12 goto +0x1d8 ; branch 0x3f698
03e7d8: if r1 == 0x13 goto +0x1ae ; branch 0x3f550
03e7e0: if r1 == 0x14 goto +0x12e ; branch 0x3f158
03e7e8: if r1 == 0x15 goto +0x139 ; branch 0x3f1b8
03e7f0: if r1 == 0x16 goto +0x1b7 ; branch 0x3f5b0
03e7f8: if r1 == 0x17 goto +0x141 ; branch 0x3f208
03e800: if r1 == 0x18 goto +0x14a ; branch 0x3f258
03e808: if r1 == 0x19 goto +0xaf ; branch 0x3ed88
03e810: if r1 == 0x1a goto +0xe1 ; branch 0x3ef20
03e818: if r1 == 0x1b goto +0xb7 ; branch 0x3edd8
03e820: if r1 == 0x1c goto +0x150 ; branch 0x3f2a8
03e828: if r1 == 0x1d goto +0xe8 ; branch 0x3ef70
03e830: if r1 == 0x1e goto +0xbe ; branch 0x3ee28
03e838: if r1 == 0x1f goto +0x157 ; branch 0x3f2f8
03e840: if r1 == 0x20 goto +0xef ; branch 0x3efc0
03e848: if r1 == 0x21 goto +0x15f ; branch 0x3f348
03e850: if r1 == 0x22 goto +0xf7 ; branch 0x3f010
03e858: if r1 == 0x23 goto +0x188 ; branch 0x3f4a0
03e860: if r1 == 0x24 goto +0x191 ; branch 0x3f4f0
03e868: if r1 == 0x25 goto +0xc1 ; branch 0x3ee78
03e870: if r1 == 0x26 goto +0xff ; branch 0x3f070
03e878: if r1 == 0x27 goto +0x107 ; branch 0x3f0b8
03e880: if r1 == 0x28 goto +0x10f ; branch 0x3f100
03e888: r1 = 0x2
03e890: *(u32 *)(r9 + 0x0) = w1
03e898: goto +0x3ac ; branch 0x40600
03e8a0: r1 = 0x4b00000000 ll
03e8b0: *(u64 *)(r9 + 0x0) = r1
03e8b8: goto +0x3a8 ; branch 0x40600
03e8c0: r6 = *(u64 *)(r10 - 0x938)
03e8c8: r8 = r6
03e8d0: r8 += 0xc0
03e8d8: r1 = *(u64 *)(r8 + 0x0)
03e8e0: r2 = 0x99898 ll ; data b"\xed\x03H\x1d\x8d\xf7w\xac\xe7Uv\x9e:\x84\xe6\xde\xedH\xa8\x7f322\xb4\xb74\x96\xde'y\x87\x86\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00prog"
03e8f0: call -0x777d ; call 0x2d10 / window 44
03e8f8: if r0 != 0x0 goto +0x1 ; branch 0x3e908
03e900: goto +0x21 ; branch 0x3ea10
03e908: r1 = 0xbf00000000 ll
03e918: goto -0x7c ; branch 0x3e540
03e920: r1 = 0xbf00000000 ll
03e930: goto -0xb4 ; branch 0x3e398
03e938: r1 = 0x4b00000000 ll
03e948: r2 = *(u64 *)(r10 - 0x930)
03e950: *(u64 *)(r2 + 0x0) = r1
03e958: goto +0x394 ; branch 0x40600
03e960: w1 = *(u32 *)(r10 - 0x551)
03e968: *(u32 *)(r10 - 0x221) = w1
03e970: r1 = *(u64 *)(r10 - 0x558)
03e978: *(u64 *)(r10 - 0x228) = r1
03e980: r1 = *(u64 *)(r10 - 0x560)
03e988: *(u64 *)(r10 - 0x230) = r1
03e990: r2 = *(u64 *)(r10 - 0x568)
03e998: *(u64 *)(r10 - 0x238) = r2
03e9a0: w3 = *(u32 *)(r10 - 0x221)
03e9a8: r4 = *(u64 *)(r10 - 0x930)
03e9b0: *(u32 *)(r4 + 0x1c) = w3
03e9b8: r3 = *(u64 *)(r10 - 0x228)
03e9c0: *(u64 *)(r4 + 0x15) = r3
03e9c8: *(u64 *)(r4 + 0xd) = r1
03e9d0: *(u64 *)(r4 + 0x5) = r2
03e9d8: *(u8 *)(r4 + 0x4) = w9
03e9e0: *(u32 *)(r4 + 0x0) = w6
03e9e8: w1 = *(u32 *)(r10 - 0x828)
03e9f0: goto -0x307 ; branch 0x3d1c0
03e9f8: r1 = *(u64 *)(r10 - 0x980)
03ea00: call -0x772d ; call 0x30a0 / window 59
03ea08: goto -0x9c ; branch 0x3e530
03ea10: *(u64 *)(r10 - 0x928) = r8
03ea18: r6 += 0x30
03ea20: r1 = r10
03ea28: r1 += -0x858
03ea30: r2 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03ea40: call 0x8edf ; call 0x86140 / window 990
03ea48: r2 = *(u64 *)(r9 + 0x0)
03ea50: r1 = *(u64 *)(r10 - 0x858)
03ea58: *(u64 *)(r10 - 0x920) = r1
03ea60: r8 = *(u64 *)(r10 - 0x850)
03ea68: r1 = r10
03ea70: r1 += -0x868
03ea78: call 0x8ed8 ; call 0x86140 / window 990
03ea80: r1 = 0x7
03ea88: *(u64 *)(r10 - 0x690) = r1
03ea90: r1 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
03eaa0: *(u64 *)(r10 - 0x698) = r1
03eaa8: *(u64 *)(r10 - 0x6b0) = r8
03eab0: r1 = *(u64 *)(r10 - 0x920)
03eab8: *(u64 *)(r10 - 0x6b8) = r1
03eac0: r1 = 0x8
03eac8: *(u64 *)(r10 - 0x6c0) = r1
03ead0: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
03eae0: *(u64 *)(r10 - 0x6c8) = r1
03eae8: r1 = *(u64 *)(r10 - 0x860)
03eaf0: *(u64 *)(r10 - 0x6a0) = r1
03eaf8: r1 = *(u64 *)(r10 - 0x868)
03eb00: *(u64 *)(r10 - 0x6a8) = r1
03eb08: r1 = r10
03eb10: r1 += -0x438
03eb18: r2 = r10
03eb20: r2 += -0x6c8
03eb28: call -0x67f9 ; call 0xab68 / window 226
03eb30: r4 = *(u64 *)(r10 - 0x430)
03eb38: r5 = *(u64 *)(r10 - 0x428)
03eb40: r1 = r10
03eb48: r1 += -0x6c8
03eb50: r2 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
03eb60: *(u64 *)(r10 - 0x920) = r6
03eb68: r3 = r6
03eb70: call -0x5df5 ; call 0xfbd0 / window 273
03eb78: w1 = *(u32 *)(r10 - 0x6c8)
03eb80: if r1 == 0x16 goto +0x1 ; branch 0x3eb90
03eb88: goto +0x14 ; branch 0x3ec30
03eb90: r1 = r10
03eb98: r1 += -0x6c8
03eba0: r2 = *(u64 *)(r10 - 0x938)
03eba8: call 0x1261 ; call 0x47eb8 / window 419
03ebb0: w6 = *(u32 *)(r10 - 0x5c0)
03ebb8: if r6 != 0x2 goto +0x197 ; branch 0x3f878
03ebc0: r1 = *(u64 *)(r10 - 0x6b0)
03ebc8: *(u64 *)(r10 - 0x350) = r1
03ebd0: r2 = *(u64 *)(r10 - 0x6b8)
03ebd8: *(u64 *)(r10 - 0x358) = r2
03ebe0: r3 = *(u64 *)(r10 - 0x6c0)
03ebe8: *(u64 *)(r10 - 0x360) = r3
03ebf0: r4 = *(u64 *)(r10 - 0x6c8)
03ebf8: *(u64 *)(r10 - 0x368) = r4
03ec00: r5 = *(u64 *)(r10 - 0x930)
03ec08: *(u64 *)(r5 + 0x18) = r1
03ec10: *(u64 *)(r5 + 0x10) = r2
03ec18: *(u64 *)(r5 + 0x8) = r3
03ec20: *(u64 *)(r5 + 0x0) = r4
03ec28: goto +0x1ac ; branch 0x3f990
03ec30: w2 = *(u8 *)(r10 - 0x6c4)
03ec38: w3 = *(u32 *)(r10 - 0x6ac)
03ec40: r4 = *(u64 *)(r10 - 0x930)
03ec48: *(u32 *)(r4 + 0x1c) = w3
03ec50: r3 = *(u64 *)(r10 - 0x6b3)
03ec58: *(u64 *)(r4 + 0x15) = r3
03ec60: r3 = *(u64 *)(r10 - 0x6bb)
03ec68: *(u64 *)(r4 + 0xd) = r3
03ec70: r3 = *(u64 *)(r10 - 0x6c3)
03ec78: *(u64 *)(r4 + 0x5) = r3
03ec80: *(u8 *)(r4 + 0x4) = w2
03ec88: *(u32 *)(r4 + 0x0) = w1
03ec90: goto +0x19f ; branch 0x3f990
03ec98: r1 = 0x9ac1b ll ; data b'IX: Update primary sale via tokenprogram/src/state/edition_marker.rsprogram/src/state/edition_marker'
03eca8: r2 = 0x21
03ecb0: call -0x1 ; external sol_log_
03ecb8: r1 = r9
03ecc0: r2 = *(u64 *)(r10 - 0x928)
03ecc8: r3 = *(u64 *)(r10 - 0x938)
03ecd0: r4 = *(u64 *)(r10 - 0x920)
03ecd8: call -0x1423 ; call 0x34bc8 / window 339
03ece0: goto +0x323 ; branch 0x40600
03ece8: r1 = 0x9ac0a ll ; data b'IX: Sign MetadataIX: Update primary sale via tokenprogram/src/state/edition_marker.rsprogram/src/sta'
03ecf8: r2 = 0x11
03ed00: call -0x1 ; external sol_log_
03ed08: r1 = r9
03ed10: r2 = *(u64 *)(r10 - 0x928)
03ed18: r3 = *(u64 *)(r10 - 0x938)
03ed20: r4 = *(u64 *)(r10 - 0x920)
03ed28: call -0x1fc5 ; call 0x2ef08 / window 332
03ed30: goto +0x319 ; branch 0x40600
03ed38: r1 = 0x9aba4 ll ; data b'IX: Puff MetadataIX: Convert Master Edition V1 to V2IX: Mint New Edition from Master Edition Via Tok'
03ed48: r2 = 0x11
03ed50: call -0x1 ; external sol_log_
03ed58: r1 = r9
03ed60: r2 = *(u64 *)(r10 - 0x928)
03ed68: r3 = *(u64 *)(r10 - 0x938)
03ed70: r4 = *(u64 *)(r10 - 0x920)
03ed78: call -0x220d ; call 0x2dd18 / window 329
03ed80: goto +0x30f ; branch 0x40600
03ed88: r1 = 0x9aa29 ll ; data b'IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Re'
03ed98: r2 = 0x1d
03eda0: call -0x1 ; external sol_log_
03eda8: r1 = r9
03edb0: r2 = *(u64 *)(r10 - 0x928)
03edb8: r3 = *(u64 *)(r10 - 0x938)
03edc0: r4 = *(u64 *)(r10 - 0x920)
03edc8: call -0x4c0b ; call 0x18d78 / window 303
03edd0: goto +0x305 ; branch 0x40600
03edd8: r1 = 0x9aaa6 ll ; data b'IX: Thaw Delegated AccountIX: Freeze Delegated AccountIX: Revoke Collection AuthorityIX: Unverify Co'
03ede8: r2 = 0x1a
03edf0: call -0x1 ; external sol_log_
03edf8: r1 = r9
03ee00: r2 = *(u64 *)(r10 - 0x928)
03ee08: r3 = *(u64 *)(r10 - 0x938)
03ee10: r4 = *(u64 *)(r10 - 0x920)
03ee18: call -0x2db6 ; call 0x28070 / window 320
03ee20: goto +0x2fb ; branch 0x40600
03ee28: r1 = 0x9aa63 ll ; data b'IX: Verify Collection V2IX: Burn NFTIX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Fre'
03ee38: r2 = 0x18
03ee40: call -0x1 ; external sol_log_
03ee48: r1 = r9
03ee50: r2 = *(u64 *)(r10 - 0x928)
03ee58: r3 = *(u64 *)(r10 - 0x938)
03ee60: r4 = *(u64 *)(r10 - 0x920)
03ee68: call -0x450b ; call 0x1c618 / window 309
03ee70: goto +0x2f1 ; branch 0x40600
03ee78: r1 = 0x9a9a0 ll ; data b'IX: Burn Edition NFTIX: Bubblegum Program Set Collection SizeIX: Set Token StandardIX: Set Collectio'
03ee88: r2 = 0x14
03ee90: call -0x1 ; external sol_log_
03ee98: r1 = r9
03eea0: r2 = *(u64 *)(r10 - 0x928)
03eea8: r3 = *(u64 *)(r10 - 0x938)
03eeb0: r4 = *(u64 *)(r10 - 0x920)
03eeb8: call -0x56cc ; call 0x13860 / window 297
03eec0: goto +0x2e7 ; branch 0x40600
03eec8: r1 = *(u64 *)(r10 - 0x6b8)
03eed0: *(u64 *)(r10 - 0x948) = r1
03eed8: r1 = *(u64 *)(r10 - 0x6c0)
03eee0: *(u64 *)(r10 - 0x940) = r1
03eee8: r1 = 0x9ab6d ll ; data b'V3 Create Master EditionIX: Update Metadata Accounts v2IX: Puff MetadataIX: Convert Master Edition V'
03eef8: r2 = 0x18
03ef00: call -0x1 ; external sol_log_
03ef08: r1 = *(u64 *)(r10 - 0x920)
03ef10: if r1 > 0x7 goto +0x155 ; branch 0x3f9c0
03ef18: goto +0xeb ; branch 0x3f678
03ef20: r1 = 0x9aac0 ll ; data b'IX: Freeze Delegated AccountIX: Revoke Collection AuthorityIX: Unverify CollectionIX: Revoke Use Aut'
03ef30: r2 = 0x1c
03ef38: call -0x1 ; external sol_log_
03ef40: r1 = r9
03ef48: r2 = *(u64 *)(r10 - 0x928)
03ef50: r3 = *(u64 *)(r10 - 0x938)
03ef58: r4 = *(u64 *)(r10 - 0x920)
03ef60: call -0x2f19 ; call 0x276a0 / window 319
03ef68: goto +0x2d2 ; branch 0x40600
03ef70: r1 = 0x9aa7b ll ; data b'IX: Burn NFTIX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Freeze Delegated AccountIX:'
03ef80: r2 = 0xc
03ef88: call -0x1 ; external sol_log_
03ef90: r1 = r9
03ef98: r2 = *(u64 *)(r10 - 0x928)
03efa0: r3 = *(u64 *)(r10 - 0x938)
03efa8: r4 = *(u64 *)(r10 - 0x920)
03efb0: call -0x55eb ; call 0x14060 / window 298
03efb8: goto +0x2c8 ; branch 0x40600
03efc0: r1 = 0x9aa29 ll ; data b'IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Re'
03efd0: r2 = 0x1d
03efd8: call -0x1 ; external sol_log_
03efe0: r1 = r9
03efe8: r2 = *(u64 *)(r10 - 0x928)
03eff0: r3 = *(u64 *)(r10 - 0x938)
03eff8: r4 = *(u64 *)(r10 - 0x920)
03f000: call -0x4b06 ; call 0x197d8 / window 304
03f008: goto +0x2be ; branch 0x40600
03f010: r6 = *(u64 *)(r10 - 0x6c0)
03f018: r1 = 0x9a9f3 ll ; data b'IX: Set Collection SizeIX: Create Metadata Accounts v3IX: Set and Verify CollectionIX: Unverify Size'
03f028: r2 = 0x17
03f030: call -0x1 ; external sol_log_
03f038: r1 = r9
03f040: r2 = *(u64 *)(r10 - 0x928)
03f048: r3 = *(u64 *)(r10 - 0x938)
03f050: r4 = *(u64 *)(r10 - 0x920)
03f058: r5 = r6
03f060: call -0x49cf ; call 0x1a1f0 / window 305
03f068: goto +0x2b2 ; branch 0x40600
03f070: r1 = 0x9a987 ll ; data b'IX: Create Escrow AccountIX: Burn Edition NFTIX: Bubblegum Program Set Collection SizeIX: Set Token '
03f080: r2 = 0x19
03f088: call -0x1 ; external sol_log_
03f090: r1 = r9
03f098: r3 = *(u64 *)(r10 - 0x938)
03f0a0: r4 = *(u64 *)(r10 - 0x920)
03f0a8: call -0x3685 ; call 0x23c88 / window 316
03f0b0: goto +0x2a9 ; branch 0x40600
03f0b8: r1 = 0x9a96f ll ; data b'IX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Edition NFTIX: Bubblegum Program Set Colle'
03f0c8: r2 = 0x18
03f0d0: call -0x1 ; external sol_log_
03f0d8: r1 = r9
03f0e0: r3 = *(u64 *)(r10 - 0x938)
03f0e8: r4 = *(u64 *)(r10 - 0x920)
03f0f0: call -0x384c ; call 0x22e98 / window 315
03f0f8: goto +0x2a0 ; branch 0x40600
03f100: r6 = *(u64 *)(r10 - 0x6c0)
03f108: r1 = 0x9a955 ll ; data b'IX: Transfer Out Of EscrowIX: Close Escrow AccountIX: Create Escrow AccountIX: Burn Edition NFTIX: B'
03f118: r2 = 0x1a
03f120: call -0x1 ; external sol_log_
03f128: r1 = r9
03f130: r3 = *(u64 *)(r10 - 0x938)
03f138: r4 = *(u64 *)(r10 - 0x920)
03f140: r5 = r6
03f148: call -0x33dd ; call 0x25268 / window 318
03f150: goto +0x295 ; branch 0x40600
03f158: r6 = *(u64 *)(r10 - 0x6c0)
03f160: r1 = 0x9ab2a ll ; data b'IX: Approve Use AuthorityIX: Use/Utilize TokenIX: Verify CollectionV3 Create Master EditionIX: Updat'
03f170: r2 = 0x19
03f178: call -0x1 ; external sol_log_
03f180: r1 = r9
03f188: r2 = *(u64 *)(r10 - 0x928)
03f190: r3 = *(u64 *)(r10 - 0x938)
03f198: r4 = *(u64 *)(r10 - 0x920)
03f1a0: r5 = r6
03f1a8: call -0xdfd ; call 0x381c8 / window 344
03f1b0: goto +0x289 ; branch 0x40600
03f1b8: r1 = 0x9ab12 ll ; data b'IX: Revoke Use AuthorityIX: Approve Use AuthorityIX: Use/Utilize TokenIX: Verify CollectionV3 Create'
03f1c8: r2 = 0x18
03f1d0: call -0x1 ; external sol_log_
03f1d8: r1 = r9
03f1e0: r2 = *(u64 *)(r10 - 0x928)
03f1e8: r3 = *(u64 *)(r10 - 0x938)
03f1f0: r4 = *(u64 *)(r10 - 0x920)
03f1f8: call -0xc3a ; call 0x39030 / window 345
03f200: goto +0x27f ; branch 0x40600
03f208: r1 = 0x999f8 ll ; data b'IX: Approve Collection AuthorityInsufficient tokens for transferAccount has already been resizedErro'
03f218: r2 = 0x20
03f220: call -0x1 ; external sol_log_
03f228: r1 = r9
03f230: r2 = *(u64 *)(r10 - 0x928)
03f238: r3 = *(u64 *)(r10 - 0x938)
03f240: r4 = *(u64 *)(r10 - 0x920)
03f248: call -0x4ebe ; call 0x17c60 / window 301
03f250: goto +0x275 ; branch 0x40600
03f258: r1 = 0x9aadc ll ; data b'IX: Revoke Collection AuthorityIX: Unverify CollectionIX: Revoke Use AuthorityIX: Approve Use Author'
03f268: r2 = 0x1f
03f270: call -0x1 ; external sol_log_
03f278: r1 = r9
03f280: r2 = *(u64 *)(r10 - 0x928)
03f288: r3 = *(u64 *)(r10 - 0x938)
03f290: r4 = *(u64 *)(r10 - 0x920)
03f298: call -0x4d57 ; call 0x187e8 / window 302
03f2a0: goto +0x26b ; branch 0x40600
03f2a8: r1 = 0x9aa87 ll ; data b'IX: Remove Creator VerificationIX: Thaw Delegated AccountIX: Freeze Delegated AccountIX: Revoke Coll'
03f2b8: r2 = 0x1f
03f2c0: call -0x1 ; external sol_log_
03f2c8: r1 = r9
03f2d0: r2 = *(u64 *)(r10 - 0x928)
03f2d8: r3 = *(u64 *)(r10 - 0x938)
03f2e0: r4 = *(u64 *)(r10 - 0x920)
03f2e8: call -0x2226 ; call 0x2e1c0 / window 330
03f2f0: goto +0x261 ; branch 0x40600
03f2f8: r1 = 0x9aa46 ll ; data b'IX: Unverify Sized CollectionIX: Verify Collection V2IX: Burn NFTIX: Remove Creator VerificationIX: '
03f308: r2 = 0x1d
03f310: call -0x1 ; external sol_log_
03f318: r1 = r9
03f320: r2 = *(u64 *)(r10 - 0x928)
03f328: r3 = *(u64 *)(r10 - 0x938)
03f330: r4 = *(u64 *)(r10 - 0x920)
03f338: call -0x4828 ; call 0x1b200 / window 307
03f340: goto +0x257 ; branch 0x40600
03f348: r6 = r10
03f350: r6 += -0x368
03f358: r2 = r10
03f360: r2 += -0x6c0
03f368: r1 = r6
03f370: r3 = 0xa8
03f378: call 0xb362 ; call 0x98e90 / window 1246
03f380: r1 = *(u64 *)(r10 - 0x617)
03f388: *(u64 *)(r10 - 0x568) = r1
03f390: r1 = *(u64 *)(r10 - 0x60f)
03f398: *(u64 *)(r10 - 0x560) = r1
03f3a0: r1 = *(u64 *)(r10 - 0x608)
03f3a8: *(u64 *)(r10 - 0x559) = r1
03f3b0: w8 = *(u8 *)(r10 - 0x618)
03f3b8: r1 = 0x9aa0a ll ; data b'IX: Create Metadata Accounts v3IX: Set and Verify CollectionIX: Unverify Sized CollectionIX: Verify '
03f3c8: r2 = 0x1f
03f3d0: call -0x1 ; external sol_log_
03f3d8: r7 = r10
03f3e0: r7 += -0x130
03f3e8: r1 = r7
03f3f0: r2 = r6
03f3f8: r3 = 0xa8
03f400: call 0xb351 ; call 0x98e90 / window 1246
03f408: r1 = *(u64 *)(r10 - 0x559)
03f410: *(u64 *)(r10 - 0x230) = r1
03f418: r1 = *(u64 *)(r10 - 0x561)
03f420: *(u64 *)(r10 - 0x238) = r1
03f428: r8 &= 0x1
03f430: *(u64 *)(r10 - 0xff8) = r8
03f438: r1 = r10
03f440: r1 += -0x238
03f448: *(u64 *)(r10 - 0xff0) = r1
03f450: *(u64 *)(r10 - 0x1000) = r7
03f458: r5 = r10
03f460: r1 = r9
03f468: r2 = *(u64 *)(r10 - 0x928)
03f470: r3 = *(u64 *)(r10 - 0x938)
03f478: r4 = *(u64 *)(r10 - 0x920)
03f480: call -0x2b93 ; call 0x297f0 / window 322
03f488: r2 = 0x0
03f490: r1 = 0x1
03f498: goto +0x22e ; branch 0x40610
03f4a0: r1 = 0x9a9dd ll ; data b'IX: Set Token StandardIX: Set Collection SizeIX: Create Metadata Accounts v3IX: Set and Verify Colle'
03f4b0: r2 = 0x16
03f4b8: call -0x1 ; external sol_log_
03f4c0: r1 = r9
03f4c8: r2 = *(u64 *)(r10 - 0x928)
03f4d0: r3 = *(u64 *)(r10 - 0x938)
03f4d8: r4 = *(u64 *)(r10 - 0x920)
03f4e0: call -0x21de ; call 0x2e5f8 / window 331
03f4e8: goto +0x222 ; branch 0x40600
03f4f0: r6 = *(u64 *)(r10 - 0x6c0)
03f4f8: r1 = 0x9a9b4 ll ; data b'IX: Bubblegum Program Set Collection SizeIX: Set Token StandardIX: Set Collection SizeIX: Create Met'
03f508: r2 = 0x29
03f510: call -0x1 ; external sol_log_
03f518: r1 = r9
03f520: r2 = *(u64 *)(r10 - 0x928)
03f528: r3 = *(u64 *)(r10 - 0x938)
03f530: r4 = *(u64 *)(r10 - 0x920)
03f538: r5 = r6
03f540: call -0x5c42 ; call 0x11338 / window 295
03f548: goto +0x216 ; branch 0x40600
03f550: r6 = *(u64 *)(r10 - 0x6c0)
03f558: r1 = 0x9ab43 ll ; data b'IX: Use/Utilize TokenIX: Verify CollectionV3 Create Master EditionIX: Update Metadata Accounts v2IX:'
03f568: r2 = 0x15
03f570: call -0x1 ; external sol_log_
03f578: r1 = r9
03f580: r2 = *(u64 *)(r10 - 0x928)
03f588: r3 = *(u64 *)(r10 - 0x938)
03f590: r4 = *(u64 *)(r10 - 0x920)
03f598: r5 = r6
03f5a0: call -0xb44 ; call 0x39b88 / window 346
03f5a8: goto +0x20a ; branch 0x40600
03f5b0: r1 = 0x9aafb ll ; data b'IX: Unverify CollectionIX: Revoke Use AuthorityIX: Approve Use AuthorityIX: Use/Utilize TokenIX: Ver'
03f5c0: r2 = 0x17
03f5c8: call -0x1 ; external sol_log_
03f5d0: r1 = r9
03f5d8: r2 = *(u64 *)(r10 - 0x928)
03f5e0: r3 = *(u64 *)(r10 - 0x938)
03f5e8: r4 = *(u64 *)(r10 - 0x920)
03f5f0: call -0x49d5 ; call 0x1a750 / window 306
03f5f8: goto +0x200 ; branch 0x40600
03f600: r1 = 0x9abb5 ll ; data b'IX: Convert Master Edition V1 to V2IX: Mint New Edition from Master Edition Via TokenIX: Sign Metada'
03f610: r2 = 0x23
03f618: call -0x1 ; external sol_log_
03f620: r1 = *(u64 *)(r10 - 0x920)
03f628: if r1 > 0x2 goto +0xd5 ; branch 0x3fcd8
03f630: goto +0x8 ; branch 0x3f678
03f638: r1 = *(u64 *)(r10 - 0x6c0)
03f640: *(u64 *)(r10 - 0x940) = r1
03f648: r1 = 0x9abd8 ll ; data b'IX: Mint New Edition from Master Edition Via TokenIX: Sign MetadataIX: Update primary sale via token'
03f658: r2 = 0x32
03f660: call -0x1 ; external sol_log_
03f668: r1 = *(u64 *)(r10 - 0x920)
03f670: if r1 > 0xc goto +0x7f ; branch 0x3fa70
03f678: r1 = 0xa
03f680: r2 = *(u64 *)(r10 - 0x930)
03f688: *(u32 *)(r2 + 0x0) = w1
03f690: goto +0x1ed ; branch 0x40600
03f698: r1 = 0x9ab58 ll ; data b'IX: Verify CollectionV3 Create Master EditionIX: Update Metadata Accounts v2IX: Puff MetadataIX: Con'
03f6a8: r2 = 0x15
03f6b0: call -0x1 ; external sol_log_
03f6b8: r1 = r9
03f6c0: r2 = *(u64 *)(r10 - 0x928)
03f6c8: r3 = *(u64 *)(r10 - 0x938)
03f6d0: r4 = *(u64 *)(r10 - 0x920)
03f6d8: call -0x4735 ; call 0x1bd38 / window 308
03f6e0: goto +0x1e3 ; branch 0x40600
03f6e8: r6 = r10
03f6f0: r6 += -0x130
03f6f8: r2 = r10
03f700: r2 += -0x6c0
03f708: r1 = r6
03f710: r3 = 0xc9
03f718: call 0xb2ee ; call 0x98e90 / window 1246
03f720: w8 = *(u8 *)(r10 - 0x5f6)
03f728: w9 = *(u8 *)(r10 - 0x5f7)
03f730: r1 = 0x9ab85 ll ; data b'IX: Update Metadata Accounts v2IX: Puff MetadataIX: Convert Master Edition V1 to V2IX: Mint New Edit'
03f740: r2 = 0x1f
03f748: call -0x1 ; external sol_log_
03f750: r7 = r10
03f758: r7 += -0x368
03f760: r1 = r7
03f768: r2 = r6
03f770: r3 = 0xa8
03f778: call 0xb2e2 ; call 0x98e90 / window 1246
03f780: r6 = r10
03f788: r6 += -0x568
03f790: r2 = r10
03f798: r2 += -0x88
03f7a0: r1 = r6
03f7a8: r3 = 0x21
03f7b0: call 0xb2db ; call 0x98e90 / window 1246
03f7b8: *(u64 *)(r10 - 0xff0) = r9
03f7c0: *(u64 *)(r10 - 0xfe8) = r8
03f7c8: *(u64 *)(r10 - 0xff8) = r6
03f7d0: *(u64 *)(r10 - 0x1000) = r7
03f7d8: r5 = r10
03f7e0: r1 = *(u64 *)(r10 - 0x930)
03f7e8: r2 = *(u64 *)(r10 - 0x928)
03f7f0: r3 = *(u64 *)(r10 - 0x938)
03f7f8: r4 = *(u64 *)(r10 - 0x920)
03f800: call -0x16d1 ; call 0x34180 / window 338
03f808: r2 = 0x1
03f810: r1 = 0x0
03f818: goto +0x1be ; branch 0x40610
03f820: r3 = *(u64 *)(r10 - 0x6b0)
03f828: r2 = *(u64 *)(r10 - 0x6b8)
03f830: r1 = *(u64 *)(r10 - 0x6c0)
03f838: w8 = *(u32 *)(r10 - 0x6c4)
03f840: r4 = *(u64 *)(r10 - 0x930)
03f848: *(u64 *)(r4 + 0x18) = r3
03f850: *(u64 *)(r4 + 0x10) = r2
03f858: *(u64 *)(r4 + 0x8) = r1
03f860: *(u32 *)(r4 + 0x4) = w8
03f868: *(u32 *)(r4 + 0x0) = w9
03f870: goto -0x265 ; branch 0x3e550
03f878: r8 = r10
03f880: r8 += -0x368
03f888: r2 = r10
03f890: r2 += -0x6c8
03f898: r1 = r8
03f8a0: r3 = 0x108
03f8a8: call 0xb2bc ; call 0x98e90 / window 1246
03f8b0: r1 = r10
03f8b8: r1 += -0x24
03f8c0: r2 = r10
03f8c8: r2 += -0x5bc
03f8d0: r3 = 0x24
03f8d8: call 0xb2b6 ; call 0x98e90 / window 1246
03f8e0: r1 = r10
03f8e8: r1 += -0x130
03f8f0: r2 = r8
03f8f8: r3 = 0x108
03f900: call 0xb2b1 ; call 0x98e90 / window 1246
03f908: *(u32 *)(r10 - 0x28) = w6
03f910: r1 = r10
03f918: r1 += -0x10c
03f920: *(u64 *)(r10 - 0x6c8) = r1
03f928: r1 = r10
03f930: r1 += -0x6c8
03f938: r2 = r9
03f940: call -0x798e ; call 0x2cd8 / window 42
03f948: if r0 != 0x0 goto +0x1 ; branch 0x3f958
03f950: goto +0xa7 ; branch 0x3fe90
03f958: r1 = 0xf00000000 ll
03f968: r2 = *(u64 *)(r10 - 0x930)
03f970: *(u64 *)(r2 + 0x0) = r1
03f978: r1 = r10
03f980: r1 += -0xe8
03f988: call -0x791e ; call 0x30a0 / window 59
03f990: r1 = r10
03f998: r1 += -0x438
03f9a0: call -0x7915 ; call 0x3100 / window 60
03f9a8: goto -0x28c ; branch 0x3e550
03f9b0: r1 = 0x16
03f9b8: goto -0x2c8 ; branch 0x3e380
03f9c0: r2 = *(u64 *)(r10 - 0x938)
03f9c8: r2 += 0xf0
03f9d0: r1 = r10
03f9d8: r1 += -0x130
03f9e0: *(u64 *)(r10 - 0x920) = r2
03f9e8: call 0x1099 ; call 0x47eb8 / window 419
03f9f0: w9 = *(u32 *)(r10 - 0x28)
03f9f8: if r9 != 0x2 goto +0xa8 ; branch 0x3ff40
03fa00: r1 = *(u64 *)(r10 - 0x118)
03fa08: *(u64 *)(r10 - 0x350) = r1
03fa10: r2 = *(u64 *)(r10 - 0x120)
03fa18: *(u64 *)(r10 - 0x358) = r2
03fa20: r3 = *(u64 *)(r10 - 0x128)
03fa28: *(u64 *)(r10 - 0x360) = r3
03fa30: r4 = *(u64 *)(r10 - 0x130)
03fa38: *(u64 *)(r10 - 0x368) = r4
03fa40: r5 = *(u64 *)(r10 - 0x930)
03fa48: *(u64 *)(r5 + 0x18) = r1
03fa50: *(u64 *)(r5 + 0x10) = r2
03fa58: *(u64 *)(r5 + 0x8) = r3
03fa60: *(u64 *)(r5 + 0x0) = r4
03fa68: goto +0x172 ; branch 0x40600
03fa70: r1 = *(u64 *)(r10 - 0x938)
03fa78: r1 = *(u64 *)(r1 + 0x210)
03fa80: r2 = 0x99938 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fa90: call -0x79b1 ; call 0x2d10 / window 44
03fa98: if r0 != 0x0 goto +0xca ; branch 0x400f0
03faa0: r3 = *(u64 *)(r10 - 0x938)
03faa8: r6 = r3
03fab0: r6 += 0x120
03fab8: r1 = r10
03fac0: r1 += -0x130
03fac8: r2 = r6
03fad0: call 0x1239 ; call 0x48ca0 / window 427
03fad8: w1 = *(u32 *)(r10 - 0x130)
03fae0: if r1 == 0x16 goto +0x1 ; branch 0x3faf0
03fae8: goto +0x69 ; branch 0x3fe38
03faf0: r1 = *(u64 *)(r10 - 0x938)
03faf8: r2 = r1
03fb00: r2 += 0x240
03fb08: *(u64 *)(r10 - 0x920) = r2
03fb10: r2 = r1
03fb18: r2 += 0x210
03fb20: *(u64 *)(r10 - 0x948) = r2
03fb28: r2 = r1
03fb30: r2 += 0x1e0
03fb38: *(u64 *)(r10 - 0x950) = r2
03fb40: r2 = r1
03fb48: r2 += 0x1b0
03fb50: *(u64 *)(r10 - 0x958) = r2
03fb58: r5 = r1
03fb60: r5 += 0x180
03fb68: r0 = r1
03fb70: r0 += 0x150
03fb78: r8 = r1
03fb80: r8 += 0xf0
03fb88: r9 = r1
03fb90: r9 += 0xc0
03fb98: r3 = r1
03fba0: r3 += 0x90
03fba8: r7 = r1
03fbb0: r7 += 0x60
03fbb8: r2 = r1
03fbc0: r2 += 0x30
03fbc8: r4 = *(u64 *)(r10 - 0x920)
03fbd0: *(u64 *)(r10 - 0xc0) = r4
03fbd8: r4 = *(u64 *)(r10 - 0x948)
03fbe0: *(u64 *)(r10 - 0xc8) = r4
03fbe8: r4 = *(u64 *)(r10 - 0x950)
03fbf0: *(u64 *)(r10 - 0xd0) = r4
03fbf8: r4 = *(u64 *)(r10 - 0x958)
03fc00: *(u64 *)(r10 - 0xd8) = r4
03fc08: *(u64 *)(r10 - 0xe0) = r5
03fc10: *(u64 *)(r10 - 0xe8) = r0
03fc18: *(u64 *)(r10 - 0xf0) = r6
03fc20: *(u64 *)(r10 - 0xf8) = r8
03fc28: *(u64 *)(r10 - 0x100) = r9
03fc30: *(u64 *)(r10 - 0x108) = r3
03fc38: *(u64 *)(r10 - 0x110) = r7
03fc40: *(u64 *)(r10 - 0x118) = r2
03fc48: *(u64 *)(r10 - 0x120) = r1
03fc50: r1 = 0x0
03fc58: *(u64 *)(r10 - 0x130) = r1
03fc60: *(u64 *)(r10 - 0x128) = r1
03fc68: r1 = r10
03fc70: r1 += -0x368
03fc78: r3 = r10
03fc80: r3 += -0x130
03fc88: r2 = *(u64 *)(r10 - 0x928)
03fc90: r4 = *(u64 *)(r10 - 0x940)
03fc98: call 0x129f ; call 0x49198 / window 429
03fca0: w1 = *(u32 *)(r10 - 0x368)
03fca8: if r1 == 0x16 goto +0x1 ; branch 0x3fcb8
03fcb0: goto +0x111 ; branch 0x40540
03fcb8: r1 = *(u64 *)(r10 - 0x930)
03fcc0: r2 = *(u64 *)(r10 - 0x938)
03fcc8: call 0x1269 ; call 0x49018 / window 428
03fcd0: goto +0x125 ; branch 0x40600
03fcd8: r1 = r10
03fce0: r1 += -0x130
03fce8: r2 = *(u64 *)(r10 - 0x938)
03fcf0: r3 = *(u64 *)(r10 - 0x928)
03fcf8: call -0x601a ; call 0xfc30 / window 275
03fd00: w1 = *(u32 *)(r10 - 0x130)
03fd08: if r1 != 0x16 goto +0x25 ; branch 0x3fe38
03fd10: r7 = *(u64 *)(r10 - 0x938)
03fd18: r7 += 0x30
03fd20: r1 = r10
03fd28: r1 += -0x130
03fd30: r2 = r7
03fd38: r3 = 0x99938 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fd48: call -0x6024 ; call 0xfc30 / window 275
03fd50: w1 = *(u32 *)(r10 - 0x130)
03fd58: if r1 == 0x16 goto +0x1 ; branch 0x3fd68
03fd60: goto +0x1a ; branch 0x3fe38
03fd68: r8 = *(u64 *)(r10 - 0x938)
03fd70: r8 += 0x60
03fd78: r1 = r10
03fd80: r1 += -0x130
03fd88: r2 = r8
03fd90: r3 = 0x99938 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03fda0: call -0x602f ; call 0xfc30 / window 275
03fda8: w1 = *(u32 *)(r10 - 0x130)
03fdb0: if r1 == 0x16 goto +0x1 ; branch 0x3fdc0
03fdb8: goto +0xf ; branch 0x3fe38
03fdc0: r1 = r10
03fdc8: r1 += -0x130
03fdd0: r2 = *(u64 *)(r10 - 0x938)
03fdd8: call 0xdc9 ; call 0x46c28 / window 412
03fde0: r6 = *(u64 *)(r10 - 0x120)
03fde8: if r6 != 0x2 goto +0x11b ; branch 0x406c8
03fdf0: r1 = *(u64 *)(r10 - 0x100)
03fdf8: *(u64 *)(r10 - 0x550) = r1
03fe00: r2 = *(u64 *)(r10 - 0x108)
03fe08: *(u64 *)(r10 - 0x558) = r2
03fe10: r3 = *(u64 *)(r10 - 0x110)
03fe18: *(u64 *)(r10 - 0x560) = r3
03fe20: r4 = *(u64 *)(r10 - 0x118)
03fe28: *(u64 *)(r10 - 0x568) = r4
03fe30: goto -0x7f ; branch 0x3fa40
03fe38: w2 = *(u32 *)(r10 - 0x114)
03fe40: r3 = *(u64 *)(r10 - 0x930)
03fe48: *(u32 *)(r3 + 0x1c) = w2
03fe50: r2 = *(u64 *)(r10 - 0x11c)
03fe58: *(u64 *)(r3 + 0x14) = r2
03fe60: r2 = *(u64 *)(r10 - 0x124)
03fe68: *(u64 *)(r3 + 0xc) = r2
03fe70: r2 = *(u64 *)(r10 - 0x12c)
03fe78: *(u64 *)(r3 + 0x4) = r2
03fe80: *(u32 *)(r3 + 0x0) = w1
03fe88: goto +0xee ; branch 0x40600
03fe90: if r7 != 0x0 goto +0x1 ; branch 0x3fea0
03fe98: goto +0x52 ; branch 0x40130
03fea0: r1 = r10
03fea8: r1 += -0x6c8
03feb0: r2 = *(u64 *)(r10 - 0x928)
03feb8: r3 = *(u64 *)(r10 - 0x938)
03fec0: call 0x6c85 ; call 0x762f0 / window 772
03fec8: w1 = *(u32 *)(r10 - 0x6c8)
03fed0: if r1 != 0x16 goto +0x138 ; branch 0x40898
03fed8: r1 = *(u64 *)(r10 - 0x920)
03fee0: call 0x8a30 ; call 0x85068 / window 980
03fee8: if r0 == 0x0 goto +0x6 ; branch 0x3ff20
03fef0: r1 = *(u64 *)(r10 - 0x938)
03fef8: r1 += 0x48
03ff00: r2 = 0x9edd8 ll ; data b'\x00\x00\x00\x00\xb8\x98\t\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00'
03ff10: call -0x7a4c ; call 0x2cb8 / window 41
03ff18: if r0 != 0x0 goto +0x127 ; branch 0x40858
03ff20: r1 = 0x16
03ff28: r2 = *(u64 *)(r10 - 0x930)
03ff30: *(u32 *)(r2 + 0x0) = w1
03ff38: goto -0xb9 ; branch 0x3f978
03ff40: r6 = r10
03ff48: r6 += -0x368
03ff50: r2 = r10
03ff58: r2 += -0x130
03ff60: r1 = r6
03ff68: r3 = 0x108
03ff70: call 0xb1e3 ; call 0x98e90 / window 1246
03ff78: r1 = r10
03ff80: r1 += -0x45c
03ff88: r2 = r10
03ff90: r2 += -0x24
03ff98: r3 = 0x24
03ffa0: call 0xb1dd ; call 0x98e90 / window 1246
03ffa8: r1 = r10
03ffb0: r1 += -0x568
03ffb8: r2 = r6
03ffc0: r3 = 0x108
03ffc8: call 0xb1d8 ; call 0x98e90 / window 1246
03ffd0: *(u32 *)(r10 - 0x460) = w9
03ffd8: r1 = *(u64 *)(r10 - 0x938)
03ffe0: r2 = *(u64 *)(r1 + 0x40)
03ffe8: r2 += 0x10
03fff0: r1 = r10
03fff8: r1 += -0x8d8
040000: r3 = 0x9eee0 ll ; data b'\x00\x00\x00\x00\xa0\xa5\t\x009\x00\x00\x00\x00\x00\x00\x00&\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00X\x98\t\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00D\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00\x81\x00\x00\x00'
040010: call -0x78e7 ; call 0x38e0 / window 87
040018: r1 = *(u64 *)(r10 - 0x8d8)
040020: r2 = *(u64 *)(r1 + 0x0)
040028: r3 = *(u64 *)(r1 + 0x8)
040030: r9 = *(u64 *)(r10 - 0x8d0)
040038: r1 = r10
040040: r1 += -0x130
040048: call 0x2be9 ; call 0x55f98 / window 451
040050: w7 = *(u32 *)(r10 - 0x130)
040058: if r7 == 0x2 goto +0x1 ; branch 0x40068
040060: goto +0x3d ; branch 0x40250
040068: r1 = *(u64 *)(r10 - 0x110)
040070: *(u64 *)(r10 - 0x34c) = r1
040078: r2 = *(u64 *)(r10 - 0x118)
040080: *(u64 *)(r10 - 0x354) = r2
040088: r3 = *(u64 *)(r10 - 0x120)
040090: *(u64 *)(r10 - 0x35c) = r3
040098: r4 = *(u64 *)(r10 - 0x128)
0400a0: *(u64 *)(r10 - 0x364) = r4
0400a8: r5 = *(u64 *)(r10 - 0x930)
0400b0: *(u64 *)(r5 + 0x18) = r1
0400b8: *(u64 *)(r5 + 0x10) = r2
0400c0: *(u64 *)(r5 + 0x8) = r3
0400c8: *(u64 *)(r5 + 0x0) = r4
0400d0: r1 = *(u64 *)(r9 + 0x0)
0400d8: r1 += -0x1
0400e0: *(u64 *)(r9 + 0x0) = r1
0400e8: goto +0x9f ; branch 0x405e8
0400f0: r1 = 0x3e00000000 ll
040100: goto -0x2f8 ; branch 0x3e948
040108: r1 = 0x0
040110: r2 = 0x0
040118: r3 = 0x9f2a0 ll ; data b'\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x00!\x00\x00\x00\x00\x00\x00\x00X\x97\t\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00*\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x89\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\xbe\xa8\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x8a\x01\x00\x00'
040128: goto -0x38f ; branch 0x3e4b8
040130: r1 = *(u64 *)(r10 - 0x938)
040138: r2 = *(u64 *)(r1 + 0x70)
040140: r2 += 0x10
040148: r1 = r10
040150: r1 += -0x878
040158: r3 = 0x9ed90 ll ; data b'\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00=\x00\x00\x00O\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00$\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xb8\x98\t\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00'
040168: call -0x7912 ; call 0x38e0 / window 87
040170: r1 = *(u64 *)(r10 - 0x878)
040178: r2 = *(u64 *)(r1 + 0x0)
040180: r3 = *(u64 *)(r1 + 0x8)
040188: r1 = *(u64 *)(r10 - 0x870)
040190: *(u64 *)(r10 - 0x958) = r1
040198: r1 = r10
0401a0: r1 += -0x6c8
0401a8: call 0x7764 ; call 0x7bcd0 / window 850
0401b0: w1 = *(u32 *)(r10 - 0x6b8)
0401b8: *(u64 *)(r10 - 0x950) = r1
0401c0: if r1 != 0x2 goto +0x288 ; branch 0x41608
0401c8: r1 = *(u64 *)(r10 - 0x698)
0401d0: *(u64 *)(r10 - 0x21c) = r1
0401d8: r2 = *(u64 *)(r10 - 0x6a0)
0401e0: *(u64 *)(r10 - 0x224) = r2
0401e8: r3 = *(u64 *)(r10 - 0x6a8)
0401f0: *(u64 *)(r10 - 0x22c) = r3
0401f8: r4 = *(u64 *)(r10 - 0x6b0)
040200: *(u64 *)(r10 - 0x234) = r4
040208: r5 = *(u64 *)(r10 - 0x930)
040210: *(u64 *)(r5 + 0x18) = r1
040218: *(u64 *)(r5 + 0x10) = r2
040220: *(u64 *)(r5 + 0x8) = r3
040228: *(u64 *)(r5 + 0x0) = r4
040230: r2 = *(u64 *)(r10 - 0x958)
040238: r1 = *(u64 *)(r2 + 0x0)
040240: r1 += -0x1
040248: goto -0x11c ; branch 0x3f970
040250: r6 = r10
040258: r6 += -0x368
040260: r2 = r10
040268: r2 += -0x12c
040270: r1 = r6
040278: r3 = 0x24
040280: call 0xb181 ; call 0x98e90 / window 1246
040288: r1 = r10
040290: r1 += -0x410
040298: r2 = r10
0402a0: r2 += -0x108
0402a8: r3 = 0x30
0402b0: call 0xb17b ; call 0x98e90 / window 1246
0402b8: r1 = r10
0402c0: r1 += -0x434
0402c8: r2 = r6
0402d0: r3 = 0x24
0402d8: call 0xb176 ; call 0x98e90 / window 1246
0402e0: *(u32 *)(r10 - 0x438) = w7
0402e8: r1 = *(u64 *)(r9 + 0x0)
0402f0: r1 += -0x1
0402f8: *(u64 *)(r9 + 0x0) = r1
040300: r1 = r10
040308: r1 += -0x8e8
040310: r8 = *(u64 *)(r10 - 0x928)
040318: r2 = r8
040320: call 0x8bc3 ; call 0x86140 / window 990
040328: r6 = *(u64 *)(r10 - 0x938)
040330: r2 = *(u64 *)(r6 + 0x30)
040338: r7 = *(u64 *)(r10 - 0x8e8)
040340: r9 = *(u64 *)(r10 - 0x8e0)
040348: r1 = r10
040350: r1 += -0x8f8
040358: *(u64 *)(r10 - 0x950) = r2
040360: call 0x8bbb ; call 0x86140 / window 990
040368: r1 = 0x7
040370: *(u64 *)(r10 - 0xf8) = r1
040378: r1 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
040388: *(u64 *)(r10 - 0x100) = r1
040390: *(u64 *)(r10 - 0x118) = r9
040398: *(u64 *)(r10 - 0x120) = r7
0403a0: r1 = 0x8
0403a8: *(u64 *)(r10 - 0x128) = r1
0403b0: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
0403c0: *(u64 *)(r10 - 0x130) = r1
0403c8: r1 = *(u64 *)(r10 - 0x8f0)
0403d0: *(u64 *)(r10 - 0x108) = r1
0403d8: r1 = *(u64 *)(r10 - 0x8f8)
0403e0: *(u64 *)(r10 - 0x110) = r1
0403e8: r1 = r10
0403f0: r1 += -0x368
0403f8: r4 = r10
040400: r4 += -0x130
040408: r2 = r8
040410: r3 = r6
040418: r5 = 0x4
040420: call -0x610b ; call 0xfbd0 / window 273
040428: w1 = *(u32 *)(r10 - 0x368)
040430: if r1 == 0x16 goto +0x1 ; branch 0x40440
040438: goto +0x29 ; branch 0x40588
040440: r8 = *(u64 *)(r10 - 0x938)
040448: r8 += 0x120
040450: w1 = *(u8 *)(r10 - 0x364)
040458: *(u64 *)(r10 - 0x958) = r1
040460: r1 = r10
040468: r1 += -0x130
040470: r2 = r8
040478: call -0x60f3 ; call 0xfce8 / window 277
040480: w1 = *(u32 *)(r10 - 0x130)
040488: if r1 == 0x16 goto +0x1 ; branch 0x40498
040490: goto +0xa ; branch 0x404e8
040498: r3 = *(u64 *)(r10 - 0x938)
0404a0: r3 += 0x90
0404a8: r1 = r10
0404b0: r1 += -0x130
0404b8: r2 = r10
0404c0: r2 += -0x438
0404c8: r7 = r3
0404d0: call -0x61ef ; call 0xf560 / window 270
0404d8: w1 = *(u32 *)(r10 - 0x130)
0404e0: if r1 == 0x16 goto +0x8a ; branch 0x40938
0404e8: w2 = *(u32 *)(r10 - 0x114)
0404f0: r3 = *(u64 *)(r10 - 0x930)
0404f8: *(u32 *)(r3 + 0x1c) = w2
040500: r2 = *(u64 *)(r10 - 0x11c)
040508: *(u64 *)(r3 + 0x14) = r2
040510: r2 = *(u64 *)(r10 - 0x124)
040518: *(u64 *)(r3 + 0xc) = r2
040520: r2 = *(u64 *)(r10 - 0x12c)
040528: *(u64 *)(r3 + 0x4) = r2
040530: *(u32 *)(r3 + 0x0) = w1
040538: goto +0x15 ; branch 0x405e8
040540: w2 = *(u32 *)(r10 - 0x34c)
040548: r3 = *(u64 *)(r10 - 0x930)
040550: *(u32 *)(r3 + 0x1c) = w2
040558: r2 = *(u64 *)(r10 - 0x354)
040560: *(u64 *)(r3 + 0x14) = r2
040568: r2 = *(u64 *)(r10 - 0x35c)
040570: *(u64 *)(r3 + 0xc) = r2
040578: r2 = *(u64 *)(r10 - 0x364)
040580: goto -0xe2 ; branch 0x3fe78
040588: w2 = *(u8 *)(r10 - 0x364)
040590: w3 = *(u32 *)(r10 - 0x34c)
040598: r4 = *(u64 *)(r10 - 0x930)
0405a0: *(u32 *)(r4 + 0x1c) = w3
0405a8: r3 = *(u64 *)(r10 - 0x353)
0405b0: *(u64 *)(r4 + 0x15) = r3
0405b8: r3 = *(u64 *)(r10 - 0x35b)
0405c0: *(u64 *)(r4 + 0xd) = r3
0405c8: r3 = *(u64 *)(r10 - 0x363)
0405d0: *(u64 *)(r4 + 0x5) = r3
0405d8: *(u8 *)(r4 + 0x4) = w2
0405e0: *(u32 *)(r4 + 0x0) = w1
0405e8: r1 = r10
0405f0: r1 += -0x520
0405f8: call -0x7aac ; call 0x30a0 / window 59
040600: r1 = 0x1
040608: r2 = 0x1
040610: w3 = *(u32 *)(r10 - 0x6c8)
040618: if r3 > 0x28 goto +0x8 ; branch 0x40660
040620: r4 = 0x1
040628: r4 <<= r3
040630: r5 = 0x114001a2800 ll
040640: r4 &= r5
040648: if r4 != 0x0 goto -0x725 ; branch 0x3cd28
040650: if r3 == 0xf goto +0x4 ; branch 0x40678
040658: if r3 == 0x21 goto +0x9 ; branch 0x406a8
040660: r1 = r10
040668: r1 += -0x6c8
040670: goto -0x40d ; branch 0x3e610
040678: if r1 != 0x0 goto +0x1 ; branch 0x40688
040680: goto -0x72c ; branch 0x3cd28
040688: r1 = r10
040690: r1 += -0x6c0
040698: call -0x79e9 ; call 0x3758 / window 81
0406a0: goto -0x730 ; branch 0x3cd28
0406a8: if r2 == 0x0 goto -0x731 ; branch 0x3cd28
0406b0: r1 = r10
0406b8: r1 += -0x6c0
0406c0: goto -0x400 ; branch 0x3e6c8
0406c8: r1 = *(u64 *)(r10 - 0x128)
0406d0: *(u64 *)(r10 - 0x360) = r1
0406d8: r1 = *(u64 *)(r10 - 0x130)
0406e0: *(u64 *)(r10 - 0x368) = r1
0406e8: r1 = *(u64 *)(r10 - 0x118)
0406f0: *(u64 *)(r10 - 0x568) = r1
0406f8: r1 = *(u64 *)(r10 - 0x110)
040700: *(u64 *)(r10 - 0x560) = r1
040708: r1 = *(u64 *)(r10 - 0x108)
040710: *(u64 *)(r10 - 0x558) = r1
040718: r1 = *(u64 *)(r10 - 0x100)
040720: *(u64 *)(r10 - 0x550) = r1
040728: r1 = r10
040730: r1 += -0x330
040738: r2 = r10
040740: r2 += -0xf8
040748: r3 = 0x28
040750: call 0xb0e7 ; call 0x98e90 / window 1246
040758: *(u64 *)(r10 - 0x358) = r6
040760: r1 = *(u64 *)(r10 - 0x568)
040768: *(u64 *)(r10 - 0x350) = r1
040770: r1 = *(u64 *)(r10 - 0x560)
040778: *(u64 *)(r10 - 0x348) = r1
040780: r1 = *(u64 *)(r10 - 0x558)
040788: *(u64 *)(r10 - 0x340) = r1
040790: r1 = *(u64 *)(r10 - 0x550)
040798: *(u64 *)(r10 - 0x338) = r1
0407a0: r1 = r10
0407a8: r1 += -0x130
0407b0: r2 = r8
0407b8: call -0x624f ; call 0xf548 / window 269
0407c0: w1 = *(u32 *)(r10 - 0x130)
0407c8: if r1 == 0x2 goto +0x24 ; branch 0x408f0
0407d0: r6 = *(u64 *)(r10 - 0x108)
0407d8: r1 = r10
0407e0: r1 += -0x130
0407e8: r2 = r7
0407f0: call -0x6256 ; call 0xf548 / window 269
0407f8: w1 = *(u32 *)(r10 - 0x130)
040800: if r1 == 0x2 goto +0x1d ; branch 0x408f0
040808: r9 = *(u64 *)(r10 - 0x108)
040810: r2 = *(u64 *)(r7 + 0x0)
040818: r1 = r10
040820: r1 += -0x328
040828: call -0x7b64 ; call 0x2d10 / window 44
040830: if r0 != 0x0 goto +0x1 ; branch 0x40840
040838: goto +0x3b ; branch 0x40a18
040840: r1 = 0x1d00000000 ll
040850: goto -0x3e2 ; branch 0x3e948
040858: r1 = r10
040860: r1 += -0x6c8
040868: r2 = *(u64 *)(r10 - 0x928)
040870: r3 = *(u64 *)(r10 - 0x920)
040878: call 0x6b4e ; call 0x762f0 / window 772
040880: w1 = *(u32 *)(r10 - 0x6c8)
040888: if r1 != 0x16 goto +0x1 ; branch 0x40898
040890: goto -0x12f ; branch 0x3ff20
040898: w2 = *(u32 *)(r10 - 0x6ac)
0408a0: r3 = *(u64 *)(r10 - 0x930)
0408a8: *(u32 *)(r3 + 0x1c) = w2
0408b0: r2 = *(u64 *)(r10 - 0x6b4)
0408b8: *(u64 *)(r3 + 0x14) = r2
0408c0: r2 = *(u64 *)(r10 - 0x6bc)
0408c8: *(u64 *)(r3 + 0xc) = r2
0408d0: r2 = *(u64 *)(r10 - 0x6c4)
0408d8: *(u64 *)(r3 + 0x4) = r2
0408e0: *(u32 *)(r3 + 0x0) = w1
0408e8: goto -0x1ef ; branch 0x3f978
0408f0: r1 = *(u64 *)(r10 - 0x110)
0408f8: *(u64 *)(r10 - 0x54c) = r1
040900: r2 = *(u64 *)(r10 - 0x118)
040908: *(u64 *)(r10 - 0x554) = r2
040910: r3 = *(u64 *)(r10 - 0x120)
040918: *(u64 *)(r10 - 0x55c) = r3
040920: r4 = *(u64 *)(r10 - 0x128)
040928: *(u64 *)(r10 - 0x564) = r4
040930: goto -0x1df ; branch 0x3fa40
040938: r1 = r10
040940: r1 += -0x130
040948: r2 = *(u64 *)(r10 - 0x920)
040950: r3 = *(u64 *)(r10 - 0x928)
040958: call -0x61a6 ; call 0xfc30 / window 275
040960: w1 = *(u32 *)(r10 - 0x130)
040968: if r1 == 0x16 goto +0x1 ; branch 0x40978
040970: goto -0x92 ; branch 0x404e8
040978: r2 = *(u64 *)(r10 - 0x938)
040980: r2 += 0x30
040988: r3 = *(u64 *)(r8 + 0x0)
040990: r1 = r10
040998: r1 += -0x130
0409a0: r9 = r2
0409a8: call -0x61b0 ; call 0xfc30 / window 275
0409b0: w1 = *(u32 *)(r10 - 0x130)
0409b8: if r1 == 0x16 goto +0x1 ; branch 0x409c8
0409c0: goto -0x9c ; branch 0x404e8
0409c8: r1 = r10
0409d0: r1 += -0x544
0409d8: r2 = *(u64 *)(r10 - 0x950)
0409e0: call -0x7b9b ; call 0x2d10 / window 44
0409e8: if r0 != 0x0 goto +0xe ; branch 0x40a60
0409f0: w1 = *(u8 *)(r10 - 0x408)
0409f8: if r1 == 0x0 goto +0x15 ; branch 0x40aa8
040a00: r1 = 0x1800000000 ll
040a10: goto +0xb ; branch 0x40a70
040a18: r2 = *(u64 *)(r8 + 0x0)
040a20: r1 = r10
040a28: r1 += -0x348
040a30: call -0x7ba5 ; call 0x2d10 / window 44
040a38: if r0 != 0x0 goto +0x1 ; branch 0x40a48
040a40: goto +0x8 ; branch 0x40a88
040a48: r1 = 0x1c00000000 ll
040a58: goto -0x423 ; branch 0x3e948
040a60: r1 = 0xf00000000 ll
040a70: r2 = *(u64 *)(r10 - 0x930)
040a78: *(u64 *)(r2 + 0x0) = r1
040a80: goto -0x94 ; branch 0x405e8
040a88: if r6 == 0x0 goto +0x68 ; branch 0x40dd0
040a90: r1 = 0x4500000000 ll
040aa0: goto -0x42c ; branch 0x3e948
040aa8: r3 = *(u64 *)(r10 - 0x938)
040ab0: r3 += 0x60
040ab8: r1 = r10
040ac0: r1 += -0x130
040ac8: r2 = r10
040ad0: r2 += -0x568
040ad8: call -0x63b1 ; call 0xed58 / window 263
040ae0: w1 = *(u32 *)(r10 - 0x130)
040ae8: if r1 == 0x16 goto +0x1 ; branch 0x40af8
040af0: goto -0xc2 ; branch 0x404e8
040af8: r1 = *(u64 *)(r10 - 0x410)
040b00: if r1 == 0x1 goto +0x1 ; branch 0x40b10
040b08: goto +0x7a ; branch 0x40ee0
040b10: r2 = *(u64 *)(r10 - 0x938)
040b18: r1 = r2
040b20: r1 += 0x150
040b28: *(u64 *)(r10 - 0x960) = r1
040b30: r2 += 0xc0
040b38: *(u64 *)(r10 - 0x968) = r2
040b40: r1 = r10
040b48: r1 += -0x908
040b50: r6 = *(u64 *)(r10 - 0x928)
040b58: r2 = r6
040b60: call 0x8abb ; call 0x86140 / window 990
040b68: r1 = *(u64 *)(r10 - 0x908)
040b70: *(u64 *)(r10 - 0x970) = r1
040b78: r1 = *(u64 *)(r10 - 0x900)
040b80: *(u64 *)(r10 - 0x978) = r1
040b88: r1 = r10
040b90: r1 += -0x918
040b98: r2 = *(u64 *)(r10 - 0x950)
040ba0: call 0x8ab3 ; call 0x86140 / window 990
040ba8: r1 = 0x1
040bb0: *(u64 *)(r10 - 0x398) = r1
040bb8: r1 = r10
040bc0: r1 += -0x389
040bc8: *(u64 *)(r10 - 0x3a0) = r1
040bd0: r1 = 0x7
040bd8: *(u64 *)(r10 - 0x3a8) = r1
040be0: r1 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
040bf0: *(u64 *)(r10 - 0x3b0) = r1
040bf8: r1 = *(u64 *)(r10 - 0x978)
040c00: *(u64 *)(r10 - 0x3c8) = r1
040c08: r1 = *(u64 *)(r10 - 0x970)
040c10: *(u64 *)(r10 - 0x3d0) = r1
040c18: r1 = 0x8
040c20: *(u64 *)(r10 - 0x3d8) = r1
040c28: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
040c38: *(u64 *)(r10 - 0x3e0) = r1
040c40: r1 = *(u64 *)(r10 - 0x910)
040c48: *(u64 *)(r10 - 0x3b8) = r1
040c50: r1 = *(u64 *)(r10 - 0x918)
040c58: *(u64 *)(r10 - 0x3c0) = r1
040c60: r1 = *(u64 *)(r10 - 0x958)
040c68: *(u8 *)(r10 - 0x389) = w1
040c70: r1 = *(u64 *)(r6 + 0x18)
040c78: *(u64 *)(r10 - 0x118) = r1
040c80: r1 = *(u64 *)(r6 + 0x10)
040c88: *(u64 *)(r10 - 0x120) = r1
040c90: r1 = *(u64 *)(r6 + 0x8)
040c98: *(u64 *)(r10 - 0x128) = r1
040ca0: r1 = *(u64 *)(r6 + 0x0)
040ca8: *(u64 *)(r10 - 0x130) = r1
040cb0: r1 = r10
040cb8: r1 += -0x3e0
040cc0: *(u64 *)(r10 - 0xff0) = r1
040cc8: r1 = 0x5
040cd0: *(u64 *)(r10 - 0xfe8) = r1
040cd8: r1 = 0x14
040ce0: *(u64 *)(r10 - 0xff8) = r1
040ce8: r1 = *(u64 *)(r10 - 0x968)
040cf0: *(u64 *)(r10 - 0x1000) = r1
040cf8: r1 = r10
040d00: r1 += -0x368
040d08: r2 = r10
040d10: r2 += -0x130
040d18: r5 = r10
040d20: r3 = *(u64 *)(r10 - 0x938)
040d28: r4 = *(u64 *)(r10 - 0x960)
040d30: call 0x68b4 ; call 0x752d8 / window 770
040d38: w1 = *(u32 *)(r10 - 0x368)
040d40: if r1 == 0x16 goto +0x1 ; branch 0x40d50
040d48: goto +0x35 ; branch 0x40ef8
040d50: r1 = r10
040d58: r1 += -0x130
040d60: r2 = *(u64 *)(r10 - 0x938)
040d68: call 0xb8b ; call 0x469c8 / window 411
040d70: r1 = *(u64 *)(r10 - 0x130)
040d78: if r1 == 0x0 goto +0x6c ; branch 0x410e0
040d80: r1 = *(u64 *)(r10 - 0x128)
040d88: r2 = *(u64 *)(r10 - 0x110)
040d90: r3 = *(u64 *)(r10 - 0x930)
040d98: *(u64 *)(r3 + 0x18) = r2
040da0: r2 = *(u64 *)(r10 - 0x118)
040da8: *(u64 *)(r3 + 0x10) = r2
040db0: r2 = *(u64 *)(r10 - 0x120)
040db8: *(u64 *)(r3 + 0x8) = r2
040dc0: *(u64 *)(r3 + 0x0) = r1
040dc8: goto -0xfd ; branch 0x405e8
040dd0: if r9 == 0x0 goto +0x3 ; branch 0x40df0
040dd8: r1 = 0x4600000000 ll
040de8: goto -0x495 ; branch 0x3e948
040df0: r1 = r10
040df8: r1 += -0x130
040e00: r2 = *(u64 *)(r10 - 0x938)
040e08: call 0x88b3 ; call 0x853a8 / window 986
040e10: w1 = *(u32 *)(r10 - 0x130)
040e18: if r1 == 0x16 goto +0x1 ; branch 0x40e28
040e20: goto +0x4c ; branch 0x41088
040e28: r6 = *(u64 *)(r10 - 0x120)
040e30: r1 = *(u64 *)(r10 - 0x128)
040e38: r2 = *(u64 *)(r1 + 0x8)
040e40: r1 = *(u64 *)(r1 + 0x0)
040e48: r3 = *(u64 *)(r10 - 0x350)
040e50: *(u64 *)(r10 - 0x118) = r3
040e58: r3 = *(u64 *)(r10 - 0x358)
040e60: *(u64 *)(r10 - 0x120) = r3
040e68: r3 = *(u64 *)(r10 - 0x360)
040e70: *(u64 *)(r10 - 0x128) = r3
040e78: r3 = 0x6
040e80: *(u32 *)(r10 - 0x130) = w3
040e88: r3 = r10
040e90: r3 += -0x130
040e98: call -0x7424 ; call 0x6d80 / window 166
040ea0: if r0 == 0x0 goto +0x13 ; branch 0x40f40
040ea8: r1 = *(u64 *)(r10 - 0x930)
040eb0: r2 = r0
040eb8: call 0x8c0b ; call 0x86f18 / window 1002
040ec0: r1 = *(u64 *)(r6 + 0x0)
040ec8: r1 += 0x1
040ed0: *(u64 *)(r6 + 0x0) = r1
040ed8: goto -0x11c ; branch 0x40600
040ee0: r1 = 0x1000000000 ll
040ef0: goto -0x91 ; branch 0x40a70
040ef8: w2 = *(u32 *)(r10 - 0x34c)
040f00: r3 = *(u64 *)(r10 - 0x930)
040f08: *(u32 *)(r3 + 0x1c) = w2
040f10: r2 = *(u64 *)(r10 - 0x354)
040f18: *(u64 *)(r3 + 0x14) = r2
040f20: r2 = *(u64 *)(r10 - 0x35c)
040f28: *(u64 *)(r3 + 0xc) = r2
040f30: r2 = *(u64 *)(r10 - 0x364)
040f38: goto -0x143 ; branch 0x40528
040f40: r1 = *(u64 *)(r6 + 0x0)
040f48: r1 += 0x1
040f50: *(u64 *)(r6 + 0x0) = r1
040f58: r7 = *(u64 *)(r10 - 0x938)
040f60: r1 = r7
040f68: call 0x881f ; call 0x85068 / window 980
040f70: r6 = r0
040f78: r1 = r10
040f80: r1 += -0x130
040f88: r2 = r7
040f90: call 0x8882 ; call 0x853a8 / window 986
040f98: w1 = *(u32 *)(r10 - 0x130)
040fa0: if r1 == 0x16 goto +0x1 ; branch 0x40fb0
040fa8: goto +0x1b ; branch 0x41088
040fb0: r1 = 0x2
040fb8: if r1 > r6 goto +0xbb ; branch 0x41598
040fc0: r4 = *(u64 *)(r10 - 0x128)
040fc8: r1 = r6
040fd0: r1 += -0x2
040fd8: r2 = *(u64 *)(r4 + 0x8)
040fe0: if r2 > r1 goto +0x1 ; branch 0x40ff0
040fe8: goto +0xbc ; branch 0x415d0
040ff0: r3 = *(u64 *)(r10 - 0x120)
040ff8: r2 = *(u64 *)(r4 + 0x0)
041000: r2 += r1
041008: r1 = 0x0
041010: *(u8 *)(r2 + 0x0) = w1
041018: r6 += -0x1
041020: r2 = *(u64 *)(r4 + 0x8)
041028: if r2 > r6 goto +0x1 ; branch 0x41038
041030: goto +0xb6 ; branch 0x415e8
041038: r2 = *(u64 *)(r4 + 0x0)
041040: r2 += r6
041048: *(u8 *)(r2 + 0x0) = w1
041050: r1 = 0x16
041058: r2 = *(u64 *)(r10 - 0x930)
041060: *(u32 *)(r2 + 0x0) = w1
041068: r1 = *(u64 *)(r3 + 0x0)
041070: r1 += 0x1
041078: *(u64 *)(r3 + 0x0) = r1
041080: goto -0x151 ; branch 0x40600
041088: w2 = *(u32 *)(r10 - 0x12c)
041090: r3 = *(u64 *)(r10 - 0x128)
041098: r4 = *(u64 *)(r10 - 0x120)
0410a0: r5 = *(u64 *)(r10 - 0x118)
0410a8: r0 = *(u64 *)(r10 - 0x930)
0410b0: *(u64 *)(r0 + 0x18) = r5
0410b8: *(u64 *)(r0 + 0x10) = r4
0410c0: *(u64 *)(r0 + 0x8) = r3
0410c8: *(u32 *)(r0 + 0x4) = w2
0410d0: *(u32 *)(r0 + 0x0) = w1
0410d8: goto -0x15c ; branch 0x40600
0410e0: r1 = *(u64 *)(r10 - 0x128)
0410e8: *(u64 *)(r10 - 0x388) = r1
0410f0: r1 = *(u64 *)(r10 - 0x948)
0410f8: *(u64 *)(r10 - 0x370) = r1
041100: r1 = *(u64 *)(r10 - 0x940)
041108: *(u64 *)(r10 - 0x378) = r1
041110: r1 = 0x0
041118: *(u64 *)(r10 - 0x380) = r1
041120: r1 = 0x6
041128: *(u32 *)(r10 - 0x388) = w1
041130: r1 = r10
041138: r1 += -0x130
041140: r2 = *(u64 *)(r10 - 0x938)
041148: call 0x884b ; call 0x853a8 / window 986
041150: w1 = *(u32 *)(r10 - 0x130)
041158: if r1 == 0x16 goto +0x1 ; branch 0x41168
041160: goto +0xf ; branch 0x411e0
041168: r6 = *(u64 *)(r10 - 0x120)
041170: r1 = *(u64 *)(r10 - 0x128)
041178: r2 = *(u64 *)(r1 + 0x8)
041180: r1 = *(u64 *)(r1 + 0x0)
041188: r3 = r10
041190: r3 += -0x388
041198: call -0x7484 ; call 0x6d80 / window 166
0411a0: if r0 == 0x0 goto +0x12 ; branch 0x41238
0411a8: r1 = *(u64 *)(r10 - 0x930)
0411b0: r2 = r0
0411b8: call 0x8bab ; call 0x86f18 / window 1002
0411c0: r1 = *(u64 *)(r6 + 0x0)
0411c8: r1 += 0x1
0411d0: *(u64 *)(r6 + 0x0) = r1
0411d8: goto -0x17f ; branch 0x405e8
0411e0: w2 = *(u32 *)(r10 - 0x12c)
0411e8: r3 = *(u64 *)(r10 - 0x128)
0411f0: r4 = *(u64 *)(r10 - 0x120)
0411f8: r5 = *(u64 *)(r10 - 0x118)
041200: r0 = *(u64 *)(r10 - 0x930)
041208: *(u64 *)(r0 + 0x18) = r5
041210: *(u64 *)(r0 + 0x10) = r4
041218: *(u64 *)(r0 + 0x8) = r3
041220: *(u32 *)(r0 + 0x4) = w2
041228: *(u32 *)(r0 + 0x0) = w1
041230: goto -0x18a ; branch 0x405e8
041238: r1 = *(u64 *)(r6 + 0x0)
041240: r1 += 0x1
041248: *(u64 *)(r6 + 0x0) = r1
041250: r1 = *(u64 *)(r10 - 0x938)
041258: w1 = *(u8 *)(r1 + 0x119)
041260: if r1 == 0x0 goto +0x14 ; branch 0x41308
041268: r1 = r10
041270: r1 += -0x130
041278: r2 = *(u64 *)(r10 - 0x920)
041280: call 0xd86 ; call 0x47eb8 / window 419
041288: w6 = *(u32 *)(r10 - 0x28)
041290: if r6 != 0x2 goto +0x11 ; branch 0x41320
041298: r1 = *(u64 *)(r10 - 0x118)
0412a0: *(u64 *)(r10 - 0x220) = r1
0412a8: r2 = *(u64 *)(r10 - 0x120)
0412b0: *(u64 *)(r10 - 0x228) = r2
0412b8: r3 = *(u64 *)(r10 - 0x128)
0412c0: *(u64 *)(r10 - 0x230) = r3
0412c8: r4 = *(u64 *)(r10 - 0x130)
0412d0: *(u64 *)(r10 - 0x238) = r4
0412d8: r5 = *(u64 *)(r10 - 0x930)
0412e0: *(u64 *)(r5 + 0x18) = r1
0412e8: *(u64 *)(r5 + 0x10) = r2
0412f0: *(u64 *)(r5 + 0x8) = r3
0412f8: *(u64 *)(r5 + 0x0) = r4
041300: goto -0x1a4 ; branch 0x405e8
041308: r1 = 0xcb00000000 ll
041318: goto -0x116 ; branch 0x40a70
041320: r1 = r10
041328: r1 += -0x238
041330: *(u64 *)(r10 - 0x928) = r1
041338: r2 = r10
041340: r2 += -0x130
041348: r3 = 0x108
041350: call 0xaf67 ; call 0x98e90 / window 1246
041358: r1 = r10
041360: r1 += -0x25c
041368: r2 = r10
041370: r2 += -0x24
041378: r3 = 0x24
041380: call 0xaf61 ; call 0x98e90 / window 1246
041388: r1 = r10
041390: r1 += -0x368
041398: r2 = *(u64 *)(r10 - 0x928)
0413a0: r3 = 0x108
0413a8: call 0xaf5c ; call 0x98e90 / window 1246
0413b0: *(u32 *)(r10 - 0x260) = w6
0413b8: r1 = 0x0
0413c0: *(u32 *)(r10 - 0x2b4) = w1
0413c8: r1 = r10
0413d0: r1 += -0x130
0413d8: r2 = *(u64 *)(r10 - 0x920)
0413e0: call 0x87f8 ; call 0x853a8 / window 986
0413e8: w1 = *(u32 *)(r10 - 0x130)
0413f0: if r1 == 0x16 goto +0x1 ; branch 0x41400
0413f8: goto +0xf ; branch 0x41478
041400: r6 = *(u64 *)(r10 - 0x120)
041408: r1 = *(u64 *)(r10 - 0x128)
041410: r2 = *(u64 *)(r1 + 0x8)
041418: r1 = *(u64 *)(r1 + 0x0)
041420: r3 = r10
041428: r3 += -0x368
041430: call -0x74f3 ; call 0x6ca0 / window 162
041438: if r0 == 0x0 goto +0x15 ; branch 0x414e8
041440: r1 = *(u64 *)(r10 - 0x930)
041448: r2 = r0
041450: call 0x8b58 ; call 0x86f18 / window 1002
041458: r1 = *(u64 *)(r6 + 0x0)
041460: r1 += 0x1
041468: *(u64 *)(r6 + 0x0) = r1
041470: goto +0xa ; branch 0x414c8
041478: w2 = *(u32 *)(r10 - 0x12c)
041480: r3 = *(u64 *)(r10 - 0x128)
041488: r4 = *(u64 *)(r10 - 0x120)
041490: r5 = *(u64 *)(r10 - 0x118)
041498: r0 = *(u64 *)(r10 - 0x930)
0414a0: *(u64 *)(r0 + 0x18) = r5
0414a8: *(u64 *)(r0 + 0x10) = r4
0414b0: *(u64 *)(r0 + 0x8) = r3
0414b8: *(u32 *)(r0 + 0x4) = w2
0414c0: *(u32 *)(r0 + 0x0) = w1
0414c8: r1 = r10
0414d0: r1 += -0x320
0414d8: call -0x7c88 ; call 0x30a0 / window 59
0414e0: goto -0x1e0 ; branch 0x405e8
0414e8: r1 = *(u64 *)(r6 + 0x0)
0414f0: r1 += 0x1
0414f8: *(u64 *)(r6 + 0x0) = r1
041500: r1 = r10
041508: r1 += -0x320
041510: call -0x7c8f ; call 0x30a0 / window 59
041518: r3 = *(u64 *)(r10 - 0x938)
041520: r2 = *(u64 *)(r3 + 0x0)
041528: *(u64 *)(r10 - 0x1000) = r7
041530: *(u64 *)(r10 - 0xff8) = r8
041538: r1 = r10
041540: r1 += -0x130
041548: r5 = r10
041550: r4 = r9
041558: call 0x2ac8 ; call 0x56ba0 / window 458
041560: w1 = *(u32 *)(r10 - 0x130)
041568: if r1 == 0x16 goto +0x1 ; branch 0x41578
041570: goto -0x212 ; branch 0x404e8
041578: r1 = 0x16
041580: r2 = *(u64 *)(r10 - 0x930)
041588: *(u32 *)(r2 + 0x0) = w1
041590: goto -0x1f6 ; branch 0x405e8
041598: r1 = 0x9a170 ll ; data b'attempt to subtract with overflowprogram/src/assertions/metadata.rsprogram/src/assertions/misc.rs\x00\x00\x00'
0415a8: r2 = 0x21
0415b0: r3 = 0x9ee98 ll ; data b'\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x009\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x009\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x00:\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xa0\xa5\t\x009\x00\x00\x00\x00\x00\x00\x00&\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00'
0415c0: call 0x9dc9 ; call 0x90410 / window 1169
0415c8: call -0x1 ; external abort
0415d0: r3 = 0x9eeb0 ll ; data b'\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x009\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x00:\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xa0\xa5\t\x009\x00\x00\x00\x00\x00\x00\x00&\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00X\x98\t\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x00'
0415e0: goto -0x626 ; branch 0x3e4b8
0415e8: r1 = r6
0415f0: r3 = 0x9eec8 ll ; data b'\x00\x00\x00\x00`\xa5\t\x00@\x00\x00\x00\x00\x00\x00\x00:\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\xa0\xa5\t\x009\x00\x00\x00\x00\x00\x00\x00&\x00\x00\x00;\x00\x00\x00\x00\x00\x00\x00X\x98\t\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00'
041600: goto -0x62a ; branch 0x3e4b8
041608: r6 = r10
041610: r6 += -0x238
041618: r2 = r10
041620: r2 += -0x6b4
041628: r1 = r6
041630: r3 = 0x24
041638: call 0xaf0a ; call 0x98e90 / window 1246
041640: r7 = r10
041648: r7 += -0x368
041650: r2 = r10
041658: r2 += -0x690
041660: r1 = r7
041668: r3 = 0x30
041670: call 0xaf03 ; call 0x98e90 / window 1246
041678: r9 = r10
041680: r9 += -0x6c8
041688: r1 = r9
041690: r2 = r6
041698: r3 = 0x24
0416a0: call 0xaefd ; call 0x98e90 / window 1246
0416a8: r1 = r10
0416b0: r1 += -0x6a4
0416b8: r2 = r7
0416c0: r3 = 0x30
0416c8: call 0xaef8 ; call 0x98e90 / window 1246
0416d0: r6 = r10
0416d8: r6 += -0x568
0416e0: r1 = r6
0416e8: r2 = r9
0416f0: r3 = 0x54
0416f8: call 0xaef2 ; call 0x98e90 / window 1246
041700: r2 = *(u64 *)(r10 - 0x958)
041708: r1 = *(u64 *)(r2 + 0x0)
041710: r1 += -0x1
041718: *(u64 *)(r2 + 0x0) = r1
041720: r1 = *(u64 *)(r10 - 0x950)
041728: *(u32 *)(r10 - 0x6c8) = w1
041730: r1 = r10
041738: r1 += -0x6c4
041740: r2 = r6
041748: r3 = 0x54
041750: call 0xaee7 ; call 0x98e90 / window 1246
041758: r1 = r10
041760: r1 += -0x368
041768: r2 = r10
041770: r2 += -0x6c8
041778: r3 = 0x9eda8 ll ; data b'\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00$\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xb8\x98\t\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00'
041788: call -0x7aa4 ; call 0x4270 / window 95
041790: r1 = *(u64 *)(r10 - 0x340)
041798: if r1 == 0x0 goto +0x14 ; branch 0x41840
0417a0: r1 = *(u64 *)(r10 - 0x950)
0417a8: *(u32 *)(r10 - 0x6c8) = w1
0417b0: r1 = r10
0417b8: r1 += -0x6c4
0417c0: r2 = r10
0417c8: r2 += -0x568
0417d0: r3 = 0x54
0417d8: call 0xaed6 ; call 0x98e90 / window 1246
0417e0: r1 = r10
0417e8: r1 += -0x368
0417f0: r2 = r10
0417f8: r2 += -0x6c8
041800: r3 = 0x9ede0 ll ; data b'\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00'
041810: call -0x7ab5 ; call 0x4270 / window 95
041818: r1 = *(u64 *)(r10 - 0x340)
041820: if r1 == 0x0 goto +0x2c ; branch 0x41988
041828: r1 = 0xa000000000 ll
041838: goto -0x3db ; branch 0x3f968
041840: r1 = *(u64 *)(r10 - 0x950)
041848: *(u32 *)(r10 - 0x6c8) = w1
041850: r1 = r10
041858: r1 += -0x6c4
041860: r2 = r10
041868: r2 += -0x568
041870: r3 = 0x54
041878: call 0xaec2 ; call 0x98e90 / window 1246
041880: r1 = r10
041888: r1 += -0x368
041890: r2 = r10
041898: r2 += -0x6c8
0418a0: r3 = 0x9edc0 ll ; data b'\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00C\x00\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xb8\x98\t\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00R\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00'
0418b0: call -0x7ac9 ; call 0x4270 / window 95
0418b8: w1 = *(u32 *)(r10 - 0x368)
0418c0: if r1 == 0x0 goto -0x345 ; branch 0x3fea0
0418c8: r1 = *(u64 *)(r10 - 0x34c)
0418d0: *(u64 *)(r10 - 0x220) = r1
0418d8: r1 = *(u64 *)(r10 - 0x354)
0418e0: *(u64 *)(r10 - 0x228) = r1
0418e8: r1 = *(u64 *)(r10 - 0x35c)
0418f0: *(u64 *)(r10 - 0x230) = r1
0418f8: r1 = *(u64 *)(r10 - 0x364)
041900: *(u64 *)(r10 - 0x238) = r1
041908: r1 = *(u64 *)(r10 - 0x920)
041910: r2 = *(u64 *)(r1 + 0x0)
041918: r1 = r10
041920: r1 += -0x238
041928: call 0x8567 ; call 0x84468 / window 955
041930: if r0 != 0x0 goto -0x353 ; branch 0x3fea0
041938: r6 = r10
041940: r6 += -0x6c8
041948: r1 = r6
041950: call 0x8310 ; call 0x831d8 / window 915
041958: r1 = r10
041960: r1 += -0x238
041968: r2 = r6
041970: call 0x855e ; call 0x84468 / window 955
041978: if r0 != 0x0 goto -0x35c ; branch 0x3fea0
041980: goto -0x3d ; branch 0x417a0
041988: r1 = *(u64 *)(r10 - 0x950)
041990: *(u32 *)(r10 - 0x6c8) = w1
041998: r1 = r10
0419a0: r1 += -0x6c4
0419a8: r2 = r10
0419b0: r2 += -0x568
0419b8: r3 = 0x54
0419c0: call 0xae99 ; call 0x98e90 / window 1246
0419c8: r1 = r10
0419d0: r1 += -0x368
0419d8: r2 = r10
0419e0: r2 += -0x6c8
0419e8: r3 = 0x9edf8 ll ; data b'\x00\x00\x00\x00\xd6\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00&\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\xf8\xa3\t\x007\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00/\xa4\t\x00B\x00\x00\x00\x00\x00\x00\x00A\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00'
0419f8: call -0x7af2 ; call 0x4270 / window 95
041a00: w1 = *(u32 *)(r10 - 0x368)
041a08: r2 = 0x0
041a10: r3 = *(u64 *)(r10 - 0x930)
041a18: *(u32 *)(r3 + 0x0) = w2
041a20: if r1 != 0x0 goto +0x2 ; branch 0x41a38
041a28: r1 = 0xca
041a30: goto +0x1 ; branch 0x41a40
041a38: r1 = 0xa
041a40: r2 = *(u64 *)(r10 - 0x930)
041a48: *(u32 *)(r2 + 0x4) = w1
041a50: goto -0x41c ; branch 0x3f978
