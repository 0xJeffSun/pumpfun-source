00ee50: r8 = r5
00ee58: r7 = r3
00ee60: r3 = r2
00ee68: r6 = r1
00ee70: r1 = r10
00ee78: r1 += -0xb0
00ee80: r2 = r4
00ee88: call 0x1b4 ; call 0xfc30 / window 275
00ee90: w1 = *(u32 *)(r10 - 0xb0)
00ee98: if r1 != 0x16 goto +0xf ; branch 0xef18
00eea0: *(u64 *)(r10 - 0x1c8) = r7
00eea8: r9 = *(u64 *)(r8 - 0xfe8)
00eeb0: r1 = *(u64 *)(r8 - 0xff0)
00eeb8: *(u64 *)(r10 - 0x1c0) = r1
00eec0: r7 = *(u64 *)(r8 - 0xff8)
00eec8: r8 = *(u64 *)(r8 - 0x1000)
00eed0: r1 = r10
00eed8: r1 += -0xb0
00eee0: r2 = r7
00eee8: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
00eef8: r4 = 0x2
00ef00: call 0x1a8 ; call 0xfc48 / window 276
00ef08: w1 = *(u32 *)(r10 - 0xb0)
00ef10: if r1 == 0x16 goto +0xe ; branch 0xef88
00ef18: w2 = *(u32 *)(r10 - 0x94)
00ef20: *(u32 *)(r10 - 0x190) = w2
00ef28: r3 = *(u64 *)(r10 - 0x9c)
00ef30: *(u64 *)(r10 - 0x198) = r3
00ef38: r4 = *(u64 *)(r10 - 0xa4)
00ef40: *(u64 *)(r10 - 0x1a0) = r4
00ef48: r5 = *(u64 *)(r10 - 0xac)
00ef50: *(u64 *)(r10 - 0x1a8) = r5
00ef58: *(u32 *)(r6 + 0x1c) = w2
00ef60: *(u64 *)(r6 + 0x14) = r3
00ef68: *(u64 *)(r6 + 0xc) = r4
00ef70: *(u64 *)(r6 + 0x4) = r5
00ef78: *(u32 *)(r6 + 0x0) = w1
00ef80: exit
00ef88: *(u64 *)(r10 - 0x1d0) = r7
00ef90: *(u64 *)(r10 - 0x1d8) = r9
00ef98: r1 = r10
00efa0: r1 += -0xb0
00efa8: r7 = *(u64 *)(r10 - 0x1c0)
00efb0: r2 = r7
00efb8: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
00efc8: r4 = 0x2
00efd0: call 0x18e ; call 0xfc48 / window 276
00efd8: w1 = *(u32 *)(r10 - 0xb0)
00efe0: if r1 == 0x16 goto +0x1 ; branch 0xeff0
00efe8: goto -0x1b ; branch 0xef18
00eff0: *(u64 *)(r10 - 0x1e0) = r8
00eff8: r2 = *(u64 *)(r7 + 0x10)
00f000: r2 += 0x10
00f008: r1 = r10
00f010: r1 += -0x1b8
00f018: r3 = 0x9ebc0 ll ; data b'\x00\x00\x00\x00\x91\xa1\t\x00"\x00\x00\x00\x00\x00\x00\x00\xdd\x00\x00\x00P\x00\x00\x00\x00\x00\x00\x00\xb3\xa1\t\x00\x1e\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x00P\x00\x00\x00\x00\x00\x00\x00\xa8\x95\t\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xa8\xa2\t\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc5\xa2\t\x00#\x00\x00\x00\x00\x00\x00\x00-\x01\x00\x00'
00f028: call -0x16ea ; call 0x38e0 / window 87
00f030: r1 = *(u64 *)(r10 - 0x1b8)
00f038: r2 = *(u64 *)(r1 + 0x0)
00f040: r3 = *(u64 *)(r1 + 0x8)
00f048: r8 = *(u64 *)(r10 - 0x1b0)
00f050: r1 = r10
00f058: r1 += -0xb0
00f060: call 0x8e2c ; call 0x561c8 / window 452
00f068: w7 = *(u32 *)(r10 - 0x68)
00f070: if r7 != 0x2 goto +0x10 ; branch 0xf0f8
00f078: r1 = *(u64 *)(r10 - 0x98)
00f080: *(u64 *)(r10 - 0xe0) = r1
00f088: r2 = *(u64 *)(r10 - 0xa0)
00f090: *(u64 *)(r10 - 0xe8) = r2
00f098: r3 = *(u64 *)(r10 - 0xa8)
00f0a0: *(u64 *)(r10 - 0xf0) = r3
00f0a8: r4 = *(u64 *)(r10 - 0xb0)
00f0b0: *(u64 *)(r10 - 0xf8) = r4
00f0b8: *(u64 *)(r6 + 0x18) = r1
00f0c0: *(u64 *)(r6 + 0x10) = r2
00f0c8: *(u64 *)(r6 + 0x8) = r3
00f0d0: *(u64 *)(r6 + 0x0) = r4
00f0d8: r1 = *(u64 *)(r8 + 0x0)
00f0e0: r1 += -0x1
00f0e8: *(u64 *)(r8 + 0x0) = r1
00f0f0: goto -0x2f ; branch 0xef80
00f0f8: r9 = r10
00f100: r9 += -0xf8
00f108: r2 = r10
00f110: r2 += -0xb0
00f118: r1 = r9
00f120: r3 = 0x48
00f128: call 0x113ac ; call 0x98e90 / window 1246
00f130: r1 = r10
00f138: r1 += -0x15c
00f140: r2 = r10
00f148: r2 += -0x64
00f150: r3 = 0x64
00f158: call 0x113a6 ; call 0x98e90 / window 1246
00f160: r1 = r10
00f168: r1 += -0x1a8
00f170: r2 = r9
00f178: r3 = 0x48
00f180: call 0x113a1 ; call 0x98e90 / window 1246
00f188: *(u32 *)(r10 - 0x160) = w7
00f190: r1 = *(u64 *)(r8 + 0x0)
00f198: r1 += -0x1
00f1a0: *(u64 *)(r8 + 0x0) = r1
00f1a8: r1 = *(u64 *)(r10 - 0x1c8)
00f1b0: r2 = *(u64 *)(r1 + 0x0)
00f1b8: r1 = r10
00f1c0: r1 += -0x188
00f1c8: call -0x1898 ; call 0x2d10 / window 44
00f1d0: if r0 != 0x0 goto +0xa ; branch 0xf228
00f1d8: r1 = *(u64 *)(r10 - 0x1d0)
00f1e0: r2 = *(u64 *)(r1 + 0x0)
00f1e8: r1 = r10
00f1f0: r1 += -0x1a8
00f1f8: call -0x189e ; call 0x2d10 / window 44
00f200: if r0 != 0x0 goto +0x1 ; branch 0xf210
00f208: goto +0x7 ; branch 0xf248
00f210: r1 = 0xf00000000 ll
00f220: goto +0x2 ; branch 0xf238
00f228: r1 = 0x4400000000 ll
00f238: *(u64 *)(r6 + 0x0) = r1
00f240: goto -0x59 ; branch 0xef80
00f248: r1 = *(u64 *)(r10 - 0x168)
00f250: r2 = *(u64 *)(r10 - 0x1d8)
00f258: if r2 > r1 goto +0x8 ; branch 0xf2a0
00f260: r2 = *(u64 *)(r10 - 0x1e0)
00f268: r2 += 0x24
00f270: r1 = r10
00f278: r1 += -0x1a8
00f280: call -0x18af ; call 0x2d10 / window 44
00f288: if r0 != 0x0 goto -0x10 ; branch 0xf210
00f290: r1 = 0x16
00f298: goto -0x65 ; branch 0xef78
00f2a0: r1 = 0xb800000000 ll
00f2b0: goto -0x10 ; branch 0xf238
