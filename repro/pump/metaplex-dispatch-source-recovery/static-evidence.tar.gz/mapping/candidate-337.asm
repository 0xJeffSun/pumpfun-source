032128: r9 = r5
032130: *(u64 *)(r10 - 0x6f8) = r2
032138: r6 = r1
032140: r1 = r10
032148: r1 += -0x1b0
032150: r2 = r3
032158: r3 = r4
032160: call 0x5f9c ; call 0x61e48 / window 496
032168: r8 = *(u64 *)(r10 - 0x198)
032170: r1 = *(u64 *)(r10 - 0x1a0)
032178: r3 = *(u64 *)(r10 - 0x1a8)
032180: r2 = *(u64 *)(r10 - 0x1b0)
032188: r7 = *(u64 *)(r10 - 0x188)
032190: if r7 != 0x0 goto +0x6 ; branch 0x321c8
032198: *(u64 *)(r6 + 0x18) = r8
0321a0: *(u64 *)(r6 + 0x10) = r1
0321a8: *(u64 *)(r6 + 0x8) = r3
0321b0: *(u64 *)(r6 + 0x0) = r2
0321b8: r1 = r9
0321c0: goto +0x71 ; branch 0x32550
0321c8: *(u64 *)(r10 - 0x708) = r3
0321d0: *(u64 *)(r10 - 0x700) = r2
0321d8: *(u64 *)(r10 - 0x720) = r1
0321e0: *(u64 *)(r10 - 0x6f0) = r6
0321e8: r1 = *(u64 *)(r10 - 0x160)
0321f0: *(u64 *)(r10 - 0x730) = r1
0321f8: r1 = *(u64 *)(r10 - 0x168)
032200: *(u64 *)(r10 - 0x728) = r1
032208: r6 = *(u64 *)(r10 - 0x170)
032210: r1 = *(u64 *)(r10 - 0x178)
032218: *(u64 *)(r10 - 0x718) = r1
032220: r1 = *(u64 *)(r10 - 0x180)
032228: *(u64 *)(r10 - 0x710) = r1
032230: r1 = *(u64 *)(r10 - 0x190)
032238: *(u64 *)(r10 - 0x738) = r1
032240: r1 = r10
032248: r1 += -0x6c8
032250: r2 = r9
032258: r3 = 0x158
032260: call 0xcd85 ; call 0x98e90 / window 1246
032268: r1 = r10
032270: r1 += -0x1b0
032278: r2 = r7
032280: call 0x8867 ; call 0x765c0 / window 773
032288: w1 = *(u32 *)(r10 - 0x1b0)
032290: r9 = r7
032298: if r1 != 0x16 goto +0x40 ; branch 0x324a0
0322a0: r1 = r10
0322a8: r1 += -0x1b0
0322b0: r2 = r6
0322b8: call 0x8860 ; call 0x765c0 / window 773
0322c0: w1 = *(u32 *)(r10 - 0x1b0)
0322c8: if r1 == 0x16 goto +0x1 ; branch 0x322d8
0322d0: goto +0x39 ; branch 0x324a0
0322d8: r6 = *(u64 *)(r10 - 0x6f0)
0322e0: r2 = *(u64 *)(r10 - 0x700)
0322e8: if r2 == 0x0 goto +0x8 ; branch 0x32330
0322f0: r1 = r10
0322f8: r1 += -0x1b0
032300: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
032310: call -0x44dd ; call 0xfc30 / window 275
032318: w1 = *(u32 *)(r10 - 0x1b0)
032320: if r1 == 0x16 goto +0x1 ; branch 0x32330
032328: goto +0x39 ; branch 0x324f8
032330: r2 = *(u64 *)(r10 - 0x708)
032338: if r2 == 0x0 goto +0x9 ; branch 0x32388
032340: r1 = r10
032348: r1 += -0x1b0
032350: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
032360: r4 = 0x2
032368: call -0x44e5 ; call 0xfc48 / window 276
032370: w1 = *(u32 *)(r10 - 0x1b0)
032378: if r1 == 0x16 goto +0x1 ; branch 0x32388
032380: goto +0x2e ; branch 0x324f8
032388: r1 = r10
032390: r1 += -0x1b0
032398: r2 = *(u64 *)(r10 - 0x710)
0323a0: r3 = 0x9cb7e ll ; data b"\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9\x06\xdd\xf6\xe1\xeeu\x8f\xde\x18B]\xbc\xe4l\xcd\xda\xb6\x1a\xfcM\x83\xb9\r'\xfe\xbd\xf9(\xd8\xa1\x8b\xfcsrc/token/utils.rsattempt to add wit"
0323b0: r4 = 0x2
0323b8: call -0x44ef ; call 0xfc48 / window 276
0323c0: w1 = *(u32 *)(r10 - 0x1b0)
0323c8: if r1 == 0x16 goto +0x1 ; branch 0x323d8
0323d0: goto +0x24 ; branch 0x324f8
0323d8: r1 = r10
0323e0: r1 += -0x1b0
0323e8: r2 = *(u64 *)(r10 - 0x718)
0323f0: r3 = *(u64 *)(r10 - 0x6f8)
0323f8: call -0x44fa ; call 0xfc30 / window 275
032400: w1 = *(u32 *)(r10 - 0x1b0)
032408: if r1 == 0x16 goto +0x1 ; branch 0x32418
032410: goto +0x1c ; branch 0x324f8
032418: r2 = *(u64 *)(r10 - 0x720)
032420: if r2 == 0x0 goto +0x7 ; branch 0x32460
032428: r1 = r10
032430: r1 += -0x1b0
032438: r3 = *(u64 *)(r10 - 0x6f8)
032440: call -0x4503 ; call 0xfc30 / window 275
032448: w1 = *(u32 *)(r10 - 0x1b0)
032450: if r1 == 0x16 goto +0x1 ; branch 0x32460
032458: goto +0x13 ; branch 0x324f8
032460: r1 = *(u64 *)(r10 - 0x728)
032468: r2 = 0x9ec58 ll ; data b'\x00\x00\x00\x00\xd8\x98\t\x00\x00\x00\x00\x00\xb8\x99\t\x00\x00\x00\x00\x00\x08\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x008\x99\t\x00\x00\x00\x00\x00*\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00P\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00'
032478: call -0x5ef5 ; call 0x2cd8 / window 42
032480: if r0 != 0x0 goto +0x1 ; branch 0x32490
032488: goto +0x1a ; branch 0x32560
032490: r1 = 0x6
032498: goto +0x13 ; branch 0x32538
0324a0: w2 = *(u32 *)(r10 - 0x194)
0324a8: r3 = *(u64 *)(r10 - 0x6f0)
0324b0: *(u32 *)(r3 + 0x1c) = w2
0324b8: r2 = *(u64 *)(r10 - 0x19c)
0324c0: *(u64 *)(r3 + 0x14) = r2
0324c8: r2 = *(u64 *)(r10 - 0x1a4)
0324d0: *(u64 *)(r3 + 0xc) = r2
0324d8: r2 = *(u64 *)(r10 - 0x1ac)
0324e0: *(u64 *)(r3 + 0x4) = r2
0324e8: *(u32 *)(r3 + 0x0) = w1
0324f0: goto +0x9 ; branch 0x32540
0324f8: w2 = *(u32 *)(r10 - 0x194)
032500: *(u32 *)(r6 + 0x1c) = w2
032508: r2 = *(u64 *)(r10 - 0x19c)
032510: *(u64 *)(r6 + 0x14) = r2
032518: r2 = *(u64 *)(r10 - 0x1a4)
032520: *(u64 *)(r6 + 0xc) = r2
032528: r2 = *(u64 *)(r10 - 0x1ac)
032530: *(u64 *)(r6 + 0x4) = r2
032538: *(u32 *)(r6 + 0x0) = w1
032540: r1 = r10
032548: r1 += -0x6c8
032550: call -0x5e39 ; call 0x3390 / window 68
032558: exit
032560: r1 = *(u64 *)(r10 - 0x730)
032568: r2 = 0x9ec60 ll ; data b'\x00\x00\x00\x00\xb8\x99\t\x00\x00\x00\x00\x00\x08\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x008\x99\t\x00\x00\x00\x00\x00*\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00P\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00v\xa3\t\x00)\x00\x00\x00'
032578: call -0x5f15 ; call 0x2cd8 / window 42
032580: if r0 != 0x0 goto -0x1f ; branch 0x32490
032588: r1 = *(u64 *)(r10 - 0x738)
032590: if r1 == 0x0 goto +0x6 ; branch 0x325c8
032598: if r8 == 0x0 goto +0x30 ; branch 0x32720
0325a0: r1 = r8
0325a8: r2 = 0x9f0f0 ll ; data b'\x00\x00\x00\x00\xd8\x99\t\x00\x00\x00\x00\x00A\xa7\t\x00*\x00\x00\x00\x00\x00\x00\x00\xd2\x00\x00\x00<\x00\x00\x00\x00\x00\x00\x00A\xa7\t\x00*\x00\x00\x00\x00\x00\x00\x00\xfd\x00\x00\x00T\x00\x00\x00\x00\x00\x00\x00A\xa7\t\x00*\x00\x00\x00\x00\x00\x00\x00\xd3\x01\x00\x00R\x00\x00\x00\x00\x00\x00\x00A\xa7\t\x00*\x00\x00\x00\x00\x00\x00\x00Q\x01\x00\x00'
0325b8: call -0x5f1d ; call 0x2cd8 / window 42
0325c0: if r0 != 0x0 goto -0x27 ; branch 0x32490
0325c8: r8 = 0x0
0325d0: r6 = 0x2
0325d8: r2 = *(u64 *)(r10 - 0x708)
0325e0: if r2 == 0x0 goto +0x7b ; branch 0x329c0
0325e8: r1 = r10
0325f0: r1 += -0x1b0
0325f8: call 0xa5a6 ; call 0x85330 / window 985
032600: w1 = *(u32 *)(r10 - 0x1b0)
032608: if r1 == 0x16 goto +0x1 ; branch 0x32618
032610: goto +0x25 ; branch 0x32740
032618: r7 = *(u64 *)(r10 - 0x1a0)
032620: r1 = *(u64 *)(r10 - 0x1a8)
032628: r3 = *(u64 *)(r1 + 0x8)
032630: r2 = *(u64 *)(r1 + 0x0)
032638: r1 = r10
032640: r1 += -0x1b0
032648: call 0x936b ; call 0x7c1a8 / window 851
032650: w6 = *(u32 *)(r10 - 0x158)
032658: if r6 == 0x2 goto +0x1 ; branch 0x32668
032660: goto +0x26 ; branch 0x32798
032668: r1 = *(u64 *)(r10 - 0x198)
032670: *(u64 *)(r10 - 0x460) = r1
032678: r1 = *(u64 *)(r10 - 0x1a0)
032680: *(u64 *)(r10 - 0x468) = r1
032688: r1 = *(u64 *)(r10 - 0x1a8)
032690: *(u64 *)(r10 - 0x428) = r1
032698: *(u64 *)(r10 - 0x470) = r1
0326a0: r1 = *(u64 *)(r10 - 0x1b0)
0326a8: *(u64 *)(r10 - 0x430) = r1
0326b0: *(u64 *)(r10 - 0x478) = r1
0326b8: r1 = *(u64 *)(r10 - 0x460)
0326c0: r2 = *(u64 *)(r10 - 0x6f0)
0326c8: *(u64 *)(r2 + 0x18) = r1
0326d0: r1 = *(u64 *)(r10 - 0x468)
0326d8: *(u64 *)(r2 + 0x10) = r1
0326e0: r1 = *(u64 *)(r10 - 0x470)
0326e8: *(u64 *)(r2 + 0x8) = r1
0326f0: r1 = *(u64 *)(r10 - 0x478)
0326f8: *(u64 *)(r2 + 0x0) = r1
032700: r1 = *(u64 *)(r7 + 0x0)
032708: r1 += -0x1
032710: *(u64 *)(r7 + 0x0) = r1
032718: goto -0x3c ; branch 0x32540
032720: r1 = 0x9600000000 ll
032730: *(u64 *)(r6 + 0x0) = r1
032738: goto -0x40 ; branch 0x32540
032740: w2 = *(u32 *)(r10 - 0x1ac)
032748: r3 = *(u64 *)(r10 - 0x1a8)
032750: r4 = *(u64 *)(r10 - 0x1a0)
032758: r5 = *(u64 *)(r10 - 0x198)
032760: r0 = *(u64 *)(r10 - 0x6f0)
032768: *(u64 *)(r0 + 0x18) = r5
032770: *(u64 *)(r0 + 0x10) = r4
032778: *(u64 *)(r0 + 0x8) = r3
032780: *(u32 *)(r0 + 0x4) = w2
032788: *(u32 *)(r0 + 0x0) = w1
032790: goto -0x4b ; branch 0x32540
032798: *(u64 *)(r10 - 0x728) = r9
0327a0: r8 = r10
0327a8: r8 += -0x570
0327b0: r2 = r10
0327b8: r2 += -0x1b0
0327c0: r1 = r8
0327c8: r3 = 0x58
0327d0: call 0xccd7 ; call 0x98e90 / window 1246
0327d8: r1 = r10
0327e0: r1 += -0x39c
0327e8: r2 = r10
0327f0: r2 += -0x154
0327f8: *(u64 *)(r10 - 0x730) = r1
032800: r3 = 0x64
032808: call 0xccd0 ; call 0x98e90 / window 1246
032810: r1 = r10
032818: r1 += -0x58
032820: r2 = r8
032828: r3 = 0x58
032830: call 0xcccb ; call 0x98e90 / window 1246
032838: r8 = r10
032840: r8 += -0x430
032848: r2 = r10
032850: r2 += -0x48
032858: r1 = r8
032860: r3 = 0x48
032868: call 0xccc4 ; call 0x98e90 / window 1246
032870: r9 = r10
032878: r9 += -0x478
032880: r1 = r9
032888: r2 = r8
032890: r3 = 0x48
032898: call 0xccbe ; call 0x98e90 / window 1246
0328a0: r8 = r10
0328a8: r8 += -0x3e8
0328b0: r1 = r8
0328b8: r2 = r9
0328c0: r3 = 0x48
0328c8: call 0xccb8 ; call 0x98e90 / window 1246
0328d0: *(u32 *)(r10 - 0x3a0) = w6
0328d8: r1 = *(u64 *)(r7 + 0x0)
0328e0: r1 += -0x1
0328e8: *(u64 *)(r7 + 0x0) = r1
0328f0: r1 = *(u64 *)(r10 - 0x710)
0328f8: r2 = *(u64 *)(r1 + 0x0)
032900: r1 = r8
032908: call -0x5f80 ; call 0x2d10 / window 44
032910: if r0 != 0x0 goto +0x1 ; branch 0x32920
032918: goto +0x3 ; branch 0x32938
032920: r1 = 0xf00000000 ll
032930: goto +0x12e ; branch 0x332a8
032938: r1 = *(u64 *)(r10 - 0x3a8)
032940: if r1 == 0x0 goto +0x12a ; branch 0x33298
032948: r1 = *(u64 *)(r10 - 0x708)
032950: r8 = *(u64 *)(r1 + 0x0)
032958: r1 = r10
032960: r1 += -0x4c0
032968: r2 = r10
032970: r2 += -0x3e8
032978: r3 = 0x48
032980: call 0xcca1 ; call 0x98e90 / window 1246
032988: w6 = *(u32 *)(r10 - 0x3a0)
032990: r1 = r10
032998: r1 += -0x2b8
0329a0: r2 = *(u64 *)(r10 - 0x730)
0329a8: r3 = 0x64
0329b0: call 0xcc9b ; call 0x98e90 / window 1246
0329b8: r9 = *(u64 *)(r10 - 0x728)
0329c0: r1 = r10
0329c8: r1 += -0x570
0329d0: r2 = r10
0329d8: r2 += -0x4c0
0329e0: r3 = 0x48
0329e8: call 0xcc94 ; call 0x98e90 / window 1246
0329f0: *(u32 *)(r10 - 0x528) = w6
0329f8: r1 = r10
032a00: r1 += -0x524
032a08: r2 = r10
032a10: r2 += -0x2b8
032a18: r3 = 0x64
032a20: call 0xcc8d ; call 0x98e90 / window 1246
032a28: r1 = r10
032a30: r1 += -0x1b0
032a38: r2 = *(u64 *)(r10 - 0x718)
032a40: call 0x2a8e ; call 0x47eb8 / window 419
032a48: w7 = *(u32 *)(r10 - 0xa8)
032a50: if r7 != 0x2 goto +0xe ; branch 0x32ac8
032a58: r1 = *(u64 *)(r10 - 0x198)
032a60: *(u64 *)(r10 - 0x2a0) = r1
032a68: r2 = *(u64 *)(r10 - 0x1a0)
032a70: *(u64 *)(r10 - 0x2a8) = r2
032a78: r3 = *(u64 *)(r10 - 0x1a8)
032a80: *(u64 *)(r10 - 0x2b0) = r3
032a88: r4 = *(u64 *)(r10 - 0x1b0)
032a90: *(u64 *)(r10 - 0x2b8) = r4
032a98: r5 = *(u64 *)(r10 - 0x6f0)
032aa0: *(u64 *)(r5 + 0x18) = r1
032aa8: *(u64 *)(r5 + 0x10) = r2
032ab0: *(u64 *)(r5 + 0x8) = r3
032ab8: *(u64 *)(r5 + 0x0) = r4
032ac0: goto -0xb1 ; branch 0x32540
032ac8: r6 = r10
032ad0: r6 += -0x2b8
032ad8: r2 = r10
032ae0: r2 += -0x1b0
032ae8: r1 = r6
032af0: r3 = 0x108
032af8: call 0xcc72 ; call 0x98e90 / window 1246
032b00: r1 = r10
032b08: r1 += -0x2dc
032b10: r2 = r10
032b18: r2 += -0xa4
032b20: r3 = 0x24
032b28: call 0xcc6c ; call 0x98e90 / window 1246
032b30: r1 = r10
032b38: r1 += -0x3e8
032b40: r2 = r6
032b48: r3 = 0x108
032b50: call 0xcc67 ; call 0x98e90 / window 1246
032b58: *(u32 *)(r10 - 0x2e0) = w7
032b60: r1 = *(u64 *)(r10 - 0x710)
032b68: r2 = *(u64 *)(r1 + 0x0)
032b70: r1 = r10
032b78: r1 += -0x3c4
032b80: call -0x5fcf ; call 0x2d10 / window 44
032b88: if r0 != 0x0 goto +0x1 ; branch 0x32b98
032b90: goto +0x5 ; branch 0x32bc0
032b98: r1 = 0xf00000000 ll
032ba8: r2 = *(u64 *)(r10 - 0x6f0)
032bb0: *(u64 *)(r2 + 0x0) = r1
032bb8: goto +0xd7 ; branch 0x33278
032bc0: r1 = *(u64 *)(r10 - 0x720)
032bc8: if r1 == 0x0 goto +0x29 ; branch 0x32d18
032bd0: r1 = r10
032bd8: r1 += -0x6d8
032be0: r6 = *(u64 *)(r10 - 0x6f8)
032be8: r2 = r6
032bf0: call 0xa6a9 ; call 0x86140 / window 990
032bf8: r1 = *(u64 *)(r10 - 0x710)
032c00: r2 = *(u64 *)(r1 + 0x0)
032c08: r1 = *(u64 *)(r10 - 0x6d8)
032c10: *(u64 *)(r10 - 0x708) = r1
032c18: r7 = *(u64 *)(r10 - 0x6d0)
032c20: r1 = r10
032c28: r1 += -0x6e8
032c30: call 0xa6a1 ; call 0x86140 / window 990
032c38: r1 = 0x7
032c40: *(u64 *)(r10 - 0x178) = r1
032c48: r1 = 0x9a145 ll ; data b'editionprogram/src/assertions/edition.rs\x00\x00\x00attempt to subtract with overflowprogram/src/assertions/m'
032c58: *(u64 *)(r10 - 0x180) = r1
032c60: *(u64 *)(r10 - 0x198) = r7
032c68: r1 = *(u64 *)(r10 - 0x708)
032c70: *(u64 *)(r10 - 0x1a0) = r1
032c78: r1 = 0x8
032c80: *(u64 *)(r10 - 0x1a8) = r1
032c88: r1 = 0x9a100 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
032c98: *(u64 *)(r10 - 0x1b0) = r1
032ca0: r1 = *(u64 *)(r10 - 0x6e0)
032ca8: *(u64 *)(r10 - 0x188) = r1
032cb0: r1 = *(u64 *)(r10 - 0x6e8)
032cb8: *(u64 *)(r10 - 0x190) = r1
032cc0: r1 = r10
032cc8: r1 += -0x2b8
032cd0: r4 = r10
032cd8: r4 += -0x1b0
032ce0: r2 = r6
032ce8: r3 = *(u64 *)(r10 - 0x720)
032cf0: r5 = 0x4
032cf8: call -0x4626 ; call 0xfbd0 / window 273
032d00: w1 = *(u32 *)(r10 - 0x2b8)
032d08: if r1 == 0x16 goto +0x1 ; branch 0x32d18
032d10: goto +0xa0 ; branch 0x33218
032d18: r3 = 0x0
032d20: w1 = *(u8 *)(r10 - 0x330)
032d28: if r1 == 0x2 goto +0x2 ; branch 0x32d40
032d30: r3 = r10
032d38: r3 += -0x32f
032d40: w2 = *(u32 *)(r10 - 0x6c8)
032d48: r1 = r10
032d50: r1 += -0x62c
032d58: *(u64 *)(r10 - 0x6f8) = r3
032d60: if r2 == 0x0 goto +0x7 ; branch 0x32da0
032d68: if r2 == 0x1 goto +0x6 ; branch 0x32da0
032d70: r1 = r10
032d78: r1 += -0x6c0
032d80: if r2 == 0x3 goto +0x3 ; branch 0x32da0
032d88: r3 = r9
032d90: if r2 == 0x7 goto +0x1 ; branch 0x32da0
032d98: goto +0x6 ; branch 0x32dd0
032da0: w2 = *(u32 *)(r1 + 0x0)
032da8: r1 += 0x5
032db0: if r2 == 0x2 goto +0x1 ; branch 0x32dc0
032db8: r1 = *(u64 *)(r10 - 0x6f8)
032dc0: *(u64 *)(r10 - 0x6f8) = r1
032dc8: r3 = r9
032dd0: *(u64 *)(r10 - 0x728) = r3
032dd8: r1 = *(u64 *)(r3 + 0x0)
032de0: *(u64 *)(r10 - 0x730) = r1
032de8: r1 = *(u64 *)(r10 - 0x710)
032df0: r1 = *(u64 *)(r1 + 0x0)
032df8: *(u64 *)(r10 - 0x740) = r1
032e00: w9 = *(u32 *)(r10 - 0x528)
032e08: r1 = 0x1c
032e10: r2 = 0x4
032e18: call -0x5a33 ; call 0x5c88 / window 138
032e20: r6 = r0
032e28: r1 = 0x400000006 ll
032e38: *(u64 *)(r6 + 0x10) = r1
032e40: r1 = 0x100000005 ll
032e50: *(u64 *)(r6 + 0x8) = r1
032e58: r1 = 0x300000000 ll
032e68: *(u64 *)(r6 + 0x0) = r1
032e70: r1 = r10
032e78: r1 += -0x570
032e80: r7 = 0x0
032e88: r2 = 0x0
032e90: *(u64 *)(r10 - 0x708) = r2
032e98: if r9 == 0x2 goto +0x1 ; branch 0x32ea8
032ea0: *(u64 *)(r10 - 0x708) = r1
032ea8: r9 = 0x7
032eb0: *(u32 *)(r6 + 0x18) = w9
032eb8: r1 = 0xc
032ec0: r2 = 0x4
032ec8: call -0x5a49 ; call 0x5c88 / window 138
032ed0: r1 = 0x100000003 ll
032ee0: *(u64 *)(r0 + 0x0) = r1
032ee8: r2 = 0x4
032ef0: *(u32 *)(r0 + 0x8) = w2
032ef8: r1 = 0x998d8 ll ; data b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibrary/core/src/slice/memchr.rs\x06\xdd\xf6\xe1'
032f08: *(u64 *)(r10 - 0x168) = r1
032f10: *(u64 *)(r10 - 0x170) = r1
032f18: *(u64 *)(r10 - 0x178) = r1
032f20: r1 = 0x99da4 ll ; data b'\x04\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00host unreachablerange end index already mutably borrowed/home/runner/work/platform-t'
032f30: *(u64 *)(r10 - 0x1b0) = r1
032f38: *(u64 *)(r10 - 0x160) = r7
032f40: *(u64 *)(r10 - 0x1a8) = r2
032f48: *(u64 *)(r10 - 0x1a0) = r7
032f50: *(u64 *)(r10 - 0x198) = r7
032f58: *(u64 *)(r10 - 0x190) = r7
032f60: *(u64 *)(r10 - 0x188) = r7
032f68: *(u64 *)(r10 - 0x150) = r7
032f70: *(u64 *)(r10 - 0x158) = r2
032f78: *(u64 *)(r10 - 0x148) = r7
032f80: *(u64 *)(r10 - 0x140) = r2
032f88: *(u64 *)(r10 - 0x138) = r7
032f90: *(u64 *)(r10 - 0x180) = r7
032f98: *(u64 *)(r10 - 0x130) = r7
032fa0: *(u64 *)(r10 - 0x128) = r2
032fa8: *(u64 *)(r10 - 0x120) = r7
032fb0: r1 = *(u64 *)(r10 - 0x740)
032fb8: *(u64 *)(r10 - 0x270) = r1
032fc0: r1 = *(u64 *)(r10 - 0x730)
032fc8: *(u64 *)(r10 - 0x280) = r1
032fd0: r1 = 0x9a77c ll ; data b'\x01\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00Auth type: DelegateAuth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.'
032fe0: *(u64 *)(r10 - 0x2b8) = r1
032fe8: *(u64 *)(r10 - 0x248) = r0
032ff0: r1 = 0x3
032ff8: *(u64 *)(r10 - 0x2b0) = r1
033000: *(u64 *)(r10 - 0x240) = r1
033008: *(u64 *)(r10 - 0x250) = r1
033010: *(u64 *)(r10 - 0x260) = r6
033018: *(u64 *)(r10 - 0x258) = r9
033020: *(u64 *)(r10 - 0x268) = r9
033028: r1 = *(u64 *)(r10 - 0x700)
033030: *(u64 *)(r10 - 0x290) = r1
033038: *(u64 *)(r10 - 0x2a0) = r8
033040: r1 = *(u64 *)(r10 - 0x6f8)
033048: *(u64 *)(r10 - 0x2a8) = r1
033050: r1 = *(u64 *)(r10 - 0x708)
033058: *(u64 *)(r10 - 0x298) = r1
033060: *(u64 *)(r10 - 0x288) = r7
033068: *(u64 *)(r10 - 0x228) = r7
033070: *(u64 *)(r10 - 0x230) = r2
033078: r1 = *(u64 *)(r10 - 0x130)
033080: *(u64 *)(r10 - 0x238) = r1
033088: r6 = r10
033090: r6 += -0x3e4
033098: *(u64 *)(r10 - 0x278) = r6
0330a0: r1 = r10
0330a8: r1 += -0x58
0330b0: r2 = r10
0330b8: r2 += -0x2b8
0330c0: call 0x20a2 ; call 0x435d8 / window 370
0330c8: r1 = r10
0330d0: r1 += -0x160
0330d8: w2 = *(u32 *)(r10 - 0x58)
0330e0: if r2 == 0x16 goto +0x1 ; branch 0x330f0
0330e8: goto +0x16 ; branch 0x331a0
0330f0: w8 = *(u32 *)(r10 - 0x4c)
0330f8: w7 = *(u32 *)(r10 - 0x50)
033100: call -0x55bc ; call 0x8328 / window 199
033108: r1 = r10
033110: r1 += -0x148
033118: call -0x55bf ; call 0x8328 / window 199
033120: r1 = 0x9a7ac ll ; data b'Auth type: Metadataprogram/src/processor/resize/mod.rsprogram/src/processor/state/mod.rsprogram/src/'
033130: if r8 == 0x1 goto +0x33 ; branch 0x332d0
033138: if r8 == 0x3 goto +0x30 ; branch 0x332c0
033140: r1 = 0x9e
033148: if r8 != 0x2 goto +0x5 ; branch 0x33178
033150: r1 = 0x9a79b ll ; data b'Auth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.rsprogram/src/processor/state/m'
033160: r2 = 0x11
033168: call -0x1 ; external sol_log_
033170: r1 = 0x91
033178: r2 = *(u64 *)(r10 - 0x6f0)
033180: *(u32 *)(r2 + 0x4) = w1
033188: r1 = 0x0
033190: *(u32 *)(r2 + 0x0) = w1
033198: goto +0x1b ; branch 0x33278
0331a0: r3 = *(u64 *)(r10 - 0x54)
0331a8: w4 = *(u32 *)(r10 - 0x4c)
0331b0: r5 = *(u64 *)(r10 - 0x48)
0331b8: r0 = *(u64 *)(r10 - 0x6f0)
0331c0: *(u64 *)(r0 + 0x10) = r5
0331c8: r5 = *(u64 *)(r10 - 0x40)
0331d0: *(u64 *)(r0 + 0x18) = r5
0331d8: *(u32 *)(r0 + 0xc) = w4
0331e0: *(u64 *)(r0 + 0x4) = r3
0331e8: *(u32 *)(r0 + 0x0) = w2
0331f0: call -0x55da ; call 0x8328 / window 199
0331f8: r1 = r10
033200: r1 += -0x148
033208: call -0x55dd ; call 0x8328 / window 199
033210: goto +0xc ; branch 0x33278
033218: w2 = *(u8 *)(r10 - 0x2b4)
033220: w3 = *(u32 *)(r10 - 0x29c)
033228: r4 = *(u64 *)(r10 - 0x6f0)
033230: *(u32 *)(r4 + 0x1c) = w3
033238: r3 = *(u64 *)(r10 - 0x2a3)
033240: *(u64 *)(r4 + 0x15) = r3
033248: r3 = *(u64 *)(r10 - 0x2ab)
033250: *(u64 *)(r4 + 0xd) = r3
033258: r3 = *(u64 *)(r10 - 0x2b3)
033260: *(u64 *)(r4 + 0x5) = r3
033268: *(u8 *)(r4 + 0x4) = w2
033270: *(u32 *)(r4 + 0x0) = w1
033278: r1 = r10
033280: r1 += -0x3a0
033288: call -0x603e ; call 0x30a0 / window 59
033290: goto -0x1ab ; branch 0x32540
033298: r1 = 0xa800000000 ll
0332a8: r2 = *(u64 *)(r10 - 0x6f0)
0332b0: *(u64 *)(r2 + 0x0) = r1
0332b8: goto -0x1b0 ; branch 0x32540
0332c0: r1 = 0x9a788 ll ; data b'Auth type: DelegateAuth type: HolderAuth type: Metadataprogram/src/processor/resize/mod.rsprogram/sr'
0332d0: r2 = 0x13
0332d8: call -0x1 ; external sol_log_
0332e0: r1 = 0xb7
0332e8: if r7 == 0x0 goto +0x9 ; branch 0x33338
0332f0: if r7 == 0x1 goto +0xb ; branch 0x33350
0332f8: if r7 == 0x3 goto +0xe ; branch 0x33370
033300: if r7 == 0x4 goto +0x11 ; branch 0x33390
033308: if r7 == 0x5 goto +0x14 ; branch 0x333b0
033310: if r7 == 0x6 goto +0x17 ; branch 0x333d0
033318: if r7 == 0x7 goto +0x1a ; branch 0x333f0
033320: if r7 != 0x8 goto -0x36 ; branch 0x33178
033328: w2 = *(u32 *)(r10 - 0x6c8)
033330: goto +0x2a ; branch 0x33488
033338: w2 = *(u32 *)(r10 - 0x6c8)
033340: if r2 == 0x2 goto +0x2d ; branch 0x334b0
033348: goto -0x3b ; branch 0x33178
033350: r7 = 0x6
033358: w2 = *(u32 *)(r10 - 0x6c8)
033360: if r2 == 0x3 goto +0x2f ; branch 0x334e0
033368: goto -0x3f ; branch 0x33178
033370: r7 = 0x6
033378: w2 = *(u32 *)(r10 - 0x6c8)
033380: if r2 == 0x4 goto +0x2b ; branch 0x334e0
033388: goto -0x43 ; branch 0x33178
033390: w2 = *(u32 *)(r10 - 0x6c8)
033398: if r2 == 0x0 goto +0xe ; branch 0x33410
0333a0: if r2 == 0x5 goto +0x1c ; branch 0x33488
0333a8: goto -0x47 ; branch 0x33178
0333b0: r7 = 0x6
0333b8: w2 = *(u32 *)(r10 - 0x6c8)
0333c0: if r2 == 0x6 goto +0x23 ; branch 0x334e0
0333c8: goto -0x4b ; branch 0x33178
0333d0: r7 = 0x6
0333d8: w2 = *(u32 *)(r10 - 0x6c8)
0333e0: if r2 == 0x7 goto +0x1f ; branch 0x334e0
0333e8: goto -0x4f ; branch 0x33178
0333f0: r7 = 0x6
0333f8: w2 = *(u32 *)(r10 - 0x6c8)
033400: if r2 == 0x8 goto +0x1b ; branch 0x334e0
033408: goto -0x53 ; branch 0x33178
033410: w3 = *(u8 *)(r10 - 0x6c0)
033418: if r3 != 0x0 goto -0x55 ; branch 0x33178
033420: r3 = *(u64 *)(r10 - 0x690)
033428: if r3 != 0x0 goto -0x57 ; branch 0x33178
033430: w3 = *(u8 *)(r10 - 0x630)
033438: if r3 != 0x2 goto -0x59 ; branch 0x33178
033440: w3 = *(u8 *)(r10 - 0x62f)
033448: if r3 != 0x2 goto -0x5b ; branch 0x33178
033450: w3 = *(u32 *)(r10 - 0x62c)
033458: if r3 != 0x0 goto -0x5d ; branch 0x33178
033460: w3 = *(u32 *)(r10 - 0x600)
033468: if r3 != 0x0 goto -0x5f ; branch 0x33178
033470: w3 = *(u32 *)(r10 - 0x5e8)
033478: if r3 == 0x0 goto +0x1 ; branch 0x33488
033480: goto -0x62 ; branch 0x33178
033488: r1 = r2
033490: if r1 == 0x1 goto +0x6 ; branch 0x334c8
033498: r7 = 0x6
0334a0: if r1 == 0x2 goto +0x1 ; branch 0x334b0
0334a8: goto +0x6 ; branch 0x334e0
0334b0: r1 = r10
0334b8: r1 += -0x69c
0334c0: goto +0x2 ; branch 0x334d8
0334c8: r1 = r10
0334d0: r1 += -0x5a4
0334d8: w7 = *(u32 *)(r1 + 0x0)
0334e0: w1 = *(u32 *)(r10 - 0x334)
0334e8: if r1 == 0x6 goto +0x1 ; branch 0x334f8
0334f0: goto +0x8 ; branch 0x33538
0334f8: r1 = r10
033500: r1 += -0x1b0
033508: r2 = *(u64 *)(r10 - 0x710)
033510: r3 = *(u64 *)(r10 - 0x720)
033518: call 0x45e1 ; call 0x56428 / window 453
033520: w1 = *(u32 *)(r10 - 0x1b0)
033528: if r1 != 0x16 goto +0x88 ; branch 0x33970
033530: w1 = *(u32 *)(r10 - 0x1ac)
033538: r2 = r7
033540: r2 <<= 0x20
033548: r2 >>= 0x20
033550: r9 = r1
033558: if r2 == 0x6 goto +0xc ; branch 0x335c0
033560: r2 = r1
033568: r2 += -0x1
033570: r2 <<= 0x20
033578: r2 >>= 0x20
033580: r3 = 0x2
033588: if r3 > r2 goto +0x86 ; branch 0x339c0
033590: r2 = r7
033598: r2 <<= 0x20
0335a0: r2 >>= 0x20
0335a8: r9 = r7
0335b0: if r1 == r2 goto +0x1 ; branch 0x335c0
0335b8: goto +0x89 ; branch 0x33a08
0335c0: r1 = 0xfffffffe ll
0335d0: r2 = r9
0335d8: r2 &= r1
0335e0: if r2 == 0x4 goto +0x64 ; branch 0x33908
0335e8: r1 = r10
0335f0: r1 += -0x1b0
0335f8: r2 = r10
033600: r2 += -0x6c8
033608: r3 = 0x158
033610: call 0xcb0f ; call 0x98e90 / window 1246
033618: *(u32 *)(r10 - 0x334) = w9
033620: w1 = *(u32 *)(r10 - 0x528)
033628: *(u64 *)(r10 - 0x6f8) = r1
033630: w3 = *(u32 *)(r10 - 0x1b0)
033638: r1 = r10
033640: r1 += -0x1a8
033648: r8 = r10
033650: r8 += -0xe8
033658: r2 = r10
033660: r2 += -0xd0
033668: if r3 == 0x0 goto +0x3b ; branch 0x33848
033670: if r3 == 0x1 goto +0x3a ; branch 0x33848
033678: w1 = *(u32 *)(r10 - 0x1b0)
033680: r6 = r10
033688: r6 += -0x180
033690: if r1 == 0x0 goto +0x6 ; branch 0x336c8
033698: if r1 == 0x1 goto +0x5 ; branch 0x336c8
0336a0: if r1 == 0x4 goto +0x2 ; branch 0x336b8
0336a8: if r1 == 0x6 goto +0x1 ; branch 0x336b8
0336b0: goto +0x24 ; branch 0x337d8
0336b8: r6 = r10
0336c0: r6 += -0x1a8
0336c8: r2 = *(u64 *)(r6 + 0x8)
0336d0: if r2 == 0x0 goto +0x20 ; branch 0x337d8
0336d8: w1 = *(u8 *)(r10 - 0x337)
0336e0: if r1 == 0x0 goto +0x95 ; branch 0x33b90
0336e8: r1 = *(u64 *)(r10 - 0x728)
0336f0: r3 = *(u64 *)(r1 + 0x0)
0336f8: w1 = *(u8 *)(r1 + 0x28)
033700: r2 = 0x0
033708: *(u64 *)(r10 - 0x1000) = r2
033710: *(u64 *)(r10 - 0xff8) = r1
033718: r1 = r10
033720: r1 += -0x2b8
033728: r4 = r10
033730: r4 += -0x3e8
033738: r5 = r10
033740: r2 = r6
033748: call -0x4a31 ; call 0xe5c8 / window 262
033750: w7 = *(u32 *)(r10 - 0x2b8)
033758: if r7 == 0x16 goto +0x1 ; branch 0x33768
033760: goto +0xca ; branch 0x33db8
033768: r7 = r10
033770: r7 += -0x2b8
033778: r1 = r7
033780: r2 = r6
033788: call 0x61ca ; call 0x645e0 / window 521
033790: r6 = r10
033798: r6 += -0x3a0
0337a0: r1 = r6
0337a8: call -0x60e2 ; call 0x30a0 / window 59
0337b0: r1 = r6
0337b8: r2 = r7
0337c0: r3 = 0x68
0337c8: call 0xcad8 ; call 0x98e90 / window 1246
0337d0: w1 = *(u32 *)(r10 - 0x1b0)
0337d8: r4 = r1
0337e0: r2 = r10
0337e8: r2 += -0x117
0337f0: r3 = r10
0337f8: r3 += -0x118
033800: if r4 == 0x0 goto +0x7b ; branch 0x33be0
033808: if r4 == 0x1 goto +0x7a ; branch 0x33be0
033810: if r4 == 0x2 goto +0x75 ; branch 0x33bc0
033818: if r4 == 0x3 goto +0x2 ; branch 0x33830
033820: if r4 == 0x7 goto +0x1 ; branch 0x33830
033828: goto +0xc4 ; branch 0x33e50
033830: r2 = r10
033838: r2 += -0x1a8
033840: goto +0x91 ; branch 0x33cd0
033848: w3 = *(u8 *)(r10 - 0x1a8)
033850: if r3 == 0x0 goto +0x8 ; branch 0x33898
033858: r3 = *(u64 *)(r1 + 0x19)
033860: *(u64 *)(r6 + 0x18) = r3
033868: r3 = *(u64 *)(r1 + 0x11)
033870: *(u64 *)(r6 + 0x10) = r3
033878: r3 = *(u64 *)(r1 + 0x9)
033880: *(u64 *)(r6 + 0x8) = r3
033888: r1 = *(u64 *)(r1 + 0x1)
033890: *(u64 *)(r6 + 0x0) = r1
033898: w1 = *(u32 *)(r10 - 0xd0)
0338a0: r1 += -0x1
0338a8: r3 = 0x2
0338b0: if r3 > r1 goto +0x2d ; branch 0x33a20
0338b8: w1 = *(u32 *)(r10 - 0xe8)
0338c0: if r1 == 0x2 goto +0x1 ; branch 0x338d0
0338c8: goto -0x4b ; branch 0x33678
0338d0: w1 = *(u32 *)(r10 - 0x2f0)
0338d8: if r1 != 0x2 goto +0x59 ; branch 0x33ba8
0338e0: w1 = *(u32 *)(r8 + 0x8)
0338e8: r2 = *(u64 *)(r8 + 0x10)
0338f0: *(u64 *)(r10 - 0x2e8) = r2
0338f8: *(u32 *)(r10 - 0x2f0) = w1
033900: goto -0x52 ; branch 0x33678
033908: w1 = *(u32 *)(r10 - 0x2e0)
033910: if r1 != 0x0 goto -0x66 ; branch 0x335e8
033918: w1 = *(u8 *)(r10 - 0x2dc)
033920: if r1 == 0x0 goto -0x68 ; branch 0x335e8
033928: r3 = r10
033930: r3 += -0x2e0
033938: r1 = r10
033940: r1 += -0x1b0
033948: r2 = *(u64 *)(r10 - 0x738)
033950: call -0x478b ; call 0xfd00 / window 278
033958: w1 = *(u32 *)(r10 - 0x1b0)
033960: if r1 != 0x16 goto +0x3a ; branch 0x33b38
033968: goto -0x71 ; branch 0x335e8
033970: w2 = *(u32 *)(r10 - 0x1ac)
033978: r3 = *(u64 *)(r10 - 0x198)
033980: r4 = *(u64 *)(r10 - 0x6f0)
033988: *(u64 *)(r4 + 0x18) = r3
033990: r3 = *(u64 *)(r10 - 0x1a0)
033998: *(u64 *)(r4 + 0x10) = r3
0339a0: r3 = *(u64 *)(r10 - 0x1a8)
0339a8: *(u64 *)(r4 + 0x8) = r3
0339b0: *(u32 *)(r4 + 0x4) = w2
0339b8: goto -0xea ; branch 0x33270
0339c0: r2 = r7
0339c8: r2 <<= 0x20
0339d0: r2 >>= 0x20
0339d8: r4 = r2
0339e0: r4 += -0x1
0339e8: r9 = r7
0339f0: if r3 > r4 goto -0x87 ; branch 0x335c0
0339f8: r9 = r7
033a00: if r1 == r2 goto -0x89 ; branch 0x335c0
033a08: r1 = 0x8700000000 ll
033a18: goto -0x1cf ; branch 0x32ba8
033a20: r6 = r10
033a28: r6 += -0x2b8
033a30: r1 = r6
033a38: call 0x5500 ; call 0x5e240 / window 480
033a40: r7 = r10
033a48: r7 += -0x58
033a50: r1 = r7
033a58: r2 = r6
033a60: call -0x4673 ; call 0x106d0 / window 286
033a68: r1 = r10
033a70: r1 += -0x2b8
033a78: r6 = r10
033a80: r6 += -0x308
033a88: r2 = r7
033a90: r3 = r6
033a98: call -0x47a1 ; call 0xfd98 / window 279
033aa0: w7 = *(u32 *)(r10 - 0x2b8)
033aa8: if r7 != 0x16 goto +0x7 ; branch 0x33ae8
033ab0: r1 = *(u64 *)(r10 - 0x48)
033ab8: *(u64 *)(r6 + 0x10) = r1
033ac0: r1 = *(u64 *)(r10 - 0x50)
033ac8: *(u64 *)(r6 + 0x8) = r1
033ad0: r1 = *(u64 *)(r10 - 0x58)
033ad8: *(u64 *)(r6 + 0x0) = r1
033ae0: goto -0x46 ; branch 0x338b8
033ae8: w1 = *(u32 *)(r10 - 0x29c)
033af0: *(u32 *)(r10 - 0x414) = w1
033af8: r1 = *(u64 *)(r10 - 0x2a4)
033b00: *(u64 *)(r10 - 0x41c) = r1
033b08: r1 = *(u64 *)(r10 - 0x2ac)
033b10: *(u64 *)(r10 - 0x424) = r1
033b18: r1 = *(u64 *)(r10 - 0x2b4)
033b20: *(u64 *)(r10 - 0x42c) = r1
033b28: *(u32 *)(r10 - 0x430) = w7
033b30: goto +0xaf ; branch 0x340b0
033b38: w2 = *(u32 *)(r10 - 0x194)
033b40: r3 = *(u64 *)(r10 - 0x6f0)
033b48: *(u32 *)(r3 + 0x1c) = w2
033b50: r2 = *(u64 *)(r10 - 0x19c)
033b58: *(u64 *)(r3 + 0x14) = r2
033b60: r2 = *(u64 *)(r10 - 0x1a4)
033b68: *(u64 *)(r3 + 0xc) = r2
033b70: r2 = *(u64 *)(r10 - 0x1ac)
033b78: *(u64 *)(r3 + 0x4) = r2
033b80: *(u32 *)(r3 + 0x0) = w1
033b88: goto -0x123 ; branch 0x33278
033b90: r1 = 0x3b00000000 ll
033ba0: goto +0x9f ; branch 0x340a0
033ba8: r1 = 0x6600000000 ll
033bb8: goto +0x9c ; branch 0x340a0
033bc0: r2 = r10
033bc8: r2 += -0x186
033bd0: r3 = r10
033bd8: r3 += -0x187
033be0: w3 = *(u8 *)(r3 + 0x0)
033be8: if r3 == 0x2 goto +0x7 ; branch 0x33c28
033bf0: if r3 != 0x0 goto +0x5 ; branch 0x33c20
033bf8: w4 = *(u8 *)(r10 - 0x338)
033c00: if r4 != 0x1 goto +0x3 ; branch 0x33c20
033c08: r1 = 0x2a00000000 ll
033c18: goto +0x90 ; branch 0x340a0
033c20: *(u8 *)(r10 - 0x338) = w3
033c28: w2 = *(u8 *)(r2 + 0x0)
033c30: if r2 == 0x2 goto +0x7 ; branch 0x33c70
033c38: if r2 == 0x0 goto +0x5 ; branch 0x33c68
033c40: w3 = *(u8 *)(r10 - 0x337)
033c48: if r3 != 0x0 goto +0x3 ; branch 0x33c68
033c50: r1 = 0x4900000000 ll
033c60: goto +0x87 ; branch 0x340a0
033c68: *(u8 *)(r10 - 0x337) = w2
033c70: r2 = r1
033c78: if r2 == 0x0 goto +0x8 ; branch 0x33cc0
033c80: if r2 == 0x1 goto +0x7 ; branch 0x33cc0
033c88: if r2 == 0x2 goto +0x1 ; branch 0x33c98
033c90: goto +0x74 ; branch 0x34038
033c98: w1 = *(u8 *)(r10 - 0x1a8)
033ca0: if r1 == 0x0 goto +0x72 ; branch 0x34038
033ca8: r1 = 0xc100000000 ll
033cb8: goto +0x7c ; branch 0x340a0
033cc0: r2 = r10
033cc8: r2 += -0x114
033cd0: w3 = *(u32 *)(r2 + 0x0)
033cd8: if r3 == 0x0 goto +0x2e ; branch 0x33e50
033ce0: if r3 == 0x1 goto +0x23 ; branch 0x33e00
033ce8: r6 = r10
033cf0: r6 += -0x330
033cf8: r7 = r10
033d00: r7 += -0x2b8
033d08: r1 = r7
033d10: call 0x544a ; call 0x5df68 / window 478
033d18: r8 = r10
033d20: r8 += -0x58
033d28: r1 = r8
033d30: r2 = r7
033d38: call -0x46e9 ; call 0x105f8 / window 285
033d40: r1 = r10
033d48: r1 += -0x2b8
033d50: r2 = 0x0
033d58: r3 = r6
033d60: r4 = r8
033d68: call -0x4d74 ; call 0xd1d0 / window 254
033d70: w7 = *(u32 *)(r10 - 0x2b8)
033d78: if r7 != 0x16 goto +0x7 ; branch 0x33db8
033d80: r2 = r10
033d88: r2 += -0x58
033d90: r1 = r6
033d98: r3 = 0x21
033da0: call 0xca1d ; call 0x98e90 / window 1246
033da8: w1 = *(u32 *)(r10 - 0x1b0)
033db0: goto +0x13 ; branch 0x33e50
033db8: w1 = *(u32 *)(r10 - 0x29c)
033dc0: *(u32 *)(r10 - 0x414) = w1
033dc8: r1 = *(u64 *)(r10 - 0x2a4)
033dd0: *(u64 *)(r10 - 0x41c) = r1
033dd8: r1 = *(u64 *)(r10 - 0x2ac)
033de0: *(u64 *)(r10 - 0x424) = r1
033de8: r1 = *(u64 *)(r10 - 0x2b4)
033df0: *(u64 *)(r10 - 0x42c) = r1
033df8: goto +0x56 ; branch 0x340b0
033e00: w2 = *(u8 *)(r10 - 0x330)
033e08: r3 = r2
033e10: r3 &= 0x3
033e18: if r3 == 0x0 goto +0x4 ; branch 0x33e40
033e20: if r2 == 0x2 goto +0x5 ; branch 0x33e50
033e28: r1 = 0x7000000000 ll
033e38: goto +0x4c ; branch 0x340a0
033e40: r2 = 0x2
033e48: *(u8 *)(r10 - 0x330) = w2
033e50: r1 <<= 0x20
033e58: r1 >>= 0x20
033e60: if r1 == 0x0 goto +0x7 ; branch 0x33ea0
033e68: if r1 == 0x1 goto +0x6 ; branch 0x33ea0
033e70: if r1 == 0x5 goto +0x2 ; branch 0x33e88
033e78: if r1 == 0x8 goto +0x1 ; branch 0x33e88
033e80: goto +0x36 ; branch 0x34038
033e88: r2 = r10
033e90: r2 += -0x1a8
033e98: goto +0x2 ; branch 0x33eb0
033ea0: r2 = r10
033ea8: r2 += -0xb0
033eb0: w1 = *(u32 *)(r2 + 0x0)
033eb8: r1 += -0x1
033ec0: if r1 > 0x1 goto +0x2e ; branch 0x34038
033ec8: r9 &= -0x2
033ed0: r9 <<= 0x20
033ed8: r9 >>= 0x20
033ee0: if r9 != 0x4 goto +0x8 ; branch 0x33f28
033ee8: r1 = *(u64 *)(r10 - 0x6f8)
033ef0: if r1 == 0x0 goto +0x9 ; branch 0x33f40
033ef8: r1 = *(u64 *)(r10 - 0x6f8)
033f00: if r1 == 0x2 goto +0x1 ; branch 0x33f10
033f08: goto +0x30 ; branch 0x34090
033f10: r1 = 0x9400000000 ll
033f20: goto +0x2f ; branch 0x340a0
033f28: r1 = 0x8700000000 ll
033f38: goto +0x2c ; branch 0x340a0
033f40: r6 = r10
033f48: r6 += -0x2b8
033f50: r1 = r6
033f58: call 0x5508 ; call 0x5e7a0 / window 483
033f60: r1 = r10
033f68: r1 += -0x58
033f70: r2 = r6
033f78: call -0x46f8 ; call 0x107c0 / window 287
033f80: r1 = 0x1
033f88: w3 = *(u8 *)(r10 - 0x58)
033f90: r2 = 0x1
033f98: if r3 == 0x0 goto +0x9 ; branch 0x33fe8
033fa0: r2 = *(u64 *)(r10 - 0x3f)
033fa8: *(u64 *)(r10 - 0x2a0) = r2
033fb0: r2 = *(u64 *)(r10 - 0x47)
033fb8: *(u64 *)(r10 - 0x2a8) = r2
033fc0: r2 = *(u64 *)(r10 - 0x4f)
033fc8: *(u64 *)(r10 - 0x2b0) = r2
033fd0: r2 = *(u64 *)(r10 - 0x57)
033fd8: *(u64 *)(r10 - 0x2b8) = r2
033fe0: r2 = 0x0
033fe8: *(u8 *)(r10 - 0x2dc) = w1
033ff0: *(u32 *)(r10 - 0x2e0) = w2
033ff8: r1 = *(u64 *)(r10 - 0x2b8)
034000: *(u64 *)(r10 - 0x2db) = r1
034008: r1 = *(u64 *)(r10 - 0x2b0)
034010: *(u64 *)(r10 - 0x2d3) = r1
034018: r1 = *(u64 *)(r10 - 0x2a8)
034020: *(u64 *)(r10 - 0x2cb) = r1
034028: r1 = *(u64 *)(r10 - 0x2a0)
034030: *(u64 *)(r10 - 0x2c3) = r1
034038: r6 = r10
034040: r6 += -0x3e8
034048: r1 = r6
034050: call 0x4501 ; call 0x56860 / window 456
034058: r1 = r10
034060: r1 += -0x430
034068: r2 = r6
034070: r3 = *(u64 *)(r10 - 0x718)
034078: call 0x38bf ; call 0x50678 / window 440
034080: w7 = *(u32 *)(r10 - 0x430)
034088: goto +0x4 ; branch 0x340b0
034090: r1 = 0xad00000000 ll
0340a0: *(u64 *)(r10 - 0x430) = r1
0340a8: r7 = 0x0
0340b0: r1 = r10
0340b8: r1 += -0x1b0
0340c0: call -0x61a7 ; call 0x3390 / window 68
0340c8: r1 = r7
0340d0: r1 <<= 0x20
0340d8: r1 >>= 0x20
0340e0: if r1 == 0x16 goto +0x1 ; branch 0x340f0
0340e8: goto +0x4 ; branch 0x34110
0340f0: r1 = 0x16
0340f8: r2 = *(u64 *)(r10 - 0x6f0)
034100: *(u32 *)(r2 + 0x0) = w1
034108: goto +0xa ; branch 0x34160
034110: w1 = *(u32 *)(r10 - 0x414)
034118: r2 = *(u64 *)(r10 - 0x6f0)
034120: *(u32 *)(r2 + 0x1c) = w1
034128: r1 = *(u64 *)(r10 - 0x41c)
034130: *(u64 *)(r2 + 0x14) = r1
034138: r1 = *(u64 *)(r10 - 0x424)
034140: *(u64 *)(r2 + 0xc) = r1
034148: r1 = *(u64 *)(r10 - 0x42c)
034150: *(u64 *)(r2 + 0x4) = r1
034158: *(u32 *)(r2 + 0x0) = w7
034160: r1 = r10
034168: r1 += -0x3a0
034170: call -0x621b ; call 0x30a0 / window 59
034178: goto -0x385 ; branch 0x32558
