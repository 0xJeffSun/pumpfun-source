00fc48: r7 = r4
00fc50: r8 = r3
00fc58: r6 = r1
00fc60: r7 <<= 0x5
00fc68: r9 = *(u64 *)(r2 + 0x18)
00fc70: if r7 == 0x0 goto +0xa ; branch 0xfcc8
00fc78: r1 = r8
00fc80: r2 = r9
00fc88: call 0xcd4d ; call 0x766f8 / window 774
00fc90: r7 += -0x20
00fc98: r8 += 0x20
00fca0: if r0 != 0x0 goto +0x1 ; branch 0xfcb0
00fca8: goto -0x8 ; branch 0xfc70
00fcb0: r1 = 0x16
00fcb8: *(u32 *)(r6 + 0x0) = w1
00fcc0: goto +0x3 ; branch 0xfce0
00fcc8: r1 = 0x3900000000 ll
00fcd8: *(u64 *)(r6 + 0x0) = r1
00fce0: exit
