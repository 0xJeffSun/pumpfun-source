02c6c0: r7 = r5
02c6c8: *(u64 *)(r10 - 0x4e0) = r4
02c6d0: r6 = r1
02c6d8: r1 = *(u64 *)(r2 + 0x88)
02c6e0: *(u64 *)(r10 - 0x4d8) = r1
02c6e8: r1 = *(u64 *)(r2 + 0x80)
02c6f0: *(u64 *)(r10 - 0x4c0) = r1
02c6f8: r1 = *(u64 *)(r2 + 0x78)
02c700: *(u64 *)(r10 - 0x4b0) = r1
02c708: r1 = *(u64 *)(r2 + 0x70)
02c710: *(u64 *)(r10 - 0x488) = r1
02c718: r1 = *(u64 *)(r2 + 0x68)
02c720: *(u64 *)(r10 - 0x4c8) = r1
02c728: r9 = *(u64 *)(r2 + 0x60)
02c730: r1 = *(u64 *)(r2 + 0x58)
02c738: *(u64 *)(r10 - 0x500) = r1
02c740: r1 = *(u64 *)(r2 + 0x50)
02c748: *(u64 *)(r10 - 0x4f8) = r1
02c750: r1 = *(u64 *)(r2 + 0x40)
02c758: *(u64 *)(r10 - 0x4f0) = r1
02c760: r1 = *(u64 *)(r2 + 0x38)
02c768: *(u64 *)(r10 - 0x4e8) = r1
02c770: r1 = *(u64 *)(r2 + 0x0)
02c778: *(u64 *)(r10 - 0x4d0) = r1
02c780: r1 = *(u64 *)(r2 + 0x30)
02c788: *(u64 *)(r10 - 0x498) = r1
02c790: r1 = *(u64 *)(r2 + 0x28)
02c798: *(u64 *)(r10 - 0x4a0) = r1
02c7a0: r1 = *(u64 *)(r2 + 0x20)
02c7a8: *(u64 *)(r10 - 0x4a8) = r1
02c7b0: r1 = *(u64 *)(r2 + 0x18)
02c7b8: *(u64 *)(r10 - 0x480) = r1
02c7c0: r1 = *(u64 *)(r2 + 0x10)
02c7c8: *(u64 *)(r10 - 0x4b8) = r1
02c7d0: r3 = *(u64 *)(r2 + 0x48)
02c7d8: r8 = *(u64 *)(r2 + 0x8)
02c7e0: r1 = r10
02c7e8: r1 += -0x230
02c7f0: *(u64 *)(r10 - 0x490) = r3
02c7f8: r2 = r3
02c800: r3 = r8
02c808: call 0x3892 ; call 0x48ca0 / window 427
02c810: w1 = *(u32 *)(r10 - 0x230)
02c818: if r1 != 0x16 goto +0x17 ; branch 0x2c8d8
02c820: *(u64 *)(r10 - 0x508) = r8
02c828: r1 = *(u64 *)(r7 - 0xff8)
02c830: *(u64 *)(r10 - 0x510) = r1
02c838: r7 = *(u64 *)(r7 - 0x1000)
02c840: r1 = r10
02c848: r1 += -0x230
02c850: r2 = r9
02c858: call 0x36cb ; call 0x47eb8 / window 419
02c860: w8 = *(u32 *)(r10 - 0x128)
02c868: if r8 != 0x2 goto +0x1b ; branch 0x2c948
02c870: r1 = *(u64 *)(r10 - 0x218)
02c878: *(u64 *)(r10 - 0x320) = r1
02c880: r2 = *(u64 *)(r10 - 0x220)
02c888: *(u64 *)(r10 - 0x328) = r2
02c890: r3 = *(u64 *)(r10 - 0x228)
02c898: *(u64 *)(r10 - 0x330) = r3
02c8a0: r4 = *(u64 *)(r10 - 0x230)
02c8a8: *(u64 *)(r10 - 0x338) = r4
02c8b0: *(u64 *)(r6 + 0x18) = r1
02c8b8: *(u64 *)(r6 + 0x10) = r2
02c8c0: *(u64 *)(r6 + 0x8) = r3
02c8c8: *(u64 *)(r6 + 0x0) = r4
02c8d0: goto +0x16d ; branch 0x2d440
02c8d8: w2 = *(u32 *)(r10 - 0x214)
02c8e0: *(u32 *)(r10 - 0x450) = w2
02c8e8: r3 = *(u64 *)(r10 - 0x21c)
02c8f0: *(u64 *)(r10 - 0x458) = r3
02c8f8: r4 = *(u64 *)(r10 - 0x224)
02c900: *(u64 *)(r10 - 0x460) = r4
02c908: r5 = *(u64 *)(r10 - 0x22c)
02c910: *(u64 *)(r10 - 0x468) = r5
02c918: *(u32 *)(r6 + 0x1c) = w2
02c920: *(u64 *)(r6 + 0x14) = r3
02c928: *(u64 *)(r6 + 0xc) = r4
02c930: *(u64 *)(r6 + 0x4) = r5
02c938: *(u32 *)(r6 + 0x0) = w1
02c940: goto +0x15f ; branch 0x2d440
02c948: *(u64 *)(r10 - 0x518) = r7
02c950: *(u64 *)(r10 - 0x520) = r9
02c958: r7 = r10
02c960: r7 += -0x338
02c968: r2 = r10
02c970: r2 += -0x230
02c978: r1 = r7
02c980: r3 = 0x108
02c988: call 0xd8a0 ; call 0x98e90 / window 1246
02c990: r1 = r10
02c998: r1 += -0x35c
02c9a0: r2 = r10
02c9a8: r2 += -0x124
02c9b0: r3 = 0x24
02c9b8: call 0xd89a ; call 0x98e90 / window 1246
02c9c0: r1 = r10
02c9c8: r1 += -0x468
02c9d0: r2 = r7
02c9d8: r3 = 0x108
02c9e0: call 0xd895 ; call 0x98e90 / window 1246
02c9e8: *(u32 *)(r10 - 0x360) = w8
02c9f0: r9 = 0x0
02c9f8: w7 = *(u32 *)(r10 - 0x3b4)
02ca00: if r7 == 0x6 goto +0x1 ; branch 0x2ca10
02ca08: r9 = r7
02ca10: r8 = *(u64 *)(r10 - 0x480)
02ca18: r1 = r8
02ca20: call 0xb0d6 ; call 0x850d8 / window 981
02ca28: r3 = *(u64 *)(r10 - 0x508)
02ca30: if r0 != 0x0 goto +0x11 ; branch 0x2cac0
02ca38: r1 = r10
02ca40: r1 += -0x230
02ca48: r2 = r8
02ca50: r4 = r9
02ca58: call 0x5041 ; call 0x54c68 / window 449
02ca60: w1 = *(u32 *)(r10 - 0x230)
02ca68: if r1 == 0x2 goto +0x1 ; branch 0x2ca78
02ca70: goto +0x27 ; branch 0x2cbb0
02ca78: r1 = *(u64 *)(r10 - 0x210)
02ca80: *(u64 *)(r10 - 0x31c) = r1
02ca88: r2 = *(u64 *)(r10 - 0x218)
02ca90: *(u64 *)(r10 - 0x324) = r2
02ca98: r3 = *(u64 *)(r10 - 0x220)
02caa0: *(u64 *)(r10 - 0x32c) = r3
02caa8: r4 = *(u64 *)(r10 - 0x228)
02cab0: *(u64 *)(r10 - 0x334) = r4
02cab8: goto +0x4c ; branch 0x2cd20
02cac0: w1 = *(u8 *)(r8 + 0x28)
02cac8: if r1 == 0x0 goto +0x31 ; branch 0x2cc58
02cad0: r1 = 0x0
02cad8: *(u64 *)(r10 - 0xff0) = r1
02cae0: r1 = *(u64 *)(r10 - 0x488)
02cae8: *(u64 *)(r10 - 0xfe0) = r1
02caf0: *(u64 *)(r10 - 0xff8) = r9
02caf8: r1 = *(u64 *)(r10 - 0x490)
02cb00: *(u64 *)(r10 - 0x1000) = r1
02cb08: r1 = r10
02cb10: r1 += -0x230
02cb18: r5 = r10
02cb20: r2 = r8
02cb28: r4 = *(u64 *)(r10 - 0x498)
02cb30: call 0x4e30 ; call 0x53cb8 / window 448
02cb38: w1 = *(u32 *)(r10 - 0x230)
02cb40: if r1 == 0x16 goto +0x11 ; branch 0x2cbd0
02cb48: w2 = *(u32 *)(r10 - 0x214)
02cb50: *(u32 *)(r10 - 0x320) = w2
02cb58: r3 = *(u64 *)(r10 - 0x21c)
02cb60: *(u64 *)(r10 - 0x328) = r3
02cb68: r4 = *(u64 *)(r10 - 0x224)
02cb70: *(u64 *)(r10 - 0x330) = r4
02cb78: r5 = *(u64 *)(r10 - 0x22c)
02cb80: *(u64 *)(r10 - 0x338) = r5
02cb88: *(u32 *)(r6 + 0x1c) = w2
02cb90: *(u64 *)(r6 + 0x14) = r3
02cb98: *(u64 *)(r6 + 0xc) = r4
02cba0: *(u64 *)(r6 + 0x4) = r5
02cba8: goto +0x12a ; branch 0x2d500
02cbb0: w1 = *(u8 *)(r10 - 0x200)
02cbb8: if r1 != 0x0 goto +0x31 ; branch 0x2cd48
02cbc0: r1 = *(u64 *)(r10 - 0x208)
02cbc8: if r1 > 0x1 goto +0x2f ; branch 0x2cd48
02cbd0: r8 = *(u64 *)(r10 - 0x4a0)
02cbd8: r1 = r8
02cbe0: call 0xb09e ; call 0x850d8 / window 981
02cbe8: if r0 != 0x0 goto +0x1 ; branch 0x2cbf8
02cbf0: goto +0xf ; branch 0x2cc70
02cbf8: r1 = r10
02cc00: r1 += -0x230
02cc08: r8 = *(u64 *)(r10 - 0x480)
02cc10: r2 = r8
02cc18: call 0x9576 ; call 0x777d0 / window 781
02cc20: w1 = *(u32 *)(r10 - 0x230)
02cc28: if r1 != 0x16 goto +0x27 ; branch 0x2cd68
02cc30: r1 = *(u64 *)(r10 - 0x228)
02cc38: if r1 == 0x0 goto +0x30 ; branch 0x2cdc0
02cc40: r1 = 0xa000000000 ll
02cc50: goto +0x20 ; branch 0x2cd58
02cc58: r1 = 0x8600000000 ll
02cc68: goto +0x1d ; branch 0x2cd58
02cc70: *(u64 *)(r10 - 0xff8) = r9
02cc78: r1 = 0x1
02cc80: *(u64 *)(r10 - 0xff0) = r1
02cc88: r1 = *(u64 *)(r10 - 0x488)
02cc90: *(u64 *)(r10 - 0x1000) = r1
02cc98: r1 = r10
02cca0: r1 += -0x230
02cca8: r5 = r10
02ccb0: r2 = *(u64 *)(r10 - 0x480)
02ccb8: r3 = r8
02ccc0: r4 = *(u64 *)(r10 - 0x4a8)
02ccc8: call 0x511c ; call 0x555b0 / window 450
02ccd0: w1 = *(u32 *)(r10 - 0x1e8)
02ccd8: if r1 != 0x2 goto +0xed ; branch 0x2d448
02cce0: r1 = *(u64 *)(r10 - 0x218)
02cce8: *(u64 *)(r10 - 0x320) = r1
02ccf0: r2 = *(u64 *)(r10 - 0x220)
02ccf8: *(u64 *)(r10 - 0x328) = r2
02cd00: r3 = *(u64 *)(r10 - 0x228)
02cd08: *(u64 *)(r10 - 0x330) = r3
02cd10: r4 = *(u64 *)(r10 - 0x230)
02cd18: *(u64 *)(r10 - 0x338) = r4
02cd20: *(u64 *)(r6 + 0x18) = r1
02cd28: *(u64 *)(r6 + 0x10) = r2
02cd30: *(u64 *)(r6 + 0x8) = r3
02cd38: *(u64 *)(r6 + 0x0) = r4
02cd40: goto +0xdc ; branch 0x2d428
02cd48: r1 = 0x8800000000 ll
02cd58: *(u64 *)(r6 + 0x0) = r1
02cd60: goto +0xd8 ; branch 0x2d428
02cd68: r2 = *(u64 *)(r10 - 0x220)
02cd70: *(u64 *)(r10 - 0x338) = r2
02cd78: r3 = *(u64 *)(r10 - 0x218)
02cd80: *(u64 *)(r10 - 0x330) = r3
02cd88: w4 = *(u32 *)(r10 - 0x22c)
02cd90: r5 = *(u64 *)(r10 - 0x228)
02cd98: *(u64 *)(r6 + 0x18) = r3
02cda0: *(u64 *)(r6 + 0x10) = r2
02cda8: *(u64 *)(r6 + 0x8) = r5
02cdb0: *(u32 *)(r6 + 0x4) = w4
02cdb8: goto +0xe8 ; branch 0x2d500
02cdc0: r1 = *(u64 *)(r10 - 0x488)
02cdc8: r5 = *(u64 *)(r1 + 0x0)
02cdd0: r4 = *(u64 *)(r8 + 0x0)
02cdd8: r1 = *(u64 *)(r10 - 0x4a8)
02cde0: r3 = *(u64 *)(r1 + 0x0)
02cde8: r7 = *(u64 *)(r10 - 0x490)
02cdf0: r2 = *(u64 *)(r7 + 0x0)
02cdf8: r1 = r10
02ce00: r1 += -0x338
02ce08: *(u64 *)(r10 - 0x528) = r1
02ce10: call 0x7b32 ; call 0x6a7a8 / window 591
02ce18: r1 = r10
02ce20: r1 += -0x100
02ce28: *(u64 *)(r10 - 0x538) = r1
02ce30: r2 = r7
02ce38: call -0x44cd ; call 0xa7d8 / window 217
02ce40: r7 = r10
02ce48: r7 += -0x90
02ce50: r1 = r7
02ce58: r2 = *(u64 *)(r10 - 0x4a8)
02ce60: call -0x44d2 ; call 0xa7d8 / window 217
02ce68: r1 = r10
02ce70: r1 += -0x60
02ce78: *(u64 *)(r10 - 0x530) = r1
02ce80: r2 = r8
02ce88: call -0x44d7 ; call 0xa7d8 / window 217
02ce90: r1 = r10
02ce98: r1 += -0x30
02cea0: *(u64 *)(r10 - 0x4a8) = r1
02cea8: r2 = *(u64 *)(r10 - 0x4a0)
02ceb0: call -0x44dc ; call 0xa7d8 / window 217
02ceb8: r8 = r10
02cec0: r8 += -0x230
02cec8: r1 = r8
02ced0: r2 = *(u64 *)(r10 - 0x538)
02ced8: r3 = 0x30
02cee0: call 0xd7f5 ; call 0x98e90 / window 1246
02cee8: r1 = r10
02cef0: r1 += -0x200
02cef8: r2 = r7
02cf00: r3 = 0x30
02cf08: call 0xd7f0 ; call 0x98e90 / window 1246
02cf10: r1 = r10
02cf18: r1 += -0x1d0
02cf20: r2 = *(u64 *)(r10 - 0x530)
02cf28: r3 = 0x30
02cf30: call 0xd7eb ; call 0x98e90 / window 1246
02cf38: r1 = r10
02cf40: r1 += -0x1a0
02cf48: r2 = *(u64 *)(r10 - 0x4a8)
02cf50: r3 = 0x30
02cf58: call 0xd7e6 ; call 0x98e90 / window 1246
02cf60: r1 = r10
02cf68: r1 += -0xb0
02cf70: r2 = *(u64 *)(r10 - 0x528)
02cf78: r3 = r8
02cf80: r4 = 0x4
02cf88: call 0xb281 ; call 0x86398 / window 996
02cf90: w1 = *(u32 *)(r10 - 0xb0)
02cf98: if r1 == 0x16 goto +0x1 ; branch 0x2cfa8
02cfa0: goto +0x25 ; branch 0x2d0d0
02cfa8: r1 = r10
02cfb0: r1 += -0x230
02cfb8: call -0x5329 ; call 0x3678 / window 77
02cfc0: r1 = r10
02cfc8: r1 += -0x338
02cfd0: call -0x53d6 ; call 0x3128 / window 61
02cfd8: r8 = *(u64 *)(r10 - 0x4a0)
02cfe0: r4 = *(u64 *)(r8 + 0x0)
02cfe8: r1 = *(u64 *)(r10 - 0x480)
02cff0: r3 = *(u64 *)(r1 + 0x0)
02cff8: r1 = *(u64 *)(r10 - 0x488)
02d000: r2 = *(u64 *)(r1 + 0x0)
02d008: r1 = *(u64 *)(r10 - 0x498)
02d010: r1 = *(u64 *)(r1 + 0x0)
02d018: r5 = 0x0
02d020: *(u64 *)(r10 - 0xff0) = r5
02d028: r5 = 0x1
02d030: *(u64 *)(r10 - 0xfe8) = r5
02d038: r5 = 0x995a8 ll ; data b'Error: BuiltinProgramsMustConsumeComputeUnitsError: MaxInstructionTraceLengthExceededError: InvalidR'
02d048: *(u64 *)(r10 - 0xff8) = r5
02d050: *(u64 *)(r10 - 0x1000) = r1
02d058: r1 = r10
02d060: r1 += -0x230
02d068: r5 = r10
02d070: call 0xa3e3 ; call 0x7ef90 / window 864
02d078: r7 = *(u64 *)(r10 - 0x208)
02d080: if r7 != 0x0 goto +0x1a ; branch 0x2d158
02d088: r1 = *(u64 *)(r10 - 0x218)
02d090: *(u64 *)(r10 - 0xe8) = r1
02d098: r2 = *(u64 *)(r10 - 0x220)
02d0a0: *(u64 *)(r10 - 0xf0) = r2
02d0a8: r3 = *(u64 *)(r10 - 0x228)
02d0b0: *(u64 *)(r10 - 0xf8) = r3
02d0b8: r4 = *(u64 *)(r10 - 0x230)
02d0c0: *(u64 *)(r10 - 0x100) = r4
02d0c8: goto -0x76 ; branch 0x2cd20
02d0d0: w2 = *(u32 *)(r10 - 0x94)
02d0d8: *(u32 *)(r10 - 0xb8) = w2
02d0e0: r3 = *(u64 *)(r10 - 0x9c)
02d0e8: *(u64 *)(r10 - 0xc0) = r3
02d0f0: r4 = *(u64 *)(r10 - 0xa4)
02d0f8: *(u64 *)(r10 - 0xc8) = r4
02d100: r5 = *(u64 *)(r10 - 0xac)
02d108: *(u64 *)(r10 - 0xd0) = r5
02d110: *(u32 *)(r6 + 0x1c) = w2
02d118: *(u64 *)(r6 + 0x14) = r3
02d120: *(u64 *)(r6 + 0xc) = r4
02d128: *(u64 *)(r6 + 0x4) = r5
02d130: *(u32 *)(r6 + 0x0) = w1
02d138: r1 = r10
02d140: r1 += -0x230
02d148: call -0x535b ; call 0x3678 / window 77
02d150: goto +0x57 ; branch 0x2d410
02d158: r8 = r10
02d160: r8 += -0x100
02d168: r2 = r10
02d170: r2 += -0x230
02d178: r1 = r8
02d180: r3 = 0x28
02d188: call 0xd7a0 ; call 0x98e90 / window 1246
02d190: r1 = *(u64 *)(r10 - 0x200)
02d198: *(u64 *)(r10 - 0x308) = r1
02d1a0: r1 = *(u64 *)(r10 - 0x1f8)
02d1a8: *(u64 *)(r10 - 0x300) = r1
02d1b0: r1 = *(u64 *)(r10 - 0x1f0)
02d1b8: *(u64 *)(r10 - 0x2f8) = r1
02d1c0: r1 = *(u64 *)(r10 - 0x1e8)
02d1c8: *(u64 *)(r10 - 0x2f0) = r1
02d1d0: r1 = r10
02d1d8: r1 += -0x338
02d1e0: *(u64 *)(r10 - 0x4a8) = r1
02d1e8: r2 = r8
02d1f0: r3 = 0x28
02d1f8: call 0xd792 ; call 0x98e90 / window 1246
02d200: *(u64 *)(r10 - 0x310) = r7
02d208: r8 = r10
02d210: r8 += -0x90
02d218: r1 = r8
02d220: r2 = *(u64 *)(r10 - 0x480)
02d228: call -0x454b ; call 0xa7d8 / window 217
02d230: r7 = r10
02d238: r7 += -0x60
02d240: r1 = r7
02d248: r2 = *(u64 *)(r10 - 0x4a0)
02d250: call -0x4550 ; call 0xa7d8 / window 217
02d258: r1 = r10
02d260: r1 += -0x30
02d268: *(u64 *)(r10 - 0x530) = r1
02d270: r2 = *(u64 *)(r10 - 0x498)
02d278: call -0x4555 ; call 0xa7d8 / window 217
02d280: r1 = r10
02d288: r1 += -0x230
02d290: *(u64 *)(r10 - 0x528) = r1
02d298: r2 = r8
02d2a0: r3 = 0x30
02d2a8: call 0xd77c ; call 0x98e90 / window 1246
02d2b0: r1 = r10
02d2b8: r1 += -0x200
02d2c0: r2 = r7
02d2c8: r3 = 0x30
02d2d0: call 0xd777 ; call 0x98e90 / window 1246
02d2d8: r1 = r10
02d2e0: r1 += -0x1d0
02d2e8: r2 = *(u64 *)(r10 - 0x530)
02d2f0: r3 = 0x30
02d2f8: call 0xd772 ; call 0x98e90 / window 1246
02d300: r1 = r10
02d308: r1 += -0xb0
02d310: r2 = *(u64 *)(r10 - 0x4a8)
02d318: r3 = *(u64 *)(r10 - 0x528)
02d320: r4 = 0x3
02d328: call 0xb20d ; call 0x86398 / window 996
02d330: w1 = *(u32 *)(r10 - 0xb0)
02d338: if r1 == 0x16 goto +0x1 ; branch 0x2d348
02d340: goto +0x9 ; branch 0x2d390
02d348: r1 = r10
02d350: r1 += -0x230
02d358: call -0x53a6 ; call 0x3630 / window 76
02d360: r1 = r10
02d368: r1 += -0x338
02d370: call -0x544a ; call 0x3128 / window 61
02d378: r1 = *(u64 *)(r10 - 0x508)
02d380: r8 = *(u64 *)(r10 - 0x480)
02d388: goto +0x27 ; branch 0x2d4c8
02d390: w2 = *(u32 *)(r10 - 0x94)
02d398: *(u32 *)(r10 - 0xb8) = w2
02d3a0: r3 = *(u64 *)(r10 - 0x9c)
02d3a8: *(u64 *)(r10 - 0xc0) = r3
02d3b0: r4 = *(u64 *)(r10 - 0xa4)
02d3b8: *(u64 *)(r10 - 0xc8) = r4
02d3c0: r5 = *(u64 *)(r10 - 0xac)
02d3c8: *(u64 *)(r10 - 0xd0) = r5
02d3d0: *(u32 *)(r6 + 0x1c) = w2
02d3d8: *(u64 *)(r6 + 0x14) = r3
02d3e0: *(u64 *)(r6 + 0xc) = r4
02d3e8: *(u64 *)(r6 + 0x4) = r5
02d3f0: *(u32 *)(r6 + 0x0) = w1
02d3f8: r1 = r10
02d400: r1 += -0x230
02d408: call -0x53bc ; call 0x3630 / window 76
02d410: r1 = r10
02d418: r1 += -0x338
02d420: call -0x5460 ; call 0x3128 / window 61
02d428: r1 = r10
02d430: r1 += -0x420
02d438: call -0x5474 ; call 0x30a0 / window 59
02d440: exit
02d448: r1 = *(u64 *)(r10 - 0x1a4)
02d450: *(u64 *)(r10 - 0x30) = r1
02d458: r1 = *(u64 *)(r10 - 0x19c)
02d460: *(u64 *)(r10 - 0x28) = r1
02d468: r1 = *(u64 *)(r10 - 0x194)
02d470: *(u64 *)(r10 - 0x20) = r1
02d478: r1 = *(u64 *)(r10 - 0x18c)
02d480: *(u64 *)(r10 - 0x18) = r1
02d488: r8 = *(u64 *)(r10 - 0x480)
02d490: if r7 == 0x6 goto +0x6 ; branch 0x2d4c8
02d498: r1 = 0xfffffffe ll
02d4a8: r7 &= r1
02d4b0: if r7 != 0x4 goto +0x2 ; branch 0x2d4c8
02d4b8: w1 = *(u32 *)(r10 - 0x1a8)
02d4c0: if r1 == 0x1 goto +0x4e ; branch 0x2d738
02d4c8: r1 = *(u64 *)(r10 - 0x4b0)
02d4d0: r2 = 0x9eef8 ll ; data b'\x00\x00\x00\x00X\x98\t\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00]\x00\x00\x009\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00u\x00\x00\x00D\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00\x81\x00\x00\x00F\x00\x00\x00\x00\x00\x00\x00\xdf\xa5\t\x00,\x00\x00\x00\x00\x00\x00\x00\x96\x00\x00\x00'
02d4e0: call -0x5502 ; call 0x2cd8 / window 42
02d4e8: if r0 != 0x0 goto +0x1 ; branch 0x2d4f8
02d4f0: goto +0x3 ; branch 0x2d510
02d4f8: r1 = 0x6
02d500: *(u32 *)(r6 + 0x0) = w1
02d508: goto -0x1d ; branch 0x2d428
02d510: r1 = *(u64 *)(r10 - 0x4c0)
02d518: r2 = 0x9ec60 ll ; data b'\x00\x00\x00\x00\xb8\x99\t\x00\x00\x00\x00\x00\x08\xa3\t\x00"\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00M\x00\x00\x00\x00\x00\x00\x008\x99\t\x00\x00\x00\x00\x00*\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x003\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00P\xa3\t\x00&\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00A\x00\x00\x00\x00\x00\x00\x00v\xa3\t\x00)\x00\x00\x00'
02d528: call -0x550b ; call 0x2cd8 / window 42
02d530: if r0 != 0x0 goto -0x8 ; branch 0x2d4f8
02d538: r2 = r9
02d540: r2 <<= 0x20
02d548: r2 >>= 0x20
02d550: r3 = *(u64 *)(r10 - 0x4b8)
02d558: r7 = *(u64 *)(r10 - 0x4c8)
02d560: if r2 == 0x0 goto +0x2e ; branch 0x2d6d8
02d568: if r2 == 0x4 goto +0x1 ; branch 0x2d578
02d570: goto +0x4a ; branch 0x2d7c8
02d578: r7 = *(u64 *)(r10 - 0x4d0)
02d580: if r7 == 0x0 goto +0xae ; branch 0x2daf8
02d588: r1 = *(u64 *)(r10 - 0x4a0)
02d590: r3 = *(u64 *)(r1 + 0x0)
02d598: r2 = *(u64 *)(r8 + 0x0)
02d5a0: r1 = r10
02d5a8: r1 += -0x230
02d5b0: call -0x3880 ; call 0x111b8 / window 294
02d5b8: r1 = *(u64 *)(r10 - 0x218)
02d5c0: *(u64 *)(r10 - 0x320) = r1
02d5c8: r1 = *(u64 *)(r10 - 0x220)
02d5d0: *(u64 *)(r10 - 0x328) = r1
02d5d8: r1 = *(u64 *)(r10 - 0x228)
02d5e0: *(u64 *)(r10 - 0x330) = r1
02d5e8: r1 = *(u64 *)(r10 - 0x230)
02d5f0: *(u64 *)(r10 - 0x338) = r1
02d5f8: r2 = *(u64 *)(r7 + 0x0)
02d600: r1 = r10
02d608: r1 += -0x338
02d610: call 0x91fb ; call 0x765f0 / window 774
02d618: if r0 != 0x0 goto +0x1 ; branch 0x2d628
02d620: goto +0x9d ; branch 0x2db10
02d628: r1 = r7
02d630: call 0xaf54 ; call 0x850d8 / window 981
02d638: if r0 != 0x0 goto +0x1 ; branch 0x2d648
02d640: goto +0xa4 ; branch 0x2db68
02d648: r1 = *(u64 *)(r10 - 0x490)
02d650: *(u64 *)(r10 - 0xff8) = r1
02d658: r1 = *(u64 *)(r10 - 0x4d8)
02d660: *(u64 *)(r10 - 0xff0) = r1
02d668: r1 = *(u64 *)(r10 - 0x4a0)
02d670: *(u64 *)(r10 - 0x1000) = r1
02d678: r1 = r10
02d680: r1 += -0x230
02d688: r5 = r10
02d690: r2 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02d6a0: r3 = r7
02d6a8: r4 = r8
02d6b0: call 0x4634 ; call 0x50858 / window 441
02d6b8: w1 = *(u32 *)(r10 - 0x230)
02d6c0: if r1 != 0x16 goto +0x9c ; branch 0x2dba8
02d6c8: r7 = *(u64 *)(r10 - 0x4c8)
02d6d0: r3 = *(u64 *)(r10 - 0x4b8)
02d6d8: r2 = r10
02d6e0: r2 += -0x464
02d6e8: *(u64 *)(r10 - 0x230) = r2
02d6f0: r2 = r10
02d6f8: r2 += -0x230
02d700: r1 = r7
02d708: call -0x5547 ; call 0x2cd8 / window 42
02d710: if r0 != 0x0 goto +0x1 ; branch 0x2d720
02d718: goto +0x18 ; branch 0x2d7e0
02d720: r1 = 0x700000000 ll
02d730: goto -0x13c ; branch 0x2cd58
02d738: r1 = *(u64 *)(r10 - 0x18)
02d740: *(u64 *)(r10 - 0x218) = r1
02d748: r1 = *(u64 *)(r10 - 0x20)
02d750: *(u64 *)(r10 - 0x220) = r1
02d758: r1 = *(u64 *)(r10 - 0x28)
02d760: *(u64 *)(r10 - 0x228) = r1
02d768: r1 = *(u64 *)(r10 - 0x30)
02d770: *(u64 *)(r10 - 0x230) = r1
02d778: r1 = *(u64 *)(r10 - 0x4b8)
02d780: r2 = *(u64 *)(r1 + 0x0)
02d788: r1 = r10
02d790: r1 += -0x230
02d798: call -0x5552 ; call 0x2d10 / window 44
02d7a0: if r0 != 0x0 goto +0x1 ; branch 0x2d7b0
02d7a8: goto -0x5d ; branch 0x2d4c8
02d7b0: r1 = 0xbc00000000 ll
02d7c0: goto -0x14e ; branch 0x2cd58
02d7c8: r1 = 0x8700000000 ll
02d7d8: goto -0x151 ; branch 0x2cd58
02d7e0: r1 = *(u64 *)(r10 - 0x4d8)
02d7e8: *(u64 *)(r10 - 0x1c0) = r1
02d7f0: r1 = *(u64 *)(r10 - 0x488)
02d7f8: *(u64 *)(r10 - 0x1c8) = r1
02d800: r1 = *(u64 *)(r10 - 0x520)
02d808: *(u64 *)(r10 - 0x1d0) = r1
02d810: *(u64 *)(r10 - 0x1d8) = r7
02d818: r1 = *(u64 *)(r10 - 0x500)
02d820: *(u64 *)(r10 - 0x1e0) = r1
02d828: r1 = *(u64 *)(r10 - 0x4f8)
02d830: *(u64 *)(r10 - 0x1e8) = r1
02d838: r1 = *(u64 *)(r10 - 0x490)
02d840: *(u64 *)(r10 - 0x1f0) = r1
02d848: r1 = *(u64 *)(r10 - 0x498)
02d850: *(u64 *)(r10 - 0x1f8) = r1
02d858: r1 = *(u64 *)(r10 - 0x4f0)
02d860: *(u64 *)(r10 - 0x200) = r1
02d868: *(u64 *)(r10 - 0x208) = r8
02d870: r1 = *(u64 *)(r10 - 0x4e8)
02d878: *(u64 *)(r10 - 0x210) = r1
02d880: r7 = *(u64 *)(r10 - 0x4b8)
02d888: *(u64 *)(r10 - 0x218) = r7
02d890: r1 = *(u64 *)(r10 - 0x508)
02d898: *(u64 *)(r10 - 0x220) = r1
02d8a0: r1 = *(u64 *)(r10 - 0x510)
02d8a8: *(u64 *)(r10 - 0x228) = r1
02d8b0: r1 = *(u64 *)(r10 - 0x518)
02d8b8: *(u64 *)(r10 - 0x230) = r1
02d8c0: r1 = r10
02d8c8: r1 += -0x338
02d8d0: r3 = r10
02d8d8: r3 += -0x230
02d8e0: r2 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02d8f0: r4 = *(u64 *)(r10 - 0x4e0)
02d8f8: call 0x3713 ; call 0x49198 / window 429
02d900: w1 = *(u32 *)(r10 - 0x338)
02d908: if r1 == 0x16 goto +0x1 ; branch 0x2d918
02d910: goto +0x42 ; branch 0x2db28
02d918: r9 <<= 0x20
02d920: r9 >>= 0x20
02d928: if r9 == 0x4 goto +0x1 ; branch 0x2d938
02d930: goto +0x6c ; branch 0x2dc98
02d938: r1 = r10
02d940: r1 += -0x60
02d948: *(u64 *)(r10 - 0x490) = r1
02d950: r2 = r8
02d958: call -0x4631 ; call 0xa7d8 / window 217
02d960: r8 = r10
02d968: r8 += -0x30
02d970: r1 = r8
02d978: r2 = *(u64 *)(r10 - 0x4a0)
02d980: call -0x4636 ; call 0xa7d8 / window 217
02d988: r9 = r10
02d990: r9 += -0x338
02d998: r1 = r9
02d9a0: r2 = r7
02d9a8: call -0x463b ; call 0xa7d8 / window 217
02d9b0: r7 = r10
02d9b8: r7 += -0x230
02d9c0: r1 = r7
02d9c8: r2 = *(u64 *)(r10 - 0x488)
02d9d0: call -0x4640 ; call 0xa7d8 / window 217
02d9d8: *(u64 *)(r10 - 0x1000) = r7
02d9e0: r1 = 0x0
02d9e8: *(u64 *)(r10 - 0xff8) = r1
02d9f0: r1 = r10
02d9f8: r1 += -0x90
02da00: r5 = r10
02da08: r2 = *(u64 *)(r10 - 0x490)
02da10: r3 = r8
02da18: r4 = r9
02da20: call 0x4667 ; call 0x50d60 / window 442
02da28: w1 = *(u32 *)(r10 - 0x90)
02da30: if r1 != 0x16 goto +0x37 ; branch 0x2dbf0
02da38: r8 = *(u64 *)(r10 - 0x4b8)
02da40: r1 = r8
02da48: call 0xaec3 ; call 0x85068 / window 980
02da50: r7 = r0
02da58: r2 = *(u64 *)(r8 + 0x10)
02da60: r2 += 0x10
02da68: r1 = r10
02da70: r1 += -0x478
02da78: r3 = 0x9f050 ll ; data b"\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x000\x01\x00\x002\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x1f\xa7\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x000\xa7\t\x00\x0c\x00\x00\x00"
02da88: call -0x5448 ; call 0x3850 / window 86
02da90: r1 = *(u64 *)(r10 - 0x470)
02da98: r3 = *(u64 *)(r10 - 0x478)
02daa0: r2 = *(u64 *)(r3 + 0x8)
02daa8: r4 = 0x2a
02dab0: if r4 > r2 goto +0x1 ; branch 0x2dac0
02dab8: goto +0x2f ; branch 0x2dc38
02dac0: r2 = 0xc800000000 ll
02dad0: *(u64 *)(r6 + 0x0) = r2
02dad8: r2 = *(u64 *)(r1 + 0x0)
02dae0: r2 += 0x1
02dae8: *(u64 *)(r1 + 0x0) = r2
02daf0: goto -0xda ; branch 0x2d428
02daf8: r1 = 0x9f00000000 ll
02db08: goto -0x1b7 ; branch 0x2cd58
02db10: r1 = 0x9a00000000 ll
02db20: goto -0x1ba ; branch 0x2cd58
02db28: w2 = *(u32 *)(r10 - 0x31c)
02db30: *(u32 *)(r10 - 0x18) = w2
02db38: r3 = *(u64 *)(r10 - 0x324)
02db40: *(u64 *)(r10 - 0x20) = r3
02db48: r4 = *(u64 *)(r10 - 0x32c)
02db50: *(u64 *)(r10 - 0x28) = r4
02db58: r5 = *(u64 *)(r10 - 0x334)
02db60: goto +0xf ; branch 0x2dbe0
02db68: r1 = r10
02db70: r1 += -0x230
02db78: r2 = r7
02db80: r3 = 0x998b8 ll ; data b'\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00program/src/state/reservation.rslibr'
02db90: call -0x3bed ; call 0xfc30 / window 275
02db98: w1 = *(u32 *)(r10 - 0x230)
02dba0: if r1 == 0x16 goto -0x9c ; branch 0x2d6c8
02dba8: w2 = *(u32 *)(r10 - 0x214)
02dbb0: *(u32 *)(r10 - 0x18) = w2
02dbb8: r3 = *(u64 *)(r10 - 0x21c)
02dbc0: *(u64 *)(r10 - 0x20) = r3
02dbc8: r4 = *(u64 *)(r10 - 0x224)
02dbd0: *(u64 *)(r10 - 0x28) = r4
02dbd8: r5 = *(u64 *)(r10 - 0x22c)
02dbe0: *(u64 *)(r10 - 0x30) = r5
02dbe8: goto -0x20d ; branch 0x2cb88
02dbf0: w2 = *(u32 *)(r10 - 0x74)
02dbf8: *(u32 *)(r10 - 0xe8) = w2
02dc00: r3 = *(u64 *)(r10 - 0x7c)
02dc08: *(u64 *)(r10 - 0xf0) = r3
02dc10: r4 = *(u64 *)(r10 - 0x84)
02dc18: *(u64 *)(r10 - 0xf8) = r4
02dc20: r5 = *(u64 *)(r10 - 0x8c)
02dc28: *(u64 *)(r10 - 0x100) = r5
02dc30: goto -0x216 ; branch 0x2cb88
02dc38: if r7 == 0x0 goto +0xf ; branch 0x2dcb8
02dc40: r7 += -0x1
02dc48: if r2 > r7 goto +0x1 ; branch 0x2dc58
02dc50: goto +0x13 ; branch 0x2dcf0
02dc58: r2 = *(u64 *)(r3 + 0x0)
02dc60: r2 += r7
02dc68: r3 = 0x4
02dc70: *(u8 *)(r2 + 0x0) = w3
02dc78: r2 = *(u64 *)(r1 + 0x0)
02dc80: r2 += 0x1
02dc88: *(u64 *)(r1 + 0x0) = r2
02dc90: r1 = *(u64 *)(r10 - 0x508)
02dc98: r1 = r6
02dca0: r2 = *(u64 *)(r10 - 0x508)
02dca8: call 0x366d ; call 0x49018 / window 428
02dcb0: goto -0x112 ; branch 0x2d428
02dcb8: r1 = 0x9a170 ll ; data b'attempt to subtract with overflowprogram/src/assertions/metadata.rsprogram/src/assertions/misc.rs\x00\x00\x00'
02dcc8: r2 = 0x21
02dcd0: r3 = 0x9f068 ll ; data b"\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x1f\xa7\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x000\xa7\t\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xe4\x9c\t\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
02dce0: call 0xc4e5 ; call 0x90410 / window 1169
02dce8: call -0x1 ; external abort
02dcf0: r1 = r7
02dcf8: r3 = 0x9f080 ll ; data b"\x00\x00\x00\x00\xf8\xa6\t\x00'\x00\x00\x00\x00\x00\x00\x006\x01\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x1f\xa7\t\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x000\xa7\t\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xe4\x9c\t\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00<\xa7\t\x00\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00A\xa7\t\x00*\x00\x00\x00"
02dd08: call 0xc50c ; call 0x90570 / window 1172
02dd10: call -0x1 ; external abort
