002d10: call 0x102ea ; call 0x84468 / window 955
002d18: r0 ^= 0x1
002d20: exit
