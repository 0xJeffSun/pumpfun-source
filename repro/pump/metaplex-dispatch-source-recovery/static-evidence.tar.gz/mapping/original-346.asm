039c58: r9 = r5
039c60: r7 = r4
039c68: r8 = r2
039c70: r6 = r1
039c78: r1 = 0x0
039c80: *(u64 *)(r10 - 0x568) = r1
039c88: *(u64 *)(r10 - 0x570) = r3
039c90: r1 = r7
039c98: r1 *= 0x30
039ca0: r3 += r1
039ca8: *(u64 *)(r10 - 0x578) = r3
039cb0: r1 = r10
039cb8: r1 += -0x1f0
039cc0: r2 = r10
039cc8: r2 += -0x578
039cd0: call -0x716f ; call 0x1160 / window 20
039cd8: w1 = *(u32 *)(r10 - 0x1f0)
039ce0: if r1 != 0x16 goto +0x64 ; branch 0x3a008
039ce8: r1 = *(u64 *)(r10 - 0x1e8)
039cf0: *(u64 *)(r10 - 0x598) = r1
039cf8: r1 = r10
039d00: r1 += -0x1f0
039d08: r2 = r10
039d10: r2 += -0x578
039d18: call -0x7178 ; call 0x1160 / window 20
039d20: w1 = *(u32 *)(r10 - 0x1f0)
039d28: if r1 == 0x16 goto +0x1 ; branch 0x39d38
039d30: goto +0x5a ; branch 0x3a008
039d38: r1 = *(u64 *)(r10 - 0x1e8)
039d40: *(u64 *)(r10 - 0x5a0) = r1
039d48: r1 = r10
039d50: r1 += -0x1f0
039d58: r2 = r10
039d60: r2 += -0x578
039d68: call -0x7182 ; call 0x1160 / window 20
039d70: w1 = *(u32 *)(r10 - 0x1f0)
039d78: if r1 == 0x16 goto +0x1 ; branch 0x39d88
039d80: goto +0x50 ; branch 0x3a008
039d88: r1 = *(u64 *)(r10 - 0x1e8)
039d90: *(u64 *)(r10 - 0x5a8) = r1
039d98: r1 = r10
039da0: r1 += -0x1f0
039da8: r2 = r10
039db0: r2 += -0x578
039db8: call -0x718c ; call 0x1160 / window 20
039dc0: w1 = *(u32 *)(r10 - 0x1f0)
039dc8: if r1 == 0x16 goto +0x1 ; branch 0x39dd8
039dd0: goto +0x46 ; branch 0x3a008
039dd8: r1 = *(u64 *)(r10 - 0x1e8)
039de0: *(u64 *)(r10 - 0x5b0) = r1
039de8: r1 = r10
039df0: r1 += -0x1f0
039df8: r2 = r10
039e00: r2 += -0x578
039e08: call -0x7196 ; call 0x1160 / window 20
039e10: w1 = *(u32 *)(r10 - 0x1f0)
039e18: if r1 == 0x16 goto +0x1 ; branch 0x39e28
039e20: goto +0x3c ; branch 0x3a008
039e28: r1 = *(u64 *)(r10 - 0x1e8)
039e30: *(u64 *)(r10 - 0x5b8) = r1
039e38: r1 = r10
039e40: r1 += -0x1f0
039e48: r2 = r10
039e50: r2 += -0x578
039e58: call -0x71a0 ; call 0x1160 / window 20
039e60: w1 = *(u32 *)(r10 - 0x1f0)
039e68: if r1 == 0x16 goto +0x1 ; branch 0x39e78
039e70: goto +0x32 ; branch 0x3a008
039e78: r1 = *(u64 *)(r10 - 0x1e8)
039e80: *(u64 *)(r10 - 0x5c0) = r1
039e88: r1 = r10
039e90: r1 += -0x1f0
039e98: r2 = r10
039ea0: r2 += -0x578
039ea8: call -0x71aa ; call 0x1160 / window 20
039eb0: w1 = *(u32 *)(r10 - 0x1f0)
039eb8: if r1 == 0x16 goto +0x1 ; branch 0x39ec8
039ec0: goto +0x28 ; branch 0x3a008
039ec8: r1 = r10
039ed0: r1 += -0x1f0
039ed8: r2 = r10
039ee0: r2 += -0x578
039ee8: call -0x71b2 ; call 0x1160 / window 20
039ef0: w1 = *(u32 *)(r10 - 0x1f0)
039ef8: if r1 == 0x16 goto +0x1 ; branch 0x39f08
039f00: goto +0x20 ; branch 0x3a008
039f08: r1 = r10
039f10: r1 += -0x578
039f18: call -0x6bf8 ; call 0x3f60 / window 89
039f20: *(u64 *)(r10 - 0x5c8) = r0
039f28: r1 = r10
039f30: r1 += -0x1f0
039f38: r2 = *(u64 *)(r10 - 0x598)
039f40: call 0x1c0f ; call 0x47fc0 / window 419
039f48: r2 = 0x1
039f50: r1 = 0x1
039f58: if r7 == 0xb goto +0x1 ; branch 0x39f68
039f60: r1 = 0x0
039f68: if r7 == 0xa goto +0x1 ; branch 0x39f78
039f70: r2 = 0x0
039f78: r3 = *(u64 *)(r10 - 0x5c8)
039f80: if r3 == 0x0 goto +0x1 ; branch 0x39f90
039f88: r2 = r1
039f90: w7 = *(u32 *)(r10 - 0xe8)
039f98: if r7 != 0x2 goto +0x19 ; branch 0x3a068
039fa0: r1 = *(u64 *)(r10 - 0x1d8)
039fa8: *(u64 *)(r10 - 0x410) = r1
039fb0: r2 = *(u64 *)(r10 - 0x1e0)
039fb8: *(u64 *)(r10 - 0x418) = r2
039fc0: r3 = *(u64 *)(r10 - 0x1e8)
039fc8: *(u64 *)(r10 - 0x420) = r3
039fd0: r4 = *(u64 *)(r10 - 0x1f0)
039fd8: *(u64 *)(r10 - 0x428) = r4
039fe0: *(u64 *)(r6 + 0x18) = r1
039fe8: *(u64 *)(r6 + 0x10) = r2
039ff0: *(u64 *)(r6 + 0x8) = r3
039ff8: *(u64 *)(r6 + 0x0) = r4
03a000: goto +0xb ; branch 0x3a060
03a008: r2 = *(u64 *)(r10 - 0x1e0)
03a010: *(u64 *)(r10 - 0x428) = r2
03a018: r3 = *(u64 *)(r10 - 0x1d8)
03a020: *(u64 *)(r10 - 0x420) = r3
03a028: w4 = *(u32 *)(r10 - 0x1ec)
03a030: r5 = *(u64 *)(r10 - 0x1e8)
03a038: *(u64 *)(r6 + 0x18) = r3
03a040: *(u64 *)(r6 + 0x10) = r2
03a048: *(u64 *)(r6 + 0x8) = r5
03a050: *(u32 *)(r6 + 0x4) = w4
03a058: *(u32 *)(r6 + 0x0) = w1
03a060: exit
03a068: *(u64 *)(r10 - 0x5d0) = r2
03a070: r1 = r10
03a078: r1 += -0x428
03a080: *(u64 *)(r10 - 0x5c8) = r1
03a088: r2 = r10
03a090: r2 += -0x1f0
03a098: r3 = 0x108
03a0a0: call 0xbdde ; call 0x98f98 / window 1246
03a0a8: r1 = r10
03a0b0: r1 += -0x44c
03a0b8: r2 = r10
03a0c0: r2 += -0xe4
03a0c8: r3 = 0x24
03a0d0: call 0xbdd8 ; call 0x98f98 / window 1246
03a0d8: r1 = r10
03a0e0: r1 += -0x558
03a0e8: r2 = *(u64 *)(r10 - 0x5c8)
03a0f0: r3 = 0x108
03a0f8: call 0xbdd3 ; call 0x98f98 / window 1246
03a100: *(u32 *)(r10 - 0x450) = w7
03a108: w1 = *(u32 *)(r10 - 0x478)
03a110: if r1 == 0x3 goto +0x6 ; branch 0x3a148
03a118: w1 = *(u32 *)(r10 - 0x4a4)
03a120: if r1 == 0x6 goto +0x1 ; branch 0x3a130
03a128: goto +0xa ; branch 0x3a180
03a130: r1 = 0x8700000000 ll
03a140: goto +0x2 ; branch 0x3a158
03a148: r1 = 0x5500000000 ll
03a158: *(u64 *)(r6 + 0x0) = r1
03a160: r1 = r10
03a168: r1 += -0x510
03a170: call -0x6e1b ; call 0x30a0 / window 59
03a178: goto -0x24 ; branch 0x3a060
03a180: if r1 > 0x5 goto -0xb ; branch 0x3a130
03a188: r2 = 0x1
03a190: r2 <<= r1
03a198: r2 &= 0x39
03a1a0: if r2 != 0x0 goto +0x1 ; branch 0x3a1b0
03a1a8: goto -0x10 ; branch 0x3a130
03a1b0: r1 = *(u64 *)(r10 - 0x5c0)
03a1b8: r1 = *(u64 *)(r1 + 0x0)
03a1c0: r2 = 0x99a48 ll ; data b'\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce\xeby\xac\x1c\xb4\x85\xed_[7\x91:\x8c\xf5\x85~\xff\x00\xa9index out of bounds: the len is program/src/processor/fee/mod.rs6K/T'
03a1d0: call -0x6e99 ; call 0x2d10 / window 44
03a1d8: if r0 != 0x0 goto +0x1 ; branch 0x3a1e8
03a1e0: goto +0x3 ; branch 0x3a200
03a1e8: r1 = 0x3e00000000 ll
03a1f8: goto -0x15 ; branch 0x3a158
03a200: r1 = r10
03a208: r1 += -0x1f0
03a210: r2 = *(u64 *)(r10 - 0x5b0)
03a218: call 0x7895 ; call 0x766c8 / window 773
03a220: w1 = *(u32 *)(r10 - 0x1f0)
03a228: if r1 == 0x16 goto +0x1 ; branch 0x3a238
03a230: goto +0x25 ; branch 0x3a360
03a238: r1 = *(u64 *)(r10 - 0x5a8)
03a240: *(u64 *)(r10 - 0xff8) = r1
03a248: r1 = *(u64 *)(r10 - 0x5a0)
03a250: *(u64 *)(r10 - 0xff0) = r1
03a258: r1 = r10
03a260: r1 += -0x558
03a268: *(u64 *)(r10 - 0x1000) = r1
03a270: r1 = r10
03a278: r1 += -0x1f0
03a280: r5 = r10
03a288: r2 = r8
03a290: r3 = *(u64 *)(r10 - 0x5b8)
03a298: r7 = *(u64 *)(r10 - 0x598)
03a2a0: r4 = r7
03a2a8: call -0x5697 ; call 0xedf8 / window 264
03a2b0: w1 = *(u32 *)(r10 - 0x1f0)
03a2b8: if r1 == 0x16 goto +0x1 ; branch 0x3a2c8
03a2c0: goto +0x13 ; branch 0x3a360
03a2c8: r1 = r10
03a2d0: r1 += -0x1f0
03a2d8: r2 = r7
03a2e0: call 0x1b9b ; call 0x47fc0 / window 419
03a2e8: w7 = *(u32 *)(r10 - 0xe8)
03a2f0: if r7 != 0x2 goto +0x1b ; branch 0x3a3d0
03a2f8: r1 = *(u64 *)(r10 - 0x1d8)
03a300: *(u64 *)(r10 - 0x2e0) = r1
03a308: r2 = *(u64 *)(r10 - 0x1e0)
03a310: *(u64 *)(r10 - 0x2e8) = r2
03a318: r3 = *(u64 *)(r10 - 0x1e8)
03a320: *(u64 *)(r10 - 0x2f0) = r3
03a328: r4 = *(u64 *)(r10 - 0x1f0)
03a330: *(u64 *)(r10 - 0x2f8) = r4
03a338: *(u64 *)(r6 + 0x18) = r1
03a340: *(u64 *)(r6 + 0x10) = r2
03a348: *(u64 *)(r6 + 0x8) = r3
03a350: *(u64 *)(r6 + 0x0) = r4
03a358: goto -0x40 ; branch 0x3a160
03a360: w2 = *(u32 *)(r10 - 0x1d4)
03a368: *(u32 *)(r10 - 0x410) = w2
03a370: r3 = *(u64 *)(r10 - 0x1dc)
03a378: *(u64 *)(r10 - 0x418) = r3
03a380: r4 = *(u64 *)(r10 - 0x1e4)
03a388: *(u64 *)(r10 - 0x420) = r4
03a390: r5 = *(u64 *)(r10 - 0x1ec)
03a398: *(u64 *)(r10 - 0x428) = r5
03a3a0: *(u32 *)(r6 + 0x1c) = w2
03a3a8: *(u64 *)(r6 + 0x14) = r3
03a3b0: *(u64 *)(r6 + 0xc) = r4
03a3b8: *(u64 *)(r6 + 0x4) = r5
03a3c0: *(u32 *)(r6 + 0x0) = w1
03a3c8: goto -0x4e ; branch 0x3a160
03a3d0: r1 = r10
03a3d8: r1 += -0x2f8
03a3e0: *(u64 *)(r10 - 0x5c8) = r1
03a3e8: r2 = r10
03a3f0: r2 += -0x1f0
03a3f8: r3 = 0x108
03a400: call 0xbd72 ; call 0x98f98 / window 1246
03a408: r1 = r10
03a410: r1 += -0x31c
03a418: r2 = r10
03a420: r2 += -0xe4
03a428: r3 = 0x24
03a430: call 0xbd6c ; call 0x98f98 / window 1246
03a438: r1 = r10
03a440: r1 += -0x428
03a448: r2 = *(u64 *)(r10 - 0x5c8)
03a450: r3 = 0x108
03a458: call 0xbd67 ; call 0x98f98 / window 1246
03a460: *(u32 *)(r10 - 0x320) = w7
03a468: r1 = *(u64 *)(r10 - 0x338)
03a470: *(u64 *)(r10 - 0x1e0) = r1
03a478: r1 = *(u64 *)(r10 - 0x340)
03a480: *(u64 *)(r10 - 0x1e8) = r1
03a488: r1 = *(u64 *)(r10 - 0x348)
03a490: *(u64 *)(r10 - 0x1f0) = r1
03a498: r1 = r10
03a4a0: r1 += -0xc0
03a4a8: r2 = r10
03a4b0: r2 += -0x1f0
03a4b8: r3 = 0x9f350 ll ; data b"\x00\x00\x00\x00y\xa9\t\x00%\x00\x00\x00\x00\x00\x00\x00U\x00\x00\x00'\x00\x00\x00\x00\x00\x00\x00\x9e\xa9\t\x000\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x00S\x00\x00\x00\x00\x00\x00\x00\x9e\xa9\t\x000\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x005\x00\x00\x00\x00\x00\x00\x00\xce\xa9\t\x00\x1c\x00\x00\x00\x00\x00\x00\x00l\x01\x00\x003\x00\x00\x00\x00\x00\x00\x00"
03a4c8: call -0x6c42 ; call 0x42c0 / window 96
03a4d0: if r9 == 0x0 goto +0x4 ; branch 0x3a4f8
03a4d8: r1 = *(u64 *)(r10 - 0xb0)
03a4e0: if r9 > r1 goto +0x2 ; branch 0x3a4f8
03a4e8: r7 = *(u64 *)(r10 - 0xb8)
03a4f0: if r7 >= r9 goto +0x7 ; branch 0x3a530
03a4f8: r1 = 0x5600000000 ll
03a508: *(u64 *)(r6 + 0x0) = r1
03a510: r1 = r10
03a518: r1 += -0x3e0
03a520: call -0x6e91 ; call 0x30a0 / window 59
03a528: goto -0x7a ; branch 0x3a160
03a530: w2 = *(u32 *)(r10 - 0xc0)
03a538: *(u64 *)(r10 - 0x338) = r1
03a540: *(u64 *)(r10 - 0x5c8) = r2
03a548: *(u32 *)(r10 - 0x348) = w2
03a550: r1 = r7
03a558: r1 -= r9
03a560: *(u64 *)(r10 - 0x340) = r1
03a568: r1 = *(u64 *)(r10 - 0x5d0)
03a570: r1 &= 0x1
03a578: if r1 != 0x0 goto +0x8 ; branch 0x3a5c0
03a580: r1 = *(u64 *)(r10 - 0x5b0)
03a588: r2 = *(u64 *)(r10 - 0x5b8)
03a590: call -0x6f18 ; call 0x2cd8 / window 42
03a598: if r0 != 0x0 goto +0x1 ; branch 0x3a5a8
03a5a0: goto +0x85 ; branch 0x3a9d0
03a5a8: r1 = 0x6200000000 ll
03a5b8: goto -0x17 ; branch 0x3a508
03a5c0: r1 = r10
03a5c8: r1 += -0x1f0
03a5d0: r2 = r10
03a5d8: r2 += -0x578
03a5e0: call -0x7291 ; call 0x1160 / window 20
03a5e8: w1 = *(u32 *)(r10 - 0x1f0)
03a5f0: if r1 != 0x16 goto +0x12c ; branch 0x3af58
03a5f8: r2 = *(u64 *)(r10 - 0x1e8)
03a600: r1 = r10
03a608: r1 += -0x1f0
03a610: *(u64 *)(r10 - 0x5d8) = r2
03a618: call 0x95d2 ; call 0x854b0 / window 986
03a620: w1 = *(u32 *)(r10 - 0x1f0)
03a628: if r1 == 0x16 goto +0x1 ; branch 0x3a638
03a630: goto +0x8b ; branch 0x3aa90
03a638: r1 = *(u64 *)(r10 - 0x1e0)
03a640: *(u64 *)(r10 - 0x5e0) = r1
03a648: r1 = *(u64 *)(r10 - 0x1e8)
03a650: *(u64 *)(r10 - 0x5e8) = r1
03a658: r1 = *(u64 *)(r1 + 0x8)
03a660: if r1 == 0x0 goto +0x39 ; branch 0x3a830
03a668: r1 = r10
03a670: r1 += -0x1f0
03a678: r2 = *(u64 *)(r10 - 0x5d8)
03a680: r3 = r8
03a688: call -0x554c ; call 0xfc30 / window 275
03a690: w1 = *(u32 *)(r10 - 0x1f0)
03a698: if r1 == 0x16 goto +0x1 ; branch 0x3a6a8
03a6a0: goto +0x24 ; branch 0x3a7c8
03a6a8: r1 = r10
03a6b0: r1 += -0x1f0
03a6b8: r2 = r8
03a6c0: r3 = *(u64 *)(r10 - 0x5d8)
03a6c8: r4 = *(u64 *)(r10 - 0x5b0)
03a6d0: r5 = *(u64 *)(r10 - 0x5a8)
03a6d8: call -0x54e4 ; call 0xffc0 / window 281
03a6e0: w1 = *(u32 *)(r10 - 0x1f0)
03a6e8: if r1 == 0x16 goto +0x1 ; branch 0x3a6f8
03a6f0: goto +0x2b ; branch 0x3a850
03a6f8: w1 = *(u8 *)(r10 - 0x1ec)
03a700: *(u64 *)(r10 - 0x5b0) = r1
03a708: r1 = *(u64 *)(r10 - 0x5e8)
03a710: r3 = *(u64 *)(r1 + 0x8)
03a718: r2 = *(u64 *)(r1 + 0x0)
03a720: r1 = r10
03a728: r1 += -0x1f0
03a730: call 0x15d6 ; call 0x455e8 / window 396
03a738: w1 = *(u32 *)(r10 - 0x1f0)
03a740: if r1 == 0x16 goto +0x1 ; branch 0x3a750
03a748: goto +0xf ; branch 0x3a7c8
03a750: r1 = *(u64 *)(r10 - 0x1e0)
03a758: *(u64 *)(r10 - 0x28) = r1
03a760: r2 = *(u64 *)(r10 - 0x1e8)
03a768: *(u64 *)(r10 - 0x30) = r2
03a770: r1 = *(u64 *)(r10 - 0x1d8)
03a778: *(u64 *)(r10 - 0x20) = r1
03a780: r1 &= 0xff
03a788: if r1 != 0x0 goto +0x2b ; branch 0x3a8e8
03a790: r2 <<= 0x20
03a798: r2 >>= 0x20
03a7a0: if r2 == 0x8 goto +0x1 ; branch 0x3a7b0
03a7a8: goto +0x27 ; branch 0x3a8e8
03a7b0: r1 = *(u64 *)(r10 - 0x5b0)
03a7b8: *(u8 *)(r10 - 0x20) = w1
03a7c0: goto +0x27 ; branch 0x3a900
03a7c8: w2 = *(u32 *)(r10 - 0x1d4)
03a7d0: *(u32 *)(r10 - 0x2e0) = w2
03a7d8: r3 = *(u64 *)(r10 - 0x1dc)
03a7e0: *(u64 *)(r10 - 0x2e8) = r3
03a7e8: r4 = *(u64 *)(r10 - 0x1e4)
03a7f0: *(u64 *)(r10 - 0x2f0) = r4
03a7f8: r5 = *(u64 *)(r10 - 0x1ec)
03a800: *(u64 *)(r10 - 0x2f8) = r5
03a808: *(u32 *)(r6 + 0x1c) = w2
03a810: *(u64 *)(r6 + 0x14) = r3
03a818: *(u64 *)(r6 + 0xc) = r4
03a820: *(u64 *)(r6 + 0x4) = r5
03a828: goto +0x14 ; branch 0x3a8d0
03a830: r1 = 0x5400000000 ll
03a840: *(u64 *)(r6 + 0x0) = r1
03a848: goto +0x11 ; branch 0x3a8d8
03a850: w2 = *(u32 *)(r10 - 0x1d4)
03a858: *(u32 *)(r10 - 0x2e1) = w2
03a860: r2 = *(u64 *)(r10 - 0x1db)
03a868: *(u64 *)(r10 - 0x2e8) = r2
03a870: r2 = *(u64 *)(r10 - 0x1eb)
03a878: *(u64 *)(r10 - 0x2f8) = r2
03a880: r3 = *(u64 *)(r10 - 0x1e3)
03a888: *(u64 *)(r10 - 0x2f0) = r3
03a890: w4 = *(u8 *)(r10 - 0x1ec)
03a898: w5 = *(u32 *)(r10 - 0x2e1)
03a8a0: *(u32 *)(r6 + 0x1c) = w5
03a8a8: r5 = *(u64 *)(r10 - 0x2e8)
03a8b0: *(u64 *)(r6 + 0x15) = r5
03a8b8: *(u64 *)(r6 + 0xd) = r3
03a8c0: *(u64 *)(r6 + 0x5) = r2
03a8c8: *(u8 *)(r6 + 0x4) = w4
03a8d0: *(u32 *)(r6 + 0x0) = w1
03a8d8: r2 = *(u64 *)(r10 - 0x5e0)
03a8e0: goto +0x31 ; branch 0x3aa70
03a8e8: r2 = *(u64 *)(r10 - 0x5b0)
03a8f0: if r1 == r2 goto +0x1 ; branch 0x3a900
03a8f8: goto +0x13 ; branch 0x3a998
03a900: r1 = *(u64 *)(r10 - 0x28)
03a908: if r9 > r1 goto +0x1 ; branch 0x3a918
03a910: goto +0x3 ; branch 0x3a930
03a918: r1 = 0x5600000000 ll
03a928: goto -0x1e ; branch 0x3a840
03a930: r1 -= r9
03a938: *(u64 *)(r10 - 0x28) = r1
03a940: r1 = *(u64 *)(r10 - 0x5e8)
03a948: r2 = *(u64 *)(r1 + 0x8)
03a950: r1 = *(u64 *)(r1 + 0x0)
03a958: r3 = r10
03a960: r3 += -0x30
03a968: call -0x6769 ; call 0x6e28 / window 169
03a970: if r0 == 0x0 goto +0x7 ; branch 0x3a9b0
03a978: r1 = r6
03a980: r2 = r0
03a988: call 0x98d2 ; call 0x87020 / window 1002
03a990: goto -0x18 ; branch 0x3a8d8
03a998: r1 = 0x5900000000 ll
03a9a8: goto -0x2e ; branch 0x3a840
03a9b0: r2 = *(u64 *)(r10 - 0x5e0)
03a9b8: r1 = *(u64 *)(r2 + 0x0)
03a9c0: r1 += 0x1
03a9c8: *(u64 *)(r2 + 0x0) = r1
03a9d0: r1 = r10
03a9d8: r1 += -0x1f0
03a9e0: r2 = *(u64 *)(r10 - 0x598)
03a9e8: call 0x9558 ; call 0x854b0 / window 986
03a9f0: w1 = *(u32 *)(r10 - 0x1f0)
03a9f8: if r1 == 0x16 goto +0x1 ; branch 0x3aa08
03aa00: goto +0x11 ; branch 0x3aa90
03aa08: r1 = *(u64 *)(r10 - 0x1e0)
03aa10: *(u64 *)(r10 - 0x598) = r1
03aa18: r1 = *(u64 *)(r10 - 0x1e8)
03aa20: r3 = *(u64 *)(r1 + 0x8)
03aa28: r2 = *(u64 *)(r1 + 0x0)
03aa30: r1 = r10
03aa38: r1 += -0x428
03aa40: call 0x1080 ; call 0x42e48 / window 365
03aa48: if r0 == 0x0 goto +0x11 ; branch 0x3aad8
03aa50: r1 = r6
03aa58: r2 = r0
03aa60: call 0x98b7 ; call 0x87020 / window 1002
03aa68: r2 = *(u64 *)(r10 - 0x598)
03aa70: r1 = *(u64 *)(r2 + 0x0)
03aa78: r1 += 0x1
03aa80: *(u64 *)(r2 + 0x0) = r1
03aa88: goto -0xb0 ; branch 0x3a510
03aa90: w2 = *(u32 *)(r10 - 0x1ec)
03aa98: r3 = *(u64 *)(r10 - 0x1e8)
03aaa0: r4 = *(u64 *)(r10 - 0x1e0)
03aaa8: r5 = *(u64 *)(r10 - 0x1d8)
03aab0: *(u64 *)(r6 + 0x18) = r5
03aab8: *(u64 *)(r6 + 0x10) = r4
03aac0: *(u64 *)(r6 + 0x8) = r3
03aac8: *(u32 *)(r6 + 0x4) = w2
03aad0: goto +0x9a ; branch 0x3afa8
03aad8: r2 = *(u64 *)(r10 - 0x598)
03aae0: r1 = *(u64 *)(r2 + 0x0)
03aae8: r1 += 0x1
03aaf0: *(u64 *)(r2 + 0x0) = r1
03aaf8: r1 = *(u64 *)(r10 - 0x5c8)
03ab00: if r1 != 0x0 goto +0x88 ; branch 0x3af48
03ab08: if r7 == r9 goto +0x1 ; branch 0x3ab18
03ab10: goto +0x86 ; branch 0x3af48
03ab18: r1 = *(u64 *)(r10 - 0x5d0)
03ab20: r1 &= 0x1
03ab28: if r1 != 0x0 goto +0x30 ; branch 0x3acb0
03ab30: r1 = r10
03ab38: r1 += -0x1e0
03ab40: r2 = *(u64 *)(r10 - 0x5a8)
03ab48: call -0x606f ; call 0xa7d8 / window 217
03ab50: r8 = r10
03ab58: r8 += -0x30
03ab60: r1 = r8
03ab68: r2 = *(u64 *)(r10 - 0x5b8)
03ab70: call -0x6074 ; call 0xa7d8 / window 217
03ab78: r7 = r10
03ab80: r7 += -0x2f8
03ab88: r1 = r7
03ab90: r2 = *(u64 *)(r10 - 0x5c0)
03ab98: call -0x6079 ; call 0xa7d8 / window 217
03aba0: r1 = r10
03aba8: r1 += -0x1b0
03abb0: r2 = *(u64 *)(r10 - 0x5a0)
03abb8: call -0x607d ; call 0xa7d8 / window 217
03abc0: r1 = 0x1
03abc8: *(u64 *)(r10 - 0x120) = r1
03abd0: r1 = r10
03abd8: r1 += -0x180
03abe0: r2 = r8
03abe8: r3 = 0x30
03abf0: call 0xbc74 ; call 0x98f98 / window 1246
03abf8: r1 = 0x0
03ac00: *(u64 *)(r10 - 0x1f0) = r1
03ac08: r1 = r10
03ac10: r1 += -0x150
03ac18: r2 = r7
03ac20: r3 = 0x30
03ac28: call 0xbc6d ; call 0x98f98 / window 1246
03ac30: r1 = r10
03ac38: r1 += -0x60
03ac40: r2 = r10
03ac48: r2 += -0x1f0
03ac50: call 0x776b ; call 0x767b0 / window 775
03ac58: w1 = *(u32 *)(r10 - 0x60)
03ac60: if r1 == 0x16 goto +0x5c ; branch 0x3af48
03ac68: w2 = *(u32 *)(r10 - 0x44)
03ac70: *(u32 *)(r10 - 0x68) = w2
03ac78: r3 = *(u64 *)(r10 - 0x4c)
03ac80: *(u64 *)(r10 - 0x70) = r3
03ac88: r4 = *(u64 *)(r10 - 0x54)
03ac90: *(u64 *)(r10 - 0x78) = r4
03ac98: r5 = *(u64 *)(r10 - 0x5c)
03aca0: *(u64 *)(r10 - 0x80) = r5
03aca8: goto +0x6e ; branch 0x3b020
03acb0: r1 = r10
03acb8: r1 += -0x1f0
03acc0: r2 = r10
03acc8: r2 += -0x578
03acd0: call -0x736f ; call 0x1160 / window 20
03acd8: w1 = *(u32 *)(r10 - 0x1f0)
03ace0: if r1 != 0x16 goto +0x4e ; branch 0x3af58
03ace8: r7 = *(u64 *)(r10 - 0x1e8)
03acf0: r2 = *(u64 *)(r7 + 0x0)
03acf8: r1 = r10
03ad00: r1 += -0x580
03ad08: call -0x55c2 ; call 0xff00 / window 280
03ad10: w9 = *(u8 *)(r10 - 0x57f)
03ad18: w1 = *(u8 *)(r10 - 0x580)
03ad20: r1 &= 0x1
03ad28: if r1 == 0x0 goto +0x1 ; branch 0x3ad38
03ad30: goto +0x50 ; branch 0x3afb8
03ad38: r1 = r10
03ad40: r1 += -0x590
03ad48: r2 = r8
03ad50: call 0x969e ; call 0x86248 / window 990
03ad58: r1 = r10
03ad60: r1 += -0xa1
03ad68: *(u64 *)(r10 - 0x2c8) = r1
03ad70: r1 = 0x9a140 ll ; data b'burnKindNone\x01\x00Invalid Option representation: . The first byte must be 0 or 1src/entrypoint.rs\x00\x00\x00IX: '
03ad80: *(u64 *)(r10 - 0x2d8) = r1
03ad88: r1 = 0x8
03ad90: *(u64 *)(r10 - 0x2f0) = r1
03ad98: r1 = 0x9a210 ll ; data b'metadatadeadlocksrc/assertions.rsprogram/src/assertions/collection.rseditionprogram/src/assertions/e'
03ada8: *(u64 *)(r10 - 0x2f8) = r1
03adb0: r1 = *(u64 *)(r10 - 0x588)
03adb8: *(u64 *)(r10 - 0x2e0) = r1
03adc0: r1 = *(u64 *)(r10 - 0x590)
03adc8: *(u64 *)(r10 - 0x2e8) = r1
03add0: *(u8 *)(r10 - 0xa1) = w9
03add8: r9 = 0x1
03ade0: *(u64 *)(r10 - 0x2c0) = r9
03ade8: r1 = 0x4
03adf0: *(u64 *)(r10 - 0x2d0) = r1
03adf8: r1 = r10
03ae00: r1 += -0x1e0
03ae08: r2 = *(u64 *)(r10 - 0x5a8)
03ae10: call -0x60c8 ; call 0xa7d8 / window 217
03ae18: r8 = r10
03ae20: r8 += -0x60
03ae28: r1 = r8
03ae30: r2 = r7
03ae38: call -0x60cd ; call 0xa7d8 / window 217
03ae40: r7 = r10
03ae48: r7 += -0x30
03ae50: r1 = r7
03ae58: r2 = *(u64 *)(r10 - 0x5c0)
03ae60: call -0x60d2 ; call 0xa7d8 / window 217
03ae68: r1 = r10
03ae70: r1 += -0x1b0
03ae78: r2 = *(u64 *)(r10 - 0x5a0)
03ae80: call -0x60d6 ; call 0xa7d8 / window 217
03ae88: *(u64 *)(r10 - 0x120) = r9
03ae90: r1 = r10
03ae98: r1 += -0x180
03aea0: r2 = r8
03aea8: r3 = 0x30
03aeb0: call 0xbc1c ; call 0x98f98 / window 1246
03aeb8: r1 = 0x4
03aec0: *(u64 *)(r10 - 0x1e8) = r1
03aec8: r1 = r10
03aed0: r1 += -0x2f8
03aed8: *(u64 *)(r10 - 0x1f0) = r1
03aee0: r1 = r10
03aee8: r1 += -0x150
03aef0: r2 = r7
03aef8: r3 = 0x30
03af00: call 0xbc12 ; call 0x98f98 / window 1246
03af08: r1 = r10
03af10: r1 += -0x80
03af18: r2 = r10
03af20: r2 += -0x1f0
03af28: call 0x7710 ; call 0x767b0 / window 775
03af30: w1 = *(u32 *)(r10 - 0x80)
03af38: if r1 == 0x16 goto +0x1 ; branch 0x3af48
03af40: goto +0x13 ; branch 0x3afe0
03af48: r1 = 0x16
03af50: goto +0xa ; branch 0x3afa8
03af58: r2 = *(u64 *)(r10 - 0x1e0)
03af60: *(u64 *)(r10 - 0x2f8) = r2
03af68: r3 = *(u64 *)(r10 - 0x1d8)
03af70: *(u64 *)(r10 - 0x2f0) = r3
03af78: w4 = *(u32 *)(r10 - 0x1ec)
03af80: r5 = *(u64 *)(r10 - 0x1e8)
03af88: *(u64 *)(r6 + 0x18) = r3
03af90: *(u64 *)(r6 + 0x10) = r2
03af98: *(u64 *)(r6 + 0x8) = r5
03afa0: *(u32 *)(r6 + 0x4) = w4
03afa8: *(u32 *)(r6 + 0x0) = w1
03afb0: goto -0x155 ; branch 0x3a510
03afb8: r1 = 0x0
03afc0: *(u32 *)(r6 + 0x0) = w1
03afc8: r1 = r9
03afd0: *(u32 *)(r6 + 0x4) = w1
03afd8: goto -0x15a ; branch 0x3a510
03afe0: w2 = *(u32 *)(r10 - 0x64)
03afe8: *(u32 *)(r10 - 0x88) = w2
03aff0: r3 = *(u64 *)(r10 - 0x6c)
03aff8: *(u64 *)(r10 - 0x90) = r3
03b000: r4 = *(u64 *)(r10 - 0x74)
03b008: *(u64 *)(r10 - 0x98) = r4
03b010: r5 = *(u64 *)(r10 - 0x7c)
03b018: *(u64 *)(r10 - 0xa0) = r5
03b020: *(u32 *)(r6 + 0x1c) = w2
03b028: *(u64 *)(r6 + 0x14) = r3
03b030: *(u64 *)(r6 + 0xc) = r4
03b038: *(u64 *)(r6 + 0x4) = r5
03b040: goto -0x14 ; branch 0x3afa8
