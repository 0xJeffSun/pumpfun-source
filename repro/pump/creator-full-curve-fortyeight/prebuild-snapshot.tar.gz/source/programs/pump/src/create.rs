use crate::*;
use anchor_spl::{token::{self,Mint,Token,TokenAccount},associated_token::AssociatedToken};
use anchor_lang::solana_program::{instruction::{Instruction,AccountMeta},program::invoke_signed};
#[derive(Clone)]
pub struct MetadataProgram;
impl Id for MetadataProgram {fn id()->Pubkey{anchor_lang::solana_program::pubkey!("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s")}}
#[event_cpi]
#[derive(Accounts)]
pub struct Create<'info>{
 #[account(init,payer=user,mint::decimals=6,mint::authority=mint_authority)]
 pub mint:Account<'info,Mint>,
 /// CHECK: canonical program mint authority.
 #[account(seeds=[b"mint-authority"],bump)]
 pub mint_authority:UncheckedAccount<'info>,
 #[account(init,payer=user,space=166,seeds=[b"bonding-curve",mint.key().as_ref()],bump)]
 pub bonding_curve:Account<'info,trade_types::BondingCurve>,
 #[account(init,payer=user,associated_token::mint=mint,associated_token::authority=bonding_curve)]
 pub associated_bonding_curve:Account<'info,TokenAccount>,
 #[account(seeds=[b"global"],bump)]
 pub global:Box<Account<'info,Global>>,
 pub mpl_token_metadata:Program<'info,MetadataProgram>,
 /// CHECK: canonical metadata account, allocated by the metadata program.
 #[account(mut,seeds=[b"metadata",mpl_token_metadata.key().as_ref(),mint.key().as_ref()],bump,seeds::program=mpl_token_metadata.key())]
 pub metadata:UncheckedAccount<'info>,
 #[account(mut)]pub user:Signer<'info>,
 pub system_program:Program<'info,System>,
 pub token_program:Program<'info,Token>,
 pub associated_token_program:Program<'info,AssociatedToken>,
 pub rent:Sysvar<'info,Rent>,
}
pub fn execute(ctx:Context<Create>,name:String,symbol:String,uri:String,creator:Pubkey)->Result<()>{
 require!(creator!=Pubkey::default(),PumpError::CreatorShouldNotBeZero);
 let a=&ctx.accounts;let bump=[ctx.bumps.mint_authority];let seeds:&[&[u8]]=&[b"mint-authority",&bump];
 let mut data=vec![33];name.serialize(&mut data)?;symbol.serialize(&mut data)?;uri.serialize(&mut data)?;
 0u16.serialize(&mut data)?;data.push(1);1u32.serialize(&mut data)?;creator.serialize(&mut data)?;data.extend_from_slice(&[0,100,0,0,0,0]);
 let ix=Instruction{program_id:a.mpl_token_metadata.key(),accounts:vec![AccountMeta::new(a.metadata.key(),false),AccountMeta::new_readonly(a.mint.key(),false),AccountMeta::new_readonly(a.mint_authority.key(),true),AccountMeta::new(a.user.key(),true),AccountMeta::new_readonly(a.mint_authority.key(),false),AccountMeta::new_readonly(a.system_program.key(),false)],data};
 invoke_signed(&ix,&[a.metadata.to_account_info(),a.mint.to_account_info(),a.mint_authority.to_account_info(),a.user.to_account_info(),a.mint_authority.to_account_info(),a.system_program.to_account_info(),a.mpl_token_metadata.to_account_info()],&[seeds])?;
 token::mint_to(CpiContext::new_with_signer(a.token_program.to_account_info(),token::MintTo{mint:a.mint.to_account_info(),to:a.associated_bonding_curve.to_account_info(),authority:a.mint_authority.to_account_info()},&[seeds]),a.global.token_total_supply)?;
 token::set_authority(CpiContext::new_with_signer(a.token_program.to_account_info(),token::SetAuthority{current_authority:a.mint_authority.to_account_info(),account_or_mint:a.mint.to_account_info()},&[seeds]),token::spl_token::instruction::AuthorityType::MintTokens,None)?;
 let event=CreateEvent{name,symbol,uri,mint:a.mint.key(),bonding_curve:a.bonding_curve.key(),user:a.user.key(),creator,timestamp:Clock::get()?.unix_timestamp,virtual_token_reserves:a.global.initial_virtual_token_reserves,virtual_sol_reserves:a.global.initial_virtual_sol_reserves,real_token_reserves:a.global.initial_real_token_reserves,token_total_supply:a.global.token_total_supply,token_program:a.token_program.key(),is_mayhem_mode:false,is_cashback_enabled:false,quote_mint:Pubkey::default(),virtual_quote_reserves:a.global.initial_virtual_sol_reserves,creator_fee_bps:0,is_holder_reward:false,depth:0};
 let g=&ctx.accounts.global;let curve=&mut ctx.accounts.bonding_curve;curve.virtual_token_reserves=g.initial_virtual_token_reserves;curve.virtual_quote_reserves=g.initial_virtual_sol_reserves;curve.real_token_reserves=g.initial_real_token_reserves;curve.token_total_supply=g.token_total_supply;curve.creator=creator;curve.initial_virtual_quote_reserves=g.initial_virtual_sol_reserves;
 emit!(event.clone());emit_cpi!(event);Ok(())
}
#[event]
#[derive(Clone)]
pub struct CreateEvent {pub name:String,pub symbol:String,pub uri:String,pub mint:Pubkey,pub bonding_curve:Pubkey,pub user:Pubkey,pub creator:Pubkey,pub timestamp:i64,pub virtual_token_reserves:u64,pub virtual_sol_reserves:u64,pub real_token_reserves:u64,pub token_total_supply:u64,pub token_program:Pubkey,pub is_mayhem_mode:bool,pub is_cashback_enabled:bool,pub quote_mint:Pubkey,pub virtual_quote_reserves:u64,pub creator_fee_bps:u64,pub is_holder_reward:bool,pub depth:u8}
