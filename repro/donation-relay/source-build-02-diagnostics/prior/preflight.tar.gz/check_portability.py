"""Copies and tests saved preflight evidence; no Cargo/compiler/target invocation."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def seal(p):
 (p/'manifest.json').write_text(json.dumps({'files':{str(f.relative_to(p)):H(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file() and f!=p/'manifest.json'}},indent=2)+'\n')
def invoke(py,p,case,success):
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONPATH',None)
 r=subprocess.run([str(py),'-B',str(p/'verify.py')],cwd=p.parent,env=env,text=True,capture_output=True)
 assert (r.returncode==0)==success,(case,r.stdout,r.stderr)
 return {'case':case,'python':str(py),'returncode':r.returncode,'expected_pass':success,'stdout':r.stdout,'stderr':r.stderr,'manifest_sha256':H((p/'manifest.json').read_bytes())}
def check(venv):
 rows=[]
 with tempfile.TemporaryDirectory(prefix='relay-preflight-portable-') as temp:
  root=Path(temp).resolve();copy=root/'copy';shutil.copytree(P,copy)
  rows.append(invoke(sys.executable,copy,'external_copy_base',True));rows.append(invoke(venv,copy,'external_copy_venv',True))
  for kind in ['missing_archive','tampered_source','false_resolved_checksum','false_SDK_mode']:
   c=root/kind;shutil.copytree(P,c)
   if kind=='missing_archive':(c/'registry/archives/solana-program-2.2.1.crate').unlink()
   elif kind=='tampered_source':
    f=c/'crate/src/solana_runtime.rs';f.write_text(f.read_text().replace('signer:a.is_signer','signer:true'))
   elif kind=='false_resolved_checksum':
    f=c/'resolved-packages-features.json';x=json.loads(f.read_text());row=next(r for r in x if r['checksum']);row['checksum']='0'*64;f.write_text(json.dumps(x,indent=2)+'\n');seal(c)
   else:
    f=c/'tool-witness/sdk-files.json';x=json.loads(f.read_text());x['scripts/install.sh']['mode']=0o644;f.write_text(json.dumps(x,indent=2)+'\n');seal(c)
   rows.append(invoke(venv,c,kind,False))
 return rows
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--venv',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.write_text(json.dumps({'scope':'saved-evidence Python checks only; no Cargo/compiler/target execution','checks':check(a.venv.resolve())},indent=2)+'\n');print('all saved-evidence copy/negative checks passed')
