# Relay offline dependency and build preflight

The sealed nineteen-module source proposal now resolves offline against the retained public dependency cache. **No source compilation, Rust typecheck, SDK installer, target execution or transaction fixture ran.** This package prepares one subsequent build for review; it does not claim a recovered historical toolchain or an equivalent relay.

The source comes unchanged from proposal seal `eff9e0de455652e97a929a918fcc2dde1d5e0acc80537801d69c9ce1d4806a38`, archived in full as `source-proposal.tar.gz`. The only new crate input is the resolved `Cargo.lock`. All nineteen Rust modules and `Cargo.toml` remain byte-identical. Original diagnostic gaps, including the deliberately unspoofed IDL SetBuffer source origin, remain open. `static-source-review.json` records eight manual API/lifetime checks; no grounded Rust correction was identified, and no alternate source was produced.

## Dependency result

The unfiltered offline `cargo metadata` selected exactly **232 registry packages plus the relay root**. Its locked repeat produced identical metadata and unchanged lock bytes. Every registry name, version, checksum, source and dependency record equals the proposed graph. Cargo only moved the root package into sorted order; `lock-order-only.patch` shows the complete textual delta. There are no additions, version changes, checksum changes, edge changes or unfiltered pruning.

A second, locked metadata view for the actual retained target spelling `sbf-solana-solana` retains **153 registry packages plus the root**. It filters 79 target-inapplicable packages and changes 20 conditional dependency edge lists. Existing feature lists do not change. This is a target view of the same lock, not a new lock or version choice. `sbf-platform-resolution-delta.json` lists every filtered package and edge change; `resolved-sbf-packages-features.json` records every remaining package, checksum, feature and dependency. The complete unfiltered view is also retained.

Only `work/fees-family-221-trial/cargo-home/registry` supplied cache inputs. Both known public registry namespace copies were read and checksum-verified, then copied into a fresh isolated Cargo home. No credentials, global Cargo/Rustup configuration, network service or other cache source was consulted. All **232 official archives and 7,607 extracted source files** match byte-for-byte. Cargo's `.cargo-ok` markers are recorded separately from source. The namespace/index/selected-record ledger is `registry-cache-provenance.json`; the selected index cache is compressed in `registry/index.tar.gz` without altering its bytes.

Cargo metadata queried the pinned compiler for version, target configuration and output filename information. It wrote only `.rustc_info.json`; that file and its hash are preserved. It did not compile this crate, run build scripts, or produce objects, libraries or ELFs. An initial overly strict empty-target-directory check rejected this legitimate metadata cache. A separate first SBF postcheck incorrectly expected the unfiltered package count. Both are retained as preparation failures; the metadata commands themselves succeeded. The corrected checks distinguish metadata queries and target filtering from compilation or dependency changes.

## Proposed single-build orchestrator

`relay_build_once.py` is relay-specific; it never labels the relay as a core program. Its **default action checks frozen inputs and local tool witnesses without starting a build**. `--execute --output <new-canonical-directory>` is present only for a later authorized run. No `--execute` invocation occurred here.

The runner creates fresh source, Cargo home, SDK, Rustup home and target directories. It uses the frozen public index/archives, never global Cargo configuration. The SDK starts from the exact 53-file recorded source archive with executable modes preserved, **without dependency symlinks or fabricated installer completion markers**. The unchanged installer may use the already validated existing tool caches; it must create its own normal SDK links/markers during a future build. The existing completed SDK installation is recorded as evidence only.

The proposed command requests the same recorded **Darwin v1.44 compilation / v1.52 SDK stripping** pipeline. Seven actual tool files, the SDK files/modes, and exact existing cache targets are hash-bound under `tool-witness/`. The runner checks files before and after, preserves raw SDK and Rustup link state and retains stdout/stderr/failure details. These are requested-version and file/link witnesses, **not complete per-process invocation attestation**. Historical relay recipe identity remains unknown.

Only `donation_relay_source_proposal.so` at the exact artifacts path and the named unstripped target path are retained as `candidate.so` and `unstripped.so`. The latter retains genuine symbols. No original ELF is a compiler input. Generated keypairs are neither read, hashed nor copied; only excluded filenames are recorded. All output path components are checked for symlinks before reading artifacts. Source, lock, SDK and dependency source bytes are checked again after a future build; failures preserve the attempt. No retry, tool version matrix, source variation, binary patch or runtime test is performed by this runner.

Ten synthetic tests cover exact artifact selection, keypair non-reading, missing/non-ELF files, root/intermediate/file symlinks, executable mode preservation and unsafe archive paths. The first test run encountered macOS `/var`'s system symlink; tests were corrected to use their canonical temporary root, while deliberate alias tests remain. The strict output guard was not weakened. Tests perform file operations only.

## Verify and review

```sh
python3 -B work/relay-runtime-build-preflight/handoff/verify.py
python3 -B work/relay-runtime-build-preflight/handoff/relay_build_once.py
```

The first command is portable and checks only retained evidence, sources, archives, metadata and synthetic file-operation tests. `verification-results.json` retains passing base-Python/venv external-copy checks and four rejected missing/tampered or self-consistent false-evidence cases. It needs no compiler, Cargo, network, local cache or `work/` references after copying. The second additionally checks the exact local tool/cache paths and stays read-only unless a future caller explicitly supplies `--execute`.

Review the nineteen-module source, unchanged diagnostic limitations, all-target/SBF feature records and orchestrator before authorizing one build. The verifier does not resolve dependencies again or certify Rust compilation. **Accepted handlers and runtime receipts added: zero.**
