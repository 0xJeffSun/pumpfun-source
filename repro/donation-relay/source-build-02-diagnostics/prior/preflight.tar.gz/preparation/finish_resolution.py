from pathlib import Path
import hashlib,json,tarfile,subprocess,tempfile,os,tomllib,shutil,difflib,io,datetime
P=Path(__file__).resolve().parent;ROOT=P.parents[1];PUB=P/'handoff';W=P/'execution';H=lambda b:hashlib.sha256(b).hexdigest()
def save(n,x):
 p=PUB/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(x if isinstance(x,bytes) else (json.dumps(x,indent=2)+'\n').encode())
meta=json.loads((PUB/'metadata.stdout.json').read_text());checks=[]
for p in meta['packages']:
 if not p['source']:continue
 name=f"{p['name']}-{p['version']}";archive=PUB/'registry/archives'/f'{name}.crate';source=Path(p['manifest_path']).parent
 assert source.is_relative_to(W/'cargo-home/registry/src')
 with tarfile.open(archive) as t:
  expected={m.name.removeprefix(name+'/'):t.extractfile(m).read() for m in t if m.isfile()}
 actual={str(f.relative_to(source)):f for f in source.rglob('*') if f.is_file()}
 extras=set(actual)-set(expected);assert extras<={'.cargo-ok'},(name,extras)
 filemap={}
 for rel,b in expected.items():assert (source/rel).read_bytes()==b,(name,rel);filemap[rel]=H(b)
 checks.append({'name':p['name'],'version':p['version'],'archive_sha256':H(archive.read_bytes()),'source_namespace':source.parent.name,'files':filemap,'cargo_generated_markers':{x:H(actual[x].read_bytes()) for x in extras},'archive_equals_extracted':True})
save('resolved-source-archive-equality.json',checks)
old=tomllib.loads((PUB/'proposed-Cargo.lock').read_text());new=tomllib.loads((PUB/'resolved-Cargo.lock').read_text());oby={(x['name'],x['version']):x for x in old['package']};nby={(x['name'],x['version']):x for x in new['package']};assert oby==nby
save('lock-delta.json',{'package_records_equal':True,'added':[],'removed':[],'dependency_edge_changes':[],'change':'root package position sorted by Cargo; all parsed package records identical','before_sha256':H((PUB/'proposed-Cargo.lock').read_bytes()),'after_sha256':H((PUB/'resolved-Cargo.lock').read_bytes())})
save('lock-order-only.patch',''.join(difflib.unified_diff((PUB/'proposed-Cargo.lock').read_text().splitlines(True),(PUB/'resolved-Cargo.lock').read_text().splitlines(True),fromfile='proposed-Cargo.lock',tofile='resolved-Cargo.lock')).encode())
inv=json.loads((PUB/'metadata-invocation.json').read_text());cmd=inv['command']+['--locked'];before=(W/'crate/Cargo.lock').read_bytes()
# Reuse the already recorded locked repeat; this inventory fix does not rerun Cargo.
assert json.loads((PUB/'metadata-locked-invocation.json').read_text())['metadata_identical']
assert json.loads((PUB/'metadata-locked.stdout.json').read_text())==meta
metadata_cache=W/'target/.rustc_info.json'
actual_target={str(f.relative_to(W/'target')) for f in (W/'target').rglob('*') if f.is_file()}
assert actual_target=={'.rustc_info.json'},('unexpected target outputs',actual_target)
save('metadata-rustc-info.json',metadata_cache.read_bytes())
save('target-inventory.json',{'files':{'.rustc_info.json':H(metadata_cache.read_bytes())},'kind':'Cargo metadata compiler-information query cache only','crate_compilation_outputs':0})
# Copy exact resolved lock into publication's source tree only after the gate.
shutil.copyfile(PUB/'resolved-Cargo.lock',PUB/'crate/Cargo.lock')
source={str(f.relative_to(PUB/'crate')):H(f.read_bytes()) for f in sorted((PUB/'crate').rglob('*')) if f.is_file()};save('resolved-source-sha256.json',source)
# Public source SDK snapshot and observed installed dependency records.
base=ROOT/'repro/pump_fees/donation-business-v144';sdk=ROOT/'work/fees-donation-business-build/main-promotion/build-01/sdk'
sdkarchive=(base/'sbf-sdk-snapshot.tar.gz').read_bytes();save('tool-witness/sbf-sdk-snapshot.tar.gz',sdkarchive)
save('tool-witness/recorded-tool-phases.json',(base/'tool-phase-provenance.json').read_bytes())
sdkfiles={}
with tarfile.open(fileobj=io.BytesIO(sdkarchive)) as t:
 for m in t:
  if not m.isfile():continue
  b=t.extractfile(m).read();actual=sdk/m.name;assert actual.read_bytes()==b;assert actual.stat().st_mode&0o777==m.mode
  sdkfiles[m.name]={'sha256':H(b),'mode':m.mode,'size':len(b)}
save('tool-witness/sdk-files.json',sdkfiles)
installed={}
for f in sorted((sdk/'dependencies').iterdir()):
 if f.is_symlink():installed[f.name]={'kind':'symlink','target':str(f.resolve()),'link_text':os.readlink(f),'target_is_directory':f.resolve().is_dir()}
 else:installed[f.name]={'kind':'file','sha256':H(f.read_bytes()),'size':f.stat().st_size,'mode':f.stat().st_mode&0o777};save('tool-witness/installed-dependencies/'+f.name,f.read_bytes())
save('tool-witness/installed-sdk-dependencies.json',installed)
compile_root=ROOT/'work/fees-compat/toolchains/v1.44';strip_root=Path(installed['platform-tools']['target']);cli=Path(shutil.which('cargo-build-sbf')).resolve();rustup=Path(shutil.which('rustup')).resolve()
paths={'compile_rustc':compile_root/'rust/bin/rustc','compile_cargo':compile_root/'rust/bin/cargo','compile_lld':compile_root/'llvm/bin/ld.lld','compile_objcopy':compile_root/'llvm/bin/llvm-objcopy','sdk_strip_objcopy':strip_root/'llvm/bin/llvm-objcopy','cargo_build_sbf':cli,'rustup':rustup};toolmap={k:{'path':str(v),'resolved_path':str(v.resolve()),'sha256':H(v.read_bytes()),'mode':v.stat().st_mode&0o777,'size':v.stat().st_size} for k,v in paths.items()};save('tool-witness/tool-files.json',toolmap)
oldphases=json.loads((PUB/'tool-witness/recorded-tool-phases.json').read_text());assert toolmap['compile_rustc']['sha256']==oldphases['compile']['tool_files']['rust/bin/rustc']['sha256'];assert toolmap['sdk_strip_objcopy']['sha256']==oldphases['strip']['file_sha256_after']
save('tool-witness/phase-interpretation.json',{'compile':'v1.44','SDK_stripper':'v1.52','installation_record':'existing completed SDK copy and original marker bytes retained; no installer was run and no success marker fabricated','global_configuration_read':False,'rustup':'binary hash only; no global settings read','historical_relay_recipe_claimed':False})
print(json.dumps({'archive_equal_sources':len(checks),'source_files_checked':sum(len(x['files']) for x in checks),'locked_metadata_identical':True,'source_inputs':len(source),'SDK_files':len(sdkfiles),'tools':len(toolmap)}))
