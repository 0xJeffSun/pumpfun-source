"""Authorized offline Cargo metadata only. No compile/typecheck/target execution."""
from pathlib import Path
import hashlib,json,shutil,tarfile,io,os,subprocess,tempfile,datetime,tomllib
P=Path(__file__).resolve().parent;ROOT=P.parents[1];SOURCE=ROOT/'work/relay-runtime-source-integration';CACHE=ROOT/'work/fees-family-221-trial/cargo-home/registry';H=lambda b:hashlib.sha256(b).hexdigest()
W=P/'execution';PUB=P/'handoff';W.mkdir();PUB.mkdir()
def save(n,x):
 p=PUB/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(x if isinstance(x,bytes) else (json.dumps(x,indent=2)+'\n').encode())
assert H((SOURCE/'manifest.json').read_bytes())=='eff9e0de455652e97a929a918fcc2dde1d5e0acc80537801d69c9ce1d4806a38'
sealed=json.loads((SOURCE/'manifest.json').read_text())['files']
for name,digest in sealed.items():assert H((SOURCE/name).read_bytes())==digest,name
shutil.copytree(SOURCE/'crate',W/'crate');shutil.copytree(SOURCE/'crate',PUB/'crate')
lock=(SOURCE/'dependency-proposal/Cargo.lock').read_bytes();(W/'crate/Cargo.lock').write_bytes(lock);save('proposed-Cargo.lock',lock)
save('source-proposal-manifest.json',(SOURCE/'manifest.json').read_bytes());save('source-proposal-source-map.json',(SOURCE/'source-map.json').read_bytes());save('source-proposal-build-plan.json',(SOURCE/'build-proposal.json').read_bytes())
# Archive only sealed predecessor files. No mutable/unsealed work cache included.
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w:gz') as t:
 for name in sorted(set(sealed)|{'manifest.json'}):
  f=SOURCE/name;b=f.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=f.stat().st_mode&0o777;i.mtime=0;t.addfile(i,io.BytesIO(b))
save('source-proposal.tar.gz',stream.getvalue())
selection=[p for p in tomllib.loads(lock.decode())['package'] if 'source' in p];ch=W/'cargo-home';records=[]
for ns in ['index.crates.io-1949cf8c6b5b557f','index.crates.io-6f17d22bba15001f']:
 cfg=(CACHE/'index'/ns/'config.json').read_bytes();parsed=json.loads(cfg);assert parsed.get('dl','').startswith('https://static.crates.io/');assert not parsed.get('auth-required',False)
 dest=ch/'registry/index'/ns;dest.mkdir(parents=True);(dest/'config.json').write_bytes(cfg);save('registry/index/'+ns+'/config.json',cfg)
 for row in selection:
  n,v=row['name'],row['version'];name=f'{n}-{v}.crate';src=CACHE/'cache'/ns/name;b=src.read_bytes();assert H(b)==row['checksum'],name
  target=ch/'registry/cache'/ns/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  # One self-contained archive copy; both source namespaces are recorded below.
  if not (PUB/'registry/archives'/name).exists():save('registry/archives/'+name,b)
  rel=Path(n[:2])/n[2:4]/n if len(n)>3 else (Path('3')/n[:1]/n if len(n)==3 else Path(str(len(n)))/n)
  index=(CACHE/'index'/ns/'.cache'/rel).read_bytes();lines=[json.loads(x) for x in index.split(b'\0') if x.startswith(b'{')];entry=next(x for x in lines if x['vers']==v);assert entry['cksum']==row['checksum']
  ip=dest/'.cache'/rel;ip.parent.mkdir(parents=True,exist_ok=True);ip.write_bytes(index);save('registry/index/'+ns+'/.cache/'+str(rel),index)
  records.append(dict(name=n,version=v,checksum=row['checksum'],source_namespace=ns,archive_sha256=H(b),index_sha256=H(index),index_relative=str(rel),selected_index_record=entry))
save('registry-cache-provenance.json',{'source':'work/fees-family-221-trial/cargo-home/registry','selected_packages':len(selection),'namespace_records':records,'global_cargo_config_read':False,'credentials_read':False,'network':False})
# Direct pinned tools; no rustup/global Cargo configuration is consulted.
tools=ROOT/'work/fees-compat/toolchains/v1.44/rust/bin';cargo=tools/'cargo';rustc=tools/'rustc'
assert H(cargo.read_bytes())=='cd27e4113fc155b5e79fca97c1cc5447ef89d1c8ce3d0e1e5679d2dd7a9ab0ef'
assert H(rustc.read_bytes())=='1f26338cc2cabd0a6057dcbd0528bba262b23ca1296d357a55304ee31d1d9e5a'
(W/'rustup-home').mkdir();(W/'target').mkdir()
env={'PATH':'/usr/bin:/bin','CARGO_HOME':str(ch),'RUSTUP_HOME':str(W/'rustup-home'),'RUSTC':str(rustc),'CARGO_TARGET_DIR':str(W/'target'),'CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'}
cmd=[str(cargo),'metadata','--manifest-path',str(W/'crate/Cargo.toml'),'--format-version','1','--offline']
with tempfile.TemporaryDirectory(prefix='relay-metadata-cwd-') as temp:
 for ancestor in [Path(temp),*Path(temp).parents]:
  assert not (ancestor/'.cargo/config').exists() and not (ancestor/'.cargo/config.toml').exists(), 'unexpected ancestor config'
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();run=subprocess.run(cmd,cwd=temp,env=env,capture_output=True)
save('metadata.stdout.json',run.stdout);save('metadata.stderr.txt',run.stderr)
after=(W/'crate/Cargo.lock').read_bytes();save('resolved-Cargo.lock',after)
save('metadata-invocation.json',{'command':cmd,'environment':env,'cwd':'temporary directory checked to have no ancestor Cargo configuration','started_utc':started,'returncode':run.returncode,'before_lock_sha256':H(lock),'after_lock_sha256':H(after),'cargo_sha256':H(cargo.read_bytes()),'rustc_sha256':H(rustc.read_bytes()),'compile_or_typecheck':False})
if run.returncode:raise SystemExit('Offline metadata failed; retained outputs, no retry or build.')
old={(p['name'],p['version']):p for p in selection};new=[p for p in tomllib.loads(after.decode())['package'] if 'source' in p];newby={(p['name'],p['version']):p for p in new}
added=[p for key,p in newby.items() if key not in old];changed=[p for key,p in newby.items() if key in old and (p.get('checksum'),p.get('source'))!=(old[key].get('checksum'),old[key].get('source'))];removed=[p for key,p in old.items() if key not in newby]
meta=json.loads(run.stdout);nodes={n['id']:n for n in meta['resolve']['nodes']};resolved=[]
for p in meta['packages']:
 node=nodes[p['id']];entry=newby.get((p['name'],p['version']));resolved.append({'id':p['id'],'name':p['name'],'version':p['version'],'source':p['source'],'checksum':entry.get('checksum') if entry else None,'features':node['features'],'deps':node['deps'],'manifest_path':p['manifest_path'],'targets':p['targets'],'declared_features':p['features']})
save('resolved-packages-features.json',resolved)
gate={'original_registry_nodes':len(old),'resolved_registry_nodes':len(newby),'resolved_metadata_packages':len(meta['packages']),'added_nodes':added,'checksum_or_source_changes':changed,'pruned_nodes':removed,'same_registry_selections':not added and not changed,'lock_bytes_changed':lock!=after,'build_allowed_by_this_record':False}
save('resolution-gate.json',gate)
if added or changed:raise SystemExit('Unexpected dependency additions/version/checksum changes. Stopped before any build.')
print(json.dumps(gate,indent=2))
