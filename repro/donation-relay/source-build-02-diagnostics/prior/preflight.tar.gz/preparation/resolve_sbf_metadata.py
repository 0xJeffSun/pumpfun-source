from pathlib import Path
import subprocess,tempfile,json,hashlib,tomllib
P=Path(__file__).resolve().parent;H=P/'handoff';W=P/'execution';digest=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((H/'metadata-invocation.json').read_text());cmd=inv['command']+['--locked','--filter-platform','sbf-solana-solana'];before=(W/'crate/Cargo.lock').read_bytes()
# Target spelling is from the retained completed Fees build's actual target directory.
witness=P.parents[1]/'work/fees-donation-business-build/main-promotion/build-01/target/sbf-solana-solana';assert witness.is_dir()
# Reuse successful Cargo output; only correct the over-strict postcheck.
assert before==(W/'crate/Cargo.lock').read_bytes()
meta=json.loads((H/'metadata-sbf.stdout.json').read_text());original=json.loads((H/'metadata.stdout.json').read_text())
oldset={(p['name'],p['version'],p['source']) for p in original['packages']};newset={(p['name'],p['version'],p['source']) for p in meta['packages']}
assert not (newset-oldset),'unplanned package addition'
pruned=[{'name':n,'version':v,'source':src} for n,v,src in sorted(oldset-newset)]
oldnodes={n['id']:n for n in original['resolve']['nodes']};changes=[]
for n in meta['resolve']['nodes']:
 old=oldnodes[n['id']]
 if n!=old:changes.append({'id':n['id'],'features_before':old['features'],'features_after':n['features'],'dependencies_before':old['deps'],'dependencies_after':n['deps']})
(H/'metadata-sbf-invocation.json').write_text(json.dumps({'command':cmd,'returncode':0,'lock_unchanged':True,'no_added_or_changed_selections':True,'filtered_registry_nodes':len(meta['packages'])-1,'pruned_for_target':pruned,'target':'sbf-solana-solana','target_spelling_witness':str(witness.relative_to(P.parents[1])),'source_compilation':False},indent=2)+'\n')
(H/'sbf-platform-resolution-delta.json').write_text(json.dumps({'pruned_for_target':pruned,'changes':changes,'features_changed_nodes':sum(x['features_before']!=x['features_after'] for x in changes),'notes':'Conditional dependency edges are filtered for SBF; no registry package/version/checksum changed.'},indent=2)+'\n')
(H/'metadata-rustc-info.json').write_bytes((W/'target/.rustc_info.json').read_bytes())
(H/'target-inventory.json').write_text(json.dumps({'files':{'.rustc_info.json':digest((W/'target/.rustc_info.json').read_bytes())},'kind':'Cargo metadata compiler-information queries only, now including SBF target cfg','crate_compilation_outputs':0},indent=2)+'\n')
print(json.dumps({'no_added_or_changed_selections':True,'target_pruned_count':len(pruned),'changed_conditional_node_edges':len(changes),'changed_features':sum(x['features_before']!=x['features_after'] for x in changes)}))
