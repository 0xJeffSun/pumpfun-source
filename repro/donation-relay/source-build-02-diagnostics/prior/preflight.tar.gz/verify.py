#!/usr/bin/env python3
"""Portable saved preflight verifier. Never invokes Cargo, Rust, SDK or target code."""
from pathlib import Path,PurePosixPath
import argparse,ast,hashlib,json,os,subprocess,sys,tarfile,tempfile,tomllib
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
PROPOSAL='eff9e0de455652e97a929a918fcc2dde1d5e0acc80537801d69c9ce1d4806a38'
def read(n):return (P/n).read_bytes()
def js(n):return json.loads(read(n))
def need(b,msg):
 if not b:raise AssertionError(msg)
def archive(path,allow_dirs=False):
 out={};modes={}
 with tarfile.open(path) as t:
  for m in t:
   if allow_dirs and m.isdir():continue
   p=PurePosixPath(m.name);need(m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in out,'safe regular unique archive member')
   out[m.name]=t.extractfile(m).read();modes[m.name]=m.mode
 return out,modes
def run_python(script,cwd):
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONPATH',None)
 r=subprocess.run([sys.executable,'-B',str(script)],cwd=cwd,env=env,text=True,capture_output=True)
 need(r.returncode==0,'saved Python verification: '+r.stdout+r.stderr);return r

def verify(local_tools=False):
 need(not any(f.is_symlink() for f in P.rglob('*')),'package has no symlinks')
 actual={str(f.relative_to(P)):H(f.read_bytes()) for f in P.rglob('*') if f.is_file() and f!=P/'manifest.json'}
 need(actual==js('manifest.json')['files'],'exact payload seal')
 old,modes=archive(P/'source-proposal.tar.gz');need(H(old['manifest.json'])==PROPOSAL,'source proposal seal')
 oldmap=json.loads(old['manifest.json'])['files'];need(set(old)==set(oldmap)|{'manifest.json'},'full proposal archive')
 for n,h in oldmap.items():need(H(old[n])==h,'source proposal payload '+n)
 with tempfile.TemporaryDirectory(prefix='relay-preflight-source-') as t:
  root=Path(t).resolve()/'source'
  for n,b in old.items():
   p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(modes[n])
  r=run_python(root/'verify.py',root.parent);source_proof=json.loads(r.stdout)
 current={str(f.relative_to(P/'crate')):H(f.read_bytes()) for f in (P/'crate').rglob('*') if f.is_file()}
 need(current==js('resolved-source-sha256.json') and len(current)==21,'21 exact source inputs')
 for n,h in current.items():
  if n!='Cargo.lock':need(read('crate/'+n)==old['crate/'+n],'unchanged19module source '+n)
 need(read('crate/Cargo.lock')==read('resolved-Cargo.lock'),'installed resolved lock')
 proposal=tomllib.loads(read('proposed-Cargo.lock').decode());resolved=tomllib.loads(read('resolved-Cargo.lock').decode())
 a={(x['name'],x['version']):x for x in proposal['package']};b={(x['name'],x['version']):x for x in resolved['package']};need(a==b,'all lock records unchanged')
 registry={k:v for k,v in b.items() if 'source' in v};need(len(registry)==232,'232 registry records')
 index,_=archive(P/'registry/index.tar.gz');prov=js('registry-cache-provenance.json');need(len(prov['namespace_records'])==464,'both registry namespaces recorded')
 for row in prov['namespace_records']:
  key=(row['name'],row['version']);need(registry[key]['checksum']==row['checksum'],'lock checksum')
  name=row['name']+'-'+row['version']+'.crate';need(H(read('registry/archives/'+name))==row['archive_sha256']==row['checksum'],'official archive '+name)
  path=row['source_namespace']+'/.cache/'+row['index_relative'];raw=index[path];need(H(raw)==row['index_sha256'],'exact retained index bytes')
  records=[json.loads(x) for x in raw.split(b'\0') if x.startswith(b'{')];need(row['selected_index_record'] in records and row['selected_index_record']['cksum']==row['checksum'],'selected official record')
 source_files=0
 for row in js('resolved-source-archive-equality.json'):
  name=row['name']+'-'+row['version'];files,_=archive(P/'registry/archives'/(name+'.crate'),True)
  derived={k.removeprefix(name+'/'):H(v) for k,v in files.items()};need(derived==row['files'],'every extracted source file '+name);source_files+=len(derived)
 need(source_files==7607,'7607 source files')
 meta=js('metadata.stdout.json');locked=js('metadata-locked.stdout.json');need(meta==locked,'locked metadata identical')
 need(js('metadata-invocation.json')['returncode']==0 and js('metadata-locked-invocation.json')['returncode']==0,'Cargo metadata successful')
 need(js('metadata-sbf-invocation.json')['returncode']==0,'SBF metadata successful')
 nodes={n['id']:n for n in meta['resolve']['nodes']};packages={p['id']:p for p in meta['packages']};need(len(packages)==233,'root +232 metadata packages')
 def check_rows(rows,m):
  ns={n['id']:n for n in m['resolve']['nodes']};ps={p['id']:p for p in m['packages']};need({r['id'] for r in rows}==set(ps),'complete resolved feature inventory')
  for row in rows:
   node=ns[row['id']];p=ps[row['id']];need(row['features']==node['features'] and row['deps']==node['deps'],'feature/dependency binding')
   need(all(d['pkg'] in ps for d in node['deps']),'resolved dependency ids')
   if p['source']:need(row['checksum']==registry[(p['name'],p['version'])]['checksum'],'resolved checksum')
 check_rows(js('resolved-packages-features.json'),meta)
 sbf=js('metadata-sbf.stdout.json');check_rows(js('resolved-sbf-packages-features.json'),sbf)
 sbfset={(p['name'],p['version'],p['source']) for p in sbf['packages']};full={(p['name'],p['version'],p['source']) for p in meta['packages']}
 need(sbfset<=full and len(sbfset)==154 and len(full-sbfset)==79,'exact target pruning')
 changes=[]
 for n in sbf['resolve']['nodes']:
  before=nodes[n['id']]
  if n!=before:changes.append({'id':n['id'],'features_before':before['features'],'features_after':n['features'],'dependencies_before':before['deps'],'dependencies_after':n['deps']})
 need(changes==js('sbf-platform-resolution-delta.json')['changes'] and len(changes)==20,'exact target edge changes')
 need(all(x['features_before']==x['features_after'] for x in changes),'target feature lists unchanged')
 need(js('target-inventory.json')['files']=={'.rustc_info.json':H(read('metadata-rustc-info.json'))},'only compiler-information cache')
 sdk,sdkmodes=archive(P/'tool-witness/sbf-sdk-snapshot.tar.gz');expected=js('tool-witness/sdk-files.json');need(len(expected)==53 and set(expected)==set(sdk),'complete SDK source')
 for name,entry in expected.items():need(entry=={'sha256':H(sdk[name]),'mode':sdkmodes[name],'size':len(sdk[name])},'SDK source/mode')
 for name in ['dump','install','objcopy','package','strip']:need(sdkmodes['scripts/'+name+'.sh']&0o111,'SDK executable modes')
 need(b'version=v1.52\n' in sdk['scripts/install.sh'],'recorded SDK strip version')
 tools=js('tool-witness/tool-files.json');oldphase=json.loads(old['inputs/build-witness/tool-phase-provenance.json'])
 for key,path in [('compile_rustc','rust/bin/rustc'),('compile_cargo','rust/bin/cargo'),('compile_lld','llvm/bin/ld.lld'),('compile_objcopy','llvm/bin/llvm-objcopy')]:need(tools[key]['sha256']==oldphase['compile']['tool_files'][path]['sha256'],'recorded compile tool')
 need(tools['sdk_strip_objcopy']['sha256']==oldphase['strip']['file_sha256_after'],'recorded actual stripping tool')
 # Parse orchestration Python only; no execution path invokes it with --execute.
 runner=read('relay_build_once.py').decode();ast.parse(runner)
 for token in ["if not args.execute:","'build-sbf'","'--tools-version','v1.44'","'--locked','--offline'","if (sdk/'dependencies').exists()","'candidate.so'","'unstripped.so'","No installer is run here"]:need(token in runner,'orchestrator invariant '+token)
 tests=run_python(P/'test_relay_build_once.py',P);need('Ran 10 tests' in tests.stderr and tests.stderr.rstrip().endswith('OK'),'10 synthetic tests')
 review=js('static-source-review.json');need(not review['confirmed_source_fixes'] and not review['typechecked'],'manual static review scope')
 result=js('result.json');need(not any(result[k] for k in ['source_build_started','typechecked','target_executed','network_requests','global_configs_or_credentials_read','accepted_handler_delta','runtime_receipt_delta','historical_recipe_claimed']),'honest scope')
 if local_tools:
  local=run_python(P/'relay_build_once.py',P);need(json.loads(local.stdout)['build_started'] is False,'local read-only preflight')
 return {'verified':True,'payload_files':len(actual),'registry_nodes':232,'SBF_registry_nodes':153,'target_filtered_nodes':79,'conditional_edge_changes':20,'source_archive_files_verified':source_files,'source_inputs':21,'SDK_files':53,'synthetic_tests':10,'source_proposal_verified':source_proof['verified'],'local_tools_checked':local_tools,'build_typecheck_target_execution':False}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--local-tools',action='store_true');a=parser.parse_args();print(json.dumps(verify(a.local_tools),indent=2,sort_keys=True))
