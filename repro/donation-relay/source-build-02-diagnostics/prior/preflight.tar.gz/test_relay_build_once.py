"""Synthetic path/retention tests; no compiler, Cargo, SDK installer or target execution."""
from pathlib import Path
import builtins,io,tarfile,tempfile,unittest
from unittest.mock import patch
import relay_build_once as b
class Retention(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='relay-retention-test-');self.root=Path(self.temp.name).resolve()/'out';self.root.mkdir()
  self.target=self.root/'target';self.artifacts=self.root/'artifacts';self.artifacts.mkdir();self.release=self.target/'sbf-solana-solana/release';self.release.mkdir(parents=True)
  (self.release/(b.NAME+'.so')).write_bytes(b'\x7fELFsymbol-bearing-original')
  (self.artifacts/(b.NAME+'.so')).write_bytes(b'\x7fELFstripped')
  (self.artifacts/(b.NAME+'-keypair.json')).write_bytes(b'THIS MUST NOT BE READ')
 def tearDown(self):self.temp.cleanup()
 def retain(self):return b.retain_artifacts(self.root,self.target,self.artifacts,self.root/'retained')
 def test_exact_named_artifacts_keypair_not_read(self):
  original=Path.read_bytes;reads=[]
  def observe(p):
   reads.append(p.name)
   if p.name.endswith('-keypair.json'):raise AssertionError('keypair read')
   return original(p)
  with patch.object(Path,'read_bytes',observe):out=self.retain()
  self.assertEqual(set(p.name for p in (self.root/'retained').iterdir()),{'candidate.so','unstripped.so'})
  self.assertNotIn(b.NAME+'-keypair.json',reads);self.assertEqual(out['excluded_keypair_names'],[b.NAME+'-keypair.json'])
 def test_missing_candidate(self):
  (self.artifacts/(b.NAME+'.so')).unlink()
  with self.assertRaisesRegex(ValueError,'Missing named candidate'):self.retain()
 def test_missing_unstripped(self):
  (self.release/(b.NAME+'.so')).unlink()
  with self.assertRaisesRegex(ValueError,'Missing named unstripped'):self.retain()
 def test_non_elf(self):
  (self.artifacts/(b.NAME+'.so')).write_bytes(b'bad')
  with self.assertRaisesRegex(ValueError,'not ELF'):self.retain()
 def test_output_root_symlink_rejected_before_reads(self):
  alias=Path(self.temp.name).resolve()/'alias';alias.symlink_to(self.root,target_is_directory=True)
  with patch.object(Path,'read_bytes',side_effect=AssertionError('premature read')),patch.object(Path,'open',side_effect=AssertionError('premature open')),patch.object(builtins,'open',side_effect=AssertionError('premature open')),patch.object(io,'open',side_effect=AssertionError('premature open')):
   with self.assertRaisesRegex(ValueError,'Symlink path component'):b.retain_artifacts(alias,alias/'target',alias/'artifacts',alias/'retained')
 def test_selected_file_symlink(self):
  p=self.artifacts/(b.NAME+'.so');p.unlink();p.symlink_to(self.release/(b.NAME+'.so'))
  with self.assertRaisesRegex(ValueError,'Symlink path component'):self.retain()
 def test_target_parent_symlink(self):
  renamed=self.root/'elsewhere';self.target.rename(renamed);self.target.symlink_to(renamed,target_is_directory=True)
  with patch.object(Path,'read_bytes',side_effect=AssertionError('premature read')):
   with self.assertRaisesRegex(ValueError,'Symlink path component'):self.retain()
class Extraction(unittest.TestCase):
 def make(self,kind):
  self.temp=tempfile.TemporaryDirectory(prefix='relay-sdk-test-');self.addCleanup(self.temp.cleanup);root=Path(self.temp.name).resolve();archive=root/'sdk.tar.gz'
  with tarfile.open(archive,'w:gz') as t:
   m=tarfile.TarInfo('../escape' if kind=='traversal' else 'scripts/install.sh');m.mode=0o755
   if kind=='symlink':m.type=tarfile.SYMTYPE;m.linkname='/tmp/outside';t.addfile(m)
   else:m.size=2;t.addfile(m,io.BytesIO(b'ok'))
  return root,archive
 def test_preserve_sdk_executable_mode(self):
  root,a=self.make('normal');b.safe_extract(a,root/'sdk');self.assertEqual((root/'sdk/scripts/install.sh').stat().st_mode&0o777,0o755)
 def test_reject_traversal(self):
  root,a=self.make('traversal')
  with self.assertRaisesRegex(ValueError,'unsafe archive'):b.safe_extract(a,root/'sdk')
 def test_reject_symlink(self):
  root,a=self.make('symlink')
  with self.assertRaisesRegex(ValueError,'unsafe archive'):b.safe_extract(a,root/'sdk')
if __name__=='__main__':unittest.main()
