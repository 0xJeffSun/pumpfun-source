#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys,subprocess,os,difflib,ast
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def js(n):return json.loads((P/n).read_text())
def read(n):return (P/n).read_bytes()
def verify():
 assert not any(p.is_symlink() for p in P.rglob('*'))
 actual={str(p.relative_to(P)):H(p.read_bytes()) for p in P.rglob('*') if p.is_file() and p!=P/'manifest.json'};assert actual==js('manifest.json')['files'],'payload seal'
 assert H(read('preflight/manifest.json'))=='4e48eb72d136fb12d895d2e4ac3b568caba69491b931ec8c91a7911e76165b97'
 prior=js('preflight/manifest.json')['files']
 for p in (P/'preflight').rglob('*'):
  if p.is_file() and p.name!='manifest.json':assert H(p.read_bytes())==prior[str(p.relative_to(P/'preflight'))]
 source=js('preflight/resolved-source-sha256.json');assert len(source)==21 and source==js('source-after.json')==js('attempt/build-result.json')['source_after']
 for name,digest in source.items():assert H(read('source/'+name))==digest
 assert js('attempt/build-result.json')['returncode']==1
 assert b'no such command: `+solana`' in read('attempt/build.stderr')
 assert b'Cargo does not handle `+toolchain` directives.' in read('attempt/build.stderr')
 before=js('attempt/tool-phase-before.json');after=js('attempt/tool-phase-after.json');assert before['tools']==after['tools']
 post=js('attempt-postcheck.json');assert post['all21_source_inputs_unchanged'] and post['SDK53_sources_unchanged'] and post['all7_tool_files_unchanged']
 assert js('attempt/SDK-source-after.json')==js('preflight/tool-witness/sdk-files.json')
 assert not post['target_exists'] and not post['artifacts_exists'] and post['keypair_files_read']==0
 old=read('preflight/relay_build_once.py').decode();new=old
 needle="    tools=json.loads((P/'tool-witness/tool-files.json').read_text())\n"
 replacement=needle+'''    # cargo-build-sbf internally invokes `cargo +solana`; this must resolve to
    # the genuine rustup proxy, not a direct toolchain Cargo executable.
    proxy=Path(tools['rustup']['path']).parent/'cargo'
    if sha(proxy)!=tools['rustup']['sha256'] or not os.access(proxy,os.X_OK):
        raise ValueError('The selected Cargo proxy is not the pinned rustup binary')
'''
 new=new.replace(needle,replacement)
 new=new.replace("[str(Path(tools['compile_cargo']['path']).parent),str(Path(tools['cargo_build_sbf']['path']).parent),str(Path(tools['rustup']['path']).parent),'/usr/bin','/bin']","[str(Path(tools['rustup']['path']).parent),str(Path(tools['cargo_build_sbf']['path']).parent),str(Path(tools['compile_cargo']['path']).parent),'/usr/bin','/bin']")
 assert new.encode()==read('proposed/relay_build_once.py'),'exact two-site correction'
 assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/relay_build_once.py',tofile='b/relay_build_once.py')).encode()==read('correction.patch')
 ast.parse(new)
 assert H(read('proposed/test_relay_build_once.py'))==prior['test_relay_build_once.py']
 prop=js('proposal.json');assert prop['old_runner_sha256']==H(old.encode()) and prop['new_runner_sha256']==H(new.encode())
 assert prop['builds_attempted']==1 and prop['builds_retried']==0 and not prop['source_inputs_changed'] and not prop['dependency_changes'] and not prop['flag_changes']
 witness=js('proxy-witness.json');assert witness['sha256']==js('preflight/tool-witness/tool-files.json')['rustup']['sha256']
 command=js('proxy-version-command.json');assert command['command']==[witness['path'],'+solana','--version'] and command['returncode']==0 and command['only_version_query'] and not command['source_compile']
 assert read('proxy-version.stdout').startswith(b'cargo 1.79.0 ')
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONPATH',None)
 r=subprocess.run([sys.executable,'-B',str(P/'proposed/test_relay_build_once.py')],cwd=P,env=env,capture_output=True,text=True)
 assert r.returncode==0 and 'Ran 10 tests' in r.stderr,(r.stdout,r.stderr)
 return {'verified':True,'payload_files':len(actual),'source_inputs_unchanged':21,'tool_files_unchanged':7,'SDK_source_files_unchanged':53,'synthetic_tests':10,'build_attempts':1,'build_retries':0,'crate_compilation_reached':False,'target_execution':False}
if __name__=='__main__':print(json.dumps(verify(),indent=2,sort_keys=True))
