from pathlib import Path
import hashlib,json,shutil,difflib,subprocess,datetime,os
P=Path(__file__).resolve().parent;ROOT=P.parents[1];B=ROOT/'work/relay-first-source-build-01';F=ROOT/'work/relay-runtime-build-preflight/handoff';H=lambda b:hashlib.sha256(b).hexdigest()
def write(n,b):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else (json.dumps(b,indent=2)+'\n').encode())
assert H((F/'manifest.json').read_bytes())=='4e48eb72d136fb12d895d2e4ac3b568caba69491b931ec8c91a7911e76165b97'
for n in ['manifest.json','relay_build_once.py','resolved-source-sha256.json','tool-witness/tool-files.json','tool-witness/sdk-files.json','tool-witness/runtime-cache-paths.json']:
 write('preflight/'+n,(F/n).read_bytes())
for n in ['build-launch.json','build-result.json','build.stderr','build.stdout','failure.txt','tool-phase-before.json','tool-phase-after.json','dependency-source-after.json']:
 write('attempt/'+n,(B/n).read_bytes())
for n in ['relay-first-source-build-launch.json','relay-first-source-build-launch.stderr','relay-first-source-build-launch.stdout']:
 write('attempt/'+n,(ROOT/'work'/n).read_bytes())
expected=json.loads((F/'resolved-source-sha256.json').read_text());actual={}
for n,digest in expected.items():
 raw=(B/'source'/n).read_bytes();assert H(raw)==digest;write('source/'+n,raw);actual[n]=H(raw)
write('source-after.json',actual)
# Independent post-failure tool/SDK and absence inventory; never touch keypairs.
before=json.loads((B/'tool-phase-before.json').read_text());after=json.loads((B/'tool-phase-after.json').read_text());assert before['tools']==after['tools']
sdkexpected=json.loads((F/'tool-witness/sdk-files.json').read_text());sdkactual={}
for n in sdkexpected:
 f=B/'sdk'/n;sdkactual[n]={'sha256':H(f.read_bytes()),'mode':f.stat().st_mode&0o777,'size':f.stat().st_size}
assert sdkactual==sdkexpected
write('attempt-postcheck.json',{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all21_source_inputs_unchanged':actual==expected,'SDK53_sources_unchanged':sdkactual==sdkexpected,'all7_tool_files_unchanged':before['tools']==after['tools'],'target_exists':(B/'target').exists(),'artifacts_exists':(B/'artifacts').exists(),'keypair_files_read':0,'stage':'cargo-build-sbf inner cargo +solana launch, before crate compilation','source_diagnostics':[],'source_corrections_proposed':[]})
old=(F/'relay_build_once.py').read_text();new=old
needle="    tools=json.loads((P/'tool-witness/tool-files.json').read_text())\n"
replacement=needle+'''    # cargo-build-sbf internally invokes `cargo +solana`; this must resolve to
    # the genuine rustup proxy, not a direct toolchain Cargo executable.
    proxy=Path(tools['rustup']['path']).parent/'cargo'
    if sha(proxy)!=tools['rustup']['sha256'] or not os.access(proxy,os.X_OK):
        raise ValueError('The selected Cargo proxy is not the pinned rustup binary')
'''
assert needle in new;new=new.replace(needle,replacement)
oldpath="[str(Path(tools['compile_cargo']['path']).parent),str(Path(tools['cargo_build_sbf']['path']).parent),str(Path(tools['rustup']['path']).parent),'/usr/bin','/bin']"
newpath="[str(Path(tools['rustup']['path']).parent),str(Path(tools['cargo_build_sbf']['path']).parent),str(Path(tools['compile_cargo']['path']).parent),'/usr/bin','/bin']"
assert oldpath in new;new=new.replace(oldpath,newpath)
write('proposed/relay_build_once.py',new.encode());write('correction.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/relay_build_once.py',tofile='b/relay_build_once.py')).encode())
tools=json.loads((F/'tool-witness/tool-files.json').read_text());proxy=Path(tools['rustup']['path']).parent/'cargo';assert H(proxy.read_bytes())==tools['rustup']['sha256']
write('proxy-witness.json',{'path':str(proxy),'is_symlink':proxy.is_symlink(),'link':os.readlink(proxy) if proxy.is_symlink() else None,'resolved_path':str(proxy.resolve()),'sha256':H(proxy.read_bytes()),'same_bytes_as_pinned_rustup':True,'mode':proxy.stat().st_mode&0o777})
# Read-only proof: the exact existing isolated solana alias accepts the +syntax
# through this proxy. --version performs no compilation or dependency resolution.
env={'PATH':os.pathsep.join([str(proxy.parent),str(Path(tools['cargo_build_sbf']['path']).parent),str(Path(tools['compile_cargo']['path']).parent),'/usr/bin','/bin']),'CARGO_HOME':str(B/'cargo-home'),'RUSTUP_HOME':str(B/'rustup'),'CARGO_NET_OFFLINE':'true'}
cmd=[str(proxy),'+solana','--version'];r=subprocess.run(cmd,cwd=P,env=env,capture_output=True);write('proxy-version.stdout',r.stdout);write('proxy-version.stderr',r.stderr)
write('proxy-version-command.json',{'command':cmd,'environment':env,'returncode':r.returncode,'only_version_query':True,'source_compile':False});assert r.returncode==0,r.stderr
write('proposal.json',{'old_runner_sha256':H(old.encode()),'new_runner_sha256':H(new.encode()),'source_inputs_changed':[],'dependency_changes':[],'compiler_version_changes':[],'flag_changes':[],'changes':['Validate the exact cargo proxy bytes equal the pinned rustup binary','Put the rustup proxy directory first for inner cargo +solana lookup; keep outer absolute v1.44 Cargo command unchanged'],'builds_attempted':1,'builds_retried':0,'runtime_tests':0,'retry_requires_root_review':True})
print(json.dumps({'source_inputs':len(actual),'runner_sha256':H(new.encode()),'proxy_version':r.stdout.decode().strip(),'no_retry':True}))
