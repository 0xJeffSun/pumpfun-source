# First relay build: launcher failure and bounded correction

The one authorized offline build stopped **before compiling the relay crate**. `cargo-build-sbf` tried to invoke `cargo +solana`, but the runner had placed the direct v1.44 Cargo binary first in PATH. That binary reported `no such command: +solana` and explained that the syntax requires the Rustup proxy. There was no target directory, artifact directory or candidate ELF. The failure and complete launcher/stdout/stderr records are retained under `attempt/`.

All 21 source inputs, all 53 SDK source files/modes, and all seven measured tool files remained unchanged. The CLI legitimately created isolated SDK/Rustup links to v1.44; it did not reach the later SDK stripping phase. Thus **no actual v1.52 stripping is claimed for this failed attempt**. `attempt-postcheck.json` records the observed state. No keypair contents were read. The original source/runtime and offline-preflight seals remain unchanged.

`correction.patch` changes only two runner sites: verify that the selected `cargo` proxy has the already pinned Rustup bytes, then place that proxy directory first in PATH so the inner `cargo +solana` command is interpreted correctly. The outer absolute v1.44 Cargo command, dependency lock, Rust source, SDK, compiler choice, flags and output-retention guards are unchanged. The proposed runner SHA-256 is `1ee5bcb679e8e04ee8abd65f7630571a5577e2dd6d9ccab369a10cdf8f165bd7`.

A read-only `cargo +solana --version` query through the exact proxy and the failed attempt's isolated Rustup home returned `cargo 1.79.0 (804e32543 2025-01-29)`. That query did not compile, resolve packages, install a toolchain or execute a target. The ten existing synthetic path/artifact/mode tests also pass against the proposed runner. This is a launcher correction, not a Rust-source repair: there are no Rust compiler diagnostics yet to justify a source change.

**No retry occurred.** To retry after review, copy the full frozen preflight package to a new isolated location, apply only this runner patch, bind the corrected runner in that copy's new manifest, verify the copy, and use a new output directory. Do not modify either historical sealed package. Original recipe identity and all previous diagnostic limitations remain unresolved.

`python3 -B work/relay-first-build-launcher-correction/verify.py` verifies the sealed evidence, exact patch, source equality and synthetic tests without invoking Cargo, a compiler or the target. It also runs from a copied directory with no repository/tool/cache dependency.
