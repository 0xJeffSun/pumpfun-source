use anchor_lang::prelude::*; use anchor_spl::{associated_token::AssociatedToken,token_interface::{Mint,TokenAccount,TokenInterface}}; use crate::anchor_framework::*;
#[event_cpi]
#[derive(Accounts)]
pub struct SwapThenDistributeV1<'info> {
 #[account(seeds=[b"epoch_tracker_v1",distribution.config_id.as_ref(),distribution.mint.as_ref()],bump=epoch_tracker.bump)]
 pub epoch_tracker:Account<'info,EpochTrackerV1>,
 #[account(seeds=[b"debouncer_v1",distribution.config_id.as_ref(),distribution.mint.as_ref()],bump=debouncer.bump)]
 pub debouncer:Account<'info,DebouncerV1>,
 #[account(mut,close=signer,seeds=[b"distribution_v1",distribution.config_id.as_ref(),distribution.mint.as_ref(),&distribution.epoch.to_le_bytes()],bump=distribution.bump)]
 pub distribution:Account<'info,DistributionV1>,
 #[account(mut,associated_token::mint=mint,associated_token::authority=distribution,associated_token::token_program=token_program)]
 pub distribution_token_account:InterfaceAccount<'info,TokenAccount>,
 #[account(init,payer=signer,associated_token::mint=output_mint,associated_token::authority=distribution,associated_token::token_program=output_mint_program)]
 pub output_distribution_token_account:InterfaceAccount<'info,TokenAccount>,
 #[account(mut,mint::token_program=token_program,address=debouncer.mint)]
 pub mint:Box<InterfaceAccount<'info,Mint>>,
 #[account(mut,mint::token_program=output_mint_program,address=Pubkey::new_from_array(crate::codec::constants::SETTLEMENT))]
 pub output_mint:Box<InterfaceAccount<'info,Mint>>,
 pub output_mint_program:Interface<'info,TokenInterface>,
 #[account(mut,address=Pubkey::new_from_array(crate::codec::constants::RELAYER))]
 pub signer:Signer<'info>,
 pub token_program:Interface<'info,TokenInterface>,
 /// CHECK: Captured fixed Jupiter program address; real CPI enforces privileges.
 #[account(address=Pubkey::new_from_array(crate::codec::constants::JUPITER))]
 pub jupiter_program:AccountInfo<'info>,
 pub associated_token_program:Program<'info,AssociatedToken>,
 pub system_program:Program<'info,System>,
}

use crate::anchor_framework::{Share,DonationEpochClosedV1Event,DonationEpochProcessedV1Event,DonationEpochJustSwappedV1Event};
use crate::tools::checks::check_relayer;
pub fn process<'info>(ctx:Context<'_, '_, 'info, 'info,SwapThenDistributeV1<'info>>,jupiter_swap_ix_data:Vec<u8>,shares:Vec<Share>)->Result<DonationEpochProcessedV1Event> {
            check_relayer(&ctx.accounts.signer)?;
            let remaining=ctx.remaining_accounts;
            let event=crate::settlement_handlers::swap_then_distribute(ctx.accounts,crate::codec::wire::SwapThenDistributeV1 {jupiter_swap_ix_data,shares},remaining)?;
            emit!(event);emit_cpi!(event);Ok(event)
        }
