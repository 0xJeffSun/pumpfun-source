"""UNEXECUTED build-only controller. No runtime or active source writes."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,os,datetime
P=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
a=argparse.ArgumentParser();a.add_argument('--reviewed-control-sha256',required=True);a.add_argument('--launch-build',action='store_true');args=a.parse_args()
assert H(P/'manifest.json')==args.reviewed_control_sha256
m=J(P/'manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and f not in[P/'manifest.json',P/'manifest.sha256']}
for n,h in m.items():assert not(P/n).is_symlink()and H(P/n)==h,n
g=J(P/'inputs.json');assert len(g['source'])==26
for n,h in g['source'].items():assert H(P/'baseline'/n)==h,n
for n,h in g['helpers'].items():assert H(P/'helpers'/n)==h,n
assert g['helpers']['scripts/build_partial_candidate.py']=='bb683621ffc4297c58f030cb03da54484b7370b786fd8eda965a37f4b3198ee9'
assert H(P/'proposal.rs')==g['proposal_sha256']
tools=g['tools']
for v in [*tools['compile_tools'].values(),tools['strip_tool'],tools['cli']]:assert H(Path(v['resolved_path']))==v['sha256']
cache=Path(g['cache']);dep=Path(g['dependency_manifest']);assert H(dep)==g['dependency_manifest_sha256']
def dependencies():return {str(f.relative_to(cache)):H(f)for directory in ['registry/cache','registry/src']for f in(cache/directory).rglob('*')if f.is_file()}
assert dependencies()==J(dep)
if not args.launch_build:print('PASS read-only preflight; build UNRUN; no runtime authorization');raise SystemExit(0)
W=P.parent/'fees-sharing-authorize-build';assert not W.exists(),'One build only; never overwrite a failed attempt';W.mkdir()
def record(name,value):
 with(W/name).open('x')as f:f.write(json.dumps(value,indent=2)+'\n')
def event(value):
 with(W/'events.jsonl').open('a')as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**value})+'\n')
try:
 repo=W/'repo';shutil.copytree(P/'baseline',repo)
 for n in g['helpers']:
  d=repo/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'helpers'/n,d)
 shutil.copy2(P/'proposal.rs',repo/'programs/pump-fees/src/sharing.rs')
 original=P.parents[1]/'work/fees-sharing-fourth-cpi-build/analysis/method/inputs/original.so'
 assert H(original)=='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
 dest=repo/'evidence/original/pump_fees/deployed.so';dest.parent.mkdir(parents=True);shutil.copy2(original,dest)
 source={n:H(repo/n)for n in g['source']};assert[n for n in source if source[n]!=g['source'][n]]==['programs/pump-fees/src/sharing.rs']
 record('preflight.json',{'passed':True,'baseline_source':g['source'],'proposed_source':source,'helper_sha256':g['helpers'],'tool_inputs':tools,'dependencies_sha256':g['dependency_manifest_sha256'],'control_seal':args.reviewed_control_sha256,'build_limit':1,'runtime_authorized':False})
 B=W/'build-01';cmd=[sys.executable,'-B',str(repo/'scripts/build_partial_candidate.py'),'--manifest',str(repo/'programs/pump-fees/Cargo.toml'),'--program','pump_fees','--artifact-name','pump_fees_candidate.so','--tools-version','v1.44','--output',str(B),'--extra-input',str(repo/'programs/pump-fees/README.md')]
 env={**os.environ,'CARGO_HOME':str(cache),'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
 record('launch.json',{'command':cmd,'explicit_tools_version':'v1.44','strip_recipe':'unchanged pinned build-sbf v1.52 strip phase','attempt':1});event({'phase':'build-start'})
 with(W/'build.stdout').open('x')as out,(W/'build.stderr').open('x')as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record('build-exit.json',{'returncode':r.returncode});event({'phase':'build-exit','returncode':r.returncode});r.check_returncode()
 assert {n:H(repo/n)for n in source}==source
 for n,h in g['helpers'].items():assert H(repo/n)==h,n
 for v in [*tools['compile_tools'].values(),tools['strip_tool'],tools['cli']]:assert H(Path(v['resolved_path']))==v['sha256']
 assert dependencies()==J(dep)
 attempt=J(B/'build-attempt.json');assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['selected_toolchain']=='v1.44'
 strip=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy';assert H(strip)==tools['strip_tool']['sha256']and(B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
 for n,h in tools['sdk_template_files'].items():assert H(B/'sdk'/n)==h,n
 log=(B/'build.log').read_text().lower();assert not any(x in log for x in ['stack offset','stack frame','stack size','stack overflow','llvm error','error: function'])
 record('build-only-assessment.json',{'passed':True,'candidate_sha256':H(B/'artifacts/pump_fees_candidate.so'),'symbols_sha256':H(B/'target/sbf-solana-solana/release/pump_fees_candidate.so'),'runtime_executions':0,'next':'root emitted-body review and separate runtime authorization required'})
except BaseException as exc:
 record('controller-exit.json',{'returncode':1,'error_type':type(exc).__name__,'message':str(exc)});event({'phase':'controller-failed'});raise
else:record('controller-exit.json',{'returncode':0});event({'phase':'awaiting-static-review-no-runtime'})
