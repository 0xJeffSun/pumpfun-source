"""UNEXECUTED runtime-only exact existing corpus; no build or new case."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,os,datetime
P=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
a=argparse.ArgumentParser();a.add_argument('--reviewed-control-sha256',required=True);a.add_argument('--run-existing-corpus',action='store_true');args=a.parse_args()
assert H(P/'manifest.json')==args.reviewed_control_sha256
m=J(P/'manifest.json');assert set(m)=={str(f.relative_to(P))for f in P.rglob('*')if f.is_file()and f not in[P/'manifest.json',P/'manifest.sha256']}
for n,h in m.items():assert not(P/n).is_symlink()and H(P/n)==h,n
g=J(P/'bindings.json');B=Path(g['build']);OLD=Path(g['previous_corpus']);cache=Path(g['cache']);dep=Path(g['dependency_manifest'])
def gate():
 for n,h in g['files'].items():assert H(Path(n))==h,n
 for n,h in g['source'].items():assert H(B/'repo'/n)==h,n
 assert len(g['source'])==26 and H(Path(g['candidate']))==g['candidate_sha256']and H(Path(g['symbols']))==g['symbols_sha256']
 assert J(B/'controller-exit.json')['returncode']==J(B/'build-exit.json')['returncode']==0
 for v in [*g['tools']['compile_tools'].values(),g['tools']['strip_tool'],g['tools']['cli']]:assert H(Path(v['resolved_path']))==v['sha256']
 cli=Path(shutil.which('cargo-build-sbf')).resolve();assert str(cli)==g['tools']['cli']['resolved_path']and H(cli)==g['tools']['cli']['sha256']
 assert H(dep)==g['dependency_manifest_sha256'];actual={str(f.relative_to(cache)):H(f)for directory in ['registry/cache','registry/src']for f in(cache/directory).rglob('*')if f.is_file()};assert actual==J(dep)
gate()
if not args.run_existing_corpus:print('PASS preflight only; runtime UNRUN');raise SystemExit(0)
W=P.parent/'fees-sharing-authorize-runtime';assert not W.exists(),'One exact replay; retain all failures';W.mkdir()
def save(n,v):
 with(W/n).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def event(v):
 with(W/'events.jsonl').open('a')as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**v})+'\n')
def run(script,*args):
 cmd=[sys.executable,'-B',str(script),*map(str,args)];event({'command':cmd});p=subprocess.run(cmd,cwd=W,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
 name=str(script.name)+('-'+str(args[0])if args else'');(W/(name+'.stdout')).write_text(p.stdout);(W/(name+'.stderr')).write_text(p.stderr);event({'command_exit':cmd,'returncode':p.returncode});p.check_returncode();return p.stdout
try:
 shutil.copy2(g['candidate'],W/'candidate.so');shutil.copy2(g['symbols'],W/'symbols.so')
 for n in ['runner-repo','validation-layer','reference']:shutil.copytree(OLD/n,W/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 shutil.copy2(OLD/'runtime-frozen-inputs.json',W/'runtime-frozen-inputs.json')
 for n in ['run_runtime.py','check_saved.py','measure_runtime.py','record_diagnostics.py','check_option_coverage.py']:shutil.copy2(P/n,W/n)
 for n,h in g['source'].items():
  dest=W/'source'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'repo'/n,dest);assert H(dest)==h
 (W/'build-01').mkdir();shutil.copy2(B/'build-01/build-comparison.json',W/'build-01/build-comparison.json')
 binding=W/'validation-layer/corrected-source-sha256.json';before=J(binding);binding.write_text(json.dumps(g['source'],indent=2)+'\n');save('runtime-source-rebinding.json',{'before':before,'after':g['source'],'scope':'same unchanged focused20 cases/harness, source hash map only'})
 # Static verifier executes instruction/hash checks only, never a target.
 static=json.loads(run(B/'analysis/verify_static.py'));assert static['passed']and static['candidate_sha256']==g['candidate_sha256'];save('static-gate.json',static)
 save('gate-before.json',g);run(W/'measure_runtime.py','before');run(W/'run_runtime.py')
 run(W/'check_saved.py');run(W/'check_option_coverage.py');run(W/'record_diagnostics.py')
 run(W/'validation-layer/harness/check_retained_diagnostics.py','--report',W/'runtime/differential.json','--output',W/'saved-verification/retained-diagnostics.json');run(W/'measure_runtime.py','after')
 gate()
 for n,h in g['source'].items():assert H(W/'source'/n)==h,n
 r=J(W/'runtime/summary.json');assert len(r['results'])==11 and all(x['passed']and x['returncode']==0 for x in r['results']);assert sum(x['expected_cases']or 0 for x in r['results'])==17461
 assert J(W/'saved-verification/focused-signatures.json')=={'fields':40,'signatures':80}
 assert J(W/'saved-verification/prior.stdout')['verified_signatures_in_encoded_fields']==17204
 save('runtime-only-result.json',{'passed':True,'candidate_sha256':g['candidate_sha256'],'comparisons':17461,'focused20_included':True,'separate_sequence_steps':10,'new_fixtures':0,'new_builds':0,'authority_only_probes':0,'source_tool_dependency_before_after':True})
except BaseException as exc:save('controller-exit.json',{'returncode':1,'type':type(exc).__name__,'message':str(exc)});raise
else:save('controller-exit.json',{'returncode':0})
