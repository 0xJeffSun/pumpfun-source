# Runtime-only controller — UNEXECUTED

Required root-reviewed manifest seal. Default performs read-only frozen source26/candidate2387/symbol/staticbuildcontrol855/CLIselection/tool/dependency preflight. Explicit --run-existing-corpus creates one new work-only replay directory, no compiler or active mutation.

Exact prior admitted run_runtime.py and17461input list retained, focused20 INCLUDED, separate10stepsequence, genuine signed savedhistory/messages and17204+80signature checks unchanged. No authority/admin-only probe or newfixture; missing changed-domain coverage stays explicit. Only focused wrapper sourcehash map rebound to actual snapshot. Static verifier runs before any target. Runtime/helper/cases/source hashes gated before/after, exits append-only events and exclusive terminalrecord. Root must read beforelaunch.
