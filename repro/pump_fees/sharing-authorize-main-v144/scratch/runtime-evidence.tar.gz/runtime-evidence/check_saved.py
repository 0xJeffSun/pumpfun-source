from pathlib import Path
import json,gzip,shutil,subprocess,sys,base64
W=Path(__file__).resolve().parent;R=W/'runtime';V=W/'saved-verification';V.mkdir();(V/'runtime').mkdir()
J=lambda p:json.loads(p.read_text())
for p in R.glob('*.json'):(V/'runtime'/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
shutil.copy2(W/'reference/verify_prior_saved.py',V/'verify_prior_saved.py');(V/'candidate.so').symlink_to(W/'candidate.so');(V/'runner-repo').symlink_to(W/'runner-repo')
p=subprocess.run([sys.executable,'-B',str(V/'verify_prior_saved.py')],capture_output=True,text=True);(V/'prior.stdout').write_text(p.stdout);(V/'prior.stderr').write_text(p.stderr);assert p.returncode==0
from solders.transaction import VersionedTransaction
counts={'fields':0,'signatures':0}
def visit(x):
 if isinstance(x,dict):
  if isinstance(x.get('transaction_base64'),str):
   raw=base64.b64decode(x['transaction_base64']);tx=VersionedTransaction.from_bytes(raw);assert bytes(tx)==raw and all(tx.verify_with_results());counts['fields']+=1;counts['signatures']+=len(tx.signatures)
  for k,v in x.items():
   if k!='transaction_base64':visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(J(R/'focused20.json'));(V/'focused-signatures.json').write_text(json.dumps(counts,indent=2)+'\n')
rows=J(R/'differential.json')['suites']['sharing_creation']['cases'];selected=[]
for row in rows:
 if any('AmmAccountsRequiredForGraduatedCoin' in l for l in row['original']['logs']):selected.append(row)
(V/'missing-pool-coverage.json').write_text(json.dumps({'sharing_creation_cases':len(rows),'original_error6019_rows':selected,'limit':'Existing fixtures only; no new case. First missing-pool versus later missing options must be distinguished using case data, not code alone.'},indent=2)+'\n')
print(p.stdout);print(counts);print('error6019',len(selected))
