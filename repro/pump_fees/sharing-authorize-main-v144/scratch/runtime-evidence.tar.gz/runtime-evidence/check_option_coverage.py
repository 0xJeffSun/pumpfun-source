from pathlib import Path
import json
P=Path(__file__).resolve().parent;J=lambda p:json.loads(p.read_text());rows=J(P/'runtime/differential.json')['suites']['sharing_creation']['cases']
r={'scope':'Only existing unchanged sharing_creation cases; no new fixtures.','case_count':len(rows),'error6019_rows':[],'late_program_or_event_error6019_rows':[],'all_zero_pool_rows':[],'nongraduated_rows':[],'limitations':['The existing builder couples pool=True to all three supplied AMM accounts; missing account-count cases may fail the parser before application checks. Missing late program/event errors need direct recorded evidence; they are not inferred from parser rejection.']}
for row in rows:
 c=row['case'];o=row['original'];summary={'case':c,'match':row['match'],'original_error':o['error'],'candidate_error':row['candidate']['error']}
 if any('AmmAccountsRequiredForGraduatedCoin' in s for s in o['logs']):
  r['error6019_rows'].append(summary)
  if c.get('pool'):r['late_program_or_event_error6019_rows'].append(summary)
 if c.get('tokens',1000)==0 and c.get('pool'):r['all_zero_pool_rows'].append(summary)
 if c.get('tokens',1000)!=0:r['nongraduated_rows'].append(summary)
(P/'saved-verification/option-order-coverage.json').write_text(json.dumps(r,indent=2)+'\n');print({k:len(r[k])for k in ['error6019_rows','late_program_or_event_error6019_rows','all_zero_pool_rows','nongraduated_rows']})
