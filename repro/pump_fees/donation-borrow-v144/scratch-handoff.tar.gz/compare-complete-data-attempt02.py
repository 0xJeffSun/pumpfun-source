"""Rebind the accepted complete data extents to fresh actual handler references."""
from pathlib import Path
import hashlib,json,re,struct,sys
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(W/'analysis-method'))
from elf_reader import Elf
from window_tools import instructions
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
B=Elf(W/'analysis-method/inputs/baseline-candidate.so');C=Elf(W/'candidate.so')
BS=Elf(W/'analysis-method/inputs/baseline-symbols.so');CS=Elf(W/'symbols.so')
Q=R/'repro/pump_fees/donation-borrow-source-proposal'
old=read(Q/'handler-data.json');proof=read(W/'caller-static-proof.json');refs=read(W/'fresh-data-reference-ledger.json')['handler']['candidate']
targets={r['target']for r in refs};out=[]
def shifted_data_address(at):
 names=[n for n,s in B.secs.items()if s[4]<=at<s[4]+s[5]and s[1]==1];assert len(names)==1,names
 name=names[0];return C.secs[name][4]+at-B.secs[name][4]
def rebound_function(pc):
 funcs=[f for f in BS.funcs if f['start']<=pc<f['start']+f['size']];assert funcs
 f=max(funcs,key=lambda x:x['start']);matches=[g for g in CS.funcs if g['name']==f['name']]
 if not matches:
  canonical=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
  matches=[g for g in CS.funcs if canonical(g['name'])==canonical(f['name'])]
 assert len(matches)==1
 g=matches[0];assert f['size']==g['size']and B.normalized[f['start']:f['start']+f['size']]==C.normalized[g['start']:g['start']+g['size']]
 assert B.pattern(f['start'],f['size'])==C.pattern(g['start'],g['size']);return g['start']+pc-f['start']
for row in old:
 if row['side']!='candidate':continue
 n=row['bytes'];at=shifted_data_address(row['target']);data=C.b[at:at+n];role=row['role']
 if role=='business error message':
  pcs=[rebound_function(pc)for pc in row['referenced_by']]
  for pc in pcs:
   ins=instructions(C,pc,24);assert ins[0]['imm64_unsigned']==at and ins[1]['dst']==3 and ins[1]['immediate_signed']==n
 else:
  assert at in targets,(role,at);pcs=[r['pc']for r in refs if r['target']==at]
 item={'role':role,'baseline_target':row['target'],'candidate_target':at,'bytes':n,'hex':data.hex(),'sha256':sha(data),'actual_reference_pcs':pcs,'raw_equal':data.hex()==row['hex']}
 if role=='panic location':
  ptr=struct.unpack_from('<Q',data)[0]>>32;length,line,column=struct.unpack_from('<QII',data,8);filename=C.b[ptr:ptr+length]
  assert filename.hex()==row['filename']['hex']and(line,column)==(row['line'],row['column'])
  item.update(filename={'target':ptr,'bytes':length,'hex':filename.hex(),'text':filename.decode()},line=line,column=column,semantic_fields_equal=True)
 elif 'vtable'in role:
  words=[struct.unpack_from('<Q',data,i)[0]for i in range(0,n,8)];assert words[1:3]==row['words'][1:3];methods=[]
  for i in [0,*range(3,len(words))]:
   a=row['words'][i]>>32;b=words[i]>>32
   if not a:assert not b;continue
   assert rebound_function(a)==b;methods.append({'slot':i,'baseline_target':a,'candidate_target':b,'complete_function_normalized_equal':True})
  item.update(words=words,actual_methods=methods,semantic_fields_equal=True,transitive_implementation_proven=False)
 else:assert item['raw_equal'],role;item['semantic_fields_equal']=True
 out.append(item)
assert targets=={r['candidate_target']for r in out if r['role']!='business error message'}
handler=proof['windows']['handler']['candidate'];ins=instructions(C,handler['start'],handler['size']);inline=[]
for row in read(Q/'inline-objects.json'):
 if row['side']!='candidate':continue
 blob=bytes.fromhex(row['hex']);chunks=[int.from_bytes(blob[i:i+8],'little')for i in range(0,len(blob),8)];pcs=[]
 for v in chunks:
  hits=[i['pc']for i in ins if i.get('imm64_unsigned')==v];assert hits,(row['role'],v);pcs.append(hits)
 inline.append({'role':row['role'],'hex':row['hex'],'matching_actual_immediate_pcs':pcs,'scope':'Complete immediate values retained; this is not a general store/dataflow proof.'})
oldproof=read(W/'analysis-method/inputs/baseline-caller-static-proof.json')
def clone_calls(p):
 result=[]
 for call in p['windows']['handler']['candidate']['direct_calls']:
  names=[f['name']for f in p['direct_target_inventory']['candidate:'+str(call['target'])]['window']['named_symbols']]
  if any('AccountInfo' in n and 'clone' in n for n in names):result.append({'pc':call['pc'],'target':call['target'],'names':names})
 return result
report={'candidate_sha256':sha(C.b),'baseline_sha256':sha(B.b),'complete_handler_direct_data_objects':len(targets),'complete_business_error_messages':6,'objects':out,'inline_values':inline,'baseline_direct_accountinfo_clone_calls':clone_calls(oldproof),'candidate_direct_accountinfo_clone_calls':clone_calls(proof),'limits':['Section-relative address mapping was checked against every actual fresh reference and each complete interpreted extent.','Inlined Rc operations are not counted as direct clone calls. No full handler equality, transitive closure or all-input equivalence claim.']}
(W/'complete-data-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'complete_direct_data_objects':len(targets),'complete_error_messages':6,'baseline_direct_clone_calls':len(report['baseline_direct_accountinfo_clone_calls']),'candidate_direct_clone_calls':len(report['candidate_direct_accountinfo_clone_calls'])}))
