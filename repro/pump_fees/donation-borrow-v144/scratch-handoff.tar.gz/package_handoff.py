"""Package completed source/static/runtime evidence, never build targets or keypairs."""
from pathlib import Path
import gzip, hashlib, json, shutil, tarfile
W=Path(__file__).resolve().parent; R=W.parents[1]; P=W/'handoff'; B=W/'build-01'
H=lambda b:hashlib.sha256(b).hexdigest(); J=lambda p:json.loads(p.read_text())
assert not P.exists()
summary=J(W/'runtime/summary.json'); assert summary['comparison_receipts']==17441 and not summary['mismatches'] and not summary['orchestration_failures']
focus=J(W/'runtime-focused/focused20.json'); assert focus['case_count']==20 and not focus['mismatches']
assert len(J(W/'runtime/retained-diagnostics.json')['rows'])==11
P.mkdir()
def safe(path):
 assert not path.is_symlink() and not path.name.endswith('-keypair.json'), str(path)
def copy(src, rel):
 safe(src); dst=P/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(src.read_bytes())
def save(rel,value):
 dst=P/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text(json.dumps(value,indent=2)+'\n')
def archive(rel,root,hashes):
 with tarfile.open(P/rel,'w:gz') as tar:
  for name,digest in sorted(hashes.items()):
   src=root/name; safe(src); assert H(src.read_bytes())==digest,name; tar.add(src,arcname=name,recursive=False)
# This list is captured before the handoff exists. No build target is traversed.
for f in sorted(W.iterdir()):
 if f.is_file(): copy(f,f.name)
for dirname in ['analysis-method','borrow-analysis-reference','validation-layer','runtime-focused']:
 for f in sorted((W/dirname).rglob('*')):
  if f.is_file():copy(f,f.relative_to(W))
pre=J(W/'prebuild/manifest-sha256.json')
assert H((W/'prebuild/manifest-sha256.json').read_bytes())=='4e7bffb98b4d0e23f5e7a780691f27830b089cc687cdd38013a6443e930ca639'
for n,v in pre.items():
 f=W/'prebuild'/n; safe(f); assert H(f.read_bytes())==v['sha256'] and f.stat().st_size==v['bytes']; copy(f,'prebuild/'+n)
copy(W/'prebuild/manifest-sha256.json','prebuild/manifest-sha256.json')
for n in ['source-sha256.json','baseline-source-sha256.json','source.patch']:copy(W/'prebuild'/n,n)
source=J(P/'source-sha256.json'); base=J(P/'baseline-source-sha256.json')
assert [n for n in source if source[n]!=base[n]]==['programs/pump-fees/src/donation.rs']
assert all(H((R/n).read_bytes())==h for n,h in base.items())
archive('source-snapshot.tar.gz',W/'prebuild/source',source)
archive('baseline-source-snapshot.tar.gz',W/'prebuild/baseline-source',base)
for n in ['build-attempt.json','build-comparison.json']:copy(B/n,'build-01/'+n)
(P/'build-01/build.log.gz').write_bytes(gzip.compress((B/'build.log').read_bytes(),mtime=0))
archive('sbf-sdk-snapshot.tar.gz',B/'sdk',J(B/'build-comparison.json')['sdk_source_sha256'])
copy(W/'candidate.so','pump_fees_candidate.so')
inputs=J(W/'frozen-runner-inputs.json'); harness=inputs['harness_sha256']; runtime=inputs['runtime_sha256']
save('harness-source-sha256.json',harness); save('runtime-inputs.json',runtime)
archive('harness-snapshot.tar.gz',W/'runner-repo',harness)
for n,h in runtime.items():
 f=W/'runner-repo'/n; safe(f); assert H(f.read_bytes())==h; copy(f,'runtime/'+n)
for n in ['summary.json','progress.json','retained-diagnostics.json','retained-diagnostics-launch.json','retained-diagnostics-result.json','retained-diagnostics.log']:copy(W/'runtime'/n,'runtime-'+n)
rows=[]
for row in summary['reports']:
 n=row['name']; raw=(W/'runtime'/(n+'.json')).read_bytes(); encoded=gzip.compress(raw,mtime=0)
 (P/(n+'.json.gz')).write_bytes(encoded); copy(W/'runtime'/(n+'.log'),'runtime-logs/'+n+'.log')
 rows.append({**row,'saved_report':n+'.json.gz','saved_report_sha256':H(encoded),'raw_report_sha256':H(raw),'normalized_source_sha256':source})
save('receipt-build-bindings.json',rows)
old=R/'work/fees-donation-business-build/run-02/handoff/verify_saved_runtime.py'
copy(old,'verify_saved_runtime.py')
save('saved-verifier-origin.json',{'origin':str(old.relative_to(R)),'sha256':H(old.read_bytes()),'byte_unchanged':True})
pub=R/'repro/pump_fees/donation-business-v144'
for n in ['published-harness-sha256.json','published-focused-harness-sha256.json']:copy(pub/n,n)
save('provenance.json',{'scope':'One isolated fixed-recipe source build of exactly two approved AccountInfo clone-to-borrow substitutions. Main source unmodified.','baseline_candidate_sha256':'fc1088f3e25738267a49aaa2b5189f1ab77c487f1023d45fede11e14e5a086b2','candidate_sha256':H((P/'candidate.so').read_bytes()),'candidate_bytes':770016,'symbols_sha256':H((P/'symbols.so').read_bytes()),'source_inputs':26,'compile_tools_version':'v1.44','strip_tools_version':'v1.52','source_build_attempts':1,'source_build_failures':0,'runtime_failures':0,'whole_original_elf_equal':False,'main_source_modified':False,'historical_absolute_paths':'Retained provenance only. Read-only package verification does not require source checkout, work paths, compiler, cache or VM.','excluded_artifacts':'Only explicitly named build records/log, candidate, symbols, rustc-info and SDK source entries were copied. Generated deployment keypairs were never read/hash-opened/copied.'})
save('main-source-proposal.json',{'status':'Parent review required before main promotion.','source_delta_paths':['programs/pump-fees/src/donation.rs'],'donation_rs_sha256':source['programs/pump-fees/src/donation.rs'],'source_patch_sha256':H((P/'source.patch').read_bytes()),'source_inputs':26,'bounded_handlers_unchanged':31,'new_unique_cases':0,'baseline_comparisons':17441,'focused_comparisons':20,'separate_donation_sequence_steps':10,'saved_diagnostic_rows':11,'whole_original_elf_equal':False,'full_handler_normalized_equal':False,'requires_clean_main_build_whole_elf_and_symbol_identity':True,'optional_quote_helper_applied':False})
save('evidence-collection-notes.json',{'focused_process_exit':'Focused process completed with a full successful report and final success log. Its numeric process exit code was not separately persisted; no retrospective numeric exit assertion is made.','focused_source_harness_checks':'Runner checks all26 source inputs before and after execution. Packaging rechecked its four recorded harness hashes and actual source map.','historical_focused_case_labels':'The unchanged case manifest labels12 combinations as new_typed_synthetic_combination relative to the earlier donation-business checkpoint. All20 inputs are repeats in this borrowed-account change.','historical_harness_docstring':'The preserved focused harness says UNEXECUTED proposal in its historical docstring. It was explicitly approved and executed here; the complete receipts supersede that draft status.','static_tool_preparation':'Two read-only data-rebinding tool attempts failed on duplicate linked symbols before actual-pointer selection was made explicit. Logs and both tool sources retained. No source/compiler/runtime variation resulted.'})
print(json.dumps({'packaged_files_before_verifier':sum(p.is_file() for p in P.rglob('*')),'candidate_sha256':H((P/'candidate.so').read_bytes())}))
