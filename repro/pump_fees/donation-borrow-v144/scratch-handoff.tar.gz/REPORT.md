# Fees donation borrowed accounts: isolated validated source build

Exactly the two reviewed `AccountInfo` clone-to-borrow substitutions build and pass the unchanged accepted corpus. No main source was edited. This package requests review of that one-file source proposal; it does not authorize or report main promotion.

The source patch removes the temporary owned copies of `ctx.accounts.pool` and `ctx.accounts.sharing_config`. It changes no guard, account order, data field, event, initializer authorization, runtime fixture or compiler setting. The optional quote-helper fragment is not included. The approved donation source is SHA-256 `540a659ea7d2867db556b2dc95a2b085fb99e4d34d59fc211488c33910d2d40b`, compared with current accepted `a99db3b6156a3009e805ea24ca087d1bea1eb28b90be076dda024f30ac0a14b9`.

## Source and build

One clean isolated build used the unchanged pinned v1.44 compiler and actual v1.52 SDK stripping stage. All 26 inputs, including the current Fees README, were frozen before compilation and checked afterwards. The root Cargo lock, all dependency versions, profile, four build helpers and 53 SDK source files are unchanged. The approved prebuild is included intact under `prebuild/`, manifest SHA-256 `4e7bffb98b4d0e23f5e7a780691f27830b089cc687cdd38013a6443e930ca639`. It binds the reviewed public source proposal, the baseline checkpoint, 252 locked registry packages and the prechecked 13,306 extracted source-file copies. The cache files are not required for saved-evidence verification.

The stripped candidate is 770,016 bytes, SHA-256 `5cf8d567934188d1307d2f9f3d2220ede52f6978e389064b08897441fbdd7d49`. The symbol-bearing ELF is SHA-256 `99ac87e9b79e86e23d7458400475d5d967545e345767d0263d544bfd02660a07`. Both are included. `build-01/`, `cargo-rustc-info.json` and `tool-phase-provenance.json` retain the actual command, exit result, source hashes, log and observed compiler sysroot/strip identity. The build succeeded on its first attempt. There was no binary patch, source padding or compiler/flag/path variant.

The generated deployment keypair was excluded by name before any retention read. Only its path metadata is recorded. No build target tree was archived; only the explicit candidate, symbols, build records, log, rustc-info and SDK source manifest entries were copied.

## Fresh static comparison

Original `create_donation_fee_pda` dispatch identity and every compared address were recovered afresh against this candidate's symbols. The exhaustive ledgers preserve complete windows, calls, relocations and data references, including nonmatches.

| Body | Original start / bytes | Candidate start / bytes | Full normalized and relocation pattern |
| --- | --- | --- | --- |
| Wrapper | 655904 / 928 | 356136 / 928 | Match |
| Account parser | 425776 / 8984 | 134648 / 8984 | Match |
| Donation handler | 163920 / 13800 | 424568 / 12864 | **Does not match** |

The prior candidate's donation handler was 13,592 bytes. Removing these ownership operations reduces it to 12,864; that size change is **not** a whole-body match or a claim of improved byte distance. The prior handler's direct `AccountInfo::clone` call is absent from the new direct call inventory. That observation does not count inlined reference-count operations and does not establish all-input equivalence; theoretical reference-count overflow behavior changes when cloning is removed.

The existing serializer and related gates still pass: 10 complete bodies, 26 direct calls and five literals, plus five account codecs and their 35 actual direct calls. Each codec's documented source-coordinate difference remains. The complete data check rebinds all 19 actual handler data objects and six business-error messages. It compares complete primitive bytes, panic filename/line/column and actual vtable target bodies; literal native-mint/event immediate values are also retained. `complete-data-comparison.json` states the limits on immediate-value and transitive proofs.

The inventory still has 585 inferred original windows and 546 symbol windows. All original-window dispositions are unchanged from `fc1088`: 437 mapped, 145 unattributed, three call conflicts. Candidate dispositions remain 438 normalized/call-consistent, 105 unmatched, three conflicts. The 272 immediate-call residuals, 122 candidate indirect calls and all ambiguous matches remain explicit. These windows are not a proved historical source-function denominator.

Two read-only data-analysis preparation attempts initially failed because duplicate linked symbols invalidated a unique-name lookup assumption. Their sources and logs are retained. The completed tool uses each actual vtable pointer to choose the target and checks its entire body; it does not select an unused same-name match. No target source, build or transaction was changed for this analysis repair.

## Fresh runtime evidence

The fresh candidate passed all 17,441 baseline comparisons: the unchanged 18-suite aggregate contains 17,331, with the eight existing supplemental reports accounting for the other 110. The separate ten-step donation sequence also passed. Every baseline job exited zero, with before/after checks on the copied 26 source, 46 harness and 18 runtime inputs. `receipt-build-bindings.json` binds each complete saved report to the exact compiler input map, build report and candidate. These are new executions, not inherited receipts.

The exact accepted focused20 also passed, with 40 transactions and 80 verified ordinary test-owned signatures. The four focused harness files and all case/account/guard/assertion bytes are unchanged. Only the expected source/build map was updated. The old source-map README value referred to the predecessor scratch source; the new map correctly binds the accepted current README. The focused cases use fresh VMs with signature and blockhash checking and default history. Their saved assertions compare state before/after, events, inner instructions, return data, errors and semantic logs, with exact rollback and expected outcomes. Raw logs are retained; source coordinates and compute-unit lines remain the established exclusions from semantic log equality.

The focused numeric process exit code was not separately persisted. The complete successful report and its final zero-mismatch JSON log were saved, and the portable verifier recomputes every focused assertion and verifies every encoded signature. This distinction is retained in `evidence-collection-notes.json`; no exit code is reconstructed.

The unchanged strict diagnostic postprocessor passes all 11 existing saved cases. The unchanged saved-runtime verifier checks the two genuine historical signed messages byte-for-byte, freshness rejection, existing compared-value and authority logs, codec errors, signed transfers and serialization rollback. It cryptographically verifies 17,204 signatures in 8,644 encoded baseline/sequence fields; the focused20 adds 80 signatures in 40 fields. Two historical signatures are checked separately. Some older baseline reports retain signature-check assertions rather than full transaction encodings, so these totals describe the saved fields, not every execution in the corpus.

There are **zero newly unique cases** in this change. All focused20 inputs already existed at the prior donation-business checkpoint (whose unchanged manifest labels eight as repeats and 12 as then-new combinations). The 31 bounded Fees-handler count is unchanged. The ten sequence steps are separate from comparison totals. No initializer-success fixture, altered historical payload, PDA signer substitution, private input or live-chain operation was added.

## Verification and proposed next step

Run from any directory with Python and the accepted `solders` package available:

```sh
python /path/to/handoff/verify.py
```

To additionally check that current main still has the unmodified baseline source and published harness/runtime/build-helper inputs:

```sh
python /path/to/handoff/verify.py --repo /path/to/repository
```

The verifier checks the package seal, exact source delta, actual build inputs/phases, complete fresh static ledgers, complete data objects, saved expected outcomes and signatures. It executes no SBF, build, network operation or new transaction. The copied check requires no original work directory, compiler cache or local Surfpool executable. Historical absolute paths are retained only as execution provenance.

`main-source-proposal.json` records the minimal pending promotion. A separate clean main-source build and whole stripped/symbol ELF identity would be required before carrying these receipts into a main publication. Full original-ELF equality remains false; historical source identity, full call/data closure and the security audit remain incomplete. All previously stopped lanes remain stopped.

The completed portability checks passed from a copy outside the checkout. The verifier rejected a missing captured original, an omitted source input even after outer re-sealing, and an altered focused transaction even after outer re-sealing. `verification/` preserves the exact pre-final tested manifest and reports; the final seal additionally includes these verification records. No negative test altered the source package.
