"""One parent-approved build of the sealed two-line source change."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'prebuild';B=W/'build-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def out(n,j):(W/n).write_text(json.dumps(j,indent=2)+'\n')
assert not B.exists()
assert sha(P/'manifest-sha256.json')=='4e7bffb98b4d0e23f5e7a780691f27830b089cc687cdd38013a6443e930ca639'
v=subprocess.run([sys.executable,'-B',str(P/'verify.py'),'--repo',str(R),'--recheck-environment'],cwd=R,capture_output=True,text=True)
(W/'prelaunch-verification.stdout').write_text(v.stdout);(W/'prelaunch-verification.stderr').write_text(v.stderr);v.check_returncode()
plan=json.loads((P/'build-plan.json').read_text());tools=json.loads((P/'tools-recheck.json').read_text())
out('build-launch.json',{'approved_prebuild_seal':sha(P/'manifest-sha256.json'),'command':plan['command'],'cwd':plan['cwd'],'environment':plan['environment'],'runner_sha256':sha(Path(__file__)),'scope':'One authorized build, no variations. Actual compiler/strip identities must be measured after completion.'})
env={**os.environ,**plan['environment']};result=subprocess.run(plan['command'],cwd=plan['cwd'],env=env,capture_output=True,text=True)
(W/'build-launch.stdout').write_text(result.stdout);(W/'build-launch.stderr').write_text(result.stderr)
source=json.loads((P/'source-sha256.json').read_text());base=json.loads((P/'baseline-source-sha256.json').read_text())
current={n:sha(P/'source'/n)for n in source};unchanged_main={n:sha(R/n)for n in base}==base
out('build-result.json',{'returncode':result.returncode,'source_after_sha256':current,'source_unchanged':current==source,'main_source_unchanged':unchanged_main})
assert result.returncode==0 and current==source and unchanged_main
report=json.loads((B/'build-comparison.json').read_text());assert report['source_sha256']==plan['actual_prospective_source_sha256']and len(report['source_sha256'])==26
info=json.loads((B/'target/.rustc_info.json').read_text());roots={s for v in info['outputs'].values()for s in v.get('stdout','').splitlines()if s.startswith('/')and s.endswith('/rust')};assert len(roots)==1
compiler=Path(roots.pop());actual={}
for name,v in tools['compile_tools'].items():
 p=compiler.parent/name;assert sha(p)==v['sha256'];actual[name]={'resolved_path':str(p.resolve()),'sha256':sha(p)}
strip=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy';assert sha(strip)==tools['strip_tool']['sha256']and(B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
for n,h in tools['helper_files'].items():assert sha(R/n)==h
for n,h in tools['sdk_template_files'].items():assert sha(B/'sdk'/n)==h
for n,v in tools['compile_tools'].items():assert sha(Path(v['resolved_path']))==v['sha256']
assert sha(Path(tools['cli']['resolved_path']))==tools['cli']['sha256']
symbols=B/'target/sbf-solana-solana/release/pump_fees_candidate.so';candidate=B/'artifacts/pump_fees_candidate.so'
shutil.copyfile(symbols,W/'symbols.so');shutil.copyfile(candidate,W/'candidate.so')
shutil.copyfile(B/'target/.rustc_info.json',W/'cargo-rustc-info.json')
out('tool-phase-provenance.json',{'scope':'Actual cargo rustc_info sysroot and observed unchanged SDK stripping stage, with matching pre/post tool hashes. No claimed historical pipeline identity.','compile':{'requested_tools_version':'v1.44','observed_sysroot':str(compiler),'tool_files':actual,'cargo_rustc_info_sha256':sha(W/'cargo-rustc-info.json'),'unstripped_sha256':sha(symbols)},'strip':{'expected_version':'v1.52','sdk_marker':'platform-tools-v1.52.md','resolved_path':str(strip.resolve()),'sha256':sha(strip),'candidate_sha256':sha(candidate)},'cli':tools['cli'],'sdk_template_files':tools['sdk_template_files'],'helper_files':tools['helper_files'],'excluded_generated_artifact_paths':[str(p.relative_to(B))for p in(B/'artifacts').iterdir()if p.name.endswith('-keypair.json')],'excluded_policy':'Generated keypair names only; contents never opened/read/hashed/copied.'})
assert sha(P/'manifest-sha256.json')=='4e7bffb98b4d0e23f5e7a780691f27830b089cc687cdd38013a6443e930ca639'
print(json.dumps({'built':True,'candidate_sha256':sha(candidate),'candidate_bytes':candidate.stat().st_size,'symbols_sha256':sha(symbols),'source_inputs':26,'compiler':'v1.44','stripper':'v1.52','full_original_byte_equality':report['comparison']['full_byte_equality']},indent=2))
