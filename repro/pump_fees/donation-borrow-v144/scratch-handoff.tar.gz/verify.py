#!/usr/bin/env python3
"""Read-only source, build, static and saved-receipt checks; no VM or compilation."""
from pathlib import Path, PurePosixPath
import argparse, base64, collections, difflib, gzip, hashlib, json, runpy, shutil, subprocess, sys, tarfile, tempfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def raw(name):
 p=PurePosixPath(name); assert not p.is_absolute() and '..' not in p.parts and not p.name.endswith('-keypair.json')
 f=P/p; assert not f.is_symlink(); return f.read_bytes()
def read(name):return json.loads(raw(name))
def run(script,args=(),cwd=None):
 p=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],cwd=cwd,capture_output=True,text=True)
 assert p.returncode==0,(script,p.stdout,p.stderr)
 return p.stdout
def archive(name,expected):
 with tarfile.open(P/name) as t:
  members=t.getmembers()
  assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and not PurePosixPath(m.name).name.endswith('-keypair.json') for m in members)
  data={m.name:t.extractfile(m).read() for m in members}; assert len(data)==len(members)
 assert {n:H(v) for n,v in data.items()}==expected,name
 return data
def main():
 ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--repo',type=Path); a=ap.parse_args()
 files=[]
 for f in P.rglob('*'):
  assert not f.is_symlink()
  if f.is_file() and f!=P/'manifest-sha256.json':
   assert not f.name.endswith('-keypair.json'); files.append(f.relative_to(P).as_posix())
 manifest=read('manifest-sha256.json')
 assert set(files)==set(manifest),'Package file inventory mismatch'
 assert {n:H(raw(n)) for n in files}==manifest,'Package payload hash mismatch'
 C_SHA='5cf8d567934188d1307d2f9f3d2220ede52f6978e389064b08897441fbdd7d49'
 S_SHA='99ac87e9b79e86e23d7458400475d5d967545e345767d0263d544bfd02660a07'
 O_SHA='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
 assert H(raw('prebuild/manifest-sha256.json'))=='4e7bffb98b4d0e23f5e7a780691f27830b089cc687cdd38013a6443e930ca639'
 run(P/'prebuild/verify.py',cwd='/')
 source=read('source-sha256.json'); base=read('baseline-source-sha256.json'); assert len(source)==len(base)==26
 assert source==read('prebuild/source-sha256.json') and base==read('prebuild/baseline-source-sha256.json')
 before=archive('baseline-source-snapshot.tar.gz',base); after=archive('source-snapshot.tar.gz',source)
 target='programs/pump-fees/src/donation.rs'; assert [n for n in source if source[n]!=base[n]]==[target]
 for n in source:assert after[n]==raw('prebuild/source/'+n) and before[n]==raw('prebuild/baseline-source/'+n)
 assert ''.join(difflib.unified_diff(before[target].decode().splitlines(True),after[target].decode().splitlines(True),fromfile='a/'+target,tofile='b/'+target)).encode()==raw('source.patch')==raw('prebuild/source.patch')
 build=read('build-01/build-comparison.json'); attempt=read('build-01/build-attempt.json'); prefix='work/fees-donation-borrow-build/prebuild/source/'
 assert build['source_sha256']==read('prebuild/actual-prospective-build-inputs.json')
 assert all(n.startswith(prefix) for n in build['source_sha256'])
 assert {n[len(prefix):]:h for n,h in build['source_sha256'].items()}==source
 assert attempt['returncode']==0 and attempt['source_unchanged'] and attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256']
 assert H(gzip.decompress(raw('build-01/build.log.gz')))==attempt['build_log_sha256']==build['build_log_sha256']
 assert read('build-result.json')=={'returncode':0,'source_after_sha256':source,'source_unchanged':True,'main_source_unchanged':True}
 plan=read('prebuild/build-plan.json'); launch=read('build-launch.json')
 assert launch['command']==plan['command'] and launch['environment']==plan['environment'] and launch['runner_sha256']==H(raw('run_build_once.py'))
 C=raw('candidate.so'); O=raw('analysis-method/inputs/original.so'); S=raw('symbols.so')
 assert C==raw('pump_fees_candidate.so') and H(C)==C_SHA and len(C)==770016 and H(O)==O_SHA and H(S)==S_SHA
 comparison={'original_bytes':len(O),'candidate_bytes':len(C),'original_sha256':H(O),'candidate_sha256':H(C),'full_byte_equality':O==C,'first_difference':next((i for i,(x,y) in enumerate(zip(O,C)) if x!=y),None),'different_positions_in_shared_length':sum(x!=y for x,y in zip(O,C)),'length_difference':len(C)-len(O)}
 assert comparison==build['comparison'] and not comparison['full_byte_equality']
 sdk=archive('sbf-sdk-snapshot.tar.gz',build['sdk_source_sha256']); assert len(sdk)==53
 phase=read('tool-phase-provenance.json'); tools=read('prebuild/tools-recheck.json')
 assert phase['compile']['requested_tools_version']=='v1.44' and phase['compile']['unstripped_sha256']==S_SHA
 assert phase['compile']['cargo_rustc_info_sha256']==H(raw('cargo-rustc-info.json'))
 roots={line for v in read('cargo-rustc-info.json')['outputs'].values() for line in v.get('stdout','').splitlines() if line.startswith('/') and line.endswith('/rust')}
 assert roots=={phase['compile']['observed_sysroot']}
 assert {n:v['sha256'] for n,v in phase['compile']['tool_files'].items()}=={n:v['sha256'] for n,v in tools['compile_tools'].items()}
 assert phase['strip']['sdk_marker']=='platform-tools-v1.52.md' and phase['strip']['sha256']==tools['strip_tool']['sha256']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
 assert phase['strip']['candidate_sha256']==C_SHA and phase['cli']==tools['cli']
 assert phase['helper_files']==tools['helper_files'] and phase['sdk_template_files']==tools['sdk_template_files']==build['sdk_source_sha256']
 for n,h in phase['helper_files'].items():assert H(raw('prebuild/build-helper-snapshot/'+n))==h
 for n,h in phase['sdk_template_files'].items():assert H(sdk[n])==h
 for n,h in read('analysis-inputs-sha256.json').items():assert H(raw(n))==h
 for n,value in runpy.run_path(str(P/'inspect_candidate.py'))['run']().items():assert value==read(n),n
 retained=read('retained-static-gate.json'); assert runpy.run_path(str(P/'verify_retained.py'))['run']()==retained and retained['all_retained_gates_passed']
 inv=read('full-function-inventory.json'); assert len(inv['original_rows'])==585 and len(inv['candidate_rows'])==546
 assert all(r['baseline_status']==r['candidate_status'] for r in read('inventory-vs-fc1088.json')['original_rows'])
 proof=read('caller-static-proof.json'); assert not proof['whole_original_equal'] and not proof['windows']['handler']['comparison']['normalized_equal']
 assert proof['windows']['handler']['original']['size']==13800 and proof['windows']['handler']['candidate']['size']==12864
 for n in ['wrapper','parser']:assert proof['windows'][n]['comparison']['normalized_equal'] and proof['windows'][n]['comparison']['relocation_pattern_equal']
 assert len(proof['direct_target_inventory'])==84 and len(proof['exact_handler_logs'])==4
 for r in proof['strip_sections']:
  if r['allocated']:assert r['equal']
 with tempfile.TemporaryDirectory(prefix='fees-borrow-readonly-') as temp:
  temp=Path(temp); scratch=temp/'static'; scratch.mkdir()
  for n in ['candidate.so','symbols.so','caller-static-proof.json','fresh-data-reference-ledger.json','compare_complete_data.py']:shutil.copyfile(P/n,scratch/n)
  for n in ['analysis-method','borrow-analysis-reference']:shutil.copytree(P/n,scratch/n)
  run(scratch/'compare_complete_data.py',cwd=temp)
  assert json.loads((scratch/'complete-data-comparison.json').read_text())==read('complete-data-comparison.json')
  data=read('complete-data-comparison.json'); assert data['complete_handler_direct_data_objects']==19 and data['complete_business_error_messages']==6
  assert len(data['baseline_direct_accountinfo_clone_calls'])==1 and not data['candidate_direct_accountinfo_clone_calls']
  for r in data['objects']:assert r['semantic_fields_equal']
  harness=read('harness-source-sha256.json'); runtime=read('runtime-inputs.json'); assert len(harness)==46 and len(runtime)==18
  archive('harness-snapshot.tar.gz',harness)
  for n,h in runtime.items():assert H(raw('runtime/'+n))==h
  frozen=read('frozen-runner-inputs.json'); assert frozen['source_sha256']==source and frozen['harness_sha256']==harness and frozen['runtime_sha256']==runtime
  assert frozen['focused_cases_sha256']==H(raw('validation-layer/cases.json')) and frozen['focused_source_map_sha256']==H(raw('validation-layer/corrected-source-sha256.json'))
  runtime_launch=read('runtime-launch.json'); assert runtime_launch['runner_sha256']==H(raw('run_regressions.py')) and runtime_launch['prior_orchestration_sha256']==H(raw('prior-run-regressions.py'))
  assert runtime_launch['actual_compiler_inputs']==build['source_sha256'] and runtime_launch['build_report_sha256']==H(raw('build-01/build-comparison.json'))
  rows=read('receipt-build-bindings.json'); assert len(rows)==10
  for r in rows:
   encoded=raw(r['saved_report']); decoded=gzip.decompress(encoded); d=json.loads(decoded)
   assert H(encoded)==r['saved_report_sha256'] and H(decoded)==r['raw_report_sha256']==r['report_sha256']
   assert d['candidate_sha256']==C_SHA and d['original_sha256']==O_SHA and not d['mismatches']
   assert r['candidate_sha256']==C_SHA and r['normalized_source_sha256']==source and r['actual_compiler_inputs']==build['source_sha256']
   assert r['build_report_sha256']==H(raw('build-01/build-comparison.json')) and r['returncode']==0 and r['passed']
  summary=read('runtime-summary.json'); assert summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and not summary['mismatches'] and not summary['orchestration_failures']
  out=temp/'diagnostics.json'; run(P/'validation-layer/harness/check_retained_diagnostics.py',['--report',P/'differential.json.gz','--output',out],cwd=temp)
  diagnostic=json.loads(out.read_text()); saved=read('runtime-retained-diagnostics.json')
  assert diagnostic['rows']==saved['rows'] and len(saved['rows'])==11 and not diagnostic['mismatches'] and not saved['mismatches']
  assert saved['input_sha256']==H(gzip.decompress(raw('differential.json.gz'))) and saved['candidate_sha256']==C_SHA
  assert read('runtime-retained-diagnostics-result.json')['returncode']==0
  assert read('saved-verifier-origin.json')['sha256']==H(raw('verify_saved_runtime.py'))
  sig=json.loads(run(P/'verify_saved_runtime.py',cwd=temp)); assert sig==read('runtime-verification-result.json')
 focused=read('runtime-focused/focused20.json'); layer=P/'validation-layer'
 assert focused['source_sha256']==source==read('validation-layer/corrected-source-sha256.json') and focused['candidate_sha256']==C_SHA and focused['original_sha256']==O_SHA
 binding=read('validation-layer/current-build-binding.json')
 assert focused['build_record']==binding and focused['build_record_sha256']==H(raw('validation-layer/current-build-binding.json'))
 assert binding['source_sha256']==source and binding['actual_source_sha256']==build['source_sha256'] and binding['candidate_sha256']==C_SHA and binding['symbols_sha256']==S_SHA
 assert binding['build_comparison_sha256']==H(raw('build-01/build-comparison.json')) and binding['build_attempt_sha256']==H(raw('build-01/build-attempt.json')) and binding['tool_phase_sha256']==H(raw('tool-phase-provenance.json'))
 assert binding['prebuild_seal']==H(raw('prebuild/manifest-sha256.json'))
 assert focused['case_manifest_sha256']==H(raw('validation-layer/cases.json'))
 h={f.name:H(f.read_bytes()) for f in (layer/'harness').glob('*.py')}; assert focused['harness_sha256']==h
 assert frozen['focused_harness']==h
 assert {Path(n).name:v for n,v in read('published-focused-harness-sha256.json').items()}==h
 update=read('validation-layer/source-binding-update.json'); assert update['after']==source
 assert set(n for n in source if update['before'][n]!=source[n])=={'programs/pump-fees/README.md',target}
 assert focused['case_count']==20 and focused['transaction_count']==40 and focused['signature_count']==80 and not focused['mismatches']
 assert focused['runtime']=={'signature_verification':True,'blockhash_check':True,'history':'default enabled; fresh VM per case'}
 functions=runpy.run_path(str(layer/'harness/assertions.py')); roles=focused['roles']; cases=read('validation-layer/cases.json')
 assert [r['case'] for r in focused['cases']]==cases and collections.Counter(r['input_provenance'] for r in cases)=={'existing_input_repeat':8,'new_typed_synthetic_combination':12}
 from solders.transaction import VersionedTransaction
 txs=sigs=0
 for r in focused['cases']:
  assert r['match'] and not r['mismatches'] and not any(r['expected_failures'].values())
  assert functions['comparable'](r['original'],roles['PROGRAM']['str'])==functions['comparable'](r['candidate'],roles['PROGRAM']['str'])
  assert r['raw_logs_equal']==(r['original']['logs']==r['candidate']['logs'])
  for side in ['original','candidate']:
   value=r[side]; assert not functions['check_expected'](value,r['case'],roles)
   assert value['signature_verification']==[True,True] and set(value['message_account_keys'][:2])=={roles['PAYER']['str'],roles['AUTH']['str']}
   b=base64.b64decode(value['transaction_base64']); tx=VersionedTransaction.from_bytes(b)
   assert bytes(tx)==b and tx.verify_with_results()==[True,True] and [str(k) for k in tx.message.account_keys]==value['message_account_keys']
   txs+=1; sigs+=len(tx.signatures)
 assert (txs,sigs)==(40,80)
 post=read('runtime-postcheck.json'); assert all(post[n] for n in ['source_unchanged','runner_source_harness_runtime_unchanged','focused_harness_unchanged','focused_complete_report_pass'])
 assert post['focused_report_sha256']==H(raw('runtime-focused/focused20.json'))
 if a.repo:
  repo=a.repo.resolve()
  for n,h in {**base,**read('published-harness-sha256.json'),**read('published-focused-harness-sha256.json'),**runtime,**tools['helper_files']}.items():
   assert not Path(n).name.endswith('-keypair.json') and H((repo/n).read_bytes())==h,('current baseline input',n)
 print(json.dumps({'verified':True,'sealed_files':len(manifest),'source_inputs':26,'source_build_attempts':1,'candidate_sha256':C_SHA,'baseline_comparisons':17441,'focused_comparisons':20,'new_unique_cases':0,'separate_donation_steps':10,'saved_diagnostic_rows':11,'saved_encoded_transaction_fields':sig['encoded_transaction_fields']+txs,'verified_signatures_in_saved_fields':sig['verified_signatures_in_encoded_fields']+sigs,'separately_verified_unchanged_historical_transactions':2,'original_inferred_windows':585,'candidate_symbol_windows':546,'handler_normalized_equal':False,'whole_original_elf_equal':False,'current_baseline_inputs_checked':bool(a.repo)},indent=2))
if __name__=='__main__':main()
