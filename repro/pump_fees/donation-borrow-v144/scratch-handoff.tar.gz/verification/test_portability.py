"""Exercise saved-evidence verification only; never runs transactions or builds."""
from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, sys, tempfile
W=Path(__file__).resolve().parent; P=W/'handoff'
H=lambda b:hashlib.sha256(b).hexdigest()
initial=H((P/'manifest-sha256.json').read_bytes()); rows=[]
def test(label,package,expected):
 p=subprocess.run([sys.executable,'-B',str(package/'verify.py')],cwd='/',capture_output=True,text=True)
 row={'name':label,'expected_pass':expected,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'passed':(p.returncode==0)==expected}
 rows.append(row); assert row['passed'],row
def update_manifest(package,name):
 path=package/'manifest-sha256.json'; value=json.loads(path.read_text()); value[name]=H((package/name).read_bytes()); path.write_text(json.dumps(value,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='fees-borrow-portable-') as temp:
 temp=Path(temp)
 copy=temp/'positive';shutil.copytree(P,copy);test('copy outside checkout',copy,True)
 missing=temp/'missing';shutil.copytree(P,missing);(missing/'runtime/evidence/original/pump_fees/deployed.so').unlink();test('missing captured original',missing,False)
 source=temp/'source';shutil.copytree(P,source)
 name='source-sha256.json'; path=source/name; value=json.loads(path.read_text());value.pop('programs/pump-fees/README.md');path.write_text(json.dumps(value,indent=2)+'\n');update_manifest(source,name)
 test('source input omitted and outer seal recomputed',source,False)
 receipt=temp/'receipt';shutil.copytree(P,receipt)
 name='runtime-focused/focused20.json';path=receipt/name;value=json.loads(path.read_text());value['cases'][0]['original']['transaction_base64']='AAAA';path.write_text(json.dumps(value,indent=2)+'\n');update_manifest(receipt,name)
 test('focused transaction altered and outer seal recomputed',receipt,False)
assert H((P/'manifest-sha256.json').read_bytes())==initial
result={'tested_manifest_sha256':initial,'operations':'Saved verification only; no SBF or new transactions. Negative mutations affect disposable copies only.','checks':rows,'all_passed':all(r['passed'] for r in rows)}
(W/'portable-handoff-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_passed':result['all_passed'],'checks':len(rows)}))
