#!/usr/bin/env python3
from pathlib import Path
import ast,hashlib,json,tarfile
P=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((P/n).read_text())
seal=read('manifest-sha256.json');assert{str(p.relative_to(P)):H(p.read_bytes())for p in P.rglob('*')if p.is_file()and p!=P/'manifest-sha256.json'}==seal
for name,binding in read('input-bindings.json').items():assert H((P/'inputs'/name).read_bytes())==binding['sha256']
proposal=read('inputs/proposal-manifest.json')['files']
assert H((P/'inputs/proposal-helper.py').read_bytes())==proposal['proposed_core_linux_v144_build.py']
assert H((P/'inputs/current-helper.py').read_bytes())==proposal['prior-helper/core_linux_v144_build.py']
assert H((P/'inputs/current-pins.json').read_bytes())==proposal['prior-helper/core_linux_v144_inputs.json']
assert H((P/'inputs/current-tests.py').read_bytes())==proposal['prior-helper/test_core_linux_v144_retention.py']
old=ast.parse((P/'inputs/current-helper.py').read_text());new=ast.parse((P/'inputs/proposal-helper.py').read_text())
gates=['generated_keypair_path','tree_hashes','excluded_keypair_paths','source_hashes','prepare_compile_inputs','retain_generated_outputs','seal_evidence','snapshot_source','dependency_inventory','compare_after_build']
defs=lambda t:{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
assert all(ast.dump(defs(old)[n])==ast.dump(defs(new)[n])for n in gates)
source=(P/'inputs/proposal-helper.py').read_text();selector=next(n.value for n in ast.walk(new)if isinstance(n,ast.Constant)and isinstance(n.value,str)and n.value.startswith('trace=execve,'))
assert all(n not in selector.split('=')[1].split(',')for n in ['fork','vfork','clone','clone3'])
assert 'len(archives) != 1 or len(sources) != 1'in source
obs=read('inputs/cache-observation.json');assert'index.crates.io-1949cf8c6b5b557f'in obs['selected_package']['manifest_path']
assert H((P/'inputs/actual-sbf-pubkey.d').read_bytes())==obs['sbf_depfile_sha256']and'index.crates.io-6f17d22bba15001f'in(P/'inputs/actual-sbf-pubkey.d').read_text()
assert 'attempting to make an HTTP request, but --offline was specified'in(P/'inputs/prior-cache-failure.log').read_text()
with tarfile.open(P/'inputs/recorded-sdk.tar.gz')as t:
 scripts=[m for m in t if'/scripts/'in m.name];assert len(scripts)==5 and all(m.mode==0o755 for m in scripts)
modes=read('sdk-mode-check.json');assert modes['copied_sdk_files_verified']==53 and not modes['scripts_executed']
for row in read('metadata/retrievals.json'):
 assert row['returncode']==0 and H((P/'metadata'/row['file']).read_bytes())==row['sha256']
assert read('proposal-verification.json')['returncode']==0
print(json.dumps({'verified':True,'sealed_files':len(seal),'unchanged_gates':10,'findings':2,'sdk_scripts_mode_0755':5,'source_changes':0,'compiler_or_tracer_executions':0,'runner_strace_ptrace_readiness':'not established by metadata; preflight required'},indent=2))
