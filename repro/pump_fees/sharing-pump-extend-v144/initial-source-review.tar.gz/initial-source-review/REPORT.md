# First sharing-create Pump extension CPI: narrow typed-context proposal

## Finding and scope

The manual CPI is not ownership-equivalent to the original generated helper: it owns five AccountInfos and an eight-byte data vector, whereas the original owns a typed context, constructs its account-info vector, appends a separate context program AccountInfo, and allocates a256-byte data buffer. A blind conversion using the current IDL would also change the extension payer metadata from writable to readonly.

The exact two-file proposal restores **only the first Pump `extend_account` call** with the existing generated `crate::pump::cpi::extend_account(CpiContext::new(...))` API, and adds `writable:true` to `extend_account.user` in the Fees-local pump.json. That field restores original metadata; it is not a safety adjustment. The other three manual calls and their helpers remain unchanged. No build, runtime or main edit was performed.

## Complete retained evidence

Inputs bind original4f2955d0..., current executable4baf4866909828f5017a86e595a72dc7f47b443ad4623597b2d532f9ca57778e, symbols6cd45b521ac233e1396d794e9f44baec04d8d6814f3b527e38a0c25f50ab56cc, and all26 current source inputs. Full original application177720..190104, parser445160, Pump program parser73544, CPI helpers552776/556488/579040, metadata helpers571320/572392, AccountInfo clone63024, invoke adapter724336, current application509160..521944 and manual invoke helper88296 are included. Full original/current inventory retains every call/data reference and unresolved classification. Bound Anchor context and generator sources are copied from the existing dependency cache; no dependency was run or fetched.

## Argument and target correspondence

Original parser447280 calls73544. That full Program<T> parser compares the account key against the32-byte Pump ID at806637 and requires executable. Its success pointer447288 is saved at447320 tostack-3264, reloaded455696 and stored455704 tocontext1496. Application181584 selects this validated program and begins cloning it before the ordinary accounts. The first account is the bonding-curve AccountInfo atcontext328 (181752), followed by payer1480 (182008), system program1488 and Pump event authority1208, then the same program field. These named fields have complete parser context in the retained body and match the currently compiled source account declarations.

The original context's accounts start at+72, proven by552984/552992 before its metadata helper571320 at553032. The helper receives the five-account typed structure in declaration order. The first Pump call enters552776 at183904. Its data buffer capacity is256 (allocation setup552824), discriminator552960 is `ea66c2cb96483ee5`, the exact no-argument `extend_account` discriminator. Original helper invokes724336 at555120 using the context's program key, account metas, account infos, and signer seeds. The proposed `CpiContext::new` supplies the already-validated Pump program; no signer seeds or remaining accounts are added.

## Metadata blocker and minimal IDL repair

The full original metadata helper571320..572392 writes five packed34-byte AccountMeta records. Flag words at571528/571736/571936/572136/572328 are256,257,0,0,0. With key32 + is_signer byte + is_writable byte this is `(false,true),(true,true),(false,false),(false,false),(false,false)`.

Current manual flags are already exactly those values. Current pump.json declares account writable, user signer, and all others readonly; user lacks writable. Thus calling its generated helper unchanged would incorrectly make user readonly. The proposed single `writable:true` field brings generated metadata into agreement with the original and current manual flags. Parsed-JSON comparison in verify.py proves this is the only IDL data change. The AMM extension interface has the same readonly discrepancy, but is deliberately left untouched because its manual call is not changed in this proposal.

## Ownership, allocation and cleanup support

Original application begins with the separate program clone, then the five typed account fields. Original helper constructs AccountMeta vector through571320 and AccountInfo vector from the typed accounts. At554624 onward it increments refcounts for the separate context program and writes the appended48-byte AccountInfo at555024;555064 increments the account-info count before invoke555120. Signer-seed pointers are read from context+312/+320 at555032/555040. No PDA signer is invented.

After invoke,555128..555264 stores either success or converted error, then both outcomes enter the full cleanup continuation. The AccountInfo drop loop555272..555528 decrements the two shared reference counters per48-byte item;555536 onward and the remainder through556480 clean the owned context/account members and return the stored result. The complete function is retained, not a fragment claimed as total cleanup equivalence. The manual helper owns a prebuilt Vec and has no separate CpiContext program member or generated accounts-to-infos clone pass.

The bound Anchor generator has the corresponding natural structure: capacity256 data allocation, discriminator/serialization, `ctx.to_account_metas(None)`, program from `ctx.program.key()`, `ctx.to_account_infos()`, and `invoke_signed(...,ctx.signer_seeds)`. Bound CpiContext::new owns the supplied program and account structure, empty remaining accounts and empty signer seeds. Its `to_account_infos` clones typed fields in order and appends `self.program.clone()`. The account generator honors `constraints.is_mutable()` and preserves account declaration order. This supports using the existing API instead of reproducing its allocation/drop layout manually.

## Explicit limits

This is a source-level restoration hypothesis with complete first-call operand/metadata/context evidence; it does not establish exact emitted helper identity before a reviewed build. Original allocator/OOM behavior, compiler cleanup lowering and recursive downstream Pump behavior are not proven identical. The proposal does not inspect Pump handler bodies or excluded lanes. Later migration and AMM call ownership still differ and remain outside this narrow patch. Their interface discriminators were inspected only to avoid conflating the first extension helper with a migration helper.

Run `python3 -B verify.py` for exact original helper/metadata/caller instructions, program-ID binding, codegen mechanism, parsed-JSON delta and one-call source scope. No target execution occurs.
