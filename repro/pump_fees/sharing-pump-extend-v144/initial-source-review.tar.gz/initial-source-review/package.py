from pathlib import Path
import shutil,hashlib,json,difflib,sys
W=Path(__file__).resolve().parent;R=W.parents[1];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in ['inputs','method','evidence','before','proposal']:(W/d).mkdir(exist_ok=True)
for n in ['elf_reader.py','disasm.py','analyze_elf.py']:shutil.copy2(R/'work/fees-sharing-option-order-review/method'/n,W/'method'/n)
for n,p in [('original.so',R/'work/fees-sharing-option-order-review/inputs/original.so'),('candidate.so',R/'work/fees-sharing-option-order-build/candidate.so'),('symbols.so',R/'work/fees-sharing-option-order-build/symbols.so')]:shutil.copy2(p,W/'inputs'/n)
s=(R/'programs/pump-fees/src/sharing.rs').read_text();old='''  call(PUMP,vec![ctx.accounts.bonding_curve.to_account_info(),ctx.accounts.payer.to_account_info(),ctx.accounts.system_program.to_account_info(),ctx.accounts.pump_event_authority.to_account_info(),ctx.accounts.pump_program.to_account_info()],&[(true,false),(true,true),(false,false),(false,false),(false,false)],vec![234,102,194,203,150,72,62,229])?;''';new='''  crate::pump::cpi::extend_account(CpiContext::new(
      ctx.accounts.pump_program.to_account_info(),
      crate::pump::cpi::accounts::ExtendAccount {
          account: ctx.accounts.bonding_curve.to_account_info(),
          user: ctx.accounts.payer.to_account_info(),
          system_program: ctx.accounts.system_program.to_account_info(),
          event_authority: ctx.accounts.pump_event_authority.to_account_info(),
          program: ctx.accounts.pump_program.to_account_info(),
      },
  ))?;''';assert s.count(old)==1;(W/'before/sharing.rs').write_text(s);(W/'proposal/sharing.rs').write_text(s.replace(old,new))
t=(R/'programs/pump-fees/idls/pump.json').read_text();e=t.index('"name": "extend_account"');a=t.rfind('"accounts":',0,e);chunk=t[a:e];old2='"name": "user",\n          "signer": true';assert chunk.count(old2)==1;t2=t[:a]+chunk.replace(old2,'"name": "user",\n          "writable": true,\n          "signer": true')+t[e:];(W/'before/pump.json').write_text(t);(W/'proposal/pump.json').write_text(t2)
patch=''
for n,dest in [('sharing.rs','programs/pump-fees/src/sharing.rs'),('pump.json','programs/pump-fees/idls/pump.json')]:patch+=''.join(difflib.unified_diff((W/'before'/n).read_text().splitlines(True),(W/'proposal'/n).read_text().splitlines(True),fromfile='a/'+dest,tofile='b/'+dest))
(W/'proposal.patch').write_text(patch)
for n,p in [('context.rs','anchor-lang-0.31.1/src/context.rs'),('cpi-codegen.rs','anchor-attribute-program-0.31.2/src/declare_program/mods/cpi.rs'),('internal-codegen.rs','anchor-attribute-program-0.31.2/src/declare_program/mods/internal.rs')]:shutil.copy2(R/'work/fees-v2-caller-build/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f'/p,W/'inputs'/n)
I=json.loads((R/'work/fees-sharing-option-order-build/analysis/full-function-inventory.json').read_text());(W/'inputs/inventory.json').write_text(json.dumps(I,indent=2)+'\n');sys.path.insert(0,str(W/'method'));import disasm
for side,file,starts in [('original','original.so',[177720,445160,73544,552776,556488,579040,571320,572392,63024,724336]),('candidate','symbols.so',[509160,88296])]:
 e=disasm.a.Elf((W/'inputs'/file).read_bytes());rs=I['original_rows'if side=='original'else'candidate_rows'];out=[]
 for a in starts:
  r=next(x for x in rs if x['start']==a);out.append(r);(W/'evidence'/f'{side}-{a}.asm').write_text(disasm.render(e,a,r['end']))
 (W/'evidence'/f'{side}-ledger.json').write_text(json.dumps(out,indent=2)+'\n')
sources=json.loads((R/'work/fees-sharing-option-order-main-control/source-proposed.json').read_text());assert all(H(R/n)==h for n,h in sources.items());(W/'input-bindings.json').write_text(json.dumps({'source':sources,'inputs':{p.name:H(p)for p in(W/'inputs').iterdir()}},indent=2)+'\n')
