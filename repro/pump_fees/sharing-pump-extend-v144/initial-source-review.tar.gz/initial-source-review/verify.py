from pathlib import Path
import json,sys,struct,hashlib,re
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'method'));from elf_reader import Elf
O=Elf(P/'inputs/original.so');J=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ins(p):return struct.unpack('<BBhi',O.b[p:p+8])
assert O.calls[183904]==552776 and O.calls[553032]==571320 and O.calls[555120]==724336
assert ins(552984)==(0xbf,0x58,0,0) and ins(552992)==(0x07,8,0,72)
assert ins(552960)[0]==0x18 and O.b[552964:552968]+O.b[552972:552976]==bytes([234,102,194,203,150,72,62,229])
for pc,off,v in [(571528,32,256),(571736,66,257),(571936,100,0),(572136,134,0),(572328,168,0)]:assert ins(pc)==(0x6a,1,off,v)
# The separately owned context program is cloned into infos then count incremented.
assert ins(555064)==(0x07,8,0,1)
assert ins(555032)==(0x79,0x91,320,0)and ins(555040)==(0x79,0x92,312,0)
assert O.calls[447280]==73544 and ins(447320)==(0x7b,0x3a,-3264,0)
assert ins(455696)==(0x79,0xa3,-3264,0) and ins(455704)==(0x7b,0x36,1496,0)
from solders.pubkey import Pubkey
assert O.b[806637:806669]==bytes(Pubkey.from_string('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P'))
assert ins(181584)==(0x79,0x72,1496,0) and ins(181752)==(0x79,0x71,328,0) and ins(182008)==(0x79,0x72,1480,0)
a=J(P/'before/pump.json');b=J(P/'proposal/pump.json');old=next(x for x in a['instructions']if x['name']=='extend_account');new=next(x for x in b['instructions']if x['name']=='extend_account');assert not old['accounts'][1].get('writable',False);a['instructions'][a['instructions'].index(old)]['accounts'][1]['writable']=True;assert a==b
assert [(x.get('signer',False),x.get('writable',False))for x in new['accounts']]==[(False,True),(True,True),(False,False),(False,False),(False,False)]
s=(P/'before/sharing.rs').read_text();t=(P/'proposal/sharing.rs').read_text();assert s.count('  call(')==4 and t.count('  call(')==3 and t.count('crate::pump::cpi::extend_account(')==1
assert 'infos.push(self.program.clone());'in(P/'inputs/context.rs').read_text()
g=(P/'inputs/cpi-codegen.rs').read_text();assert 'Vec::with_capacity(256)'in g and 'ctx.to_account_infos()'in g and 'ctx.program.key()'in g and 'ctx.signer_seeds'in g
for n,h in J(P/'input-bindings.json')['inputs'].items():assert H(P/'inputs'/n)==h
if(P/'manifest.json').exists():
 for n,h in J(P/'manifest.json').items():assert H(P/n)==h,n
print(json.dumps({'passed':True,'proposal_calls':1,'prerequisite_idl_fields':1,'other_manual_calls_unchanged':3,'builds':0,'runtime_executions':0,'whole_helper_identity':False}))
