#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,difflib,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];P=R/'repro/pump_fees/solana-family-221-v144';S=W/'source';B=W/'build-01'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):(W/name).write_text(json.dumps(v,indent=2)+'\n')
assert not S.exists() and not B.exists()
proof=R/'work/cli-swarm-2026-10-24/fees_context_layout/publication';copy=W/'static-lead';shutil.copytree(proof,copy,ignore=shutil.ignore_patterns('__pycache__'))
result=subprocess.run([sys.executable,'-B',str(copy/'verify.py')],cwd=W,capture_output=True,text=True)
save('lead-verification.json',{'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'copied_package_manifest_sha256':H(copy/'manifest-sha256.json'),'copied_without_repository_paths':True});assert result.returncode==0
expected=json.loads((P/'source-sha256.json').read_text());assert len(expected)==22
assert {p:H(R/p)for p in expected}==expected
for n,h in expected.items():
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
file='programs/pump-fees/src/contexts.rs';before=(S/file).read_text();old="pub pump_global: Box<Account<'info, crate::pump_global::Global>>,";new="pub pump_global: Account<'info, crate::pump_global::Global>,"
assert before.count(old)==1;after=before.replace(old,new);(S/file).write_text(after)
(W/'source-change.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+file,tofile='b/'+file)))
changed={p:H(S/p)for p in expected};assert [p for p in expected if changed[p]!=expected[p]]==[file]
save('baseline-source-sha256.json',expected);save('source-sha256.json',changed)
helpers=json.loads((P/'build-helper-sha256.json').read_text());assert all(H(R/p)==v for p,v in helpers.items());save('build-helper-sha256.json',helpers)
phase=json.loads((P/'tool-phase-provenance.json').read_text());tools=phase['compile']['tool_files'];tool_before={p:H(Path(v['resolved_path']))for p,v in tools.items()};assert tool_before==phase['compile']['tool_hashes_before']
stripper=Path.home()/'.cache/solana/v1.52/platform-tools/llvm/bin/llvm-objcopy';strip_before=H(stripper);assert strip_before==phase['strip']['file_sha256_before']
sdk_source=Path(shutil.which('cargo-build-sbf')).resolve().parent/'sdk/sbf';sdk={str(p.relative_to(sdk_source)):H(p)for p in sdk_source.rglob('*')if p.is_file()and'dependencies'not in p.relative_to(sdk_source).parts};assert sdk==json.loads((P/'build-comparison.json').read_text())['sdk_source_sha256'];assert len(sdk)==53
command=[sys.executable,str(R/'scripts/build_partial_candidate.py'),'--manifest',str(S/'programs/pump-fees/Cargo.toml'),'--program','pump_fees','--artifact-name','pump_fees_candidate.so','--tools-version','v1.44','--output',str(B),'--extra-input',str(S/'programs/pump-fees/README.md')]
cache=R/'work/fees-family-221-trial/cargo-home'
save('build-launch.json',{'command':command,'CARGO_HOME':str(cache),'network_offline':True,'source_before':changed,'helper_hashes':helpers,'compile_tool_file_hashes_before':tool_before,'stripper_v152_file_hash_before':strip_before,'sdk_source_sha256':sdk,'scope':'One source-only type correction; unchanged profile, lock, flags, compiler144 and postprocessing152. No state module change.'})
for label,root,files in [('source-snapshot.tar.gz',S,changed),('build-helper-snapshot.tar.gz',R,helpers)]:
 with tarfile.open(W/label,'w:gz')as t:
  for n in files:t.add(root/n,arcname=n,recursive=False)
env={**os.environ,'CARGO_HOME':str(cache),'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True);(W/'build-launch.stdout').write_text(result.stdout);(W/'build-launch.stderr').write_text(result.stderr)
actual={p:H(S/p)for p in expected};save('build-result.json',{'returncode':result.returncode,'source_after':actual,'source_unchanged':actual==changed,'main_source_unchanged':{p:H(R/p)for p in expected}==expected});assert result.returncode==0 and actual==changed
report=json.loads((B/'build-comparison.json').read_text());prefix=str(S.relative_to(R))+'/'
assert {n[len(prefix):]:h for n,h in report['source_sha256'].items()if n.startswith(prefix)}==changed and len(report['source_sha256'])==22
shutil.copyfile(B/'target/sbf-solana-solana/release/pump_fees_candidate.so',W/'unstripped.so')
actual_stripper=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy'
assert (B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
tool_after={p:H(Path(v['resolved_path']))for p,v in tools.items()};assert tool_after==tool_before and H(actual_stripper)==strip_before
save('tool-phase-provenance.json',{'scope':phase['scope'],'compile':{'requested_tools_version':'v1.44','tool_files':tools,'tool_hashes_before':tool_before,'tool_hashes_after':tool_after,'unstripped_sha256':H(W/'unstripped.so')},'strip':{'sdk_platform_tools_symlink':str((B/'sdk/dependencies/platform-tools').readlink()),'sdk_platform_tools_realpath':str((B/'sdk/dependencies/platform-tools').resolve()),'sdk_marker':'platform-tools-v1.52.md','llvm_objcopy_resolved_path':str(actual_stripper.resolve()),'file_sha256_before':strip_before,'file_sha256_after':H(actual_stripper),'candidate_sha256':H(B/'artifacts/pump_fees_candidate.so')},'phase_source_sha256':{p:H(B/'sdk'/p)for p in phase['phase_source_sha256']}})
print(json.dumps({'built':True,'candidate_sha256':H(B/'artifacts/pump_fees_candidate.so'),'candidate_bytes':(B/'artifacts/pump_fees_candidate.so').stat().st_size,'source_inputs':len(changed),'changed_source':[file]},indent=2))
