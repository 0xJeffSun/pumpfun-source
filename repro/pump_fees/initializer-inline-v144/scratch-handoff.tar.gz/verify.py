#!/usr/bin/env python3
"""Verify frozen scratch evidence, static gates and saved signatures without runtime execution."""
from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,subprocess,sys,tarfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((P/n).read_text())
seal=read('manifest-sha256.json')
files={str(p.relative_to(P)):H(p.read_bytes())for p in P.rglob('*')if p.is_file()and p!=P/'manifest-sha256.json'and'__pycache__'not in p.parts}
assert files==seal
assert not any(p.is_symlink()for p in P.rglob('*'))
def archive(name):
 out={}
 with tarfile.open(P/name)as t:
  for member in t:
   p=PurePosixPath(member.name);assert member.isfile()and not p.is_absolute()and'..'not in p.parts and not p.name.endswith('-keypair.json')and member.name not in out
   out[member.name]=t.extractfile(member).read()
 return out
source=archive('source-snapshot.tar.gz');source_hash={n:H(v)for n,v in source.items()};assert len(source)==22 and source_hash==read('source-sha256.json')
baseline=read('baseline-source-sha256.json');assert source_hash.keys()==baseline.keys()
assert [n for n in baseline if source_hash[n]!=baseline[n]]==['programs/pump-fees/src/contexts.rs']
old=(P/'static-lead/inputs/contexts.rs').read_bytes();new=old.replace(b"pub pump_global: Box<Account<'info, crate::pump_global::Global>>,",b"pub pump_global: Account<'info, crate::pump_global::Global>,")
assert old!=new and H(old)==baseline['programs/pump-fees/src/contexts.rs']and new==source['programs/pump-fees/src/contexts.rs']
assert {n:H(v)for n,v in archive('harness-snapshot.tar.gz').items()}==read('harness-source-sha256.json')
assert {n:H(v)for n,v in archive('build-helper-snapshot.tar.gz').items()}==read('build-helper-sha256.json')
for n,h in read('runtime-inputs.json').items():assert H((P/'runtime'/n).read_bytes())==h
build=read('build-comparison.json');attempt=read('build-attempt.json');prefix='work/fees-initializer-inline-recovery/source/'
assert len(build['source_sha256'])==22 and {n[len(prefix):]:v for n,v in build['source_sha256'].items()if n.startswith(prefix)}==source_hash
assert build['source_sha256']==attempt['source_sha256']==attempt['source_after_sha256']and attempt['returncode']==0 and attempt['source_unchanged']
assert H(gzip.decompress((P/'build.log.gz').read_bytes()))==build['build_log_sha256']
assert {n:H(v)for n,v in archive('sbf-sdk-snapshot.tar.gz').items()}==build['sdk_source_sha256']and len(build['sdk_source_sha256'])==53
candidate=H((P/'pump_fees_candidate.so').read_bytes());prov=read('provenance.json')
assert candidate==prov['candidate_sha256']==build['comparison']['candidate_sha256']=='01fedce5878ec14618233c4683bcb4149e471775acb48ffb69614d9df570bb95'
assert (P/'pump_fees_candidate.so').stat().st_size==prov['candidate_bytes']==767992
phase=read('tool-phase-provenance.json');assert phase['compile']['requested_tools_version']==build['selected_toolchain']=='v1.44'
assert phase['compile']['tool_hashes_before']==phase['compile']['tool_hashes_after']=={k:v['sha256']for k,v in phase['compile']['tool_files'].items()}
assert phase['compile']['unstripped_sha256']==H((P/'symbols.so').read_bytes())
assert phase['strip']['file_sha256_before']==phase['strip']['file_sha256_after']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
assert phase['strip']['sdk_marker']=='platform-tools-v1.52.md'and phase['strip']['candidate_sha256']==candidate
for row in read('receipt-build-bindings.json'):
 raw=(P/row['saved_report']).read_bytes();data=gzip.decompress(raw)
 assert H(raw)==row['saved_report_sha256']and H(data)==row['raw_report_sha256']==row['report_sha256']
 assert row['executed_candidate_sha256']==candidate and row['actual_source_sha256']==source_hash and row['build_report_sha256']==H((P/'build-comparison.json').read_bytes())
 assert row['returncode']==0 and not row['mismatches']
commands=['static-lead/verify.py','verify_static.py','verify_saved_runtime.py'];results={}
for script in commands:
 r=subprocess.run([sys.executable,'-B',str(P/script)],cwd=P,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
 assert r.returncode==0,(script,r.stdout,r.stderr)
 if script!='static-lead/verify.py':results[script]=json.loads(r.stdout)
assert results['verify_saved_runtime.py']==read('runtime-verification-result.json')==read('accepted-runtime-verification-result.json')
assert results['verify_static.py']['all_static_gates_passed']
print(json.dumps({'verified':True,'sealed_payload_files':len(files),'candidate_sha256':candidate,'source_inputs':22,'harness_inputs':46,'runtime_inputs':18,'handler_bytes':2992,'parser_bytes':6824,'wrapper_bytes':1608,'direct_calls':9,'literals':2,'comparison_receipts':17441,'donation_steps':10,'encoded_transaction_fields':8644,'verified_signatures_in_encoded_fields':17204,'authentic_unchanged_historical_messages':2,'full_original_byte_equality':False,'new_runtime_executions_by_verifier':0},indent=2))
