#!/usr/bin/env python3
"""Bounded static gate for one inline-context source correction; no program execution."""
from pathlib import Path
import hashlib,json,re,struct,sys
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(W/'static-lead'))
from elf_reader import Elf
H=lambda b:hashlib.sha256(b).hexdigest()
C=Elf(W/'build-01/artifacts/pump_fees_candidate.so');S=Elf(W/'unstripped.so');O=Elf(W/'static-lead/inputs/original.so');BASE=Elf(W/'static-lead/inputs/symbols.so')
assert H(O.b)=='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]and C.pattern(C.lo,C.hi-C.lo)==S.pattern(S.lo,S.hi-S.lo)
canonical=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
orig_ranges={p:(O.entries[i+1]if i+1<len(O.entries)else O.hi)-p for i,p in enumerate(O.entries)}
def selected(predicate):
 found={(f['start'],f['size'])for f in S.funcs if predicate(f['name'])};assert len(found)==1,found
 return next(iter(found))
def body(c,o,n):
 return {'candidate_start':c,'original_start':o,'bytes':n,'candidate_raw_sha256':H(C.b[c:c+n]),'original_raw_sha256':H(O.b[o:o+n]),'raw_equal':C.b[c:c+n]==O.b[o:o+n],'normalized_equal':C.normalized[c:c+n]==O.normalized[o:o+n],'relocation_pattern_equal':C.pattern(c,n)==O.pattern(o,n),'original_entry_bounded':orig_ranges[o]==n,'normalized_different_slots':[i for i in range(0,n,8)if C.normalized[c+i:c+i+8]!=O.normalized[o+i:o+i+8]]}
def require(row):assert row['normalized_equal']and row['relocation_pattern_equal']and row['original_entry_bounded'],row

def callees(c,o,n):
 rows=[]
 for call in C.callsites(c,n):
  off=call['offset'];other=O.calls[o+off];sizes={f['size']for f in S.funcs if f['start']==call['target']};assert len(sizes)==1
  row=body(call['target'],other,next(iter(sizes)));row['call_offset']=off;row['raw_candidate_operand']=struct.unpack_from('<i',C.b,c+off+4)[0];row['raw_original_operand']=struct.unpack_from('<i',O.b,o+off+4)[0]
  assert c+off+8+row['raw_candidate_operand']*8==call['target']and o+off+8+row['raw_original_operand']*8==other
  require(row);rows.append(row)
 return rows

def literal(c,o,off,n):
 def pointer(e,a):return struct.unpack_from('<I',e.b,a+4)[0]|struct.unpack_from('<I',e.b,a+12)[0]<<32
 cp=pointer(C,c+off);op=pointer(O,o+off);cb=C.b[cp:cp+n];ob=O.b[op:op+n];assert len(cb)==n and cb==ob
 return {'instruction_offset':off,'bytes':n,'candidate_target':cp,'original_target':op,'sha256':H(cb),'equal':True,'hex':cb.hex()}
handler=selected(lambda n:'19pump_fees_candidate19pump_fees_candidate29initialize_fee_program_global17'in n)
parser=selected(lambda n:'InitializeFeeProgramGlobal'in n and '$12try_accounts17'in n)
wrapper=selected(lambda n:'9__private8__global29initialize_fee_program_global17'in n)
rows={k:body(start,origin,size)for k,(start,size),origin in [('handler',handler,85560),('parser',parser,308352),('wrapper',wrapper,618504)]}
assert [handler[1],parser[1],wrapper[1]]==[2992,6824,1608]
for row in rows.values():require(row)
assert C.calls[wrapper[0]+432]==parser[0]and C.calls[wrapper[0]+720]==handler[0]
direct=callees(handler[0],85560,2992);assert len(direct)==9
literals=[literal(handler[0],85560,off,n)for off,n in [(2232,32),(2424,17)]]
assert C.pattern(handler[0],2992)==[{'offset':1040,'type':10,'symbol':'abort'}]+[{'offset':off,'type':8,'symbol':''}for off in [2232,2424]]
# Recheck exact inline return stores and transfer lengths at original-relative offsets.
checks={38559:[7,1,0,0,-2008],38561:None,38562:[0x79,8,10,-2000,0],38563:[0x79,2,10,-2008,0],38591:[7,1,0,0,-1264],38593:[7,2,0,0,-1992],38594:[0xb7,3,0,0,723],39338:[7,1,0,0,472],39340:[7,2,0,0,-1264],39341:[0xb7,3,0,0,723],39350:[0x63,6,1,1196,0],39351:[0x73,6,7,1195,0],39353:[0x7b,6,1,464,0],39355:[0x7b,6,1,456,0],39387:[0x7b,6,1,360,0],39388:[0x7b,6,9,352,0],39389:[0x7b,6,8,344,0]}
anchors=[]
for slot,want in checks.items():
 if want is None:continue
 at=parser[0]+slot*8-308352;op,regs,off,imm=struct.unpack_from('<BBhi',C.b,at);got=[op,regs&15,regs>>4,off,imm];assert got==want
 anchors.append({'candidate_pc':at,'original_pc':slot*8,'decoded':got})
# Preserve previously accepted social exit and Pubkey immediate-body gates.
prior=json.loads((R/'repro/pump_fees/solana-family-221-v144/static-gate.json').read_text())
previous=[]
for label,old in [('social_exit',prior['social_exit'])]+[('pubkey_'+r['name'],r)for r in prior['pubkey_helpers']]:
 names={canonical(f['name'])for f in BASE.funcs if f['start']==old['candidate_start']}
 start,size=selected(lambda n:canonical(n)in names);assert size==old['bytes']
 row=body(start,old['original_start'],size);require(row);row['name']=label;previous.append(row)
social=previous[0];social_calls=callees(social['candidate_start'],405560,560);assert len(social_calls)==7
social_literals=[literal(social['candidate_start'],405560,off,n)for off,n in [(40,32),(320,14),(504,10)]]
formatter=next(r for r in previous if r['name']=='pubkey_write_as_base58');formatter_calls=callees(formatter['candidate_start'],formatter['original_start'],formatter['bytes']);assert len(formatter_calls)==10
result={'candidate_sha256':H(C.b),'original_sha256':H(O.b),'symbols_sha256':H(S.b),'full_byte_equality':False,'all_static_gates_passed':True,'initializer_bodies':rows,'initializer_direct_calls':direct,'initializer_literals':literals,'parser_layout_anchors':anchors,'observed_layout':{'size':1200,'pump_global_inline_range':[456,1200],'system_program_offset':352,'event_authority_offset':360,'program_offset':408},'retained_prior_bodies':previous,'retained_social_calls':social_calls,'retained_social_literals':social_literals,'retained_formatter_calls':formatter_calls,'limitations':['Diagnostic normalization is in-memory only. No whole-ELF identity or unique historical source claim.','Parser/wrapper complete normalized body match does not establish arbitrary transitive callees or relocated-data closure.','Nine handler direct targets and two literal extents are checked, not unlimited descendant closure.'],'runtime_cases_at_gate':0}
(W/'static-gate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'candidate_sha256':H(C.b),'handler_bytes':2992,'parser_bytes':6824,'wrapper_bytes':1608,'direct_calls':len(direct),'literals':len(literals),'layout_size':1200,'prior_social_and_pubkey_bodies_preserved':True,'all_static_gates_passed':True},indent=2))
