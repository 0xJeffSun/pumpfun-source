"""Complete V2 roots, actual helper paths, and original-target closure ledger."""
from pathlib import Path
import gzip,hashlib,json,sys
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'reference/analysis-method'))
from elf_reader import Elf
from window_tools import window,comparison,data_refs,instructions,extent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def run():
 c=Elf(W/'candidate.so');s=Elf(W/'symbols.so');o=Elf(W/'reference/analysis-method/inputs/original.so')
 inventory=json.loads((W/'reference/full-function-inventory.json').read_text())
 originals={r['start']:r for r in inventory['original_rows']}
 def find(fragment):
  f=[r for r in s.funcs if fragment in r['name']];v={(r['start'],r['size'])for r in f}
  assert len(v)==1,(fragment,v)
  return next(iter(v))
 specs={
 'handler':(211408,'19pump_fees_candidate20update_fee_shares_v217h'),
 'parser':(502096,'sharing_update..UpdateFeeSharesV2$u20$as$u20$anchor_lang..Accounts'),
 'wrapper':(641744,'__global20update_fee_shares_v217h'),
 'authorize':(234096,'14sharing_update16legacy_authorize17h'),
 'preprocess':(231576,'14sharing_update20preprocess_remaining17h'),
 'paired_payout':(219376,'14sharing_update23prepare_v2_quote_payout17h'),
 'zero_payout':(199072,'14sharing_update22prepare_v2_zero_payout17h'),
 'final_validation':(225920,'14sharing_update18v2_validate_shares17h'),
 'pump_adapter':(236240,'14sharing_update26v2_distribute_creator_fees17h'),
 'pump_cpi':(548160,'4pump3cpi26distribute_creator_fees_v217h'),
 'pump_metas':(568848,'distribute_creator_fees_v2..DistributeCreatorFeesV2$u20$as$u20$anchor_lang..ToAccountMetas'),
 'pump_infos':(564232,'distribute_creator_fees_v2..DistributeCreatorFeesV2$u20$as$u20$anchor_lang..ToAccountInfos'),
 'amm_cpi':(586976,'8pump_amm3cpi32transfer_creator_fees_to_pump_v217h'),
 'amm_metas':(595656,'transfer_creator_fees_to_pump_v2..TransferCreatorFeesToPumpV2$u20$as$u20$anchor_lang..ToAccountMetas'),
 'amm_infos':(564232,'transfer_creator_fees_to_pump_v2..TransferCreatorFeesToPumpV2$u20$as$u20$anchor_lang..ToAccountInfos'),
 }
 roots={};ledgers={};targets={}
 for name,(original,fragment) in specs.items():
  at,size=find(fragment);old=originals[original]
  roots[name]={'original':window(o,original,old['bytes'],[]),'candidate':window(c,at,size,s.funcs),'comparison':comparison(o,c,original,at,old['bytes'],size)}
  ledgers[name]={}
  for label,e,start,n,syms in [('original',o,original,old['bytes'],[]),('candidate',c,at,size,s.funcs)]:
   ledgers[name][label]={'instructions':instructions(e,start,n),'data':data_refs(e,start,n)}
   for call in e.callsites(start,n):
    q=call['target'];key=label+':'+str(q)
    if key not in targets:
     ns={f['size']for f in syms if f['start']==q};z=next(iter(ns))if len(ns)==1 else extent(e,q)
     targets[key]={'window':window(e,q,z,syms),'data':data_refs(e,q,z),'callers':[]}
    targets[key]['callers'].append({'root':name,'pc':start+call['offset']})
 # Preserve every target result, including failures, with no same-offset pairing
 # for roots whose complete normalized bytes differ.
 pairs={}
 for name,r in roots.items():
  if not(r['comparison']['normalized_equal']and r['comparison']['relocation_pattern_equal']):
   pairs[name]={'pairing_permitted':False};continue
  rows=[]
  for x,y in zip(r['original']['direct_calls'],r['candidate']['direct_calls'],strict=True):
   assert x['offset']==y['offset']
   a=targets['original:'+str(x['target'])]['window'];b=targets['candidate:'+str(y['target'])]['window']
   rows.append({'offset':x['offset'],'original':x['target'],'candidate':y['target'],'comparison':comparison(o,c,a['start'],b['start'],a['size'],b['size'])})
  pairs[name]={'pairing_permitted':True,'pairs':rows}
 for name in ['pump_cpi','pump_metas','pump_infos','amm_metas','amm_infos']:
  assert roots[name]['comparison']['normalized_equal']and roots[name]['comparison']['relocation_pattern_equal']
  assert all(q['comparison']['normalized_equal']and q['comparison']['relocation_pattern_equal']for q in pairs[name]['pairs'])
 paths={}
 for name in ['pump_cpi','amm_cpi','paired_payout','zero_payout','authorize','preprocess','final_validation']:
  target=roots[name]['candidate']['start'];queue=[(roots['handler']['candidate'],[])];seen=set()
  while queue:
   node,path=queue.pop(0)
   if node['start']in seen:continue
   seen.add(node['start'])
   found=None
   for call in node['direct_calls']:
    edge={'from':node['start'],'pc':node['start']+call['offset'],'target':call['target']}
    if call['target']==target:found=path+[edge];break
    f=[f for f in s.funcs if f['start']==call['target']and 'pump_fees_candidate14sharing_update'in f['name']]
    if f:queue.append((window(c,f[0]['start'],f[0]['size'],s.funcs),path+[edge]))
   if found:paths[name]=found;break
  assert name in paths,('missing actual source-helper path',name)
 # Original helper 1008 now has a concrete, called monomorphization. It is not
 # inferred from a different specialization with the same textual method name.
 matches=originals[1008]['candidate_matches'];assert len(matches)==1
 helper=matches[0]['candidate_start'];hn=matches[0]['candidate_bytes']
 format_cmp=comparison(o,c,1008,helper,originals[1008]['bytes'],hn)
 assert format_cmp['normalized_equal']and format_cmp['relocation_pattern_equal']
 formatting=[]
 for name in ['paired_payout','zero_payout']:
  calls=[q for q in roots[name]['candidate']['direct_calls']if q['target']==helper];assert calls,(name,helper)
  formatting.append({'root':name,'calls':calls})
 old=json.loads((W/'baseline-inventory.json').read_text())
 changes=[{'original_start':a['start'],'original_bytes':a['bytes'],'before':a['status'],'after':b['status']}for a,b in zip(old['original_rows'],inventory['original_rows'],strict=True)if a['status']!=b['status']]
 return {'candidate_sha256':H(W/'candidate.so'),'symbols_sha256':H(W/'symbols.so'),'original_sha256':H(o.path),'roots':roots,'full_instructions_and_data':ledgers,'direct_target_inventory':targets,'same_offset_target_comparisons':pairs,'actual_handler_paths':paths,'called_formatted_values_helper':{'candidate_start':helper,'comparison':format_cmp,'callers':formatting},'inventory_changes':changes,'whole_original_equal':o.b==c.b,'limits':['Only matched complete normalized roots permit target pairing. Raw ELF identity remains false.','Full parser/caller/cleanup/data and diagnostic identity are not established.','No runtime result transferred from prior candidates.']}

if __name__=='__main__':
 r=run();(W/'v2-static-proof.json.gz').write_bytes(gzip.compress((json.dumps(r,indent=2)+'\n').encode(),mtime=0))
 print(json.dumps({'candidate_sha256':r['candidate_sha256'],'inventory_changes':r['inventory_changes'],'matched_roots':[n for n,v in r['roots'].items()if v['comparison']['normalized_equal']and v['comparison']['relocation_pattern_equal']],'actual_handler_paths':r['actual_handler_paths']},indent=2))
