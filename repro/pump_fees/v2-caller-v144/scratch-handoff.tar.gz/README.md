# Fees V2 caller: isolated reconstruction

This composes original-ordered quote admission, remaining-account preprocessing,
AMM V2 CPI, zero/nonzero quote payout filtering, early serialization, conditional
Pump V2 CPI and shareholder validation. The existing contexts and pass 07 legacy
diagnostic fix are preserved. Only the sharing source and retained Pump V2 IDL
entry change. No dependency or compiler changes, artificial source coordinates,
binary modifications, new fixtures or account-validation relaxations are used.

The complete original remains unequal. Five previously unattributed original
windows now have normalized matches: the actually called formatted-value helper,
Pump V2 CPI, shared V2 account-info builder and both V2 meta builders. The full
585-original/575-candidate ledger retains 453 mapped, 130 unattributed and two
conflicting original windows. Complete callers, parser, cleanup, diagnostics and
transitive data remain unresolved. All 17,461 existing comparisons and the ten
separate sequence steps must pass before this package can be produced.

Run python -B verify.py --runtime for saved proof and signature verification.
--repo additionally checks the pre-promotion baseline. Main integration requires
a separate clean build and whole executable/symbol identity comparison.
