from pathlib import Path
import shutil,json,hashlib,gzip
R=Path.cwd();W=R/'work/fees-v2-caller-build';P=W/'handoff';C=R/'repro/pump_fees/legacy-value-v144';Q=R/'repro/pump_fees/v2-caller-source-proposal'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
assert J(W/'runtime/summary.json')['baseline_comparisons']==17441
assert not P.exists();P.mkdir()
def cp(n,d=None):
 src=W/n;dst=P/(d or n);assert src.is_file()and not src.is_symlink()and not src.name.endswith('-keypair.json');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def tree(src,dst):
 for p in sorted(src.rglob('*')):
  assert not p.is_symlink()
  if p.is_file()and '__pycache__'not in p.parts:
   assert not p.name.endswith('-keypair.json');q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for n in ['candidate.so','symbols.so','baseline-candidate.so','baseline-symbols.so','baseline-inventory.json','build_once.py','measure_runtime.py','inspect_legacy.py','inspect_v2.py','compare_bytes.py','run_runtime.py','preflight.json','prebuild-manifest-sha256.json','build-launch.json','build-result.json','build.stdout','build.stderr','dependency-after.json','cargo-rustc-info.json','tool-phase-provenance.json','static-gate.json','legacy-static-proof.json.gz','v2-static-proof.json.gz','legacy-instructions.json.gz','legacy-data-references.json.gz','inventory-vs-c177acab.json.gz','complete-byte-comparison.json.gz','check_retained_social.py','retained-social.json.gz','analysis-method-origins.json','runtime-engine-before.json','runtime-engine-after.json','runtime-preflight.json','runtime-frozen-inputs.json','runtime-launch.stdout','runtime-launch.stderr','inspect-candidate.stdout','inspect-candidate.stderr','inspect-legacy.stdout','inspect-legacy.stderr','inspect-v2.stdout','inspect-v2.stderr','retained.stdout','retained.stderr','retained-social.stdout','retained-social.stderr']:cp(n)
for n in ['build-attempt.json','build-comparison.json','build.log']:cp('build-01/'+n)
for n in ['inputs','validation-layer','reference','analysis-history']:tree(W/n,P/n)
for n in J(W/'inputs/corrected-source-sha256.json'):cp('source/'+n)
for n in J(W/'inputs/tools-before.json')['helper_files']:cp('source/'+n)
cp('source/evidence/original/pump_fees/deployed.so')
for rows in J(W/'runtime-frozen-inputs.json').values():
 for n in rows:cp('runner-repo/'+n)
# Retain exact reviewed proposal files with membership proofs in its published
# manifest. The large predecessor evidence packages remain at their sealed
# public locations; no new claim is made by duplicating them.
for n in ['manifest.json','MANIFEST.sha256','REPORT.md','baseline/sharing_update.rs','proposal/sharing_update.rs','proposal/pump.json','bindings/pump-v2-instruction.json']:
 d=P/'source-review'/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Q/n,d)
shutil.copyfile(R/'work/fees-legacy-value-build/handoff/inputs/cache-integrity.json',P/'inputs/cache-integrity.json')
for n in ['sbf-sdk-snapshot.tar.gz','build-helper-snapshot.tar.gz']:shutil.copyfile(C/n,P/n)
(P/'runtime').mkdir()
for src in(W/'runtime').iterdir():
 if src.suffix=='.json':(P/'runtime'/(src.name+'.gz')).write_bytes(gzip.compress(src.read_bytes(),mtime=0))
 elif src.is_file():shutil.copyfile(src,P/'runtime'/src.name)
shutil.copyfile(R/'work/fees-legacy-value-build/handoff/verify_prior_saved.py',P/'verify_prior_saved.py')
v=(R/'work/fees-legacy-value-build/handoff/verify.py').read_text()
v=v.replace("=={'programs/pump-fees/src/sharing_update.rs'}", "=={'programs/pump-fees/src/sharing_update.rs','programs/pump-fees/idls/pump.json'}")
v=v.replace('34e7590537a77f507d06ce51dc14415094bbf2b6225353bad4014f5df63a1ea9',J(W/'inputs/corrected-source-sha256.json')['programs/pump-fees/src/sharing_update.rs'])
start=v.index(" assert source['programs/pump-fees/src/sharing_update.rs']==H(P/'source-review/after.rs')")
end=v.index(' if a.repo:',start)
v=v[:start]+''' assert H(P/'source-review/manifest.json')=='3ec845f42c97b7512ea8a7e797d28e3203dc9bb06278a13b094a5d3f9d2b4349'
 proposal_manifest=J(P/'source-review/manifest.json')
 for p in (P/'source-review').rglob('*'):
  if p.is_file() and p.name not in ['manifest.json','MANIFEST.sha256']:
   assert H(p)==proposal_manifest[str(p.relative_to(P/'source-review'))]
 frozen=(P/'source-review/baseline/sharing_update.rs').read_text()
 proposed=(P/'source-review/proposal/sharing_update.rs').read_text()
 baseline=(P/'source-review/baseline/sharing_update.rs').read_text()
 # The accepted baseline additionally carries pass 07's one diagnostic fix.
 legacy_old='require_keys_eq!(account.key(), share.address, FeeError::ShareholderAccountMismatch);'
 legacy_new='if account.key() != share.address {\\n            return Err(error!(FeeError::ShareholderAccountMismatch)\\n                .with_values((account.key(), share.address)));\\n        }'
 assert baseline.count(legacy_old)==1
 baseline=baseline.replace(legacy_old,legacy_new)
 assert hashlib.sha256(baseline.encode()).hexdigest()==base['programs/pump-fees/src/sharing_update.rs']
 marker=' pub fn update_fee_shares_v2'; stop='\\nfn legacy_curve_quote_is_zero'
 old_body=frozen[frozen.index(marker):frozen.index(stop)]
 new_body=proposed[proposed.index(marker):proposed.index(stop)]
 appended=proposed[len(proposed[:proposed.index(stop)])+len(frozen[frozen.index(stop):]):]
 expected=baseline.replace(old_body,new_body)+appended
 assert expected==(P/'source/programs/pump-fees/src/sharing_update.rs').read_text()
 assert H(P/'source/programs/pump-fees/idls/pump.json')==H(P/'source-review/proposal/pump.json')
''' +v[end:]
v=v.replace('c177acab23511d3a77010717bc42b46f9e57e261fae101ac00dfff748f0d8237',H(W/'candidate.so')).replace('fec21621ac262365a3afab47e8888a1fadf8e5f9cc70b12a5e10779392aa1e70',H(W/'symbols.so'))
v=v.replace("control=load('control',P/'error_value_witness.py');assert J(P/'error-value-witness.json')==control.run()", "control=load('v2',P/'inspect_v2.py');assert J(P/'v2-static-proof.json')==control.run()")
v=v.replace("assert H(P/'error-value-witness.json')==J(P/'static-gate.json')['error_payload_sha256']", "assert H(P/'v2-static-proof.json.gz')==J(P/'static-gate.json')['v2_static_sha256']")
v=v.replace("'candidate_windows':562", "'candidate_windows':575")
(P/'verify.py').write_text(v);shutil.copyfile(Path(__file__),P/'package_fees_v2.py')
(P/'README.md').write_text('''# Fees V2 caller: isolated reconstruction

This composes original-ordered quote admission, remaining-account preprocessing,
AMM V2 CPI, zero/nonzero quote payout filtering, early serialization, conditional
Pump V2 CPI and shareholder validation. The existing contexts and pass 07 legacy
diagnostic fix are preserved. Only the sharing source and retained Pump V2 IDL
entry change. No dependency or compiler changes, artificial source coordinates,
binary modifications, new fixtures or account-validation relaxations are used.

The complete original remains unequal. Five previously unattributed original
windows now have normalized matches: the actually called formatted-value helper,
Pump V2 CPI, shared V2 account-info builder and both V2 meta builders. The full
585-original/575-candidate ledger retains 453 mapped, 130 unattributed and two
conflicting original windows. Complete callers, parser, cleanup, diagnostics and
transitive data remain unresolved. All 17,461 existing comparisons and the ten
separate sequence steps must pass before this package can be produced.

Run python -B verify.py --runtime for saved proof and signature verification.
--repo additionally checks the pre-promotion baseline. Main integration requires
a separate clean build and whole executable/symbol identity comparison.
''')
manifest={p.relative_to(P).as_posix():H(p)for p in sorted(P.rglob('*'))if p.is_file()};(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'MANIFEST.sha256').write_text(H(P/'manifest.json')+'  manifest.json\n')
print(json.dumps({'payloads':len(manifest),'seal':H(P/'manifest.json')}))
