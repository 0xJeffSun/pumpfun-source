from pathlib import Path
import shutil,json,hashlib,gzip
R=Path.cwd();W=R/'work/fees-legacy-value-build';P=W/'handoff';C=R/'repro/pump_fees/legacy-caller-v144';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
assert J(W/'runtime/summary.json')['baseline_comparisons']==17441
assert not P.exists();P.mkdir()
def cp(n,d=None):
 src=W/n;dst=P/(d or n);assert src.is_file()and not src.is_symlink()and not src.name.endswith('-keypair.json');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def tree(src,dst):
 for p in sorted(src.rglob('*')):
  assert not p.is_symlink()
  if p.is_file()and '__pycache__'not in p.parts:
   assert not p.name.endswith('-keypair.json');q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for n in ['candidate.so','symbols.so','baseline-candidate.so','baseline-symbols.so','baseline-inventory.json','build_once.py','measure_runtime.py','inspect_legacy.py','compare_bytes.py','run_runtime.py','preflight.json','prebuild-manifest-sha256.json','build-launch.json','build-result.json','build.stdout','build.stderr','dependency-after.json','cargo-rustc-info.json','tool-phase-provenance.json','static-gate.json','legacy-static-proof.json.gz','legacy-instructions.json.gz','legacy-data-references.json.gz','inventory-vs-e5c811.json.gz','complete-byte-comparison.json.gz','check_retained_social.py','retained-social.json.gz','error_value_witness.py','error-value-witness.json','analysis-method-origins.json','runtime-engine-before.json','runtime-engine-after.json','runtime-preflight.json','runtime-frozen-inputs.json','runtime-launch.stdout','runtime-launch.stderr','inspect-candidate.stdout','inspect-candidate.stderr','inspect-legacy.stdout','inspect-legacy.stderr','retained.stdout','retained.stderr','retained-social.stdout','retained-social.stderr','compare-bytes.stdout','compare-bytes.stderr']:cp(n)
for n in ['build-attempt.json','build-comparison.json','build.log']:cp('build-01/'+n)
for n in ['inputs','validation-layer','reference']:tree(W/n,P/n)
for n in J(W/'inputs/corrected-source-sha256.json'):cp('source/'+n)
for n in J(W/'inputs/tools-before.json')['helper_files']:cp('source/'+n)
cp('source/evidence/original/pump_fees/deployed.so')
for rows in J(W/'runtime-frozen-inputs.json').values():
 for n in rows:cp('runner-repo/'+n)
tree(R/'repro/pump_fees/legacy-value-diagnostic-proposal',P/'source-review')
shutil.copyfile(R/'work/fees-legacy-caller-build/handoff/inputs/cache-integrity.json',P/'inputs/cache-integrity.json')
for n in ['sbf-sdk-snapshot.tar.gz','build-helper-snapshot.tar.gz']:shutil.copyfile(C/n,P/n)
(P/'runtime').mkdir()
for src in(W/'runtime').iterdir():
 if src.suffix=='.json':(P/'runtime'/(src.name+'.gz')).write_bytes(gzip.compress(src.read_bytes(),mtime=0))
 elif src.is_file():shutil.copyfile(src,P/'runtime'/src.name)
shutil.copyfile(R/'work/fees-legacy-caller-build/handoff/verify_prior_saved.py',P/'verify_prior_saved.py')
v=(R/'work/fees-legacy-caller-build/verify.py').read_text()
v=v.replace('94a11c22bc952b060119212b7982e638f8faf56af5e565e15234f88283766956','34e7590537a77f507d06ce51dc14415094bbf2b6225353bad4014f5df63a1ea9')
v=v.replace("assert source==J(P/'source-review/proposed-source-sha256.json') and base==J(P/'source-review/baseline-source-sha256.json')", "assert source['programs/pump-fees/src/sharing_update.rs']==H(P/'source-review/after.rs') and base['programs/pump-fees/src/sharing_update.rs']==H(P/'source-review/before.rs')")
v=v.replace('f5c86d690dd1b0c78364cc3809439a276e524b093753f1cbbd8d0e6a4c09052d','a1732b231387e244a9e2d3817c180fe5d0ea9c355990dc02bc3a9335fbc11808')
v=v.replace('e5c811e2a66b540f25b44d9a55dd7b890e7ff01a0074dfc0d0dfc25237c391fe','c177acab23511d3a77010717bc42b46f9e57e261fae101ac00dfff748f0d8237').replace('336f49a8075c87efe2eead28290793823a6b5bf004fe000b82b27981ae6ce501','fec21621ac262365a3afab47e8888a1fadf8e5f9cc70b12a5e10779392aa1e70')
old="control=load('control',P/'check_control_witnesses.py');assert J(P/'legacy-control-witnesses.json')==control.run()";assert old in v;v=v.replace(old,"control=load('control',P/'error_value_witness.py');assert J(P/'error-value-witness.json')==control.run()")
old="update=J(P/'static-replay-update.json');assert update['final_static_container_sha256']==H(P/'legacy-static-proof.json.gz') and update['new_method_sha256']==H(P/'inspect_legacy.py')\n assert update['pre_execution_static_sha256']==J(P/'static-gate.json')['legacy_static_sha256']"
assert old in v;v=v.replace(old,"assert H(P/'legacy-static-proof.json.gz')==J(P/'static-gate.json')['legacy_static_sha256']\n assert H(P/'error-value-witness.json')==J(P/'static-gate.json')['error_payload_sha256']")
(P/'verify.py').write_text(v);shutil.copyfile(Path(__file__),P/'package_fees_value.py')
(P/'README.md').write_text('''# Legacy payout formatted comparison values: isolated build

One source check now returns the original formatted-value error payload rather
than raw public keys. Account availability/equality, error code, filtering,
payout order and authorization are preserved. Source coordinates are natural.
The exact proposal, original helper and framework evidence are included.

The pinned v1.44 compile/v1.52 strip pipeline produced candidate c177acab
(828,184 bytes). All 17,461 unchanged comparisons and the separate ten-step
sequence pass. Fresh saved verification is separate from execution. No new
cases or broader branch coverage are claimed.

The formatting code inlines into the 26,128-byte legacy handler. Four actual
formatting sites reach the 40-byte Pubkey formatter, which is raw-identical to
the original target. Unrelated named with_values specializations are not the
legacy caller. Complete original/helper CFG equality remains unproved.

The full inventory retains 585 original/562 candidate windows and unchanged
448 mapped, 135 unattributed and two conflicting original windows. Ten retained
exact bodies, 26 targets, five literals and five codecs/35 targets pass; the
five social roots and 176 targets retain their baseline matches. These are
bounded static/runtime results, not whole-program identity or security sign-off.

Use python -B verify.py --runtime with Solders available. --repo additionally
checks the pre-promotion baseline. No verifier executes a target or sends a
transaction. Main promotion remains a separate clean-build identity step.
''')
manifest={p.relative_to(P).as_posix():H(p)for p in sorted(P.rglob('*'))if p.is_file()};(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'MANIFEST.sha256').write_text(H(P/'manifest.json')+'  manifest.json\n')
print(json.dumps({'payloads':len(manifest),'seal':H(P/'manifest.json')}))
