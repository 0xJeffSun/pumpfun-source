from pathlib import Path
import hashlib,json,gzip,sys
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W/'reference/analysis-method'))
from elf_reader import Elf
from window_tools import instructions,window,comparison,extent,data_refs
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 c=Elf(W/'candidate.so');s=Elf(W/'symbols.so');o=Elf(W/'reference/analysis-method/inputs/original.so')
 p=json.load(gzip.open(W/'legacy-static-proof.json.gz','rt'));root=p['roots']['candidate']['handler']
 assert H(W/'candidate.so')=='c177acab23511d3a77010717bc42b46f9e57e261fae101ac00dfff748f0d8237'
 assert o.calls[203080]==1008
 assert instructions(c,553936,8)[0]['immediate_signed']==6020
 calls=[pc for pc,target in c.calls.items()if 553936<=pc<556032 and target==703928]
 assert calls==[554336,554504,554696,555512]
 assert {f['size']for f in s.funcs if f['start']==703928}=={40}
 fmt=comparison(o,c,754592,703928,40,40);assert fmt['raw_equal']and fmt['normalized_equal']and fmt['relocation_pattern_equal']
 named=[f for f in s.funcs if 'Error11with_values' in f['name']]
 assert not any(x['target']in {f['start']for f in named}for x in root['direct_calls'])
 return {'candidate_sha256':H(W/'candidate.so'),'original_sha256':H(W/'reference/analysis-method/inputs/original.so'),'original_helper':window(o,1008,1304,[]),'original_helper_instructions':instructions(o,1008,1304),'candidate_handler':root,'candidate_error_payload_interval':[553936,556032],'candidate_interval_instructions':instructions(c,553936,2096),'candidate_interval_data':data_refs(c,553936,2096),'format_call_pcs':calls,'format_target':window(c,703928,40,s.funcs),'format_target_original_comparison':fmt,'unrelated_named_value_helpers':named,'source_model':'Error::with_values inlines into the legacy handler; do not confuse unrelated named specializations with this caller. The four formatting sites reflect two error-variant arms, each formatting both keys.','limits':['Full original helper versus inlined candidate CFG equality is not established.','Complete legacy handler, source coordinates and transitive data remain unequal.','Existing corpus acceptance is separate; no new fixture is claimed.']}
if __name__=='__main__':
 r=run();(W/'error-value-witness.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'PASS','format_sites':len(r['format_call_pcs']),'format_target_raw_equal':True,'caller_model':'inlined','full_original_byte_equality':False}))
