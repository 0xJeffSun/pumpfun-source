# Legacy payout formatted comparison values: isolated build

One source check now returns the original formatted-value error payload rather
than raw public keys. Account availability/equality, error code, filtering,
payout order and authorization are preserved. Source coordinates are natural.
The exact proposal, original helper and framework evidence are included.

The pinned v1.44 compile/v1.52 strip pipeline produced candidate c177acab
(828,184 bytes). All 17,461 unchanged comparisons and the separate ten-step
sequence pass. Fresh saved verification is separate from execution. No new
cases or broader branch coverage are claimed.

The formatting code inlines into the 26,128-byte legacy handler. Four actual
formatting sites reach the 40-byte Pubkey formatter, which is raw-identical to
the original target. Unrelated named with_values specializations are not the
legacy caller. Complete original/helper CFG equality remains unproved.

The full inventory retains 585 original/562 candidate windows and unchanged
448 mapped, 135 unattributed and two conflicting original windows. Ten retained
exact bodies, 26 targets, five literals and five codecs/35 targets pass; the
five social roots and 176 targets retain their baseline matches. These are
bounded static/runtime results, not whole-program identity or security sign-off.

Use python -B verify.py --runtime with Solders available. --repo additionally
checks the pre-promotion baseline. No verifier executes a target or sends a
transaction. Main promotion remains a separate clean-build identity step.
