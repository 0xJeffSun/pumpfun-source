from pathlib import Path
import sys,struct,json,hashlib,difflib,itertools
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'method'));from elf_reader import Elf
O=Elf(P/'inputs/original.so');C=Elf(P/'inputs/symbols.so');J=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ins(e,p):return struct.unpack('<BBhi',e.b[p:p+8])
def eq(p,v):assert ins(O,p)==v,(p,ins(O,p),v)
def call(p,t):assert O.calls[p]==t,(p,t)
for p,t in [(639288,445160),(639544,177720),(446848,70520),(70688,28120),(28776,537312),(538024,538040)]:call(p,t)
assert O.b[806268:806281]==b'bonding_curve'
assert O.normalized[538040:539488]==C.normalized[366104:367552]
assert O.pattern(538040,1448)==C.pattern(366104,1448)
assert any('BondingCurve' in f['name'] and 'try_deserialize_unchecked' in f['name'] and f['start']==366104 and f['size']==1448 for f in C.funcs)
fields=[x['name']for x in next(t for t in J(P/'inputs/pump.json')['types'] if t['name']=='BondingCurve')['type']['fields']]
assert fields[:5]==['virtual_token_reserves','virtual_sol_reserves','real_token_reserves','real_sol_reserves','token_total_supply']
# Serialized u64 fields become stable decoded reserve members.
for p,v in [(538168,(0x79,0x17,8,0)),(538448,(0x79,0x18,16,0)),(538512,(0x79,0x19,24,0)),(538576,(0x79,0x14,32,0)),(539456,(0x7b,0x76,32,0)),(539448,(0x7b,0x86,40,0)),(539440,(0x7b,0x96,48,0)),(539432,(0x7b,0x46,56,0))]:eq(p,v)
# Full decoder return -> Account adapter -> parser local -> context.
for p,v in [(28752,(0x07,1,0,-80)),(29008,(0x07,2,0,-64)),(29016,(0xb7,3,0,57)),(28984,(0x07,1,0,24)),(447184,(0x07,1,0,-776)),(447200,(0x07,2,0,-2384)),(447208,(0xb7,3,0,65)),(455496,(0x07,1,0,344)),(455512,(0x07,2,0,-776)),(455520,(0xb7,3,0,65))]:eq(p,v)
call(29024,796360);call(447216,796360);call(455528,796360)
# account result+16 is parser -2384. Decoder+32 -> account+40 -> context368.
assert 344+(32+8-16)==368
# Exact complete predicate instruction span, with branch destinations exercised.
expected={177752:(0xb7,3,0,0),177760:(0x7b,0x3a,-1760,0),177768:(0x79,0x73,392,0),177776:(0x55,3,10,0),177784:(0x79,0x73,376,0),177792:(0x55,3,8,0),177800:(0x79,0x73,384,0),177808:(0x55,3,6,0),177816:(0x79,0x73,368,0),177824:(0xb7,4,0,1),177832:(0x7b,0x4a,-1760,0),177840:(0x15,3,2,0),177848:(0xb7,3,0,0),177856:(0x7b,0x3a,-1760,0)}
for p,v in expected.items():eq(p,v)
for values in itertools.product([0,1],repeat=4):
 regs={};mem={368:values[0],376:values[1],384:values[2],392:values[3]};stack={};pc=177752
 while pc<177864:
  op,r,off,imm=ins(O,pc);d=r&15;s=r>>4
  if op==0xb7:regs[d]=imm
  elif op==0x79:regs[d]=mem[off]
  elif op==0x7b:stack[off]=regs[s]
  elif op in (0x55,0x15):
   if (regs[d]!=imm if op==0x55 else regs[d]==imm):pc+=off*8
  else:raise AssertionError(op)
  pc+=8
 assert stack[-1760]==int(not any(values)),values
for p,v in [(178032,(0x79,0xa1,-1760,0)),(178040,(0x57,1,0,1)),(178048,(0x55,1,53,0))]:eq(p,v)
assert ins(C,509208)==(0x79,0x78,288,0) and ins(C,509232)[0]==0x55
before=(P/'before/sharing.rs').read_text();after=(P/'proposal/sharing.rs').read_text();old='let graduated=ctx.accounts.bonding_curve.real_token_reserves==0;';new='let graduated=ctx.accounts.bonding_curve.virtual_token_reserves==0\n   && ctx.accounts.bonding_curve.virtual_sol_reserves==0\n   && ctx.accounts.bonding_curve.real_token_reserves==0\n   && ctx.accounts.bonding_curve.real_sol_reserves==0;';assert after==before.replace(old,new)
assert '.ok_or(FeeError::AmmAccountsRequiredForGraduatedCoin)?'in after
for n,h in J(P/'input-bindings.json')['inputs'].items():assert H(P/'inputs'/n)==h,n
if (P/'manifest.json').exists():
 for n,h in J(P/'manifest.json').items():assert H(P/n)==h,n
print(json.dumps({'passed':True,'predicate':'four reserves all zero','predicate_truth_assignments':16,'full_typed_decoder_bytes':1448,'proposal_sites':1,'option_ordering':'unchanged and unresolved','builds':0,'runtime_executions':0}))
