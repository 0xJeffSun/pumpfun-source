# Interim typed decoder bridge

Full original unchecked BondingCurve decoder [538040,539488) is normalized-byte and relocation-pattern equal to current named `pump_fees_candidate::pump::accounts::BondingCurve::try_deserialize_unchecked` [366104,367552). This is a complete 1448-byte function comparison, not a fragment.

Original reads serialized virtual_token_reserves at +8 into r7 (538168), virtual_sol_reserves at +16 into r8 (538448), real_token_reserves at +24 into r9 (538512), real_sol_reserves at +32 into r4 (538576), token_total_supply at +40 into r5 (538640). Decoder output writes these to +32/+40/+48/+56/+64 at539456/539448/539440/539432/539416. The output's first32 bytes are creator; complete/mode occupy later bytes.

The named parser chain is445160→70520→28120→537312→538040. Account adapter28120 copies decoder output+16 onward to account result+24, while first16 decoded bytes become account result+8/+16. Parser copies account result+16 onward through stack-776 into context+344, and stores account result+8 atcontext+336. Thus reserve members map to context368/376/384/392.

Original initial branch177768..177856 sets graduated iff virtual_token_reserves!=0 AND virtual_sol_reserves==0 AND real_token_reserves==0 AND real_sol_reserves==0. Current source tests only real_token_reserves==0. This is an interim result: packet still needs independently executable assertions and whole current application evidence before a proposed patch is sealed. No source edits/build/runtime performed.
