# Sharing creation graduation predicate: source-only proposal

Replace only the current `real_token_reserves == 0` predicate with conjunction of zero virtual-token, virtual-SOL, real-token and real-SOL reserves. Preserve the accepted enum19 conversion and all current optional-account checks, state writes, calls and errors. `proposal.patch` is the exact one-site change. No main edit, build or runtime execution was performed.

## Bound evidence and complete paths

The original ELF is SHA256 `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`; current executable is `70ddf61ad431b950aefd736ac50da156c9079257ea95f32cfcd9635266e40429`, current symbols `6b759981da5fa4f50158ca581a1cd44fb9c3ac6a7579db0c0cba6e678e888ace`. All26 current source hashes are captured in input-bindings.json. Full original wrapper639104..640464, parser445160..its inventory end, application177720..190104, adapter70520..70704 and28120..29144, checked decoder537312..538040, unchecked decoder538040..539488, and current complete application509160..522216 and checked/unchecked decoders are retained in evidence/. Full function inventory is retained without changing its classifications.

Original wrapper639288 calls parser445160, then639544 calls application177720. Parser446848 calls70520 with output stack-2400. Its failure label is the literal `bonding_curve` at806268 (446912/446928). Helper70520 consumes one48-byte account entry and calls28120 at70688. Adapter28120 performs account checks and data borrow before calling checked decoder537312 at28776; checked decoder validates discriminator then calls unchecked538040 at538024. All complete bodies and their calls/relocations/data inventory entries are retained.

## Typed member mapping

The entire original unchecked decoder538040..539488 is equal under the existing call/relocation normalization to current symbol-named `pump_fees_candidate::pump::accounts::BondingCurve::try_deserialize_unchecked`366104..367552:1448 bytes and the full relocation pattern, not a local fragment. The pinned IDL defines the five leading serialized fields as u64 virtual_token_reserves, virtual_sol_reserves, real_token_reserves, real_sol_reserves, token_total_supply.

Original serialized reads at538168/538448/538512/538576 are from data+8/+16/+24/+32 into r7/r8/r9/r4. Their final decoder output stores539456/539448/539440/539432 put them at result+32/+40/+48/+56. These result positions need not equal serialization layout; the proof follows the actual stores.

Adapter28120 uses decoder output stack-80. At28984/29008/29016/29024 it copies57 bytes from decoder result+16 into account result+24, yielding the four reserves at account+40/+48/+56/+64. Parser output is stack-2400; therefore account+16 starts atstack-2384. At447184..447216 it copies65 bytes from there tostack-776. At455496..455528 it copies those65 bytes to final context+344. The reserves consequently reach context+368/+376/+384/+392. This connects typed decoded members to application operands without inferring field identity merely from final offsets.

## Boolean control flow and correction history

177752/177760 initialize the saved flag to0. Nonzero context392,376 or384 branches directly to177864 retaining0. Otherwise177824/177832 set flag1, and177840 jumps to177864 when context368 equals0, retaining1. A nonzero final field falls through177848/177856 and resets0. Thus the flag is1 exactly when all four reserves are zero. At178032..178048 it is reloaded/masked; nonzero selects178480, the optional-pool branch. The non-graduated route compares payer to the bonding-curve creator and reaches the shared state-write path at181008. The full original body shows all later uses and returns; the complete current body demonstrates the single real-token test at509208/509232 and current pool path509240 onward.

The initial analysis incorrectly inverted the last branch and claimed virtual-token nonzero. Parent review identified this against the existing all-zero `pool-base` case. That incorrect note is preserved as initial-findings.incorrect-preserved.md; initial-findings.md records the correction. The verifier interprets the complete original predicate span for all16 zero/nonzero combinations and asserts the all-zero truth table. These are static instruction evaluations, not new target fixtures or executions.

## Exact scope and limitations

The change affects inputs where real_token_reserves is zero but at least one other reserve is nonzero: the corrected source takes the original non-graduated creator route. All-zero accounts continue to use the pool route. Existing finite corpus success is not a proof for that entire input domain; no new runtime case is proposed or run here.

Original optional pool/program/event checks are still later repeated (enum calls186904,187336,189328), while current source prechecks program/event early. This distinct ordering/ownership discrepancy remains unresolved and is not altered by this proposal. Full downstream equivalence, parser/borrow/error closure and whole original application identity are not claimed. The short-allocation security findings are separate and unaffected.

Run `python3 -B verify.py` from this self-contained packet. It checks full decoder correspondence, exact call/member-copy links, original branch truth table, pinned hashes, and exact source substitution. It does not compile or invoke a target program.
