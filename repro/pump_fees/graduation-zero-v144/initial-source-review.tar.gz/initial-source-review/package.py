from pathlib import Path
import shutil,json,hashlib,difflib,sys
W=Path(__file__).resolve().parent;R=W.parents[1];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in ['inputs','method','evidence','before','proposal']:(W/d).mkdir(exist_ok=True)
for n in ['elf_reader.py','disasm.py','analyze_elf.py']:shutil.copy2(R/'work/fees-next-owned-error-review/method'/n,W/'method'/n)
for n,p in [('original.so',R/'work/fees-next-owned-error-review/inputs/original.so'),('candidate.so',R/'work/fees-sharing-owned-error-build/candidate.so'),('symbols.so',R/'work/fees-sharing-owned-error-build/symbols.so')]:shutil.copy2(p,W/'inputs'/n)
before=(R/'programs/pump-fees/src/sharing.rs').read_text();old='let graduated=ctx.accounts.bonding_curve.real_token_reserves==0;';new='let graduated=ctx.accounts.bonding_curve.virtual_token_reserves==0\n   && ctx.accounts.bonding_curve.virtual_sol_reserves==0\n   && ctx.accounts.bonding_curve.real_token_reserves==0\n   && ctx.accounts.bonding_curve.real_sol_reserves==0;';assert before.count(old)==1
after=before.replace(old,new);(W/'before/sharing.rs').write_text(before);(W/'proposal/sharing.rs').write_text(after);(W/'proposal.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/programs/pump-fees/src/sharing.rs',tofile='b/programs/pump-fees/src/sharing.rs')))
shutil.copy2(R/'programs/pump-fees/idls/pump.json',W/'inputs/pump.json');shutil.copy2(R/'work/fees-sharing-owned-error-build/analysis/full-function-inventory.json',W/'inputs/inventory.json')
sys.path.insert(0,str(W/'method'));import disasm
I=json.loads((W/'inputs/inventory.json').read_text())
for side,file,starts in [('original','original.so',[639104,445160,177720,70520,28120,537312,538040,60128,51904]),('candidate','symbols.so',[509160,365376,366104])]:
 e=disasm.a.Elf((W/'inputs'/file).read_bytes());rows=I['original_rows' if side=='original'else'candidate_rows']
 for start in starts:
  row=next(x for x in rows if x['start']==start);(W/'evidence'/f'{side}-{start}.asm').write_text(disasm.render(e,start,row['end']));(W/'evidence'/f'{side}-{start}.json').write_text(json.dumps(row,indent=2)+'\n')
source_map=json.loads((R/'work/fees-sharing-owned-error-main-control/source-proposed.json').read_text());assert all(H(R/p)==h for p,h in source_map.items());(W/'input-bindings.json').write_text(json.dumps({'current_source':source_map,'inputs':{p.name:H(p)for p in (W/'inputs').iterdir()}},indent=2)+'\n')
