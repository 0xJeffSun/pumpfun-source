# Fixed Linux v1.44 Fees build proposal — revision 2

This is an unexecuted build proposal for one manual Ubuntu x86_64 source build. The helper's file-retention functions were imported and tested against synthetic temporary files; its build entrypoint, compiler, downloads and subprocess runner were not executed. No program source change, runtime probe, container or workflow dispatch was performed. The source checkpoint stays at `4ffe8bd88761059693e481ae972443c10204f7af`; the input manifest binds all 22 source/workspace/IDL/README files and the existing CLI SDK sources. Rust source, root lockfile, crate manifests and release profile remain unchanged.

Revision 1 remains byte-for-byte unchanged at `work/core-linux-v144-build-plan`, manifest SHA-256 `7f7726e02045a6ab917c0f3d72ac62182dbed27a2e513b22fa7c13ea639c5d62`. Its complete 19-file contents are also retained in `revision1-sealed-proposal.tar.gz`. Revision 1 has a known pre-read keypair-exclusion defect and must not be executed. `REVISION2_CHANGES.md` records the review and correction.

The evidence motivating this single test is the official v1.44 Linux sysroot's `/home/runner/work/platform-tools/platform-tools/out/rust/library/alloc/src/string.rs` path, which appears in the captured Fees executable. The previously used Darwin distribution embeds `/Users/runner/...`. The platform libraries also have different target object identities. This observation supports testing the official Linux distribution; it does not identify the complete historical toolchain, dependency graph or source.

## Proposed installation after review

Copy only these three reviewed proposal files into new paths:

| Proposal | Destination |
| --- | --- |
| `core-linux-v144.yml` | `.github/workflows/core-linux-v144.yml` |
| `core_linux_v144_build.py` | `scripts/core_linux_v144_build.py` |
| `core_linux_v144_inputs.json` | `scripts/core_linux_v144_inputs.json` |

The workflow is manual (`workflow_dispatch` only), uses one `ubuntu-24.04` job, read-only repository permission, pinned checkout/upload action revisions, no cache action, no matrix, no tool-version input and no fallback. Its two checkouts separate reviewed tooling from frozen source. The helper exports exactly the 22 expected source files into a fresh directory under `RUNNER_TEMP`; no captured or previous executable is exported into that compiler workspace. The captured ELF is first read by `compare_after_build()` after the single compile returns zero and produces the expected candidate. Compilation neither copies nor uses its bytes, headers, relocations or padding.

This plan does not install those destinations or dispatch the workflow. Root owns any later installation, review and dispatch. A new dispatch/rerun would be a new attempt; the helper itself makes at most one compiler invocation and never replaces a failed attempt, changes a dependency, repairs a source or tries another flag.

## Fixed recipe and isolation

The exact compile command remains:

```text
cargo build-sbf --manifest-path <fresh-source>/programs/pump-fees/Cargo.toml
  --tools-version v1.44 --offline --sbf-sdk <fresh-sdk>
  --sbf-out-dir <fresh-artifacts> -- --locked --offline
```

The root release profile stays `panic=abort`, `overflow-checks=true`, `lto=false`, `codegen-units=1`; the default SBF architecture and features remain those of the same CLI invocation. The helper supplies no Rust compiler flags, source transformations, path substitutions or binary modifications. Official `cargo-build-sbf` 2.1.21 itself adds `-Zremap-cwd-prefix=` by default at retained upstream `main.rs` lines 718–720. That behavior was already part of the existing recipe and remains unchanged; no additional/adaptive remapping is introduced.

Target, Cargo home, rustup home, SDK and temporary directories are new. The process environment contains only recorded location variables, a fixed system PATH and locale; inherited compiler/configuration variables are not passed. Ancestor Cargo/toolchain configurations are rejected. The helper bootstraps the same host Cargo 1.94.0 and rustup 1.29.0 versions; the target compiler and linker come from official platform-tools v1.44. The SDK source hashes must equal the prior recorded CLI 2.1.21 SDK hashes.

CLI 2.1.21 hardcodes `$HOME/.cache/solana/v1.44/platform-tools` and has no alternate cache flag (upstream lines 244–254). The helper requires that location absent, extracts the independently hash-verified official archive under `RUNNER_TEMP`, then creates exactly one cache symlink to that extraction. `HOME` is unchanged. Existing caches are never reused, removed or overwritten. Parent explicitly approved this implementation and the unchanged CLI default; it is not a historical path reconstruction.

## Official downloads and dependency evidence

- Platform archive: official v1.44 Linux x86_64 asset 234589397, **490,710,349 bytes**, SHA-256 `6719b889d60677a8a2fcf4c82f68441a1afe0ab093edd2efe9f84a67a808b3e9`, release tag commit `fe5617c48364a0cdfd0c91c6d5a30f1dd6d6bb90`. The whole archive and selected member hashes are checked before execution. Full extracted file/symlink maps are retained and checked unchanged after compilation.
- CLI archive: official Agave v2.1.21 Linux x86_64 asset **247593735**, **298,782,636 bytes**, commit **`8a085eebcb901b6846d1f82f4636667742146545`**. Release metadata, exact asset URL/ID/size and the hashed release YAML are verified. There is no publisher digest and no independently retained archive SHA yet; the controlled run records the actual complete downloaded archive SHA and all extracted file hashes before use. Do not describe that recorded hash as publisher attestation. No CLI archive was downloaded during planning.
- Host rustup-init 1.29.0 is pinned to its official published SHA-256 `4acc9acc76d5079515b46346a485974457b5a79893cfb01112423c89aeb5aa10`. The official Rust 1.94.0 channel manifest is pinned to SHA-256 `aaa177def36e01d539bee6bde95295230b9ce378f81057845db8d0ebe97898ee`. Rustup installs that fixed minimal host toolchain in the new homes, checks official component digests, and the helper records installed bytes and versions. No host version search/fallback is performed.
- Frozen Cargo.lock contains **252 public crates.io packages** and one local package, with no Git/path dependency. The preparatory `cargo fetch --locked` obtains the public archives and registry source trees. Each archive SHA must equal its lock checksum. Every extracted archive member is compared with the actual source tree; only Cargo's `.cargo-ok` marker may be additional. All archive bytes, per-file source hashes and registry index/config hashes are retained before/after; the source and archives must stay identical during the offline compile. This preserves Cargo registry paths, with no vendor replacement or dependency edits.

The public URLs, API metadata, official builder source and host manifest/checksums read during preparation are retained in `provenance/`. Large compiler/CLI/host archives were not downloaded by this planning task. The existing platform archive evidence was read and copied as small provenance records only.

## Retained output and acceptance

Each fresh run retains `evidence/attempt.json` before work starts, every command/exit code/raw log, downloads (including incomplete download files on failure), source snapshot and hashes, dependency archives/source hashes, SDK and compiler/host/system maps, runner image/OS information, and a final artifact hash manifest. The single build command has its own return code and elapsed time. A source/dependency/tool drift or compiler error ends the run without fallback. Target file hashes and any emitted candidate are retained even when compilation returns an error.

On successful compilation the entire candidate is copied unchanged to `evidence/pump_fees_candidate.so`, then compared byte-for-byte with captured `evidence/original/pump_fees/deployed.so` from the frozen revision. The original must hash to `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`. The comparison reports both sizes/hashes, complete equality, first difference and differing byte counts without normalization. It also records whether the new SHA equals the retained Darwin candidate `a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa` (769,000 bytes), without treating that as runtime validation.

The normal CLI may generate an unused local deployment keypair next to build artifacts. The helper excludes `*-keypair.json` paths before file inspection, opening, hashing or copying, and records only excluded path strings. Target/artifact inventories and final evidence hashing all use this pre-read exclusion; excluded directories are pruned. The workflow also explicitly excludes these paths from uploads. An unexpected keypair in the source tree causes path-set rejection before any source file is opened, and a candidate symlink is rejected before it can copy another file's contents. No user key or signing operation is needed. The upload contains only `evidence/`, with a 30-day retention period and uncompressed transport of already-compressed archives. Root must preserve the completed evidence durably before expiry if the run is accepted.

A successful workflow means the fixed compilation and honest comparison completed; `full_byte_equality=false` is a valid result, not a reason to patch, normalize or try a variant. No runtime validation is performed and no existing receipt is automatically transferred to a changed ELF. The current original-byte-equality claim remains false until the new comparison proves otherwise. The hosted image, system libraries and source include paths are recorded but are not a fully hermetic historical reconstruction. Cargo's offline option is preserved; this proposal does not claim an operating-system network sandbox.

## Checks performed on this proposal

Python AST parsing, YAML parsing/structure inspection, fixed source hashes at the selected Git revision, official metadata/checksum retrieval and static control-flow review were performed. Revision 2 also imports helper definitions and runs seven focused synthetic file-retention tests, with read-open traps on excluded files. All seven pass; `focused-tests.log` retains their output. These tests never call `build()`, `main()`, the downloader or subprocess runner. `static-review.json` records the checks, and `manifest-sha256.json` seals this proposal and retained planning evidence.
