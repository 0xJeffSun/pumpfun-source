# Revision 2 review and correction

Revision 1 remains unchanged and is archived in full. Its prior static review missed a genuine defect: the artifact dictionary comprehension removed `*-keypair.json` entries only after `tree_hashes()` had already opened and hashed them. The target inventory had no exclusion. Thus revision 1's claimed never-read behavior was false, even though it copied only the candidate to evidence. Revision 1 was never executed as a build.

Revision 2 changes:

1. `tree_hashes(root, exclude=..., excluded_paths=...)` now applies a caller-supplied path predicate before any entry inspection or content read. It prunes excluded directories. Omitted entries produce only relative path strings; there are no sizes, hashes or link targets for them.
2. `retain_generated_outputs()` uses the exclusion for both target and artifact maps and copies only the specifically named candidate. It refuses candidate symlinks. It runs in `main()`'s `finally` block, so a failure in post-build source/dependency checks no longer skips the emitted-candidate/target/artifact evidence entirely. Retention errors are recorded separately from the original failure.
3. `seal_evidence()` applies the same exclusion to final evidence hashing, records any unexpected keypair paths as path-only metadata, and excludes its own manifest from its digest set. The workflow adds explicit root/nested keypair and keypair-directory upload exclusions, including on failed runs.
4. `source_hashes()` checks the complete frozen source path set and rejects symlinks before opening files. Unexpected generated files therefore trigger a source-integrity failure without hashing their contents.
5. Download status now says `downloaded-content-hash-recorded` when neither an expected SHA nor an expected size was provided. Previously such metadata downloads were incorrectly labelled size-checked. This changes reporting only; the fixed compiler archive checks remain intact.

The fixed source, dependencies, profiles, compiler versions, build command and tool/SDK pins are unchanged. There is no new build, runtime probe, workflow installation or dispatch. The existing CLI default and cache-path behavior remain as previously reviewed. CLI archive provenance is still limited to official URL/asset identity/size and its recorded download SHA, rather than a publisher digest.

Seven focused tests cover custom pre-read exclusion, recursive/symlink pruning, target/artifact retention after a synthetic failure, final evidence sealing/resealing, unexpected source rejection before opening, candidate-symlink rejection and path-only exclusion metadata. File reads are trapped through `Path.open`, `builtins.open` and `io.open`; excluded synthetic files may be created for setup but must never be opened for reading. Tests invoke only these file-inventory functions, not build, download, workflow or subprocess code.

Static path audit:

| Content path | Allowed read/copy | Exclusion or guard |
| --- | --- | --- |
| Frozen compiler source | Exactly 22 pinned inputs | Whole path set verified before any source file is opened; symlinks rejected |
| Compiler/SDK/dependency archives and files | Official tool/dependency evidence | Separate immutable inputs; the generated deployment file is not located here |
| `target/` | Non-keypair build file hashes | Parameterized pre-read exclusion, nested directories pruned |
| `artifacts/` | Non-keypair hashes; exactly `pump_fees_candidate.so` copied | Pre-read exclusion; candidate symlink rejected |
| `evidence/` manifest | Retained non-keypair evidence hashes | Pre-read exclusion; excluded path strings saved; own manifest omitted |
| Workflow upload | `evidence/` only | Explicit keypair-file/directory exclusions; neither target nor artifact directories uploaded |
| CLI build log | Process output | Retained official source creates the keypair at lines 806–814 and logs only its path at 886–889; no keypair-content read or output is present in this path |

The helper has not been exercised on a hosted compiler run. This review establishes the tested exclusion behavior and static call paths, not successful Linux compilation or full original ELF equality.
