from pathlib import Path
import argparse,hashlib,json,re
P=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--repo',type=Path);args=a.parse_args();m=json.loads((P/'manifest.json').read_text());assert H(P/'manifest.json')==(P/'manifest.sha256').read_text().split()[0]
assert set(m)=={str(p.relative_to(P))for p in P.rglob('*')if p.is_file()and p not in[P/'manifest.json',P/'manifest.sha256']}
for n,h in m.items():assert not(P/n).is_symlink()and H(P/n)==h,n
b=json.loads((P/'bindings.json').read_text());assert b['builds']==b['runtime_executions']==0 and not b['IDL_changed']and len(b['baseline_source'])==26
if args.repo:
 for n,h in b['baseline_source'].items():assert H(args.repo/n)==h,n
f='programs/pump-fees/src/sharing.rs';before=(P/'before'/f).read_text();after=(P/'proposal'/f).read_text();old=next(x for x in before.splitlines()if'vec![87,124,52,191,52,38,214,232]'in x)
start=after.index('  crate::pump::cpi::migrate_bonding_curve_creator(');end=after.index('  ))?;',start)+len('  ))?;');new=after[start:end];assert after==before.replace(old,new)and before.count(old)==1
assert 'new_with_signer'not in new and new.count('.to_account_info()')==6
idl=json.loads((P/'before/programs/pump-fees/idls/pump.json').read_text());ix=next(x for x in idl['instructions']if x['name']=='migrate_bonding_curve_creator');assert ix['args']==[]and bytes(ix['discriminator']).hex()=='577c34bf3426d6e8'
assert[(x['name'],x.get('signer',False),x.get('writable',False))for x in ix['accounts']]==[('mint',False,False),('bonding_curve',False,True),('sharing_config',False,False),('event_authority',False,False),('program',False,False)]
meta=(P/'evidence/original-572392.asm').read_text();words=[(int(a),int(v))for a,v in re.findall(r'u16\[r1\+(\d+)\] = (\d+)',meta)];assert words==[(32,0),(66,256),(100,0),(134,0),(168,0)]
helper=(P/'evidence/original-556488.asm').read_text();caller=(P/'evidence/original-177720.asm').read_text()
for exact in ['556536: 0703000000ffffff','556672: 18010000577c34bf000000003426d6e8','556744: 85100000a3070000','557024: 7a0a98ff00010000','557056: 8510000088010000','558832: 85100000cf500000']:assert exact in helper,exact
assert 'call 556488'in caller and caller.index('call 552776')<caller.index('call 556488')
print(json.dumps({'status':'PASS','changed_files':1,'IDL_changes':0,'original_metadata_flag_words':[v for _,v in words],'builds':0,'runtime_executions':0,'whole_helper_identity':False}))
