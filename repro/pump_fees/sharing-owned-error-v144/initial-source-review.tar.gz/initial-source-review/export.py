from pathlib import Path
import sys,json,shutil
W=Path(__file__).resolve().parent;R=W.parents[1];M=W/'method';M.mkdir(exist_ok=True)
for f in ['analyze_elf.py','disasm.py']:shutil.copy2(R/'work/fees-unmatched-application-review/method'/f,M/f)
sys.path.insert(0,str(M));import disasm
I=json.loads((R/'work/fees-withdraw-lazy-build/analysis/full-function-inventory.json').read_text());E=W/'evidence';E.mkdir(exist_ok=True)
for side,path,starts in [('original',R/'work/fees-withdraw-lazy-build/analysis/method/inputs/original.so',[639104,177720,289880]),('current',R/'work/fees-withdraw-lazy-build/candidate.so',[429424,509160])]:
 e=disasm.a.Elf(path.read_bytes());rows=I['original_rows'if side=='original'else'candidate_rows']
 for start in starts:
  r=next(x for x in rows if x['start']==start);(E/f'{side}-{start}.asm').write_text(disasm.render(e,start,r['end']));(E/f'{side}-{start}.json').write_text(json.dumps(r,indent=2)+'\n');print(side,start,r['end'],r['bytes'])
