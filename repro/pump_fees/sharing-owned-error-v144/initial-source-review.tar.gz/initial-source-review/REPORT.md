# Next Fees owned-error proposal: sharing creation's first missing pool

The minimal source-supported change is one substitution in `sharing.rs:15`:

```diff
-   let pool=ctx.accounts.pool.as_ref().ok_or(error!(FeeError::AmmAccountsRequiredForGraduatedCoin))?;
+   let pool=ctx.accounts.pool.as_ref().ok_or(FeeError::AmmAccountsRequiredForGraduatedCoin)?;
```

`proposal.patch` and `proposal/sharing.rs` contain only that change. This removes eager construction of an origin-bearing owned Anchor error from the successful `Some(pool)` path and lets `?` convert enum19 on the missing path, without source-origin attachment. It changes no branch predicate, account layout, later option check, CPI argument, state mutation or payout arithmetic. Nothing has been compiled, executed or integrated.

## Input and application attribution

Original ELF SHA256 `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`; current candidate `76b027c2f4393912e274c1f05b21de77743e18116969a3546ccf8718c2cfa7f7`; symbols `086901d9b3860569b3990198e7a63a9af94bace3602b4d96119eaceda2eca351`. `input-bindings.json` binds current26 source/workspace/IDL/README files. The before/after source is review-local; main and frozen prior packets were untouched.

Original wrapper[639104,640464) references `Instruction: CreateFeeSharingConfig` at807447, calls parser445160 at639288, application177720 at639544 and exit464168 at639616. The current symbol-bearing application is[509160,522768), original[177720,190104). Both complete bodies, wrappers, original parser and exit, complete enum/name/display/box bodies and their selected current counterparts are retained. The original/current inventory entries remain `unmatched`; no source attribution changes a classification to a normalized match.

## Original first-pool control and parser link

The original application loads the optional-pool marker at178480 from context+1468. At178488 it branches to178504 when the marker equals2; the present path jumps from178496 to178560. Only the missing arm loads enum19 at178520 and calls the complete enum-to-owned-error converter289880 at178528. It leaves through the shared result/return path before first sharing-state stores beginning181016.

The pool identity is supported by the complete original parser chain, not a source-name guess:

- Parser445160 calls10760 at447696. On parse failure its diagnostic account name is the four bytes `pool` at802316, referenced447760/447776.
-10760 is the optional account adapter. It uses caller output+260 as marker, returning2 for the program-ID sentinel. Its present path calls71840, which calls29144, which calls checked decoder575408. That decoder calls unchecked576136.
- Unchecked576136 has the same complete normalized instructions and relocation pattern as current390088, symbol-named `pump_amm::accounts::Pool::try_deserialize_unchecked`.
- At447720 the caller reads output[-2400+260] = stack-2140. At447816 it preserves that marker at-3304;455664 reloads it and455672 writes context+1468. The adapter result's payload is separately copied at447880 and455352. Thus the application marker is the parsed optional Pool, including its missing sentinel.

This closes the narrow parser-to-first-pool presence link. It does not prove all fields or branches in the create-sharing parser.

## Owned error role and current mismatch

Complete converter[289880,290384) formats the enum name through280976, its message through290384, adds6000 at290272, sets no-origin tag2 at290288, and boxes through709232. The enum19 name path allocates35 bytes and the literal stores289040..289144 spell `AmmAccountsRequiredForGraduatedCoin`. Display path290528 loads804835 with45 bytes: `AMM accounts are required for graduated coins`. The original raw error number is6019, not an unrelated framework error.

Current application explicitly builds6019 at510488, embeds sharing.rs source line15 at510504, and calls owned box conversion680640 at510560. Only afterward does510592 branch on the saved optional-pool marker. Therefore a present pool still pays the owned-error construction/cleanup cost, and a missing pool receives an origin not supplied by the original enum conversion. The complete current converter632880 already matches original289880 under the retained normalization/relocation method, as established for the preceding withdrawal fix. The proposal uses that existing natural `From<FeeError>` role rather than manually constructing an AnchorError, adding layout controls or inventing source coordinates.

## Explicitly unresolved neighboring differences

This one-site proposal is not a complete sharing-creation reconstruction. The original application makes an early raw four-word decision from context+368/+376/+384/+392; the current source uses only `bonding_curve.real_token_reserves == 0`. The four field names have **not** been proved here, so no predicate rewrite is proposed. The correction is justified on the shared first-pool path, not by assuming identical reachability for every original/current input.

The original also repeats a missing-pool enum19 conversion at186904, and later checks an optional program pointer and event marker with enum19 calls187336 and189328. The current source prechecks `program.is_some() && event.is_some()` early and unwraps them later. These are distinct ordering/ownership leads. Full original field-role and intervening CPI/state sequencing must be proved before changing them. Do not broaden this proposal to those sites merely because the error code matches.

`full-immediate-call-ledger.json` preserves every direct call from both application bodies and its complete bounded target row where available; each target's full disassembly is saved. This is not arbitrary transitive call/data closure. All successful/payout/CPI paths remain as before in the proposed source. Full application equality, all cleanup/refcount paths, parse equivalence, exact post-build diagnostics and any runtime improvement are unproven until a separately authorized build/replay. The FeeConfig short-allocation security observation is independent and not part of this equivalence proposal.
