from pathlib import Path
import struct,json,sys,hashlib,difflib
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'method'));from elf_reader import Elf
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text());O=Elf(P/'inputs/original.so');C=Elf(P/'inputs/current.so')
def ins(e,p):return struct.unpack('<BBhi',e.b[p:p+8])
def call(e,p,t):assert ins(e,p)[0]==0x85 and p+8+ins(e,p)[3]*8==t
for p,t in [(639288,445160),(639544,177720),(639616,464168),(178528,289880),(447696,10760),(10928,71840),(72008,29144),(29800,575408)]:call(O,p,t)
assert b'Instruction: CreateFeeSharingConfig'==O.b[807447:807447+len(b'Instruction: CreateFeeSharingConfig')]
assert O.b[802316:802320]==b'pool'
assert ins(O,178480)==(0x71,0x71,1468,0)
assert ins(O,178488)==(0x15,1,1,2) and ins(O,178496)[0]==5
assert ins(O,178520)[3]==19
assert ins(O,447720)==(0x71,0xa1,-2140,0)
assert ins(O,447816)==(0x7b,0x1a,-3304,0)
assert ins(O,455664)==(0x79,0xa3,-3304,0)
assert ins(O,455672)==(0x73,0x36,1468,0)
assert ins(O,290272)[3]==6000 and ins(O,290288)==(0x72,0x0a,-192,2)
name=bytearray(35)
for p,off in [(289040,24),(289064,16),(289088,8),(289112,0)]:name[off:off+8]=O.b[p+4:p+8]+O.b[p+12:p+16]
name[31:35]=O.b[289144+4:289144+8]
assert name==b'AmmAccountsRequiredForGraduatedCoin'
assert O.b[804835:804880]==b'AMM accounts are required for graduated coins'
assert O.normalized[289880:290384]==C.normalized[632880:633384] and O.pattern(289880,504)==C.pattern(632880,504)
assert O.normalized[576136:579040]==C.normalized[390088:392992] and O.pattern(576136,2904)==C.pattern(390088,2904)
assert any(t==576136 for pc,t in O.calls.items()if 575408<=pc<576136)
assert ins(C,510488)[3]==6019 and ins(C,510504)[3]==15
call(C,510560,680640);assert ins(C,510592)==(0x15,2,1507,2)
before=(P/'before/sharing.rs').read_text();after=(P/'proposal/sharing.rs').read_text();old='.ok_or(error!(FeeError::AmmAccountsRequiredForGraduatedCoin))?';new='.ok_or(FeeError::AmmAccountsRequiredForGraduatedCoin)?';assert before.count(old)==1 and after==before.replace(old,new)
assert(P/'proposal.patch').read_text()==''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/programs/pump-fees/src/sharing.rs',tofile='b/programs/pump-fees/src/sharing.rs'))
for n,h in J(P/'input-bindings.json')['inputs'].items():assert H(P/'inputs'/n)==h
if(P/'manifest.json').exists():
 for n,h in J(P/'manifest.json').items():assert H(P/n)==h,n
print(json.dumps({'passed':True,'proposal_sites':1,'original_error':6019,'original_origin':'None','current_eager_origin_line':15,'whole_application_equality':False,'builds':0,'runtime_executions':0}))
