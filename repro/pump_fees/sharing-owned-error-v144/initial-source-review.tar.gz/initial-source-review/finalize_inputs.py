from pathlib import Path
import json,hashlib,shutil,sys,difflib
W=Path(__file__).resolve().parent;R=W.parents[1];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path.insert(0,str(W/'method'));import disasm
I=json.loads((R/'work/fees-withdraw-lazy-build/analysis/full-function-inventory.json').read_text());(W/'inputs').mkdir(exist_ok=True)
for src,name in [(R/'work/fees-withdraw-lazy-build/analysis/method/inputs/original.so','original.so'),(R/'work/fees-withdraw-lazy-build/candidate.so','current.so'),(R/'work/fees-withdraw-lazy-build/symbols.so','symbols.so')]:shutil.copy2(src,W/'inputs'/name)
(W/'before').mkdir();(W/'proposal').mkdir();before=(R/'programs/pump-fees/src/sharing.rs').read_text();needle='.ok_or(error!(FeeError::AmmAccountsRequiredForGraduatedCoin))?';assert before.count(needle)==1;after=before.replace(needle,'.ok_or(FeeError::AmmAccountsRequiredForGraduatedCoin)?');(W/'before/sharing.rs').write_text(before);(W/'proposal/sharing.rs').write_text(after);(W/'proposal.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/programs/pump-fees/src/sharing.rs',tofile='b/programs/pump-fees/src/sharing.rs')))
selected={};ledgers={}
for side,roots in [('original',[177720,639104,445160,464168,10760,71840,29144,575408,576136,289880,280976,290384,709232]),('candidate',[509160,429424,289488,680640,632880,390088])]:
 rows=I['original_rows'if side=='original'else'candidate_rows'];by={r['start']:r for r in rows};e=disasm.a.Elf((W/'inputs'/('original.so'if side=='original'else'current.so')).read_bytes());selected[side]=[];ledgers[side]=[]
 for s in roots:
  r=by[s];selected[side].append(r);(W/'evidence'/f'{side}-{s}.asm').write_text(disasm.render(e,s,r['end']))
  if s in [177720,509160]:
   for d in r['dependencies']['direct']:
    target=by.get(d['target']);ledgers[side].append({'call':d,'target_window':target})
    if target:(W/'evidence'/f'{side}-target-{target["start"]}.asm').write_text(disasm.render(e,target['start'],target['end']))
(W/'inputs/selected-inventory.json').write_text(json.dumps(selected,indent=2)+'\n');(W/'full-immediate-call-ledger.json').write_text(json.dumps(ledgers,indent=2)+'\n')
(W/'input-bindings.json').write_text(json.dumps({'inputs':{n:H(W/'inputs'/n)for n in ['original.so','current.so','symbols.so']},'current_source':{n:H(R/n)for n in json.loads((R/'work/fees-withdraw-lazy-build/gate-before.json').read_text())['source']},'inventory_summary':I['summary'],'method':'Unchanged bounded original/candidate catalogue from withdraw-owned-error build; no matcher changes.'},indent=2)+'\n')
print('complete roots and immediate target ledger saved')
