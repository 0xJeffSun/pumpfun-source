from pathlib import Path
import sys,json,struct
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R/'work/fees-withdraw-lazy-build/analysis/method'));from elf_reader import Elf
O=Elf(R/'work/fees-withdraw-lazy-build/analysis/method/inputs/original.so');I=json.loads((R/'work/fees-withdraw-lazy-build/analysis/full-function-inventory.json').read_text())
for label in [b'Instruction: CreateFeeSharingConfig',b'Instruction: SweepBuyback',b'Instruction: CrankDonationFeePda']:
 p=O.b.find(label);print(label,p)
 for at in range(O.lo,O.hi,8):
  if O.b[at]==24 and struct.unpack_from('<I',O.b,at+4)[0]==p:
   row=next(r for r in I['original_rows']if r['start']<=at<r['end']);print('ref',at,'window',row['start'],row['end'],'calls',[(k,v)for k,v in O.calls.items()if row['start']<=k<row['end']])
