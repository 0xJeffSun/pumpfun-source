796360: bf16000000000000                 r6 = r1
796368: 85100000ffffffff                 external {'type': 10, 'symbol': 'sol_memcpy_', 'record_offset': 872400}
796376: bf60000000000000                 r0 = r6
796384: 9500000000000000                 exit
