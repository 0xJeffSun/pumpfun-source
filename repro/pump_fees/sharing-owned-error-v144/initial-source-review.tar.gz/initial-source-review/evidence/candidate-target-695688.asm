695688: 85100000ffffffff                 external {'type': 10, 'symbol': 'sol_log_data', 'record_offset': 849776}
695696: 9500000000000000                 exit
