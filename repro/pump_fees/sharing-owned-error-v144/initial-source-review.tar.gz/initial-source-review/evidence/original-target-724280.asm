724280: 85100000ffffffff                 external {'type': 10, 'symbol': 'sol_log_data', 'record_offset': 872416}
724288: 9500000000000000                 exit
