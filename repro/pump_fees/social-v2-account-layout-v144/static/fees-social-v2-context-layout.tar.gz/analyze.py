#!/usr/bin/env python3
"""Read-only reconstruction of the bounded, frozen context-layout evidence."""
from pathlib import Path
import hashlib
import importlib.util
import json
import struct
import tomllib

ROOT = Path(__file__).resolve().parent

def sha(b):
    return hashlib.sha256(b).hexdigest()

def analyze():
    inputs = json.loads((ROOT / 'inputs.json').read_text())
    for row in inputs:
        assert sha((ROOT / row['copy']).read_bytes()) == row['sha256'], row['copy']
    spec = importlib.util.spec_from_file_location('frozen_elf', ROOT / 'elf_reader_portable.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    o = module.Elf(ROOT / 'inputs/original.so')
    c = module.Elf(ROOT / 'inputs/candidate.so')
    symbols = module.Elf(ROOT / 'inputs/symbols.so')
    assert c.b[c.lo:c.hi] == symbols.b[symbols.lo:symbols.hi]
    def instruction(elf, pc):
        opcode, regs, off, imm = struct.unpack_from('<BBhi', elf.b, pc)
        return {'pc': pc, 'slot': pc // 8, 'bytes': elf.b[pc:pc+8].hex(),
                'opcode': opcode, 'dst': regs & 15, 'src': regs >> 4,
                'offset': off, 'signed_imm': imm}
    def call(elf, pc):
        row = instruction(elf, pc)
        assert row['opcode'] == 0x85 and row['src'] == 1
        row['target_from_signed_operand'] = pc + 8 + row['signed_imm'] * 8
        assert elf.calls[pc] == row['target_from_signed_operand']
        return row
    def literal(elf, pc, length):
        assert elf.b[pc] == 0x18 and elf.relocations[pc]['type'] == 8
        at = struct.unpack_from('<I', elf.b, pc+4)[0] | struct.unpack_from('<I', elf.b, pc+12)[0] << 32
        return {'lddw_pc': pc, 'bytes': elf.b[pc:pc+16].hex(), 'relocation': elf.relocations[pc],
                'target': at, 'length': length, 'literal': elf.b[at:at+length].decode()}
    def stores(elf, first_slot, last_slot, lo, hi):
        out = []
        width = {0x73: 1, 0x6b: 2, 0x63: 4, 0x7b: 8}
        for pc in range(first_slot*8, (last_slot+1)*8, 8):
            row = instruction(elf, pc)
            if row['opcode'] in width and row['dst'] == 6 and lo <= row['offset'] < hi:
                row['width'] = width[row['opcode']]
                row['previous_instruction'] = instruction(elf, pc-8)
                out.append(row)
        assert set(range(lo,hi)) == {b for r in out for b in range(r['offset'], r['offset']+r['width'])}
        return out
    callers = []
    for name, slot, label_slot, length in [('event_authority',49731,49739,15),('program',49818,49827,7)]:
        row = {'field': name, 'call': call(o,slot*8), 'error_account_label': literal(o,label_slot*8,length)}
        assert row['call']['target_from_signed_operand'] == 6808
        assert row['error_account_label']['literal'] == name
        callers.append(row)
    original_fields = [
        {'field':'event_authority','shape':'by-value AccountInfo','start':0xb8,'end':0xe8},
        {'field':'program','shape':'by-value AccountInfo','start':0xe8,'end':0x118},
        {'field':'recipient','shape':'borrowed account pointer','start':0x118,'end':0x120},
        {'field':'quote_mint','shape':'boxed InterfaceAccount pointer','start':0x120,'end':0x128},
    ]
    candidate_fields = [
        {'field':'event_authority','shape':'borrowed UncheckedAccount pointer','start':0x250,'end':0x258},
        {'field':'program','shape':'borrowed UncheckedAccount pointer','start':0x258,'end':0x260},
        {'field':'recipient','shape':'borrowed account pointer','start':0xb8,'end':0xc0},
        {'field':'quote_mint','shape':'boxed InterfaceAccount pointer','start':0xc0,'end':0xc8},
    ]
    for r in original_fields:
        r['stores'] = stores(o,50605,50693,r['start'],r['end'])
    for r in candidate_fields:
        r['stores'] = stores(c,25942,25998,r['start'],r['end'])
    diff = [{'offset':i,'candidate':c.normalized[208000+i:208008+i].hex(),'original':o.normalized[405560+i:405568+i].hex()}
            for i in range(0,560,8) if c.normalized[208000+i:208008+i] != o.normalized[405560+i:405568+i]]
    assert [r['offset'] for r in diff] == [88]
    diagnostic = json.loads((ROOT/'inputs/exit-diagnostic.json').read_text())
    assert diff == diagnostic['normalization_diff_slots']
    assert o.pattern(405560,560) == c.pattern(208000,560)
    assert o.callsites(405560,560) == diagnostic['original_calls']
    assert c.callsites(208000,560) == diagnostic['candidate_calls']
    # Scan only the frozen current candidate, without generating any variant.
    helper_matches=[]
    pos=c.lo
    while True:
        pos=c.normalized.find(o.normalized[6808:7224],pos,c.hi)
        if pos < 0: break
        if pos % 8 == 0: helper_matches.append(pos)
        pos += 1
    assert helper_matches == []
    # Anchor AccountInfo::try_accounts clones the input; these raw anchors
    # establish its important operations without asserting historical symbol identity.
    helper_anchors = [instruction(o,slot*8) for slot in [856,864,865,866,868,869,870,871,872,877,879,880,881,882,886,889,890,891,892,893,894,895,896,897,898,899,900,901,902]]
    assert instruction(o,856*8)['signed_imm'] == 3005
    assert instruction(o,868*8)['signed_imm'] == 48
    assert instruction(o,872*8)['signed_imm'] == instruction(o,882*8)['signed_imm'] == 1
    assert o.relocations[879*8] == {'type':10,'symbol':'abort'}
    helper_call=call(o,857*8)
    assert helper_call['target_from_signed_operand'] == 721136
    versions={p['name']:p['version'] for p in tomllib.loads((ROOT/'inputs/Cargo.lock').read_text())['package']}
    assert {k:versions[k] for k in ['anchor-lang','anchor-syn','anchor-attribute-event','solana-account-info']} == {
        'anchor-lang':'0.31.1','anchor-syn':'0.31.2','anchor-attribute-event':'0.31.2','solana-account-info':'2.3.0'}
    expansion=(ROOT/'inputs/dependencies/selected-anchor-syn-event-cpi.rs').read_text()
    assert 'pub #authority_name: AccountInfo<#info_lifetime>' in expansion
    assert 'pub program: AccountInfo<#info_lifetime>' in expansion
    unchecked=(ROOT/'inputs/dependencies/anchor-unchecked-account.rs').read_text()
    account=(ROOT/'inputs/dependencies/anchor-account-info.rs').read_text()
    assert "pub struct UncheckedAccount<'info>(&'info AccountInfo<'info>);" in unchecked
    assert 'Ok(account.clone())' in account
    return {
        'scope':'Static evidence for a two-field type correction; no source edit, build or runtime execution by this review.',
        'original_sha256':sha(o.b),'boxing_only_candidate_sha256':sha(c.b),'candidate_text_equals_symbols':True,
        'input_count':len(inputs),
        'parser_ranges':{'original':{'start':395656,'end':405560,'size':9904},'candidate':{'start':198864,'end':208000,'size':9136}},
        'original_account_parser':{'start':6808,'end':7224,'size':416,'raw_sha256':sha(o.b[6808:7224]),
            'normalized_sha256':sha(o.normalized[6808:7224]),'next_inferred_entry':min(p for p in o.entries if p>6808),
            'raw_anchors':helper_anchors,'direct_error_constructor_call':helper_call,'external_calls':o.pattern(6808,416),
            'normalized_matches_in_boxing_only_candidate':helper_matches,
            'attribution':'AccountInfo-style account consumption and clone supported by raw dataflow and pinned source contract; no named exact helper match in trial01.'},
        'original_account_callers':callers,
        'original_fields':original_fields,'candidate_fields':candidate_fields,
        'original_success_output_upper_extent':0x2b0,'candidate_success_output_upper_extent':0x260,
        'mint_pointer_offset_delta':0x60,'output_extent_delta':0x50,
        'candidate_borrowed_consumption_anchors':[instruction(c,s*8) for s in range(25211,25230)],
        'shared_field_copy_anchors':{
            'social_original':[instruction(o,s*8) for s in range(50605,50611)],
            'social_candidate':[instruction(c,s*8) for s in range(25942,25948)],
            'global_original':[instruction(o,s*8) for s in range(50635,50641)],
            'global_candidate':[instruction(c,s*8) for s in range(25952,25958)]},
        'exit':{'original_start':405560,'candidate_start':208000,'size':560,'normalized_equal':False,'normalized_diff_slots':diff,
            'relocation_patterns_equal':True,'original_calls':o.callsites(405560,560),'candidate_calls':c.callsites(208000,560)},
        'selected_dependency_versions':{k:versions[k] for k in ['anchor-lang','anchor-syn','anchor-attribute-event','solana-account-info']},
        'supported_next_source_change':'In ClaimSocialFeePdaV2 only, retain the boxed quote_mint and change event_authority/program to AccountInfo while retaining existing constraints.',
        'limitations':[
            'The original is stripped; historical macro spelling and complete source provenance are not uniquely established.',
            'The failed boxing-only complete exit comparison remains failed. A new build is required to test the supported two-field correction.',
            'No complete try_accounts CFG equivalence or helper transitive closure is asserted.',
            'The parser output extent is inferred from successful output writes, not a source size_of measurement.',
            'No runtime or current-main integration acceptance is provided by this report.'
        ]
    }

if __name__ == '__main__':
    print(json.dumps(analyze(),indent=2))
