# ClaimSocialFeePdaV2 context layout: two account-value fields

The original parser supports `AccountInfo<'info>` values for `event_authority` and `program`. The boxing-only trial retains `UncheckedAccount<'info>` references for these two fields. Their different representations explain the remaining quote-mint context offset in the complete exit comparison. A focused follow-up can retain the supported boxed mint and replace only these two field types, keeping their constraints unchanged.

This is a static source-reconstruction lead. The boxing-only candidate still fails the complete exit comparison. This review made no program edits, builds, runtime calls, or main-candidate changes.

## Frozen inputs

| Object | SHA-256 |
| --- | --- |
| Captured original ELF | `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e` |
| Boxing-only trial ELF | `38e6f665bd62c5f64dddaa09429c844bf01565cdd7bcc8f9a03f9e05f8ca63ad` |
| Boxing-only trial social.rs | `bee3c04fb54be6a776c53a5eca5859e11cd9011f838452c870e86c2eb2a1910b` |
| Unchanged types.rs | `6367dc767c37b1f7ddfbe64584c05bfb6d31557e5608a86015ca11d70bd36d96` |
| Cargo.lock | `5d2be052125503747b332e88bd9a98c6134e9f8fc2009a401a58f9f554fd8ed8` |

`inputs.json` binds all 17 copied files and their provenance. The unstripped trial ELF has the exact same text bytes as the stripped trial. The copied build report identifies all 22 inputs used by the parent-owned pinned-v1.44 build; this review includes the two source files relevant to its claim, not a second complete build-input archive.

## Direct evidence

The original `try_accounts` range is 395656–405560 (9904 bytes). The boxing-only candidate range is 198864–208000 (9136 bytes). Addresses are byte offsets; the saved objdump listings display instruction slots, which must be multiplied by eight.

At original byte 397848, a raw signed internal call reaches 6808. Its error path loads relocated address 805412 with length 15: the actual bytes are `event_authority`. At byte 398544, another raw signed call reaches the same helper; its error path uses address 805427 with length 7: `program`. These account labels establish which two fields are being consumed.

The helper is bounded by observed entries 6808 and 7224, for 416 bytes. Its raw instructions check the remaining account count, return error code 3005 on an empty slice, advance the account pointer by 48 bytes, increment two reference counts with overflow-to-abort handling, and return five eight-byte components plus three flags. This is the pinned `AccountInfo::try_accounts` clone contract. There is no full normalized helper match in the boxing-only candidate, so this report does not claim a named exact helper match. Its error-constructor call to 721136 and abort relocation remain explicitly listed; this investigation does not claim their complete transitive closure.

The original parser retains the cloned components and writes them into these successful output fields:

| Field | Original output | Boxing-only output |
| --- | --- | --- |
| event_authority | `0xb8..0xe8`, 48-byte value | `0x250..0x258`, 8-byte reference |
| program | `0xe8..0x118`, 48-byte value | `0x258..0x260`, 8-byte reference |
| recipient | `0x118..0x120`, reference | `0xb8..0xc0`, reference |
| quote_mint | `0x120..0x128`, boxed pointer | `0xc0..0xc8`, boxed pointer |

The original mint pointer is stored at byte 405360 (slot 50670); the candidate pointer is stored at byte 207888 (slot 25986). The original exit then loads `context+0x120`; the candidate loads `context+0xc0`. `analysis.json` records every raw instruction that writes the four fields, including padding bytes, and their preceding loads. It also preserves the candidate's inline borrowed-account consumption sequence.

The two 48-byte values precede recipient/mint in the observed original layout, explaining their 96-byte displacement. The successful output extent is 688 bytes in the original and 608 bytes in the candidate: an 80-byte difference because two 48-byte values replace two eight-byte references. This is an inference from observed output writes, not a source `size_of` measurement or a general Rust field-order guarantee.

The leading SocialFeePda region stays at the same offsets, including a 144-byte copied section. FeeProgramGlobal's 312-byte copied section moves from candidate `0x100` to original `0x160`. These facts support the field-layout explanation; they do not support changing either account's persistent data fields or reserves.

## Pinned source contract

The selected lock/build uses anchor-lang 0.31.1, anchor-syn 0.31.2, anchor-attribute-event 0.31.2, and solana-account-info 2.3.0. The first inspected macro references were version 0.31.1; these remain frozen as reference files only. The separately frozen selected 0.31.2 macro sources provide the relevant build dependency evidence.

`selected-anchor-syn-event-cpi.rs` lines 62–66 injects `AccountInfo` for both event-CPI fields, retaining the event-authority seeds and bump. `anchor-account-info.rs` consumes one account and returns `account.clone()`. `anchor-unchecked-account.rs` stores a reference and returns that wrapper. `solana-account-info.rs` declares the `repr(C)` struct with five eight-byte members and three flags. The three account source copies were also byte-checked against the selected build cache.

This supports explicit field types matching the original dataflow. It does not prove that the historical source used the `#[event_cpi]` macro rather than equivalent explicit declarations.

## Failed comparison and limits

The entire 560-byte exit at original 405560 versus trial 208000 has exactly one remaining normalized differing instruction, at offset 88. The relocation patterns and seven direct-call positions match the preserved parent diagnostic. This review rechecks their addresses, but does not newly assert all direct-target bodies or relocated literal equivalence; those are separate acceptance checks for the follow-up build.

No complete parser CFG equivalence, runtime equivalence, or full contract source identity is established. A new source build must establish the predicted exit shape and verify its actual direct targets and data before any runtime regression or promotion. Existing failed comparison evidence stays intact.

Run `python3 -B verify.py` from a copied package to recheck its seal, all frozen inputs, the five raw disassembly ranges, signed calls and labels, all four field-store spans, dependency versions, and the expected failed exit comparison. It requires only Python's standard library and files inside this directory; it does not build or execute the program.
