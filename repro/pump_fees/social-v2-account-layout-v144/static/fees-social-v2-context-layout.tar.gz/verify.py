#!/usr/bin/env python3
"""Verify a sealed, standalone copy. No work/cache/build/runtime access."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text())
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert actual==set(manifest['files'])
for path,digest in manifest['files'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
original=(ROOT/'inputs/elf_reader.py').read_text()
line="REPO=next(p for p in Path(__file__).resolve().parents if (p/'evidence/original/pump_fees/deployed.so').is_file())"
assert (ROOT/'elf_reader_portable.py').read_text()==original.replace(line,'REPO=Path(__file__).resolve().parent')
spec=importlib.util.spec_from_file_location('frozen_analysis',ROOT/'analyze.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.analyze()
assert result==json.loads((ROOT/'analysis.json').read_text())
for name,binary,start,end in [('original-parser.asm','original.so',395656,405560),('candidate-parser.asm','candidate.so',198864,208000),('original-account-info-parser.asm','original.so',6808,7224),('original-exit.asm','original.so',405560,406120),('candidate-exit.asm','candidate.so',208000,208560)]:
    data=(ROOT/'inputs'/binary).read_bytes();covered=set()
    for line in (ROOT/name).read_text().splitlines():
        m=re.match(r'\s*(\d+):\s+((?:[0-9a-f]{2} )*[0-9a-f]{2})\s',line)
        if not m:continue
        pc=int(m[1])*8;b=bytes.fromhex(m[2]);assert data[pc:pc+len(b)]==b
        covered.update(range(pc,pc+len(b)))
    assert covered==set(range(start,end)),name
print(json.dumps({'verified':True,'sealed_files':len(actual),'inputs':result['input_count'],'assembly_ranges':5,'expected_exit_difference_offsets':[88],'original_account_info_value_fields':2,'runtime_runs':0},indent=2))
