# Fees withdrawal: avoid eager origin-bearing optional-account errors

## Concrete correction

The three token-option sites in `programs/pump-fees/src/withdrawal.rs` currently call `ok_or(error!(FeeError::IncompleteTokenAccounts))?`. This constructs an owned, origin-bearing Anchor error **before** checking whether the optional account is present. The original constructs error6035 only on the missing-account branch and has **no source origin** attached at these sites.

The minimal natural correction is:

```rust
let vault = ctx.accounts.vault_ata.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
let destination = ctx.accounts.user_ata.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
let token = ctx.accounts.token_program.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
```

The argument to `ok_or` is now the cheap fieldless FeeError value. Conversion to the owned Anchor Error occurs only when `?` propagates Err. This corrects both eager successful-path allocation and the erroneous source origin while preserving account-check order, code, name and message. No manual Error representation, custom allocator, source coordinate or binary change is introduced.

`proposal.patch` is exactly three substitutions. `proposal.initial.patch` preserves the initial narrower idea (`ok_or_else(|| error!(...))`), rejected before build because it would keep the incorrect origin. No proposal has been compiled, run or integrated. Main files remain untouched.

## Inputs and attribution

Original SHA256 `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`; current accepted candidate `b2d02994dbc29680273f0a3589d8d9fd2763445505483c1acbd4c9f09e1502fb`. The current full inventory marks candidate withdrawal [614816,624072) unmatched. Its selected full row and original rows are preserved in `inputs/prior-selected-inventory.json`; no old classification is overwritten.

The existing instruction-dispatch record binds withdraw to wrapper657672. Its21-byte instruction log, checked from the original bytes, is `Instruction: Withdraw`. The wrapper calls parser520760 at657832, application249264 at658112, then accounts-exit528664 at658184 only after application success. This distinguishes the application from the later exit hook, which only handles account persistence/drop. All selected full windows are retained under `evidence/`.

## Original optional-account control

Original application [249264,257264) first selects native or token-quote behavior using the optional quote-mint representation. The token side checks its required companions in this order:

| Required field | Predicate | Present branch | Missing-error call |
|---|---:|---:|---:|
| vault_ata |250200, marker !=2|250352|250232 ->289880|
| user_ata |250360, marker !=2|250432|250392 ->289880|
| token_program |250440, pointer !=0|251928|250472 ->289880|

Each missing arm sets enum35 immediately before calling289880. A present field jumps over its constructor. Missing errors leave the handler through shared cleanup; no transfer or event has occurred. This is an ownership/effect distinction, not merely a shorter instruction shape.

Candidate614816 instead reads each presence marker and performs name, Display and owned-error construction before branching:

| Field | Owned box call | Presence branch |
|---|---:|---:|
| vault_ata |617016 ->682096|617048|
| user_ata |617568 ->682096|617600|
| token_program |618136 ->682096|618160|

Successful present-account paths therefore create unnecessary owned errors. Those errors may incur allocation/formatting failure before reaching otherwise valid transfers. No low-memory runtime case is invented or claimed here; the unconditional allocation itself is directly visible.

## Full constructor role and source origin

Full original enum converter [289880,290384) receives enum35 in r2, retains it, calls full name body280976 at289944 and Display290384 at290080, adds6000 at290272, sets origin tag2/None at290288, and passes the completed error to box conversion709232 at290336. No line/file origin is added in this converter.

The full original name body selects35 at282752 ->284992; its allocation-success stores288024/288048/288072 spell `IncompleteTokenAccounts`. Display selects35 at291016 ->291536 and loads805321/length72: `Token withdrawals need quote_mint, vault_ata, user_ata and token_program`. Current source enum35 has that exact name/message. This establishes the source error choice without inferring from an unrelated literal.

Full original box conversion [709232,709368) allocates160 bytes with alignment8 at709264, copies160 bytes at709336, then writes pointer/tag to its output. Current [682096,682232) likewise allocates160/alignment8 and copies160, but current callers first construct error6035 with origins carrying source lines10/11/12 at616960/617512/618032. The enclosing `error!` is the natural source of those metadata additions. The proposed enum conversion retains the observed origin-free form.

The successful/missing behavior of allocation, string formatting, deallocation and every runtime implementation remains a transitive dependency. This proposal does not claim original/current box ABI identity beyond the explicit selected bodies.

## Surrounding payment/effect contract and unchanged scope

On the native branch, original249584 reads vault lamports,249616 gets Rent,249768 derives minimum balance for data length0, and249784–249824 implements saturating subtraction. Nonpositive spendable amount reaches NothingToWithdraw6036 before signed payment. This agrees with the unchanged native source expression; it is not changed in this patch.

On the token branch, the optional companions above are admitted before checking the vault amount and issuing the token transfer. The original token zero-amount error6036 is at254336; current source retains that check and uses the vault amount plus mint decimals. Existing real CPI helpers, signer seeds, account flags, parser constraints, and target IDs remain untouched. After successful payment the original obtains Clock at254592 before constructing/emitting the withdrawal event; a Clock error follows the payment in source order and relies on runtime rollback. No event/funding reordering is proposed.

We retain the full application bodies, not just successful local snippets. All omitted details—CPI serialization, token extensions, parser error envelopes, refcount cleanup, allocator and event formatting—remain explicit unclosed equivalence obligations. This three-site source change does not assert complete withdrawal equivalence, new runtime coverage or closer whole-file identity. Previously reviewed key/admin/borrow and formatter-version choices are not reopened.

## Validation and next gate

`python3 -B verify.py` validates exact original/current hashes, wrapper role calls, all three missing-arm constructors, eager current box-before-presence ordering, enum/name/message/origin fields, allocator dimensions, and the exact three-site source patch. It runs no target program. Source before/after and full selected function bytes are sealed by `manifest.json`.

A subsequent build and unchanged permitted baseline replay require review/authorization. No compiler search, runtime probe, new fixture, main edit, or excluded Pump/initializer/token-extension work was performed.
