"""Source-only original/current control and owned-error check; no target execution."""
from pathlib import Path
import struct,json,hashlib,sys,difflib
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'method'));import disasm
O=disasm.a.Elf((P/'inputs/original.so').read_bytes());C=disasm.a.Elf((P/'inputs/current.so').read_bytes());H=lambda b:hashlib.sha256(b).hexdigest()
assert H(O.b)=='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
assert H(C.b)=='b2d02994dbc29680273f0a3589d8d9fd2763445505483c1acbd4c9f09e1502fb'
def ins(e,p):return struct.unpack('<BBhi',e.at(p,8))
def call(e,p,t):assert ins(e,p)[0]==0x85 and p+8+ins(e,p)[3]*8==t
for p in [250232,250392,250472]:call(O,p,289880);assert ins(O,p-8)[3]==35
for p,t in [(657832,520760),(658112,249264),(658184,528664),(289944,280976),(290080,290384),(290336,709232),(709264,661120),(709336,796360)]:call(O,p,t)
for p,t in [(250200,250352),(250360,250432),(250440,251928)]:assert p+8+ins(O,p)[2]*8==t
# Native enum converter sets origin None and invokes owned box conversion.
assert ins(O,290272)==(0x07,0x07,0,6000)
assert ins(O,290288)==(0x72,0x0a,-192,2)
assert ins(O,709248)[3]==160 and ins(O,709256)[3]==8
# Current error box is constructed before option checks on all three sites.
for p,check in [(617016,617048),(617568,617600),(618136,618160)]:call(C,p,682096);assert p<check
assert all(ins(C,p)[3]==6035 for p in [616944,617496,618016])
assert all(ins(C,p)[3]==line for p,line in [(616960,10),(617512,11),(618032,12)])
# Name's unaligned stores independently spell the enum name.
b=bytearray(23)
for p,offset in [(288024,15),(288048,8),(288072,0)]:
 raw=O.at(p,16);v=raw[4:8]+raw[12:16];b[offset:offset+8]=v
assert bytes(b)==b'IncompleteTokenAccounts'
assert O.at(805321,72)==b'Token withdrawals need quote_mint, vault_ata, user_ata and token_program'
before=(P/'before/withdrawal.rs').read_text();after=(P/'proposal/withdrawal.rs').read_text()
assert after==before.replace('.ok_or(error!(FeeError::IncompleteTokenAccounts))?', '.ok_or(FeeError::IncompleteTokenAccounts)?')
assert before.count('.ok_or(error!(FeeError::IncompleteTokenAccounts))?')==3
assert (P/'proposal.patch').read_text()==''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/programs/pump-fees/src/withdrawal.rs',tofile='b/programs/pump-fees/src/withdrawal.rs'))
result={'original_sha256':H(O.b),'current_sha256':H(C.b),'selected_role':'withdraw token optional-account owned error','original_missing_arm_calls':[250232,250392,250472],'current_unconditional_box_before_presence_checks':[[617016,617048],[617568,617600],[618136,618160]],'source_change_sites':3,'error_code':6035,'original_origin':'None','proposed_origin':'None via FeeError conversion','builds':0,'target_executions':0,'limits':['No post-proposal binary or runtime result','Allocator/formatter/CPI execution transitive equivalence unproved','Other parser/payment/effect branches unchanged by source diff']}
(P/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
