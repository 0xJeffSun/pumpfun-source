#!/usr/bin/env python3
"""Portable static/saved-data proposal verification; no VM or signing imports."""
import argparse
import ast
import difflib
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tarfile

HERE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((HERE/path).read_text())
def same_patch(before,after,old,new):
    return ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new))
def load_pure(name,path):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path);parser.add_argument('--current-main',action='store_true');a=parser.parse_args()
    manifest=read('manifest-sha256.json')
    files={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='manifest-sha256.json'}
    assert files==set(manifest), 'Package inventory changed'
    for rel,digest in manifest.items(): assert sha(HERE/rel)==digest,rel
    for p in HERE.rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
    assert sha(HERE/'inputs/source-proposal-manifest-sha256.json')=='69e1830d5d10b1153f801b3634104e406594904cdec51bb5777c9f866e48d0c1'
    assert sha(HERE/'inputs/accepted-manifest-sha256.json')=='a544615738c62279f1ebfd9dae4107b1db5640ac55f05d25f65e939933f91340'
    source=read('inputs/accepted-source-sha256.json'); proposed=read('corrected-source-sha256.json');assert len(source)==len(proposed)==26
    donation='programs/pump-fees/src/donation.rs'
    assert [p for p in source if source[p]!=proposed[p]]==[donation]
    old=(HERE/'inputs/original-hypothesis-donation.rs').read_text();new=(HERE/'inputs/corrected-donation.rs').read_text()
    needle='.map_err(|_| error!(FeeError::InvalidPool))?'
    assert old.count(needle)==1 and old.replace(needle,'.map_err(|_| FeeError::InvalidPool)?')==new
    assert sha(HERE/'inputs/original-hypothesis-donation.rs')=='3e5dc3b42930d3c69dc543b1de343961dc49e86db2000f1181cc2b38b4a8dc80'
    assert sha(HERE/'inputs/corrected-donation.rs')==proposed[donation]=='5e2af176c8c5f627602fb276d240aa48958d9dd45758fec553e9173e56df32c8'
    assert (HERE/'correction.patch').read_text()==same_patch(old,new,'a/programs/pump-fees/src/donation.rs','b/programs/pump-fees/src/donation.rs')
    with tarfile.open(HERE/'inputs/accepted-source-snapshot.tar.gz') as archive:
        members=[m for m in archive.getmembers() if m.isfile()]
        assert {m.name for m in members}==set(source)
        for m in members:assert hashlib.sha256(archive.extractfile(m).read()).hexdigest()==source[m.name],m.name
        accepted=archive.extractfile(donation).read().decode()
    start='pub fn create(ctx: Context<CreateDonationFeePda>) -> Result<()> {'
    end='\n#[derive(Accounts)]\npub struct CreateDonationFeePda'
    assert accepted.split(start)[0]==new.split(start)[0]
    assert accepted.split(end)[1]==new.split(end)[1]
    fixture=(HERE/'harness/fees_donation_create_differential.py').read_text()
    original_fixture=(HERE/'inputs/fees_donation_create_differential.py').read_text()
    assert (HERE/'fixture-extension.patch').read_text()==same_patch(original_fixture,fixture,'a/scripts/fees_donation_create_differential.py','b/proposed/fees_donation_create_differential.py')
    assert sha(HERE/'inputs/fees_donation_create_differential.py')=='610e3296d912dde1e4f7c071416b81a204095ff3aafe4a4e318ee48411a46b87'
    draft=(HERE/'harness/fees_donation_business_differential.py').read_text()
    assert 'with_sigverify(True).with_blockhash_check(True)' in draft
    assert 'with_transaction_history(' not in draft
    assert 'super().__init__' not in draft
    cases=read('cases.json');assert len(cases)==20 and len({c['id'] for c in cases})==20
    assert sum(c['category'] in ['success','no_op'] for c in cases)==11
    assert sum(c['existing_case_index'] is not None for c in cases)==8
    allowed=set(read('assertion-contract.json')['case_fields_allowed'])
    for case in cases:
        assert set(case['fixture'])<=allowed
        if 'curve_size' in case['fixture']:assert 82<=case['fixture']['curve_size']<=200
        if 'curve_reserves' in case['fixture']:assert len(case['fixture']['curve_reserves'])==4 and all(isinstance(x,int) and 0<=x<2**64 for x in case['fixture']['curve_reserves'])
    accepted_suite=json.loads(gzip.decompress((HERE/'inputs/accepted-donation-create.json.gz').read_bytes()))
    assert len(accepted_suite['cases'])==356
    roles={'OTHER':accepted_suite['cases'][307]['case']['sharing']['admin']}
    def resolve(value):
        if isinstance(value,str) and value.startswith('$'):return roles[value[1:]]
        if isinstance(value,dict):return {k:resolve(v) for k,v in value.items()}
        if isinstance(value,list):return [resolve(v) for v in value]
        return value
    for c in cases:
        if c['existing_case_index'] is not None:
            existing=dict(accepted_suite['cases'][c['existing_case_index']]['case']);existing.pop('name')
            assert resolve(c['fixture'])==existing,c['id']
    commands=read('baseline-command-inventory.json')
    assert len(commands)==10 and sum(x['comparison_count'] or 0 for x in commands)==17441
    assert commands[-1]['sequence_steps']==10
    assert [[x['name'],x['argv'][1],x['comparison_count']] for x in commands]==read('baseline-jobs.json')
    # Pure assertion helpers only: no fixture modules imported.
    sys.path.insert(0,str(HERE/'harness'))
    pure=load_pure('assertions',HERE/'harness/assertions.py');sys.modules['assertions']=pure
    checker=load_pure('diagnostics_only',HERE/'harness/check_retained_diagnostics.py')
    recomputed=checker.check(HERE/'inputs/accepted-donation-create.json.gz')
    assert recomputed==read('saved-diagnostic-check.json') and len(recomputed['mismatches'])==11
    first='Program log: AnchorError thrown in original/file.rs:213. Error Code: NotAuthorized. Error Number: 6016. Error Message: x.'
    second=first.replace('original/file.rs:213','candidate/file.rs:87')
    assert pure.semantic_logs([first])==pure.semantic_logs([second])
    assert pure.semantic_logs([first])!=pure.semantic_logs([first.replace('thrown in original/file.rs:213','occurred')])
    assert pure.semantic_logs([first])!=pure.semantic_logs([first,'Program log: Left:','Program log: A','Program log: Right:','Program log: B'])
    assert pure.semantic_logs(['Program log: Left:','Program log: A','Program log: Right:','Program log: B'])!=pure.semantic_logs(['Program log: Left:','Program log: B','Program log: Right:','Program log: A'])
    checked=0
    if a.repo:
        repo=a.repo.resolve();package=repo/'repro/pump_fees/donation-event-account-v144'
        accepted_manifest=read('inputs/accepted-manifest-sha256.json')
        for rel in ['source-sha256.json','published-harness-sha256.json','runtime-inputs.json','source-snapshot.tar.gz','differential.json.gz','pump_fees_candidate.so']:
            assert sha(package/rel)==accepted_manifest[rel],rel;checked+=1
        full=json.loads(gzip.decompress((package/'differential.json.gz').read_bytes()))
        assert full['suites']['donation_create']==accepted_suite
        for name in ['accepted-published-harness-sha256.json','accepted-runtime-inputs.json']:
            for rel,digest in read('inputs/'+name).items():assert sha(repo/rel)==digest,rel;checked+=1
        if a.current_main:
            for rel,digest in source.items():assert sha(repo/rel)==digest,rel;checked+=1
    else:assert not a.current_main,'--current-main requires --repo'
    assert 'solders' not in sys.modules and 'solders.litesvm' not in sys.modules
    print(json.dumps({'verified_payload_files':len(manifest),'source_inputs':26,'focused_proposed_cases':20,'focused_executed_cases':0,'retained_diagnostic_gaps_reproduced':11,'baseline_cases':17441,'baseline_sequence_steps':10,'repo_bindings_checked':checked,'no_vm_or_signer_imports':True},sort_keys=True))

if __name__=='__main__':main()
