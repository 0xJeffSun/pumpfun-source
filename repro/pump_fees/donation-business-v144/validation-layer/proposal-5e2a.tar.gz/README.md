# Donation business validation proposal

This is an unexecuted validation proposal for the natural `create_donation_fee_pda` source hypothesis. It adds **20 focused comparisons** (11 successful/no-op cases and nine rejection/order cases), with eight existing-input repeats and 12 new typed synthetic combinations. No source build, VM creation, signing, or transaction execution was performed for this proposal. No new handlers or receipts are claimed.

The accepted baseline is `repro/pump_fees/donation-event-account-v144`, seal `a544615738c62279f1ebfd9dae4107b1db5640ac55f05d25f65e939933f91340`, candidate `8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e`. `inputs/accepted-source-sha256.json` binds its 26 actual inputs, including the AccountInfo event-authority field. The earlier source proposal remains sealed at `69e1830d5d10b1153f801b3634104e406594904cdec51bb5777c9f866e48d0c1`. Its donation source `3e5dc3b…` is retained verbatim. `correction.patch` records only the independently identified Pool PDA direct-error conversion, producing reviewed hypothesis donation hash `5e2af176c8c5f627602fb276d240aa48958d9dd45758fec553e9173e56df32c8`. Neither hypothesis is accepted as equivalent, compiled, or tested by this package. Another agent owns build work separately.

## Concrete inventory

`cases.json` is the exact proposed inventory, with each fixture input, expected state/error, selected branch, and existing-row reference. `assertion-contract.json` specifies complete assertions and exclusions.

| Cases | Inputs and expected behavior |
| --- | --- |
| F01–F02 | Existing canonical Pool and active shared-creator successes. |
| F03–F05 | Nonzero-reserve Curve path at 82, 114 and 115 bytes; first, second and third reserve terms; complete legacy decoder data; exact extension threshold; non-native quote at 83:115. |
| F06–F08 | 200-byte Curve data with zero quote, explicit WSOL and fixed synthetic non-native quote. |
| F09–F10 | Curve selected SharingConfig with active admin; final virtual-token-only selector term. |
| F11 | Existing version7 state is an exact no-op, with its explicit log and no new creation event. |
| F12–F16 | Existing disabled, disabled-before-existing, revoked, wrong-admin and paused cases. |
| F17/F19 | Valid typed SharingConfig with wrong admin plus revocation; admin rejection must precede revocation, through Pool and Curve. |
| F18/F20 | Explicit program-owned unconfigured sharing account (empty data); proposed guard before decoder, through Pool and Curve. These are proposed normal configuration-error checks subject to parent review, not malformed fuzz campaigns. |

The reserve combinations are legal u64 typed simulator states that select individual branches. They are not claims about historical prestate or economic reachability. All base mints are initialized, correctly owned Tokenkeg accounts; all PDAs, ordinary signers, owners, discriminators and instruction metas remain the existing valid fixture values. A non-native quote is only copied metadata: no quote-mint account, token transfer or market is introduced. The matrix does not change authorization checks or substitute PDA signatures.

## Small fixture change and explicit recording

`fixture-extension.patch` contains the complete 12-line fixture extension: four reserve values, bounded Curve size from 82 through200, a 32-byte quote at83:115, and explicit unconfigured sharing state. No existing test cases or runtime behavior are changed by that patch. `harness/fees_donation_create_differential.py` is a draft copy; the canonical repository harness remains untouched.

`harness/fees_donation_business_differential.py` is the implementable **unexecuted** focused driver. It subclasses the fixture without calling the old constructor, creates a fresh VM for each original/candidate case, enables signature and blockhash verification, and retains default transaction history. The old suite's disabled-history setting is not used for these new cases. Each transaction requires exactly the two ordinary test-owned PAYER/AUTH signatures. The case inventory does not use the old fixture's unsigned, wrong-owner, truncated-invalid, or readonly mutation options.

The driver records all message and explicit role accounts before/after, raw transaction bytes, signature results, complete events/inner instructions/return data, raw logs and exact errors. Only the intentionally different Fees executable bytes/length and initial size-dependent rent are excluded from state parity; program lamport changes remain compared. Full DonationFeePda218-byte encoding and208-byte event payload are independently checked. The self-CPI216-byte payload, event-authority account and stack height are checked without claiming signer bits absent from compiled inner metadata. Failed cases require rollback except fee-payer transaction charges, whose exact deltas are compared. Existing-state no-op is checked independently.

`harness/assertions.py` separates diagnostic and exact-byte scopes. Semantic logs omit only metered compute lines and normalize source filename/line for errors that already carry a source origin. It retains direct-vs-origin distinction, all error names/numbers/messages, Left/Right values, explicit handler logs and ordering. All raw logs remain saved; source-coordinate differences are not full diagnostic identity.

## Known diagnostic failures retained

The existing356-row create suite has all four reserves zero; its Curve-size rows still take the Pool branch. Its comparator records logs but does not compare them. `existing-coverage.json` binds these observations to the accepted aggregate; `inputs/accepted-donation-create.json.gz` is the exact extracted suite, deterministically recompressed.

The read-only saved-log checker was run on that accepted suite, **without any transaction execution**, and exited1 as expected. `saved-diagnostic-check.json` retains eleven failures: disabled/log/no-origin, existing-state log, revoked direct conversion, shared wrong-admin compared-key output, direct Pool PDA6008 conversion, and direct-creator and Pool-address Left/Right order. Parent was notified. `harness/check_retained_diagnostics.py` can later strengthen these exact eleven rows from a freshly run unchanged baseline; it adds no inputs or transactions.

The5e2a hypothesis intentionally retains three separately reported diagnostic obligations: shared wrong-admin still uses `require_keys_eq!` although original case307 has no compared-key logs; direct-creator checks retain reversed compared-key order versus original cases319/320. Pool-address checks also reverse actual/derived key order in original cases312/313. A separate agent is preparing grounded source corrections. This package must not silently replace its5e2a source binding. Any newly approved source must get an explicit subsequent manifest/provenance layer before this draft driver is used. Known Left/Right differences must not be normalized away.

## Baseline and proposed execution order

`baseline-command-inventory.json` lists the unchanged nine comparison jobs totaling17,441 cases and the separate ten-step donation sequence. Their public source/harness/runtime maps are retained, including canonical aliases for historical harness locations. Genuine historical signed messages stay byte-identical; this proposal does not modify or newly exercise them.

After parent review: obtain one approved clean candidate build and its full source/tool-phase provenance; verify its exact26-input source manifest; run the focused20 first to expose branch/diagnostic errors; retain failures; only run the unchanged baseline when authorized. Run the saved-log checker on the newly produced baseline aggregate. Do not inherit the prior candidate's receipts. A future20-case run would contain40 transactions and80 signatures, but those counts are prospective and currently zero.

The driver deliberately pins5e2a and will reject a changed source root. Its `--build-record` retains an externally reviewed build record; the driver does not independently validate compiler invocation or symbol/source association. API behavior, VM execution, fixed-clock event assertions and rollback expectations have not been exercised by this package. Only AST syntax and pure saved-data assertion logic were checked.

## Verify this proposal only

`python -B work/fees-donation-business-validation-proposal/verify.py`

Optional public repository binding: append `--repo /absolute/path/to/pumpfun-source`. This checks accepted package/source/harness/runtime hashes without running a build or VM. The verifier works from a copied package outside the repository and does not import fixture modules, solders, or signing code. It reproduces the eleven retained diagnostic failures, validates the exact source/fixture patches, and tests that compared-key/origin differences remain observable.
