#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,tomllib,difflib,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
assert {str(p.relative_to(W)):H(p.read_bytes()) for p in W.rglob('*') if p.is_file() and p!=W/'manifest-sha256.json'}==J(W/'manifest-sha256.json')
for n,r in J(W/'inputs.json').items():assert H((W/n).read_bytes())==r['sha256'] and (W/n).stat().st_size==r['bytes'],n
def members(p):
 out={}
 with tarfile.open(p) as t:
  for m in t:
   n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts and m.name not in out;out[m.name]=t.extractfile(m).read()
 return out
base=members(W/'inputs/baseline-source-snapshot.tar.gz');mapping=J(W/'inputs/baseline-source-sha256.json');assert {n:H(b) for n,b in base.items()}==mapping and len(base)==26
assert base['programs/pump-fees/src/donation.rs']==(W/'inputs/baseline-donation.rs').read_bytes()
lock=tomllib.loads(base['Cargo.lock'].decode())
for crate in ['anchor-lang-0.31.1','anchor-attribute-error-0.31.2']:
 pkg,version=crate.rsplit('-',1);r=next(r for r in lock['package'] if r['name']==pkg and r['version']==version);assert H((W/'inputs'/(crate+'.crate')).read_bytes())==r['checksum']
for n,r in J(W/'inputs.json').items():
 if 'archive' in r:assert members(W/r['archive'])[r['member']]==(W/n).read_bytes()
b=members(W/'inputs/business-branches-publication.tar.gz');assert H(b['manifest-sha256.json'])=='39fd03b09e8f07d29ccd3fac6ebf59d609ccb87f5b52369fb6822abbb0e8dbe5';assert {n:H(v) for n,v in b.items() if n!='manifest-sha256.json'}==json.loads(b['manifest-sha256.json'])
original=(W/'inputs/original.so').read_bytes()
for r in json.loads(b['provenance.json'])['ranges']:assert original[r['start']:r['end_exclusive']]==b[r['file']]
before=(W/'inputs/baseline-donation.rs').read_text();after=(W/'donation.rs').read_text()
assert ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/programs/pump-fees/src/donation.rs',tofile='b/programs/pump-fees/src/donation.rs'))==(W/'source.patch').read_text()
mapping['programs/pump-fees/src/donation.rs']=H(after.encode());assert mapping==J(W/'proposed-source-sha256.json')
from analyze import run
assert run()==J(W/'proof.json')
print('PASS: all 8 create key checks, 7 original with_pubkeys sites, complete shared-admin return, 3 expression corrections, 26 inputs and saved case307; no build/runtime.')
