"""Read-only original create-handler error and compared-key witnesses."""
from pathlib import Path
import hashlib,json,struct,tarfile,gzip
from elf_reader import Elf
W=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
def run():
 O=Elf(W/'inputs/original.so');C=Elf(W/'inputs/8f-candidate.so');S=Elf(W/'inputs/8f-symbols.so')
 assert H(O.b)=='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
 assert H(C.b)=='8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e'
 assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]
 def ins(pc):
  b=O.b[pc:pc+8];op,regs,off,imm=struct.unpack('<BBhi',b);r={'pc':pc,'raw_hex':b.hex(),'opcode':op,'dst':regs&15,'src':regs>>4,'offset':off,'immediate':imm}
  if pc in O.calls:r['direct_target']=pc+8+imm*8
  elif op&7==5 and op not in (0x85,0x95):r['branch_target']=pc+8+off*8
  return r
 callsites=[pc for pc,t in O.calls.items() if 163920<=pc<177720 and t==709768]
 assert callsites==[166664,168336,169864,173808,174816,175440,176936]
 named=[f for f in S.funcs if '12with_pubkeys' in f['name']]
 # Rust symbol spelling is current candidate evidence; the original helper body is independently compared.
 exact=[f for f in named if f['size']==520 and C.normalized[f['start']:f['start']+520]==O.normalized[709768:710288] and C.pattern(f['start'],520)==O.pattern(709768,520)]
 assert len(exact)==1
 rows=[
  dict(id='direct_creator',left='payer.key()',right='selected creator',from_pc=166480,keys_pc=166664,line_pc=166424,line=221,compare_pc=166056,ranges=[[165936,166088],[166384,166696]],change='swap key arguments'),
  dict(id='sharing_owner',left='sharing AccountInfo.owner',right='Fees ID',from_pc=168120,keys_pc=168336,line_pc=168064,line=192,compare_pc=166736,ranges=[[166696,166768],[168048,168368]],change='none'),
  dict(id='pool_owner',left='pool AccountInfo.owner',right='AMM ID',from_pc=169648,keys_pc=169864,line_pc=169592,line=148,compare_pc=164384,ranges=[[164336,164416],[169576,169896]],change='none'),
  dict(id='pool_base_mint',left='pool.base_mint',right='base_mint.key()',from_pc=173624,keys_pc=173808,line_pc=173568,line=152,compare_pc=168936,ranges=[[168808,168968],[173528,173840]],change='none'),
  dict(id='pool_creator',left='pool.creator',right='derived pool authority',from_pc=174632,keys_pc=174816,line_pc=174568,line=156,compare_pc=174416,ranges=[[174120,174456],[174520,174848]],change='none'),
  dict(id='sharing_mint',left='config.mint',right='base_mint.key()',from_pc=175256,keys_pc=175440,line_pc=175192,line=204,compare_pc=175048,ranges=[[174848,175080],[175144,175480]],change='none'),
  dict(id='pool_address',left='pool AccountInfo.key',right='derived expected pool PDA',from_pc=176752,keys_pc=176936,line_pc=176688,line=174,compare_pc=176544,ranges=[[176280,176576],[176656,176968]],change='swap key arguments'),
  dict(id='sharing_admin',left=None,right=None,from_pc=176192,keys_pc=None,line_pc=176128,line=213,compare_pc=175984,ranges=[[175856,176280],[164104,164128]],change='plain require! retains source origin, omits compared keys')]
 for r in rows:
  assert O.calls[r['from_pc']]==709232 and O.calls[r['compare_pc']]==796464
  assert ins(r['line_pc'])['immediate']==r['line'] and ins(r['line_pc'])['offset']==-488
  if r['keys_pc']:assert O.calls[r['keys_pc']]==709768
  r['raw_witnesses']=[ins(pc) for a,b in r['ranges'] for pc in range(a,b,8)]
  r['identity_basis']='manual tracked-value/stack dataflow, backed by raw original instructions and preserved typed-decoder evidence; not automated semantic proof'
 # Shared-admin failure preserves the From<AnchorError> result through cleanup, then exits.
 adminpath=list(range(176200,176280,8))+list(range(164104,164128,8))
 assert not any(pc in O.calls for pc in adminpath)
 assert ins(176200)['opcode']==0xb7 and ins(176200)['dst']==1 and ins(176200)['immediate']==0
 assert ins(176272)['branch_target']==164104
 assert ins(176264)['opcode']==0x55 and ins(176264)['dst']==1 and ins(176264)['immediate']==0
 source_path=O.b[803599:803599+74].decode();assert source_path=='programs/pump-fees/src/instructions/fee_sharing/create_donation_fee_pda.rs'
 original=(W/'inputs/baseline-donation.rs').read_text();proposed=(W/'donation.rs').read_text();expected=original
 for before,after in J(W/'replacements.json'):assert expected.count(before)==1;expected=expected.replace(before,after)
 assert proposed==expected
 cut=lambda s:s[s.index('pub fn create(ctx:'):s.index('#[derive(Accounts)]',s.index('pub fn create(ctx:'))]
 assert cut(original).count('require_keys_eq!(')==8 and cut(proposed).count('require_keys_eq!(')==7
 start=original.index('pub fn create(ctx:');end=original.index('#[derive(Accounts)]',start)
 prefix=original[:start];suffix=original[end:]
 assert proposed.startswith(prefix) and proposed.endswith(suffix)
 receipt=json.loads(gzip.decompress((W/'inputs/8f-differential.json.gz').read_bytes()))['suites']['donation_create']['cases'][307]
 assert receipt==J(W/'saved-sharing-wrong-admin.json') and receipt['case']['name']=='sharing-wrong_admin'
 assert not any('Program log: Left:'==s or 'Program log: Right:'==s for s in receipt['original']['logs'])
 assert 'Program log: Left:' in receipt['candidate']['logs'] and 'Program log: Right:' in receipt['candidate']['logs']
 assert any(':213.' in s and 'NotAuthorized' in s for s in receipt['original']['logs'])
 return dict(original_sha256=H(O.b),baseline_8f_sha256=H(C.b),build01_sha256='9e946d228c8c12f2978a38b69117e967a5590a38d108004b36c99676332ae494',
  baseline_source_sha256=H(original.encode()),proposed_source_sha256=H(proposed.encode()),all_create_keys_macro_sites_reviewed=8,
  original_with_pubkeys_calls=callsites,with_pubkeys_helper={'original':[709768,710288],'candidate':exact[0],'normalized_equal':True,'relocation_pattern_equal':True},
  source_origin={'filename_pointer':803599,'filename_bytes':74,'filename':source_path,'shared_admin_line':213,'direct_creator_line':221,'pool_address_line':174},
  checks=rows,shared_admin_return_path=[ins(pc) for pc in adminpath],
  saved_case={'suite':'donation_create','index':307,'name':'sharing-wrong_admin','receipt_sha256':H((W/'inputs/8f-differential.json.gz').read_bytes()),'replayed':False},
  limits=['Source lines/paths remain truthful current coordinates; no coordinate spoofing.','Raw/helper/field dataflow is evidence for natural macro forms, not full transitive or historical-source proof.','Build01 remains frozen and has not run runtime checks.','No new fixtures or transactions; saved case is read-only corroboration.'],
  builds=0,runtime_cases=0,main_edits=0)
if __name__=='__main__':(W/'proof.json').write_text(json.dumps(run(),indent=2)+'\n')
