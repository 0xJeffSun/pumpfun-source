# CreateDonationFeePda diagnostic source correction

This separately reviewable proposal fixes **three expressions** atop the successfully built `5e2af176` source. Build01 (`9e946d228c8c12f2978a38b69117e967a5590a38d108004b36c99676332ae494`, 770,944 bytes) remains unchanged and has not run the runtime corpus. The proposal has not been built or executed. All 26 input bindings remain explicit; only donation.rs changes, and no context or crank bytes change.

| Check | Original diagnostic behavior | Proposed correction |
|---|---|---|
| Shared admin | Source-origin NotAuthorized, **no compared keys** | `require!(config.admin == ctx.accounts.payer.key(), FeeError::NotAuthorized)` |
| Direct creator | Source-origin NotAuthorized; Left payer, Right selected creator | `require_keys_eq!(ctx.accounts.payer.key(),creator,FeeError::NotAuthorized)` |
| Pool address | Source-origin InvalidPool; Left actual pool key, Right derived PDA | `require_keys_eq!(info.key(),expected,FeeError::InvalidPool)` |

The exact patch is `source.patch`; the complete revised source is `donation.rs`, SHA-256 **`a99db3b6156a3009e805ea24ca087d1bea1eb28b90be076dda024f30ac0a14b9`**. It preserves the already reviewed direct InvalidPool conversion on PDA derivation failure, both early logs, reserve branch, quote behavior, shared authorization order and account types.

## Complete original diagnostic witnesses

The original helper at [709768,710288) fully matches the current `Error::with_pubkeys` symbol window [602232,602752) after established normalization with identical relocation pattern. The locked Anchor implementation preserves tuple order and logs Left then Right. `require_keys_eq!` calls `error!(...).with_pubkeys((value1,value2))`; plain `require!` calls `error!` without that augmentation. Both record truthful source origins through the locked error macro.

Shared-admin mismatch constructs source-origin error 6016 at original line **213**, calls From<AnchorError> at **176192→709232**, then only loads its returned words, decrements the sharing data-borrow count and returns through 164104. No with_pubkeys call occurs. The existing public donation_create row **307**, `sharing-wrong_admin`, independently corroborates the absence of original Left/Right lines and their presence in candidate8f. The whole saved receipt and exact row are retained; no transaction is replayed.

Direct-creator mismatch constructs source-origin error 6016 at line **221**, calls From<AnchorError> at **166480→709232**, fills the first tuple element from payer at 166504–166560 and the second from selected creator at 166568–166624, then calls with_pubkeys at **166664→709768**. The two error words are subsequently returned unchanged. The equality predicate is symmetric; the diagnostic ordering is not.

Pool-address mismatch constructs source-origin error 6008 at line **174**, calls From<AnchorError> at **176752→709232**, copies the actual pool key into the first tuple element at 176776–176832 and the derived address into the second at 176840–176896, then calls with_pubkeys at **176936→709768**. The saved pool AccountInfo is loaded at 176424, its key at 176432; the derived PDA bytes are assembled at 176280–176416. The proposed argument swap follows these tracked values.

All **eight** current create() key-macro sites were reviewed. The complete original handler contains exactly **seven** with_pubkeys calls. The other five existing argument orders already agree and remain unchanged:

| Check | Original Left | Original Right | with_pubkeys call |
|---|---|---|---:|
| Sharing owner | sharing owner | Fees ID | 168336 |
| Pool owner | pool owner | AMM ID | 169864 |
| Pool base mint | pool.base_mint | base_mint.key() | 173808 |
| Pool creator | pool.creator | derived authority | 174816 |
| Sharing mint | config.mint | base_mint.key() | 175440 |

`proof.json` records the complete enumeration, raw instruction witnesses, comparison and error-conversion calls, original source-line stores, shared-admin return path, the helper match and source-delta boundaries. Value-role labels are manual dataflow conclusions backed by the preserved typed-decoder evidence and raw bytes, not an automated proof or historical function-name recovery.

This corrects concrete local diagnostic behavior. It does not claim exact historical lines, a unique original Rust expression, full allocation/data/cleanup closure or runtime equivalence. No line padding or remapping is proposed. Parent review is required before a single corrected build. Do not run the old build's runtime corpus as if these known diagnostic differences were resolved.

Run `python3 -B verify.py` from any directory. Verification checks the exact file seal, original bytes, all seven compared-key sites, source macro/API members against locked crate checksums, all 26 source inputs, the exact three-expression diff and the unchanged saved case. It performs no compiler or runtime operation.
