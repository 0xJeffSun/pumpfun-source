from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
W=Path(__file__).resolve().parent;P=W/'handoff';PY=W.parents[2]/'work/test-env/bin/python'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def seal(p):
 m={f.relative_to(p).as_posix():H(f) for f in sorted(p.rglob('*')) if f.is_file() and f!=p/'manifest-sha256.json'};(p/'manifest-sha256.json').write_text(json.dumps(m,indent=2)+'\n')
results=[]
with tempfile.TemporaryDirectory(prefix='fees-donation-portable-') as temp:
 T=Path(temp);copy=T/'package';shutil.copytree(P,copy)
 def run(name,success):
  p=subprocess.run([str(PY),'-B',str(copy/'verify.py'),'--runtime'],cwd=T,text=True,capture_output=True)
  assert (p.returncode==0)==success,(name,p.stdout,p.stderr)
  results.append({'name':name,'expected_success':success,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'no_repo_argument':True})
 run('standalone copy, saved signature/static assertions',True)
 f=copy/'pump_fees_candidate.so';data=f.read_bytes();f.unlink();run('missing candidate fails complete file inventory',False);f.write_bytes(data)
 f=copy/'differential.json.gz';data=f.read_bytes();f.write_bytes(data[:-1]+bytes([data[-1]^1]));run('corrupt receipt fails recorded hash',False);f.write_bytes(data)
 f=copy/'source.patch';data=f.read_bytes();f.write_bytes(data+b'\n');seal(copy);run('resealed incorrect source patch fails source reconstruction',False);f.write_bytes(data);seal(copy)
 f=copy/'runtime-focused/focused20.json';data=f.read_bytes();d=json.loads(data);d['cases'][0]['candidate']['events']=[];f.write_text(json.dumps(d,indent=2)+'\n');seal(copy);run('resealed altered focused events fails unchanged saved assertions',False);f.write_bytes(data);seal(copy)
 assert H(copy/'manifest-sha256.json')==H(P/'manifest-sha256.json')
(W/'portable-checks.json').write_text(json.dumps({'tested_pre_final_manifest_sha256':H(P/'manifest-sha256.json'),'tests':results,'scope':'Saved evidence only; no compiler, VM, signing or replay. Negative copies were discarded; original evidence remained unchanged.'},indent=2)+'\n')
print(json.dumps({'tests':len(results),'all_expected_results_observed':True}))
