#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile
W=Path(__file__).resolve().parent;R=W.parents[2];P=R/'repro/pump_fees/donation-event-account-v144';S=W/'source';B=W/'build-02'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):(W/name).write_text(json.dumps(v,indent=2)+'\n')
assert not B.exists()
expected=json.loads((W/'baseline-source-sha256.json').read_text());changed=json.loads((W/'source-sha256.json').read_text())
assert len(expected)==26 and len(changed)==26
assert {p:H(R/p)for p in expected}==expected
assert {p:H(S/p)for p in changed}==changed
helpers=json.loads((P/'build-helper-sha256.json').read_text());assert all(H(R/p)==v for p,v in helpers.items());save('build-helper-sha256.json',helpers)
phase=json.loads((P/'tool-phase-provenance.json').read_text());tools=phase['compile']['tool_files'];tool_before={p:H(Path(v['resolved_path']))for p,v in tools.items()};assert tool_before==phase['compile']['tool_hashes_before']
stripper=Path.home()/'.cache/solana/v1.52/platform-tools/llvm/bin/llvm-objcopy';strip_before=H(stripper);assert strip_before==phase['strip']['file_sha256_before']
sdk_source=Path(shutil.which('cargo-build-sbf')).resolve().parent/'sdk/sbf';sdk={str(p.relative_to(sdk_source)):H(p)for p in sdk_source.rglob('*')if p.is_file()and'dependencies'not in p.relative_to(sdk_source).parts};assert sdk==json.loads((P/'build-comparison.json').read_text())['sdk_source_sha256'];assert len(sdk)==53
command=[sys.executable,str(R/'scripts/build_partial_candidate.py'),'--manifest',str(S/'programs/pump-fees/Cargo.toml'),'--program','pump_fees','--artifact-name','pump_fees_candidate.so','--tools-version','v1.44','--output',str(B),'--extra-input',str(S/'programs/pump-fees/README.md')]
cache=R/'work/fees-family-221-trial/cargo-home'
save('build-launch.json',{'command':command,'CARGO_HOME':str(cache),'network_offline':True,'source_before':changed,'helper_hashes':helpers,'compile_tool_file_hashes_before':tool_before,'stripper_v152_file_hash_before':strip_before,'sdk_source_sha256':sdk,'scope':'One fixed approved natural donation creation handler proposal plus directly evidenced InvalidPool conversion correction. Exact donation SHA a99db3b6156a3009e805ea24ca087d1bea1eb28b90be076dda024f30ac0a14b9. Parent-approved three-expression diagnostic correction preserves origins, removes shared-admin compared keys, orders direct-creator and pool-address compared keys as original. Build01/source5e2a retained separately without runtime. Context, crank, all other inputs, dependency lock, profile, flags and compiler144/strip152 unchanged. No padding or variants.'})
for label,root,files in [('build-helper-snapshot.tar.gz',R,helpers)]:
 with tarfile.open(W/label,'w:gz')as t:
  for n in files:t.add(root/n,arcname=n,recursive=False)
prebuild={str(p.relative_to(W)):H(p)for p in sorted(W.rglob('*'))if p.is_file()}
save('prebuild-manifest-sha256.json',prebuild)
print('Frozen prebuild seal',H(W/'prebuild-manifest-sha256.json'),flush=True)
env={**os.environ,'CARGO_HOME':str(cache),'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True);(W/'build-launch.stdout').write_text(result.stdout);(W/'build-launch.stderr').write_text(result.stderr)
assert all(H(W/p)==v for p,v in prebuild.items())
actual={p:H(S/p)for p in changed};save('build-result.json',{'returncode':result.returncode,'source_after':actual,'source_unchanged':actual==changed,'main_source_unchanged':{p:H(R/p)for p in expected}==expected});assert result.returncode==0 and actual==changed
report=json.loads((B/'build-comparison.json').read_text());prefix=str(S.relative_to(R))+'/'
assert {n[len(prefix):]:h for n,h in report['source_sha256'].items()if n.startswith(prefix)}==changed and len(report['source_sha256'])==26
shutil.copyfile(B/'target/sbf-solana-solana/release/pump_fees_candidate.so',W/'unstripped.so')
actual_stripper=B/'sdk/dependencies/platform-tools/llvm/bin/llvm-objcopy'
assert (B/'sdk/dependencies/platform-tools-v1.52.md').is_file()
tool_after={p:H(Path(v['resolved_path']))for p,v in tools.items()};assert tool_after==tool_before and H(actual_stripper)==strip_before
save('tool-phase-provenance.json',{'scope':phase['scope'],'compile':{'requested_tools_version':'v1.44','tool_files':tools,'tool_hashes_before':tool_before,'tool_hashes_after':tool_after,'unstripped_sha256':H(W/'unstripped.so')},'strip':{'sdk_platform_tools_symlink':str((B/'sdk/dependencies/platform-tools').readlink()),'sdk_platform_tools_realpath':str((B/'sdk/dependencies/platform-tools').resolve()),'sdk_marker':'platform-tools-v1.52.md','llvm_objcopy_resolved_path':str(actual_stripper.resolve()),'file_sha256_before':strip_before,'file_sha256_after':H(actual_stripper),'candidate_sha256':H(B/'artifacts/pump_fees_candidate.so')},'phase_source_sha256':{p:H(B/'sdk'/p)for p in phase['phase_source_sha256']}})
print(json.dumps({'built':True,'candidate_sha256':H(B/'artifacts/pump_fees_candidate.so'),'candidate_bytes':(B/'artifacts/pump_fees_candidate.so').stat().st_size,'source_inputs':len(changed),'changed_source':[p for p in changed if changed[p]!=expected.get(p)]},indent=2))
