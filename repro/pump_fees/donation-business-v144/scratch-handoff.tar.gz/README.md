# Fees donation business source — tested scratch build02

The reviewed natural `create_donation_fee_pda` reconstruction and three separately proved diagnostic corrections build successfully with the fixed recorded recipe. **20 focused comparisons, the unchanged 17,441-comparison corpus, ten donation sequence steps, and eleven saved-row diagnostic checks pass.** Main source is unchanged. No whole-program or complete-handler byte identity is claimed.

Candidate `fc1088f3e25738267a49aaa2b5189f1ab77c487f1023d45fede11e14e5a086b2` is **770,744 bytes**. Original SHA is `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`. The accepted baseline remains `8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e`. Exact final `donation.rs` SHA is `a99db3b6156a3009e805ea24ca087d1bea1eb28b90be076dda024f30ac0a14b9`.

## Source and build provenance

All 26 actual source inputs are preserved in maps and archives. Only `programs/pump-fees/src/donation.rs` changes relative to baseline. The patch restores the two early logs, the reserve-dependent typed BondingCurve path and raw quote threshold/range, preserves the typed Pool/sharing paths and borrow boundaries, and corrects directly evidenced error metadata and compared-key ordering. It preserves the accepted event-authority AccountInfo, inline initializer context, moved account declarations, dependencies, IDLs, lock, profile, compiler flags and existing crank.

The original natural proposal, independent review, diagnostic correction and validation proposals remain immutable, with their original seals. Build01 (`9e946d…`, 770,944 bytes) used the first reviewed source; it is explicitly superseded after three exact diagnostic discrepancies were established. **No runtime corpus ran on build01.** Its source/build/tool/log provenance is retained under `superseded-build01/`. Build02 was one fresh clean-target build with the corrected source, not a toolchain/layout search. Both attempts compiled successfully. No byte patch, padding, line spoofing, source path transformation or compiler variant was used.

The measured pipeline is v1.44 compilation with the recorded 53-file SDK and its actual v1.52 objcopy stripping. Compiler and stripper file hashes are bound before/after; source and tools remained unchanged. All shared allocated section payloads are identical before/after stripping. The scope of the tool evidence remains exact: selected compiler, measured files, build logs and observed SDK strip linkage, not a complete process invocation trace or a unique historical build recipe. Absolute work/cache paths inside historical records identify provenance only. The verifier never uses them.

## Saved execution evidence

| Evidence | Comparisons or steps | Scope |
| --- | ---: | --- |
| Existing aggregate | 17,331 | 18 unchanged suites; historical comparator scope preserved |
| Existing supplemental receipts | 110 | Nine comparison reports total with aggregate; includes 69 repeated-input comparisons across the existing corpus |
| Donation sequence | 10 steps | Existing signed sequence; separate from comparison count |
| Focused donation matrix | 20 | Eight existing inputs and twelve new typed synthetic combinations |
| Saved diagnostic strengthening | 11 rows | Reads the fresh aggregate; no additional transactions |

The focused20 produced **40 executions and 80 ordinary test-owned signatures**, with fresh LiteSVM instances, signature verification, blockhash checking and default transaction history enabled. Its unchanged assertions compare all watched account state, complete events, inner instructions, return data, errors and semantic logs, with explicit success/rejection expectations. Original and candidate raw logs are retained and are unequal in all twenty cases: the comparator excludes compute-unit lines and normalizes only source-coordinate spans; it preserves direct-versus-origin errors and all Left/Right values. This is not a raw-log equality claim. The loaded program account’s binary data fields and its initial rent balance are normalized because the two ELF files differ; all other watched account metadata/state remains compared by the frozen assertion contract.

The eleven postprocessed rows include the shared-admin error, both Pool compared-key order cases, early logs, feature/version ordering and existing quote/creator cases. The exact unchanged postprocessor now passes on the fresh baseline. No driver or expectation was changed after execution. The genuine historical initializer captures retain their original signed messages/signatures, with the existing blockhash freshness negative control. The baseline harnesses retain their original limitations; the stronger focused assertions are not retroactively attributed to every old case.

`runtime-verification-result.json` records independently rechecked saved transaction/signature counts for the existing corpus. These counts describe retained encoded fields, not all comparison executions. Focused40/80 remains separate. Python and the actual solders 0.27.1 native-extension hash are recorded in `runtime-engine.json`. A saved-only verifier invocation initially resolved the venv symlink and failed to import solders; that failed attempt is preserved. The correctly addressed venv verifier then passed without changing receipts or rerunning transactions.

## Static results and remaining limits

Original instruction identity is retained through discriminator/dispatch/wrapper/parser evidence. Complete wrapper (928 bytes) and parser (8,984 bytes) normalized bodies and relocation patterns match. The fresh handler is 13,592 bytes versus original inferred 13,800 bytes; **complete normalized and raw identity remain false**. A smaller size is not acceptance evidence.

The report retains every instruction, immediate call and referenced data preview for the relevant windows. There are 84 direct-target windows, including 42 original targets, with all matching fresh symbols, ambiguity and reachability from relevant roots recorded. Matching root call comparisons support four of five wrapper targets and seventy of seventy-one parser targets. The changed handler and the known source-coordinate-bearing init-if-needed closure remain explicit residuals. Both early log pointers, lengths and `sol_log_` calls are bound to exact consumed bytes. General 128-byte data previews are not complete object-extent proof.

The retained initializer/social/Pubkey checks cover ten complete normalized bodies, 26 immediate callees and five consumed literals. Five moved account codecs retain only the known normalized line-coordinate slot at +528, while their 35 immediate callees and consumed filename extents match. No artificial coordinate alignment is proposed.

The complete fresh inventory preserves **all 585 original inferred windows and 546 candidate symbol windows**. Original classification is unchanged from the 8f baseline: 437 mapped patterns, 145 unattributed and three call conflicts. Candidate classification is 438 normalized-call-consistent, 105 unmatched and three call conflicts. It retains raw/normalized/size alternatives, ambiguities, 272 immediate-call residuals and indirect/data references. Inferred windows are not a proven historical function denominator or semantic completion percentage; neither a mapped body nor handler counts establish transitive closure. Full original equality remains false; Fees stays **31 bounded handlers**, and whole-contract exactness remains **0/4**.

## Portable verification and promotion proposal

```
python -B /path/to/handoff/verify.py
/path/to/solders-python -B /path/to/handoff/verify.py --runtime
```

The verifier checks the complete inventory, source/build/tool archives, unchanged validation seals, all fresh static analyses, every receipt/build/source binding, focused saved assertions and eleven diagnostic rows. `--runtime` adds saved cryptographic signature verification; it does not execute SBF or instantiate a VM. Optional `--repo /path/to/repo` verifies current baseline source and published byte-identical harness/runtime files; it intentionally expects the still-unmodified 8f source. Copied-package and missing/tamper checks are recorded separately.

`main-source-proposal.json` proposes only the reviewed donation source change and an accurate program README, followed by one isolated clean main build requiring complete ELF identity with this candidate before carrying these receipts forward. It does not authorize or perform promotion. No central files, main source, git staging, commit or remote were changed by this task.
