#!/usr/bin/env python3
"""Portable static/receipt verifier. No compilation, SBF replay, VM or signer creation."""
from pathlib import Path
import argparse,collections,difflib,gzip,hashlib,json,runpy,subprocess,sys,tarfile,tempfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
read=lambda n:J(P/n)
C_SHA='fc1088f3e25738267a49aaa2b5189f1ab77c487f1023d45fede11e14e5a086b2'
O_SHA='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime',action='store_true');p.add_argument('--repo',type=Path);a=p.parse_args()
assert not any(f.is_symlink() for f in P.rglob('*'))
manifest=read('manifest-sha256.json')
assert {f.relative_to(P).as_posix():H(f.read_bytes()) for f in P.rglob('*') if f.is_file() and f!=P/'manifest-sha256.json'}==manifest,'Package inventory/hash mismatch'
def archive(name,expected=None):
 with tarfile.open(P/name) as t:
  ms=t.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in ms)
  data={m.name:t.extractfile(m).read() for m in ms};assert len(data)==len(ms)
 if expected is not None:assert {n:H(b) for n,b in data.items()}==expected,name
 return data
def sealed(name,seal):
 d=archive(name);assert H(d['manifest-sha256.json'])==seal
 assert {n:H(b) for n,b in d.items() if n!='manifest-sha256.json'}==json.loads(d['manifest-sha256.json'])
 return d
def subprocess_check(script,args=(),cwd=None):
 q=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],cwd=cwd,text=True,capture_output=True)
 assert q.returncode==0,(str(script),q.stdout,q.stderr)
 return q.stdout
source=read('source-sha256.json');base=read('baseline-source-sha256.json');assert len(source)==len(base)==26
before=archive('baseline-source-snapshot.tar.gz',base);after=archive('source-snapshot.tar.gz',source)
target='programs/pump-fees/src/donation.rs';assert [n for n in base if source[n]!=base[n]]==[target]
assert source[target]=='a99db3b6156a3009e805ea24ca087d1bea1eb28b90be076dda024f30ac0a14b9'
assert after[target]==(P/'validation-layer/inputs/corrected-donation.rs').read_bytes()
assert ''.join(difflib.unified_diff(before[target].decode().splitlines(True),after[target].decode().splitlines(True),fromfile='a/'+target,tofile='b/'+target)).encode()==(P/'source.patch').read_bytes()
pre=archive('prebuild-snapshot.tar.gz',read('prebuild-manifest-sha256.json'));assert all(pre['source/'+n]==b for n,b in after.items())
for n in ['source.patch','source-sha256.json','source-snapshot.tar.gz','build-launch.json','build_once.py']:assert pre[n]==(P/n).read_bytes()
archive('build-helper-snapshot.tar.gz',read('build-helper-sha256.json'));assert len(read('build-helper-sha256.json'))==4
build=read('build-02/build-comparison.json');attempt=read('build-02/build-attempt.json');prefix='work/fees-donation-business-build/run-02/source/'
assert all(n.startswith(prefix) for n in build['source_sha256'])
assert {n[len(prefix):]:h for n,h in build['source_sha256'].items()}==source
assert attempt['returncode']==0 and attempt['source_unchanged'] and attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256']
assert H(gzip.decompress((P/'build-02/build.log.gz').read_bytes()))==build['build_log_sha256']==attempt['build_log_sha256']
assert read('build-result.json')['source_after']==source and read('build-result.json')['source_unchanged'] and read('build-result.json')['main_source_unchanged']
C=(P/'pump_fees_candidate.so').read_bytes();O=(P/'analysis-method/inputs/original.so').read_bytes()
assert C==(P/'build-02/artifacts/pump_fees_candidate.so').read_bytes() and H(C)==C_SHA and len(C)==770744 and H(O)==O_SHA
compare={'original_bytes':len(O),'candidate_bytes':len(C),'original_sha256':H(O),'candidate_sha256':H(C),'full_byte_equality':O==C,'first_difference':next((i for i,(x,y) in enumerate(zip(O,C)) if x!=y),None),'different_positions_in_shared_length':sum(x!=y for x,y in zip(O,C)),'length_difference':len(C)-len(O)}
assert compare==build['comparison'] and compare['full_byte_equality'] is False
sdk=archive('sbf-sdk-snapshot.tar.gz',build['sdk_source_sha256']);assert len(sdk)==53
phase=read('tool-phase-provenance.json');assert phase['compile']['requested_tools_version']=='v1.44'
assert phase['compile']['tool_hashes_before']==phase['compile']['tool_hashes_after']=={n:r['sha256'] for n,r in phase['compile']['tool_files'].items()}
assert phase['compile']['unstripped_sha256']==H((P/'unstripped.so').read_bytes())
assert phase['strip']['candidate_sha256']==C_SHA and phase['strip']['sdk_marker']=='platform-tools-v1.52.md'
assert phase['strip']['file_sha256_before']==phase['strip']['file_sha256_after']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
for n,h in phase['phase_source_sha256'].items():assert H(sdk[n])==h
for n,r in read('analysis-method/inputs.json').items():assert H((P/'analysis-method'/n).read_bytes())==r['sha256']
for name,data in runpy.run_path(str(P/'inspect_candidate.py'))['run']().items():assert data==read(name),name
assert runpy.run_path(str(P/'verify_retained.py'))['run']()==read('retained-static-gate.json')
inventory=read('full-function-inventory.json');assert len(inventory['original_rows'])==585 and len(inventory['candidate_rows'])==546
assert all(r['baseline_status']==r['candidate_status'] for r in read('inventory-vs-8f.json')['original_rows'])
proof=read('caller-static-proof.json');assert not proof['whole_original_equal'] and not proof['windows']['handler']['comparison']['normalized_equal']
assert proof['windows']['handler']['original']['size']==13800 and proof['windows']['handler']['candidate']['size']==13592
for n in ['wrapper','parser']:assert proof['windows'][n]['comparison']['normalized_equal'] and proof['windows'][n]['comparison']['relocation_pattern_equal']
assert len(proof['exact_handler_logs'])==4 and len(proof['direct_target_inventory'])==84
for r in proof['strip_sections']:
 if r['allocated']:assert r['equal']
# Superseded first build is retained explicitly without runtime evidence.
old=read('superseded-build01/source-sha256.json');old_src=archive('superseded-build01/source-snapshot.tar.gz',old)
assert len(old)==26 and [n for n in old if old[n]!=source[n]]==[target]
assert old[target]=='5e2af176c8c5f627602fb276d240aa48958d9dd45758fec553e9173e56df32c8'
archive('superseded-build01/prebuild-snapshot.tar.gz',read('superseded-build01/prebuild-manifest-sha256.json'))
oldbuild=read('superseded-build01/build-01/build-comparison.json');oldcandidate=(P/'superseded-build01/build-01/artifacts/pump_fees_candidate.so').read_bytes()
assert H(oldcandidate)==oldbuild['comparison']['candidate_sha256']=='9e946d228c8c12f2978a38b69117e967a5590a38d108004b36c99676332ae494'
assert H(gzip.decompress((P/'superseded-build01/build-01/build.log.gz').read_bytes()))==oldbuild['build_log_sha256']
sealed('natural-source-proposal.tar.gz','69e1830d5d10b1153f801b3634104e406594904cdec51bb5777c9f866e48d0c1')
sealed('independent-source-review.tar.gz','2a96b9229ee8bbf62b4f7ef30f1027f3facb3e297b787ba9f1654cb3e88b2791')
assert H((P/'validation-layer/manifest-sha256.json').read_bytes())=='f7e11ec263e661950432937415c3541478dac8927925e96727665cb51a04e560'
with tempfile.TemporaryDirectory(prefix='fees-donation-saved-check-') as temp:
 subprocess_check(P/'validation-layer/verify.py',cwd=temp)
 # Fresh baseline receipts are bound independently of the focused report.
 harness=read('harness-source-sha256.json');runtime=read('runtime-inputs.json')
 assert len(harness)==46 and len(runtime)==18;archive('harness-snapshot.tar.gz',harness)
 for n,h in runtime.items():assert H((P/'runtime'/n).read_bytes())==h
 frozen=read('frozen-runner-inputs.json');assert frozen['source_sha256']==source and frozen['harness_sha256']==harness and frozen['runtime_sha256']==runtime and frozen['runner_sha256']==H((P/'run_regressions.py').read_bytes())
 rows=read('receipt-build-bindings.json');assert len(rows)==10
 for r in rows:
  encoded=(P/r['saved_report']).read_bytes();raw=gzip.decompress(encoded);d=json.loads(raw)
  assert H(encoded)==r['saved_report_sha256'] and H(raw)==r['raw_report_sha256']==r['report_sha256']
  assert d['candidate_sha256']==C_SHA and d['original_sha256']==O_SHA and not d['mismatches']
  assert r['executed_candidate_sha256']==C_SHA and r['actual_source_sha256']==source and r['build_report_sha256']==H((P/'build-02/build-comparison.json').read_bytes()) and r['passed'] and r['returncode']==0
 summary=read('runtime-summary.json');assert summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and not summary['mismatches'] and not summary['orchestration_failures']
 # Recompute strict saved logs with the exact unchanged postprocessor, without VM execution.
 out=Path(temp)/'diagnostics.json';subprocess_check(P/'validation-layer/harness/check_retained_diagnostics.py',['--report',P/'differential.json.gz','--output',out],cwd=temp)
 diagnostic=J(out);saved=read('runtime-retained-diagnostics.json')
 assert diagnostic['rows']==saved['rows'] and not diagnostic['mismatches'] and not saved['mismatches'] and len(saved['rows'])==11
 assert saved['input_sha256']==H(gzip.decompress((P/'differential.json.gz').read_bytes())) and saved['candidate_sha256']==C_SHA
 assert read('runtime-retained-diagnostics-result.json')['returncode']==0
 if a.runtime:assert json.loads(subprocess_check(P/'verify_saved_runtime.py',cwd=temp))==read('runtime-verification-result.json')
# Recheck full focused comparisons/expected observations from saved bytes.
focused=read('runtime-focused/focused20.json');layer=P/'validation-layer';assert focused['source_sha256']==source and focused['candidate_sha256']==C_SHA and focused['original_sha256']==O_SHA
assert focused['build_record']==J(layer/'build02-bindings.json') and focused['build_record_sha256']==H((layer/'build02-bindings.json').read_bytes())
assert focused['case_manifest_sha256']==H((layer/'cases.json').read_bytes())
assert focused['harness_sha256']=={f.name:H(f.read_bytes()) for f in (layer/'harness').glob('*.py')}
assert focused['case_count']==20 and focused['transaction_count']==40 and focused['signature_count']==80 and not focused['mismatches']
assert focused['runtime']=={'signature_verification':True,'blockhash_check':True,'history':'default enabled; fresh VM per case'}
assert read('runtime-focused/result.json')['returncode']==0 and read('runtime-focused/result.json')['source_unchanged'] and read('runtime-focused/result.json')['layer_unchanged']
launch=read('runtime-focused/launch.json');assert launch['source_sha256']==source and launch['candidate_sha256']==C_SHA
for n,h in launch['layer_files'].items():assert H((layer/n).read_bytes())==h
functions=runpy.run_path(str(layer/'harness/assertions.py'));roles=focused['roles'];cases=J(layer/'cases.json')
assert [r['case'] for r in focused['cases']]==cases and collections.Counter(r['input_provenance'] for r in cases)=={'existing_input_repeat':8,'new_typed_synthetic_combination':12}
transaction_count=signature_count=0
for r in focused['cases']:
 assert not r['mismatches'] and not any(r['expected_failures'].values()) and r['match']
 assert functions['comparable'](r['original'],roles['PROGRAM']['str'])==functions['comparable'](r['candidate'],roles['PROGRAM']['str'])
 assert r['raw_logs_equal']==(r['original']['logs']==r['candidate']['logs'])
 for side in ['original','candidate']:
  x=r[side];assert not functions['check_expected'](x,r['case'],roles) and x['signature_verification']==[True,True]
  assert set(x['message_account_keys'][:2])=={roles['PAYER']['str'],roles['AUTH']['str']}
  if a.runtime:
   import base64
   from solders.transaction import VersionedTransaction
   raw=base64.b64decode(x['transaction_base64']);tx=VersionedTransaction.from_bytes(raw)
   assert bytes(tx)==raw and tx.verify_with_results()==[True,True] and [str(k) for k in tx.message.account_keys]==x['message_account_keys']
   transaction_count+=1;signature_count+=len(tx.signatures)
if a.runtime:assert transaction_count==40 and signature_count==80
if a.repo:
 repo=a.repo.resolve()
 for n,h in base.items():assert H((repo/n).read_bytes())==h,('current main changed',n)
 for n,h in read('published-harness-sha256.json').items():assert H((repo/n).read_bytes())==h,n
 for n,h in runtime.items():assert H((repo/n).read_bytes())==h,n
print(json.dumps({'verified':True,'sealed_files':len(manifest),'source_inputs':26,'original_inferred_windows':585,'candidate_symbol_windows':546,'whole_original_elf_equal':False,'handler_normalized_equal':False,'baseline_comparisons':17441,'donation_steps':10,'focused_cases':20,'focused_transactions':40,'focused_signatures':80,'focused_new_input_combinations':12,'focused_repeated_inputs':8,'saved_diagnostic_rows':11,'saved_signature_verifier_rerun':a.runtime,'current_baseline_bindings_checked':bool(a.repo),'main_source_changed':False},indent=2))
