#!/usr/bin/env python3
"""Package existing immutable inputs and saved execution results; never run SBF."""
from pathlib import Path
import gzip,hashlib,importlib.metadata,json,shutil,sys,tarfile
W=Path(__file__).resolve().parent;R=W.parents[2];P=W/'handoff';B=W/'build-02';A=W.parent
H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
assert not P.exists()
summary=J(W/'runtime/summary.json');assert summary['comparison_receipts']==17441 and not summary['mismatches'] and not summary['orchestration_failures']
focused=J(W/'runtime-focused/focused20.json');assert focused['case_count']==20 and focused['transaction_count']==40 and focused['signature_count']==80 and not focused['mismatches']
diagnostic=J(W/'runtime/retained-diagnostics.json');assert len(diagnostic['rows'])==11 and not diagnostic['mismatches']
P.mkdir()
def copy(src,n):
 dst=P/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
def save(n,v):
 dst=P/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(json.dumps(v,indent=2)+'\n')
def tar_sources(dst,root,mapping):
 with tarfile.open(P/dst,'w:gz') as t:
  for n,h in mapping.items():
   f=root/n;assert f.is_file() and not f.is_symlink() and H(f.read_bytes())==h,n;t.add(f,arcname=n,recursive=False)
def sealed_archive(src,name,seal):
 files={f.relative_to(src).as_posix():H(f.read_bytes()) for f in src.rglob('*') if f.is_file()}
 assert H((src/'manifest-sha256.json').read_bytes())==seal
 assert {n:h for n,h in files.items() if n!='manifest-sha256.json'}==J(src/'manifest-sha256.json')
 tar_sources(name,src,files)
# Preserve the actual executed directory structure so read-only methods need no edits.
for f in sorted(W.iterdir()):
 if f.is_file():copy(f,f.name)
shutil.copytree(W/'analysis-method',P/'analysis-method')
shutil.copytree(W/'runtime-focused',P/'runtime-focused')
shutil.copytree(R/'work/fees-donation-business-validation-a99d',P/'validation-layer')
for n in ['build-attempt.json','build-comparison.json']:copy(B/n,'build-02/'+n)
copy(B/'artifacts/pump_fees_candidate.so','build-02/artifacts/pump_fees_candidate.so')
copy(B/'artifacts/pump_fees_candidate.so','pump_fees_candidate.so')
(P/'build-02/build.log.gz').write_bytes(gzip.compress((B/'build.log').read_bytes(),mtime=0))
source=J(W/'source-sha256.json');base=J(W/'baseline-source-sha256.json')
assert len(source)==26 and [n for n in source if source[n]!=base[n]]==['programs/pump-fees/src/donation.rs']
assert all(H((R/n).read_bytes())==h for n,h in base.items()),'Current main source drift'
tar_sources('prebuild-snapshot.tar.gz',W,J(W/'prebuild-manifest-sha256.json'))
tar_sources('sbf-sdk-snapshot.tar.gz',B/'sdk',J(B/'build-comparison.json')['sdk_source_sha256'])
prior=R/'repro/pump_fees/donation-event-account-v144'
for n in ['harness-source-sha256.json','runtime-inputs.json','harness-origin-map.json','published-harness-sha256.json']:copy(prior/n,n)
harness=J(P/'harness-source-sha256.json');runtime=J(P/'runtime-inputs.json')
tar_sources('harness-snapshot.tar.gz',W/'runner-repo',harness)
for n,h in runtime.items():
 f=W/'runner-repo'/n;assert H(f.read_bytes())==h;copy(f,'runtime/'+n)
for n in ['summary.json','progress.json','retained-diagnostics.json','retained-diagnostics-launch.json','retained-diagnostics-result.json']:copy(W/'runtime'/n,'runtime-'+n)
receipts=[]
for row in summary['reports']:
 n=row['name'];raw=(W/'runtime'/(n+'.json')).read_bytes();compressed=gzip.compress(raw,mtime=0);(P/(n+'.json.gz')).write_bytes(compressed);copy(W/'runtime'/(n+'.log'),'runtime-logs/'+n+'.log')
 receipts.append({**row,'saved_report':n+'.json.gz','saved_report_sha256':H(compressed),'raw_report_sha256':H(raw)})
save('receipt-build-bindings.json',receipts)
copy(R/'work/fees-donation-event-accountinfo-recovery/verify_saved_runtime.py','verify_saved_runtime.py')
# Preserve first build as an explicitly superseded diagnostic baseline, with no runtime.
old_names=[f.name for f in A.iterdir() if f.is_file()]
for n in old_names:copy(A/n,'superseded-build01/'+n)
for n in ['build-attempt.json','build-comparison.json']:copy(A/'build-01'/n,'superseded-build01/build-01/'+n)
copy(A/'build-01/artifacts/pump_fees_candidate.so','superseded-build01/build-01/artifacts/pump_fees_candidate.so')
(P/'superseded-build01/build-01/build.log.gz').write_bytes(gzip.compress((A/'build-01/build.log').read_bytes(),mtime=0))
tar_sources('superseded-build01/prebuild-snapshot.tar.gz',A,J(A/'prebuild-manifest-sha256.json'))
sealed_archive(R/'work/fees-donation-business-independent-review','independent-source-review.tar.gz','2a96b9229ee8bbf62b4f7ef30f1027f3facb3e297b787ba9f1654cb3e88b2791')
# Original source proposal and diagnostic correction are already inside preserved seals;
# the explicit original proposal is also saved to make the complete chronology reviewable.
sealed_archive(R/'work/fees-donation-business-source-proposal','natural-source-proposal.tar.gz','69e1830d5d10b1153f801b3634104e406594904cdec51bb5777c9f866e48d0c1')
import solders
save('runtime-engine.json',{'python':sys.version,'python_executable':sys.executable,'solders_version':importlib.metadata.version('solders'),'native_extensions':{str(p):{'sha256':H(p.read_bytes()),'bytes':p.stat().st_size} for p in Path(solders.__file__).parent.rglob('*.so')},'execution':'Local LiteSVM, unchanged baseline plus separate approved focused20; saved signature checks do not replay SBF.'})
save('provenance.json',{'scope':'Two separately reviewed source builds: build01 superseded without runtime; corrected build02 is the sole tested candidate.','baseline_package':'repro/pump_fees/donation-event-account-v144','baseline_candidate_sha256':'8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e','candidate_sha256':H((P/'pump_fees_candidate.so').read_bytes()),'candidate_bytes':770744,'original_sha256':'4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e','source_inputs':26,'source_delta_paths':['programs/pump-fees/src/donation.rs'],'compile_tools_version':'v1.44','strip_tools_version':'v1.52','build_attempts':2,'compiler_failures':0,'source_variants':'Build02 incorporates three separately proved diagnostic-expression corrections; not compiler/layout search.','main_source_modified':False,'whole_original_elf_equal':False,'historical_absolute_paths':'Provenance only; portable verifier needs no work or cache paths.'})
save('main-source-proposal.json',{'status':'Review required; main unchanged.','source_delta_paths':['programs/pump-fees/src/donation.rs'],'donation_rs_sha256':source['programs/pump-fees/src/donation.rs'],'source_patch_sha256':H((P/'source.patch').read_bytes()),'source_count':26,'bounded_handlers_unchanged':31,'exact_contracts_unchanged':'0/4','candidate_sha256':H((P/'pump_fees_candidate.so').read_bytes()),'requires_clean_main_build_whole_ELF_identity':True,'baseline_comparison_receipts':17441,'donation_sequence_steps':10,'focused_comparisons':20,'focused_transactions':40,'focused_signatures':80,'retained_diagnostic_rows_postprocessed':11,'limitations':['Original and candidate complete donation handler windows differ; no byte identity.','Only focused20 has the expanded state/event/inner/return/log assertions; baseline comparators retain documented scope.','Source coordinates and compute-unit logs remain excluded from semantic log equality and retained raw.','Original inferred windows are not a proven historical function denominator.','Immediate-call and consumed-literal proofs do not close indirect/transitive/data extents.','No deployed substitute or historical full source claim.']})
print(json.dumps({'packaged_files_before_seal':sum(p.is_file() for p in P.rglob('*')),'candidate':H((P/'pump_fees_candidate.so').read_bytes())}))
