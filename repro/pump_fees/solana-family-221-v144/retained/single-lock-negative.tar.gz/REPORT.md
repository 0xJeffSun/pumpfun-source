# Fees graph reconstruction from one retained SPL release lock

**No complete compatible graph can be derived within the permitted replacement source.** The single SPL POD 0.5.1 published Cargo.lock grounds four precise replacements, but it contains no version of the three Instruction parent packages that must also change. Keeping their current versions leaves three mandatory version conflicts and one missing feature. This is a static incompatibility result, not a Cargo resolution or build result.

The proposal in `proposed-selection.json` records all 253 current package selections, changing exactly four and retaining 249. It is explicitly not a Cargo.lock or build input. All 82 current Solana/SPL package nodes are listed in `family-nodes.json`; 692 normal/build dependency specifications from those manifests, Anchor lang/spl and the four proposed versions are preserved in `dependency-constraints.json`. The proposal is maximal within the exact evidence checked, not a claim that its unresolved graph is usable.

## Only permitted replacements

The replacement source is the cached official SPL POD 0.5.1 crate's Cargo.lock, SHA256 `a4bb7419e5934d0bd08bec57db4d8f5bbfa5879fca4f785d860e798fea3ad5f3`. The crate archive is retained and its checksum matches the unchanged Fees lock. Each proposed version below is selected by that same release lock and confirmed by its exact cached crates.io index record. No other version record was inspected or selected.

| Package | Current | Proposed | Registry checksum |
| --- | --- | --- | --- |
| solana-pubkey | 2.4.0 | 2.2.1 | `40db1ff5a0f8aea2c158d78ab5f2cf897848964251d1df42fef78efd3c85b863` |
| solana-zk-sdk | 2.3.13 | 2.2.0 | `26f66acae4f01a718825ae0201ea0a05ae3c9a3afb27a7eed6f0803b96da639b` |
| solana-instruction | 2.3.3 | 2.2.1 | `9ce496a475e5062ba5de97215ab39d9c358f9c9df4bb7f3a45a1f1a8bd9065ed` |
| solana-signature | 2.3.0 | 2.2.1 | `47d251c8f3dc015f320b4161daac7f108156c837428e5a8cc61136d25beb11d6` |

The first pair is the retained release association motivated by original Pubkey source-coordinate and formatter evidence. SDK 2.2.0 then forces Instruction and Signature exactly 2.2.1. It also pins derivation-path, sdk-ids, seed-derivable, seed-phrase and signer to 2.2.1; those five already have that frozen version. Current parent requirements of SDK 2.2.0 all accept it. All nonoptional outgoing requirements of the four proposed packages have a compatible selected version in the retained package set; this is only a local constraint check, not global closure.

Other release-lock versions are not applied indiscriminately. For example, current decode-error2.3.0, define-syscall2.3.0, hash2.3.0, program-error2.2.2 and sha256-hasher2.3.0 remain selected wherever the proposed package constraints allow them. Replacing every Solana crate merely because the release lock has an older version would not be justified by this task.

## Minimal conflict and required parent reconstruction

The unchanged Fees manifest pins Anchor lang and SPL exactly 0.31.1. Anchor lang unconditionally requires solana-program ^2. The only allowed selection for Program under this task's rule remains current 2.3.0, because the permitted release lock has **no solana-program entry at all**.

Program 2.3.0 unconditionally requires Instruction ^2.3.0. SDK 2.2.0 unconditionally requires Instruction =2.2.1. Those ranges are disjoint. Program also directly requests Instruction's `syscalls` feature; version 2.2.1 does not define it. Thus the proposed graph fails before a compiler or runtime is involved.

Two more current parents have the same mandatory version conflict:

| Required parent change | Current Instruction dependency | Replacement in permitted release lock |
| --- | --- | --- |
| solana-program2.3.0 | ^2.3.0; bincode, serde, std, syscalls | Absent |
| solana-sysvar2.3.0 | ^2.3.0; default-features false | Absent |
| solana-vote-interface2.2.6 | ^2.3.0; std, default-features false | Absent |

These are unconditional, nonoptional dependencies. Accepted SBF fingerprints show all three parent packages were compiled, so this is not an artifact of dormant optional metadata. None can be dropped by disabling a feature of the unchanged Fees/Anchor selection. No replacement version for these parents was inferred from matching numbers or fetched from another release. Retaining multiple incompatible-type copies is not a demonstrated resolution of the intended shared Solana graph, and no such graph was proposed.

The contradiction proves there is no complete proposal using these four release-backed selections plus unchanged parents. Under the task's rule that every replacement must come from the same release lock, there is no admissible next parent replacement. A further exact historical graph would require additional authoritative release/build provenance that actually includes Program, Sysvar and Vote Interface; the present evidence does not provide it.

## Features and dependency effects

The accepted SBF Pubkey features are borsh, bytemuck, curve25519, default, serde, sha2 and std. All definitions are identical in 2.2.1 and 2.4.0. Pubkey's formatter dependency changes from five8 to already-locked bs58^0.5.1. Signature2.2.1 likewise uses bs58. five8 is still needed by retained Hash2.3.0; no global removal is proposed.

Instruction's accepted SBF union is bincode, borsh, default, serde, std and syscalls. The proposed 2.2.1 version supports all except syscalls. Its serde feature does not enable serde_json, unlike 2.3.3. This is an actual feature-definition difference; existing serde_json may remain reachable elsewhere. No package-pruning inference is made.

Signature2.2.1 defaults to std; current 2.3.0 defaults to std + alloc and std itself enables alloc. There is no Signature fingerprint in the accepted SBF output. Its SDK dependency is a non-Solana target dependency, so full-lock host-target constraints and SBF feature use must remain distinct. SDK 2.2.0 requests default features for Signature and Pubkey where currentSDK 2.3.13 suppresses them. The Pubkey default is already in the accepted SBF union. This does not establish a complete reconstructed host/SBF feature union.

Both SDK versions have empty public feature tables. SPL Token-2022's zk-ops and SDK dependency facts remain unchanged: the SDK edge is unconditional. A token feature change would depart from the requested unchanged manifest and would not be justified by this source-family evidence.

All optional constraints are retained with their optional flags. Missing selections for inactive optional packages such as frozen-abi, arbitrary or Anchor's optional Metadata dependency are not counted as mandatory graph conflicts. No full new optional-feature closure is claimed, because the mandatory conflict already prevents the proposed selection from being valid.

## Source availability and evidence limits

Exact cached source archives for Pubkey2.2.1, Instruction2.2.1 and Signature2.2.1 were found, checksum-verified against the single release lock/index records, and retained with normalized manifests/VCS records. No downloads occurred. SDK 2.2.0's exact cached index record and release checksum are available; its source archive was absent from the specifically checked workspace and standard Cargo caches. This is a cache-availability statement, not proof source was never published.

The old source archives do not independently prove these were the deployment's versions. Source-coordinate and formatter evidence supports Pubkey's older source family; the SPL POD release lock supplies a concrete historical pairing, not the original Fees build manifest. The unchanged-source Linux build remains a separate lane.

No source/lock edits, downloads, Cargo resolution, builds, runtime tests or binary edits were performed. Current files were read and frozen into this scratch package only. `verify.py` checks the seal, release archive/lock association, exact proposed-version records, all retained selections, the mandatory conflicts and feature absence. Run:

```sh
python3 work/fees-release-graph-reconstruction/verify.py
```
