from pathlib import Path
import hashlib,json,tarfile,tomllib
W=Path(__file__).resolve().parent;I=W/'inputs';H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
manifest=J(W/'manifest-sha256.json');assert set(manifest)=={str(p.relative_to(W))for p in W.rglob('*')if p.is_file()and p.name!='manifest-sha256.json'}
for n,h in manifest.items():assert H((W/n).read_bytes())==h,n
cur=tomllib.loads((I/'current-Cargo.lock').read_text())['package'];rel=tomllib.loads((I/'spl-pod-0.5.1-release-Cargo.lock').read_text())['package'];source=J(W/'source-provenance.json');proposed=J(W/'proposed-selection.json')['packages'];byrel={p['name']:p for p in rel}
assert len(cur)==len(proposed)==253
assert H((I/'spl-pod-0.5.1.crate').read_bytes())==next(p['checksum']for p in cur if p['name']=='spl-pod')
with tarfile.open(I/'spl-pod-0.5.1.crate')as t:assert t.extractfile('spl-pod-0.5.1/Cargo.lock').read()==(I/'spl-pod-0.5.1-release-Cargo.lock').read_bytes()
changes={p['name']:p['version']for p in proposed if p['version']!=p['original_version']};assert changes=={'solana-pubkey':'2.2.1','solana-zk-sdk':'2.2.0','solana-instruction':'2.2.1','solana-signature':'2.2.1'}
for old,new in zip(cur,proposed):
 assert old['name']==new['name']and old['version']==new['original_version']
 if old['name']in changes:assert new['version']==byrel[old['name']]['version']and new['checksum']==byrel[old['name']]['checksum']
 else:assert old['version']==new['version']and old.get('checksum')==new.get('checksum')
index={}
for n,v in changes.items():
 key=n+'-'+v;cache=(I/(n+'-index-cache.bin')).read_bytes();rows=[b for b in cache.split(b'\0')if b.startswith(b'{')and json.loads(b).get('vers')==v];assert len(rows)==1
 assert rows[0]+b'\n'==(I/(key+'-index-record.json')).read_bytes();d=json.loads(rows[0]);index[n]=d;assert d['cksum']==byrel[n]['checksum'];assert H(cache)==source[key]['registry_cache_sha256']
 if source[key]['source_archive_present']:
  archive=I/(key+'.crate');assert H(archive.read_bytes())==d['cksum']
  with tarfile.open(archive)as t:assert t.extractfile(key+'/Cargo.toml').read()==(I/key/'Cargo.toml').read_bytes()
  m=tomllib.loads((I/key/'Cargo.toml').read_text());assert m.get('features',{})=={**d.get('features',{}),**d.get('features2',{})}
for key,row in source.items():
 if 'manifest_sha256'in row:assert H((I/key/'Cargo.toml').read_bytes())==row['manifest_sha256']
assert all(n not in byrel for n in ['solana-program','solana-sysvar','solana-vote-interface'])
zk=index['solana-zk-sdk'];assert any(d['name']=='solana-instruction'and d['req']=='=2.2.1'and d['target']is None and not d['optional']for d in zk['deps'])
ins=index['solana-instruction'];assert 'syscalls'not in{**ins['features'],**ins.get('features2',{})}
for key in ['solana-program-2.3.0','solana-sysvar-2.3.0','solana-vote-interface-2.2.6']:
 m=tomllib.loads((I/key/'Cargo.toml').read_text());d=m['dependencies']['solana-instruction'];assert d['version']=='2.3.0'and not d.get('optional',False)
 if key.startswith('solana-program-'):assert 'syscalls'in d['features']
key='anchor-lang-0.31.1';m=tomllib.loads((I/key/'Cargo.toml').read_text());assert m['dependencies']['solana-program']['version']=='2'
fees=tomllib.loads((I/'fees-Cargo.toml').read_text());assert fees['dependencies']['anchor-lang']['version']=='=0.31.1'and fees['dependencies']['anchor-spl']['version']=='=0.31.1'
es=J(W/'dependency-constraints.json');assert len(es)==692
conflicts=[x for x in es if not x['optional']and(not x['version_satisfied']or x['requested_missing_features'])];closure=J(W/'closure-result.json');assert conflicts==closure['mandatory_conflicts']and len(conflicts)==3
assert {x['parent']for x in conflicts}=={'solana-program-2.3.0','solana-sysvar-2.3.0','solana-vote-interface-2.2.6'}
assert closure['complete_compatible_graph']is False and closure['can_close_with_allowed_replacement_universe']is False
assert len(J(W/'family-nodes.json'))==82
print(json.dumps({'sealed_files':len(manifest),'package_selections':253,'retained_selections':249,'release_backed_replacements':4,'family_nodes':82,'recorded_constraint_edges':692,'mandatory_conflicting_parents':3,'missing_instruction_feature':'syscalls','complete_compatible_graph':False,'downloads':0,'builds':0,'runtime_tests':0},indent=2))
