"""Read-only, single-release-lock graph proposal; no resolver/build/version search."""
from pathlib import Path
import hashlib,json,tarfile,tomllib,shutil,re,datetime
W=Path(__file__).resolve().parent;R=W.parents[1];I=W/'inputs'
B=R/'work/fees-v144-cargo-home/registry';C=B/'cache/index.crates.io-1949cf8c6b5b557f';S=B/'src/index.crates.io-1949cf8c6b5b557f';X=B/'index/index.crates.io-1949cf8c6b5b557f/.cache'
H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text());put=lambda n,v:(W/n).write_text(json.dumps(v,indent=2)+'\n')
for src,dst in [('Cargo.lock','current-Cargo.lock'),('Cargo.toml','workspace-Cargo.toml'),('programs/pump-fees/Cargo.toml','fees-Cargo.toml'),('work/pubkey-221-graph-feasibility/inputs/spl-pod-0.5.1/Cargo.lock','spl-pod-0.5.1-release-Cargo.lock')]:shutil.copyfile(R/src,I/dst)
current=tomllib.loads((I/'current-Cargo.lock').read_text())['package'];release=tomllib.loads((I/'spl-pod-0.5.1-release-Cargo.lock').read_text())['package'];relby={p['name']:p for p in release if p['name'].startswith(('solana-','spl-'))}
# Only four replacements directly forced by the previously identified release pairing.
replace={'solana-pubkey':'2.2.1','solana-zk-sdk':'2.2.0','solana-instruction':'2.2.1','solana-signature':'2.2.1'}
for n,v in replace.items():assert relby[n]['version']==v
selected=[]
for p in current:
 row=dict(p);name=p['name'];row['original_version']=p['version'];row['selection_reason']='preserve frozen version; no required replacement established'
 if name in replace:
  row={**relby[name],'original_version':p['version'],'selection_reason':'exact version/checksum in the single SPL POD 0.5.1 published lock','release_lock_bound':True}
 row.pop('dependencies',None)
 selected.append(row)
by={}
for p in selected:by.setdefault(p['name'],[]).append(p)
provenance={};manifests={};indexes={}
for p in current:
 if p['name'].startswith(('solana-','spl-'))or p['name']in['anchor-lang','anchor-spl']:
  key=p['name']+'-'+p['version'];a=C/(key+'.crate');b=a.read_bytes();assert H(b)==p['checksum']
  with tarfile.open(a)as t:
   meta=t.extractfile(key+'/Cargo.toml').read();vcs=key+'/.cargo_vcs_info.json';v=t.extractfile(vcs).read()if vcs in t.getnames()else None
  assert meta==(S/key/'Cargo.toml').read_bytes();dest=I/key;dest.mkdir(exist_ok=True);(dest/'Cargo.toml').write_bytes(meta)
  if v:(dest/'.cargo_vcs_info.json').write_bytes(v)
  manifests[key]=tomllib.loads(meta.decode());provenance[key]={'archive_sha256':H(b),'archive_bytes':len(b),'manifest_sha256':H(meta),'checksum_matches_frozen_lock':True}
# Preserve the exact release-lock source archive, not just a free-standing lock.
pod=(C/'spl-pod-0.5.1.crate').read_bytes();(I/'spl-pod-0.5.1.crate').write_bytes(pod)
with tarfile.open(I/'spl-pod-0.5.1.crate')as t:assert t.extractfile('spl-pod-0.5.1/Cargo.lock').read()==(I/'spl-pod-0.5.1-release-Cargo.lock').read_bytes()
for name,v in replace.items():
 path=X/name[:2]/name[2:4]/name;b=path.read_bytes();rows=[r for r in b.split(b'\0')if r.startswith(b'{')and json.loads(r).get('vers')==v];assert len(rows)==1
 d=json.loads(rows[0]);assert d['cksum']==relby[name]['checksum'];indexes[name]=d;(I/(name+'-index-cache.bin')).write_bytes(b);(I/(name+'-'+v+'-index-record.json')).write_bytes(rows[0]+b'\n')
 provenance[name+'-'+v]={'registry_cache_sha256':H(b),'registry_exact_record_sha256':H(rows[0]+b'\n'),'archive_checksum_from_release_and_index':d['cksum'],'publication_time':d.get('pubtime'),'source_archive_present':False}
 # Inspect only the exact four evidenced archive names in already-known cache locations.
 paths=[]
 for base in [B,Path.home()/'.cargo/registry']:
  paths.extend(base.glob('cache/*/'+name+'-'+v+'.crate'))
 if name=='solana-pubkey':paths.append(R/'work/pubkey-source-coordinate-attribution/inputs/solana-pubkey-2.2.1.crate')
 paths=[p for p in paths if p.is_file()]
 if paths:
  archive=paths[0].read_bytes();assert H(archive)==d['cksum'];(I/(name+'-'+v+'.crate')).write_bytes(archive)
  provenance[name+'-'+v]['source_archive_present']=True;provenance[name+'-'+v]['archive_bytes']=len(archive)
  key=name+'-'+v;dest=I/key;dest.mkdir(exist_ok=True)
  with tarfile.open(paths[0])as t:
   meta=t.extractfile(key+'/Cargo.toml').read();(dest/'Cargo.toml').write_bytes(meta)
   vcs=key+'/.cargo_vcs_info.json'
   if vcs in t.getnames():(dest/'.cargo_vcs_info.json').write_bytes(t.extractfile(vcs).read())
  m=tomllib.loads(meta.decode());assert m.get('features',{})=={**d.get('features',{}),**d.get('features2',{})}
  provenance[key]['manifest_sha256']=H(meta)
# Arithmetic on observed Cargo caret/exact/basic ranges, not a dependency resolver.
def version(v):
 parts=v.split('.');return tuple(map(int,parts))+(0,)*(3-len(parts))
def allows(v,req):
 if ','in req:return all(allows(v,r.strip())for r in req.split(','))
 v=version(v);req=req.strip()
 for op in ['>=','<=','>','<','=']:
  if req.startswith(op):
   p=version(req[len(op):]);return {'>=':v>=p,'<=':v<=p,'>':v>p,'<':v<p,'=':v==p}[op]
 if req=='*':return True
 if '*'in req:
  p=tuple(map(int,req.split('.*')[0].split('.')));return v[:len(p)]==p
 if req.startswith('~'):
  q=req[1:].split('.');lo=version(req[1:]);hi=(lo[0]+1,0,0)if len(q)==1 else(lo[0],lo[1]+1,0);return lo<=v<hi
 lo=version(req.removeprefix('^'));hi=(lo[0]+1,0,0)if lo[0]else((0,lo[1]+1,0)if lo[1]else(0,0,lo[2]+1));return lo<=v<hi

def metadata_edges(key,m):
 rows=[]
 for target,section in [('unconditional',m)]+list(m.get('target',{}).items()):
  for kind in ['dependencies','build-dependencies']:
   for alias,spec in section.get(kind,{}).items():
    if isinstance(spec,str):spec={'version':spec}
    rows.append({'parent':key,'target':target,'kind':kind,'alias':alias,'dependency':spec.get('package',alias),'requirement':spec['version'],'features':spec.get('features',[]),'default_features':spec.get('default-features',True),'optional':spec.get('optional',False)})
 return rows
edges=[];feature_defs={}
for key,m in manifests.items():
 name=m['package']['name']
 if name in replace:continue
 edges.extend(metadata_edges(key,m));feature_defs[key]=m.get('features',{})
for name,d in indexes.items():
 key=name+'-'+d['vers'];feature_defs[key]={**d.get('features',{}),**d.get('features2',{})}
 for dep in d['deps']:
  if dep['kind']=='dev':continue
  edges.append({'parent':key,'target':dep['target']or'unconditional','kind':'dependencies'if dep['kind']=='normal'else'build-dependencies','alias':dep['name'],'dependency':dep.get('package')or dep['name'],'requirement':dep['req'],'features':dep['features'],'default_features':dep['default_features'],'optional':dep['optional']})
for row in edges:
 candidates=by.get(row['dependency'],[]);row['selected_compatible_versions']=[p['version']for p in candidates if allows(p['version'],row['requirement'])]
 row['retained_selected_versions']=[p['version']for p in candidates]
 row['version_satisfied']=bool(row['selected_compatible_versions'])
 row['requested_missing_features']=[]
 for p in candidates:
  key=p['name']+'-'+p['version']
  if key not in feature_defs:continue
  known=set(feature_defs[key]);known.update(e['alias']for e in edges if e['parent']==key and e['optional'] and not any('dep:'+e['alias']in items for items in feature_defs[key].values()))
  row['requested_missing_features']+=sorted(set(row['features'])-known)
required_conflicts=[e for e in edges if not e['optional'] and (not e['version_satisfied']or e['requested_missing_features'])]
assert {(e['parent'],e['dependency'])for e in required_conflicts}=={('solana-program-2.3.0','solana-instruction'),('solana-sysvar-2.3.0','solana-instruction'),('solana-vote-interface-2.2.6','solana-instruction')},required_conflicts
assert required_conflicts[0] # all below are unconditional edges, not unactivated optionals
assert all(e['target']=='unconditional'for e in required_conflicts)
# Record actual accepted SBF feature unions separately, not as a solved proposed feature union.
fingerprint_root=R/'work/fees-readme-provenance/main-build/target/sbf-solana-solana/release/.fingerprint';features=[]
for name in sorted(set(replace)|{'anchor-lang','anchor-spl','solana-program','solana-sysvar','solana-vote-interface','spl-token-2022'}):
 files=list(fingerprint_root.glob(name+'-*/lib-'+name.replace('-','_')+'.json'))
 row={'package':name,'accepted_SBF_fingerprint_present':bool(files),'accepted_features':None}
 if files:
  assert len(files)==1;raw=files[0].read_bytes();d=json.loads(raw);(I/(name+'-accepted-SBF-fingerprint.json')).write_bytes(raw)
  row['accepted_features']=json.loads(d['features'])
 if name in replace:
  oldkey=name+'-'+replace[name];cur=next(p for p in current if p['name']==name);curkey=name+'-'+cur['version'];old=feature_defs[oldkey];now=manifests[curkey].get('features',{})
  row.update(proposed_definitions=old,current_definitions=now,accepted_features_absent_from_proposed=sorted(set(row['accepted_features'])-set(old))if row['accepted_features']is not None else None,definition_changes={k:{'current':now.get(k),'proposed':old.get(k)}for k in sorted(set(old)|set(now))if old.get(k)!=now.get(k)})
 features.append(row)
solana=[{'name':p['name'],'frozen_version':p['original_version'],'proposed_version':p['version'],'changed':p['version']!=p['original_version'],'release_lock_has_name':p['name']in relby,'release_version':relby.get(p['name'],{}).get('version'),'checksum':p.get('checksum')}for p in selected if p['name'].startswith(('solana-','spl-'))]
unsat={'unchanged_top_level_manifest':True,'only_release_lock_replacements':True,'proposed_changed_nodes':len(replace),'current_total_package_nodes':len(current),'complete_compatible_graph':False,'can_close_with_allowed_replacement_universe':False,
 'mandatory_conflicts':required_conflicts,'missing_required_replacement_provenance':[{'name':n,'current_version':next(p['version']for p in current if p['name']==n),'in_permitted_release_lock':n in relby,'allowed_replacement':None}for n in ['solana-program','solana-sysvar','solana-vote-interface']],
 'minimal_conflict_witness':['Fees -> anchor-lang =0.31.1 -> solana-program ^2; frozen/only permitted selection remains2.3.0 because permitted release lock has no solana-program.','solana-program2.3.0 unconditionally requires solana-instruction ^2.3.0 with syscalls feature.','Exact release pairing chooses solana-zk-sdk2.2.0, which unconditionally requires solana-instruction =2.2.1; that version also lacks syscalls.','The required instruction ranges are disjoint. Retaining these parents cannot yield the intended unified graph. No unsupported replacement or duplicate-type graph was invented.'],
 'limitations':'Static constraint and feature evidence, not Cargo resolver execution. The failed mandatory edges alone prove this proposed selection does not close; optional/host feature union is not claimed complete. Instruction2.2.1, Signature2.2.1 and Pubkey2.2.1 exact cached archives are retained; SDK2.2.0 has cached index metadata but its source archive is absent from the inspected caches.'}
put('proposed-selection.json',{'warning':'NOT A CARGO LOCKFILE. Static, unsatisfied selection proposal only.','packages':selected});put('family-nodes.json',solana);put('dependency-constraints.json',edges);put('feature-evidence.json',features);put('source-provenance.json',provenance);put('closure-result.json',unsat)
print(json.dumps({'family_nodes':len(solana),'candidate_replacements':replace,'constraint_edges':len(edges),'mandatory_conflicts':len(required_conflicts),'absent_replacement_package_names':list(x['name']for x in unsat['missing_required_replacement_provenance']),'complete_graph':False},indent=2))
