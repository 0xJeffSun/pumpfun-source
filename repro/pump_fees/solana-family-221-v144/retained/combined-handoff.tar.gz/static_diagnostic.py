#!/usr/bin/env python3
"""Read-only, standard-library ELF diagnostic. No normalized ELF is written."""
from pathlib import Path
import hashlib
import struct

H = lambda b: hashlib.sha256(b).hexdigest()

class ELF:
    def __init__(self, path):
        self.b = Path(path).read_bytes()
        b = self.b
        off = struct.unpack_from('<Q', b, 40)[0]
        size, count, names_index = struct.unpack_from('<HHH', b, 58)
        rows = [struct.unpack_from('<IIQQQQIIQQ', b, off + i * size) for i in range(count)]
        nr = rows[names_index]
        names = b[nr[4]:nr[4] + nr[5]]
        self.sections = {names[r[0]:].split(b'\0', 1)[0].decode(): r for r in rows}
        text = self.sections['.text']
        assert text[3] == text[4]
        self.lo, self.hi = text[4], text[4] + text[5]
        self.funcs, symbols = {}, {}
        for kind in ['.dynsym', '.symtab']:
            if kind not in self.sections:
                continue
            sec = self.sections[kind]
            strings_row = rows[sec[6]]
            strings = b[strings_row[4]:strings_row[4] + strings_row[5]]
            for index, at in enumerate(range(sec[4], sec[4] + sec[5], 24)):
                name, info, _, _, addr, length = struct.unpack_from('<IBBHQQ', b, at)
                name = strings[name:].split(b'\0', 1)[0].decode()
                if kind == '.dynsym':
                    symbols[index] = name
                if info & 15 == 2 and length and self.lo <= addr < self.hi:
                    entry = self.funcs.setdefault(addr, {'length': length, 'names': []})
                    assert entry['length'] == length
                    entry['names'].append(name)
        self.rels, self.calls = {}, {}
        entries = set(self.funcs)
        ep = struct.unpack_from('<Q', b, 24)[0]
        if self.lo <= ep < self.hi:
            entries.add(ep)
        sec = self.sections.get('.rel.dyn')
        if sec:
            for at in range(sec[4], sec[4] + sec[5], 16):
                pos, info = struct.unpack_from('<QQ', b, at)
                typ = info & 0xffffffff
                self.rels[pos] = {'type': typ, 'symbol': symbols.get(info >> 32, '')}
                if typ == 8:
                    target = self.lddw(pos) if self.lo <= pos < self.hi and b[pos] == 0x18 else struct.unpack_from('<Q', b, pos)[0] >> 32
                    if self.lo <= target < self.hi and target % 8 == 0:
                        entries.add(target)
        normalized = bytearray(b)
        for at in range(self.lo, self.hi, 8):
            typ = self.rels.get(at, {}).get('type')
            if b[at:at + 2] == b'\x85\x10' and typ != 10:
                target = at + 8 + struct.unpack_from('<i', b, at + 4)[0] * 8
                self.calls[at] = target
                normalized[at + 4:at + 8] = bytes(4)
                if self.lo <= target < self.hi and target % 8 == 0:
                    entries.add(target)
            if typ == 8 and b[at] == 0x18:
                normalized[at + 4:at + 8] = bytes(4)
                normalized[at + 12:at + 16] = bytes(4)
            elif typ == 10 and b[at] == 0x85:
                normalized[at + 4:at + 8] = bytes(4)
        self.normalized, self.entries = bytes(normalized), sorted(entries)

    def lddw(self, at):
        assert self.b[at] == 0x18
        return struct.unpack_from('<I', self.b, at + 4)[0] | (struct.unpack_from('<I', self.b, at + 12)[0] << 32)

    def pattern(self, start, length):
        return [{'offset': at - start, **r} for at, r in sorted(self.rels.items()) if start <= at < start + length]

    def end(self, start):
        return next((x for x in self.entries if x > start), self.hi)

    def location(self, pc):
        record = self.lddw(pc)
        file_pointer, length, line, column = struct.unpack_from('<QQII', self.b, record)
        file_pointer >>= 32
        assert 0 < length < 1024
        filename = self.b[file_pointer:file_pointer + length].decode()
        return {'instruction': pc, 'record_address': record, 'record_sha256': H(self.b[record:record + 24]),
                'filename_address': file_pointer, 'filename': filename, 'line': line, 'column': column}

def compare_window(candidate, original, ca, oa, length):
    cb, ob = candidate.b[ca:ca + length], original.b[oa:oa + length]
    cn, on = candidate.normalized[ca:ca + length], original.normalized[oa:oa + length]
    return {'candidate_start': ca, 'original_start': oa, 'bytes': length,
            'candidate_raw_sha256': H(cb), 'original_raw_sha256': H(ob),
            'candidate_normalized_sha256': H(cn), 'original_normalized_sha256': H(on),
            'raw_equal': cb == ob, 'normalized_equal': cn == on,
            'relocation_pattern_equal': candidate.pattern(ca, length) == original.pattern(oa, length),
            'candidate_relocations': candidate.pattern(ca, length), 'original_relocations': original.pattern(oa, length),
            'original_entry_bounded': oa in original.entries and original.end(oa) == oa + length}

def diagnostic(candidate_path, original_path, symbols_path):
    candidate, original, symbols = [ELF(p) for p in [candidate_path, original_path, symbols_path]]
    assert (candidate.lo, candidate.hi) == (symbols.lo, symbols.hi)
    assert candidate.b[candidate.lo:candidate.hi] == symbols.b[symbols.lo:symbols.hi]
    specs = [('create_with_seed', 642216, 751992, 288), ('find_program_address', 642504, 752280, 312),
             ('create_program_address', 642816, 752592, 464), ('log', 643280, 753056, 16),
             ('write_as_base58', 643296, 753072, 1520), ('Display_Debug_fmt', 644816, 754592, 40)]
    windows = []
    for name, ca, oa, length in specs:
        row = compare_window(candidate, original, ca, oa, length)
        assert symbols.funcs[ca]['length'] == length
        row.update(name=name, symbol_names=symbols.funcs[ca]['names'])
        assert row['normalized_equal'] and row['relocation_pattern_equal'] and row['original_entry_bounded']
        windows.append(row)
    base = next(w for w in windows if w['name'] == 'write_as_base58')
    direct = []
    for pc, target in candidate.calls.items():
        if not base['candidate_start'] <= pc < base['candidate_start'] + base['bytes']:
            continue
        offset = pc - base['candidate_start']
        op = base['original_start'] + offset
        other_target = original.calls[op]
        length = symbols.funcs[target]['length']
        row = compare_window(candidate, original, target, other_target, length)
        row.update(call_offset=offset, candidate_call_displacement=struct.unpack_from('<i', candidate.b, pc + 4)[0],
                   original_call_displacement=struct.unpack_from('<i', original.b, op + 4)[0], symbol_names=symbols.funcs[target]['names'])
        assert row['normalized_equal'] and row['relocation_pattern_equal'] and row['original_entry_bounded']
        direct.append(row)
    assert len(direct) == 10
    locations = []
    for name, offsets in [('find_program_address', [200]), ('create_program_address', [440]),
                          ('write_as_base58', [776, 824, 1280, 1312, 1352, 1384, 1496])]:
        w = next(w for w in windows if w['name'] == name)
        for offset in offsets:
            c = candidate.location(w['candidate_start'] + offset)
            o = original.location(w['original_start'] + offset)
            assert all(c[k] == o[k] for k in ['filename', 'line', 'column'])
            locations.append({'function': name, 'offset': offset, 'candidate': c, 'original': o})
    display = next(w for w in windows if w['name'] == 'Display_Debug_fmt')
    assert display['raw_equal']
    assert candidate.calls[display['candidate_start'] + 24] == base['candidate_start']
    assert original.calls[display['original_start'] + 24] == base['original_start']
    assert [(r['candidate']['line'], r['candidate']['column']) for r in locations[:2]] == [(612, 32), (131, 18)]
    return {'scope': 'Full symbol-sized candidate bodies, inferred original entry boundaries, exact relocation patterns. Internal-call and loader immediates normalized only in memory. Formatter direct targets are checked one hop, including 8-byte thunks. Pointed source records are independently decoded. This is not all transitive data or whole-ELF identity.',
            'candidate_sha256': H(candidate.b), 'original_sha256': H(original.b), 'symbols_sha256': H(symbols.b),
            'full_byte_equality': candidate.b == original.b, 'candidate_bytes': len(candidate.b), 'original_bytes': len(original.b),
            'different_positions_in_shared_length': sum(a != b for a, b in zip(candidate.b, original.b)),
            'length_difference': len(candidate.b) - len(original.b), 'helpers': windows,
            'formatter_direct_targets': direct, 'source_location_records': locations,
            'display_call_offset': 24, 'runtime_cases': 0}
