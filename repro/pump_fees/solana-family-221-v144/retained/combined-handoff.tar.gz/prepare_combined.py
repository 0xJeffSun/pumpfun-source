#!/usr/bin/env python3
"""One authorized combination of sealed social-layout source and family lock."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];C=W/'combined';S=C/'workspace'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
assert not C.exists();S.mkdir(parents=True)
prior=R/'repro/pump_fees/social-v2-account-layout-v144'
expected=json.loads((R/'work/fees-social-v2-box-recovery/main-build-01/build-attempt.json').read_text())['source_sha256']
assert expected==json.loads((prior/'source-sha256.json').read_text()) and len(expected)==22
with tarfile.open(prior/'source-snapshot.tar.gz')as t:
 for m in t.getmembers():
  assert m.isfile() and m.name in expected and '..'not in Path(m.name).parts
  data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==expected[m.name]
  p=S/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
assert {p:H(S/p)for p in expected}==expected
shutil.copyfile(W/'cargo-resolved-Cargo.lock',S/'Cargo.lock')
helpers=json.loads((W/'handoff/build-helper-sha256.json').read_text())
for p,d in helpers.items():
 src=W/'workspace'/p;assert H(src)==d
 dst=S/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
reference=S/'evidence/original/pump_fees/deployed.so';reference.parent.mkdir(parents=True,exist_ok=True);reference.symlink_to(R/'evidence/original/pump_fees/deployed.so')
source={p:H(S/p)for p in expected};assert[p for p in expected if source[p]!=expected[p]]==['Cargo.lock']
save(C/'source-sha256.json',source)
save(C/'plan.json',{'scope':'One combination of main-build-01 social-layout source and the sealed eight-package family lock. No source variant or new runtime cases.','social_build_report_sha256':H(R/'work/fees-social-v2-box-recovery/main-build-01/build-attempt.json'),'social_source_sha256':expected,'source_sha256':source,'delta_from_social_source':['Cargo.lock'],'pure_graph_manifest_sha256':H(W/'handoff/manifest-sha256.json'),'build_helpers':helpers,'compile_tools_version':'v1.44','retained_sdk_strip_default':'v1.52'})
env={**os.environ,'CARGO_HOME':str(W/'cargo-home'),'CARGO_NET_OFFLINE':'true','PYTHONDONTWRITEBYTECODE':'1'}
cmd=['cargo','metadata','--manifest-path',str(S/'Cargo.toml'),'--format-version','1','--locked','--offline']
result=subprocess.run(cmd,cwd=S,env=env,capture_output=True,text=True);(C/'cargo-metadata.json').write_text(result.stdout);(C/'cargo-metadata.stderr').write_text(result.stderr)
assert result.returncode==0 and H(S/'Cargo.lock')==source['Cargo.lock']
meta=json.loads(result.stdout);pure=json.loads((W/'cargo-metadata.json').read_text())
selection=lambda d:sorted((p['name'],p['version'],p.get('source')or'local')for p in d['packages'])
def features(d):
 names={p['id']:(p['name'],p['version'])for p in d['packages']}
 return sorted((names[n['id']],n['features'])for n in d['resolve']['nodes'])
assert selection(meta)==selection(pure) and features(meta)==features(pure)
save(C/'resolution-gate.json',{'command':cmd,'returncode':result.returncode,'metadata_sha256':H(C/'cargo-metadata.json'),'same_253_selections_as_pure_trial':True,'same_resolved_features_as_pure_trial':True,'lock_unchanged':True})
build=['python3',str(S/'scripts/build_partial_candidate.py'),'--manifest',str(S/'programs/pump-fees/Cargo.toml'),'--program','pump_fees','--artifact-name','pump_fees_candidate.so','--tools-version','v1.44','--output',str(C/'build'),'--extra-input',str(S/'programs/pump-fees/README.md')]
save(C/'build-launch.json',{'command':build,'CARGO_HOME':env['CARGO_HOME'],'network_offline':True})
result=subprocess.run(build,cwd=S,env=env,capture_output=True,text=True);(C/'build-launch.stdout').write_text(result.stdout);(C/'build-launch.stderr').write_text(result.stderr)
save(C/'build-result.json',{'returncode':result.returncode,'source_unchanged':source=={p:H(S/p)for p in source},'runtime_cases':0})
assert result.returncode==0
shutil.copyfile(C/'build/target/sbf-solana-solana/release/pump_fees_candidate.so',C/'unstripped.so')
print(json.dumps(json.loads((C/'build/build-comparison.json').read_text())['comparison'],indent=2))
