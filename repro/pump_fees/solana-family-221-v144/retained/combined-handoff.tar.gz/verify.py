#!/usr/bin/env python3
"""Portable saved-evidence verification; no build, network, or program replay."""
from pathlib import Path
import gzip,hashlib,io,json,runpy,sys,tarfile,tomllib
sys.dont_write_bytecode=True
from static_diagnostic import ELF,compare_window
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((P/n).read_text())
def archive(n):
 data=(P/n).read_bytes()if isinstance(n,str)else n
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:*')as t:
  assert all(m.isfile()and not m.name.startswith('/')and'..'not in Path(m.name).parts for m in t.getmembers())
  return {m.name:t.extractfile(m).read()for m in t.getmembers()}
seal=read('manifest-sha256.json')
assert {str(p.relative_to(P)):H(p.read_bytes())for p in P.rglob('*')if p.is_file()and p!=P/'manifest-sha256.json'and'__pycache__'not in p.parts}==seal
prov=read('provenance.json');digest=H((P/'pump_fees_candidate.so').read_bytes())
assert digest==prov['candidate_sha256'] and (P/'pump_fees_candidate.so').stat().st_size==prov['candidate_bytes']==768072
assert not prov['full_byte_equality']and not prov['inherited_runtime_receipts']and prov['new_unique_cases']==0
pure=archive('pure-graph-trial.tar.gz');pureseal=pure.pop('manifest-sha256.json')
assert H(pureseal)==prov['pure_trial_manifest_sha256']and {p:H(b)for p,b in pure.items()}==json.loads(pureseal)
source=archive('source-snapshot.tar.gz');baseline=archive('social-baseline/source-snapshot.tar.gz')
assert {p:H(b)for p,b in source.items()}==read('source-sha256.json')and len(source)==22
assert {p:H(b)for p,b in baseline.items()}==read('social-baseline/source-sha256.json')
assert sorted(p for p in source if source[p]!=baseline[p])==['Cargo.lock']
assert source['Cargo.lock']==pure['cargo-resolved-Cargo.lock']
build,attempt=read('build-comparison.json'),read('build-attempt.json')
assert build['source_sha256']==attempt['source_sha256']==attempt['source_after_sha256']==read('source-sha256.json')
assert attempt['source_unchanged']and attempt['returncode']==0
assert H(gzip.decompress((P/'build.log.gz').read_bytes()))==build['build_log_sha256']
helpers=archive('build-helper-snapshot.tar.gz');assert{p:H(b)for p,b in helpers.items()}==read('build-helper-sha256.json')
assert (P/'build-helper-snapshot.tar.gz').read_bytes()==pure['build-helper-snapshot.tar.gz']
metadata=json.loads(gzip.decompress((P/'cargo-metadata.json.gz').read_bytes()));oldmeta=json.loads(gzip.decompress(pure['cargo-metadata.json.gz']))
def selections(d):return sorted((p['name'],p['version'],p.get('source')or'local')for p in d['packages'])
def features(d):
 names={p['id']:(p['name'],p['version'])for p in d['packages']}
 return sorted((names[n['id']],n['features'])for n in d['resolve']['nodes'])
assert selections(metadata)==selections(oldmeta)and features(metadata)==features(oldmeta)and len(metadata['packages'])==253
gate=read('resolution-gate.json');assert gate['returncode']==0 and gate['same_253_selections_as_pure_trial']and gate['same_resolved_features_as_pure_trial']and gate['lock_unchanged']
sdk=archive('sbf-sdk-snapshot.tar.gz');assert{p:H(b)for p,b in sdk.items()}==build['sdk_source_sha256']
phase=read('tool-phase-provenance.json');assert phase['compile']['requested_tools_version']=='v1.44'and phase['strip']['sdk_marker']=='platform-tools-v1.52.md'
assert b'version=v1.52'in sdk['scripts/install.sh']and b'platform-tools/llvm/bin/llvm-objcopy --strip-all'in sdk['scripts/strip.sh']
assert phase['strip']['candidate_sha256']==digest and phase['compile']['unstripped_sha256']==H((P/'symbol-source.so').read_bytes())
assert phase['strip']['llvm_objcopy_sha256']==json.loads(pure['tool-phase-provenance.json'])['strip']['llvm_objcopy_sha256']

c=ELF(P/'pump_fees_candidate.so');o=ELF(P/'runtime/evidence/original/pump_fees/deployed.so');s=ELF(P/'symbol-source.so')
assert c.b[c.lo:c.hi]==s.b[s.lo:s.hi]and c.rels==s.rels
static=read('static-gate.json');assert static['candidate_sha256']==digest and static['original_sha256']==H(o.b)==prov['original_sha256']
assert c.b!=o.b and sum(a!=b for a,b in zip(c.b,o.b))==build['comparison']['different_positions_in_shared_length']==419662
def window(row):
 actual=compare_window(c,o,row['candidate_start'],row['original_start'],row['bytes'])
 assert all(row[k]==v for k,v in actual.items())
 assert row['normalized_equal']and row['relocation_pattern_equal']and row['original_entry_bounded']
 assert s.funcs[row['candidate_start']]['length']==row['bytes']
window(static['social_exit']);assert static['social_exit']['bytes']==560 and static['social_exit']['original_start']==405560
assert len(static['pubkey_helpers'])==6
for row in static['pubkey_helpers']:window(row)
formatter=next(r for r in static['pubkey_helpers']if r['name']=='write_as_base58');assert formatter['bytes']==1520
for parent,rows,count in [(static['social_exit'],static['social_direct_calls'],7),(formatter,static['formatter_direct_targets'],10)]:
 assert len(rows)==count
 for row in rows:
  window(row);assert c.calls[parent['candidate_start']+row['call_offset']]==row['candidate_start']
  assert o.calls[parent['original_start']+row['call_offset']]==row['original_start']
assert len(static['social_literals'])==3
for row in static['social_literals']:
 ca=c.lddw(static['social_exit']['candidate_start']+row['offset']);oa=o.lddw(static['social_exit']['original_start']+row['offset'])
 assert ca==row['candidate_address']and oa==row['original_address']
 assert c.b[ca:ca+row['bytes']]==o.b[oa:oa+row['bytes']]and H(c.b[ca:ca+row['bytes']])==row['sha256']
assert len(static['pubkey_source_records'])==9
for row in static['pubkey_source_records']:
 helper=next(h for h in static['pubkey_helpers']if h['name']==row['function'])
 assert c.location(helper['candidate_start']+row['offset'])==row['candidate']
 assert o.location(helper['original_start']+row['offset'])==row['original']
 assert all(row['candidate'][k]==row['original'][k]for k in ['filename','line','column'])
display=next(r for r in static['pubkey_helpers']if r['name']=='Display_Debug_fmt');assert display['raw_equal']and c.calls[display['candidate_start']+24]==formatter['candidate_start']

harness=archive('harness-snapshot.tar.gz');assert len(harness)==46 and {p:H(b)for p,b in harness.items()}==read('harness-source-sha256.json')
inputs=read('runtime-inputs.json');assert len(inputs)==18
for name,d in inputs.items():assert H((P/'runtime'/name).read_bytes())==d
summary=read('runtime-summary.json');assert summary['candidate_sha256']==digest and summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and not summary['mismatches']
assert len(summary['reports'])==10
for row in read('receipt-build-bindings.json'):
 assert row['returncode']==0 and not row['mismatches']and row['executed_candidate_sha256']==digest
 assert row['actual_source_sha256']==read('source-sha256.json')and row['build_report_sha256']==H((P/'build-comparison.json').read_bytes())
 assert H((P/row['published_report']).read_bytes())==row['published_report_sha256']
 raw=gzip.decompress((P/row['published_report']).read_bytes());assert H(raw)==row['report_sha256']
 data=json.loads(raw);assert data['candidate_sha256']==digest and data['original_sha256']==H(o.b)
assert H((P/'verify_saved_runtime.py').read_bytes())==read('runtime-verifier-provenance.json')['sha256']
runtime_result=runpy.run_path(str(P/'verify_saved_runtime.py'))['RESULT']
assert runtime_result==read('runtime-verification-result.json')
print(json.dumps({'verified':True,'sealed_files':len(seal),'source_files':22,'harness_files':46,'runtime_inputs':18,'candidate_sha256':digest,'full_byte_equality':False,'social_exit_bytes':560,'social_direct_calls':7,'social_literals':3,'pubkey_helpers':6,'formatter_direct_targets':10,'pubkey_source_records':9,'runtime':runtime_result},indent=2))
