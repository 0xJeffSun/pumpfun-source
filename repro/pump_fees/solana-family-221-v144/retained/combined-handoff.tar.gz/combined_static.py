#!/usr/bin/env python3
"""Read-only combined-artifact gate before the unchanged runtime suites."""
from pathlib import Path
import hashlib,json,re,sys
sys.dont_write_bytecode=True
from static_diagnostic import ELF,compare_window
W=Path(__file__).resolve().parent;R=W.parents[1];C=W/'combined'
c=ELF(C/'build/artifacts/pump_fees_candidate.so');o=ELF(R/'evidence/original/pump_fees/deployed.so');s=ELF(C/'unstripped.so')
H=lambda b:hashlib.sha256(b).hexdigest()
assert c.b[c.lo:c.hi]==s.b[s.lo:s.hi] and c.rels==s.rels
canonical=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
prior=json.loads((W/'handoff/pubkey-static-diagnostic.json').read_text())
helpers=[]
for old in prior['helpers']:
 names={canonical(n)for n in old['symbol_names']}
 matches=[(a,f)for a,f in s.funcs.items() if any(canonical(n)in names for n in f['names'])]
 assert len(matches)==1,(old['name'],matches)
 a,f=matches[0];assert f['length']==old['bytes']
 row=compare_window(c,o,a,old['original_start'],old['bytes']);row.update(name=old['name'],symbol_names=f['names'])
 assert row['normalized_equal'] and row['relocation_pattern_equal'] and row['original_entry_bounded'];helpers.append(row)
formatter=next(r for r in helpers if r['name']=='write_as_base58')
direct=[]
for pc,target in c.calls.items():
 if not formatter['candidate_start']<=pc<formatter['candidate_start']+formatter['bytes']:continue
 offset=pc-formatter['candidate_start'];other=o.calls[formatter['original_start']+offset];size=s.funcs[target]['length']
 row=compare_window(c,o,target,other,size);row['call_offset']=offset
 assert row['normalized_equal'] and row['relocation_pattern_equal'] and row['original_entry_bounded'];direct.append(row)
assert len(direct)==10
locations=[]
for old in prior['source_location_records']:
 helper=next(r for r in helpers if r['name']==old['function'])
 cr=c.location(helper['candidate_start']+old['offset']);orr=o.location(helper['original_start']+old['offset'])
 assert all(cr[k]==orr[k]for k in ['filename','line','column'])
 locations.append({'function':old['function'],'offset':old['offset'],'candidate':cr,'original':orr})
display=next(r for r in helpers if r['name']=='Display_Debug_fmt');assert display['raw_equal']
assert c.calls[display['candidate_start']+24]==formatter['candidate_start']
social=[(a,f)for a,f in s.funcs.items()if any('ClaimSocialFeePdaV2'in n and'AccountsExit'in n and'4exit'in n for n in f['names'])]
assert len(social)==1
a,f=social[0];assert f['length']==560
exitrow=compare_window(c,o,a,405560,560);assert exitrow['normalized_equal']and exitrow['relocation_pattern_equal']and exitrow['original_entry_bounded']
social_calls=[]
for pc,target in c.calls.items():
 if not a<=pc<a+560:continue
 offset=pc-a;other=o.calls[405560+offset];row=compare_window(c,o,target,other,s.funcs[target]['length']);row['call_offset']=offset
 assert row['normalized_equal']and row['relocation_pattern_equal']and row['original_entry_bounded'];social_calls.append(row)
assert len(social_calls)==7
literals=[]
for offset,length in [(40,32),(320,14),(504,10)]:
 ca,oa=c.lddw(a+offset),o.lddw(405560+offset);cb,ob=c.b[ca:ca+length],o.b[oa:oa+length];assert cb==ob
 literals.append({'offset':offset,'bytes':length,'candidate_address':ca,'original_address':oa,'sha256':H(cb),'equal':True})
result={'scope':'Complete original social-v2 exit, seven direct calls and three literals, plus six Pubkey helpers, ten formatter direct targets and nine source locations. In-memory diagnostic normalization only; no whole-program or transitive-data identity claim.','candidate_sha256':H(c.b),'original_sha256':H(o.b),'symbols_sha256':H(s.b),'full_byte_equality':False,'social_exit':exitrow,'social_direct_calls':social_calls,'social_literals':literals,'pubkey_helpers':helpers,'formatter_direct_targets':direct,'pubkey_source_records':locations,'all_static_gates_passed':True,'runtime_cases_at_gate':0}
(C/'static-gate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'candidate_sha256':result['candidate_sha256'],'social_exit_bytes':560,'social_calls':7,'social_literals':3,'pubkey_helpers':6,'formatter_calls':10,'pubkey_source_records':9,'all_static_gates_passed':True},indent=2))
