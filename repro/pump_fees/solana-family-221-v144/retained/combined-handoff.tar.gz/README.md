# Combined Fees social-layout and dependency-family handoff

The single combined scratch candidate passes the complete social-account exit proof, the Pubkey dependency proof, all **17,441 existing differential comparisons**, and the existing **ten-step donation sequence**. No new handlers or unique cases are claimed. Every receipt was freshly produced by this candidate using a frozen copy of the prior 46-file harness and 18 runtime inputs.

Candidate: **768,072 bytes**, SHA-256 `e501ca2c744373e5653a5ac7e25a3fd20f6058765808b888c3605fd03adba60f`. Full captured-program identity remains **false**: 419,662 differing shared positions and a −180,872-byte length difference.

The source snapshot exactly retains all 22 inputs from `work/fees-social-v2-box-recovery/main-build-01`, except the proven eight-package `Cargo.lock` replacement. `Cargo.lock.patch` is the complete additional integration change to that accepted social source. Actual offline locked Cargo resolution confirms the same 253 package selections and feature sets as the pure dependency trial. The clean Darwin build uses **v1.44 compilation and the unchanged SDK's v1.52 stripping**, recorded separately. There were no compiler, flag, source, or binary variants in this combination.

The complete original 560-byte `ClaimSocialFeePdaV2` exit, all seven direct calls, and three consumed literals match under explicit diagnostic normalization. Six complete Pubkey helpers match, including the 1,520-byte base58 formatter and all ten direct call targets. Nine pointed source records match, including `find_program_address` at `src/lib.rs:612:32` and `create_program_address` at `src/lib.rs:131:18`. The Display/Debug wrapper is raw-byte identical. Addresses, hashes, relocation patterns, and exact record contents are retained in `static-gate.json`; no executable was changed by comparison.

The complete earlier pure graph trial remains sealed inside `pure-graph-trial.tar.gz`, including its negative whole-file result, missing-helper pre-build failure, official release-lock witness, all eight selected archives, dependency inventories, actual Cargo metadata and build provenance. The untouched saved runtime verifier is copied from the accepted social package and independently rechecks assertions and recorded signatures. Runtime receipts remain specific to this combined scratch ELF; a later main build needs exact whole-file identity or a fresh replay.

Verify the standalone package without network, compilation, or program execution:

```sh
python3 work/fees-family-221-trial/combined/handoff/verify.py
```

The verifier also works from a copied directory with `solders` installed. Main source, central status, documentation, workflows, staging and commits were not changed by this lane. This handoff does not identify a unique historical lockfile/compiler, complete parser equivalence, all transitive data, or complete original program behavior.
