"""Read-only feasibility assessment of one source-attributed Pubkey candidate."""
from pathlib import Path
import gzip,hashlib,json,shutil,struct,sys,tarfile,tomllib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'work/fees-v144-cargo-home/registry'
SOURCE=BASE/'src/index.crates.io-1949cf8c6b5b557f';CACHE=BASE/'cache/index.crates.io-1949cf8c6b5b557f'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
lock=tomllib.loads((R/'Cargo.lock').read_text());packages=lock['package'];byname={}
for row in packages:byname.setdefault(row['name'],[]).append(row)
snap=W/'inputs';snap.mkdir(exist_ok=True)
records={}
def snapshot(pkg):
    key=pkg['name']+'-'+pkg['version']
    if key in records:return tomllib.loads((snap/key/'Cargo.toml').read_text())
    archive=CACHE/(key+'.crate');data=archive.read_bytes();assert sha(data)==pkg['checksum'],key
    target=snap/key;target.mkdir(exist_ok=True)
    with tarfile.open(archive)as tar:
        meta=tar.extractfile(key+'/Cargo.toml').read();assert meta==(SOURCE/key/'Cargo.toml').read_bytes()
        (target/'Cargo.toml').write_bytes(meta)
        members={m.name for m in tar.getmembers()}
        if key+'/.cargo_vcs_info.json'in members:
            (target/'.cargo_vcs_info.json').write_bytes(tar.extractfile(key+'/.cargo_vcs_info.json').read())
    records[key]={'package':pkg['name'],'version':pkg['version'],'archive_sha256':sha(data),
                  'archive_bytes':len(data),'Cargo.toml_sha256':sha(meta),'lock_checksum_equal':True}
    return tomllib.loads(meta.decode())
def deps(manifest):
    rows=[]
    for kind in ['dependencies','build-dependencies','dev-dependencies']:
        for alias,spec in manifest.get(kind,{}).items():rows.append(('unconditional',kind,alias,{'version':spec}if isinstance(spec,str)else spec))
    for target,entry in manifest.get('target',{}).items():
        for kind in ['dependencies','build-dependencies','dev-dependencies']:
            for alias,spec in entry.get(kind,{}).items():rows.append((target,kind,alias,{'version':spec}if isinstance(spec,str)else spec))
    return rows
def allows(version,requirement):
    # Only explicit caret-compatible forms actually encountered in this bounded record.
    text=requirement.removeprefix('^');parts=tuple(int(p)for p in text.split('.'));low=parts+(0,)*(3-len(parts))
    high=(low[0]+1,0,0)if low[0]else((0,low[1]+1,0)if low[1]else(0,0,low[2]+1))
    return low<=tuple(int(p)for p in version.split('.'))<high
incoming=[]
for pkg in packages:
    if not any(d.split()[0]=='solana-pubkey'for d in pkg.get('dependencies',[])):continue
    meta=snapshot(pkg);edges=[]
    for target,kind,alias,spec in deps(meta):
        if spec.get('package',alias)=='solana-pubkey':
            edges.append({'target':target,'kind':kind,'alias':alias,'specification':spec,'allows_2_2_1':allows('2.2.1',spec['version'])})
    forwards={name:[item for item in items if 'solana-pubkey/'in item]for name,items in meta.get('features',{}).items()}
    incoming.append({'package':pkg['name'],'version':pkg['version'],'edges':edges,
                     'feature_forwarding':{k:v for k,v in forwards.items()if v},
                     'all_recorded_edges_allow_2_2_1':all(e['allows_2_2_1']for e in edges)})
assert len(incoming)==33
blockers=[row for row in incoming if not row['all_recorded_edges_allow_2_2_1']]
assert [(r['package'],r['version'])for r in blockers]==[('solana-zk-sdk','2.3.13')]
zk_incoming=[]
for pkg in packages:
    if not any(d.split()[0]=='solana-zk-sdk'for d in pkg.get('dependencies',[])):continue
    meta=snapshot(pkg);edges=[{'target':t,'kind':k,'alias':a,'specification':s}for t,k,a,s in deps(meta)if s.get('package',a)=='solana-zk-sdk']
    zk_incoming.append({'package':pkg['name'],'version':pkg['version'],'edges':edges})
assert len(zk_incoming)==6
old_dir=R/'work/pubkey-source-coordinate-attribution/inputs/solana-pubkey-2.2.1'
new_dir=R/'work/pubkey-source-coordinate-attribution/inputs/solana-pubkey-2.4.0'
for version,source in [('2.2.1',old_dir),('2.4.0',new_dir)]:
    shutil.copytree(source,snap/('pubkey-source-'+version))
old=tomllib.loads((old_dir/'Cargo.toml').read_text());new=tomllib.loads((new_dir/'Cargo.toml').read_text())
assert old['features']==new['features']
current=byname['solana-pubkey'][0];outgoing=[]
for target,kind,alias,spec in deps(old):
    if kind!='dependencies':continue
    depname=spec.get('package',alias)
    # Frozen enabled graph excludes optional arbitrary/rand/frozen-abi; retain those as unactivated, not missing.
    existing=[pkg for pkg in byname.get(depname,[])if allows(pkg['version'],spec['version'])]
    outgoing.append({'target':target,'alias':alias,'package':depname,'specification':spec,
                     'compatible_locked_versions':[p['version']for p in existing]})
    if existing and depname in ['bs58','five8','five8_const','num-traits','wasm-bindgen']:
        for pkg in existing:snapshot(pkg)
for name in ['anchor-spl','anchor-lang']:snapshot(byname[name][0])
for name in ['Cargo.toml','Cargo.lock','programs/pump-fees/Cargo.toml']:
    dst=snap/'workspace'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,dst)
build_root=R/'work/fees-readme-provenance/main-build'
assert sha((build_root/'artifacts/pump_fees_candidate.so').read_bytes())=='a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa'
fingerprints={}
for name in ['solana-pubkey','solana-zk-sdk','bs58']:
    matches=list((build_root/'target/sbf-solana-solana/release/.fingerprint').glob(name+'-*/lib-'+name.replace('-','_')+'.json'))
    assert len(matches)==1,(name,matches)
    source=matches[0];shutil.copyfile(source,snap/(name+'-fingerprint.json'));fingerprints[name]=read(source)
assert set(json.loads(fingerprints['solana-pubkey']['features']))=={'borsh','bytemuck','curve25519','default','serde','sha2','std'}
catalog_path=R/'work/fees-update-admin-closure/inputs/accepted-functions.json.gz'
shutil.copyfile(catalog_path,snap/'accepted-functions.json.gz');catalog=json.loads(gzip.decompress(catalog_path.read_bytes()))
assert catalog['candidate']['sha256']=='a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa'
pubkey_rows=[row for row in catalog['functions']if any('solana_pubkey'in name for name in row['names'])]
sys.path.insert(0,str(R/'repro/pump_fees/framework-matching'));from elf_reader import Elf
original=Elf(R/'evidence/original/pump_fees/deployed.so');candidate=Elf(R/'repro/pump_fees/readme-provenance-v144/pump_fees_candidate.so')
reverse={}
for row in catalog['functions']:
    for match in row['matches']:
        if match['entry_bounded']:reverse.setdefault(match['start'],[]).extend(row['names'])
formatter={'candidate':{'wrapper_start':648144,'call_pc':648168,'formatter_start':642632,'formatter_bytes':5512},
           'original':{'wrapper_start':754592,'call_pc':754616,'formatter_start':753072,'formatter_bytes':1520}}
for role,elf in [('original',original),('candidate',candidate)]:
    row=formatter[role];at=row['call_pc'];imm=struct.unpack_from('<i',elf.b,at+4)[0]
    assert elf.b[at:at+2]==b'\x85\x10'and at+8+imm*8==row['formatter_start']
    row['raw_call_immediate']=imm;start=row['formatter_start'];size=row['formatter_bytes']
    assert elf.entries[elf.entries.index(start)+1]==start+size
    raw=elf.b[start:start+size];row['raw_sha256']=sha(raw);(snap/(role+'-formatter.bin')).write_bytes(raw)
    row['calls']=[{**call,'matched_candidate_names':reverse.get(call['target'],[])}for call in elf.callsites(start,size)]
assert any(call['offset']==904 and call['target']==784368 and any('from_utf8' in n for n in call['matched_candidate_names'])for call in formatter['original']['calls'])
# The public 2.2.1 archive's own lock has no zk-sdk package: it cannot supply the missing graph pin.
archive=R/'work/pubkey-source-coordinate-attribution/inputs/solana-pubkey-2.2.1.crate'
with tarfile.open(archive)as tar:published_lock=tar.extractfile('solana-pubkey-2.2.1/Cargo.lock').read()
(snap/'pubkey-2.2.1-published-Cargo.lock').write_bytes(published_lock)
assert not any(p['name']=='solana-zk-sdk'for p in tomllib.loads(published_lock.decode())['package'])
report={'scope':'Static one-candidate graph feasibility. No Cargo resolve/update, source/lock edits, downloads, builds, version enumeration or runtime tests.',
        'frozen_lock_sha256':sha((R/'Cargo.lock').read_bytes()),'incoming_pubkey_packages':incoming,
        'blocking_packages':blockers,'incoming_zk_sdk_packages':zk_incoming,
        'active_sbf_pubkey_features':json.loads(fingerprints['solana-pubkey']['features']),
        'pubkey_feature_definitions_identical':True,'pubkey_221_outgoing_dependency_checks':outgoing,
        'required_known_changes':['Replace solana-pubkey 2.4.0/checksum with 2.2.1/40db1ff5a0f8aea2c158d78ab5f2cf897848964251d1df42fef78efd3c85b863.',
                                  'Replace its five8 dependency edge with already-locked bs58 0.5.1; no new bs58 features requested.',
                                  'Select a different supported solana-zk-sdk source whose Pubkey constraint permits 2.2.1, or change that source requirement; neither is authorized or identified here.',
                                  'Reconstruct any transitive changes required by that as-yet-unidentified SDK selection before a concrete compatible lock can be claimed.'],
        'not_required_by_pubkey_edge_only':['Remove five8/five8_core: other locked solana-hash and solana-signature nodes still use five8.',
                                           'Change Pubkey feature names: all seven observed SBF features exist with identical definitions in 2.2.1.'],
        'zk_sdk_source_provenance':read(snap/'solana-zk-sdk-2.3.13/.cargo_vcs_info.json'),
        'grounded_compatible_zk_sdk_version_identified':False,'published_pubkey_lock_has_zk_sdk':False,
        'pubkey_symbol_rows':pubkey_rows,'formatter_evidence':formatter,
        'one_node_replacement_satisfies_frozen_graph':False,
        'historical_recipe_proven':False,'contradiction_found_in_reviewed_original_bodies':False,
        'constraints':'No additional SDK version was guessed or enumerated. Existing catalog covers emitted candidate symbols only; absence of a contradiction is not proof of whole-crate equivalence.'}
(W/'feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
(W/'crate-metadata-provenance.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'incoming_pubkey_packages':len(incoming),'allowing_packages':32,'blocker':'solana-zk-sdk 2.3.13 requires ^2.4.0',
                  'incoming_zk_sdk_packages':len(zk_incoming),'same_pubkey_feature_definitions':True,
                  'recorded_pubkey_symbol_rows':len(pubkey_rows),'compatible_sdk_version_identified':False,'runtime_tests':0},indent=2))
