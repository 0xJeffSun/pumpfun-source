from pathlib import Path
import gzip,hashlib,json,struct,tomllib
W=Path(__file__).resolve().parent;R=W.parents[1];I=W/'inputs'
H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
seal=J(W/'manifest-sha256.json')
assert set(seal)=={str(p.relative_to(W))for p in W.rglob('*')if p.is_file()and p.name!='manifest-sha256.json'}
for name,digest in seal.items():assert H((W/name).read_bytes())==digest,name
f=J(W/'feasibility.json');r=J(W/'release-provenance.json');p=J(W/'crate-metadata-provenance.json')
assert H((I/'workspace/Cargo.lock').read_bytes())==f['frozen_lock_sha256']
assert len(f['incoming_pubkey_packages'])==33
assert [(x['package'],x['version'])for x in f['blocking_packages']]==[('solana-zk-sdk','2.3.13')]
assert len(f['incoming_zk_sdk_packages'])==6
for key,row in p.items():assert H((I/key/'Cargo.toml').read_bytes())==row['Cargo.toml_sha256']
old=tomllib.loads((I/'pubkey-source-2.2.1/Cargo.toml').read_text());new=tomllib.loads((I/'pubkey-source-2.4.0/Cargo.toml').read_text());assert old['features']==new['features']
zk=tomllib.loads((I/'solana-zk-sdk-2.3.13/Cargo.toml').read_text());assert zk['dependencies']['solana-pubkey']['version']=='2.4.0'
release=tomllib.loads((I/'spl-pod-0.5.1/Cargo.lock').read_text())['package'];selected={x['name']:x for x in release}
assert selected['solana-pubkey']['version']=='2.2.1'and selected['solana-zk-sdk']['version']=='2.2.0'
index=(I/'zk-sdk-registry-index-cache.bin').read_bytes();exact=[x for x in index.split(b'\0')if x.startswith(b'{')and json.loads(x).get('vers')=='2.2.0'];assert len(exact)==1
assert exact[0]+b'\n'==(I/'zk-sdk-2.2.0-registry-index-record.json').read_bytes();sdk=json.loads(exact[0]);assert sdk['cksum']==selected['solana-zk-sdk']['checksum']
assert H(index)==r['sdk_candidate']['registry_cache_sha256']
assert {x['parent']for x in r['remaining_frozen_parent_conflicts']}=={'solana-program','solana-sysvar','solana-vote-interface'}
for x in r['remaining_frozen_parent_conflicts']:
 m=tomllib.loads((I/(x['parent']+'-'+x['parent_version'])/'Cargo.toml').read_text());s=m if x['target']=='unconditional'else m['target'][x['target']]
 assert s['dependencies'][x['dependency']]==x['specification']and x['specification']['version']=='2.3.0'
for role,path,digest in [('original','evidence/original/pump_fees/deployed.so','4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'),('candidate','repro/pump_fees/readme-provenance-v144/pump_fees_candidate.so','a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa')]:
 b=(R/path).read_bytes();assert H(b)==digest;e=f['formatter_evidence'][role];start=e['formatter_start'];body=b[start:start+e['formatter_bytes']]
 assert body==(I/(role+'-formatter.bin')).read_bytes()and H(body)==e['raw_sha256']
 pc=e['call_pc'];imm=struct.unpack_from('<i',b,pc+4)[0];assert b[pc:pc+2]==b'\x85\x10'and imm==e['raw_call_immediate']and pc+8+imm*8==start
 for call in e['calls']:
  pc=start+call['offset'];assert b[pc:pc+2]==b'\x85\x10'and pc+8+struct.unpack_from('<i',b,pc+4)[0]*8==call['target']
assert not r['complete_compatible_lock_identified']and not r['historical_deployment_recipe_proven']
print(json.dumps({'sealed_files_verified':len(seal),'incoming_pubkey_packages':33,'sdk_release_lock_lead':'2.2.0','remaining_instruction_parent_conflicts':3,'complete_compatible_lock_proven':False,'raw_formatter_windows_verified':2,'builds':0,'runtime_tests':0},indent=2))
