"""Read only exact current release archives and one already-attributed SDK index record."""
from pathlib import Path
import hashlib,json,tarfile,tomllib,shutil
W=Path(__file__).resolve().parent;R=W.parents[1];I=W/'inputs'
B=R/'work/fees-v144-cargo-home/registry';C=B/'cache/index.crates.io-1949cf8c6b5b557f'
S=B/'src/index.crates.io-1949cf8c6b5b557f';J=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
lock=tomllib.loads((I/'workspace/Cargo.lock').read_text())['package'];by={p['name']:p for p in lock}
provenance=J(W/'crate-metadata-provenance.json')
keys=['anchor-lang-0.31.1','anchor-spl-0.31.1','spl-token-2022-6.0.0','spl-pod-0.5.1','spl-elgamal-registry-0.1.1','spl-token-confidential-transfer-ciphertext-arithmetic-0.2.1','spl-token-confidential-transfer-proof-extraction-0.2.1','spl-token-confidential-transfer-proof-generation-0.2.0','solana-zk-sdk-2.3.13']
releases=[]
for key in keys:
 data=(C/(key+'.crate')).read_bytes();assert H(data)==provenance[key]['archive_sha256']
 with tarfile.open(C/(key+'.crate')) as t:
  path=key+'/Cargo.lock';has=path in t.getnames();row={'archive':key+'.crate','archive_sha256':H(data),'published_lock_present':has}
  if has:
   b=t.extractfile(path).read();dest=I/key/'Cargo.lock';dest.write_bytes(b);pkgs=tomllib.loads(b.decode())['package']
   row.update(lock_sha256=H(b),lock_package_count=len(pkgs),selected_packages=[p for p in pkgs if p['name'] in ['solana-program','solana-pubkey','solana-zk-sdk','solana-instruction','solana-sysvar','solana-vote-interface','solana-signature']])
  releases.append(row)
index=B/'index/index.crates.io-1949cf8c6b5b557f/.cache/so/la/solana-zk-sdk';raw=index.read_bytes()
# Match exactly the release-lock evidenced version. Other index versions are not inspected.
exact=[b for b in raw.split(b'\0') if b.startswith(b'{') and json.loads(b).get('vers')=='2.2.0'];assert len(exact)==1
sdk=json.loads(exact[0]);assert sdk['cksum']=='26f66acae4f01a718825ae0201ea0a05ae3c9a3afb27a7eed6f0803b96da639b'
(I/'zk-sdk-2.2.0-registry-index-record.json').write_bytes(exact[0]+b'\n')
(I/'zk-sdk-registry-index-cache.bin').write_bytes(raw)
def allows(v,r):
 if r.startswith('='):return v==r[1:]
 nums=tuple(map(int,r.removeprefix('^').split('.')));low=nums+(0,)*(3-len(nums));high=(low[0]+1,0,0)if low[0]else((0,low[1]+1,0)if low[1]else(0,0,low[2]+1))
 return low<=tuple(map(int,v.split('.')))<high
pins={d['name']:d['req'][1:]for d in sdk['deps']if d['kind']=='normal'and d['req'].startswith('=')}
checks=[];parents=[]
for name,version in pins.items():
 checks.append({'name':name,'required_version':version,'current_version':by[name]['version'],'version_change_required':version!=by[name]['version']})
 for pkg in lock:
  if not any(x.split()[0]==name for x in pkg.get('dependencies',[])):continue
  key=pkg['name']+'-'+pkg['version'];a=C/(key+'.crate');b=a.read_bytes();assert H(b)==pkg['checksum']
  with tarfile.open(a)as t:meta=t.extractfile(key+'/Cargo.toml').read()
  assert meta==(S/key/'Cargo.toml').read_bytes();dest=I/key/'Cargo.toml';dest.parent.mkdir(exist_ok=True);dest.write_bytes(meta)
  provenance.setdefault(key,{'package':pkg['name'],'version':pkg['version'],'archive_sha256':H(b),'archive_bytes':len(b),'Cargo.toml_sha256':H(meta),'lock_checksum_equal':True})
  m=tomllib.loads(meta.decode())
  for target,section in [('unconditional',m)]+list(m.get('target',{}).items()):
   for alias,s in section.get('dependencies',{}).items():
    if isinstance(s,str):s={'version':s}
    if s.get('package',alias)==name:parents.append({'parent':pkg['name'],'parent_version':pkg['version'],'dependency':name,'target':target,'specification':s,'allows_required_pin':allows(version,s['version'])})
remaining=[x for x in parents if not x['allows_required_pin']and x['parent']!='solana-zk-sdk']
assert {x['parent']for x in remaining}=={'solana-program','solana-sysvar','solana-vote-interface'}
archive_paths=[]
for base in [B,Path.home()/'.cargo/registry']:
 archive_paths.extend(str(p)for pat in ['cache/*/solana-zk-sdk-2.2.0.crate','src/*/solana-zk-sdk-2.2.0/Cargo.toml']for p in base.glob(pat))
assert not archive_paths
report={'scope':'Current cached official release archives plus exact SDK version directly identified by spl-pod 0.5.1 published Cargo.lock; no version enumeration, network or Cargo resolution.',
 'release_lock_inventory':releases,'sdk_candidate':{'version':'2.2.0','archive_checksum':sdk['cksum'],'pubtime':sdk['pubtime'],'registry_cache_sha256':H(raw),'record_sha256':H(exact[0]+b'\n'),'features':sdk['features'],'source_archive_or_manifest_present_in_checked_caches':False},
 'sdk_exact_normal_pins':checks,'current_parent_constraints_for_exact_pins':parents,'remaining_frozen_parent_conflicts':remaining,
 'grounded_source_family':True,'complete_compatible_lock_identified':False,'historical_deployment_recipe_proven':False,
 'conclusion':'The released SPL lock grounds zk-sdk 2.2.0 with Pubkey 2.2.1. SDK pins instruction and signature to 2.2.1 too; retained solana-program 2.3.0, solana-sysvar 2.3.0 and solana-vote-interface 2.2.6 require instruction ^2.3.0. A consistent unified graph needs additional supported source selections; none selected or resolved here.'}
(W/'release-provenance.json').write_text(json.dumps(report,indent=2)+'\n');(W/'crate-metadata-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'release_locks_inspected':len(releases),'sdk_candidate':'2.2.0','remaining_conflicting_parent_packages':sorted({x['parent']for x in remaining}),'complete_compatible_lock_identified':False},indent=2))
