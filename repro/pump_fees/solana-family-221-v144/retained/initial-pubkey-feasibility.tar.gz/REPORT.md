# Pubkey 2.2.1 graph feasibility — static evidence

The frozen Fees dependency graph cannot accept an isolated Pubkey 2.4.0 → 2.2.1 replacement. A retained official SPL release lock now grounds **zk-sdk 2.2.0** as a compatible source-family lead, but that choice also requires Instruction and Signature 2.2.1 and conflicts with three other current package selections. No complete compatible lock or unique historical deployment recipe has been established.

This report reads cached public archives, registry metadata, accepted build fingerprints and existing static function evidence. It performs no downloads, Cargo resolution/update, source/lock edits, builds, runtime tests, binary mutation, or version enumeration. `feasibility.json` records the initial graph/body assessment; `release-provenance.json` records the subsequent exact release-lock lead and supersedes its initial “no SDK version identified” observation.

## Frozen graph and blocker

Workspace `Cargo.lock` SHA256: `5d2be052125503747b332e88bd9a98c6134e9f8fc2009a401a58f9f554fd8ed8`.
Fees selects Anchor lang/spl exactly 0.31.1. Anchor SPL enables token, token_2022 and associated_token. The accepted SBF fingerprints confirm Pubkey 2.4.0 and zk-sdk 2.3.13 were built; this is not merely unused host lock metadata.

All 33 locked packages with Pubkey dependency edges were checked against their checksum-verified cached release manifests. Thirty-two permit 2.2.1. **zk-sdk 2.3.13 alone requires Pubkey ^2.4.0**, both unconditionally and for non-wasm targets. Its empty feature table offers no feature switch to remove this edge. The active path is Fees → Anchor SPL token_2022 → SPL Token-2022 6.0.0 → zk-sdk. SPL Token-2022's SDK dependency is unconditional; disabling zk-ops would not remove it.

Six current packages depend on zk-sdk. Five accept ^2.1.0; SPL POD 0.5.1 accepts ^2.2.0. Their common version range contains 2.2.0. The exact constraints and target/feature annotations are preserved in the JSON inventories, not inferred from release numbering.

## Exact retained release evidence

Nine current cached official crate archives were checked for published Cargo.lock files. Anchor lang 0.31.1's lock pairs Program/Pubkey 2.1.0. Anchor SPL 0.31.1 additionally pairs zk-sdk 2.1.0. SPL Token-2022 6.0.0, ElGamal registry 0.1.1 and the three confidential-transfer releases contain no published lock; this means archive absence, not no upstream history.

**SPL POD 0.5.1's published lock** SHA256 `a4bb7419e5934d0bd08bec57db4d8f5bbfa5879fca4f785d860e798fea3ad5f3` pairs:

| Package | Exact selected version | Registry checksum |
| --- | --- | --- |
| solana-pubkey | 2.2.1 | `40db1ff5a0f8aea2c158d78ab5f2cf897848964251d1df42fef78efd3c85b863` |
| solana-zk-sdk | 2.2.0 | `26f66acae4f01a718825ae0201ea0a05ae3c9a3afb27a7eed6f0803b96da639b` |

The exact cached crates.io index record for SDK 2.2.0 agrees on the checksum, records publication `2025-02-15T06:56:29Z`, and pins Pubkey **=2.2.1**. No other SDK version was inspected. Its archive/source is absent from the workspace inventory and the checked standard Cargo cache, so the SDK source itself has not been inspected here. The full pre-existing index cache and exact extracted record are retained for verification.

SDK 2.2.0 also pins eight normal Solana dependencies to =2.2.1. Five already have that frozen version (derivation-path, sdk-ids, seed-derivable, seed-phrase, signer). Three would change:

| Package | Frozen selection | Required selection |
| --- | --- | --- |
| solana-instruction | 2.3.3 | 2.2.1 |
| solana-pubkey | 2.4.0 | 2.2.1 |
| solana-signature | 2.3.0 | 2.2.1 |

Current **solana-program 2.3.0**, **solana-sysvar 2.3.0**, and **solana-vote-interface 2.2.6** each require Instruction ^2.3.0. These current parent selections therefore also require reconstruction to support a unified Instruction 2.2.1 graph. No replacement for them was guessed or selected. A second disconnected Pubkey/Instruction copy would not establish the proposed unified source graph or cross-crate type compatibility. This report does not claim a resolver result.

## Other required edge/feature changes

Pubkey 2.2.1 replaces the current five8 formatter dependency edge with bs58 ^0.5.1 (default features false). bs58 0.5.1 is already locked and built; solana-program requests its alloc feature. five8 and five8_core cannot simply be deleted from the current lock because solana-hash and solana-signature also use them; Signature's future source selection may alter that statement but was not resolved. five8_const remains a Pubkey dependency.

The seven recorded SBF Pubkey features are borsh, bytemuck, curve25519, default, serde, sha2 and std. Their definitions are identical in 2.2.1 and 2.4.0. Other activated Pubkey direct constraints can use already-locked versions. SDK 2.2.0's index records default features true for its Pubkey dependency, whereas current SDK 2.3.13 uses false; the accepted Pubkey feature union already includes default. This does not establish the entire reconstructed graph's feature union. Exact SDK transitive and feature effects remain to be checked after a supported complete graph is identified.

## Original body evidence

The previously published source-coordinate package identifies the old Pubkey source family: original create_program_address error conversion reaches line 131:18 and find_program_address line 612:32, matching the archived 2.2.1 source, versus 134:18 and 802:32 in frozen 2.4.0. These lines alone do not identify a unique original version.

The current accepted function catalog contains 11 Pubkey-named rows. Helpers create_with_seed, find_program_address, create_program_address, log, serialization and derive/error formatting have normalized or raw correspondences; no reviewed body contradicts the 2.2.1 source-family lead. Generic BTreeSet drop is not a version fingerprint. from_str_const has multiple non-entry-bounded hits and is weak evidence. The Display wrapper match is only a wrapper match: its called formatter differs.

| Body | Original address / bytes | Current candidate address / bytes |
| --- | --- | --- |
| Display/Debug wrapper | 754592 / 40 | 648144 / 40 |
| write_as_base58 direct target | 753072 / 1520 | 642632 / 5512 |

The wrapper's raw call at original 754616 has immediate -194; current 648168 has -693. Applying `pc + 8 + immediate * 8` gives the targets above. Original formatter offset 904 calls 784368, independently matched to `core::str::converts::from_utf8`. Pubkey 2.2.1 formats through bs58 and checked from_utf8; 2.4.0 uses five8 and from_utf8_unchecked. That original checked UTF-8 call supports the older source shape. It does not prove an exact 2.2.1 compilation, nor transitively validate unknown formatter callees.

Original Fees SHA256: `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`.
Accepted candidate SHA256: `a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa`.

## Result and verification

This is a grounded graph reconstruction lead, not approval or a recipe for a one-node downgrade. A future coordinated proposal would need supported selections for the remaining Instruction parent conflicts, complete feature/transitive resolution, source archive bindings and independent original/candidate validation. The separate unchanged-source Linux build remains independent.

Run `python3 work/pubkey-221-graph-feasibility/verify.py`. It verifies every sealed file, frozen constraints, release/index association, exact pin conflicts, feature definitions and original/candidate raw formatter windows/calls. The analysis scripts describe acquisition from existing caches; the verifier needs only the sealed inputs and repository ELF references.
