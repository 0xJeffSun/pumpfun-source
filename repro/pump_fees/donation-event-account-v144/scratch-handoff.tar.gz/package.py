#!/usr/bin/env python3
from pathlib import Path
import difflib,gzip,hashlib,importlib.metadata,json,shutil,sys,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'handoff';B=W/'build-01';prior=R/'repro/pump_fees/sharing-module-v144'
H=lambda b:hashlib.sha256(b).hexdigest()
P.mkdir(exist_ok=False)
def copy(src,n):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(src.read_bytes())
def save(n,data):(P/n).write_text(json.dumps(data,indent=2)+'\n')
summary=json.loads((W/'runtime/summary.json').read_text());assert summary['comparison_receipts']==17441 and not summary['mismatches']and not summary['orchestration_failures']
names=['baseline-source-sha256.json','source-sha256.json','baseline-source-snapshot.tar.gz','source-snapshot.tar.gz','source.patch','build-helper-sha256.json','build-helper-snapshot.tar.gz','tool-phase-provenance.json','proposal-verification.json','prebuild-manifest-sha256.json','build-launch.json','build-result.json','prepare-result.json','static-gate.json','frozen-runner-inputs.json','run_regressions.py','prior-run-regressions.py','build_once.py','baseline-codecs.json','candidate-codecs.json','inspect_codecs.py','elf_reader.py','baseline-full-comparison.json','strip-section-comparison.json','accepted-inline-static-gate.json','accepted-inline-symbols.so','retained-static-gate.json','verify_retained_static.py','sharing-closure-proof.json','inspect_sharing_closure.py','build-launch.stdout','build-launch.stderr','caller-static-proof.json','fresh-instruction-ledger.json','fresh-data-reference-ledger.json','inspect_caller.py','verify_saved_runtime.py','package.py']
for n in names:copy(W/n,n)
shutil.copytree(W/'proposal',P/'proposal');shutil.copytree(W/'analysis-history',P/'analysis-history')
with tarfile.open(P/'prebuild-snapshot.tar.gz','w:gz')as t:
 for n,h in json.loads((W/'prebuild-manifest-sha256.json').read_text()).items():
  src=W/n;assert H(src.read_bytes())==h;t.add(src,arcname=n,recursive=False)
for n in ['build-attempt.json','build-comparison.json']:copy(B/n,n)
(P/'build.log.gz').write_bytes(gzip.compress((B/'build.log').read_bytes(),mtime=0));copy(W/'unstripped.so','symbols.so');copy(B/'artifacts/pump_fees_candidate.so','pump_fees_candidate.so')
copy(W/'runtime/summary.json','runtime-summary.json');copy(W/'runtime/progress.json','runtime-progress.json')
for n in ['harness-source-sha256.json','runtime-inputs.json','harness-origin-map.json','published-harness-sha256.json']:copy(prior/n,n)
harness=json.loads((P/'harness-source-sha256.json').read_text());runtime=json.loads((P/'runtime-inputs.json').read_text())
for n,h in runtime.items():
 src=W/'runner-repo'/n;assert H(src.read_bytes())==h;copy(src,'runtime/'+n)
with tarfile.open(P/'harness-snapshot.tar.gz','w:gz')as t:
 for n,h in harness.items():
  src=W/'runner-repo'/n;assert H(src.read_bytes())==h;t.add(src,arcname=n,recursive=False)
with tarfile.open(P/'sbf-sdk-snapshot.tar.gz','w:gz')as t:
 for n,h in json.loads((P/'build-comparison.json').read_text())['sdk_source_sha256'].items():
  src=B/'sdk'/n;assert H(src.read_bytes())==h;t.add(src,arcname=n,recursive=False)
receipts=[]
for row in summary['reports']:
 n=row['name'];raw=(W/'runtime'/(n+'.json')).read_bytes();compressed=gzip.compress(raw,mtime=0);(P/(n+'.json.gz')).write_bytes(compressed);copy(W/'runtime'/(n+'.log'),'runtime-logs/'+n+'.log');receipts.append({**row,'saved_report':n+'.json.gz','saved_report_sha256':H(compressed),'raw_report_sha256':H(raw)})
save('receipt-build-bindings.json',receipts)
old=(W/'inspect_sharing_closure.py').read_text();new=old.replace("W/'build-01/artifacts/pump_fees_candidate.so'","W/'pump_fees_candidate.so'").replace("W/'unstripped.so'","W/'symbols.so'")
copy(W/'inspect_sharing_closure.py','executed-inspect_sharing_closure.py');(P/'inspect_sharing_closure.py').write_text(new)
(P/'inspect_sharing_closure.py.portability.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='executed-inspect_sharing_closure.py',tofile='inspect_sharing_closure.py')))
import solders
save('runtime-engine.json',{'python':sys.version,'python_executable':sys.executable,'solders_version':importlib.metadata.version('solders'),'native_extensions':{str(p):{'sha256':H(p.read_bytes()),'bytes':p.stat().st_size}for p in Path(solders.__file__).parent.rglob('*.so')},'execution':'Unchanged local LiteSVM harnesses; no network writes or Surfpool processes.'})
save('provenance.json',{'scope':'One fixed CreateDonationFeePda event_authority AccountInfo scratch correction; main unchanged.','baseline_package':'repro/pump_fees/sharing-module-v144','baseline_candidate_sha256':H((P/'proposal/inputs/candidate.so').read_bytes()),'candidate_sha256':H((P/'pump_fees_candidate.so').read_bytes()),'candidate_bytes':(P/'pump_fees_candidate.so').stat().st_size,'original_sha256':H((P/'proposal/inputs/original.so').read_bytes()),'source_inputs':26,'source_delta_paths':['programs/pump-fees/src/donation.rs'],'compile_tools_version':'v1.44','strip_tools_version':'v1.52','source_build_attempts':1,'source_build_failures':0,'new_unique_cases':0,'new_handlers':0,'compiler_flags_lock_profile_unchanged':True,'main_source_modified':False,'whole_original_elf_equal':False,'sealed_prebuild_proposal_sha256':H((P/'proposal/manifest-sha256.json').read_bytes())})
save('main-source-proposal.json',{'status':'Review required; no main mutation performed.','source_delta_paths':['programs/pump-fees/src/donation.rs'],'source_patch_sha256':H((P/'source.patch').read_bytes()),'source_count':26,'bounded_handlers_unchanged':31,'exact_contracts_unchanged':'0/4','candidate_sha256':H((P/'pump_fees_candidate.so').read_bytes()),'requires_clean_main_build_whole_ELF_identity':True,'runtime_receipts':17441,'donation_steps':10,'new_unique_cases':0,'limitations':['Full handler reconstruction remains incomplete.','Two early logs and reserve-dependent BondingCurve branch absent.','Parser closure and codec source-coordinate deltas remain.','No full data/transitive closure or deployed substitute claim.']})
print('PACKAGED',sum(p.is_file()for p in P.rglob('*')),'files before final signature verification/seal')
