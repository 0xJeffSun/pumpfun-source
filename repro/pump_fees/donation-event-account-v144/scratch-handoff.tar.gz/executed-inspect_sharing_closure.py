from pathlib import Path
import argparse,bisect,hashlib,json,struct
from elf_reader import Elf
W=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
C=Elf(W/'build-01/artifacts/pump_fees_candidate.so');S=Elf(W/'unstripped.so');O=Elf(W/'proposal/inputs/original.so')
assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]and C.pattern(C.lo,C.hi-C.lo)==S.pattern(S.lo,S.hi-S.lo)
prior=json.loads((W/'candidate-codecs.json').read_text());assert H(C.b)==prior['candidate_sha256']and H(O.b)==prior['original_sha256']
row=next(x for x in prior['full_codecs']if x['type']=='SharingConfig');c,o,n=row['candidate_start'],row['original_start'],row['bytes'];assert (o,n)==(442944,744)
U=row['calls'][-1]['candidate_start'];assert row['calls'][-1]['original_start']==443688
wrapper_candidates={(f['start'],f['size'])for f in S.funcs if 'Account$LT$T$GT$8try_from17'in f['name']and any(f['start']<=pc<f['start']+f['size']for pc,t in C.calls.items()if t==c)};assert len(wrapper_candidates)==1
T,TN=next(iter(wrapper_candidates));assert TN==1024
def bound(e,pc):
 i=bisect.bisect_right(e.entries,pc)-1;lo=e.entries[i];hi=e.entries[i+1]if i+1<len(e.entries)else e.hi
 return lo,hi

def windows(c,o,n):
 return {'candidate_start':c,'original_start':o,'bytes':n,'candidate_end':c+n,'original_end':o+n,'candidate_symbol_full_extent':any(f['start']==c and f['size']==n for f in S.funcs),'original_entry_window':list(bound(O,o)),'original_entry_bounded':bound(O,o)==(o,o+n),'raw_equal':C.b[c:c+n]==O.b[o:o+n],'candidate_raw_sha256':H(C.b[c:c+n]),'original_raw_sha256':H(O.b[o:o+n]),'normalized_equal':C.normalized[c:c+n]==O.normalized[o:o+n],'normalized_different_slots':[i for i in range(0,n,8)if C.normalized[c+i:c+i+8]!=O.normalized[o+i:o+i+8]],'relocation_pattern_equal':C.pattern(c,n)==O.pattern(o,n),'candidate_relocations':C.pattern(c,n),'original_relocations':O.pattern(o,n),'candidate_indirect_call_offsets':[i for i in range(0,n,8)if C.b[c+i]==0x8d],'original_indirect_call_offsets':[i for i in range(0,n,8)if O.b[o+i]==0x8d]}
def calls(c,o,n):
 result=[]
 for call in C.callsites(c,n):
  off,ct=call['offset'],call['target'];ot=O.calls.get(o+off);sizes={f['size']for f in S.funcs if f['start']==ct};r={'offset':off,'candidate_call_pc':c+off,'candidate_target':ct,'original_call_pc':o+off,'original_target':ot,'candidate_signed_operand':struct.unpack_from('<i',C.b,c+off+4)[0]}
  assert c+off+8+r['candidate_signed_operand']*8==ct
  if ot is not None:
   r['original_signed_operand']=struct.unpack_from('<i',O.b,o+off+4)[0];assert o+off+8+r['original_signed_operand']*8==ot
  if len(sizes)==1 and ot is not None:r['target_window_comparison']=windows(ct,ot,next(iter(sizes)))
  else:r['unresolved_extent']=True
  result.append(r)
 return result
def pointer(e,pc):return struct.unpack_from('<I',e.b,pc+4)[0]|struct.unpack_from('<I',e.b,pc+12)[0]<<32
literals=[]
for off,count in [(488,None),(624,13)]:
 cp,op=pointer(C,c+off),pointer(O,o+off)
 cn=struct.unpack_from('<i',C.b,c+536+4)[0]if count is None else count;on=struct.unpack_from('<i',O.b,o+536+4)[0]if count is None else count
 cb,ob=C.b[cp:cp+cn],O.b[op:op+on]
 literals.append({'instruction_offset':off,'candidate_target':cp,'original_target':op,'candidate_bytes':cn,'original_bytes':on,'candidate_hex':cb.hex(),'original_hex':ob.hex(),'candidate_sha256':H(cb),'original_sha256':H(ob),'candidate_utf8':cb.decode(),'original_utf8':ob.decode(),'equal':cb==ob})
assert literals[0]['original_utf8']=='programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs'
assert literals[0]['candidate_utf8']=='programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs'and literals[1]['equal']
checked=windows(c,o,n);assert checked['normalized_different_slots']==[528]and checked['relocation_pattern_equal'];checked['direct_calls']=calls(c,o,n);checked['literals']=literals
for x in checked['direct_calls']:assert x['target_window_comparison']['normalized_equal']and x['target_window_comparison']['original_entry_bounded']
unchecked=windows(U,443688,1472);assert unchecked['normalized_equal']and unchecked['relocation_pattern_equal'];unchecked['direct_calls']=calls(U,443688,1472)
wrapper=windows(T,27096,1024);assert wrapper['normalized_equal']and wrapper['relocation_pattern_equal'];wrapper['direct_calls']=calls(T,27096,1024)
callers={}
for label,e,target in [('candidate',C,c),('original',O,o)]:
 callers[label]=[]
 for pc,t in sorted(e.calls.items()):
  if t!=target:continue
  lo,hi=bound(e,pc)
  names=[f['name']for f in S.funcs if label=='candidate'and f['start']==lo and f['size']==hi-lo]
  callers[label].append({'call_pc':pc,'signed_operand':struct.unpack_from('<i',e.b,pc+4)[0],'target':t,'enclosing_entry_window':[lo,hi],'window_bytes':hi-lo,'window_raw_sha256':H(e.b[lo:hi]),'candidate_symbol_names':names,'name_not_recovered_for_original':label=='original'})
assert len(callers['candidate'])==2 and [r['call_pc']for r in callers['original']]==[27752,173320]
# Record all immediate relocated pointer targets for these windows, with no guessed pointee extents.
pointers=[]
for name,cc,oo,nn in [('checked',c,o,n),('unchecked',U,443688,1472),('account_try_from',T,27096,1024)]:
 for side,e,start in [('candidate',C,cc),('original',O,oo)]:
  for r in e.pattern(start,nn):
   if r['type']==8 and e.b[start+r['offset']]==0x18:
    target=pointer(e,start+r['offset']);known=name=='checked'and r['offset']in [488,624]
    pointers.append({'window':name,'side':side,'offset':r['offset'],'target':target,'literal_extent_proven_above':known,'containing_section':next((name for name,x in e.secs.items()if x[4]<=target<x[4]+x[5]),None),'unresolved_payload_closure':not known})
idl=json.loads((W/'proposal/inputs/pump_fees.json').read_text());disc=next(x['discriminator']for x in idl['accounts']if x['name']=='SharingConfig');assert bytes(disc)==hashlib.sha256(b'account:SharingConfig').digest()[:8]
result={'candidate_sha256':H(C.b),'symbols_sha256':H(S.b),'original_sha256':H(O.b),'checked_codec':checked,'unchecked_codec':unchecked,'account_try_from_caller':wrapper,'incoming_direct_callers':callers,'relocated_pointer_inventory':pointers,'discriminator':{'idl_bytes':disc,'name_preimage':'account:SharingConfig','sha256_prefix_hex':bytes(disc).hex()},'diagnostic_lines':{'candidate':struct.unpack_from('<i',C.b,c+528+4)[0],'original':struct.unpack_from('<i',O.b,o+528+4)[0],'proposal_natural_attribute_line':5},'limits':['Entry-window bounds in stripped original are inferred from direct-call/relocation entries, not recovered original debug symbols.','The fresh create_donation_fee_pda caller is 10584 bytes versus the proven original 13800-byte caller. Instruction identity is separately established in proposal/analysis.json and caller-static-proof.json; complete handler equivalence is not claimed.','Only the two codec literal extents are established here. Other relocated pointer targets and arbitrary descendants remain unresolved.','This is fresh bounded static evidence for the single moved candidate. Runtime is separately recorded; no whole-program equivalence claim.']}
a.output.write_text(json.dumps(result,indent=2)+'\n');print('STATIC PROOF',len(checked['direct_calls']),'checked calls;',len(unchecked['direct_calls']),'unchecked calls;',len(wrapper['direct_calls']),'wrapper calls; source location mismatch only in checked body')
