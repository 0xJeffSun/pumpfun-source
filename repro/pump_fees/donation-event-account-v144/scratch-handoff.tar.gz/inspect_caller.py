#!/usr/bin/env python3
"""Complete fresh selected windows and bounded direct-call/data inventory."""
from pathlib import Path
import argparse, hashlib, json, re, struct
from elf_reader import Elf
from proposal.analyze_evidence import WINDOWS, window, instructions, comparison, data_refs, extent

W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--symbols',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
C=Elf(a.candidate);S=Elf(a.symbols);O=Elf(W/'proposal/inputs/original.so');B=Elf(W/'proposal/inputs/symbols.so')
H=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]
def find(old):
    exact={f['name']for f in B.funcs if f['start']==old}
    retained={(f['start'],f['size'])for f in S.funcs if f['name']in exact}
    if len(retained)==1:return next(iter(retained))
    names={canon(n)for n in exact}
    found={(f['start'],f['size'])for f in S.funcs if canon(f['name'])in names}
    assert len(found)==1,(old,found,names)
    return next(iter(found))
rows={};ledger={};references={};targets={}
for name,((o,on),(prior,pn)) in WINDOWS.items():
    c,cn=find(prior)
    rows[name]={'original':window(O,o,on,[]),'candidate':window(C,c,cn,S.funcs),'comparison':comparison(O,C,o,c,on,cn)}
    ledger[name]={'original':instructions(O,o,on),'candidate':instructions(C,c,cn)}
    references[name]={'original':data_refs(O,o,on),'candidate':data_refs(C,c,cn)}
    if name not in ['wrapper','parser','handler']:continue
    for side,e,start,n,symbols in [('original',O,o,on,[]),('candidate',C,c,cn,S.funcs)]:
        for call in e.callsites(start,n):
            target=call['target'];key=side+':'+str(target)
            if key in targets:continue
            sizes={f['size']for f in symbols if f['start']==target}
            count=next(iter(sizes))if len(sizes)==1 else extent(e,target)
            targets[key]={'image':side,'window':window(e,target,count,symbols),'relocated_data':data_refs(e,target,count),'extent_basis':'current symbol'if len(sizes)==1 else 'next inferred original entry'}
# Same-relative-offset direct-target comparison is meaningful only for the now matching root windows.
direct={}
for name in ['wrapper','parser']:
    row=rows[name];o=row['original']['start'];c=row['candidate']['start'];n=row['original']['size']
    assert row['comparison']['normalized_equal'] and row['comparison']['relocation_pattern_equal']
    cs=C.callsites(c,n);os=O.callsites(o,n);assert [x['offset']for x in cs]==[x['offset']for x in os]
    direct[name]=[]
    for x,y in zip(os,cs):
        ot=x['target'];ct=y['target'];on=extent(O,ot);sizes={f['size']for f in S.funcs if f['start']==ct};assert len(sizes)==1;cn=next(iter(sizes))
        direct[name].append({'call_offset':x['offset'],'original_call_pc':o+x['offset'],'candidate_call_pc':c+y['offset'],'original_signed_operand':struct.unpack_from('<i',O.b,o+x['offset']+4)[0],'candidate_signed_operand':struct.unpack_from('<i',C.b,c+y['offset']+4)[0],'original_target':ot,'candidate_target':ct,'original_bytes_inferred':on,'candidate_symbol_bytes':cn,'comparison':comparison(O,C,ot,ct,on,cn)})
# Explicit literal extents established by the wrapper log ABI and parser error-name ABI.
literal_pairs=[]
for name in ['wrapper','parser']:
    o=rows[name]['original']['start'];c=rows[name]['candidate']['start'];n=rows[name]['original']['size']
    for ref in O.pattern(o,n):
        off=ref['offset'];pc=o+off
        if ref['type']!=8 or O.b[pc]!=0x18:continue
        ins_o=instructions(O,pc,min(64,o+n-pc));ins_c=instructions(C,c+off,min(64,c+n-(c+off)))
        length=None;kind=None
        if name=='wrapper' and off==32:length=33;kind='instruction log: r1 pointer, r2 length'
        elif O.b[pc+1]==4 and O.b[pc+16:pc+20]==bytes([0xb7,5,0,0]) and O.b[pc+24]==0x85:
            # LDDW r4; MOV64 r5,length; direct Error::with_account_name call.
            target=O.calls[pc+24]
            if target==5512:
                length=struct.unpack_from('<i',O.b,pc+20)[0];kind='Error::with_account_name: r4 pointer, r5 length'
        if length is None:continue
        op=ins_o[0]['imm64_unsigned'];cp=ins_c[0]['imm64_unsigned'];ob=O.b[op:op+length];cb=C.b[cp:cp+length]
        assert ob==cb
        literal_pairs.append({'window':name,'offset':off,'consumption_basis':kind,'length':length,'original_target':op,'candidate_target':cp,'original_hex':ob.hex(),'candidate_hex':cb.hex(),'sha256':H(ob),'equal':True})
assert len(literal_pairs)>=15
closure_location={}
for side,e in [('original',O),('candidate',C)]:
    start=rows['parser_init_if_needed_closure'][side]['start']
    ptr=struct.unpack_from('<I',e.b,start+3528+4)[0]|struct.unpack_from('<I',e.b,start+3528+12)[0]<<32
    line=struct.unpack_from('<i',e.b,start+3568+4)[0]
    length=struct.unpack_from('<i',e.b,start+3576+4)[0]
    assert e.b[start+3528]==0x18 and e.b[start+3568]==0x62 and e.b[start+3576]==0x7a
    payload=e.b[ptr:ptr+length]
    closure_location[side]={'pointer_instruction':start+3528,'target':ptr,'length_instruction':start+3576,'length':length,'line_instruction':start+3568,'line':line,'path':payload.decode(),'sha256':H(payload)}
assert closure_location['original']['path']=='programs/pump-fees/src/instructions/fee_sharing/create_donation_fee_pda.rs'
assert closure_location['candidate']['path']=='programs/pump-fees/src/donation.rs'
wrapper=rows['wrapper']['candidate']['start'];parser=rows['parser']['candidate']['start'];handler=rows['handler']['candidate']['start']
assert C.calls[wrapper+160]==parser and C.calls[wrapper+424]==handler
assert C.calls[rows['entrypoint']['candidate']['start']+128]==rows['dispatch']['candidate']['start']
for msg in [b'donation_fee_pda already exists',b'CreateDonationFeePda is currently disabled']:assert msg not in C.b
sections=[]
for n in sorted(set(C.secs)&set(S.secs)):
    x,y=C.secs[n],S.secs[n];cb=C.b[x[4]:x[4]+x[5]];sb=S.b[y[4]:y[4]+y[5]]
    sections.append({'name':n,'allocated':bool(x[2]&2),'candidate_bytes':len(cb),'unstripped_bytes':len(sb),'payload_equal':cb==sb,'candidate_sha256':H(cb),'unstripped_sha256':H(sb)})
assert all(x['payload_equal']for x in sections if x['allocated'])
result={'candidate_sha256':H(C.b),'candidate_bytes':len(C.b),'symbols_sha256':H(S.b),'original_sha256':H(O.b),'baseline_sha256':H((W/'proposal/inputs/candidate.so').read_bytes()),'windows':rows,'matched_root_direct_targets':direct,'exact_consumed_literal_pairs':literal_pairs,'parser_closure_source_location':closure_location,'direct_target_inventory':targets,'known_missing_logs_preserved':True,'strip_sections':sections,'all_shared_allocated_payloads_unchanged':True,'limits':['Only wrapper/parser complete normalized windows now match; their handler and init_if_needed closure targets remain separately classified.','All direct target windows and their relocated data are inventoried. Bounded 128-byte previews are not full consumed-extent proofs.','Exact log/account-name and retained codec literal spans are checked separately. General descriptor/vtable and transitive indirect-call closure remain unresolved.','Missing reserve-dependent handler branch, two logs, source-coordinate differences and whole-original ELF inequality remain. No new handlers or unique runtime cases.']}
a.output.write_text(json.dumps(result,indent=2)+'\n')
a.output.with_name('fresh-instruction-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
a.output.with_name('fresh-data-reference-ledger.json').write_text(json.dumps(references,indent=2)+'\n')
print(json.dumps({'wrapper_bytes':rows['wrapper']['candidate']['size'],'parser_bytes':rows['parser']['candidate']['size'],'full_wrapper_and_parser_normalized_matches':True,'handler_bytes':rows['handler']['candidate']['size'],'direct_target_windows':len(targets),'exact_consumed_literal_pairs':len(literal_pairs)}))
