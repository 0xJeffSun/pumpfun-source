# Fees donation event-authority context recovery — isolated build

The single approved `CreateDonationFeePda.event_authority` change from `UncheckedAccount<'info>` to `AccountInfo<'info>` makes the complete parser and wrapper match the corresponding original windows after normalization of call operands and relocated addresses. The handler remains incomplete. Main source is unchanged and this is a scratch handoff for review.

Candidate: **8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e**, **768,848 bytes**. Baseline: `8cce74a5191b286eaa10af59c02c9ee16d3853be214c5e9b1132e50bba15ef87`. Original: `4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`. Whole original ELF equality is false. Source counts remain **31 bounded Fees handlers, 0/4 exact contracts**; no handler or unique test case was added.

## Source and build identity

The sealed prebuild proposal is included unchanged under `proposal/`, manifest SHA `0f0bfeab96e0358a6c2b3037ff931ec0b3b0a36b69c0e5dc613e68f50796e7f5`. Its IDL discriminator/entrypoint/dispatch/wrapper chain proves original instruction identity before any source build. `source.patch` changes exactly one field type in donation.rs. Seed/bump constraints, typed program field, handler, other contexts, IDLs, lock, profile and flags are unchanged. Both source snapshots contain exactly 26 inputs and were frozen before compilation.

One isolated build used the established Darwin pipeline: official v1.44 compilation, followed by the recorded SDK's v1.52 objcopy strip phase. The unchanged 53-file SDK snapshot, four build helpers, before/after compiler and stripper hashes, actual build log, isolated SDK/rustup/target paths and phase markers are retained. No program/lock edits, compiler variants, padding, remapping or second build occurred. Every shared allocated ELF section, including .text, is identical before and after stripping. The historical installer selects its recorded stripping tool independently of the v1.44 compile request; the report makes no stronger historical-recipe claim.

## Static outcome

| Body | Original | Fresh candidate | Result |
| --- | --- | --- | --- |
| CreateDonationFeePda parser | 425776 / 8,984 bytes | 135168 / 8,984 bytes | Complete normalized body and relocation pattern match |
| create_donation_fee_pda wrapper | 655904 / 928 bytes | 357304 / 928 bytes | Complete normalized body and relocation pattern match |
| create_donation_fee_pda handler | 163920 / 13,800 bytes | 425736 / 10,584 bytes | Different; known missing behavior remains |

All 76 direct calls from the matching parser/wrapper are paired using their signed call operands. Seventy-four target windows match normalized completely with matching relocation patterns. The remaining two are the known incomplete handler and the parser's 8,184-byte init_if_needed closure, which retains only its existing +3568/+3576 normalized slot differences. The latter are source-location line 21 versus 81 and filename length 74 versus 34; both actual consumed filename spans are now explicitly recorded. No source relocation or coordinate adjustment is included. This distinguishes matching callers from still-unmatched callees.

`caller-static-proof.json` includes 81 separate original/current direct-target windows and their relocated data inventories, plus 21 exact consumed instruction-log/account-name literal comparisons. Full instruction and data-reference ledgers cover twelve original/fresh windows. General descriptor previews are bounded to 128 bytes and are not full consumed-extent or transitive-closure proofs. The original stripped extents are next-entry inferred windows, while current sizes come from fresh symbols.

All five moved state/SharingConfig codecs retain their known natural diagnostic-line difference at +528; both filename and type-name literal spans and all 35 direct call comparisons remain intact. The SharingConfig checked/unchecked/Account caller closure retains its 23 direct-call checks. Ten previously accepted initializer/social/formatter bodies, 26 direct calls and five literal spans also pass unchanged. The identical code appears in more than one bounded check; these totals are not additive coverage denominators.

The original's two early log strings remain absent from this candidate. The separate reserve-dependent BondingCurve branch remains absent from the current handler. Handler source path/coordinates, some error/event lowering, arbitrary nested data and indirect-call closure remain unresolved. The field correction is not claimed to restore this entire instruction or contract.

## Unchanged runtime evidence

The frozen 46-file harness and 18 runtime inputs ran against this new candidate, producing fresh receipts for **17,441 comparisons** and the **ten-step donation sequence**, with zero reported mismatches. The comparison total includes the 17,331-case, 18-suite aggregate and eight additional comparison reports (including historical-message replay); it preserves prior repeated-input accounting. No new cases or probes were added. Logs are compared only where the unchanged harness checks them, so the successful corpus does not contradict the known missing log strings or establish missing-branch coverage.

Both genuine historical initializer transaction messages/signatures were replayed unchanged with runtime signature verification, and the existing blockhash-freshness negative control passed. All saved ordinary transaction fields re-verify cryptographically: **8,644 encoded transaction fields carrying 17,204 signatures**, plus the two genuine historical captures checked separately. These are saved-field/signature counts, not unique transaction counts or additional case counts. `runtime-engine.json` identifies the actual local LiteSVM/solders binary. No network writes or Surfpool process was used.

The direct nine comparison receipt gzip files and donation-sequence gzip are present; no summary replaces the receipts. Each is bound to candidate, original, actual 26 source hashes, build-report hash, unchanged runner and fixture hashes in `receipt-build-bindings.json` and `frozen-runner-inputs.json`. Official historical messages are included byte-identically under `runtime/repro/pump_fees/initializer-history/transactions/`.

## Verification and proposal

Run `python -B verify.py --runtime` from any directory. This verifies archives, sources, phases, raw ELF identity and selected static windows, then verifies saved signatures; it does not compile or replay programs. The package requires Python and the recorded solders package for the signature option. No work/cache paths are required; original absolute execution paths are provenance only.

The only analysis preparation failure was an ambiguous canonical generic symbol name. Its first script and diagnostic are preserved under `analysis-history/`; selecting the retained exact symbol name resolved it without altering source, build, or runtime. All build and runtime attempts succeeded.

`main-source-proposal.json` proposes only donation.rs's one-field correction. If accepted, finalize any program documentation before one isolated clean main build and require whole-ELF identity with this candidate before carrying these fresh receipts forward. This package makes no main promotion, deployment or whole-contract equality claim.
