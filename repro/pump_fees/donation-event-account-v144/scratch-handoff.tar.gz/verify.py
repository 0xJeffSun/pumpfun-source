#!/usr/bin/env python3
"""Portable saved-evidence verifier. No builds or program replay; optional saved signatures."""
from pathlib import Path
import argparse,difflib,gzip,hashlib,json,subprocess,sys,tarfile,tempfile
P=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((P/n).read_text())
p=argparse.ArgumentParser();p.add_argument('--runtime',action='store_true');a=p.parse_args()
assert not any(x.is_symlink()for x in P.rglob('*'))
manifest=read('manifest-sha256.json')
assert {str(x.relative_to(P)):H(x.read_bytes())for x in P.rglob('*')if x.is_file()and x!=P/'manifest-sha256.json'}==manifest
def archive(name,expected):
 with tarfile.open(P/name)as t:
  members=t.getmembers();assert all(x.isfile()and not Path(x.name).is_absolute()and'..'not in Path(x.name).parts for x in members)
  data={x.name:t.extractfile(x).read()for x in members};assert len(data)==len(members)
 assert {n:H(b)for n,b in data.items()}==expected,name
 return data
base=read('baseline-source-sha256.json');source=read('source-sha256.json');assert len(base)==len(source)==26
before=archive('baseline-source-snapshot.tar.gz',base);after=archive('source-snapshot.tar.gz',source)
assert base==read('proposal/inputs/source-sha256.json')
assert [n for n in source if source[n]!=base[n]]==['programs/pump-fees/src/donation.rs']
for n,b in before.items():assert b==(P/'proposal/inputs/source'/n).read_bytes()
for n,b in after.items():assert b==((P/'proposal/proposal/donation.rs').read_bytes()if n=='programs/pump-fees/src/donation.rs'else before[n])
assert (P/'source.patch').read_bytes()==(P/'proposal/source.patch').read_bytes()
pre=archive('prebuild-snapshot.tar.gz',read('prebuild-manifest-sha256.json'));assert pre['source.patch']==(P/'source.patch').read_bytes()and pre['source-snapshot.tar.gz']==(P/'source-snapshot.tar.gz').read_bytes()
archive('build-helper-snapshot.tar.gz',read('build-helper-sha256.json'));assert len(read('build-helper-sha256.json'))==4
archive('harness-snapshot.tar.gz',read('harness-source-sha256.json'));assert len(read('harness-source-sha256.json'))==46
runtime=read('runtime-inputs.json');assert len(runtime)==18
for n,h in runtime.items():assert H((P/'runtime'/n).read_bytes())==h
build=read('build-comparison.json');attempt=read('build-attempt.json');prefix='work/fees-donation-event-accountinfo-recovery/source/'
assert len(build['source_sha256'])==26 and {n.removeprefix(prefix):h for n,h in build['source_sha256'].items()}==source
assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256']
assert H(gzip.decompress((P/'build.log.gz').read_bytes()))==build['build_log_sha256']==attempt['build_log_sha256']
C=(P/'pump_fees_candidate.so').read_bytes();O=(P/'proposal/inputs/original.so').read_bytes();prov=read('provenance.json')
assert H(C)==prov['candidate_sha256']=='8f89dbeb0eaef9490a518a97adb50dd8cbf0a21984a2bfca343d6ff5c2fe6c8e'and len(C)==prov['candidate_bytes']==768848
assert H(O)==prov['original_sha256']=='4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e'
comparison={'original_bytes':len(O),'candidate_bytes':len(C),'original_sha256':H(O),'candidate_sha256':H(C),'full_byte_equality':O==C,'first_difference':next((i for i,(x,y)in enumerate(zip(O,C))if x!=y),None),'different_positions_in_shared_length':sum(x!=y for x,y in zip(O,C)),'length_difference':len(C)-len(O)}
assert comparison==build['comparison']and not comparison['full_byte_equality']and prov['source_build_attempts']==1 and not prov['main_source_modified']
assert H((P/'proposal/manifest-sha256.json').read_bytes())==prov['sealed_prebuild_proposal_sha256']=='0f0bfeab96e0358a6c2b3037ff931ec0b3b0a36b69c0e5dc613e68f50796e7f5'
sdk=archive('sbf-sdk-snapshot.tar.gz',build['sdk_source_sha256']);assert len(sdk)==53
phase=read('tool-phase-provenance.json')
assert phase['compile']['requested_tools_version']=='v1.44'and phase['compile']['tool_hashes_before']==phase['compile']['tool_hashes_after']=={n:v['sha256']for n,v in phase['compile']['tool_files'].items()}
assert phase['compile']['unstripped_sha256']==H((P/'symbols.so').read_bytes())and phase['strip']['candidate_sha256']==H(C)
assert phase['strip']['sdk_marker']=='platform-tools-v1.52.md'and phase['strip']['file_sha256_before']==phase['strip']['file_sha256_after']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
for n,h in phase['phase_source_sha256'].items():assert H(sdk[n])==h
with tempfile.TemporaryDirectory()as temp:
 temp=Path(temp)
 def run(script,argv):
  r=subprocess.run([sys.executable,'-B',str(P/script),*map(str,argv)],cwd=temp,capture_output=True,text=True);assert r.returncode==0,(script,r.stdout,r.stderr);return r
 run('proposal/verify.py',[])
 out=temp/'codecs.json';run('inspect_codecs.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--output',out]);assert json.loads(out.read_text())==read('candidate-codecs.json')
 out=temp/'retained.json';run('verify_retained_static.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--baseline-symbols',P/'accepted-inline-symbols.so','--gate',P/'accepted-inline-static-gate.json','--output',out]);assert json.loads(out.read_text())==read('retained-static-gate.json')
 out=temp/'sharing.json';run('inspect_sharing_closure.py',['--output',out]);assert json.loads(out.read_text())==read('sharing-closure-proof.json')
 out=temp/'caller.json';run('inspect_caller.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--output',out]);assert json.loads(out.read_text())==read('caller-static-proof.json')
 for n in ['fresh-instruction-ledger.json','fresh-data-reference-ledger.json']:assert json.loads((temp/n).read_text())==read(n)
 if a.runtime:assert json.loads(run('verify_saved_runtime.py',[]).stdout)==read('runtime-verification-result.json')
rows=read('candidate-codecs.json')['full_codecs'];assert len(rows)==5
for r in rows:
 assert r['original_entry_bounded']and r['relocation_pattern_equal']and r['different_slots']==[528]and all(x['equal']for x in r['literal_spans'])
 assert all(x['original_entry_bounded']and x['normalized_equal']and x['relocation_pattern_equal']for x in r['calls'])
proof=read('caller-static-proof.json')
assert len(proof['direct_target_inventory'])==81 and len(proof['exact_consumed_literal_pairs'])==21
assert proof['all_shared_allocated_payloads_unchanged']and proof['known_missing_logs_preserved']
for n in ['wrapper','parser']:assert proof['windows'][n]['comparison']['normalized_equal']and proof['windows'][n]['comparison']['relocation_pattern_equal']
assert proof['windows']['handler']['candidate']['size']==10584 and not proof['windows']['handler']['comparison']['normalized_equal']
targets=[r for rows in proof['matched_root_direct_targets'].values()for r in rows]
assert len(targets)==76 and sum(r['comparison']['normalized_equal']and r['comparison']['relocation_pattern_equal']for r in targets)==74
inputs=read('frozen-runner-inputs.json');assert inputs['source_sha256']==source and inputs['harness_sha256']==read('harness-source-sha256.json')and inputs['runtime_sha256']==runtime and inputs['runner_sha256']==H((P/'run_regressions.py').read_bytes())
bindings=read('receipt-build-bindings.json');assert len(bindings)==10
for r in bindings:
 encoded=(P/r['saved_report']).read_bytes();raw=gzip.decompress(encoded);d=json.loads(raw)
 assert H(encoded)==r['saved_report_sha256']and H(raw)==r['raw_report_sha256']==r['report_sha256']
 assert d['candidate_sha256']==H(C)and d['original_sha256']==H(O)and not d['mismatches']
 assert r['executed_candidate_sha256']==H(C)and r['actual_source_sha256']==source and r['build_report_sha256']==H((P/'build-comparison.json').read_bytes())and r['returncode']==0 and r['passed']
summary=read('runtime-summary.json');assert summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and summary['source_inputs']==26 and not summary['mismatches']and not summary['orchestration_failures']
print(json.dumps({'verified':True,'sealed_files':len(manifest),'source_inputs':26,'complete_wrapper_and_parser_normalized_match':True,'whole_original_elf_equal':False,'comparison_receipts':17441,'donation_steps':10,'saved_signature_verifier_rerun':a.runtime,'main_source_changed':False},indent=2))
