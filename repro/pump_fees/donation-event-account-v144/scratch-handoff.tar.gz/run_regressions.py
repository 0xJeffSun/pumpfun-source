#!/usr/bin/env python3
"""Replay only the prior ten jobs, with frozen helpers/fixtures and new bytes."""
from pathlib import Path
import ast,concurrent.futures,hashlib,json,os,subprocess,sys,tarfile,time
W=Path(__file__).resolve().parent;ROOT=W.parents[1];C=W;R=C/'runner-repo';OUT=C/'runtime'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
prior=ROOT/'repro/pump_fees/sharing-module-v144'
candidate=C/'build-01/artifacts/pump_fees_candidate.so';build=read(C/'build-01/build-comparison.json')
assert read(C/'static-gate.json')['source_delta_is_exact_one_field'] and read(C/'static-gate.json')['original_handler_identity_preserved']
assert H(candidate)==read(C/'static-gate.json')['candidate_sha256']==build['comparison']['candidate_sha256']
assert not OUT.exists() and not R.exists();OUT.mkdir();R.mkdir()
source=read(C/'source-sha256.json');harness=read(prior/'harness-source-sha256.json');runtime=read(prior/'runtime-inputs.json')
with tarfile.open(ROOT/'repro/pump_fees/social-v2-account-layout-v144/harness-snapshot.tar.gz')as t:
 for m in t.getmembers():
  assert m.isfile()and m.name in harness and '..'not in Path(m.name).parts
  data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==harness[m.name]
  p=R/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for name,digest in runtime.items():
 src=ROOT/name;assert H(src)==digest
 dst=R/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
for name,digest in source.items():
 src=C/'source'/name;assert H(src)==digest
 dst=R/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
assert {p:H(R/p)for p in harness}==harness and len(harness)==46
assert {p:H(R/p)for p in runtime}==runtime and len(runtime)==18
orchestration=(ROOT/'repro/pump_fees/social-v2-account-layout-v144/run-regressions.py').read_bytes();(C/'prior-run-regressions.py').write_bytes(orchestration)
module=ast.parse(orchestration)
jobs=next(ast.literal_eval(n.value)for n in module.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='jobs'for t in n.targets))
assert len(jobs)==10 and sum(n for _,_,n in jobs if n is not None)==17441
assert all(script in harness for _,script,_ in jobs)
save(C/'frozen-runner-inputs.json',{'source_sha256':source,'harness_sha256':harness,'runtime_sha256':runtime,'prior_orchestration_sha256':hashlib.sha256(orchestration).hexdigest(),'runner_sha256':H(Path(__file__)),'unchanged_jobs':jobs,'new_unique_cases':0})
results=[];orchestration_failures=[]
def run(row):
 name,script,expected=row;path=OUT/(name+'.json');command=[sys.executable,str(R/script),'--candidate',str(candidate),'--output',str(path)];start=time.monotonic()
 with (OUT/(name+'.log')).open('wb')as log:result=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 entry={'name':name,'command':command,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-start,'report':str(path.relative_to(C)),'expected_cases':expected,'executed_candidate_sha256':H(candidate),'actual_source_sha256':source,'build_report_sha256':H(C/'build-01/build-comparison.json')}
 assert path.exists(),name
 d=read(path);entry.update(report_sha256=H(path),case_count=d.get('case_count'),mismatches=d.get('mismatches',d.get('failures',[])))
 assert d['candidate_sha256']==H(candidate)and d['original_sha256']==H(R/'evidence/original/pump_fees/deployed.so'),name
 entry['passed']=not entry['mismatches'] and not d.get('unexpected_errors',[]) and not d.get('unexpected_original_errors',[]) and result.returncode==0
 if expected is not None:assert d['case_count']==expected,name
 else:assert len(d['steps'])==10 and all(x['match']and x['original']['signature_verification']and x['candidate']['signature_verification']for x in d['steps'])
 # A completed failing job is retained and does not prevent independent jobs.
 assert H(R/script)==harness[script],name
 print(name,'passed' if entry['passed'] else 'FAILED',expected if expected is not None else '10 steps',flush=True)
 return entry
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
  for future in concurrent.futures.as_completed([pool.submit(run,row)for row in jobs]):
   try:results.append(future.result())
   except BaseException as e:orchestration_failures.append({'type':type(e).__name__,'error':str(e)})
   save(OUT/'progress.json',{'results':results,'orchestration_failures':orchestration_failures})
 for p,h in {**source,**harness,**runtime}.items():assert H(R/p)==h,p
 assert source=={p:H(C/'source'/p)for p in source}
 total=sum(r['case_count']for r in results if r['expected_cases']is not None);assert total==17441
 save(OUT/'summary.json',{'candidate_sha256':H(candidate),'original_sha256':H(R/'evidence/original/pump_fees/deployed.so'),'comparison_receipts':total,'donation_sequence_steps':10,'reports':results,'source_inputs':26,'harness_inputs':46,'runtime_inputs':18,'new_unique_cases':0,'mismatches':[r['name']for r in results if not r['passed']],'orchestration_failures':orchestration_failures})
 assert not orchestration_failures
 print('COMPLETED',total,'failed jobs',[r['name']for r in results if not r['passed']],flush=True)
except BaseException as e:
 save(OUT/'failure.json',{'type':type(e).__name__,'error':str(e),'finished_results':results});raise
