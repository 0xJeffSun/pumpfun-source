"""Verify saved source-attribution evidence without executing or rebuilding programs."""
from pathlib import Path
import hashlib,json,struct,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
manifest=read(W/'manifest-sha256.json')
for path,digest in manifest.items():assert sha((W/path).read_bytes())==digest,path
report=read(W/'attribution.json')
assert not report['unique_historical_version_proven']and not report['build_recipe_proposed']
for crate in report['crates']:
    name='solana-pubkey-'+crate['version'];root=W/'inputs'/name
    archive=W/'inputs'/(name+'.crate');index=read(root/'registry-index-record.json')
    assert sha(archive.read_bytes())==crate['archive_sha256']==index['cksum']
    with tarfile.open(archive)as tar:
        for path,entry in crate['files'].items():
            data=tar.extractfile(name+'/'+path).read()
            assert data==(root/path).read_bytes()and sha(data)==entry['sha256']
for row in report['coordinate_checks']:
    for version,expected in row['source_coordinates'].items():
        lines=(W/'inputs'/('solana-pubkey-'+version)/'src/lib.rs').read_text().splitlines()
        text=lines[expected['line']-1]
        assert text==expected['text']and text.index('panic!')+1==expected['column']
for row in report['identical_source_blocks']:
    data=[]
    for version,positions in row['lines'].items():
        lines=(W/'inputs'/('solana-pubkey-'+version)/'src/lib.rs').read_text().splitlines()
        text='\n'.join(lines[positions['first']-1:positions['last']])
        text=text[text.index(row['declaration']):]
        assert sha(text.encode())==row['text_sha256'];data.append(text)
    assert len(data)==2 and data[0]==data[1]
elfs={role:(R/report[role+'_path']).read_bytes()for role in ['original','candidate']}
for role,data in elfs.items():assert sha(data)==report[role+'_sha256']
for row in report['matching_helper_nodes']:
    normalized=[]
    for role,data in elfs.items():
        start=row[role];size=row[role+'_bytes'];raw=data[start:start+size]
        assert raw==(W/'inputs'/f'{role}-{start}.bin').read_bytes()
        assert sha(raw)==row[role+'_raw_sha256']
        relocs={r['offset']:r for r in row[role+'_relocations']};normal=bytearray(raw)
        for off in range(0,size,8):
            if raw[off]==0x85 and raw[off+1]==0x10 and relocs.get(off,{}).get('type')!=10:normal[off+4:off+8]=bytes(4)
            if off in relocs:
                typ=relocs[off]['type']
                if typ==8 and raw[off]==0x18:normal[off+4:off+8]=bytes(4);normal[off+12:off+16]=bytes(4)
                elif typ==10 and raw[off]==0x85:normal[off+4:off+8]=bytes(4)
        normalized.append(bytes(normal))
    assert normalized[0]==normalized[1]and row['candidate_relocations']==row['original_relocations']
for row in report['helper_relocation_evidence']:
    for role,data in elfs.items():
        record=row[role+'_record'];at=record['address'];ptr,n=struct.unpack_from('<QQ',data,at)
        assert ptr>>32==record['decoded_pointer']and n==record['length']
        assert sha(data[ptr>>32:(ptr>>32)+n])==record['pointee_sha256']
        if record['kind']=='source_location_record':
            assert struct.unpack_from('<II',data,at+16)==(record['line'],record['column'])
            assert data[at:at+24]==(W/'inputs'/f'{role}-location-{at}.bin').read_bytes()
print(json.dumps({'sealed_files':len(manifest),'crate_archives':2,'exact_coordinate_pairs':2,
                  'identical_source_blocks':4,'complete_normalized_helper_windows':2,
                  'unique_historical_version_proven':False,'builds':0,'runtime_tests':0},indent=2))
