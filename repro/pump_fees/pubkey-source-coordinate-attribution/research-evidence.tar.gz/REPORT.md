# Pubkey source-coordinate attribution

The already cached published `solana-pubkey` **2.2.1** source is a concrete match
for both source coordinates preserved in the original Fees executable. Its
`PubkeyError::from` panic is at **131:18**, and its `find_program_address` panic
is at **612:32**. The candidate's pinned **2.4.0** source places the same panic
tokens at **134:18** and **802:32**. Both line and column coordinates match
exactly; this is more specific than a general compiler-family observation.

This identifies a supported source candidate, not a unique historical version
or complete build recipe. Only the pinned 2.4.0 source and the already available
2.2.1 archive were examined. Other releases or commits may retain the same lines
and helper bodies. No version enumeration, download, build, runtime test, source
change, path padding or binary edit was performed.

| Published crate | Cached archive SHA-256 | src/lib.rs SHA-256 |
| --- | --- | --- |
| 2.2.1 | `40db1ff5a0f8aea2c158d78ab5f2cf897848964251d1df42fef78efd3c85b863` | `143252a8a99a9a5c1acd9cfb9bef6759b94c6b1788fdbbddc1126b57632a34a4` |
| 2.4.0 | `9b62adb9c3261a052ca1f999398c388f1daf558a1b492f60a6d9e64857db4ff1` | `a667b28ce392328ef9ef3a6a4ef24606e9c764d58c9c536afe1d22a191898a24` |

Both archive hashes equal their cached crates.io index checksums. The copied
source, syscall module, Cargo metadata and `.cargo_vcs_info.json` equal the
contents of those archives byte for byte. Current `Cargo.lock` also pins the
2.4.0 checksum. The cached registry records give publication timestamps
2025-02-12T20:18:24Z and 2025-05-16T16:08:46Z, respectively; these are registry
metadata timestamps, not acquisition times.

The 2.2.1 archive declares repository `https://github.com/anza-xyz/agave`, commit
`1c1d667f161666f12f5a43ebef8eda9470a8c6ee`, path `pubkey`. The 2.4.0 archive
declares `https://github.com/anza-xyz/solana-sdk`, commit
`483720e23010213a2d611ea1295bd72b3fd98979`, path `pubkey`. These are the
published archive's own metadata; the named Git objects were not fetched or
independently authenticated in this bounded review.

Four complete source blocks, including signatures and bodies, are text-identical
between the two releases: `impl From<u64> for PubkeyError`,
`find_program_address`, `try_find_program_address`, and
`create_program_address`. The first conversion occupies lines 125–134 versus
128–137; the public find wrapper occupies 610–613 versus 800–803. The exact
source lines, block hashes and other block boundaries are in `attribution.json`.
Preceding documentation and attributes are not included in the identical-block
claim. The 190-line displacement at the find panic is accounted for by actual
preceding source changes, including the custom Pubkey hash implementation/module,
parsing and unique-key-generation changes; `line-shift-hunks.json` preserves the
complete relevant diff hunks. It is not unexplained compiler movement.

The existing matching-helper proof is retained without alteration. Candidate
`create_program_address` at 642152 and original 752592 both occupy 464 bytes;
candidate `find_program_address` at 641840 and original 752280 both occupy
312 bytes. Each complete normalized body and relocation pattern matches, while
its raw bytes and referenced source-location records differ. The create helper's
first panic coordinate belongs to the inlined `PubkeyError::from` conversion,
not the line declaring the public create method. Its panic text is the same
`Unsupported PubkeyError`; the find wrapper's panic text also matches. The new
record contains the original closure manifest, exact selected node/relocation
records, raw helper windows and raw 24-byte location records.

The frozen original Fees ELF remains
`4f2955d0f6b40cc9ff7daa18ccad7d19119ba1249759f4e7e3bb691beee6b35e`;
the accepted candidate remains
`a9c4ea9e47356a91bf9bd97318746a7c207b873e32485d7786853f048d7d4afa`.
No original identity or business-logic correction is newly established. Other
parts of the Pubkey crate differ, so the matching blocks do not prove that a
whole-crate substitution is behaviorally equivalent throughout Fees. Features,
the remaining dependency graph, compiler, OS and flags are still unresolved.
No build recipe is proposed by this read-only attribution report.

Run `python3 work/pubkey-source-coordinate-attribution/verify.py` to check the
sealed files, crate checksums/source copies, exact source coordinates, retained
raw ELF windows and normalized helper bodies. It does not execute a program.
