"""Read cached official crate sources and existing ELF evidence; no builds or execution."""
from pathlib import Path
import datetime, difflib, hashlib, json, shutil, struct, tarfile

W=Path(__file__).resolve().parent;R=W.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
closure_root=R/'work/fees-update-admin-closure'
closure=read(closure_root/'closure.json')
for path,digest in read(closure_root/'manifest-sha256.json').items():
    assert sha((closure_root/path).read_bytes())==digest,path
(W/'inputs').mkdir(exist_ok=True)
index_path=Path('/Users/shawwalters/.cargo/registry/index/index.crates.io-1949cf8c6b5b557f/.cache/so/la/solana-pubkey')
records={}
for raw in index_path.read_bytes().split(b'\0'):
    if raw.startswith(b'{'):
        record=json.loads(raw)
        if record.get('vers')in ['2.2.1','2.4.0']:records[record['vers']]=(record,raw)
crate_rows=[];source_text={}
for version,base in [('2.2.1',Path('/Users/shawwalters/.cargo/registry')),('2.4.0',R/'work/fees-v144-cargo-home/registry')]:
    name='solana-pubkey-'+version
    cache=base/'cache/index.crates.io-1949cf8c6b5b557f'/(name+'.crate')
    extracted=base/'src/index.crates.io-1949cf8c6b5b557f'/name
    destination=W/'inputs'/name;destination.mkdir(exist_ok=True)
    shutil.copyfile(cache,W/'inputs'/(name+'.crate'))
    record,raw=records[version];assert sha(cache.read_bytes())==record['cksum']
    (destination/'registry-index-record.json').write_bytes(raw+b'\n')
    copied={}
    with tarfile.open(cache)as archive:
        for path in ['src/lib.rs','src/syscalls.rs','Cargo.toml','Cargo.toml.orig','.cargo_vcs_info.json']:
            data=archive.extractfile(name+'/'+path).read()
            assert data==(extracted/path).read_bytes(),path
            target=destination/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            copied[path]={'bytes':len(data),'sha256':sha(data)}
    source_text[version]=(destination/'src/lib.rs').read_text()
    vcs=read(destination/'.cargo_vcs_info.json')
    metadata=(destination/'Cargo.toml').read_text()
    repository=next(line.split(' = ',1)[1].strip('"')for line in metadata.splitlines()if line.startswith('repository = '))
    crate_rows.append({'version':version,'archive_cache_path':str(cache),'archive_bytes':cache.stat().st_size,
                       'archive_sha256':sha(cache.read_bytes()),'registry_checksum_equal':True,
                       'registry_published_at':record.get('pubtime'),'registry_yanked_at_cached_snapshot':record.get('yanked'),
                       'declared_repository':repository,'declared_vcs_commit':vcs['git']['sha1'],'declared_path_in_vcs':vcs['path_in_vcs'],
                       'archive_source_equals_cache':True,'files':copied})
def block(text,needle):
    start=text.index(needle);opening=text.index('{',start);depth=0
    for at in range(opening,len(text)):
        if text[at]=='{':depth+=1
        elif text[at]=='}':
            depth-=1
            if depth==0:return text[start:at+1],text[:start].count('\n')+1,text[:at+1].count('\n')+1
    raise AssertionError(needle)
source_blocks=[]
for needle in ['impl From<u64> for PubkeyError','pub fn find_program_address','pub fn try_find_program_address','pub fn create_program_address']:
    blocks={v:block(text,needle)for v,text in source_text.items()}
    assert blocks['2.2.1'][0]==blocks['2.4.0'][0]
    source_blocks.append({'declaration':needle,'bytes':len(blocks['2.2.1'][0].encode()),'text_sha256':sha(blocks['2.2.1'][0].encode()),
                          'source_text_identical':True,'lines':{v:{'first':data[1],'last':data[2]}for v,data in blocks.items()}})
coordinate_checks=[]
for name,coordinates in [('PubkeyError::from',{'2.2.1':(131,18),'2.4.0':(134,18)}),('Pubkey::find_program_address',{'2.2.1':(612,32),'2.4.0':(802,32)})]:
    row={'site':name,'source_coordinates':{}}
    for v,(line,column)in coordinates.items():
        text=source_text[v].splitlines()[line-1];assert text.index('panic!')+1==column
        row['source_coordinates'][v]={'line':line,'column':column,'text':text}
    coordinate_checks.append(row)
line_hunks=[];before=source_text['2.2.1'].splitlines();after=source_text['2.4.0'].splitlines()
for tag,a,b,c,d in difflib.SequenceMatcher(None,before,after).get_opcodes():
    if tag!='equal'and a<612:
        line_hunks.append({'tag':tag,'old_start':a+1,'old_end':b,'new_start':c+1,'new_end':d,
                           'line_delta':(d-c)-(b-a),'old_lines':before[a:b],'new_lines':after[c:d]})
assert sum(row['line_delta']for row in line_hunks)==190
nodes=[n for n in closure['nodes']if any('Pubkey' in name and any(s in name for s in ['create_program_address','find_program_address'])for name in n['candidate_names'])]
assert len(nodes)==2
candidate=(closure_root/'inputs/candidate.so').read_bytes();original=(closure_root/'inputs/original.so').read_bytes()
targets=[t for t in closure['relocation_targets']if t['candidate_function']in {n['candidate']for n in nodes}]
assert len(targets)==4
for node in nodes:
    assert node['matched_body']and node['normalized_equal']and node['relocation_patterns_equal']
    for role,binary in [('candidate',candidate),('original',original)]:
        start=node[role];size=node[role+'_bytes'];data=binary[start:start+size]
        assert sha(data)==node[role+'_raw_sha256']
        (W/'inputs'/f'{role}-{start}.bin').write_bytes(data)
for target in targets:
    for role,binary in [('candidate',candidate),('original',original)]:
        row=target[role+'_record'];address=row['address'];pointer,length=struct.unpack_from('<QQ',binary,address)
        assert pointer>>32==row['decoded_pointer']and length==row['length']
        data=binary[pointer>>32:(pointer>>32)+length]
        assert sha(data)==row['pointee_sha256']
        if row['kind']=='source_location_record':
            line,column=struct.unpack_from('<II',binary,address+16)
            assert (line,column)==(row['line'],row['column'])
            (W/'inputs'/f'{role}-location-{address}.bin').write_bytes(binary[address:address+24])
for name in ['closure.json','manifest-sha256.json','input-sha256.json','REPORT.md']:
    shutil.copyfile(closure_root/name,W/'inputs'/('prior-'+name))
shutil.copyfile(R/'Cargo.lock',W/'inputs/Cargo.lock')
report={'scope':'Read-only two-source attribution using already cached published crates and preserved matching ELF helpers. No version enumeration, new downloads, builds, source edits or runtime tests.',
        'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'candidate_path':'repro/pump_fees/readme-provenance-v144/pump_fees_candidate.so','candidate_sha256':sha(candidate),
        'original_path':'evidence/original/pump_fees/deployed.so','original_sha256':sha(original),
        'crates':crate_rows,'coordinate_checks':coordinate_checks,'identical_source_blocks':source_blocks,
        'matching_helper_nodes':nodes,'helper_relocation_evidence':targets,
        'supported_candidate':'Published solana-pubkey 2.2.1 source, or another source revision with these same relevant lines and bodies.',
        'unique_historical_version_proven':False,'historical_dependency_graph_proven':False,'build_recipe_proposed':False,
        'limitations':['Only pinned 2.4.0 and already cached 2.2.1 sources were examined; other release/commit uniqueness was not tested.',
                       'Exact helper source blocks and coordinates do not identify other dependency inputs, features, compiler, OS, paths or flags.',
                       'Other source regions differ, including custom hashing, base58 parsing and unique-pubkey generation; a whole-crate substitution is not proved equivalent.',
                       'Existing normalized helper matches retain differing raw instructions/relocated data; no whole-program equality is claimed.']}
(W/'attribution.json').write_text(json.dumps(report,indent=2)+'\n')
(W/'line-shift-hunks.json').write_text(json.dumps(line_hunks,indent=2)+'\n')
print(json.dumps({'source_candidate':'solana-pubkey 2.2.1','exact_coordinate_pairs':2,'identical_source_blocks':4,
                  'retained_matching_helper_bytes':[n['candidate_bytes']for n in nodes],
                  'unique_historical_version_proven':False,'builds':0,'runtime_tests':0},indent=2))
