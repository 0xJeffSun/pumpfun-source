03cce8 (+0000): r9 = r3
03ccf0 (+0008): r8 = r1
03ccf8 (+0010): r3 = *(u64 *)(r5 - 0xff8)
03cd00 (+0018): if r3 == 0x0 goto +0x1c <.text+0x3ccc8> ; branch 0x3cde8 / relative 0x100
03cd08 (+0020): *(u64 *)(r10 - 0x920) = r4
03cd10 (+0028): *(u64 *)(r10 - 0x928) = r2
03cd18 (+0030): r6 = *(u64 *)(r5 - 0x1000)
03cd20 (+0038): r1 = r10
03cd28 (+0040): r1 += -0x6c8
03cd30 (+0048): r2 = r6
03cd38 (+0050): call -0x6ceb ; call 0x65e8 / window 154
03cd40 (+0058): r7 = *(u32 *)(r10 - 0x6c8)
03cd48 (+0060): if r7 == 0x3a goto +0x1 <.text+0x3cc38> ; branch 0x3cd58 / relative 0x70
03cd50 (+0068): goto +0x16 <.text+0x3cce8> ; branch 0x3ce08 / relative 0x120
03cd58 (+0070): r1 = 0x2
03cd60 (+0078): r2 = *(u8 *)(r6 + 0x0)
03cd68 (+0080): if r2 > 0x30 goto +0x8 <.text+0x3cc90> ; branch 0x3cdb0 / relative 0xc8
03cd70 (+0088): r3 = 0x1
03cd78 (+0090): r3 <<= r2
03cd80 (+0098): r2 = 0x100000001036f ll
03cd90 (+00a8): r3 &= r2
03cd98 (+00b0): if r3 != 0x0 goto +0x1 <.text+0x3cc88> ; branch 0x3cda8 / relative 0xc0
03cda0 (+00b8): goto +0x1 <.text+0x3cc90> ; branch 0x3cdb0 / relative 0xc8
03cda8 (+00c0): r1 = 0x0
03cdb0 (+00c8): r2 = 0x4b
03cdb8 (+00d0): *(u32 *)(r8 + 0x4) = r2
03cdc0 (+00d8): *(u32 *)(r8 + 0x0) = r1
03cdc8 (+00e0): r1 = r10
03cdd0 (+00e8): r1 += -0x6c8
03cdd8 (+00f0): call -0x73d9 ; call 0x2f18 / window 52
03cde0 (+00f8): goto +0x3 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03cde8 (+0100): r1 = 0xbd00000000 ll
03cdf8 (+0110): *(u64 *)(r8 + 0x0) = r1
03ce00 (+0118): exit
03ce08 (+0120): *(u64 *)(r10 - 0x930) = r8
03ce10 (+0128): r1 = *(u64 *)(r10 - 0x6b8)
03ce18 (+0130): *(u64 *)(r10 - 0x818) = r1
03ce20 (+0138): r1 = *(u64 *)(r10 - 0x6b0)
03ce28 (+0140): *(u64 *)(r10 - 0x810) = r1
03ce30 (+0148): r1 = *(u64 *)(r10 - 0x6a8)
03ce38 (+0150): *(u64 *)(r10 - 0x808) = r1
03ce40 (+0158): r6 = *(u64 *)(r10 - 0x6c4)
03ce48 (+0160): r8 = *(u32 *)(r10 - 0x6bc)
03ce50 (+0168): r1 = r10
03ce58 (+0170): r1 += -0x800
03ce60 (+0178): r2 = r10
03ce68 (+0180): r2 += -0x6a0
03ce70 (+0188): r3 = 0x138
03ce78 (+0190): call 0xb823 ; call 0x98f98 / window 1246
03ce80 (+0198): *(u32 *)(r10 - 0x81c) = r8
03ce88 (+01a0): *(u64 *)(r10 - 0x824) = r6
03ce90 (+01a8): *(u32 *)(r10 - 0x828) = r7
03ce98 (+01b0): r1 = *(u64 *)(r10 - 0x928)
03cea0 (+01b8): *(u64 *)(r10 - 0x6c8) = r1
03cea8 (+01c0): r1 = r10
03ceb0 (+01c8): r1 += -0x838
03ceb8 (+01d0): *(u64 *)(r10 - 0x938) = r9
03cec0 (+01d8): r2 = r9
03cec8 (+01e0): r3 = *(u64 *)(r10 - 0x920)
03ced0 (+01e8): call 0x76f9 ; call 0x786a0 / window 802
03ced8 (+01f0): r1 = r10
03cee0 (+01f8): r1 += -0x820
03cee8 (+0200): *(u64 *)(r10 - 0x940) = r1
03cef0 (+0208): r1 = r10
03cef8 (+0210): r1 += -0x818
03cf00 (+0218): *(u64 *)(r10 - 0x948) = r1
03cf08 (+0220): r9 = *(u64 *)(r10 - 0x838)
03cf10 (+0228): r6 = *(u64 *)(r10 - 0x830)
03cf18 (+0230): r6 += 0x18
03cf20 (+0238): r8 = 0x3
03cf28 (+0240): r7 = r6
03cf30 (+0248): r7 += -0x18
03cf38 (+0250): if r7 == r9 goto +0x23 <.text+0x3cf38> ; branch 0x3d058 / relative 0x370
03cf40 (+0258): r2 = r10
03cf48 (+0260): r2 += -0x6c8
03cf50 (+0268): r1 = r6
03cf58 (+0270): call -0x7455 ; call 0x2cb8 / window 41
03cf60 (+0278): if r0 == 0x0 goto +0x1c <.text+0x3cf28> ; branch 0x3d048 / relative 0x360
03cf68 (+0280): r1 = r7
03cf70 (+0288): call 0x904d ; call 0x851e0 / window 981
03cf78 (+0290): if r0 != 0x0 goto +0x19 <.text+0x3cf28> ; branch 0x3d048 / relative 0x360
03cf80 (+0298): r2 = *(u64 *)(r6 - 0x8)
03cf88 (+02a0): r2 += 0x10
03cf90 (+02a8): r1 = r10
03cf98 (+02b0): r1 += -0x848
03cfa0 (+02b8): r3 = 0x9f3d0 ll ; pointer 0x9f3d0; data32hex 00000000cea909001c00000000000000880100002a00000000000000cea90900
03cfb0 (+02c8): call -0x72db ; call 0x38e0 / window 87
03cfb8 (+02d0): r3 = *(u64 *)(r10 - 0x848)
03cfc0 (+02d8): r2 = *(u64 *)(r3 + 0x8)
03cfc8 (+02e0): if r2 == 0x0 goto +0x2b0 <.text+0x3e430> ; branch 0x3e550 / relative 0x1868
03cfd0 (+02e8): r1 = *(u64 *)(r10 - 0x840)
03cfd8 (+02f0): r3 = *(u64 *)(r3 + 0x0)
03cfe0 (+02f8): r4 = *(u8 *)(r3 + 0x0)
03cfe8 (+0300): if r4 == 0xb goto +0x1 <.text+0x3ced8> ; branch 0x3cff8 / relative 0x310
03cff0 (+0308): goto +0x7 <.text+0x3cf10> ; branch 0x3d030 / relative 0x348
03cff8 (+0310): if r8 > r2 goto +0x2af <.text+0x3e458> ; branch 0x3e578 / relative 0x1890
03d000 (+0318): r2 = *(u8 *)(r3 + 0x2)
03d008 (+0320): r3 = *(u64 *)(r1 + 0x0)
03d010 (+0328): r3 += -0x1
03d018 (+0330): *(u64 *)(r1 + 0x0) = r3
03d020 (+0338): if r2 == 0x1 goto +0x6 <.text+0x3cf38> ; branch 0x3d058 / relative 0x370
03d028 (+0340): goto +0x3 <.text+0x3cf28> ; branch 0x3d048 / relative 0x360
03d030 (+0348): r2 = *(u64 *)(r1 + 0x0)
03d038 (+0350): r2 += -0x1
03d040 (+0358): *(u64 *)(r1 + 0x0) = r2
03d048 (+0360): r6 += 0x30
03d050 (+0368): goto -0x26 <.text+0x3ce08> ; branch 0x3cf28 / relative 0x240
03d058 (+0370): r1 = *(u32 *)(r10 - 0x828)
03d060 (+0378): if r7 == r9 goto +0x1 <.text+0x3cf50> ; branch 0x3d070 / relative 0x388
03d068 (+0380): if r1 != 0x2f goto +0x41 <.text+0x3d158> ; branch 0x3d278 / relative 0x590
03d070 (+0388): if r1 == 0x29 goto +0xc4 <.text+0x3d578> ; branch 0x3d698 / relative 0x9b0
03d078 (+0390): r8 = *(u64 *)(r10 - 0x930)
03d080 (+0398): r9 = *(u64 *)(r10 - 0x938)
03d088 (+03a0): if r1 == 0x2a goto +0x50 <.text+0x3d1f0> ; branch 0x3d310 / relative 0x628
03d090 (+03a8): if r1 == 0x2b goto +0x1bf <.text+0x3dd70> ; branch 0x3de90 / relative 0x11a8
03d098 (+03b0): if r1 == 0x2c goto +0x87 <.text+0x3d3b8> ; branch 0x3d4d8 / relative 0x7f0
03d0a0 (+03b8): if r1 == 0x2d goto +0x65 <.text+0x3d2b0> ; branch 0x3d3d0 / relative 0x6e8
03d0a8 (+03c0): if r1 == 0x2e goto +0x70 <.text+0x3d310> ; branch 0x3d430 / relative 0x748
03d0b0 (+03c8): if r1 == 0x2f goto +0x1d5 <.text+0x3de40> ; branch 0x3df60 / relative 0x1278
03d0b8 (+03d0): if r1 == 0x30 goto +0x1d1 <.text+0x3de28> ; branch 0x3df48 / relative 0x1260
03d0c0 (+03d8): if r1 == 0x31 goto +0xa7 <.text+0x3d4e0> ; branch 0x3d600 / relative 0x918
03d0c8 (+03e0): if r1 == 0x32 goto +0x1a5 <.text+0x3dcd8> ; branch 0x3ddf8 / relative 0x1110
03d0d0 (+03e8): if r1 == 0x34 goto +0x18c <.text+0x3dc18> ; branch 0x3dd38 / relative 0x1050
03d0d8 (+03f0): if r1 == 0x35 goto +0x197 <.text+0x3dc78> ; branch 0x3dd98 / relative 0x10b0
03d0e0 (+03f8): if r1 == 0x36 goto +0xcc <.text+0x3d628> ; branch 0x3d748 / relative 0xa60
03d0e8 (+0400): if r1 == 0x37 goto +0x93 <.text+0x3d468> ; branch 0x3d588 / relative 0x8a0
03d0f0 (+0408): if r1 == 0x38 goto +0xc1 <.text+0x3d5e0> ; branch 0x3d700 / relative 0xa18
03d0f8 (+0410): if r1 == 0x39 goto +0x1 <.text+0x3cfe8> ; branch 0x3d108 / relative 0x420
03d100 (+0418): goto +0x1df <.text+0x3dee0> ; branch 0x3e000 / relative 0x1318
03d108 (+0420): r1 = 0x9a9ea ll ; pointer 0x9a9ea; data32hex 49583a20436c6f7365204163636f756e747349583a20526573697a6549583a20
03d118 (+0430): r2 = 0x12
03d120 (+0438): call -0x1 ; external sol_log_
03d128 (+0440): r1 = 0x5
03d130 (+0448): r2 = *(u64 *)(r10 - 0x920)
03d138 (+0450): if r1 > r2 goto +0x265 <.text+0x3e348> ; branch 0x3e468 / relative 0x1780
03d140 (+0458): r1 = r10
03d148 (+0460): r1 += -0x6c8
03d150 (+0468): r2 = r9
03d158 (+0470): r3 = 0x999c8 ll ; pointer 0x999c8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03d168 (+0480): call -0x5aa8 ; call 0xfc30 / window 275
03d170 (+0488): r1 = *(u32 *)(r10 - 0x6c8)
03d178 (+0490): if r1 == 0x16 goto +0x1 <.text+0x3d068> ; branch 0x3d188 / relative 0x4a0
03d180 (+0498): goto +0x252 <.text+0x3e2f8> ; branch 0x3e418 / relative 0x1730
03d188 (+04a0): r6 = r9
03d190 (+04a8): r9 += 0x60
03d198 (+04b0): r1 = r9
03d1a0 (+04b8): call 0x9007 ; call 0x851e0 / window 981
03d1a8 (+04c0): if r0 != 0x0 goto +0x1 <.text+0x3d098> ; branch 0x3d1b8 / relative 0x4d0
03d1b0 (+04c8): goto +0x259 <.text+0x3e360> ; branch 0x3e480 / relative 0x1798
03d1b8 (+04d0): r1 = r6
03d1c0 (+04d8): r1 += 0x78
03d1c8 (+04e0): r2 = 0x9ed68 ll ; pointer 0x9ed68; data32hex 00000000e899090000000000c89a09000000000018a409002200000000000000
03d1d8 (+04f0): call -0x74a5 ; call 0x2cb8 / window 41
03d1e0 (+04f8): r7 = 0x1
03d1e8 (+0500): if r0 == 0x0 goto +0x252 <.text+0x3e360> ; branch 0x3e480 / relative 0x1798
03d1f0 (+0508): r6 += 0x90
03d1f8 (+0510): r1 = r10
03d200 (+0518): r1 += -0x6c8
03d208 (+0520): r2 = r6
03d210 (+0528): call 0x7296 ; call 0x766c8 / window 773
03d218 (+0530): r1 = *(u32 *)(r10 - 0x6c8)
03d220 (+0538): if r1 == 0x16 goto +0x1 <.text+0x3d110> ; branch 0x3d230 / relative 0x548
03d228 (+0540): goto +0x256 <.text+0x3e3c0> ; branch 0x3e4e0 / relative 0x17f8
03d230 (+0548): r1 = *(u64 *)(r6 + 0x0)
03d238 (+0550): r2 = 0x99928 ll ; pointer 0x99928; data32hex a3a58e4c1ed793790e47a3fcb85ca0eb51391e8c227ff80def9440974ff283f8
03d248 (+0560): call -0x74a8 ; call 0x2d10 / window 44
03d250 (+0568): if r0 != 0x0 goto +0x1 <.text+0x3d140> ; branch 0x3d260 / relative 0x578
03d258 (+0570): goto +0x2e7 <.text+0x3e878> ; branch 0x3e998 / relative 0x1cb0
03d260 (+0578): r1 = 0xbc00000000 ll
03d270 (+0588): goto +0x274 <.text+0x3e4f8> ; branch 0x3e618 / relative 0x1930
03d278 (+0590): r2 = 0x9b00000000 ll
03d288 (+05a0): r3 = *(u64 *)(r10 - 0x930)
03d290 (+05a8): *(u64 *)(r3 + 0x0) = r2
03d298 (+05b0): r2 = r1
03d2a0 (+05b8): r2 += -0x34
03d2a8 (+05c0): r3 = 0x2
03d2b0 (+05c8): if r3 > r2 goto -0x97 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03d2b8 (+05d0): if r1 == 0x29 goto -0x98 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03d2c0 (+05d8): if r1 == 0x2a goto +0x29a <.text+0x3e678> ; branch 0x3e798 / relative 0x1ab0
03d2c8 (+05e0): if r1 == 0x2b goto +0x28b <.text+0x3e608> ; branch 0x3e728 / relative 0x1a40
03d2d0 (+05e8): if r1 == 0x2c goto +0x29d <.text+0x3e6a0> ; branch 0x3e7c0 / relative 0x1ad8
03d2d8 (+05f0): if r1 == 0x2d goto -0x9c <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03d2e0 (+05f8): if r1 == 0x2e goto +0x291 <.text+0x3e650> ; branch 0x3e770 / relative 0x1a88
03d2e8 (+0600): if r1 == 0x2f goto +0x290 <.text+0x3e650> ; branch 0x3e770 / relative 0x1a88
03d2f0 (+0608): if r1 == 0x31 goto +0x286 <.text+0x3e608> ; branch 0x3e728 / relative 0x1a40
03d2f8 (+0610): if r1 == 0x32 goto +0x289 <.text+0x3e628> ; branch 0x3e748 / relative 0x1a60
03d300 (+0618): if r1 == 0x37 goto -0xa1 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03d308 (+0620): goto +0x279 <.text+0x3e5b8> ; branch 0x3e6d8 / relative 0x19f0
03d310 (+0628): r1 = 0x9aa5b ll ; pointer 0x9aa5b; data32hex 49583a2043726561746549583a205472616e73666572204f7574204f66204573
03d320 (+0638): r2 = 0xa
03d328 (+0640): call -0x1 ; external sol_log_
03d330 (+0648): r6 = r10
03d338 (+0650): r6 += -0x6c8
03d340 (+0658): r1 = r6
03d348 (+0660): r2 = *(u64 *)(r10 - 0x940)
03d350 (+0668): r3 = 0x108
03d358 (+0670): call 0xb787 ; call 0x98f98 / window 1246
03d360 (+0678): r1 = r8
03d368 (+0680): r2 = *(u64 *)(r10 - 0x928)
03d370 (+0688): r3 = r9
03d378 (+0690): r4 = *(u64 *)(r10 - 0x920)
03d380 (+0698): r5 = r6
03d388 (+06a0): call -0x2914 ; call 0x28af0 / window 321
03d390 (+06a8): r6 = 0x0
03d398 (+06b0): r1 = 0x1
03d3a0 (+06b8): r2 = 0x1
03d3a8 (+06c0): r3 = 0x1
03d3b0 (+06c8): r4 = 0x1
03d3b8 (+06d0): r5 = 0x1
03d3c0 (+06d8): r0 = 0x1
03d3c8 (+06e0): goto +0x252 <.text+0x3e540> ; branch 0x3e660 / relative 0x1978
03d3d0 (+06e8): r6 = *(u32 *)(r10 - 0x820)
03d3d8 (+06f0): r1 = 0x9aa45 ll ; pointer 0x9aa45; data32hex 49583a205265766f6b6549583a2044656c656761746549583a20437265617465
03d3e8 (+0700): r2 = 0xa
03d3f0 (+0708): call -0x1 ; external sol_log_
03d3f8 (+0710): r1 = r8
03d400 (+0718): r2 = *(u64 *)(r10 - 0x928)
03d408 (+0720): r3 = r9
03d410 (+0728): r4 = *(u64 *)(r10 - 0x920)
03d418 (+0730): r5 = r6
03d420 (+0738): call -0x39bd ; call 0x20640 / window 313
03d428 (+0740): goto +0x23f <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03d430 (+0748): r1 = 0x9a200 ll ; pointer 0x9a200; data32hex 49583a204c6f636b44656c65676174656d65746164617461646561646c6f636b
03d440 (+0758): r2 = 0x8
03d448 (+0760): call -0x1 ; external sol_log_
03d450 (+0768): r6 = r10
03d458 (+0770): r6 += -0x6c8
03d460 (+0778): r1 = r6
03d468 (+0780): r2 = *(u64 *)(r10 - 0x940)
03d470 (+0788): r3 = 0x38
03d478 (+0790): call 0xb763 ; call 0x98f98 / window 1246
03d480 (+0798): r1 = r8
03d488 (+07a0): r2 = *(u64 *)(r10 - 0x928)
03d490 (+07a8): r3 = r9
03d498 (+07b0): r4 = *(u64 *)(r10 - 0x920)
03d4a0 (+07b8): r5 = r6
03d4a8 (+07c0): call -0xe13 ; call 0x36418 / window 341
03d4b0 (+07c8): r4 = 0x0
03d4b8 (+07d0): r1 = 0x1
03d4c0 (+07d8): r2 = 0x1
03d4c8 (+07e0): r3 = 0x1
03d4d0 (+07e8): goto +0x22e <.text+0x3e528> ; branch 0x3e648 / relative 0x1960
03d4d8 (+07f0): r1 = 0x9aa4f ll ; pointer 0x9aa4f; data32hex 49583a2044656c656761746549583a2043726561746549583a205472616e7366
03d4e8 (+0800): r2 = 0xc
03d4f0 (+0808): call -0x1 ; external sol_log_
03d4f8 (+0810): r6 = r10
03d500 (+0818): r6 += -0x6c8
03d508 (+0820): r1 = r6
03d510 (+0828): r2 = *(u64 *)(r10 - 0x940)
03d518 (+0830): r3 = 0x60
03d520 (+0838): call 0xb74e ; call 0x98f98 / window 1246
03d528 (+0840): r1 = r8
03d530 (+0848): r2 = *(u64 *)(r10 - 0x928)
03d538 (+0850): r3 = r9
03d540 (+0858): r4 = *(u64 *)(r10 - 0x920)
03d548 (+0860): r5 = r6
03d550 (+0868): call -0x4027 ; call 0x1d420 / window 311
03d558 (+0870): r5 = 0x0
03d560 (+0878): r1 = 0x1
03d568 (+0880): r2 = 0x1
03d570 (+0888): r3 = 0x1
03d578 (+0890): r4 = 0x1
03d580 (+0898): goto +0x219 <.text+0x3e530> ; branch 0x3e650 / relative 0x1968
03d588 (+08a0): r6 = *(u64 *)(r10 - 0x818)
03d590 (+08a8): r7 = *(u32 *)(r10 - 0x820)
03d598 (+08b0): r1 = 0x9aa06 ll ; pointer 0x9aa06; data32hex 49583a205072696e7449583a20556e76657269667949583a2056657269667949
03d5a8 (+08c0): r2 = 0x9
03d5b0 (+08c8): call -0x1 ; external sol_log_
03d5b8 (+08d0): *(u64 *)(r10 - 0x1000) = r7
03d5c0 (+08d8): *(u64 *)(r10 - 0xff8) = r6
03d5c8 (+08e0): r5 = r10
03d5d0 (+08e8): r1 = r8
03d5d8 (+08f0): r2 = *(u64 *)(r10 - 0x928)
03d5e0 (+08f8): r3 = r9
03d5e8 (+0900): r4 = *(u64 *)(r10 - 0x920)
03d5f0 (+0908): call -0x22bb ; call 0x2c020 / window 325
03d5f8 (+0910): goto +0x205 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03d600 (+0918): r1 = 0x9aa2f ll ; pointer 0x9aa2f; data32hex 49583a205472616e7366657249583a20556e6c6f636b49583a205265766f6b65
03d610 (+0928): r2 = 0xc
03d618 (+0930): call -0x1 ; external sol_log_
03d620 (+0938): r6 = r10
03d628 (+0940): r6 += -0x6c8
03d630 (+0948): r1 = r6
03d638 (+0950): r2 = *(u64 *)(r10 - 0x940)
03d640 (+0958): r3 = 0x40
03d648 (+0960): call 0xb729 ; call 0x98f98 / window 1246
03d650 (+0968): r1 = r8
03d658 (+0970): r2 = *(u64 *)(r10 - 0x928)
03d660 (+0978): r3 = r9
03d668 (+0980): r4 = *(u64 *)(r10 - 0x920)
03d670 (+0988): r5 = r6
03d678 (+0990): call -0x1c10 ; call 0x2f600 / window 335
03d680 (+0998): r2 = 0x0
03d688 (+09a0): r1 = 0x1
03d690 (+09a8): goto +0x1f4 <.text+0x3e518> ; branch 0x3e638 / relative 0x1950
03d698 (+09b0): r6 = *(u64 *)(r10 - 0x818)
03d6a0 (+09b8): r1 = 0x9a1b8 ll ; pointer 0x9a1b8; data32hex 49583a204275726e4370694775617264446561646c6f636b4e6f74466f756e64
03d6b0 (+09c8): r2 = 0x8
03d6b8 (+09d0): call -0x1 ; external sol_log_
03d6c0 (+09d8): *(u64 *)(r10 - 0xff8) = r6
03d6c8 (+09e0): r5 = r10
03d6d0 (+09e8): r1 = *(u64 *)(r10 - 0x930)
03d6d8 (+09f0): r2 = *(u64 *)(r10 - 0x928)
03d6e0 (+09f8): r3 = *(u64 *)(r10 - 0x938)
03d6e8 (+0a00): r4 = *(u64 *)(r10 - 0x920)
03d6f0 (+0a08): call -0x57e1 ; call 0x117f0 / window 296
03d6f8 (+0a10): goto +0x1e5 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03d700 (+0a18): r1 = 0x9a9fc ll ; pointer 0x9a9fc; data32hex 49583a20526573697a6549583a205072696e7449583a20556e76657269667949
03d710 (+0a28): r2 = 0xa
03d718 (+0a30): call -0x1 ; external sol_log_
03d720 (+0a38): r1 = r8
03d728 (+0a40): r3 = r9
03d730 (+0a48): r4 = *(u64 *)(r10 - 0x920)
03d738 (+0a50): call -0x10aa ; call 0x351f0 / window 340
03d740 (+0a58): goto +0x1dc <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03d748 (+0a60): r1 = *(u64 *)(r10 - 0x928)
03d750 (+0a68): *(u64 *)(r10 - 0x568) = r1
03d758 (+0a70): *(u64 *)(r10 - 0x360) = r9
03d760 (+0a78): r1 = *(u64 *)(r10 - 0x920)
03d768 (+0a80): r1 *= 0x30
03d770 (+0a88): r9 += r1
03d778 (+0a90): *(u64 *)(r10 - 0x368) = r9
03d780 (+0a98): r1 = r10
03d788 (+0aa0): r1 += -0x6c8
03d790 (+0aa8): r2 = r10
03d798 (+0ab0): r2 += -0x368
03d7a0 (+0ab8): call 0x89b8 ; call 0x82568 / window 881
03d7a8 (+0ac0): r1 = *(u32 *)(r10 - 0x6c8)
03d7b0 (+0ac8): if r1 != 0x16 goto +0x183 <.text+0x3e2b0> ; branch 0x3e3d0 / relative 0x16e8
03d7b8 (+0ad0): r6 = *(u64 *)(r10 - 0x6c0)
03d7c0 (+0ad8): r1 = r10
03d7c8 (+0ae0): r1 += -0x6c8
03d7d0 (+0ae8): r2 = r6
03d7d8 (+0af0): call 0x71dd ; call 0x766c8 / window 773
03d7e0 (+0af8): r1 = *(u32 *)(r10 - 0x6c8)
03d7e8 (+0b00): if r1 == 0x16 goto +0x1 <.text+0x3d6d8> ; branch 0x3d7f8 / relative 0xb10
03d7f0 (+0b08): goto +0x184 <.text+0x3e2f8> ; branch 0x3e418 / relative 0x1730
03d7f8 (+0b10): r1 = *(u64 *)(r6 + 0x0)
03d800 (+0b18): r2 = 0x99848 ll ; pointer 0x99848; data32hex 0508ec7b72c55f8e93b1ddeaa5430a586a71dd99c930a32917770924ce7191ea
03d810 (+0b28): call -0x7561 ; call 0x2d10 / window 44
03d818 (+0b30): if r0 != 0x0 goto +0x1a3 <.text+0x3e418> ; branch 0x3e538 / relative 0x1850
03d820 (+0b38): r1 = r10
03d828 (+0b40): r1 += -0x6c8
03d830 (+0b48): r2 = r10
03d838 (+0b50): r2 += -0x368
03d840 (+0b58): call 0x89a4 ; call 0x82568 / window 881
03d848 (+0b60): r1 = *(u32 *)(r10 - 0x6c8)
03d850 (+0b68): if r1 == 0x16 goto +0x1 <.text+0x3d740> ; branch 0x3d860 / relative 0xb78
03d858 (+0b70): goto +0x16e <.text+0x3e2b0> ; branch 0x3e3d0 / relative 0x16e8
03d860 (+0b78): r1 = *(u64 *)(r10 - 0x6c0)
03d868 (+0b80): *(u64 *)(r10 - 0x938) = r1
03d870 (+0b88): r1 = *(u64 *)(r1 + 0x0)
03d878 (+0b90): r2 = 0x99948 ll ; pointer 0x99948; data32hex 18be35e87ce34452616c90e106e97a0043af8fc70d41525c347dfeb4bee1df89
03d888 (+0ba0): call -0x7570 ; call 0x2d10 / window 44
03d890 (+0ba8): if r0 != 0x0 goto +0x22c <.text+0x3e8d8> ; branch 0x3e9f8 / relative 0x1d10
03d898 (+0bb0): r6 = *(u64 *)(r10 - 0x360)
03d8a0 (+0bb8): r1 = *(u64 *)(r10 - 0x368)
03d8a8 (+0bc0): if r6 != r1 goto +0x1 <.text+0x3d798> ; branch 0x3d8b8 / relative 0xbd0
03d8b0 (+0bc8): goto +0x43a <.text+0x3f968> ; branch 0x3fa88 / relative 0x2da0
03d8b8 (+0bd0): r1 = r6
03d8c0 (+0bd8): r1 += 0x30
03d8c8 (+0be0): *(u64 *)(r10 - 0x360) = r1
03d8d0 (+0be8): r1 = r6
03d8d8 (+0bf0): r1 += 0x18
03d8e0 (+0bf8): r2 = r10
03d8e8 (+0c00): r2 += -0x568
03d8f0 (+0c08): call -0x7584 ; call 0x2cd8 / window 42
03d8f8 (+0c10): if r0 != 0x0 goto +0x21f <.text+0x3e8d8> ; branch 0x3e9f8 / relative 0x1d10
03d900 (+0c18): *(u64 *)(r10 - 0x920) = r6
03d908 (+0c20): r2 = *(u64 *)(r6 + 0x10)
03d910 (+0c28): r2 += 0x10
03d918 (+0c30): r1 = r10
03d920 (+0c38): r1 += -0x888
03d928 (+0c40): r3 = 0x9f088 ll ; pointer 0x9f088; data32hex 00000000889a090020000000000000002a0000002600000000000000889a0900
03d938 (+0c50): call -0x740c ; call 0x38e0 / window 87
03d940 (+0c58): r2 = *(u64 *)(r10 - 0x888)
03d948 (+0c60): r3 = *(u64 *)(r2 + 0x8)
03d950 (+0c68): r1 = 0x9a14d ll ; pointer 0x9a14d; data32hex 00496e76616c6964204f7074696f6e20726570726573656e746174696f6e3a20
03d960 (+0c78): if r3 == 0x0 goto +0x1 <.text+0x3d850> ; branch 0x3d970 / relative 0xc88
03d968 (+0c80): r1 = *(u64 *)(r2 + 0x0)
03d970 (+0c88): r1 = *(u8 *)(r1 + 0x0)
03d978 (+0c90): r6 = *(u64 *)(r10 - 0x880)
03d980 (+0c98): call -0x7a1c ; call 0x8a8 / window 11
03d988 (+0ca0): r7 = r0
03d990 (+0ca8): r1 = *(u64 *)(r6 + 0x0)
03d998 (+0cb0): r1 += -0x1
03d9a0 (+0cb8): *(u64 *)(r6 + 0x0) = r1
03d9a8 (+0cc0): r8 = 0xbf
03d9b0 (+0cc8): r9 = 0x0
03d9b8 (+0cd0): r7 <<= 0x20
03d9c0 (+0cd8): r7 >>= 0x20
03d9c8 (+0ce0): if r7 == 0xf goto +0x3e9 <.text+0x3f7f8> ; branch 0x3f918 / relative 0x2c30
03d9d0 (+0ce8): r1 = r10
03d9d8 (+0cf0): r1 += -0x6c8
03d9e0 (+0cf8): call 0x99a1 ; call 0x8a6f0 / window 1033
03d9e8 (+0d00): r9 = *(u32 *)(r10 - 0x6c8)
03d9f0 (+0d08): if r9 != 0x16 goto +0x3e0 <.text+0x3f7d8> ; branch 0x3f8f8 / relative 0x2c10
03d9f8 (+0d10): r1 = *(u64 *)(r10 - 0x6b0)
03da00 (+0d18): *(u64 *)(r10 - 0x120) = r1
03da08 (+0d20): r1 = *(u64 *)(r10 - 0x6b8)
03da10 (+0d28): *(u64 *)(r10 - 0x128) = r1
03da18 (+0d30): r1 = *(u64 *)(r10 - 0x6c0)
03da20 (+0d38): *(u64 *)(r10 - 0x130) = r1
03da28 (+0d40): r6 = *(u64 *)(r10 - 0x920)
03da30 (+0d48): r1 = r6
03da38 (+0d50): call 0x8ee6 ; call 0x85170 / window 980
03da40 (+0d58): r1 = r10
03da48 (+0d60): r1 += -0x130
03da50 (+0d68): r2 = r0
03da58 (+0d70): call 0x939e ; call 0x87750 / window 1009
03da60 (+0d78): *(u64 *)(r10 - 0x928) = r0
03da68 (+0d80): if r7 == 0x0 goto +0xd <.text+0x3d9b8> ; branch 0x3dad8 / relative 0xdf0
03da70 (+0d88): r8 = 0xbf
03da78 (+0d90): r9 = 0x0
03da80 (+0d98): if r7 == 0x4 goto +0x1 <.text+0x3d970> ; branch 0x3da90 / relative 0xda8
03da88 (+0da0): goto +0x3d1 <.text+0x3f7f8> ; branch 0x3f918 / relative 0x2c30
03da90 (+0da8): r1 = *(u64 *)(r10 - 0x920)
03da98 (+0db0): call 0x8ec1 ; call 0x850a8 / window 979
03daa0 (+0db8): r6 = r0
03daa8 (+0dc0): r8 = 0x33
03dab0 (+0dc8): r4 = *(u64 *)(r10 - 0x928)
03dab8 (+0dd0): if r4 > r6 goto +0x3cb <.text+0x3f7f8> ; branch 0x3f918 / relative 0x2c30
03dac0 (+0dd8): r1 = *(u64 *)(r10 - 0x928)
03dac8 (+0de0): r6 -= r1
03dad0 (+0de8): goto +0x9 <.text+0x3da00> ; branch 0x3db20 / relative 0xe38
03dad8 (+0df0): r1 = r6
03dae0 (+0df8): r2 = 0x999e8 ll ; pointer 0x999e8; data32hex 0000000000000000000000000000000000000000000000000000000000000000
03daf0 (+0e08): call 0x8f84 ; call 0x85718 / window 988
03daf8 (+0e10): r1 = r6
03db00 (+0e18): call 0x8eb4 ; call 0x850a8 / window 979
03db08 (+0e20): r6 = r0
03db10 (+0e28): r1 = 0x0
03db18 (+0e30): *(u64 *)(r10 - 0x928) = r1
03db20 (+0e38): r1 = *(u64 *)(r10 - 0x938)
03db28 (+0e40): call 0x8eaf ; call 0x850a8 / window 979
03db30 (+0e48): r7 = r0
03db38 (+0e50): r7 += r6
03db40 (+0e58): r9 = 0x0
03db48 (+0e60): r4 = 0x1
03db50 (+0e68): if r0 > r7 goto +0x1 <.text+0x3da40> ; branch 0x3db60 / relative 0xe78
03db58 (+0e70): r4 = 0x0
03db60 (+0e78): r8 = 0x33
03db68 (+0e80): r4 &= 0x1
03db70 (+0e88): if r4 != 0x0 goto +0x3b4 <.text+0x3f7f8> ; branch 0x3f918 / relative 0x2c30
03db78 (+0e90): r1 = *(u64 *)(r10 - 0x938)
03db80 (+0e98): r2 = *(u64 *)(r1 + 0x8)
03db88 (+0ea0): r2 += 0x10
03db90 (+0ea8): r1 = r10
03db98 (+0eb0): r1 += -0x898
03dba0 (+0eb8): r3 = 0x9f0a0 ll ; pointer 0x9f0a0; data32hex 00000000889a09002000000000000000480000001a00000000000000889a0900
03dbb0 (+0ec8): call -0x746d ; call 0x3850 / window 86
03dbb8 (+0ed0): r1 = *(u64 *)(r10 - 0x898)
03dbc0 (+0ed8): r1 = *(u64 *)(r1 + 0x0)
03dbc8 (+0ee0): r2 = *(u64 *)(r10 - 0x890)
03dbd0 (+0ee8): *(u64 *)(r1 + 0x0) = r7
03dbd8 (+0ef0): r1 = *(u64 *)(r2 + 0x0)
03dbe0 (+0ef8): r1 += 0x1
03dbe8 (+0f00): *(u64 *)(r2 + 0x0) = r1
03dbf0 (+0f08): r6 = *(u64 *)(r10 - 0x920)
03dbf8 (+0f10): r2 = *(u64 *)(r6 + 0x8)
03dc00 (+0f18): r2 += 0x10
03dc08 (+0f20): r1 = r10
03dc10 (+0f28): r1 += -0x8a8
03dc18 (+0f30): r3 = 0x9f0b8 ll ; pointer 0x9f0b8; data32hex 00000000889a090020000000000000004b0000001d000000000000001ba70900
03dc28 (+0f40): call -0x747c ; call 0x3850 / window 86
03dc30 (+0f48): r1 = *(u64 *)(r10 - 0x8a8)
03dc38 (+0f50): r1 = *(u64 *)(r1 + 0x0)
03dc40 (+0f58): r2 = *(u64 *)(r10 - 0x8a0)
03dc48 (+0f60): r3 = *(u64 *)(r10 - 0x928)
03dc50 (+0f68): *(u64 *)(r1 + 0x0) = r3
03dc58 (+0f70): r1 = *(u64 *)(r2 + 0x0)
03dc60 (+0f78): r1 += 0x1
03dc68 (+0f80): *(u64 *)(r2 + 0x0) = r1
03dc70 (+0f88): r1 = r6
03dc78 (+0f90): call 0x8e9e ; call 0x85170 / window 980
03dc80 (+0f98): r6 = r0
03dc88 (+0fa0): if r6 == 0x0 goto +0x391 <.text+0x3f7f8> ; branch 0x3f918 / relative 0x2c30
03dc90 (+0fa8): r1 = r10
03dc98 (+0fb0): r1 += -0x6c8
03dca0 (+0fb8): r2 = *(u64 *)(r10 - 0x920)
03dca8 (+0fc0): call 0x8f00 ; call 0x854b0 / window 986
03dcb0 (+0fc8): r9 = *(u32 *)(r10 - 0x6c8)
03dcb8 (+0fd0): if r9 != 0x16 goto +0x387 <.text+0x3f7d8> ; branch 0x3f8f8 / relative 0x2c10
03dcc0 (+0fd8): r6 += -0x1
03dcc8 (+0fe0): r1 = *(u64 *)(r10 - 0x6b8)
03dcd0 (+0fe8): r2 = *(u64 *)(r10 - 0x6c0)
03dcd8 (+0ff0): r3 = *(u64 *)(r2 + 0x8)
03dce0 (+0ff8): if r3 > r6 goto +0x1 <.text+0x3dbd0> ; branch 0x3dcf0 / relative 0x1008
03dce8 (+1000): goto +0x4 <.text+0x3dbf0> ; branch 0x3dd10 / relative 0x1028
03dcf0 (+1008): r2 = *(u64 *)(r2 + 0x0)
03dcf8 (+1010): r2 += r6
03dd00 (+1018): r3 = 0x0
03dd08 (+1020): *(u8 *)(r2 + 0x0) = r3
03dd10 (+1028): r2 = *(u64 *)(r1 + 0x0)
03dd18 (+1030): r2 += 0x1
03dd20 (+1038): *(u64 *)(r1 + 0x0) = r2
03dd28 (+1040): r8 = *(u64 *)(r10 - 0x930)
03dd30 (+1048): goto -0x94 <.text+0x3d778> ; branch 0x3d898 / relative 0xbb0
03dd38 (+1050): r6 = *(u32 *)(r10 - 0x820)
03dd40 (+1058): r1 = 0x9aa1b ll ; pointer 0x9aa1b; data32hex 49583a2056657269667949583a2055706461746549583a205472616e73666572
03dd50 (+1068): r2 = 0xa
03dd58 (+1070): call -0x1 ; external sol_log_
03dd60 (+1078): r1 = r8
03dd68 (+1080): r2 = *(u64 *)(r10 - 0x928)
03dd70 (+1088): r3 = r9
03dd78 (+1090): r4 = *(u64 *)(r10 - 0x920)
03dd80 (+1098): r5 = r6
03dd88 (+10a0): call -0x58f ; call 0x3b118 / window 348
03dd90 (+10a8): goto +0x112 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03dd98 (+10b0): r6 = *(u32 *)(r10 - 0x820)
03dda0 (+10b8): r1 = 0x9aa0f ll ; pointer 0x9aa0f; data32hex 49583a20556e76657269667949583a2056657269667949583a20557064617465
03ddb0 (+10c8): r2 = 0xc
03ddb8 (+10d0): call -0x1 ; external sol_log_
03ddc0 (+10d8): r1 = r8
03ddc8 (+10e0): r2 = *(u64 *)(r10 - 0x928)
03ddd0 (+10e8): r3 = r9
03ddd8 (+10f0): r4 = *(u64 *)(r10 - 0x920)
03dde0 (+10f8): r5 = r6
03dde8 (+1100): call -0x404 ; call 0x3bdd0 / window 349
03ddf0 (+1108): goto +0x106 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03ddf8 (+1110): r1 = 0x9aa25 ll ; pointer 0x9aa25; data32hex 49583a2055706461746549583a205472616e7366657249583a20556e6c6f636b
03de08 (+1120): r2 = 0xa
03de10 (+1128): call -0x1 ; external sol_log_
03de18 (+1130): r6 = r10
03de20 (+1138): r6 += -0x6c8
03de28 (+1140): r1 = r6
03de30 (+1148): r2 = *(u64 *)(r10 - 0x940)
03de38 (+1150): r3 = 0x158
03de40 (+1158): call 0xb62a ; call 0x98f98 / window 1246
03de48 (+1160): r1 = r8
03de50 (+1168): r2 = *(u64 *)(r10 - 0x928)
03de58 (+1170): r3 = r9
03de60 (+1178): r4 = *(u64 *)(r10 - 0x920)
03de68 (+1180): r5 = r6
03de70 (+1188): call -0x1788 ; call 0x32238 / window 337
03de78 (+1190): r2 = 0x1
03de80 (+1198): r1 = 0x0
03de88 (+11a0): goto +0xf5 <.text+0x3e518> ; branch 0x3e638 / relative 0x1950
03de90 (+11a8): r1 = 0x9a1a0 ll ; pointer 0x9a1a0; data32hex 49583a204d696e742028627974657320446174614974656d49583a204275726e
03dea0 (+11b8): r2 = 0x8
03dea8 (+11c0): call -0x1 ; external sol_log_
03deb0 (+11c8): r6 = r10
03deb8 (+11d0): r6 += -0x6c8
03dec0 (+11d8): r1 = r6
03dec8 (+11e0): r2 = *(u64 *)(r10 - 0x940)
03ded0 (+11e8): r3 = 0x40
03ded8 (+11f0): call 0xb617 ; call 0x98f98 / window 1246
03dee0 (+11f8): r1 = r8
03dee8 (+1200): r2 = *(u64 *)(r10 - 0x928)
03def0 (+1208): r3 = r9
03def8 (+1210): r4 = *(u64 *)(r10 - 0x920)
03df00 (+1218): r5 = r6
03df08 (+1220): call -0x2864 ; call 0x29bf0 / window 323
03df10 (+1228): r0 = 0x0
03df18 (+1230): r1 = 0x1
03df20 (+1238): r2 = 0x1
03df28 (+1240): r3 = 0x1
03df30 (+1248): r4 = 0x1
03df38 (+1250): r5 = 0x1
03df40 (+1258): goto +0xe2 <.text+0x3e538> ; branch 0x3e658 / relative 0x1970
03df48 (+1260): r1 = 0x4b00000000 ll
03df58 (+1270): goto +0xa2 <.text+0x3e350> ; branch 0x3e470 / relative 0x1788
03df60 (+1278): r1 = 0x9aa3b ll ; pointer 0x9aa3b; data32hex 49583a20556e6c6f636b49583a205265766f6b6549583a2044656c6567617465
03df70 (+1288): r2 = 0xa
03df78 (+1290): call -0x1 ; external sol_log_
03df80 (+1298): r6 = r10
03df88 (+12a0): r6 += -0x6c8
03df90 (+12a8): r1 = r6
03df98 (+12b0): r2 = *(u64 *)(r10 - 0x940)
03dfa0 (+12b8): r3 = 0x38
03dfa8 (+12c0): call 0xb5fd ; call 0x98f98 / window 1246
03dfb0 (+12c8): r1 = r8
03dfb8 (+12d0): r2 = *(u64 *)(r10 - 0x928)
03dfc0 (+12d8): r3 = r9
03dfc8 (+12e0): r4 = *(u64 *)(r10 - 0x920)
03dfd0 (+12e8): r5 = r6
03dfd8 (+12f0): call -0xf46 ; call 0x365b0 / window 342
03dfe0 (+12f8): r3 = 0x0
03dfe8 (+1300): r1 = 0x1
03dff0 (+1308): r2 = 0x1
03dff8 (+1310): goto +0xc8 <.text+0x3e520> ; branch 0x3e640 / relative 0x1958
03e000 (+1318): r1 = *(u64 *)(r10 - 0x928)
03e008 (+1320): *(u64 *)(r10 - 0x438) = r1
03e010 (+1328): r1 = r10
03e018 (+1330): r1 += -0x8b8
03e020 (+1338): r2 = r9
03e028 (+1340): r3 = *(u64 *)(r10 - 0x920)
03e030 (+1348): call 0x74cd ; call 0x786a0 / window 802
03e038 (+1350): r1 = r10
03e040 (+1358): r1 += -0x110
03e048 (+1360): *(u64 *)(r10 - 0x958) = r1
03e050 (+1368): r1 = r10
03e058 (+1370): r1 += -0x12b
03e060 (+1378): *(u64 *)(r10 - 0x960) = r1
03e068 (+1380): r1 = r10
03e070 (+1388): r1 += -0x6a8
03e078 (+1390): *(u64 *)(r10 - 0x968) = r1
03e080 (+1398): r1 = r10
03e088 (+13a0): r1 += -0x6c3
03e090 (+13a8): *(u64 *)(r10 - 0x950) = r1
03e098 (+13b0): r1 = r10
03e0a0 (+13b8): r1 += -0xe8
03e0a8 (+13c0): *(u64 *)(r10 - 0x980) = r1
03e0b0 (+13c8): r1 = r10
03e0b8 (+13d0): r1 += -0x24
03e0c0 (+13d8): *(u64 *)(r10 - 0x970) = r1
03e0c8 (+13e0): r1 = r10
03e0d0 (+13e8): r1 += -0x5bc
03e0d8 (+13f0): *(u64 *)(r10 - 0x978) = r1
03e0e0 (+13f8): r8 = *(u64 *)(r10 - 0x8b8)
03e0e8 (+1400): r7 = *(u64 *)(r10 - 0x8b0)
03e0f0 (+1408): r7 += 0x18
03e0f8 (+1410): *(u64 *)(r10 - 0x988) = r8
03e100 (+1418): r9 = 0x0
03e108 (+1420): r6 = r7
03e110 (+1428): r6 += -0x18
03e118 (+1430): if r6 == r8 goto +0x9b <.text+0x3e4d8> ; branch 0x3e5f8 / relative 0x1910
03e120 (+1438): r2 = r10
03e128 (+1440): r2 += -0x438
03e130 (+1448): r1 = r7
03e138 (+1450): call -0x7691 ; call 0x2cb8 / window 41
03e140 (+1458): if r0 == 0x0 goto +0x3 <.text+0x3e040> ; branch 0x3e160 / relative 0x1478
03e148 (+1460): r1 = r6
03e150 (+1468): call 0x8e11 ; call 0x851e0 / window 981
03e158 (+1470): if r0 == 0x0 goto +0xd <.text+0x3e0a8> ; branch 0x3e1c8 / relative 0x14e0
03e160 (+1478): r1 = r6
03e168 (+1480): r2 = 0x9f3c8 ll ; pointer 0x9f3c8; data32hex 000000006898090000000000cea909001c00000000000000880100002a000000
03e178 (+1490): call -0x7699 ; call 0x2cb8 / window 41
03e180 (+1498): r9 = 0x1
03e188 (+14a0): if r0 != 0x0 goto +0x8d <.text+0x3e4d8> ; branch 0x3e5f8 / relative 0x1910
03e190 (+14a8): r1 = r7
03e198 (+14b0): r2 = 0x9f3c8 ll ; pointer 0x9f3c8; data32hex 000000006898090000000000cea909001c00000000000000880100002a000000
03e1a8 (+14c0): call -0x769f ; call 0x2cb8 / window 41
03e1b0 (+14c8): if r0 != 0x0 goto +0x88 <.text+0x3e4d8> ; branch 0x3e5f8 / relative 0x1910
03e1b8 (+14d0): r7 += 0x30
03e1c0 (+14d8): goto -0x19 <.text+0x3dfe0> ; branch 0x3e100 / relative 0x1418
03e1c8 (+14e0): r2 = *(u64 *)(r7 - 0x8)
03e1d0 (+14e8): r2 += 0x10
03e1d8 (+14f0): r1 = r10
03e1e0 (+14f8): r1 += -0x8c8
03e1e8 (+1500): r3 = 0x9f398 ll ; pointer 0x9f398; data32hex 00000000cea909001c000000000000006c0100003300000000000000cea90900
03e1f8 (+1510): call -0x7524 ; call 0x38e0 / window 87
03e200 (+1518): r1 = *(u64 *)(r10 - 0x8c8)
03e208 (+1520): r2 = *(u64 *)(r1 + 0x8)
03e210 (+1528): if r2 == 0x0 goto +0x3f9 <.text+0x400c0> ; branch 0x401e0 / relative 0x34f8
03e218 (+1530): r2 = *(u64 *)(r10 - 0x8c0)
03e220 (+1538): r1 = *(u64 *)(r1 + 0x0)
03e228 (+1540): r1 = *(u8 *)(r1 + 0x0)
03e230 (+1548): r3 = *(u64 *)(r2 + 0x0)
03e238 (+1550): r3 += -0x1
03e240 (+1558): *(u64 *)(r2 + 0x0) = r3
03e248 (+1560): if r1 == 0x4 goto +0x1 <.text+0x3e138> ; branch 0x3e258 / relative 0x1570
03e250 (+1568): goto -0x14 <.text+0x3e098> ; branch 0x3e1b8 / relative 0x14d0
03e258 (+1570): r1 = r10
03e260 (+1578): r1 += -0x6c8
03e268 (+1580): r2 = r6
03e270 (+1588): call 0x13a9 ; call 0x47fc0 / window 419
03e278 (+1590): r2 = *(u64 *)(r10 - 0x950)
03e280 (+1598): r1 = *(u64 *)(r2 + 0x0)
03e288 (+15a0): *(u64 *)(r10 - 0x368) = r1
03e290 (+15a8): r1 = *(u64 *)(r2 + 0x8)
03e298 (+15b0): *(u64 *)(r10 - 0x360) = r1
03e2a0 (+15b8): r1 = *(u64 *)(r2 + 0x10)
03e2a8 (+15c0): *(u64 *)(r10 - 0x358) = r1
03e2b0 (+15c8): r1 = *(u32 *)(r2 + 0x17)
03e2b8 (+15d0): *(u32 *)(r10 - 0x351) = r1
03e2c0 (+15d8): r9 = *(u8 *)(r10 - 0x6c4)
03e2c8 (+15e0): r6 = *(u32 *)(r10 - 0x6c8)
03e2d0 (+15e8): r8 = *(u32 *)(r10 - 0x5c0)
03e2d8 (+15f0): if r8 == 0x2 goto +0x58 <.text+0x3e480> ; branch 0x3e5a0 / relative 0x18b8
03e2e0 (+15f8): r1 = *(u64 *)(r10 - 0x958)
03e2e8 (+1600): r2 = *(u64 *)(r10 - 0x968)
03e2f0 (+1608): r3 = 0xe8
03e2f8 (+1610): call 0xb593 ; call 0x98f98 / window 1246
03e300 (+1618): r1 = *(u64 *)(r10 - 0x970)
03e308 (+1620): r2 = *(u64 *)(r10 - 0x978)
03e310 (+1628): r3 = 0x24
03e318 (+1630): call 0xb58f ; call 0x98f98 / window 1246
03e320 (+1638): *(u8 *)(r10 - 0x12c) = r9
03e328 (+1640): *(u32 *)(r10 - 0x130) = r6
03e330 (+1648): r1 = *(u32 *)(r10 - 0x351)
03e338 (+1650): r2 = *(u64 *)(r10 - 0x960)
03e340 (+1658): *(u32 *)(r2 + 0x17) = r1
03e348 (+1660): r1 = *(u64 *)(r10 - 0x358)
03e350 (+1668): *(u64 *)(r2 + 0x10) = r1
03e358 (+1670): r1 = *(u64 *)(r10 - 0x360)
03e360 (+1678): *(u64 *)(r2 + 0x8) = r1
03e368 (+1680): r1 = *(u64 *)(r10 - 0x368)
03e370 (+1688): *(u64 *)(r2 + 0x0) = r1
03e378 (+1690): *(u32 *)(r10 - 0x28) = r8
03e380 (+1698): r1 = *(u32 *)(r10 - 0x7c)
03e388 (+16a0): if r1 == 0x6 goto +0x4 <.text+0x3e290> ; branch 0x3e3b0 / relative 0x16c8
03e390 (+16a8): r2 = 0xfffffffe ll
03e3a0 (+16b8): r1 &= r2
03e3a8 (+16c0): if r1 == 0x4 goto +0xe4 <.text+0x3e9b0> ; branch 0x3ead0 / relative 0x1de8
03e3b0 (+16c8): r1 = *(u64 *)(r10 - 0x980)
03e3b8 (+16d0): call -0x7664 ; call 0x30a0 / window 59
03e3c0 (+16d8): r8 = *(u64 *)(r10 - 0x988)
03e3c8 (+16e0): goto -0x43 <.text+0x3e098> ; branch 0x3e1b8 / relative 0x14d0
03e3d0 (+16e8): r2 = *(u32 *)(r10 - 0x6c4)
03e3d8 (+16f0): r3 = *(u64 *)(r10 - 0x6c0)
03e3e0 (+16f8): r4 = *(u64 *)(r10 - 0x6b0)
03e3e8 (+1700): *(u64 *)(r8 + 0x18) = r4
03e3f0 (+1708): r4 = *(u64 *)(r10 - 0x6b8)
03e3f8 (+1710): *(u64 *)(r8 + 0x10) = r4
03e400 (+1718): *(u64 *)(r8 + 0x8) = r3
03e408 (+1720): *(u32 *)(r8 + 0x4) = r2
03e410 (+1728): goto +0x8 <.text+0x3e338> ; branch 0x3e458 / relative 0x1770
03e418 (+1730): r2 = *(u32 *)(r10 - 0x6ac)
03e420 (+1738): *(u32 *)(r8 + 0x1c) = r2
03e428 (+1740): r2 = *(u64 *)(r10 - 0x6b4)
03e430 (+1748): *(u64 *)(r8 + 0x14) = r2
03e438 (+1750): r2 = *(u64 *)(r10 - 0x6bc)
03e440 (+1758): *(u64 *)(r8 + 0xc) = r2
03e448 (+1760): r2 = *(u64 *)(r10 - 0x6c4)
03e450 (+1768): *(u64 *)(r8 + 0x4) = r2
03e458 (+1770): *(u32 *)(r8 + 0x0) = r1
03e460 (+1778): goto +0x38 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03e468 (+1780): r1 = 0xa
03e470 (+1788): *(u64 *)(r8 + 0x0) = r1
03e478 (+1790): goto +0x35 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03e480 (+1798): r1 = r10
03e488 (+17a0): r1 += -0x6c8
03e490 (+17a8): r2 = r9
03e498 (+17b0): r3 = 0x9cc8e ll ; pointer 0x9cc8e; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03e4a8 (+17c0): r4 = 0x2
03e4b0 (+17c8): call -0x5d0e ; call 0xfc48 / window 276
03e4b8 (+17d0): r1 = *(u32 *)(r10 - 0x6c8)
03e4c0 (+17d8): if r1 != 0x16 goto +0x3 <.text+0x3e3c0> ; branch 0x3e4e0 / relative 0x17f8
03e4c8 (+17e0): r7 = 0x0
03e4d0 (+17e8): r6 = *(u64 *)(r10 - 0x938)
03e4d8 (+17f0): goto -0x25e <.text+0x3d0d0> ; branch 0x3d1f0 / relative 0x508
03e4e0 (+17f8): r2 = *(u32 *)(r10 - 0x6ac)
03e4e8 (+1800): r3 = *(u64 *)(r10 - 0x930)
03e4f0 (+1808): *(u32 *)(r3 + 0x1c) = r2
03e4f8 (+1810): r2 = *(u64 *)(r10 - 0x6b4)
03e500 (+1818): *(u64 *)(r3 + 0x14) = r2
03e508 (+1820): r2 = *(u64 *)(r10 - 0x6bc)
03e510 (+1828): *(u64 *)(r3 + 0xc) = r2
03e518 (+1830): r2 = *(u64 *)(r10 - 0x6c4)
03e520 (+1838): *(u64 *)(r3 + 0x4) = r2
03e528 (+1840): *(u32 *)(r3 + 0x0) = r1
03e530 (+1848): goto +0x1e <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03e538 (+1850): r1 = 0x700000000 ll
03e548 (+1860): goto -0x1c <.text+0x3e350> ; branch 0x3e470 / relative 0x1788
03e550 (+1868): r1 = 0x0
03e558 (+1870): r2 = 0x0
03e560 (+1878): r3 = 0x9f3e8 ll ; pointer 0x9f3e8; data32hex 00000000cea909001c000000000000008a0100001100000000000000cea90900
03e570 (+1888): goto +0x3 <.text+0x3e470> ; branch 0x3e590 / relative 0x18a8
03e578 (+1890): r1 = 0x2
03e580 (+1898): r3 = 0x9f400 ll ; pointer 0x9f400; data32hex 00000000cea909001c000000000000008b01000015000000000000004cad0900
03e590 (+18a8): call 0xa41c ; call 0x90678 / window 1172
03e598 (+18b0): call -0x1 ; external abort
03e5a0 (+18b8): r1 = *(u64 *)(r10 - 0x368)
03e5a8 (+18c0): *(u64 *)(r10 - 0x568) = r1
03e5b0 (+18c8): r1 = *(u64 *)(r10 - 0x360)
03e5b8 (+18d0): *(u64 *)(r10 - 0x560) = r1
03e5c0 (+18d8): r1 = *(u64 *)(r10 - 0x358)
03e5c8 (+18e0): *(u64 *)(r10 - 0x558) = r1
03e5d0 (+18e8): r1 = *(u32 *)(r10 - 0x351)
03e5d8 (+18f0): *(u32 *)(r10 - 0x551) = r1
03e5e0 (+18f8): r1 = r6
03e5e8 (+1900): if r1 == 0x16 goto +0x1 <.text+0x3e4d8> ; branch 0x3e5f8 / relative 0x1910
03e5f0 (+1908): goto +0x88 <.text+0x3e918> ; branch 0x3ea38 / relative 0x1d50
03e5f8 (+1910): r9 &= 0xff
03e600 (+1918): if r9 == 0x0 goto +0x3a <.text+0x3e6b8> ; branch 0x3e7d8 / relative 0x1af0
03e608 (+1920): r1 = 0x9900000000 ll
03e618 (+1930): r2 = *(u64 *)(r10 - 0x930)
03e620 (+1938): *(u64 *)(r2 + 0x0) = r1
03e628 (+1940): r1 = 0x1
03e630 (+1948): r2 = 0x1
03e638 (+1950): r3 = 0x1
03e640 (+1958): r4 = 0x1
03e648 (+1960): r5 = 0x1
03e650 (+1968): r0 = 0x1
03e658 (+1970): r6 = 0x1
03e660 (+1978): r7 = *(u32 *)(r10 - 0x828)
03e668 (+1980): r8 = r7
03e670 (+1988): r8 += -0x34
03e678 (+1990): r9 = 0x2
03e680 (+1998): if r9 > r8 goto -0x311 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e688 (+19a0): if r7 == 0x29 goto -0x312 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e690 (+19a8): if r7 == 0x2a goto +0x1e <.text+0x3e668> ; branch 0x3e788 / relative 0x1aa0
03e698 (+19b0): if r7 == 0x2b goto +0xb <.text+0x3e5d8> ; branch 0x3e6f8 / relative 0x1a10
03e6a0 (+19b8): if r7 == 0x2c goto +0x21 <.text+0x3e690> ; branch 0x3e7b0 / relative 0x1ac8
03e6a8 (+19c0): if r7 == 0x2d goto -0x316 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e6b0 (+19c8): if r7 == 0x2e goto +0x15 <.text+0x3e640> ; branch 0x3e760 / relative 0x1a78
03e6b8 (+19d0): if r7 == 0x2f goto +0x9 <.text+0x3e5e8> ; branch 0x3e708 / relative 0x1a20
03e6c0 (+19d8): if r7 == 0x31 goto +0xa <.text+0x3e5f8> ; branch 0x3e718 / relative 0x1a30
03e6c8 (+19e0): if r7 == 0x32 goto +0xe <.text+0x3e620> ; branch 0x3e740 / relative 0x1a58
03e6d0 (+19e8): if r7 == 0x37 goto -0x31b <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e6d8 (+19f0): r1 = r10
03e6e0 (+19f8): r1 += -0x828
03e6e8 (+1a00): call -0x769b ; call 0x3218 / window 66
03e6f0 (+1a08): goto -0x31f <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e6f8 (+1a10): if r0 != 0x0 goto +0x5 <.text+0x3e608> ; branch 0x3e728 / relative 0x1a40
03e700 (+1a18): goto -0x321 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e708 (+1a20): if r3 != 0x0 goto +0xc <.text+0x3e650> ; branch 0x3e770 / relative 0x1a88
03e710 (+1a28): goto -0x323 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e718 (+1a30): if r2 != 0x0 goto +0x1 <.text+0x3e608> ; branch 0x3e728 / relative 0x1a40
03e720 (+1a38): goto -0x325 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e728 (+1a40): r1 = r10
03e730 (+1a48): r1 += -0x810
03e738 (+1a50): goto +0x7 <.text+0x3e658> ; branch 0x3e778 / relative 0x1a90
03e740 (+1a58): if r1 == 0x0 goto -0x329 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e748 (+1a60): r1 = *(u64 *)(r10 - 0x940)
03e750 (+1a68): call -0x7679 ; call 0x3390 / window 68
03e758 (+1a70): goto -0x32c <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e760 (+1a78): if r4 != 0x0 goto +0x1 <.text+0x3e650> ; branch 0x3e770 / relative 0x1a88
03e768 (+1a80): goto -0x32e <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e770 (+1a88): r1 = *(u64 *)(r10 - 0x948)
03e778 (+1a90): call -0x75eb ; call 0x3828 / window 85
03e780 (+1a98): goto -0x331 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e788 (+1aa0): if r6 != 0x0 goto +0x1 <.text+0x3e678> ; branch 0x3e798 / relative 0x1ab0
03e790 (+1aa8): goto -0x333 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e798 (+1ab0): r1 = *(u64 *)(r10 - 0x948)
03e7a0 (+1ab8): call -0x76e1 ; call 0x30a0 / window 59
03e7a8 (+1ac0): goto -0x336 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e7b0 (+1ac8): if r5 != 0x0 goto +0x1 <.text+0x3e6a0> ; branch 0x3e7c0 / relative 0x1ad8
03e7b8 (+1ad0): goto -0x338 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e7c0 (+1ad8): r1 = *(u64 *)(r10 - 0x940)
03e7c8 (+1ae0): call -0x7670 ; call 0x3450 / window 69
03e7d0 (+1ae8): goto -0x33b <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
03e7d8 (+1af0): r1 = r10
03e7e0 (+1af8): r1 += -0x6c8
03e7e8 (+1b00): r2 = r10
03e7f0 (+1b08): r2 += -0x828
03e7f8 (+1b10): r3 = 0x160
03e800 (+1b18): call 0xb4f2 ; call 0x98f98 / window 1246
03e808 (+1b20): r1 = *(u32 *)(r10 - 0x6c8)
03e810 (+1b28): if r1 == 0x0 goto +0x3f <.text+0x3e8f0> ; branch 0x3ea10 / relative 0x1d28
03e818 (+1b30): if r1 == 0x1 goto +0x3e <.text+0x3e8f0> ; branch 0x3ea10 / relative 0x1d28
03e820 (+1b38): if r1 == 0x2 goto +0x3d <.text+0x3e8f0> ; branch 0x3ea10 / relative 0x1d28
03e828 (+1b40): r9 = *(u64 *)(r10 - 0x930)
03e830 (+1b48): if r1 == 0x3 goto +0x28 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e838 (+1b50): if r1 == 0x4 goto +0xa6 <.text+0x3ec50> ; branch 0x3ed70 / relative 0x2088
03e840 (+1b58): if r1 == 0x5 goto +0x26 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e848 (+1b60): if r1 == 0x6 goto +0x25 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e850 (+1b68): if r1 == 0x7 goto +0xad <.text+0x3eca0> ; branch 0x3edc0 / relative 0x20d8
03e858 (+1b70): if r1 == 0x8 goto +0x23 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e860 (+1b78): if r1 == 0x9 goto +0x22 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e868 (+1b80): if r1 == 0xa goto +0x21 <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e870 (+1b88): if r1 == 0xb goto +0x1d3 <.text+0x3f5f0> ; branch 0x3f710 / relative 0x2a28
03e878 (+1b90): if r1 == 0xc goto +0x1cb <.text+0x3f5b8> ; branch 0x3f6d8 / relative 0x29f0
03e880 (+1b98): if r1 == 0xd goto +0x1e <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e888 (+1ba0): if r1 == 0xe goto +0xb0 <.text+0x3ecf0> ; branch 0x3ee10 / relative 0x2128
03e890 (+1ba8): if r1 == 0xf goto +0x1e5 <.text+0x3f6a0> ; branch 0x3f7c0 / relative 0x2ad8
03e898 (+1bb0): if r1 == 0x10 goto +0x1b <.text+0x3e858> ; branch 0x3e978 / relative 0x1c90
03e8a0 (+1bb8): if r1 == 0x11 goto +0xdf <.text+0x3ee80> ; branch 0x3efa0 / relative 0x22b8
03e8a8 (+1bc0): if r1 == 0x12 goto +0x1d8 <.text+0x3f650> ; branch 0x3f770 / relative 0x2a88
03e8b0 (+1bc8): if r1 == 0x13 goto +0x1ae <.text+0x3f508> ; branch 0x3f628 / relative 0x2940
03e8b8 (+1bd0): if r1 == 0x14 goto +0x12e <.text+0x3f110> ; branch 0x3f230 / relative 0x2548
03e8c0 (+1bd8): if r1 == 0x15 goto +0x139 <.text+0x3f170> ; branch 0x3f290 / relative 0x25a8
03e8c8 (+1be0): if r1 == 0x16 goto +0x1b7 <.text+0x3f568> ; branch 0x3f688 / relative 0x29a0
03e8d0 (+1be8): if r1 == 0x17 goto +0x141 <.text+0x3f1c0> ; branch 0x3f2e0 / relative 0x25f8
03e8d8 (+1bf0): if r1 == 0x18 goto +0x14a <.text+0x3f210> ; branch 0x3f330 / relative 0x2648
03e8e0 (+1bf8): if r1 == 0x19 goto +0xaf <.text+0x3ed40> ; branch 0x3ee60 / relative 0x2178
03e8e8 (+1c00): if r1 == 0x1a goto +0xe1 <.text+0x3eed8> ; branch 0x3eff8 / relative 0x2310
03e8f0 (+1c08): if r1 == 0x1b goto +0xb7 <.text+0x3ed90> ; branch 0x3eeb0 / relative 0x21c8
03e8f8 (+1c10): if r1 == 0x1c goto +0x150 <.text+0x3f260> ; branch 0x3f380 / relative 0x2698
03e900 (+1c18): if r1 == 0x1d goto +0xe8 <.text+0x3ef28> ; branch 0x3f048 / relative 0x2360
03e908 (+1c20): if r1 == 0x1e goto +0xbe <.text+0x3ede0> ; branch 0x3ef00 / relative 0x2218
03e910 (+1c28): if r1 == 0x1f goto +0x157 <.text+0x3f2b0> ; branch 0x3f3d0 / relative 0x26e8
03e918 (+1c30): if r1 == 0x20 goto +0xef <.text+0x3ef78> ; branch 0x3f098 / relative 0x23b0
03e920 (+1c38): if r1 == 0x21 goto +0x15f <.text+0x3f300> ; branch 0x3f420 / relative 0x2738
03e928 (+1c40): if r1 == 0x22 goto +0xf7 <.text+0x3efc8> ; branch 0x3f0e8 / relative 0x2400
03e930 (+1c48): if r1 == 0x23 goto +0x188 <.text+0x3f458> ; branch 0x3f578 / relative 0x2890
03e938 (+1c50): if r1 == 0x24 goto +0x191 <.text+0x3f4a8> ; branch 0x3f5c8 / relative 0x28e0
03e940 (+1c58): if r1 == 0x25 goto +0xc1 <.text+0x3ee30> ; branch 0x3ef50 / relative 0x2268
03e948 (+1c60): if r1 == 0x26 goto +0xff <.text+0x3f028> ; branch 0x3f148 / relative 0x2460
03e950 (+1c68): if r1 == 0x27 goto +0x107 <.text+0x3f070> ; branch 0x3f190 / relative 0x24a8
03e958 (+1c70): if r1 == 0x28 goto +0x10f <.text+0x3f0b8> ; branch 0x3f1d8 / relative 0x24f0
03e960 (+1c78): r1 = 0x2
03e968 (+1c80): *(u32 *)(r9 + 0x0) = r1
03e970 (+1c88): goto +0x3ab <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03e978 (+1c90): r1 = 0x4b00000000 ll
03e988 (+1ca0): *(u64 *)(r9 + 0x0) = r1
03e990 (+1ca8): goto +0x3a7 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03e998 (+1cb0): r6 = *(u64 *)(r10 - 0x938)
03e9a0 (+1cb8): r8 = r6
03e9a8 (+1cc0): r8 += 0xc0
03e9b0 (+1cc8): r1 = *(u64 *)(r8 + 0x0)
03e9b8 (+1cd0): r2 = 0x999a8 ll ; pointer 0x999a8; data32hex ed03481d8df777ace755769e3a84e6deed48a87f333232b4b73496de27798786
03e9c8 (+1ce0): call -0x7798 ; call 0x2d10 / window 44
03e9d0 (+1ce8): if r0 != 0x0 goto +0x1 <.text+0x3e8c0> ; branch 0x3e9e0 / relative 0x1cf8
03e9d8 (+1cf0): goto +0x21 <.text+0x3e9c8> ; branch 0x3eae8 / relative 0x1e00
03e9e0 (+1cf8): r1 = 0xbf00000000 ll
03e9f0 (+1d08): goto -0x7c <.text+0x3e4f8> ; branch 0x3e618 / relative 0x1930
03e9f8 (+1d10): r1 = 0xbf00000000 ll
03ea08 (+1d20): goto -0xb4 <.text+0x3e350> ; branch 0x3e470 / relative 0x1788
03ea10 (+1d28): r1 = 0x4b00000000 ll
03ea20 (+1d38): r2 = *(u64 *)(r10 - 0x930)
03ea28 (+1d40): *(u64 *)(r2 + 0x0) = r1
03ea30 (+1d48): goto +0x393 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ea38 (+1d50): r1 = *(u32 *)(r10 - 0x551)
03ea40 (+1d58): *(u32 *)(r10 - 0x221) = r1
03ea48 (+1d60): r1 = *(u64 *)(r10 - 0x558)
03ea50 (+1d68): *(u64 *)(r10 - 0x228) = r1
03ea58 (+1d70): r1 = *(u64 *)(r10 - 0x560)
03ea60 (+1d78): *(u64 *)(r10 - 0x230) = r1
03ea68 (+1d80): r2 = *(u64 *)(r10 - 0x568)
03ea70 (+1d88): *(u64 *)(r10 - 0x238) = r2
03ea78 (+1d90): r3 = *(u32 *)(r10 - 0x221)
03ea80 (+1d98): r4 = *(u64 *)(r10 - 0x930)
03ea88 (+1da0): *(u32 *)(r4 + 0x1c) = r3
03ea90 (+1da8): r3 = *(u64 *)(r10 - 0x228)
03ea98 (+1db0): *(u64 *)(r4 + 0x15) = r3
03eaa0 (+1db8): *(u64 *)(r4 + 0xd) = r1
03eaa8 (+1dc0): *(u64 *)(r4 + 0x5) = r2
03eab0 (+1dc8): *(u8 *)(r4 + 0x4) = r9
03eab8 (+1dd0): *(u32 *)(r4 + 0x0) = r6
03eac0 (+1dd8): r1 = *(u32 *)(r10 - 0x828)
03eac8 (+1de0): goto -0x307 <.text+0x3d178> ; branch 0x3d298 / relative 0x5b0
03ead0 (+1de8): r1 = *(u64 *)(r10 - 0x980)
03ead8 (+1df0): call -0x7748 ; call 0x30a0 / window 59
03eae0 (+1df8): goto -0x9c <.text+0x3e4e8> ; branch 0x3e608 / relative 0x1920
03eae8 (+1e00): *(u64 *)(r10 - 0x928) = r8
03eaf0 (+1e08): r6 += 0x30
03eaf8 (+1e10): r1 = r10
03eb00 (+1e18): r1 += -0x858
03eb08 (+1e20): r2 = 0x999c8 ll ; pointer 0x999c8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03eb18 (+1e30): call 0x8ee5 ; call 0x86248 / window 990
03eb20 (+1e38): r2 = *(u64 *)(r9 + 0x0)
03eb28 (+1e40): r1 = *(u64 *)(r10 - 0x858)
03eb30 (+1e48): *(u64 *)(r10 - 0x920) = r1
03eb38 (+1e50): r8 = *(u64 *)(r10 - 0x850)
03eb40 (+1e58): r1 = r10
03eb48 (+1e60): r1 += -0x868
03eb50 (+1e68): call 0x8ede ; call 0x86248 / window 990
03eb58 (+1e70): r1 = 0x7
03eb60 (+1e78): *(u64 *)(r10 - 0x690) = r1
03eb68 (+1e80): r1 = 0x9a255 ll ; pointer 0x9a255; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
03eb78 (+1e90): *(u64 *)(r10 - 0x698) = r1
03eb80 (+1e98): *(u64 *)(r10 - 0x6b0) = r8
03eb88 (+1ea0): r1 = *(u64 *)(r10 - 0x920)
03eb90 (+1ea8): *(u64 *)(r10 - 0x6b8) = r1
03eb98 (+1eb0): r1 = 0x8
03eba0 (+1eb8): *(u64 *)(r10 - 0x6c0) = r1
03eba8 (+1ec0): r1 = 0x9a210 ll ; pointer 0x9a210; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
03ebb8 (+1ed0): *(u64 *)(r10 - 0x6c8) = r1
03ebc0 (+1ed8): r1 = *(u64 *)(r10 - 0x860)
03ebc8 (+1ee0): *(u64 *)(r10 - 0x6a0) = r1
03ebd0 (+1ee8): r1 = *(u64 *)(r10 - 0x868)
03ebd8 (+1ef0): *(u64 *)(r10 - 0x6a8) = r1
03ebe0 (+1ef8): r1 = r10
03ebe8 (+1f00): r1 += -0x438
03ebf0 (+1f08): r2 = r10
03ebf8 (+1f10): r2 += -0x6c8
03ec00 (+1f18): call -0x6814 ; call 0xab68 / window 226
03ec08 (+1f20): r4 = *(u64 *)(r10 - 0x430)
03ec10 (+1f28): r5 = *(u64 *)(r10 - 0x428)
03ec18 (+1f30): r1 = r10
03ec20 (+1f38): r1 += -0x6c8
03ec28 (+1f40): r2 = 0x999c8 ll ; pointer 0x999c8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03ec38 (+1f50): *(u64 *)(r10 - 0x920) = r6
03ec40 (+1f58): r3 = r6
03ec48 (+1f60): call -0x5e10 ; call 0xfbd0 / window 273
03ec50 (+1f68): r1 = *(u32 *)(r10 - 0x6c8)
03ec58 (+1f70): if r1 == 0x16 goto +0x1 <.text+0x3eb48> ; branch 0x3ec68 / relative 0x1f80
03ec60 (+1f78): goto +0x14 <.text+0x3ebe8> ; branch 0x3ed08 / relative 0x2020
03ec68 (+1f80): r1 = r10
03ec70 (+1f88): r1 += -0x6c8
03ec78 (+1f90): r2 = *(u64 *)(r10 - 0x938)
03ec80 (+1f98): call 0x1267 ; call 0x47fc0 / window 419
03ec88 (+1fa0): r6 = *(u32 *)(r10 - 0x5c0)
03ec90 (+1fa8): if r6 != 0x2 goto +0x197 <.text+0x3f830> ; branch 0x3f950 / relative 0x2c68
03ec98 (+1fb0): r1 = *(u64 *)(r10 - 0x6b0)
03eca0 (+1fb8): *(u64 *)(r10 - 0x350) = r1
03eca8 (+1fc0): r2 = *(u64 *)(r10 - 0x6b8)
03ecb0 (+1fc8): *(u64 *)(r10 - 0x358) = r2
03ecb8 (+1fd0): r3 = *(u64 *)(r10 - 0x6c0)
03ecc0 (+1fd8): *(u64 *)(r10 - 0x360) = r3
03ecc8 (+1fe0): r4 = *(u64 *)(r10 - 0x6c8)
03ecd0 (+1fe8): *(u64 *)(r10 - 0x368) = r4
03ecd8 (+1ff0): r5 = *(u64 *)(r10 - 0x930)
03ece0 (+1ff8): *(u64 *)(r5 + 0x18) = r1
03ece8 (+2000): *(u64 *)(r5 + 0x10) = r2
03ecf0 (+2008): *(u64 *)(r5 + 0x8) = r3
03ecf8 (+2010): *(u64 *)(r5 + 0x0) = r4
03ed00 (+2018): goto +0x1ac <.text+0x3f948> ; branch 0x3fa68 / relative 0x2d80
03ed08 (+2020): r2 = *(u8 *)(r10 - 0x6c4)
03ed10 (+2028): r3 = *(u32 *)(r10 - 0x6ac)
03ed18 (+2030): r4 = *(u64 *)(r10 - 0x930)
03ed20 (+2038): *(u32 *)(r4 + 0x1c) = r3
03ed28 (+2040): r3 = *(u64 *)(r10 - 0x6b3)
03ed30 (+2048): *(u64 *)(r4 + 0x15) = r3
03ed38 (+2050): r3 = *(u64 *)(r10 - 0x6bb)
03ed40 (+2058): *(u64 *)(r4 + 0xd) = r3
03ed48 (+2060): r3 = *(u64 *)(r10 - 0x6c3)
03ed50 (+2068): *(u64 *)(r4 + 0x5) = r3
03ed58 (+2070): *(u8 *)(r4 + 0x4) = r2
03ed60 (+2078): *(u32 *)(r4 + 0x0) = r1
03ed68 (+2080): goto +0x19f <.text+0x3f948> ; branch 0x3fa68 / relative 0x2d80
03ed70 (+2088): r1 = 0x9ad2b ll ; pointer 0x9ad2b; data32hex 49583a20557064617465207072696d6172792073616c652076696120746f6b65
03ed80 (+2098): r2 = 0x21
03ed88 (+20a0): call -0x1 ; external sol_log_
03ed90 (+20a8): r1 = r9
03ed98 (+20b0): r2 = *(u64 *)(r10 - 0x928)
03eda0 (+20b8): r3 = *(u64 *)(r10 - 0x938)
03eda8 (+20c0): r4 = *(u64 *)(r10 - 0x920)
03edb0 (+20c8): call -0x142f ; call 0x34c40 / window 339
03edb8 (+20d0): goto +0x322 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03edc0 (+20d8): r1 = 0x9ad1a ll ; pointer 0x9ad1a; data32hex 49583a205369676e204d6574616461746149583a20557064617465207072696d
03edd0 (+20e8): r2 = 0x11
03edd8 (+20f0): call -0x1 ; external sol_log_
03ede0 (+20f8): r1 = r9
03ede8 (+2100): r2 = *(u64 *)(r10 - 0x928)
03edf0 (+2108): r3 = *(u64 *)(r10 - 0x938)
03edf8 (+2110): r4 = *(u64 *)(r10 - 0x920)
03ee00 (+2118): call -0x1fc7 ; call 0x2efd0 / window 332
03ee08 (+2120): goto +0x318 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ee10 (+2128): r1 = 0x9acb4 ll ; pointer 0x9acb4; data32hex 49583a2050756666204d6574616461746149583a20436f6e76657274204d6173
03ee20 (+2138): r2 = 0x11
03ee28 (+2140): call -0x1 ; external sol_log_
03ee30 (+2148): r1 = r9
03ee38 (+2150): r2 = *(u64 *)(r10 - 0x928)
03ee40 (+2158): r3 = *(u64 *)(r10 - 0x938)
03ee48 (+2160): r4 = *(u64 *)(r10 - 0x920)
03ee50 (+2168): call -0x2219 ; call 0x2dd90 / window 329
03ee58 (+2170): goto +0x30e <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ee60 (+2178): r1 = 0x9ab39 ll ; pointer 0x9ab39; data32hex 49583a2053657420616e642056657269667920436f6c6c656374696f6e49583a
03ee70 (+2188): r2 = 0x1d
03ee78 (+2190): call -0x1 ; external sol_log_
03ee80 (+2198): r1 = r9
03ee88 (+21a0): r2 = *(u64 *)(r10 - 0x928)
03ee90 (+21a8): r3 = *(u64 *)(r10 - 0x938)
03ee98 (+21b0): r4 = *(u64 *)(r10 - 0x920)
03eea0 (+21b8): call -0x4c1d ; call 0x18dc0 / window 303
03eea8 (+21c0): goto +0x304 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03eeb0 (+21c8): r1 = 0x9abb6 ll ; pointer 0x9abb6; data32hex 49583a20546861772044656c656761746564204163636f756e7449583a204672
03eec0 (+21d8): r2 = 0x1a
03eec8 (+21e0): call -0x1 ; external sol_log_
03eed0 (+21e8): r1 = r9
03eed8 (+21f0): r2 = *(u64 *)(r10 - 0x928)
03eee0 (+21f8): r3 = *(u64 *)(r10 - 0x938)
03eee8 (+2200): r4 = *(u64 *)(r10 - 0x920)
03eef0 (+2208): call -0x2dbb ; call 0x28120 / window 320
03eef8 (+2210): goto +0x2fa <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ef00 (+2218): r1 = 0x9ab73 ll ; pointer 0x9ab73; data32hex 49583a2056657269667920436f6c6c656374696f6e20563249583a204275726e
03ef10 (+2228): r2 = 0x18
03ef18 (+2230): call -0x1 ; external sol_log_
03ef20 (+2238): r1 = r9
03ef28 (+2240): r2 = *(u64 *)(r10 - 0x928)
03ef30 (+2248): r3 = *(u64 *)(r10 - 0x938)
03ef38 (+2250): r4 = *(u64 *)(r10 - 0x920)
03ef40 (+2258): call -0x451d ; call 0x1c660 / window 309
03ef48 (+2260): goto +0x2f0 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ef50 (+2268): r1 = 0x9aab0 ll ; pointer 0x9aab0; data32hex 49583a204275726e2045646974696f6e204e465449583a20427562626c656775
03ef60 (+2278): r2 = 0x14
03ef68 (+2280): call -0x1 ; external sol_log_
03ef70 (+2288): r1 = r9
03ef78 (+2290): r2 = *(u64 *)(r10 - 0x928)
03ef80 (+2298): r3 = *(u64 *)(r10 - 0x938)
03ef88 (+22a0): r4 = *(u64 *)(r10 - 0x920)
03ef90 (+22a8): call -0x56e7 ; call 0x13860 / window 297
03ef98 (+22b0): goto +0x2e6 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03efa0 (+22b8): r1 = *(u64 *)(r10 - 0x6b8)
03efa8 (+22c0): *(u64 *)(r10 - 0x948) = r1
03efb0 (+22c8): r1 = *(u64 *)(r10 - 0x6c0)
03efb8 (+22d0): *(u64 *)(r10 - 0x940) = r1
03efc0 (+22d8): r1 = 0x9ac7d ll ; pointer 0x9ac7d; data32hex 563320437265617465204d61737465722045646974696f6e49583a2055706461
03efd0 (+22e8): r2 = 0x18
03efd8 (+22f0): call -0x1 ; external sol_log_
03efe0 (+22f8): r1 = *(u64 *)(r10 - 0x920)
03efe8 (+2300): if r1 > 0x7 goto +0x155 <.text+0x3f978> ; branch 0x3fa98 / relative 0x2db0
03eff0 (+2308): goto +0xeb <.text+0x3f630> ; branch 0x3f750 / relative 0x2a68
03eff8 (+2310): r1 = 0x9abd0 ll ; pointer 0x9abd0; data32hex 49583a20467265657a652044656c656761746564204163636f756e7449583a20
03f008 (+2320): r2 = 0x1c
03f010 (+2328): call -0x1 ; external sol_log_
03f018 (+2330): r1 = r9
03f020 (+2338): r2 = *(u64 *)(r10 - 0x928)
03f028 (+2340): r3 = *(u64 *)(r10 - 0x938)
03f030 (+2348): r4 = *(u64 *)(r10 - 0x920)
03f038 (+2350): call -0x2f1e ; call 0x27750 / window 319
03f040 (+2358): goto +0x2d1 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f048 (+2360): r1 = 0x9ab8b ll ; pointer 0x9ab8b; data32hex 49583a204275726e204e465449583a2052656d6f76652043726561746f722056
03f058 (+2370): r2 = 0xc
03f060 (+2378): call -0x1 ; external sol_log_
03f068 (+2380): r1 = r9
03f070 (+2388): r2 = *(u64 *)(r10 - 0x928)
03f078 (+2390): r3 = *(u64 *)(r10 - 0x938)
03f080 (+2398): r4 = *(u64 *)(r10 - 0x920)
03f088 (+23a0): call -0x5606 ; call 0x14060 / window 298
03f090 (+23a8): goto +0x2c7 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f098 (+23b0): r1 = 0x9ab39 ll ; pointer 0x9ab39; data32hex 49583a2053657420616e642056657269667920436f6c6c656374696f6e49583a
03f0a8 (+23c0): r2 = 0x1d
03f0b0 (+23c8): call -0x1 ; external sol_log_
03f0b8 (+23d0): r1 = r9
03f0c0 (+23d8): r2 = *(u64 *)(r10 - 0x928)
03f0c8 (+23e0): r3 = *(u64 *)(r10 - 0x938)
03f0d0 (+23e8): r4 = *(u64 *)(r10 - 0x920)
03f0d8 (+23f0): call -0x4b18 ; call 0x19820 / window 304
03f0e0 (+23f8): goto +0x2bd <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f0e8 (+2400): r6 = *(u64 *)(r10 - 0x6c0)
03f0f0 (+2408): r1 = 0x9ab03 ll ; pointer 0x9ab03; data32hex 49583a2053657420436f6c6c656374696f6e2053697a6549583a204372656174
03f100 (+2418): r2 = 0x17
03f108 (+2420): call -0x1 ; external sol_log_
03f110 (+2428): r1 = r9
03f118 (+2430): r2 = *(u64 *)(r10 - 0x928)
03f120 (+2438): r3 = *(u64 *)(r10 - 0x938)
03f128 (+2440): r4 = *(u64 *)(r10 - 0x920)
03f130 (+2448): r5 = r6
03f138 (+2450): call -0x49e1 ; call 0x1a238 / window 305
03f140 (+2458): goto +0x2b1 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f148 (+2460): r1 = 0x9aa97 ll ; pointer 0x9aa97; data32hex 49583a2043726561746520457363726f77204163636f756e7449583a20427572
03f158 (+2470): r2 = 0x19
03f160 (+2478): call -0x1 ; external sol_log_
03f168 (+2480): r1 = r9
03f170 (+2488): r3 = *(u64 *)(r10 - 0x938)
03f178 (+2490): r4 = *(u64 *)(r10 - 0x920)
03f180 (+2498): call -0x368a ; call 0x23d38 / window 316
03f188 (+24a0): goto +0x2a8 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f190 (+24a8): r1 = 0x9aa7f ll ; pointer 0x9aa7f; data32hex 49583a20436c6f736520457363726f77204163636f756e7449583a2043726561
03f1a0 (+24b8): r2 = 0x18
03f1a8 (+24c0): call -0x1 ; external sol_log_
03f1b0 (+24c8): r1 = r9
03f1b8 (+24d0): r3 = *(u64 *)(r10 - 0x938)
03f1c0 (+24d8): r4 = *(u64 *)(r10 - 0x920)
03f1c8 (+24e0): call -0x3851 ; call 0x22f48 / window 315
03f1d0 (+24e8): goto +0x29f <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f1d8 (+24f0): r6 = *(u64 *)(r10 - 0x6c0)
03f1e0 (+24f8): r1 = 0x9aa65 ll ; pointer 0x9aa65; data32hex 49583a205472616e73666572204f7574204f6620457363726f7749583a20436c
03f1f0 (+2508): r2 = 0x1a
03f1f8 (+2510): call -0x1 ; external sol_log_
03f200 (+2518): r1 = r9
03f208 (+2520): r3 = *(u64 *)(r10 - 0x938)
03f210 (+2528): r4 = *(u64 *)(r10 - 0x920)
03f218 (+2530): r5 = r6
03f220 (+2538): call -0x33e2 ; call 0x25318 / window 318
03f228 (+2540): goto +0x294 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f230 (+2548): r6 = *(u64 *)(r10 - 0x6c0)
03f238 (+2550): r1 = 0x9ac3a ll ; pointer 0x9ac3a; data32hex 49583a20417070726f76652055736520417574686f7269747949583a20557365
03f248 (+2560): r2 = 0x19
03f250 (+2568): call -0x1 ; external sol_log_
03f258 (+2570): r1 = r9
03f260 (+2578): r2 = *(u64 *)(r10 - 0x928)
03f268 (+2580): r3 = *(u64 *)(r10 - 0x938)
03f270 (+2588): r4 = *(u64 *)(r10 - 0x920)
03f278 (+2590): r5 = r6
03f280 (+2598): call -0xe09 ; call 0x38240 / window 344
03f288 (+25a0): goto +0x288 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f290 (+25a8): r1 = 0x9ac22 ll ; pointer 0x9ac22; data32hex 49583a205265766f6b652055736520417574686f7269747949583a2041707072
03f2a0 (+25b8): r2 = 0x18
03f2a8 (+25c0): call -0x1 ; external sol_log_
03f2b0 (+25c8): r1 = r9
03f2b8 (+25d0): r2 = *(u64 *)(r10 - 0x928)
03f2c0 (+25d8): r3 = *(u64 *)(r10 - 0x938)
03f2c8 (+25e0): r4 = *(u64 *)(r10 - 0x920)
03f2d0 (+25e8): call -0xc3b ; call 0x39100 / window 345
03f2d8 (+25f0): goto +0x27e <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f2e0 (+25f8): r1 = 0x99b08 ll ; pointer 0x99b08; data32hex 49583a20417070726f766520436f6c6c656374696f6e20417574686f72697479
03f2f0 (+2608): r2 = 0x20
03f2f8 (+2610): call -0x1 ; external sol_log_
03f300 (+2618): r1 = r9
03f308 (+2620): r2 = *(u64 *)(r10 - 0x928)
03f310 (+2628): r3 = *(u64 *)(r10 - 0x938)
03f318 (+2630): r4 = *(u64 *)(r10 - 0x920)
03f320 (+2638): call -0x4ed9 ; call 0x17c60 / window 301
03f328 (+2640): goto +0x274 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f330 (+2648): r1 = 0x9abec ll ; pointer 0x9abec; data32hex 49583a205265766f6b6520436f6c6c656374696f6e20417574686f7269747949
03f340 (+2658): r2 = 0x1f
03f348 (+2660): call -0x1 ; external sol_log_
03f350 (+2668): r1 = r9
03f358 (+2670): r2 = *(u64 *)(r10 - 0x928)
03f360 (+2678): r3 = *(u64 *)(r10 - 0x938)
03f368 (+2680): r4 = *(u64 *)(r10 - 0x920)
03f370 (+2688): call -0x4d69 ; call 0x18830 / window 302
03f378 (+2690): goto +0x26a <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f380 (+2698): r1 = 0x9ab97 ll ; pointer 0x9ab97; data32hex 49583a2052656d6f76652043726561746f7220566572696669636174696f6e49
03f390 (+26a8): r2 = 0x1f
03f398 (+26b0): call -0x1 ; external sol_log_
03f3a0 (+26b8): r1 = r9
03f3a8 (+26c0): r2 = *(u64 *)(r10 - 0x928)
03f3b0 (+26c8): r3 = *(u64 *)(r10 - 0x938)
03f3b8 (+26d0): r4 = *(u64 *)(r10 - 0x920)
03f3c0 (+26d8): call -0x2232 ; call 0x2e238 / window 330
03f3c8 (+26e0): goto +0x260 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f3d0 (+26e8): r1 = 0x9ab56 ll ; pointer 0x9ab56; data32hex 49583a20556e7665726966792053697a656420436f6c6c656374696f6e49583a
03f3e0 (+26f8): r2 = 0x1d
03f3e8 (+2700): call -0x1 ; external sol_log_
03f3f0 (+2708): r1 = r9
03f3f8 (+2710): r2 = *(u64 *)(r10 - 0x928)
03f400 (+2718): r3 = *(u64 *)(r10 - 0x938)
03f408 (+2720): r4 = *(u64 *)(r10 - 0x920)
03f410 (+2728): call -0x483a ; call 0x1b248 / window 307
03f418 (+2730): goto +0x256 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f420 (+2738): r6 = r10
03f428 (+2740): r6 += -0x368
03f430 (+2748): r2 = r10
03f438 (+2750): r2 += -0x6c0
03f440 (+2758): r1 = r6
03f448 (+2760): r3 = 0xa8
03f450 (+2768): call 0xb368 ; call 0x98f98 / window 1246
03f458 (+2770): r1 = *(u64 *)(r10 - 0x617)
03f460 (+2778): *(u64 *)(r10 - 0x568) = r1
03f468 (+2780): r1 = *(u64 *)(r10 - 0x60f)
03f470 (+2788): *(u64 *)(r10 - 0x560) = r1
03f478 (+2790): r1 = *(u64 *)(r10 - 0x608)
03f480 (+2798): *(u64 *)(r10 - 0x559) = r1
03f488 (+27a0): r8 = *(u8 *)(r10 - 0x618)
03f490 (+27a8): r1 = 0x9ab1a ll ; pointer 0x9ab1a; data32hex 49583a20437265617465204d65746164617461204163636f756e747320763349
03f4a0 (+27b8): r2 = 0x1f
03f4a8 (+27c0): call -0x1 ; external sol_log_
03f4b0 (+27c8): r7 = r10
03f4b8 (+27d0): r7 += -0x130
03f4c0 (+27d8): r1 = r7
03f4c8 (+27e0): r2 = r6
03f4d0 (+27e8): r3 = 0xa8
03f4d8 (+27f0): call 0xb357 ; call 0x98f98 / window 1246
03f4e0 (+27f8): r1 = *(u64 *)(r10 - 0x559)
03f4e8 (+2800): *(u64 *)(r10 - 0x230) = r1
03f4f0 (+2808): r1 = *(u64 *)(r10 - 0x561)
03f4f8 (+2810): *(u64 *)(r10 - 0x238) = r1
03f500 (+2818): r8 &= 0x1
03f508 (+2820): *(u64 *)(r10 - 0xff8) = r8
03f510 (+2828): r1 = r10
03f518 (+2830): r1 += -0x238
03f520 (+2838): *(u64 *)(r10 - 0xff0) = r1
03f528 (+2840): *(u64 *)(r10 - 0x1000) = r7
03f530 (+2848): r5 = r10
03f538 (+2850): r1 = r9
03f540 (+2858): r2 = *(u64 *)(r10 - 0x928)
03f548 (+2860): r3 = *(u64 *)(r10 - 0x938)
03f550 (+2868): r4 = *(u64 *)(r10 - 0x920)
03f558 (+2870): call -0x2b98 ; call 0x298a0 / window 322
03f560 (+2878): r2 = 0x0
03f568 (+2880): r1 = 0x1
03f570 (+2888): goto +0x22d <.text+0x405c0> ; branch 0x406e0 / relative 0x39f8
03f578 (+2890): r1 = 0x9aaed ll ; pointer 0x9aaed; data32hex 49583a2053657420546f6b656e205374616e6461726449583a2053657420436f
03f588 (+28a0): r2 = 0x16
03f590 (+28a8): call -0x1 ; external sol_log_
03f598 (+28b0): r1 = r9
03f5a0 (+28b8): r2 = *(u64 *)(r10 - 0x928)
03f5a8 (+28c0): r3 = *(u64 *)(r10 - 0x938)
03f5b0 (+28c8): r4 = *(u64 *)(r10 - 0x920)
03f5b8 (+28d0): call -0x21ea ; call 0x2e670 / window 331
03f5c0 (+28d8): goto +0x221 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f5c8 (+28e0): r6 = *(u64 *)(r10 - 0x6c0)
03f5d0 (+28e8): r1 = 0x9aac4 ll ; pointer 0x9aac4; data32hex 49583a20427562626c6567756d2050726f6772616d2053657420436f6c6c6563
03f5e0 (+28f8): r2 = 0x29
03f5e8 (+2900): call -0x1 ; external sol_log_
03f5f0 (+2908): r1 = r9
03f5f8 (+2910): r2 = *(u64 *)(r10 - 0x928)
03f600 (+2918): r3 = *(u64 *)(r10 - 0x938)
03f608 (+2920): r4 = *(u64 *)(r10 - 0x920)
03f610 (+2928): r5 = r6
03f618 (+2930): call -0x5c5d ; call 0x11338 / window 295
03f620 (+2938): goto +0x215 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f628 (+2940): r6 = *(u64 *)(r10 - 0x6c0)
03f630 (+2948): r1 = 0x9ac53 ll ; pointer 0x9ac53; data32hex 49583a205573652f5574696c697a6520546f6b656e49583a2056657269667920
03f640 (+2958): r2 = 0x15
03f648 (+2960): call -0x1 ; external sol_log_
03f650 (+2968): r1 = r9
03f658 (+2970): r2 = *(u64 *)(r10 - 0x928)
03f660 (+2978): r3 = *(u64 *)(r10 - 0x938)
03f668 (+2980): r4 = *(u64 *)(r10 - 0x920)
03f670 (+2988): r5 = r6
03f678 (+2990): call -0xb45 ; call 0x39c58 / window 346
03f680 (+2998): goto +0x209 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f688 (+29a0): r1 = 0x9ac0b ll ; pointer 0x9ac0b; data32hex 49583a20556e76657269667920436f6c6c656374696f6e49583a205265766f6b
03f698 (+29b0): r2 = 0x17
03f6a0 (+29b8): call -0x1 ; external sol_log_
03f6a8 (+29c0): r1 = r9
03f6b0 (+29c8): r2 = *(u64 *)(r10 - 0x928)
03f6b8 (+29d0): r3 = *(u64 *)(r10 - 0x938)
03f6c0 (+29d8): r4 = *(u64 *)(r10 - 0x920)
03f6c8 (+29e0): call -0x49e7 ; call 0x1a798 / window 306
03f6d0 (+29e8): goto +0x1ff <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f6d8 (+29f0): r1 = 0x9acc5 ll ; pointer 0x9acc5; data32hex 49583a20436f6e76657274204d61737465722045646974696f6e20563120746f
03f6e8 (+2a00): r2 = 0x23
03f6f0 (+2a08): call -0x1 ; external sol_log_
03f6f8 (+2a10): r1 = *(u64 *)(r10 - 0x920)
03f700 (+2a18): if r1 > 0x2 goto +0xd5 <.text+0x3fc90> ; branch 0x3fdb0 / relative 0x30c8
03f708 (+2a20): goto +0x8 <.text+0x3f630> ; branch 0x3f750 / relative 0x2a68
03f710 (+2a28): r1 = *(u64 *)(r10 - 0x6c0)
03f718 (+2a30): *(u64 *)(r10 - 0x940) = r1
03f720 (+2a38): r1 = 0x9ace8 ll ; pointer 0x9ace8; data32hex 49583a204d696e74204e65772045646974696f6e2066726f6d204d6173746572
03f730 (+2a48): r2 = 0x32
03f738 (+2a50): call -0x1 ; external sol_log_
03f740 (+2a58): r1 = *(u64 *)(r10 - 0x920)
03f748 (+2a60): if r1 > 0xc goto +0x7f <.text+0x3fa28> ; branch 0x3fb48 / relative 0x2e60
03f750 (+2a68): r1 = 0xa
03f758 (+2a70): r2 = *(u64 *)(r10 - 0x930)
03f760 (+2a78): *(u32 *)(r2 + 0x0) = r1
03f768 (+2a80): goto +0x1ec <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f770 (+2a88): r1 = 0x9ac68 ll ; pointer 0x9ac68; data32hex 49583a2056657269667920436f6c6c656374696f6e563320437265617465204d
03f780 (+2a98): r2 = 0x15
03f788 (+2aa0): call -0x1 ; external sol_log_
03f790 (+2aa8): r1 = r9
03f798 (+2ab0): r2 = *(u64 *)(r10 - 0x928)
03f7a0 (+2ab8): r3 = *(u64 *)(r10 - 0x938)
03f7a8 (+2ac0): r4 = *(u64 *)(r10 - 0x920)
03f7b0 (+2ac8): call -0x4747 ; call 0x1bd80 / window 308
03f7b8 (+2ad0): goto +0x1e2 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03f7c0 (+2ad8): r6 = r10
03f7c8 (+2ae0): r6 += -0x130
03f7d0 (+2ae8): r2 = r10
03f7d8 (+2af0): r2 += -0x6c0
03f7e0 (+2af8): r1 = r6
03f7e8 (+2b00): r3 = 0xc9
03f7f0 (+2b08): call 0xb2f4 ; call 0x98f98 / window 1246
03f7f8 (+2b10): r8 = *(u8 *)(r10 - 0x5f6)
03f800 (+2b18): r9 = *(u8 *)(r10 - 0x5f7)
03f808 (+2b20): r1 = 0x9ac95 ll ; pointer 0x9ac95; data32hex 49583a20557064617465204d65746164617461204163636f756e747320763249
03f818 (+2b30): r2 = 0x1f
03f820 (+2b38): call -0x1 ; external sol_log_
03f828 (+2b40): r7 = r10
03f830 (+2b48): r7 += -0x368
03f838 (+2b50): r1 = r7
03f840 (+2b58): r2 = r6
03f848 (+2b60): r3 = 0xa8
03f850 (+2b68): call 0xb2e8 ; call 0x98f98 / window 1246
03f858 (+2b70): r6 = r10
03f860 (+2b78): r6 += -0x568
03f868 (+2b80): r2 = r10
03f870 (+2b88): r2 += -0x88
03f878 (+2b90): r1 = r6
03f880 (+2b98): r3 = 0x21
03f888 (+2ba0): call 0xb2e1 ; call 0x98f98 / window 1246
03f890 (+2ba8): *(u64 *)(r10 - 0xff0) = r9
03f898 (+2bb0): *(u64 *)(r10 - 0xfe8) = r8
03f8a0 (+2bb8): *(u64 *)(r10 - 0xff8) = r6
03f8a8 (+2bc0): *(u64 *)(r10 - 0x1000) = r7
03f8b0 (+2bc8): r5 = r10
03f8b8 (+2bd0): r1 = *(u64 *)(r10 - 0x930)
03f8c0 (+2bd8): r2 = *(u64 *)(r10 - 0x928)
03f8c8 (+2be0): r3 = *(u64 *)(r10 - 0x938)
03f8d0 (+2be8): r4 = *(u64 *)(r10 - 0x920)
03f8d8 (+2bf0): call -0x16dd ; call 0x341f8 / window 338
03f8e0 (+2bf8): r2 = 0x1
03f8e8 (+2c00): r1 = 0x0
03f8f0 (+2c08): goto +0x1bd <.text+0x405c0> ; branch 0x406e0 / relative 0x39f8
03f8f8 (+2c10): r3 = *(u64 *)(r10 - 0x6b0)
03f900 (+2c18): r2 = *(u64 *)(r10 - 0x6b8)
03f908 (+2c20): r1 = *(u64 *)(r10 - 0x6c0)
03f910 (+2c28): r8 = *(u32 *)(r10 - 0x6c4)
03f918 (+2c30): r4 = *(u64 *)(r10 - 0x930)
03f920 (+2c38): *(u64 *)(r4 + 0x18) = r3
03f928 (+2c40): *(u64 *)(r4 + 0x10) = r2
03f930 (+2c48): *(u64 *)(r4 + 0x8) = r1
03f938 (+2c50): *(u32 *)(r4 + 0x4) = r8
03f940 (+2c58): *(u32 *)(r4 + 0x0) = r9
03f948 (+2c60): goto -0x265 <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03f950 (+2c68): r8 = r10
03f958 (+2c70): r8 += -0x368
03f960 (+2c78): r2 = r10
03f968 (+2c80): r2 += -0x6c8
03f970 (+2c88): r1 = r8
03f978 (+2c90): r3 = 0x108
03f980 (+2c98): call 0xb2c2 ; call 0x98f98 / window 1246
03f988 (+2ca0): r1 = r10
03f990 (+2ca8): r1 += -0x24
03f998 (+2cb0): r2 = r10
03f9a0 (+2cb8): r2 += -0x5bc
03f9a8 (+2cc0): r3 = 0x24
03f9b0 (+2cc8): call 0xb2bc ; call 0x98f98 / window 1246
03f9b8 (+2cd0): r1 = r10
03f9c0 (+2cd8): r1 += -0x130
03f9c8 (+2ce0): r2 = r8
03f9d0 (+2ce8): r3 = 0x108
03f9d8 (+2cf0): call 0xb2b7 ; call 0x98f98 / window 1246
03f9e0 (+2cf8): *(u32 *)(r10 - 0x28) = r6
03f9e8 (+2d00): r1 = r10
03f9f0 (+2d08): r1 += -0x10c
03f9f8 (+2d10): *(u64 *)(r10 - 0x6c8) = r1
03fa00 (+2d18): r1 = r10
03fa08 (+2d20): r1 += -0x6c8
03fa10 (+2d28): r2 = r9
03fa18 (+2d30): call -0x79a9 ; call 0x2cd8 / window 42
03fa20 (+2d38): if r0 != 0x0 goto +0x1 <.text+0x3f910> ; branch 0x3fa30 / relative 0x2d48
03fa28 (+2d40): goto +0xa7 <.text+0x3fe48> ; branch 0x3ff68 / relative 0x3280
03fa30 (+2d48): r1 = 0xf00000000 ll
03fa40 (+2d58): r2 = *(u64 *)(r10 - 0x930)
03fa48 (+2d60): *(u64 *)(r2 + 0x0) = r1
03fa50 (+2d68): r1 = r10
03fa58 (+2d70): r1 += -0xe8
03fa60 (+2d78): call -0x7939 ; call 0x30a0 / window 59
03fa68 (+2d80): r1 = r10
03fa70 (+2d88): r1 += -0x438
03fa78 (+2d90): call -0x7930 ; call 0x3100 / window 60
03fa80 (+2d98): goto -0x28c <.text+0x3e508> ; branch 0x3e628 / relative 0x1940
03fa88 (+2da0): r1 = 0x16
03fa90 (+2da8): goto -0x2c8 <.text+0x3e338> ; branch 0x3e458 / relative 0x1770
03fa98 (+2db0): r2 = *(u64 *)(r10 - 0x938)
03faa0 (+2db8): r2 += 0xf0
03faa8 (+2dc0): r1 = r10
03fab0 (+2dc8): r1 += -0x130
03fab8 (+2dd0): *(u64 *)(r10 - 0x920) = r2
03fac0 (+2dd8): call 0x109f ; call 0x47fc0 / window 419
03fac8 (+2de0): r9 = *(u32 *)(r10 - 0x28)
03fad0 (+2de8): if r9 != 0x2 goto +0xa8 <.text+0x3fef8> ; branch 0x40018 / relative 0x3330
03fad8 (+2df0): r1 = *(u64 *)(r10 - 0x118)
03fae0 (+2df8): *(u64 *)(r10 - 0x350) = r1
03fae8 (+2e00): r2 = *(u64 *)(r10 - 0x120)
03faf0 (+2e08): *(u64 *)(r10 - 0x358) = r2
03faf8 (+2e10): r3 = *(u64 *)(r10 - 0x128)
03fb00 (+2e18): *(u64 *)(r10 - 0x360) = r3
03fb08 (+2e20): r4 = *(u64 *)(r10 - 0x130)
03fb10 (+2e28): *(u64 *)(r10 - 0x368) = r4
03fb18 (+2e30): r5 = *(u64 *)(r10 - 0x930)
03fb20 (+2e38): *(u64 *)(r5 + 0x18) = r1
03fb28 (+2e40): *(u64 *)(r5 + 0x10) = r2
03fb30 (+2e48): *(u64 *)(r5 + 0x8) = r3
03fb38 (+2e50): *(u64 *)(r5 + 0x0) = r4
03fb40 (+2e58): goto +0x171 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03fb48 (+2e60): r1 = *(u64 *)(r10 - 0x938)
03fb50 (+2e68): r1 = *(u64 *)(r1 + 0x210)
03fb58 (+2e70): r2 = 0x99a48 ll ; pointer 0x99a48; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03fb68 (+2e80): call -0x79cc ; call 0x2d10 / window 44
03fb70 (+2e88): if r0 != 0x0 goto +0xca <.text+0x400a8> ; branch 0x401c8 / relative 0x34e0
03fb78 (+2e90): r3 = *(u64 *)(r10 - 0x938)
03fb80 (+2e98): r6 = r3
03fb88 (+2ea0): r6 += 0x120
03fb90 (+2ea8): r1 = r10
03fb98 (+2eb0): r1 += -0x130
03fba0 (+2eb8): r2 = r6
03fba8 (+2ec0): call 0x123f ; call 0x48da8 / window 427
03fbb0 (+2ec8): r1 = *(u32 *)(r10 - 0x130)
03fbb8 (+2ed0): if r1 == 0x16 goto +0x1 <.text+0x3faa8> ; branch 0x3fbc8 / relative 0x2ee0
03fbc0 (+2ed8): goto +0x69 <.text+0x3fdf0> ; branch 0x3ff10 / relative 0x3228
03fbc8 (+2ee0): r1 = *(u64 *)(r10 - 0x938)
03fbd0 (+2ee8): r2 = r1
03fbd8 (+2ef0): r2 += 0x240
03fbe0 (+2ef8): *(u64 *)(r10 - 0x920) = r2
03fbe8 (+2f00): r2 = r1
03fbf0 (+2f08): r2 += 0x210
03fbf8 (+2f10): *(u64 *)(r10 - 0x948) = r2
03fc00 (+2f18): r2 = r1
03fc08 (+2f20): r2 += 0x1e0
03fc10 (+2f28): *(u64 *)(r10 - 0x950) = r2
03fc18 (+2f30): r2 = r1
03fc20 (+2f38): r2 += 0x1b0
03fc28 (+2f40): *(u64 *)(r10 - 0x958) = r2
03fc30 (+2f48): r5 = r1
03fc38 (+2f50): r5 += 0x180
03fc40 (+2f58): r0 = r1
03fc48 (+2f60): r0 += 0x150
03fc50 (+2f68): r8 = r1
03fc58 (+2f70): r8 += 0xf0
03fc60 (+2f78): r9 = r1
03fc68 (+2f80): r9 += 0xc0
03fc70 (+2f88): r3 = r1
03fc78 (+2f90): r3 += 0x90
03fc80 (+2f98): r7 = r1
03fc88 (+2fa0): r7 += 0x60
03fc90 (+2fa8): r2 = r1
03fc98 (+2fb0): r2 += 0x30
03fca0 (+2fb8): r4 = *(u64 *)(r10 - 0x920)
03fca8 (+2fc0): *(u64 *)(r10 - 0xc0) = r4
03fcb0 (+2fc8): r4 = *(u64 *)(r10 - 0x948)
03fcb8 (+2fd0): *(u64 *)(r10 - 0xc8) = r4
03fcc0 (+2fd8): r4 = *(u64 *)(r10 - 0x950)
03fcc8 (+2fe0): *(u64 *)(r10 - 0xd0) = r4
03fcd0 (+2fe8): r4 = *(u64 *)(r10 - 0x958)
03fcd8 (+2ff0): *(u64 *)(r10 - 0xd8) = r4
03fce0 (+2ff8): *(u64 *)(r10 - 0xe0) = r5
03fce8 (+3000): *(u64 *)(r10 - 0xe8) = r0
03fcf0 (+3008): *(u64 *)(r10 - 0xf0) = r6
03fcf8 (+3010): *(u64 *)(r10 - 0xf8) = r8
03fd00 (+3018): *(u64 *)(r10 - 0x100) = r9
03fd08 (+3020): *(u64 *)(r10 - 0x108) = r3
03fd10 (+3028): *(u64 *)(r10 - 0x110) = r7
03fd18 (+3030): *(u64 *)(r10 - 0x118) = r2
03fd20 (+3038): *(u64 *)(r10 - 0x120) = r1
03fd28 (+3040): r1 = 0x0
03fd30 (+3048): *(u64 *)(r10 - 0x130) = r1
03fd38 (+3050): *(u64 *)(r10 - 0x128) = r1
03fd40 (+3058): r1 = r10
03fd48 (+3060): r1 += -0x368
03fd50 (+3068): r3 = r10
03fd58 (+3070): r3 += -0x130
03fd60 (+3078): r2 = *(u64 *)(r10 - 0x928)
03fd68 (+3080): r4 = *(u64 *)(r10 - 0x940)
03fd70 (+3088): call 0x12a5 ; call 0x492a0 / window 429
03fd78 (+3090): r1 = *(u32 *)(r10 - 0x368)
03fd80 (+3098): if r1 == 0x16 goto +0x1 <.text+0x3fc70> ; branch 0x3fd90 / relative 0x30a8
03fd88 (+30a0): goto +0x110 <.text+0x404f0> ; branch 0x40610 / relative 0x3928
03fd90 (+30a8): r1 = *(u64 *)(r10 - 0x930)
03fd98 (+30b0): r2 = *(u64 *)(r10 - 0x938)
03fda0 (+30b8): call 0x126f ; call 0x49120 / window 428
03fda8 (+30c0): goto +0x124 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03fdb0 (+30c8): r1 = r10
03fdb8 (+30d0): r1 += -0x130
03fdc0 (+30d8): r2 = *(u64 *)(r10 - 0x938)
03fdc8 (+30e0): r3 = *(u64 *)(r10 - 0x928)
03fdd0 (+30e8): call -0x6035 ; call 0xfc30 / window 275
03fdd8 (+30f0): r1 = *(u32 *)(r10 - 0x130)
03fde0 (+30f8): if r1 != 0x16 goto +0x25 <.text+0x3fdf0> ; branch 0x3ff10 / relative 0x3228
03fde8 (+3100): r7 = *(u64 *)(r10 - 0x938)
03fdf0 (+3108): r7 += 0x30
03fdf8 (+3110): r1 = r10
03fe00 (+3118): r1 += -0x130
03fe08 (+3120): r2 = r7
03fe10 (+3128): r3 = 0x99a48 ll ; pointer 0x99a48; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03fe20 (+3138): call -0x603f ; call 0xfc30 / window 275
03fe28 (+3140): r1 = *(u32 *)(r10 - 0x130)
03fe30 (+3148): if r1 == 0x16 goto +0x1 <.text+0x3fd20> ; branch 0x3fe40 / relative 0x3158
03fe38 (+3150): goto +0x1a <.text+0x3fdf0> ; branch 0x3ff10 / relative 0x3228
03fe40 (+3158): r8 = *(u64 *)(r10 - 0x938)
03fe48 (+3160): r8 += 0x60
03fe50 (+3168): r1 = r10
03fe58 (+3170): r1 += -0x130
03fe60 (+3178): r2 = r8
03fe68 (+3180): r3 = 0x99a48 ll ; pointer 0x99a48; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03fe78 (+3190): call -0x604a ; call 0xfc30 / window 275
03fe80 (+3198): r1 = *(u32 *)(r10 - 0x130)
03fe88 (+31a0): if r1 == 0x16 goto +0x1 <.text+0x3fd78> ; branch 0x3fe98 / relative 0x31b0
03fe90 (+31a8): goto +0xf <.text+0x3fdf0> ; branch 0x3ff10 / relative 0x3228
03fe98 (+31b0): r1 = r10
03fea0 (+31b8): r1 += -0x130
03fea8 (+31c0): r2 = *(u64 *)(r10 - 0x938)
03feb0 (+31c8): call 0xdcf ; call 0x46d30 / window 412
03feb8 (+31d0): r6 = *(u64 *)(r10 - 0x120)
03fec0 (+31d8): if r6 != 0x2 goto +0x11a <.text+0x40678> ; branch 0x40798 / relative 0x3ab0
03fec8 (+31e0): r1 = *(u64 *)(r10 - 0x100)
03fed0 (+31e8): *(u64 *)(r10 - 0x550) = r1
03fed8 (+31f0): r2 = *(u64 *)(r10 - 0x108)
03fee0 (+31f8): *(u64 *)(r10 - 0x558) = r2
03fee8 (+3200): r3 = *(u64 *)(r10 - 0x110)
03fef0 (+3208): *(u64 *)(r10 - 0x560) = r3
03fef8 (+3210): r4 = *(u64 *)(r10 - 0x118)
03ff00 (+3218): *(u64 *)(r10 - 0x568) = r4
03ff08 (+3220): goto -0x7f <.text+0x3f9f8> ; branch 0x3fb18 / relative 0x2e30
03ff10 (+3228): r2 = *(u32 *)(r10 - 0x114)
03ff18 (+3230): r3 = *(u64 *)(r10 - 0x930)
03ff20 (+3238): *(u32 *)(r3 + 0x1c) = r2
03ff28 (+3240): r2 = *(u64 *)(r10 - 0x11c)
03ff30 (+3248): *(u64 *)(r3 + 0x14) = r2
03ff38 (+3250): r2 = *(u64 *)(r10 - 0x124)
03ff40 (+3258): *(u64 *)(r3 + 0xc) = r2
03ff48 (+3260): r2 = *(u64 *)(r10 - 0x12c)
03ff50 (+3268): *(u64 *)(r3 + 0x4) = r2
03ff58 (+3270): *(u32 *)(r3 + 0x0) = r1
03ff60 (+3278): goto +0xed <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
03ff68 (+3280): if r7 != 0x0 goto +0x1 <.text+0x3fe58> ; branch 0x3ff78 / relative 0x3290
03ff70 (+3288): goto +0x52 <.text+0x400e8> ; branch 0x40208 / relative 0x3520
03ff78 (+3290): r1 = r10
03ff80 (+3298): r1 += -0x6c8
03ff88 (+32a0): r2 = *(u64 *)(r10 - 0x928)
03ff90 (+32a8): r3 = *(u64 *)(r10 - 0x938)
03ff98 (+32b0): call 0x6c8b ; call 0x763f8 / window 772
03ffa0 (+32b8): r1 = *(u32 *)(r10 - 0x6c8)
03ffa8 (+32c0): if r1 != 0x16 goto +0x137 <.text+0x40848> ; branch 0x40968 / relative 0x3c80
03ffb0 (+32c8): r1 = *(u64 *)(r10 - 0x920)
03ffb8 (+32d0): call 0x8a36 ; call 0x85170 / window 980
03ffc0 (+32d8): if r0 == 0x0 goto +0x6 <.text+0x3fed8> ; branch 0x3fff8 / relative 0x3310
03ffc8 (+32e0): r1 = *(u64 *)(r10 - 0x938)
03ffd0 (+32e8): r1 += 0x48
03ffd8 (+32f0): r2 = 0x9eee8 ll ; pointer 0x9eee8; data32hex 00000000c899090000000000e6a4090022000000000000005200000026000000
03ffe8 (+3300): call -0x7a67 ; call 0x2cb8 / window 41
03fff0 (+3308): if r0 != 0x0 goto +0x126 <.text+0x40808> ; branch 0x40928 / relative 0x3c40
03fff8 (+3310): r1 = 0x16
040000 (+3318): r2 = *(u64 *)(r10 - 0x930)
040008 (+3320): *(u32 *)(r2 + 0x0) = r1
040010 (+3328): goto -0xb9 <.text+0x3f930> ; branch 0x3fa50 / relative 0x2d68
040018 (+3330): r6 = r10
040020 (+3338): r6 += -0x368
040028 (+3340): r2 = r10
040030 (+3348): r2 += -0x130
040038 (+3350): r1 = r6
040040 (+3358): r3 = 0x108
040048 (+3360): call 0xb1e9 ; call 0x98f98 / window 1246
040050 (+3368): r1 = r10
040058 (+3370): r1 += -0x45c
040060 (+3378): r2 = r10
040068 (+3380): r2 += -0x24
040070 (+3388): r3 = 0x24
040078 (+3390): call 0xb1e3 ; call 0x98f98 / window 1246
040080 (+3398): r1 = r10
040088 (+33a0): r1 += -0x568
040090 (+33a8): r2 = r6
040098 (+33b0): r3 = 0x108
0400a0 (+33b8): call 0xb1de ; call 0x98f98 / window 1246
0400a8 (+33c0): *(u32 *)(r10 - 0x460) = r9
0400b0 (+33c8): r1 = *(u64 *)(r10 - 0x938)
0400b8 (+33d0): r2 = *(u64 *)(r1 + 0x40)
0400c0 (+33d8): r2 += 0x10
0400c8 (+33e0): r1 = r10
0400d0 (+33e8): r1 += -0x8d8
0400d8 (+33f0): r3 = 0x9eff0 ll ; pointer 0x9eff0; data32hex 00000000b0a609003900000000000000280000003b0000000000000068990900
0400e8 (+3400): call -0x7902 ; call 0x38e0 / window 87
0400f0 (+3408): r1 = *(u64 *)(r10 - 0x8d8)
0400f8 (+3410): r2 = *(u64 *)(r1 + 0x0)
040100 (+3418): r3 = *(u64 *)(r1 + 0x8)
040108 (+3420): r9 = *(u64 *)(r10 - 0x8d0)
040110 (+3428): r1 = r10
040118 (+3430): r1 += -0x130
040120 (+3438): call 0x2bef ; call 0x560a0 / window 451
040128 (+3440): r7 = *(u32 *)(r10 - 0x130)
040130 (+3448): if r7 == 0x2 goto +0x1 <.text+0x40020> ; branch 0x40140 / relative 0x3458
040138 (+3450): goto +0x3d <.text+0x40208> ; branch 0x40328 / relative 0x3640
040140 (+3458): r1 = *(u64 *)(r10 - 0x110)
040148 (+3460): *(u64 *)(r10 - 0x34c) = r1
040150 (+3468): r2 = *(u64 *)(r10 - 0x118)
040158 (+3470): *(u64 *)(r10 - 0x354) = r2
040160 (+3478): r3 = *(u64 *)(r10 - 0x120)
040168 (+3480): *(u64 *)(r10 - 0x35c) = r3
040170 (+3488): r4 = *(u64 *)(r10 - 0x128)
040178 (+3490): *(u64 *)(r10 - 0x364) = r4
040180 (+3498): r5 = *(u64 *)(r10 - 0x930)
040188 (+34a0): *(u64 *)(r5 + 0x18) = r1
040190 (+34a8): *(u64 *)(r5 + 0x10) = r2
040198 (+34b0): *(u64 *)(r5 + 0x8) = r3
0401a0 (+34b8): *(u64 *)(r5 + 0x0) = r4
0401a8 (+34c0): r1 = *(u64 *)(r9 + 0x0)
0401b0 (+34c8): r1 += -0x1
0401b8 (+34d0): *(u64 *)(r9 + 0x0) = r1
0401c0 (+34d8): goto +0x9e <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
0401c8 (+34e0): r1 = 0x3e00000000 ll
0401d8 (+34f0): goto -0x2f8 <.text+0x3e900> ; branch 0x3ea20 / relative 0x1d38
0401e0 (+34f8): r1 = 0x0
0401e8 (+3500): r2 = 0x0
0401f0 (+3508): r3 = 0x9f3b0 ll ; pointer 0x9f3b0; data32hex 00000000cea909001c000000000000006c010000210000000000000068980900
040200 (+3518): goto -0x38f <.text+0x3e470> ; branch 0x3e590 / relative 0x18a8
040208 (+3520): r1 = *(u64 *)(r10 - 0x938)
040210 (+3528): r2 = *(u64 *)(r1 + 0x70)
040218 (+3530): r2 += 0x10
040220 (+3538): r1 = r10
040228 (+3540): r1 += -0x878
040230 (+3548): r3 = 0x9eea0 ll ; pointer 0x9eea0; data32hex 00000000e6a4090022000000000000003d0000004f00000000000000e6a40900
040240 (+3558): call -0x792d ; call 0x38e0 / window 87
040248 (+3560): r1 = *(u64 *)(r10 - 0x878)
040250 (+3568): r2 = *(u64 *)(r1 + 0x0)
040258 (+3570): r3 = *(u64 *)(r1 + 0x8)
040260 (+3578): r1 = *(u64 *)(r10 - 0x870)
040268 (+3580): *(u64 *)(r10 - 0x958) = r1
040270 (+3588): r1 = r10
040278 (+3590): r1 += -0x6c8
040280 (+3598): call 0x776a ; call 0x7bdd8 / window 850
040288 (+35a0): r1 = *(u32 *)(r10 - 0x6b8)
040290 (+35a8): *(u64 *)(r10 - 0x950) = r1
040298 (+35b0): if r1 != 0x2 goto +0x28e <.text+0x415f0> ; branch 0x41710 / relative 0x4a28
0402a0 (+35b8): r1 = *(u64 *)(r10 - 0x698)
0402a8 (+35c0): *(u64 *)(r10 - 0x21c) = r1
0402b0 (+35c8): r2 = *(u64 *)(r10 - 0x6a0)
0402b8 (+35d0): *(u64 *)(r10 - 0x224) = r2
0402c0 (+35d8): r3 = *(u64 *)(r10 - 0x6a8)
0402c8 (+35e0): *(u64 *)(r10 - 0x22c) = r3
0402d0 (+35e8): r4 = *(u64 *)(r10 - 0x6b0)
0402d8 (+35f0): *(u64 *)(r10 - 0x234) = r4
0402e0 (+35f8): r5 = *(u64 *)(r10 - 0x930)
0402e8 (+3600): *(u64 *)(r5 + 0x18) = r1
0402f0 (+3608): *(u64 *)(r5 + 0x10) = r2
0402f8 (+3610): *(u64 *)(r5 + 0x8) = r3
040300 (+3618): *(u64 *)(r5 + 0x0) = r4
040308 (+3620): r2 = *(u64 *)(r10 - 0x958)
040310 (+3628): r1 = *(u64 *)(r2 + 0x0)
040318 (+3630): r1 += -0x1
040320 (+3638): goto -0x11c <.text+0x3f928> ; branch 0x3fa48 / relative 0x2d60
040328 (+3640): r6 = r10
040330 (+3648): r6 += -0x368
040338 (+3650): r2 = r10
040340 (+3658): r2 += -0x12c
040348 (+3660): r1 = r6
040350 (+3668): r3 = 0x24
040358 (+3670): call 0xb187 ; call 0x98f98 / window 1246
040360 (+3678): r1 = r10
040368 (+3680): r1 += -0x410
040370 (+3688): r2 = r10
040378 (+3690): r2 += -0x108
040380 (+3698): r3 = 0x30
040388 (+36a0): call 0xb181 ; call 0x98f98 / window 1246
040390 (+36a8): r1 = r10
040398 (+36b0): r1 += -0x434
0403a0 (+36b8): r2 = r6
0403a8 (+36c0): r3 = 0x24
0403b0 (+36c8): call 0xb17c ; call 0x98f98 / window 1246
0403b8 (+36d0): *(u32 *)(r10 - 0x438) = r7
0403c0 (+36d8): r1 = *(u64 *)(r9 + 0x0)
0403c8 (+36e0): r1 += -0x1
0403d0 (+36e8): *(u64 *)(r9 + 0x0) = r1
0403d8 (+36f0): r1 = r10
0403e0 (+36f8): r1 += -0x8e8
0403e8 (+3700): r8 = *(u64 *)(r10 - 0x928)
0403f0 (+3708): r2 = r8
0403f8 (+3710): call 0x8bc9 ; call 0x86248 / window 990
040400 (+3718): r9 = *(u64 *)(r10 - 0x938)
040408 (+3720): r2 = *(u64 *)(r9 + 0x30)
040410 (+3728): r6 = *(u64 *)(r10 - 0x8e8)
040418 (+3730): r7 = *(u64 *)(r10 - 0x8e0)
040420 (+3738): r1 = r10
040428 (+3740): r1 += -0x8f8
040430 (+3748): *(u64 *)(r10 - 0x950) = r2
040438 (+3750): call 0x8bc1 ; call 0x86248 / window 990
040440 (+3758): r1 = 0x7
040448 (+3760): *(u64 *)(r10 - 0xf8) = r1
040450 (+3768): r1 = 0x9a255 ll ; pointer 0x9a255; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
040460 (+3778): *(u64 *)(r10 - 0x100) = r1
040468 (+3780): *(u64 *)(r10 - 0x118) = r7
040470 (+3788): *(u64 *)(r10 - 0x120) = r6
040478 (+3790): r1 = 0x8
040480 (+3798): *(u64 *)(r10 - 0x128) = r1
040488 (+37a0): r1 = 0x9a210 ll ; pointer 0x9a210; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
040498 (+37b0): *(u64 *)(r10 - 0x130) = r1
0404a0 (+37b8): r1 = *(u64 *)(r10 - 0x8f0)
0404a8 (+37c0): *(u64 *)(r10 - 0x108) = r1
0404b0 (+37c8): r1 = *(u64 *)(r10 - 0x8f8)
0404b8 (+37d0): *(u64 *)(r10 - 0x110) = r1
0404c0 (+37d8): r1 = r10
0404c8 (+37e0): r1 += -0x368
0404d0 (+37e8): r4 = r10
0404d8 (+37f0): r4 += -0x130
0404e0 (+37f8): r2 = r8
0404e8 (+3800): r3 = r9
0404f0 (+3808): r5 = 0x4
0404f8 (+3810): call -0x6126 ; call 0xfbd0 / window 273
040500 (+3818): r1 = *(u32 *)(r10 - 0x368)
040508 (+3820): if r1 == 0x16 goto +0x1 <.text+0x403f8> ; branch 0x40518 / relative 0x3830
040510 (+3828): goto +0x28 <.text+0x40538> ; branch 0x40658 / relative 0x3970
040518 (+3830): r2 = *(u64 *)(r10 - 0x938)
040520 (+3838): r2 += 0x120
040528 (+3840): r6 = *(u8 *)(r10 - 0x364)
040530 (+3848): r1 = r10
040538 (+3850): r1 += -0x130
040540 (+3858): r8 = r2
040548 (+3860): call -0x610d ; call 0xfce8 / window 277
040550 (+3868): r1 = *(u32 *)(r10 - 0x130)
040558 (+3870): if r1 == 0x16 goto +0x1 <.text+0x40448> ; branch 0x40568 / relative 0x3880
040560 (+3878): goto +0xa <.text+0x40498> ; branch 0x405b8 / relative 0x38d0
040568 (+3880): r3 = *(u64 *)(r10 - 0x938)
040570 (+3888): r3 += 0x90
040578 (+3890): r1 = r10
040580 (+3898): r1 += -0x130
040588 (+38a0): r2 = r10
040590 (+38a8): r2 += -0x438
040598 (+38b0): r9 = r3
0405a0 (+38b8): call -0x6209 ; call 0xf560 / window 270
0405a8 (+38c0): r1 = *(u32 *)(r10 - 0x130)
0405b0 (+38c8): if r1 == 0x16 goto +0x8a <.text+0x408e8> ; branch 0x40a08 / relative 0x3d20
0405b8 (+38d0): r2 = *(u32 *)(r10 - 0x114)
0405c0 (+38d8): r3 = *(u64 *)(r10 - 0x930)
0405c8 (+38e0): *(u32 *)(r3 + 0x1c) = r2
0405d0 (+38e8): r2 = *(u64 *)(r10 - 0x11c)
0405d8 (+38f0): *(u64 *)(r3 + 0x14) = r2
0405e0 (+38f8): r2 = *(u64 *)(r10 - 0x124)
0405e8 (+3900): *(u64 *)(r3 + 0xc) = r2
0405f0 (+3908): r2 = *(u64 *)(r10 - 0x12c)
0405f8 (+3910): *(u64 *)(r3 + 0x4) = r2
040600 (+3918): *(u32 *)(r3 + 0x0) = r1
040608 (+3920): goto +0x15 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
040610 (+3928): r2 = *(u32 *)(r10 - 0x34c)
040618 (+3930): r3 = *(u64 *)(r10 - 0x930)
040620 (+3938): *(u32 *)(r3 + 0x1c) = r2
040628 (+3940): r2 = *(u64 *)(r10 - 0x354)
040630 (+3948): *(u64 *)(r3 + 0x14) = r2
040638 (+3950): r2 = *(u64 *)(r10 - 0x35c)
040640 (+3958): *(u64 *)(r3 + 0xc) = r2
040648 (+3960): r2 = *(u64 *)(r10 - 0x364)
040650 (+3968): goto -0xe1 <.text+0x3fe30> ; branch 0x3ff50 / relative 0x3268
040658 (+3970): r2 = *(u8 *)(r10 - 0x364)
040660 (+3978): r3 = *(u32 *)(r10 - 0x34c)
040668 (+3980): r4 = *(u64 *)(r10 - 0x930)
040670 (+3988): *(u32 *)(r4 + 0x1c) = r3
040678 (+3990): r3 = *(u64 *)(r10 - 0x353)
040680 (+3998): *(u64 *)(r4 + 0x15) = r3
040688 (+39a0): r3 = *(u64 *)(r10 - 0x35b)
040690 (+39a8): *(u64 *)(r4 + 0xd) = r3
040698 (+39b0): r3 = *(u64 *)(r10 - 0x363)
0406a0 (+39b8): *(u64 *)(r4 + 0x5) = r3
0406a8 (+39c0): *(u8 *)(r4 + 0x4) = r2
0406b0 (+39c8): *(u32 *)(r4 + 0x0) = r1
0406b8 (+39d0): r1 = r10
0406c0 (+39d8): r1 += -0x520
0406c8 (+39e0): call -0x7ac6 ; call 0x30a0 / window 59
0406d0 (+39e8): r1 = 0x1
0406d8 (+39f0): r2 = 0x1
0406e0 (+39f8): r3 = *(u32 *)(r10 - 0x6c8)
0406e8 (+3a00): if r3 > 0x28 goto +0x8 <.text+0x40610> ; branch 0x40730 / relative 0x3a48
0406f0 (+3a08): r4 = 0x1
0406f8 (+3a10): r4 <<= r3
040700 (+3a18): r5 = 0x114001a2800 ll
040710 (+3a28): r4 &= r5
040718 (+3a30): if r4 != 0x0 goto -0x724 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
040720 (+3a38): if r3 == 0xf goto +0x4 <.text+0x40628> ; branch 0x40748 / relative 0x3a60
040728 (+3a40): if r3 == 0x21 goto +0x9 <.text+0x40658> ; branch 0x40778 / relative 0x3a90
040730 (+3a48): r1 = r10
040738 (+3a50): r1 += -0x6c8
040740 (+3a58): goto -0x40c <.text+0x3e5c8> ; branch 0x3e6e8 / relative 0x1a00
040748 (+3a60): if r1 != 0x0 goto +0x1 <.text+0x40638> ; branch 0x40758 / relative 0x3a70
040750 (+3a68): goto -0x72b <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
040758 (+3a70): r1 = r10
040760 (+3a78): r1 += -0x6c0
040768 (+3a80): call -0x7a03 ; call 0x3758 / window 81
040770 (+3a88): goto -0x72f <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
040778 (+3a90): if r2 == 0x0 goto -0x730 <.text+0x3cce0> ; branch 0x3ce00 / relative 0x118
040780 (+3a98): r1 = r10
040788 (+3aa0): r1 += -0x6c0
040790 (+3aa8): goto -0x3ff <.text+0x3e680> ; branch 0x3e7a0 / relative 0x1ab8
040798 (+3ab0): r1 = *(u64 *)(r10 - 0x128)
0407a0 (+3ab8): *(u64 *)(r10 - 0x360) = r1
0407a8 (+3ac0): r1 = *(u64 *)(r10 - 0x130)
0407b0 (+3ac8): *(u64 *)(r10 - 0x368) = r1
0407b8 (+3ad0): r1 = *(u64 *)(r10 - 0x118)
0407c0 (+3ad8): *(u64 *)(r10 - 0x568) = r1
0407c8 (+3ae0): r1 = *(u64 *)(r10 - 0x110)
0407d0 (+3ae8): *(u64 *)(r10 - 0x560) = r1
0407d8 (+3af0): r1 = *(u64 *)(r10 - 0x108)
0407e0 (+3af8): *(u64 *)(r10 - 0x558) = r1
0407e8 (+3b00): r1 = *(u64 *)(r10 - 0x100)
0407f0 (+3b08): *(u64 *)(r10 - 0x550) = r1
0407f8 (+3b10): r1 = r10
040800 (+3b18): r1 += -0x330
040808 (+3b20): r2 = r10
040810 (+3b28): r2 += -0xf8
040818 (+3b30): r3 = 0x28
040820 (+3b38): call 0xb0ee ; call 0x98f98 / window 1246
040828 (+3b40): *(u64 *)(r10 - 0x358) = r6
040830 (+3b48): r1 = *(u64 *)(r10 - 0x568)
040838 (+3b50): *(u64 *)(r10 - 0x350) = r1
040840 (+3b58): r1 = *(u64 *)(r10 - 0x560)
040848 (+3b60): *(u64 *)(r10 - 0x348) = r1
040850 (+3b68): r1 = *(u64 *)(r10 - 0x558)
040858 (+3b70): *(u64 *)(r10 - 0x340) = r1
040860 (+3b78): r1 = *(u64 *)(r10 - 0x550)
040868 (+3b80): *(u64 *)(r10 - 0x338) = r1
040870 (+3b88): r1 = r10
040878 (+3b90): r1 += -0x130
040880 (+3b98): r2 = r8
040888 (+3ba0): call -0x6269 ; call 0xf548 / window 269
040890 (+3ba8): r1 = *(u32 *)(r10 - 0x130)
040898 (+3bb0): if r1 == 0x2 goto +0x24 <.text+0x408a0> ; branch 0x409c0 / relative 0x3cd8
0408a0 (+3bb8): r6 = *(u64 *)(r10 - 0x108)
0408a8 (+3bc0): r1 = r10
0408b0 (+3bc8): r1 += -0x130
0408b8 (+3bd0): r2 = r7
0408c0 (+3bd8): call -0x6270 ; call 0xf548 / window 269
0408c8 (+3be0): r1 = *(u32 *)(r10 - 0x130)
0408d0 (+3be8): if r1 == 0x2 goto +0x1d <.text+0x408a0> ; branch 0x409c0 / relative 0x3cd8
0408d8 (+3bf0): r9 = *(u64 *)(r10 - 0x108)
0408e0 (+3bf8): r2 = *(u64 *)(r7 + 0x0)
0408e8 (+3c00): r1 = r10
0408f0 (+3c08): r1 += -0x328
0408f8 (+3c10): call -0x7b7e ; call 0x2d10 / window 44
040900 (+3c18): if r0 != 0x0 goto +0x1 <.text+0x407f0> ; branch 0x40910 / relative 0x3c28
040908 (+3c20): goto +0x3b <.text+0x409c8> ; branch 0x40ae8 / relative 0x3e00
040910 (+3c28): r1 = 0x1d00000000 ll
040920 (+3c38): goto -0x3e1 <.text+0x3e900> ; branch 0x3ea20 / relative 0x1d38
040928 (+3c40): r1 = r10
040930 (+3c48): r1 += -0x6c8
040938 (+3c50): r2 = *(u64 *)(r10 - 0x928)
040940 (+3c58): r3 = *(u64 *)(r10 - 0x920)
040948 (+3c60): call 0x6b55 ; call 0x763f8 / window 772
040950 (+3c68): r1 = *(u32 *)(r10 - 0x6c8)
040958 (+3c70): if r1 != 0x16 goto +0x1 <.text+0x40848> ; branch 0x40968 / relative 0x3c80
040960 (+3c78): goto -0x12e <.text+0x3fed8> ; branch 0x3fff8 / relative 0x3310
040968 (+3c80): r2 = *(u32 *)(r10 - 0x6ac)
040970 (+3c88): r3 = *(u64 *)(r10 - 0x930)
040978 (+3c90): *(u32 *)(r3 + 0x1c) = r2
040980 (+3c98): r2 = *(u64 *)(r10 - 0x6b4)
040988 (+3ca0): *(u64 *)(r3 + 0x14) = r2
040990 (+3ca8): r2 = *(u64 *)(r10 - 0x6bc)
040998 (+3cb0): *(u64 *)(r3 + 0xc) = r2
0409a0 (+3cb8): r2 = *(u64 *)(r10 - 0x6c4)
0409a8 (+3cc0): *(u64 *)(r3 + 0x4) = r2
0409b0 (+3cc8): *(u32 *)(r3 + 0x0) = r1
0409b8 (+3cd0): goto -0x1ee <.text+0x3f930> ; branch 0x3fa50 / relative 0x2d68
0409c0 (+3cd8): r1 = *(u64 *)(r10 - 0x110)
0409c8 (+3ce0): *(u64 *)(r10 - 0x54c) = r1
0409d0 (+3ce8): r2 = *(u64 *)(r10 - 0x118)
0409d8 (+3cf0): *(u64 *)(r10 - 0x554) = r2
0409e0 (+3cf8): r3 = *(u64 *)(r10 - 0x120)
0409e8 (+3d00): *(u64 *)(r10 - 0x55c) = r3
0409f0 (+3d08): r4 = *(u64 *)(r10 - 0x128)
0409f8 (+3d10): *(u64 *)(r10 - 0x564) = r4
040a00 (+3d18): goto -0x1de <.text+0x3f9f8> ; branch 0x3fb18 / relative 0x2e30
040a08 (+3d20): r1 = r10
040a10 (+3d28): r1 += -0x130
040a18 (+3d30): r2 = *(u64 *)(r10 - 0x920)
040a20 (+3d38): r3 = *(u64 *)(r10 - 0x928)
040a28 (+3d40): call -0x61c0 ; call 0xfc30 / window 275
040a30 (+3d48): r1 = *(u32 *)(r10 - 0x130)
040a38 (+3d50): if r1 == 0x16 goto +0x1 <.text+0x40928> ; branch 0x40a48 / relative 0x3d60
040a40 (+3d58): goto -0x92 <.text+0x40498> ; branch 0x405b8 / relative 0x38d0
040a48 (+3d60): r2 = *(u64 *)(r10 - 0x938)
040a50 (+3d68): r2 += 0x30
040a58 (+3d70): r3 = *(u64 *)(r8 + 0x0)
040a60 (+3d78): r1 = r10
040a68 (+3d80): r1 += -0x130
040a70 (+3d88): r7 = r2
040a78 (+3d90): call -0x61ca ; call 0xfc30 / window 275
040a80 (+3d98): r1 = *(u32 *)(r10 - 0x130)
040a88 (+3da0): if r1 == 0x16 goto +0x1 <.text+0x40978> ; branch 0x40a98 / relative 0x3db0
040a90 (+3da8): goto -0x9c <.text+0x40498> ; branch 0x405b8 / relative 0x38d0
040a98 (+3db0): r1 = r10
040aa0 (+3db8): r1 += -0x544
040aa8 (+3dc0): r2 = *(u64 *)(r10 - 0x950)
040ab0 (+3dc8): call -0x7bb5 ; call 0x2d10 / window 44
040ab8 (+3dd0): if r0 != 0x0 goto +0xe <.text+0x40a10> ; branch 0x40b30 / relative 0x3e48
040ac0 (+3dd8): r1 = *(u8 *)(r10 - 0x408)
040ac8 (+3de0): if r1 == 0x0 goto +0x15 <.text+0x40a58> ; branch 0x40b78 / relative 0x3e90
040ad0 (+3de8): r1 = 0x1800000000 ll
040ae0 (+3df8): goto +0xb <.text+0x40a20> ; branch 0x40b40 / relative 0x3e58
040ae8 (+3e00): r2 = *(u64 *)(r8 + 0x0)
040af0 (+3e08): r1 = r10
040af8 (+3e10): r1 += -0x348
040b00 (+3e18): call -0x7bbf ; call 0x2d10 / window 44
040b08 (+3e20): if r0 != 0x0 goto +0x1 <.text+0x409f8> ; branch 0x40b18 / relative 0x3e30
040b10 (+3e28): goto +0x8 <.text+0x40a38> ; branch 0x40b58 / relative 0x3e70
040b18 (+3e30): r1 = 0x1c00000000 ll
040b28 (+3e40): goto -0x422 <.text+0x3e900> ; branch 0x3ea20 / relative 0x1d38
040b30 (+3e48): r1 = 0xf00000000 ll
040b40 (+3e58): r2 = *(u64 *)(r10 - 0x930)
040b48 (+3e60): *(u64 *)(r2 + 0x0) = r1
040b50 (+3e68): goto -0x94 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
040b58 (+3e70): if r6 == 0x0 goto +0xe <.text+0x40ab0> ; branch 0x40bd0 / relative 0x3ee8
040b60 (+3e78): r1 = 0x4500000000 ll
040b70 (+3e88): goto -0x42b <.text+0x3e900> ; branch 0x3ea20 / relative 0x1d38
040b78 (+3e90): r1 = *(u64 *)(r10 - 0x938)
040b80 (+3e98): r1 += 0x150
040b88 (+3ea0): *(u64 *)(r10 - 0x958) = r1
040b90 (+3ea8): r2 = 0x9ed68 ll ; pointer 0x9ed68; data32hex 00000000e899090000000000c89a09000000000018a409002200000000000000
040ba0 (+3eb8): call -0x7bda ; call 0x2cd8 / window 42
040ba8 (+3ec0): if r0 != 0x0 goto +0x1 <.text+0x40a98> ; branch 0x40bb8 / relative 0x3ed0
040bb0 (+3ec8): goto +0x7 <.text+0x40ad0> ; branch 0x40bf0 / relative 0x3f08
040bb8 (+3ed0): r1 = 0x7e00000000 ll
040bc8 (+3ee0): goto -0x12 <.text+0x40a20> ; branch 0x40b40 / relative 0x3e58
040bd0 (+3ee8): if r9 == 0x0 goto +0x64 <.text+0x40dd8> ; branch 0x40ef8 / relative 0x4210
040bd8 (+3ef0): r1 = 0x4600000000 ll
040be8 (+3f00): goto -0x43a <.text+0x3e900> ; branch 0x3ea20 / relative 0x1d38
040bf0 (+3f08): r3 = *(u64 *)(r10 - 0x938)
040bf8 (+3f10): r3 += 0x60
040c00 (+3f18): r1 = r10
040c08 (+3f20): r1 += -0x130
040c10 (+3f28): r2 = r10
040c18 (+3f30): r2 += -0x568
040c20 (+3f38): call -0x63da ; call 0xed58 / window 263
040c28 (+3f40): r1 = *(u32 *)(r10 - 0x130)
040c30 (+3f48): if r1 == 0x16 goto +0x1 <.text+0x40b20> ; branch 0x40c40 / relative 0x3f58
040c38 (+3f50): goto -0xd1 <.text+0x40498> ; branch 0x405b8 / relative 0x38d0
040c40 (+3f58): r1 = *(u64 *)(r10 - 0x410)
040c48 (+3f60): if r1 == 0x1 goto +0x1 <.text+0x40b38> ; branch 0x40c58 / relative 0x3f70
040c50 (+3f68): goto +0x76 <.text+0x40ee8> ; branch 0x41008 / relative 0x4320
040c58 (+3f70): r1 = *(u64 *)(r10 - 0x938)
040c60 (+3f78): r1 += 0xc0
040c68 (+3f80): *(u64 *)(r10 - 0x960) = r1
040c70 (+3f88): r1 = r10
040c78 (+3f90): r1 += -0x908
040c80 (+3f98): r2 = *(u64 *)(r10 - 0x928)
040c88 (+3fa0): call 0x8ab7 ; call 0x86248 / window 990
040c90 (+3fa8): r1 = *(u64 *)(r10 - 0x908)
040c98 (+3fb0): *(u64 *)(r10 - 0x968) = r1
040ca0 (+3fb8): r1 = *(u64 *)(r10 - 0x900)
040ca8 (+3fc0): *(u64 *)(r10 - 0x970) = r1
040cb0 (+3fc8): r1 = r10
040cb8 (+3fd0): r1 += -0x918
040cc0 (+3fd8): r2 = *(u64 *)(r10 - 0x950)
040cc8 (+3fe0): call 0x8aaf ; call 0x86248 / window 990
040cd0 (+3fe8): r1 = 0x1
040cd8 (+3ff0): *(u64 *)(r10 - 0x398) = r1
040ce0 (+3ff8): r1 = r10
040ce8 (+4000): r1 += -0x389
040cf0 (+4008): *(u64 *)(r10 - 0x3a0) = r1
040cf8 (+4010): r1 = 0x7
040d00 (+4018): *(u64 *)(r10 - 0x3a8) = r1
040d08 (+4020): r1 = 0x9a255 ll ; pointer 0x9a255; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
040d18 (+4030): *(u64 *)(r10 - 0x3b0) = r1
040d20 (+4038): r1 = *(u64 *)(r10 - 0x970)
040d28 (+4040): *(u64 *)(r10 - 0x3c8) = r1
040d30 (+4048): r1 = *(u64 *)(r10 - 0x968)
040d38 (+4050): *(u64 *)(r10 - 0x3d0) = r1
040d40 (+4058): r1 = 0x8
040d48 (+4060): *(u64 *)(r10 - 0x3d8) = r1
040d50 (+4068): r1 = 0x9a210 ll ; pointer 0x9a210; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
040d60 (+4078): *(u64 *)(r10 - 0x3e0) = r1
040d68 (+4080): r1 = *(u64 *)(r10 - 0x910)
040d70 (+4088): *(u64 *)(r10 - 0x3b8) = r1
040d78 (+4090): r1 = *(u64 *)(r10 - 0x918)
040d80 (+4098): *(u64 *)(r10 - 0x3c0) = r1
040d88 (+40a0): *(u8 *)(r10 - 0x389) = r6
040d90 (+40a8): r2 = *(u64 *)(r10 - 0x928)
040d98 (+40b0): r1 = *(u64 *)(r2 + 0x18)
040da0 (+40b8): *(u64 *)(r10 - 0x118) = r1
040da8 (+40c0): r1 = *(u64 *)(r2 + 0x10)
040db0 (+40c8): *(u64 *)(r10 - 0x120) = r1
040db8 (+40d0): r1 = *(u64 *)(r2 + 0x8)
040dc0 (+40d8): *(u64 *)(r10 - 0x128) = r1
040dc8 (+40e0): r1 = *(u64 *)(r2 + 0x0)
040dd0 (+40e8): *(u64 *)(r10 - 0x130) = r1
040dd8 (+40f0): r1 = r10
040de0 (+40f8): r1 += -0x3e0
040de8 (+4100): *(u64 *)(r10 - 0xff0) = r1
040df0 (+4108): r1 = 0x5
040df8 (+4110): *(u64 *)(r10 - 0xfe8) = r1
040e00 (+4118): r1 = 0x14
040e08 (+4120): *(u64 *)(r10 - 0xff8) = r1
040e10 (+4128): r1 = *(u64 *)(r10 - 0x960)
040e18 (+4130): *(u64 *)(r10 - 0x1000) = r1
040e20 (+4138): r1 = r10
040e28 (+4140): r1 += -0x368
040e30 (+4148): r2 = r10
040e38 (+4150): r2 += -0x130
040e40 (+4158): r5 = r10
040e48 (+4160): r3 = *(u64 *)(r10 - 0x938)
040e50 (+4168): r4 = *(u64 *)(r10 - 0x958)
040e58 (+4170): call 0x68b0 ; call 0x753e0 / window 770
040e60 (+4178): r1 = *(u32 *)(r10 - 0x368)
040e68 (+4180): if r1 == 0x16 goto +0x1 <.text+0x40d58> ; branch 0x40e78 / relative 0x4190
040e70 (+4188): goto +0x65 <.text+0x41080> ; branch 0x411a0 / relative 0x44b8
040e78 (+4190): r1 = r10
040e80 (+4198): r1 += -0x130
040e88 (+41a0): r2 = *(u64 *)(r10 - 0x938)
040e90 (+41a8): call 0xb87 ; call 0x46ad0 / window 411
040e98 (+41b0): r1 = *(u64 *)(r10 - 0x130)
040ea0 (+41b8): if r1 == 0x0 goto +0x68 <.text+0x410c8> ; branch 0x411e8 / relative 0x4500
040ea8 (+41c0): r1 = *(u64 *)(r10 - 0x128)
040eb0 (+41c8): r2 = *(u64 *)(r10 - 0x110)
040eb8 (+41d0): r3 = *(u64 *)(r10 - 0x930)
040ec0 (+41d8): *(u64 *)(r3 + 0x18) = r2
040ec8 (+41e0): r2 = *(u64 *)(r10 - 0x118)
040ed0 (+41e8): *(u64 *)(r3 + 0x10) = r2
040ed8 (+41f0): r2 = *(u64 *)(r10 - 0x120)
040ee0 (+41f8): *(u64 *)(r3 + 0x8) = r2
040ee8 (+4200): *(u64 *)(r3 + 0x0) = r1
040ef0 (+4208): goto -0x108 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
040ef8 (+4210): r6 = *(u64 *)(r10 - 0x938)
040f00 (+4218): r1 = r6
040f08 (+4220): call 0x884c ; call 0x85170 / window 980
040f10 (+4228): r7 = r0
040f18 (+4230): r1 = r10
040f20 (+4238): r1 += -0x130
040f28 (+4240): r2 = r6
040f30 (+4248): call 0x88af ; call 0x854b0 / window 986
040f38 (+4250): r1 = *(u32 *)(r10 - 0x130)
040f40 (+4258): if r1 == 0x16 goto +0x1 <.text+0x40e30> ; branch 0x40f50 / relative 0x4268
040f48 (+4260): goto +0x3f <.text+0x41028> ; branch 0x41148 / relative 0x4460
040f50 (+4268): r6 = *(u64 *)(r10 - 0x120)
040f58 (+4270): r1 = *(u64 *)(r10 - 0x128)
040f60 (+4278): r2 = *(u64 *)(r1 + 0x8)
040f68 (+4280): r1 = *(u64 *)(r1 + 0x0)
040f70 (+4288): r3 = *(u64 *)(r10 - 0x350)
040f78 (+4290): *(u64 *)(r10 - 0x118) = r3
040f80 (+4298): r3 = *(u64 *)(r10 - 0x358)
040f88 (+42a0): *(u64 *)(r10 - 0x120) = r3
040f90 (+42a8): r3 = *(u64 *)(r10 - 0x360)
040f98 (+42b0): *(u64 *)(r10 - 0x128) = r3
040fa0 (+42b8): r3 = 0x6
040fa8 (+42c0): *(u32 *)(r10 - 0x130) = r3
040fb0 (+42c8): r3 = r10
040fb8 (+42d0): r3 += -0x130
040fc0 (+42d8): call -0x7449 ; call 0x6d80 / window 166
040fc8 (+42e0): if r0 == 0x0 goto +0xa <.text+0x40f00> ; branch 0x41020 / relative 0x4338
040fd0 (+42e8): r1 = *(u64 *)(r10 - 0x930)
040fd8 (+42f0): r2 = r0
040fe0 (+42f8): call 0x8c07 ; call 0x87020 / window 1002
040fe8 (+4300): r1 = *(u64 *)(r6 + 0x0)
040ff0 (+4308): r1 += 0x1
040ff8 (+4310): *(u64 *)(r6 + 0x0) = r1
041000 (+4318): goto -0x127 <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
041008 (+4320): r1 = 0x1000000000 ll
041018 (+4330): goto -0x9c <.text+0x40a20> ; branch 0x40b40 / relative 0x3e58
041020 (+4338): r1 = *(u64 *)(r6 + 0x0)
041028 (+4340): r1 += 0x1
041030 (+4348): *(u64 *)(r6 + 0x0) = r1
041038 (+4350): r1 = r10
041040 (+4358): r1 += -0x130
041048 (+4360): r2 = *(u64 *)(r10 - 0x938)
041050 (+4368): call 0x888b ; call 0x854b0 / window 986
041058 (+4370): r1 = *(u32 *)(r10 - 0x130)
041060 (+4378): if r1 == 0x16 goto +0x1 <.text+0x40f50> ; branch 0x41070 / relative 0x4388
041068 (+4380): goto +0x1b <.text+0x41028> ; branch 0x41148 / relative 0x4460
041070 (+4388): r1 = 0x2
041078 (+4390): if r1 > r7 goto +0xc4 <.text+0x41580> ; branch 0x416a0 / relative 0x49b8
041080 (+4398): r4 = *(u64 *)(r10 - 0x128)
041088 (+43a0): r1 = r7
041090 (+43a8): r1 += -0x2
041098 (+43b0): r2 = *(u64 *)(r4 + 0x8)
0410a0 (+43b8): if r2 > r1 goto +0x1 <.text+0x40f90> ; branch 0x410b0 / relative 0x43c8
0410a8 (+43c0): goto +0xc5 <.text+0x415b8> ; branch 0x416d8 / relative 0x49f0
0410b0 (+43c8): r3 = *(u64 *)(r10 - 0x120)
0410b8 (+43d0): r2 = *(u64 *)(r4 + 0x0)
0410c0 (+43d8): r2 += r1
0410c8 (+43e0): r1 = 0x0
0410d0 (+43e8): *(u8 *)(r2 + 0x0) = r1
0410d8 (+43f0): r7 += -0x1
0410e0 (+43f8): r2 = *(u64 *)(r4 + 0x8)
0410e8 (+4400): if r2 > r7 goto +0x1 <.text+0x40fd8> ; branch 0x410f8 / relative 0x4410
0410f0 (+4408): goto +0xbf <.text+0x415d0> ; branch 0x416f0 / relative 0x4a08
0410f8 (+4410): r2 = *(u64 *)(r4 + 0x0)
041100 (+4418): r2 += r7
041108 (+4420): *(u8 *)(r2 + 0x0) = r1
041110 (+4428): r1 = 0x16
041118 (+4430): r2 = *(u64 *)(r10 - 0x930)
041120 (+4438): *(u32 *)(r2 + 0x0) = r1
041128 (+4440): r1 = *(u64 *)(r3 + 0x0)
041130 (+4448): r1 += 0x1
041138 (+4450): *(u64 *)(r3 + 0x0) = r1
041140 (+4458): goto -0x14f <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
041148 (+4460): r2 = *(u32 *)(r10 - 0x12c)
041150 (+4468): r3 = *(u64 *)(r10 - 0x128)
041158 (+4470): r4 = *(u64 *)(r10 - 0x120)
041160 (+4478): r5 = *(u64 *)(r10 - 0x118)
041168 (+4480): r0 = *(u64 *)(r10 - 0x930)
041170 (+4488): *(u64 *)(r0 + 0x18) = r5
041178 (+4490): *(u64 *)(r0 + 0x10) = r4
041180 (+4498): *(u64 *)(r0 + 0x8) = r3
041188 (+44a0): *(u32 *)(r0 + 0x4) = r2
041190 (+44a8): *(u32 *)(r0 + 0x0) = r1
041198 (+44b0): goto -0x15a <.text+0x405b0> ; branch 0x406d0 / relative 0x39e8
0411a0 (+44b8): r2 = *(u32 *)(r10 - 0x34c)
0411a8 (+44c0): r3 = *(u64 *)(r10 - 0x930)
0411b0 (+44c8): *(u32 *)(r3 + 0x1c) = r2
0411b8 (+44d0): r2 = *(u64 *)(r10 - 0x354)
0411c0 (+44d8): *(u64 *)(r3 + 0x14) = r2
0411c8 (+44e0): r2 = *(u64 *)(r10 - 0x35c)
0411d0 (+44e8): *(u64 *)(r3 + 0xc) = r2
0411d8 (+44f0): r2 = *(u64 *)(r10 - 0x364)
0411e0 (+44f8): goto -0x17e <.text+0x404d8> ; branch 0x405f8 / relative 0x3910
0411e8 (+4500): r1 = *(u64 *)(r10 - 0x128)
0411f0 (+4508): *(u64 *)(r10 - 0x388) = r1
0411f8 (+4510): r1 = *(u64 *)(r10 - 0x948)
041200 (+4518): *(u64 *)(r10 - 0x370) = r1
041208 (+4520): r1 = *(u64 *)(r10 - 0x940)
041210 (+4528): *(u64 *)(r10 - 0x378) = r1
041218 (+4530): r1 = 0x0
041220 (+4538): *(u64 *)(r10 - 0x380) = r1
041228 (+4540): r1 = 0x6
041230 (+4548): *(u32 *)(r10 - 0x388) = r1
041238 (+4550): r1 = r10
041240 (+4558): r1 += -0x130
041248 (+4560): r2 = *(u64 *)(r10 - 0x938)
041250 (+4568): call 0x884b ; call 0x854b0 / window 986
041258 (+4570): r1 = *(u32 *)(r10 - 0x130)
041260 (+4578): if r1 == 0x16 goto +0x1 <.text+0x41150> ; branch 0x41270 / relative 0x4588
041268 (+4580): goto +0xf <.text+0x411c8> ; branch 0x412e8 / relative 0x4600
041270 (+4588): r6 = *(u64 *)(r10 - 0x120)
041278 (+4590): r1 = *(u64 *)(r10 - 0x128)
041280 (+4598): r2 = *(u64 *)(r1 + 0x8)
041288 (+45a0): r1 = *(u64 *)(r1 + 0x0)
041290 (+45a8): r3 = r10
041298 (+45b0): r3 += -0x388
0412a0 (+45b8): call -0x74a5 ; call 0x6d80 / window 166
0412a8 (+45c0): if r0 == 0x0 goto +0x12 <.text+0x41220> ; branch 0x41340 / relative 0x4658
0412b0 (+45c8): r1 = *(u64 *)(r10 - 0x930)
0412b8 (+45d0): r2 = r0
0412c0 (+45d8): call 0x8bab ; call 0x87020 / window 1002
0412c8 (+45e0): r1 = *(u64 *)(r6 + 0x0)
0412d0 (+45e8): r1 += 0x1
0412d8 (+45f0): *(u64 *)(r6 + 0x0) = r1
0412e0 (+45f8): goto -0x186 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
0412e8 (+4600): r2 = *(u32 *)(r10 - 0x12c)
0412f0 (+4608): r3 = *(u64 *)(r10 - 0x128)
0412f8 (+4610): r4 = *(u64 *)(r10 - 0x120)
041300 (+4618): r5 = *(u64 *)(r10 - 0x118)
041308 (+4620): r0 = *(u64 *)(r10 - 0x930)
041310 (+4628): *(u64 *)(r0 + 0x18) = r5
041318 (+4630): *(u64 *)(r0 + 0x10) = r4
041320 (+4638): *(u64 *)(r0 + 0x8) = r3
041328 (+4640): *(u32 *)(r0 + 0x4) = r2
041330 (+4648): *(u32 *)(r0 + 0x0) = r1
041338 (+4650): goto -0x191 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
041340 (+4658): r1 = *(u64 *)(r6 + 0x0)
041348 (+4660): r1 += 0x1
041350 (+4668): *(u64 *)(r6 + 0x0) = r1
041358 (+4670): r1 = *(u64 *)(r10 - 0x938)
041360 (+4678): r1 = *(u8 *)(r1 + 0x119)
041368 (+4680): if r1 == 0x0 goto +0x14 <.text+0x412f0> ; branch 0x41410 / relative 0x4728
041370 (+4688): r1 = r10
041378 (+4690): r1 += -0x130
041380 (+4698): r2 = *(u64 *)(r10 - 0x920)
041388 (+46a0): call 0xd86 ; call 0x47fc0 / window 419
041390 (+46a8): r6 = *(u32 *)(r10 - 0x28)
041398 (+46b0): if r6 != 0x2 goto +0x11 <.text+0x41308> ; branch 0x41428 / relative 0x4740
0413a0 (+46b8): r1 = *(u64 *)(r10 - 0x118)
0413a8 (+46c0): *(u64 *)(r10 - 0x220) = r1
0413b0 (+46c8): r2 = *(u64 *)(r10 - 0x120)
0413b8 (+46d0): *(u64 *)(r10 - 0x228) = r2
0413c0 (+46d8): r3 = *(u64 *)(r10 - 0x128)
0413c8 (+46e0): *(u64 *)(r10 - 0x230) = r3
0413d0 (+46e8): r4 = *(u64 *)(r10 - 0x130)
0413d8 (+46f0): *(u64 *)(r10 - 0x238) = r4
0413e0 (+46f8): r5 = *(u64 *)(r10 - 0x930)
0413e8 (+4700): *(u64 *)(r5 + 0x18) = r1
0413f0 (+4708): *(u64 *)(r5 + 0x10) = r2
0413f8 (+4710): *(u64 *)(r5 + 0x8) = r3
041400 (+4718): *(u64 *)(r5 + 0x0) = r4
041408 (+4720): goto -0x1ab <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
041410 (+4728): r1 = 0xcb00000000 ll
041420 (+4738): goto -0x11d <.text+0x40a20> ; branch 0x40b40 / relative 0x3e58
041428 (+4740): r1 = r10
041430 (+4748): r1 += -0x238
041438 (+4750): *(u64 *)(r10 - 0x928) = r1
041440 (+4758): r2 = r10
041448 (+4760): r2 += -0x130
041450 (+4768): r3 = 0x108
041458 (+4770): call 0xaf67 ; call 0x98f98 / window 1246
041460 (+4778): r1 = r10
041468 (+4780): r1 += -0x25c
041470 (+4788): r2 = r10
041478 (+4790): r2 += -0x24
041480 (+4798): r3 = 0x24
041488 (+47a0): call 0xaf61 ; call 0x98f98 / window 1246
041490 (+47a8): r1 = r10
041498 (+47b0): r1 += -0x368
0414a0 (+47b8): r2 = *(u64 *)(r10 - 0x928)
0414a8 (+47c0): r3 = 0x108
0414b0 (+47c8): call 0xaf5c ; call 0x98f98 / window 1246
0414b8 (+47d0): *(u32 *)(r10 - 0x260) = r6
0414c0 (+47d8): r1 = 0x0
0414c8 (+47e0): *(u32 *)(r10 - 0x2b4) = r1
0414d0 (+47e8): r1 = r10
0414d8 (+47f0): r1 += -0x130
0414e0 (+47f8): r2 = *(u64 *)(r10 - 0x920)
0414e8 (+4800): call 0x87f8 ; call 0x854b0 / window 986
0414f0 (+4808): r1 = *(u32 *)(r10 - 0x130)
0414f8 (+4810): if r1 == 0x16 goto +0x1 <.text+0x413e8> ; branch 0x41508 / relative 0x4820
041500 (+4818): goto +0xf <.text+0x41460> ; branch 0x41580 / relative 0x4898
041508 (+4820): r6 = *(u64 *)(r10 - 0x120)
041510 (+4828): r1 = *(u64 *)(r10 - 0x128)
041518 (+4830): r2 = *(u64 *)(r1 + 0x8)
041520 (+4838): r1 = *(u64 *)(r1 + 0x0)
041528 (+4840): r3 = r10
041530 (+4848): r3 += -0x368
041538 (+4850): call -0x7514 ; call 0x6ca0 / window 162
041540 (+4858): if r0 == 0x0 goto +0x15 <.text+0x414d0> ; branch 0x415f0 / relative 0x4908
041548 (+4860): r1 = *(u64 *)(r10 - 0x930)
041550 (+4868): r2 = r0
041558 (+4870): call 0x8b58 ; call 0x87020 / window 1002
041560 (+4878): r1 = *(u64 *)(r6 + 0x0)
041568 (+4880): r1 += 0x1
041570 (+4888): *(u64 *)(r6 + 0x0) = r1
041578 (+4890): goto +0xa <.text+0x414b0> ; branch 0x415d0 / relative 0x48e8
041580 (+4898): r2 = *(u32 *)(r10 - 0x12c)
041588 (+48a0): r3 = *(u64 *)(r10 - 0x128)
041590 (+48a8): r4 = *(u64 *)(r10 - 0x120)
041598 (+48b0): r5 = *(u64 *)(r10 - 0x118)
0415a0 (+48b8): r0 = *(u64 *)(r10 - 0x930)
0415a8 (+48c0): *(u64 *)(r0 + 0x18) = r5
0415b0 (+48c8): *(u64 *)(r0 + 0x10) = r4
0415b8 (+48d0): *(u64 *)(r0 + 0x8) = r3
0415c0 (+48d8): *(u32 *)(r0 + 0x4) = r2
0415c8 (+48e0): *(u32 *)(r0 + 0x0) = r1
0415d0 (+48e8): r1 = r10
0415d8 (+48f0): r1 += -0x320
0415e0 (+48f8): call -0x7ca9 ; call 0x30a0 / window 59
0415e8 (+4900): goto -0x1e7 <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
0415f0 (+4908): r1 = *(u64 *)(r6 + 0x0)
0415f8 (+4910): r1 += 0x1
041600 (+4918): *(u64 *)(r6 + 0x0) = r1
041608 (+4920): r1 = r10
041610 (+4928): r1 += -0x320
041618 (+4930): call -0x7cb0 ; call 0x30a0 / window 59
041620 (+4938): r3 = *(u64 *)(r10 - 0x938)
041628 (+4940): r2 = *(u64 *)(r3 + 0x0)
041630 (+4948): *(u64 *)(r10 - 0x1000) = r9
041638 (+4950): *(u64 *)(r10 - 0xff8) = r8
041640 (+4958): r1 = r10
041648 (+4960): r1 += -0x130
041650 (+4968): r5 = r10
041658 (+4970): r4 = r7
041660 (+4978): call 0x2ac8 ; call 0x56ca8 / window 458
041668 (+4980): r1 = *(u32 *)(r10 - 0x130)
041670 (+4988): if r1 == 0x16 goto +0x1 <.text+0x41560> ; branch 0x41680 / relative 0x4998
041678 (+4990): goto -0x219 <.text+0x40498> ; branch 0x405b8 / relative 0x38d0
041680 (+4998): r1 = 0x16
041688 (+49a0): r2 = *(u64 *)(r10 - 0x930)
041690 (+49a8): *(u32 *)(r2 + 0x0) = r1
041698 (+49b0): goto -0x1fd <.text+0x40598> ; branch 0x406b8 / relative 0x39d0
0416a0 (+49b8): r1 = 0x9a280 ll ; pointer 0x9a280; data32hex 617474656d707420746f2073756274726163742077697468206f766572666c6f
0416b0 (+49c8): r2 = 0x21
0416b8 (+49d0): r3 = 0x9efa8 ll ; pointer 0x9efa8; data32hex 0000000070a6090040000000000000003c0000001e0000000000000070a60900
0416c8 (+49e0): call 0x9dc9 ; call 0x90518 / window 1169
0416d0 (+49e8): call -0x1 ; external abort
0416d8 (+49f0): r3 = 0x9efc0 ll ; pointer 0x9efc0; data32hex 0000000070a6090040000000000000003c000000050000000000000070a60900
0416e8 (+4a00): goto -0x62c <.text+0x3e470> ; branch 0x3e590 / relative 0x18a8
0416f0 (+4a08): r1 = r7
0416f8 (+4a10): r3 = 0x9efd8 ll ; pointer 0x9efd8; data32hex 0000000070a6090040000000000000003d0000000500000000000000b0a60900
041708 (+4a20): goto -0x630 <.text+0x3e470> ; branch 0x3e590 / relative 0x18a8
041710 (+4a28): r6 = r10
041718 (+4a30): r6 += -0x238
041720 (+4a38): r2 = r10
041728 (+4a40): r2 += -0x6b4
041730 (+4a48): r1 = r6
041738 (+4a50): r3 = 0x24
041740 (+4a58): call 0xaf0a ; call 0x98f98 / window 1246
041748 (+4a60): r7 = r10
041750 (+4a68): r7 += -0x368
041758 (+4a70): r2 = r10
041760 (+4a78): r2 += -0x690
041768 (+4a80): r1 = r7
041770 (+4a88): r3 = 0x30
041778 (+4a90): call 0xaf03 ; call 0x98f98 / window 1246
041780 (+4a98): r9 = r10
041788 (+4aa0): r9 += -0x6c8
041790 (+4aa8): r1 = r9
041798 (+4ab0): r2 = r6
0417a0 (+4ab8): r3 = 0x24
0417a8 (+4ac0): call 0xaefd ; call 0x98f98 / window 1246
0417b0 (+4ac8): r1 = r10
0417b8 (+4ad0): r1 += -0x6a4
0417c0 (+4ad8): r2 = r7
0417c8 (+4ae0): r3 = 0x30
0417d0 (+4ae8): call 0xaef8 ; call 0x98f98 / window 1246
0417d8 (+4af0): r6 = r10
0417e0 (+4af8): r6 += -0x568
0417e8 (+4b00): r1 = r6
0417f0 (+4b08): r2 = r9
0417f8 (+4b10): r3 = 0x54
041800 (+4b18): call 0xaef2 ; call 0x98f98 / window 1246
041808 (+4b20): r2 = *(u64 *)(r10 - 0x958)
041810 (+4b28): r1 = *(u64 *)(r2 + 0x0)
041818 (+4b30): r1 += -0x1
041820 (+4b38): *(u64 *)(r2 + 0x0) = r1
041828 (+4b40): r1 = *(u64 *)(r10 - 0x950)
041830 (+4b48): *(u32 *)(r10 - 0x6c8) = r1
041838 (+4b50): r1 = r10
041840 (+4b58): r1 += -0x6c4
041848 (+4b60): r2 = r6
041850 (+4b68): r3 = 0x54
041858 (+4b70): call 0xaee7 ; call 0x98f98 / window 1246
041860 (+4b78): r1 = r10
041868 (+4b80): r1 += -0x368
041870 (+4b88): r2 = r10
041878 (+4b90): r2 += -0x6c8
041880 (+4b98): r3 = 0x9eeb8 ll ; pointer 0x9eeb8; data32hex 00000000e6a409002200000000000000410000002400000000000000e6a40900
041890 (+4ba8): call -0x7ac5 ; call 0x4270 / window 95
041898 (+4bb0): r1 = *(u64 *)(r10 - 0x340)
0418a0 (+4bb8): if r1 == 0x0 goto +0x14 <.text+0x41828> ; branch 0x41948 / relative 0x4c60
0418a8 (+4bc0): r1 = *(u64 *)(r10 - 0x950)
0418b0 (+4bc8): *(u32 *)(r10 - 0x6c8) = r1
0418b8 (+4bd0): r1 = r10
0418c0 (+4bd8): r1 += -0x6c4
0418c8 (+4be0): r2 = r10
0418d0 (+4be8): r2 += -0x568
0418d8 (+4bf0): r3 = 0x54
0418e0 (+4bf8): call 0xaed6 ; call 0x98f98 / window 1246
0418e8 (+4c00): r1 = r10
0418f0 (+4c08): r1 += -0x368
0418f8 (+4c10): r2 = r10
041900 (+4c18): r2 += -0x6c8
041908 (+4c20): r3 = 0x9eef0 ll ; pointer 0x9eef0; data32hex 00000000e6a409002200000000000000520000002600000000000000e6a40900
041918 (+4c30): call -0x7ad6 ; call 0x4270 / window 95
041920 (+4c38): r1 = *(u64 *)(r10 - 0x340)
041928 (+4c40): if r1 == 0x0 goto +0x2c <.text+0x41970> ; branch 0x41a90 / relative 0x4da8
041930 (+4c48): r1 = 0xa000000000 ll
041940 (+4c58): goto -0x3e1 <.text+0x3f920> ; branch 0x3fa40 / relative 0x2d58
041948 (+4c60): r1 = *(u64 *)(r10 - 0x950)
041950 (+4c68): *(u32 *)(r10 - 0x6c8) = r1
041958 (+4c70): r1 = r10
041960 (+4c78): r1 += -0x6c4
041968 (+4c80): r2 = r10
041970 (+4c88): r2 += -0x568
041978 (+4c90): r3 = 0x54
041980 (+4c98): call 0xaec2 ; call 0x98f98 / window 1246
041988 (+4ca0): r1 = r10
041990 (+4ca8): r1 += -0x368
041998 (+4cb0): r2 = r10
0419a0 (+4cb8): r2 += -0x6c8
0419a8 (+4cc0): r3 = 0x9eed0 ll ; pointer 0x9eed0; data32hex 00000000e6a409002200000000000000430000001700000000000000c8990900
0419b8 (+4cd0): call -0x7aea ; call 0x4270 / window 95
0419c0 (+4cd8): r1 = *(u32 *)(r10 - 0x368)
0419c8 (+4ce0): if r1 == 0x0 goto -0x34b <.text+0x3fe58> ; branch 0x3ff78 / relative 0x3290
0419d0 (+4ce8): r1 = *(u64 *)(r10 - 0x34c)
0419d8 (+4cf0): *(u64 *)(r10 - 0x220) = r1
0419e0 (+4cf8): r1 = *(u64 *)(r10 - 0x354)
0419e8 (+4d00): *(u64 *)(r10 - 0x228) = r1
0419f0 (+4d08): r1 = *(u64 *)(r10 - 0x35c)
0419f8 (+4d10): *(u64 *)(r10 - 0x230) = r1
041a00 (+4d18): r1 = *(u64 *)(r10 - 0x364)
041a08 (+4d20): *(u64 *)(r10 - 0x238) = r1
041a10 (+4d28): r1 = *(u64 *)(r10 - 0x920)
041a18 (+4d30): r2 = *(u64 *)(r1 + 0x0)
041a20 (+4d38): r1 = r10
041a28 (+4d40): r1 += -0x238
041a30 (+4d48): call 0x8567 ; call 0x84570 / window 955
041a38 (+4d50): if r0 != 0x0 goto -0x359 <.text+0x3fe58> ; branch 0x3ff78 / relative 0x3290
041a40 (+4d58): r6 = r10
041a48 (+4d60): r6 += -0x6c8
041a50 (+4d68): r1 = r6
041a58 (+4d70): call 0x8310 ; call 0x832e0 / window 915
041a60 (+4d78): r1 = r10
041a68 (+4d80): r1 += -0x238
041a70 (+4d88): r2 = r6
041a78 (+4d90): call 0x855e ; call 0x84570 / window 955
041a80 (+4d98): if r0 != 0x0 goto -0x362 <.text+0x3fe58> ; branch 0x3ff78 / relative 0x3290
041a88 (+4da0): goto -0x3d <.text+0x41788> ; branch 0x418a8 / relative 0x4bc0
041a90 (+4da8): r1 = *(u64 *)(r10 - 0x950)
041a98 (+4db0): *(u32 *)(r10 - 0x6c8) = r1
041aa0 (+4db8): r1 = r10
041aa8 (+4dc0): r1 += -0x6c4
041ab0 (+4dc8): r2 = r10
041ab8 (+4dd0): r2 += -0x568
041ac0 (+4dd8): r3 = 0x54
041ac8 (+4de0): call 0xae99 ; call 0x98f98 / window 1246
041ad0 (+4de8): r1 = r10
041ad8 (+4df0): r1 += -0x368
041ae0 (+4df8): r2 = r10
041ae8 (+4e00): r2 += -0x6c8
041af0 (+4e08): r3 = 0x9ef08 ll ; pointer 0x9ef08; data32hex 00000000e6a40900220000000000000054000000260000000000000008a50900
041b00 (+4e18): call -0x7b13 ; call 0x4270 / window 95
041b08 (+4e20): r1 = *(u32 *)(r10 - 0x368)
041b10 (+4e28): r2 = 0x0
041b18 (+4e30): r3 = *(u64 *)(r10 - 0x930)
041b20 (+4e38): *(u32 *)(r3 + 0x0) = r2
041b28 (+4e40): if r1 != 0x0 goto +0x2 <.text+0x41a20> ; branch 0x41b40 / relative 0x4e58
041b30 (+4e48): r1 = 0xca
041b38 (+4e50): goto +0x1 <.text+0x41a28> ; branch 0x41b48 / relative 0x4e60
041b40 (+4e58): r1 = 0xa
041b48 (+4e60): r2 = *(u64 *)(r10 - 0x930)
041b50 (+4e68): *(u32 *)(r2 + 0x4) = r1
041b58 (+4e70): goto -0x422 <.text+0x3f930> ; branch 0x3fa50 / relative 0x2d68
