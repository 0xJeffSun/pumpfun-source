#!/usr/bin/env python3
"""Read-only ELF/source diagnostic. Writes text and JSON, never executable bytes."""
from pathlib import Path
import collections, datetime, difflib, hashlib, json, re, struct, subprocess, sys
ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'repro/pump_fees/framework-matching'))
from elf_reader import Elf
BUILD = ROOT / 'work/metaplex-recovered-build-40157158772'
ART = BUILD / 'metaplex-rebuild-40157158772'
PATHS = {'original':ROOT/'evidence/dependencies/token_metadata/deployed.so', 'candidate10':ART/'token_metadata.so'}
E = {k:Elf(v) for k,v in PATHS.items()}
sha = lambda b:hashlib.sha256(b).hexdigest()
targets = [344,346,350]
rows = []
for ordinal in targets:
    row = {'ordinal':ordinal}; forms = {}
    for side,e in E.items():
        start,end = e.entries[ordinal:ordinal+2]
        idx = {v:k for k,v in enumerate(e.entries)}
        raw = (BUILD/f'{side}-{ordinal}.asm').read_text()
        (W/f'{side}-{ordinal}.raw.asm').write_text(raw)
        instructions = []
        for line in raw.splitlines():
            m = re.match(r'\s*(\d+):\s*((?:[a-f0-9]{2} )*[a-f0-9]{2})\s+(.+)',line)
            if not m: continue
            at=int(m[1])*8; bs=bytes.fromhex(m[2]); text=m[3]
            assert e.b[at:at+len(bs)]==bs
            assert start<=at<end
            norm=re.sub(r' <[^>]*>','',text); extra=[]
            op=e.b[at]
            if at in e.calls:
                extra.append(f'call {e.calls[at]:#x} / window {idx.get(e.calls[at])}')
                norm='call window '+str(idx.get(e.calls[at]))
            if at in e.relocations and e.relocations[at]['type']==10:
                extra.append('external '+e.relocations[at]['symbol']);norm='call external '+e.relocations[at]['symbol']
            if op&7==5 and op not in [0x85,0x8d,0x95]:
                target=at+8+8*struct.unpack_from('<h',e.b,at+2)[0]
                extra.append(f'branch {target:#x} / relative {target-start:#x}')
                norm=re.sub(r'goto .*','goto <branch>',norm)
            if op==0x18 and at in e.relocations:
                ptr=struct.unpack_from('<I',e.b,at+4)[0]|struct.unpack_from('<I',e.b,at+12)[0]<<32
                extra.append(f'pointer {ptr:#x}; data32hex '+e.b[ptr:ptr+32].hex())
                norm=re.sub(r'0x[0-9a-f]+ ll','<relocated-pointer> ll',norm)
            instructions.append({'at':at,'relative':at-start,'bytes':bs.hex(),'text':text,'alignment':norm,'annotations':extra})
        assert sum(len(bytes.fromhex(x['bytes'])) for x in instructions)==end-start
        (W/f'{side}-{ordinal}.asm').write_text('\n'.join(f"{x['at']:06x} (+{x['relative']:04x}): {x['text']}"+(' ; '+' ; '.join(x['annotations']) if x['annotations'] else '') for x in instructions)+'\n')
        (W/f'{side}-{ordinal}.json').write_text(json.dumps(instructions,indent=2)+'\n')
        calls=[{'at':at,'ordinal':idx.get(target)} for at,target in e.calls.items() if start<=at<end]
        row[side]={'start':start,'end':end,'bytes':end-start,'sha256':sha(e.b[start:end]),'normalized_sha256':sha(e.normalized[start:end]),'calls':calls}
        forms[side]=instructions
    A= forms['original']; B=forms['candidate10'];out=[]
    for group in difflib.SequenceMatcher(None,[x['alignment'] for x in A],[x['alignment'] for x in B],autojunk=False).get_grouped_opcodes(5):
        out.append('@@')
        for op,i,j,k,l in group:
            if op=='equal':out.extend(f" {x['at']:06x}: {x['alignment']}" for x in A[i:j])
            else:
                out.extend(f"-{x['at']:06x}: {x['alignment']}" for x in A[i:j])
                out.extend(f"+{x['at']:06x}: {x['alignment']}" for x in B[k:l])
    (W/f'diff-{ordinal}.txt').write_text('\n'.join(out)+'\n')
    a=[x['ordinal'] for x in row['original']['calls']];b=[x['ordinal'] for x in row['candidate10']['calls']]
    row['call_sequence_equal']=a==b
    row['call_multiset_equal']=collections.Counter(a)==collections.Counter(b)
    rows.append(row)
(W/'windows.json').write_text(json.dumps(rows,indent=2)+'\n')
source_paths=[
 'programs/token-metadata/program/src/processor/uses/approve_use_authority.rs',
 'programs/token-metadata/program/src/processor/uses/utilize.rs',
 'programs/token-metadata/program/src/processor/edition/create_master_edition_v3.rs',
 'programs/token-metadata/program/src/processor/edition/convert_master_edition_v1_to_v2.rs',
 'programs/token-metadata/program/src/processor/mod.rs',
 'programs/token-metadata/program/src/state/uses.rs',
 'programs/token-metadata/program/src/error.rs',
]
sources=[];rev='17e99434af5ead3e989c08f32af33609821d0bc0'
source_manifest=json.loads((ART/'source-manifest.json').read_text())
upstream_manifest=json.loads((ART/'upstream-source-manifest.json').read_text())
for p in source_paths:
    public=subprocess.check_output(['git','-C',str(ROOT/'work/pump-recovery/metaplex-source'),'show',f'{rev}:{p}'])
    trial=ROOT/'work/metaplex-dispatch-source-trial/source'/p
    # Only changed files exist in trial source, otherwise unchanged public source applies.
    current=trial.read_bytes() if trial.exists() else public
    assert sha(public)==upstream_manifest[p]
    assert sha(current)==source_manifest[p]
    for side,data in [('public17e994',public),('candidate10',current)]:
        dest=W/'source'/side/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        sources.append({'side':side,'path':p,'bytes':len(data),'sha256':sha(data)})
refs=[ART/n for n in ['source.patch','source-manifest.json','upstream-source-manifest.json','patch-source-inputs.json','tool-versions.json','comparison.json']]
inputs={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elfs':{k:{**e.identity(),'bytes':len(e.b),'windows':len(e.entries)} for k,e in E.items()},'source_revision':rev,'source_snapshots':sources,'references':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in refs], 'scope':{'builds':0,'runtime_probes':0,'program_source_edits':0,'executable_edits':0,'normalization':'In-memory address/call/branch alignment only; raw inputs unchanged; alignment is not semantic proof.'}}
(W/'elf_reader.snapshot.py').write_bytes((ROOT/'repro/pump_fees/framework-matching/elf_reader.py').read_bytes())
checks=[]
for n in range(min(len(e.entries) for e in E.values())):
    bounds={side:(e.entries[n],e.entries[n+1] if n+1<len(e.entries) else e.hi) for side,e in E.items()}
    blobs={side:e.normalized[a:b] for side,e in E.items() for a,b in [bounds[side]]}
    patterns={side:e.pattern(a,b-a) for side,e in E.items() for a,b in [bounds[side]]}
    calls={side:[(at-a,{x:i for i,x in enumerate(e.entries)}.get(target)) for at,target in e.calls.items() if a<=at<b] for side,e in E.items() for a,b in [bounds[side]]}
    same=blobs['original']==blobs['candidate10'] and patterns['original']==patterns['candidate10'] and calls['original']==calls['candidate10']
    checks.append({'ordinal':n,'normalized_window_and_calls_equal':same})
inputs['matching_windows'] = sum(x['normalized_window_and_calls_equal'] for x in checks)
inputs['unmatched_ordinals'] = [x['ordinal'] for x in checks if not x['normalized_window_and_calls_equal']]
inputs['source_snapshots_verified_against_both_build_manifests']=True
(W/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps({'elfs':inputs['elfs'],'windows':[{k:v for k,v in r.items() if k not in ['original','candidate10']} for r in rows]},indent=2))
