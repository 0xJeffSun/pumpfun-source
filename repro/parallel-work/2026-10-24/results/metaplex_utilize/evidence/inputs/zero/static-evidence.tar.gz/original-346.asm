039c58 (+0000): r9 = r5
039c60 (+0008): r7 = r4
039c68 (+0010): r8 = r2
039c70 (+0018): r6 = r1
039c78 (+0020): r1 = 0x0
039c80 (+0028): *(u64 *)(r10 - 0x568) = r1
039c88 (+0030): *(u64 *)(r10 - 0x570) = r3
039c90 (+0038): r1 = r7
039c98 (+0040): r1 *= 0x30
039ca0 (+0048): r3 += r1
039ca8 (+0050): *(u64 *)(r10 - 0x578) = r3
039cb0 (+0058): r1 = r10
039cb8 (+0060): r1 += -0x1f0
039cc0 (+0068): r2 = r10
039cc8 (+0070): r2 += -0x578
039cd0 (+0078): call -0x716f ; call 0x1160 / window 20
039cd8 (+0080): r1 = *(u32 *)(r10 - 0x1f0)
039ce0 (+0088): if r1 != 0x16 goto +0x64 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039ce8 (+0090): r1 = *(u64 *)(r10 - 0x1e8)
039cf0 (+0098): *(u64 *)(r10 - 0x598) = r1
039cf8 (+00a0): r1 = r10
039d00 (+00a8): r1 += -0x1f0
039d08 (+00b0): r2 = r10
039d10 (+00b8): r2 += -0x578
039d18 (+00c0): call -0x7178 ; call 0x1160 / window 20
039d20 (+00c8): r1 = *(u32 *)(r10 - 0x1f0)
039d28 (+00d0): if r1 == 0x16 goto +0x1 <.text+0x39c18> ; branch 0x39d38 / relative 0xe0
039d30 (+00d8): goto +0x5a <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039d38 (+00e0): r1 = *(u64 *)(r10 - 0x1e8)
039d40 (+00e8): *(u64 *)(r10 - 0x5a0) = r1
039d48 (+00f0): r1 = r10
039d50 (+00f8): r1 += -0x1f0
039d58 (+0100): r2 = r10
039d60 (+0108): r2 += -0x578
039d68 (+0110): call -0x7182 ; call 0x1160 / window 20
039d70 (+0118): r1 = *(u32 *)(r10 - 0x1f0)
039d78 (+0120): if r1 == 0x16 goto +0x1 <.text+0x39c68> ; branch 0x39d88 / relative 0x130
039d80 (+0128): goto +0x50 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039d88 (+0130): r1 = *(u64 *)(r10 - 0x1e8)
039d90 (+0138): *(u64 *)(r10 - 0x5a8) = r1
039d98 (+0140): r1 = r10
039da0 (+0148): r1 += -0x1f0
039da8 (+0150): r2 = r10
039db0 (+0158): r2 += -0x578
039db8 (+0160): call -0x718c ; call 0x1160 / window 20
039dc0 (+0168): r1 = *(u32 *)(r10 - 0x1f0)
039dc8 (+0170): if r1 == 0x16 goto +0x1 <.text+0x39cb8> ; branch 0x39dd8 / relative 0x180
039dd0 (+0178): goto +0x46 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039dd8 (+0180): r1 = *(u64 *)(r10 - 0x1e8)
039de0 (+0188): *(u64 *)(r10 - 0x5b0) = r1
039de8 (+0190): r1 = r10
039df0 (+0198): r1 += -0x1f0
039df8 (+01a0): r2 = r10
039e00 (+01a8): r2 += -0x578
039e08 (+01b0): call -0x7196 ; call 0x1160 / window 20
039e10 (+01b8): r1 = *(u32 *)(r10 - 0x1f0)
039e18 (+01c0): if r1 == 0x16 goto +0x1 <.text+0x39d08> ; branch 0x39e28 / relative 0x1d0
039e20 (+01c8): goto +0x3c <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039e28 (+01d0): r1 = *(u64 *)(r10 - 0x1e8)
039e30 (+01d8): *(u64 *)(r10 - 0x5b8) = r1
039e38 (+01e0): r1 = r10
039e40 (+01e8): r1 += -0x1f0
039e48 (+01f0): r2 = r10
039e50 (+01f8): r2 += -0x578
039e58 (+0200): call -0x71a0 ; call 0x1160 / window 20
039e60 (+0208): r1 = *(u32 *)(r10 - 0x1f0)
039e68 (+0210): if r1 == 0x16 goto +0x1 <.text+0x39d58> ; branch 0x39e78 / relative 0x220
039e70 (+0218): goto +0x32 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039e78 (+0220): r1 = *(u64 *)(r10 - 0x1e8)
039e80 (+0228): *(u64 *)(r10 - 0x5c0) = r1
039e88 (+0230): r1 = r10
039e90 (+0238): r1 += -0x1f0
039e98 (+0240): r2 = r10
039ea0 (+0248): r2 += -0x578
039ea8 (+0250): call -0x71aa ; call 0x1160 / window 20
039eb0 (+0258): r1 = *(u32 *)(r10 - 0x1f0)
039eb8 (+0260): if r1 == 0x16 goto +0x1 <.text+0x39da8> ; branch 0x39ec8 / relative 0x270
039ec0 (+0268): goto +0x28 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039ec8 (+0270): r1 = r10
039ed0 (+0278): r1 += -0x1f0
039ed8 (+0280): r2 = r10
039ee0 (+0288): r2 += -0x578
039ee8 (+0290): call -0x71b2 ; call 0x1160 / window 20
039ef0 (+0298): r1 = *(u32 *)(r10 - 0x1f0)
039ef8 (+02a0): if r1 == 0x16 goto +0x1 <.text+0x39de8> ; branch 0x39f08 / relative 0x2b0
039f00 (+02a8): goto +0x20 <.text+0x39ee8> ; branch 0x3a008 / relative 0x3b0
039f08 (+02b0): r1 = r10
039f10 (+02b8): r1 += -0x578
039f18 (+02c0): call -0x6bf8 ; call 0x3f60 / window 89
039f20 (+02c8): *(u64 *)(r10 - 0x5c8) = r0
039f28 (+02d0): r1 = r10
039f30 (+02d8): r1 += -0x1f0
039f38 (+02e0): r2 = *(u64 *)(r10 - 0x598)
039f40 (+02e8): call 0x1c0f ; call 0x47fc0 / window 419
039f48 (+02f0): r2 = 0x1
039f50 (+02f8): r1 = 0x1
039f58 (+0300): if r7 == 0xb goto +0x1 <.text+0x39e48> ; branch 0x39f68 / relative 0x310
039f60 (+0308): r1 = 0x0
039f68 (+0310): if r7 == 0xa goto +0x1 <.text+0x39e58> ; branch 0x39f78 / relative 0x320
039f70 (+0318): r2 = 0x0
039f78 (+0320): r3 = *(u64 *)(r10 - 0x5c8)
039f80 (+0328): if r3 == 0x0 goto +0x1 <.text+0x39e70> ; branch 0x39f90 / relative 0x338
039f88 (+0330): r2 = r1
039f90 (+0338): r7 = *(u32 *)(r10 - 0xe8)
039f98 (+0340): if r7 != 0x2 goto +0x19 <.text+0x39f48> ; branch 0x3a068 / relative 0x410
039fa0 (+0348): r1 = *(u64 *)(r10 - 0x1d8)
039fa8 (+0350): *(u64 *)(r10 - 0x410) = r1
039fb0 (+0358): r2 = *(u64 *)(r10 - 0x1e0)
039fb8 (+0360): *(u64 *)(r10 - 0x418) = r2
039fc0 (+0368): r3 = *(u64 *)(r10 - 0x1e8)
039fc8 (+0370): *(u64 *)(r10 - 0x420) = r3
039fd0 (+0378): r4 = *(u64 *)(r10 - 0x1f0)
039fd8 (+0380): *(u64 *)(r10 - 0x428) = r4
039fe0 (+0388): *(u64 *)(r6 + 0x18) = r1
039fe8 (+0390): *(u64 *)(r6 + 0x10) = r2
039ff0 (+0398): *(u64 *)(r6 + 0x8) = r3
039ff8 (+03a0): *(u64 *)(r6 + 0x0) = r4
03a000 (+03a8): goto +0xb <.text+0x39f40> ; branch 0x3a060 / relative 0x408
03a008 (+03b0): r2 = *(u64 *)(r10 - 0x1e0)
03a010 (+03b8): *(u64 *)(r10 - 0x428) = r2
03a018 (+03c0): r3 = *(u64 *)(r10 - 0x1d8)
03a020 (+03c8): *(u64 *)(r10 - 0x420) = r3
03a028 (+03d0): r4 = *(u32 *)(r10 - 0x1ec)
03a030 (+03d8): r5 = *(u64 *)(r10 - 0x1e8)
03a038 (+03e0): *(u64 *)(r6 + 0x18) = r3
03a040 (+03e8): *(u64 *)(r6 + 0x10) = r2
03a048 (+03f0): *(u64 *)(r6 + 0x8) = r5
03a050 (+03f8): *(u32 *)(r6 + 0x4) = r4
03a058 (+0400): *(u32 *)(r6 + 0x0) = r1
03a060 (+0408): exit
03a068 (+0410): *(u64 *)(r10 - 0x5d0) = r2
03a070 (+0418): r1 = r10
03a078 (+0420): r1 += -0x428
03a080 (+0428): *(u64 *)(r10 - 0x5c8) = r1
03a088 (+0430): r2 = r10
03a090 (+0438): r2 += -0x1f0
03a098 (+0440): r3 = 0x108
03a0a0 (+0448): call 0xbdde ; call 0x98f98 / window 1246
03a0a8 (+0450): r1 = r10
03a0b0 (+0458): r1 += -0x44c
03a0b8 (+0460): r2 = r10
03a0c0 (+0468): r2 += -0xe4
03a0c8 (+0470): r3 = 0x24
03a0d0 (+0478): call 0xbdd8 ; call 0x98f98 / window 1246
03a0d8 (+0480): r1 = r10
03a0e0 (+0488): r1 += -0x558
03a0e8 (+0490): r2 = *(u64 *)(r10 - 0x5c8)
03a0f0 (+0498): r3 = 0x108
03a0f8 (+04a0): call 0xbdd3 ; call 0x98f98 / window 1246
03a100 (+04a8): *(u32 *)(r10 - 0x450) = r7
03a108 (+04b0): r1 = *(u32 *)(r10 - 0x478)
03a110 (+04b8): if r1 == 0x3 goto +0x6 <.text+0x3a028> ; branch 0x3a148 / relative 0x4f0
03a118 (+04c0): r1 = *(u32 *)(r10 - 0x4a4)
03a120 (+04c8): if r1 == 0x6 goto +0x1 <.text+0x3a010> ; branch 0x3a130 / relative 0x4d8
03a128 (+04d0): goto +0xa <.text+0x3a060> ; branch 0x3a180 / relative 0x528
03a130 (+04d8): r1 = 0x8700000000 ll
03a140 (+04e8): goto +0x2 <.text+0x3a038> ; branch 0x3a158 / relative 0x500
03a148 (+04f0): r1 = 0x5500000000 ll
03a158 (+0500): *(u64 *)(r6 + 0x0) = r1
03a160 (+0508): r1 = r10
03a168 (+0510): r1 += -0x510
03a170 (+0518): call -0x6e1b ; call 0x30a0 / window 59
03a178 (+0520): goto -0x24 <.text+0x39f40> ; branch 0x3a060 / relative 0x408
03a180 (+0528): if r1 > 0x5 goto -0xb <.text+0x3a010> ; branch 0x3a130 / relative 0x4d8
03a188 (+0530): r2 = 0x1
03a190 (+0538): r2 <<= r1
03a198 (+0540): r2 &= 0x39
03a1a0 (+0548): if r2 != 0x0 goto +0x1 <.text+0x3a090> ; branch 0x3a1b0 / relative 0x558
03a1a8 (+0550): goto -0x10 <.text+0x3a010> ; branch 0x3a130 / relative 0x4d8
03a1b0 (+0558): r1 = *(u64 *)(r10 - 0x5c0)
03a1b8 (+0560): r1 = *(u64 *)(r1 + 0x0)
03a1c0 (+0568): r2 = 0x99a48 ll ; pointer 0x99a48; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03a1d0 (+0578): call -0x6e99 ; call 0x2d10 / window 44
03a1d8 (+0580): if r0 != 0x0 goto +0x1 <.text+0x3a0c8> ; branch 0x3a1e8 / relative 0x590
03a1e0 (+0588): goto +0x3 <.text+0x3a0e0> ; branch 0x3a200 / relative 0x5a8
03a1e8 (+0590): r1 = 0x3e00000000 ll
03a1f8 (+05a0): goto -0x15 <.text+0x3a038> ; branch 0x3a158 / relative 0x500
03a200 (+05a8): r1 = r10
03a208 (+05b0): r1 += -0x1f0
03a210 (+05b8): r2 = *(u64 *)(r10 - 0x5b0)
03a218 (+05c0): call 0x7895 ; call 0x766c8 / window 773
03a220 (+05c8): r1 = *(u32 *)(r10 - 0x1f0)
03a228 (+05d0): if r1 == 0x16 goto +0x1 <.text+0x3a118> ; branch 0x3a238 / relative 0x5e0
03a230 (+05d8): goto +0x25 <.text+0x3a240> ; branch 0x3a360 / relative 0x708
03a238 (+05e0): r1 = *(u64 *)(r10 - 0x5a8)
03a240 (+05e8): *(u64 *)(r10 - 0xff8) = r1
03a248 (+05f0): r1 = *(u64 *)(r10 - 0x5a0)
03a250 (+05f8): *(u64 *)(r10 - 0xff0) = r1
03a258 (+0600): r1 = r10
03a260 (+0608): r1 += -0x558
03a268 (+0610): *(u64 *)(r10 - 0x1000) = r1
03a270 (+0618): r1 = r10
03a278 (+0620): r1 += -0x1f0
03a280 (+0628): r5 = r10
03a288 (+0630): r2 = r8
03a290 (+0638): r3 = *(u64 *)(r10 - 0x5b8)
03a298 (+0640): r7 = *(u64 *)(r10 - 0x598)
03a2a0 (+0648): r4 = r7
03a2a8 (+0650): call -0x5697 ; call 0xedf8 / window 264
03a2b0 (+0658): r1 = *(u32 *)(r10 - 0x1f0)
03a2b8 (+0660): if r1 == 0x16 goto +0x1 <.text+0x3a1a8> ; branch 0x3a2c8 / relative 0x670
03a2c0 (+0668): goto +0x13 <.text+0x3a240> ; branch 0x3a360 / relative 0x708
03a2c8 (+0670): r1 = r10
03a2d0 (+0678): r1 += -0x1f0
03a2d8 (+0680): r2 = r7
03a2e0 (+0688): call 0x1b9b ; call 0x47fc0 / window 419
03a2e8 (+0690): r7 = *(u32 *)(r10 - 0xe8)
03a2f0 (+0698): if r7 != 0x2 goto +0x1b <.text+0x3a2b0> ; branch 0x3a3d0 / relative 0x778
03a2f8 (+06a0): r1 = *(u64 *)(r10 - 0x1d8)
03a300 (+06a8): *(u64 *)(r10 - 0x2e0) = r1
03a308 (+06b0): r2 = *(u64 *)(r10 - 0x1e0)
03a310 (+06b8): *(u64 *)(r10 - 0x2e8) = r2
03a318 (+06c0): r3 = *(u64 *)(r10 - 0x1e8)
03a320 (+06c8): *(u64 *)(r10 - 0x2f0) = r3
03a328 (+06d0): r4 = *(u64 *)(r10 - 0x1f0)
03a330 (+06d8): *(u64 *)(r10 - 0x2f8) = r4
03a338 (+06e0): *(u64 *)(r6 + 0x18) = r1
03a340 (+06e8): *(u64 *)(r6 + 0x10) = r2
03a348 (+06f0): *(u64 *)(r6 + 0x8) = r3
03a350 (+06f8): *(u64 *)(r6 + 0x0) = r4
03a358 (+0700): goto -0x40 <.text+0x3a040> ; branch 0x3a160 / relative 0x508
03a360 (+0708): r2 = *(u32 *)(r10 - 0x1d4)
03a368 (+0710): *(u32 *)(r10 - 0x410) = r2
03a370 (+0718): r3 = *(u64 *)(r10 - 0x1dc)
03a378 (+0720): *(u64 *)(r10 - 0x418) = r3
03a380 (+0728): r4 = *(u64 *)(r10 - 0x1e4)
03a388 (+0730): *(u64 *)(r10 - 0x420) = r4
03a390 (+0738): r5 = *(u64 *)(r10 - 0x1ec)
03a398 (+0740): *(u64 *)(r10 - 0x428) = r5
03a3a0 (+0748): *(u32 *)(r6 + 0x1c) = r2
03a3a8 (+0750): *(u64 *)(r6 + 0x14) = r3
03a3b0 (+0758): *(u64 *)(r6 + 0xc) = r4
03a3b8 (+0760): *(u64 *)(r6 + 0x4) = r5
03a3c0 (+0768): *(u32 *)(r6 + 0x0) = r1
03a3c8 (+0770): goto -0x4e <.text+0x3a040> ; branch 0x3a160 / relative 0x508
03a3d0 (+0778): r1 = r10
03a3d8 (+0780): r1 += -0x2f8
03a3e0 (+0788): *(u64 *)(r10 - 0x5c8) = r1
03a3e8 (+0790): r2 = r10
03a3f0 (+0798): r2 += -0x1f0
03a3f8 (+07a0): r3 = 0x108
03a400 (+07a8): call 0xbd72 ; call 0x98f98 / window 1246
03a408 (+07b0): r1 = r10
03a410 (+07b8): r1 += -0x31c
03a418 (+07c0): r2 = r10
03a420 (+07c8): r2 += -0xe4
03a428 (+07d0): r3 = 0x24
03a430 (+07d8): call 0xbd6c ; call 0x98f98 / window 1246
03a438 (+07e0): r1 = r10
03a440 (+07e8): r1 += -0x428
03a448 (+07f0): r2 = *(u64 *)(r10 - 0x5c8)
03a450 (+07f8): r3 = 0x108
03a458 (+0800): call 0xbd67 ; call 0x98f98 / window 1246
03a460 (+0808): *(u32 *)(r10 - 0x320) = r7
03a468 (+0810): r1 = *(u64 *)(r10 - 0x338)
03a470 (+0818): *(u64 *)(r10 - 0x1e0) = r1
03a478 (+0820): r1 = *(u64 *)(r10 - 0x340)
03a480 (+0828): *(u64 *)(r10 - 0x1e8) = r1
03a488 (+0830): r1 = *(u64 *)(r10 - 0x348)
03a490 (+0838): *(u64 *)(r10 - 0x1f0) = r1
03a498 (+0840): r1 = r10
03a4a0 (+0848): r1 += -0xc0
03a4a8 (+0850): r2 = r10
03a4b0 (+0858): r2 += -0x1f0
03a4b8 (+0860): r3 = 0x9f350 ll ; pointer 0x9f350; data32hex 0000000079a9090025000000000000005500000027000000000000009ea90900
03a4c8 (+0870): call -0x6c42 ; call 0x42c0 / window 96
03a4d0 (+0878): if r9 == 0x0 goto +0x4 <.text+0x3a3d8> ; branch 0x3a4f8 / relative 0x8a0
03a4d8 (+0880): r1 = *(u64 *)(r10 - 0xb0)
03a4e0 (+0888): if r9 > r1 goto +0x2 <.text+0x3a3d8> ; branch 0x3a4f8 / relative 0x8a0
03a4e8 (+0890): r7 = *(u64 *)(r10 - 0xb8)
03a4f0 (+0898): if r7 >= r9 goto +0x7 <.text+0x3a410> ; branch 0x3a530 / relative 0x8d8
03a4f8 (+08a0): r1 = 0x5600000000 ll
03a508 (+08b0): *(u64 *)(r6 + 0x0) = r1
03a510 (+08b8): r1 = r10
03a518 (+08c0): r1 += -0x3e0
03a520 (+08c8): call -0x6e91 ; call 0x30a0 / window 59
03a528 (+08d0): goto -0x7a <.text+0x3a040> ; branch 0x3a160 / relative 0x508
03a530 (+08d8): r2 = *(u32 *)(r10 - 0xc0)
03a538 (+08e0): *(u64 *)(r10 - 0x338) = r1
03a540 (+08e8): *(u64 *)(r10 - 0x5c8) = r2
03a548 (+08f0): *(u32 *)(r10 - 0x348) = r2
03a550 (+08f8): r1 = r7
03a558 (+0900): r1 -= r9
03a560 (+0908): *(u64 *)(r10 - 0x340) = r1
03a568 (+0910): r1 = *(u64 *)(r10 - 0x5d0)
03a570 (+0918): r1 &= 0x1
03a578 (+0920): if r1 != 0x0 goto +0x8 <.text+0x3a4a0> ; branch 0x3a5c0 / relative 0x968
03a580 (+0928): r1 = *(u64 *)(r10 - 0x5b0)
03a588 (+0930): r2 = *(u64 *)(r10 - 0x5b8)
03a590 (+0938): call -0x6f18 ; call 0x2cd8 / window 42
03a598 (+0940): if r0 != 0x0 goto +0x1 <.text+0x3a488> ; branch 0x3a5a8 / relative 0x950
03a5a0 (+0948): goto +0x85 <.text+0x3a8b0> ; branch 0x3a9d0 / relative 0xd78
03a5a8 (+0950): r1 = 0x6200000000 ll
03a5b8 (+0960): goto -0x17 <.text+0x3a3e8> ; branch 0x3a508 / relative 0x8b0
03a5c0 (+0968): r1 = r10
03a5c8 (+0970): r1 += -0x1f0
03a5d0 (+0978): r2 = r10
03a5d8 (+0980): r2 += -0x578
03a5e0 (+0988): call -0x7291 ; call 0x1160 / window 20
03a5e8 (+0990): r1 = *(u32 *)(r10 - 0x1f0)
03a5f0 (+0998): if r1 != 0x16 goto +0x12c <.text+0x3ae38> ; branch 0x3af58 / relative 0x1300
03a5f8 (+09a0): r2 = *(u64 *)(r10 - 0x1e8)
03a600 (+09a8): r1 = r10
03a608 (+09b0): r1 += -0x1f0
03a610 (+09b8): *(u64 *)(r10 - 0x5d8) = r2
03a618 (+09c0): call 0x95d2 ; call 0x854b0 / window 986
03a620 (+09c8): r1 = *(u32 *)(r10 - 0x1f0)
03a628 (+09d0): if r1 == 0x16 goto +0x1 <.text+0x3a518> ; branch 0x3a638 / relative 0x9e0
03a630 (+09d8): goto +0x8b <.text+0x3a970> ; branch 0x3aa90 / relative 0xe38
03a638 (+09e0): r1 = *(u64 *)(r10 - 0x1e0)
03a640 (+09e8): *(u64 *)(r10 - 0x5e0) = r1
03a648 (+09f0): r1 = *(u64 *)(r10 - 0x1e8)
03a650 (+09f8): *(u64 *)(r10 - 0x5e8) = r1
03a658 (+0a00): r1 = *(u64 *)(r1 + 0x8)
03a660 (+0a08): if r1 == 0x0 goto +0x39 <.text+0x3a710> ; branch 0x3a830 / relative 0xbd8
03a668 (+0a10): r1 = r10
03a670 (+0a18): r1 += -0x1f0
03a678 (+0a20): r2 = *(u64 *)(r10 - 0x5d8)
03a680 (+0a28): r3 = r8
03a688 (+0a30): call -0x554c ; call 0xfc30 / window 275
03a690 (+0a38): r1 = *(u32 *)(r10 - 0x1f0)
03a698 (+0a40): if r1 == 0x16 goto +0x1 <.text+0x3a588> ; branch 0x3a6a8 / relative 0xa50
03a6a0 (+0a48): goto +0x24 <.text+0x3a6a8> ; branch 0x3a7c8 / relative 0xb70
03a6a8 (+0a50): r1 = r10
03a6b0 (+0a58): r1 += -0x1f0
03a6b8 (+0a60): r2 = r8
03a6c0 (+0a68): r3 = *(u64 *)(r10 - 0x5d8)
03a6c8 (+0a70): r4 = *(u64 *)(r10 - 0x5b0)
03a6d0 (+0a78): r5 = *(u64 *)(r10 - 0x5a8)
03a6d8 (+0a80): call -0x54e4 ; call 0xffc0 / window 281
03a6e0 (+0a88): r1 = *(u32 *)(r10 - 0x1f0)
03a6e8 (+0a90): if r1 == 0x16 goto +0x1 <.text+0x3a5d8> ; branch 0x3a6f8 / relative 0xaa0
03a6f0 (+0a98): goto +0x2b <.text+0x3a730> ; branch 0x3a850 / relative 0xbf8
03a6f8 (+0aa0): r1 = *(u8 *)(r10 - 0x1ec)
03a700 (+0aa8): *(u64 *)(r10 - 0x5b0) = r1
03a708 (+0ab0): r1 = *(u64 *)(r10 - 0x5e8)
03a710 (+0ab8): r3 = *(u64 *)(r1 + 0x8)
03a718 (+0ac0): r2 = *(u64 *)(r1 + 0x0)
03a720 (+0ac8): r1 = r10
03a728 (+0ad0): r1 += -0x1f0
03a730 (+0ad8): call 0x15d6 ; call 0x455e8 / window 396
03a738 (+0ae0): r1 = *(u32 *)(r10 - 0x1f0)
03a740 (+0ae8): if r1 == 0x16 goto +0x1 <.text+0x3a630> ; branch 0x3a750 / relative 0xaf8
03a748 (+0af0): goto +0xf <.text+0x3a6a8> ; branch 0x3a7c8 / relative 0xb70
03a750 (+0af8): r1 = *(u64 *)(r10 - 0x1e0)
03a758 (+0b00): *(u64 *)(r10 - 0x28) = r1
03a760 (+0b08): r2 = *(u64 *)(r10 - 0x1e8)
03a768 (+0b10): *(u64 *)(r10 - 0x30) = r2
03a770 (+0b18): r1 = *(u64 *)(r10 - 0x1d8)
03a778 (+0b20): *(u64 *)(r10 - 0x20) = r1
03a780 (+0b28): r1 &= 0xff
03a788 (+0b30): if r1 != 0x0 goto +0x2b <.text+0x3a7c8> ; branch 0x3a8e8 / relative 0xc90
03a790 (+0b38): r2 <<= 0x20
03a798 (+0b40): r2 >>= 0x20
03a7a0 (+0b48): if r2 == 0x8 goto +0x1 <.text+0x3a690> ; branch 0x3a7b0 / relative 0xb58
03a7a8 (+0b50): goto +0x27 <.text+0x3a7c8> ; branch 0x3a8e8 / relative 0xc90
03a7b0 (+0b58): r1 = *(u64 *)(r10 - 0x5b0)
03a7b8 (+0b60): *(u8 *)(r10 - 0x20) = r1
03a7c0 (+0b68): goto +0x27 <.text+0x3a7e0> ; branch 0x3a900 / relative 0xca8
03a7c8 (+0b70): r2 = *(u32 *)(r10 - 0x1d4)
03a7d0 (+0b78): *(u32 *)(r10 - 0x2e0) = r2
03a7d8 (+0b80): r3 = *(u64 *)(r10 - 0x1dc)
03a7e0 (+0b88): *(u64 *)(r10 - 0x2e8) = r3
03a7e8 (+0b90): r4 = *(u64 *)(r10 - 0x1e4)
03a7f0 (+0b98): *(u64 *)(r10 - 0x2f0) = r4
03a7f8 (+0ba0): r5 = *(u64 *)(r10 - 0x1ec)
03a800 (+0ba8): *(u64 *)(r10 - 0x2f8) = r5
03a808 (+0bb0): *(u32 *)(r6 + 0x1c) = r2
03a810 (+0bb8): *(u64 *)(r6 + 0x14) = r3
03a818 (+0bc0): *(u64 *)(r6 + 0xc) = r4
03a820 (+0bc8): *(u64 *)(r6 + 0x4) = r5
03a828 (+0bd0): goto +0x14 <.text+0x3a7b0> ; branch 0x3a8d0 / relative 0xc78
03a830 (+0bd8): r1 = 0x5400000000 ll
03a840 (+0be8): *(u64 *)(r6 + 0x0) = r1
03a848 (+0bf0): goto +0x11 <.text+0x3a7b8> ; branch 0x3a8d8 / relative 0xc80
03a850 (+0bf8): r2 = *(u32 *)(r10 - 0x1d4)
03a858 (+0c00): *(u32 *)(r10 - 0x2e1) = r2
03a860 (+0c08): r2 = *(u64 *)(r10 - 0x1db)
03a868 (+0c10): *(u64 *)(r10 - 0x2e8) = r2
03a870 (+0c18): r2 = *(u64 *)(r10 - 0x1eb)
03a878 (+0c20): *(u64 *)(r10 - 0x2f8) = r2
03a880 (+0c28): r3 = *(u64 *)(r10 - 0x1e3)
03a888 (+0c30): *(u64 *)(r10 - 0x2f0) = r3
03a890 (+0c38): r4 = *(u8 *)(r10 - 0x1ec)
03a898 (+0c40): r5 = *(u32 *)(r10 - 0x2e1)
03a8a0 (+0c48): *(u32 *)(r6 + 0x1c) = r5
03a8a8 (+0c50): r5 = *(u64 *)(r10 - 0x2e8)
03a8b0 (+0c58): *(u64 *)(r6 + 0x15) = r5
03a8b8 (+0c60): *(u64 *)(r6 + 0xd) = r3
03a8c0 (+0c68): *(u64 *)(r6 + 0x5) = r2
03a8c8 (+0c70): *(u8 *)(r6 + 0x4) = r4
03a8d0 (+0c78): *(u32 *)(r6 + 0x0) = r1
03a8d8 (+0c80): r2 = *(u64 *)(r10 - 0x5e0)
03a8e0 (+0c88): goto +0x31 <.text+0x3a950> ; branch 0x3aa70 / relative 0xe18
03a8e8 (+0c90): r2 = *(u64 *)(r10 - 0x5b0)
03a8f0 (+0c98): if r1 == r2 goto +0x1 <.text+0x3a7e0> ; branch 0x3a900 / relative 0xca8
03a8f8 (+0ca0): goto +0x13 <.text+0x3a878> ; branch 0x3a998 / relative 0xd40
03a900 (+0ca8): r1 = *(u64 *)(r10 - 0x28)
03a908 (+0cb0): if r9 > r1 goto +0x1 <.text+0x3a7f8> ; branch 0x3a918 / relative 0xcc0
03a910 (+0cb8): goto +0x3 <.text+0x3a810> ; branch 0x3a930 / relative 0xcd8
03a918 (+0cc0): r1 = 0x5600000000 ll
03a928 (+0cd0): goto -0x1e <.text+0x3a720> ; branch 0x3a840 / relative 0xbe8
03a930 (+0cd8): r1 -= r9
03a938 (+0ce0): *(u64 *)(r10 - 0x28) = r1
03a940 (+0ce8): r1 = *(u64 *)(r10 - 0x5e8)
03a948 (+0cf0): r2 = *(u64 *)(r1 + 0x8)
03a950 (+0cf8): r1 = *(u64 *)(r1 + 0x0)
03a958 (+0d00): r3 = r10
03a960 (+0d08): r3 += -0x30
03a968 (+0d10): call -0x6769 ; call 0x6e28 / window 169
03a970 (+0d18): if r0 == 0x0 goto +0x7 <.text+0x3a890> ; branch 0x3a9b0 / relative 0xd58
03a978 (+0d20): r1 = r6
03a980 (+0d28): r2 = r0
03a988 (+0d30): call 0x98d2 ; call 0x87020 / window 1002
03a990 (+0d38): goto -0x18 <.text+0x3a7b8> ; branch 0x3a8d8 / relative 0xc80
03a998 (+0d40): r1 = 0x5900000000 ll
03a9a8 (+0d50): goto -0x2e <.text+0x3a720> ; branch 0x3a840 / relative 0xbe8
03a9b0 (+0d58): r2 = *(u64 *)(r10 - 0x5e0)
03a9b8 (+0d60): r1 = *(u64 *)(r2 + 0x0)
03a9c0 (+0d68): r1 += 0x1
03a9c8 (+0d70): *(u64 *)(r2 + 0x0) = r1
03a9d0 (+0d78): r1 = r10
03a9d8 (+0d80): r1 += -0x1f0
03a9e0 (+0d88): r2 = *(u64 *)(r10 - 0x598)
03a9e8 (+0d90): call 0x9558 ; call 0x854b0 / window 986
03a9f0 (+0d98): r1 = *(u32 *)(r10 - 0x1f0)
03a9f8 (+0da0): if r1 == 0x16 goto +0x1 <.text+0x3a8e8> ; branch 0x3aa08 / relative 0xdb0
03aa00 (+0da8): goto +0x11 <.text+0x3a970> ; branch 0x3aa90 / relative 0xe38
03aa08 (+0db0): r1 = *(u64 *)(r10 - 0x1e0)
03aa10 (+0db8): *(u64 *)(r10 - 0x598) = r1
03aa18 (+0dc0): r1 = *(u64 *)(r10 - 0x1e8)
03aa20 (+0dc8): r3 = *(u64 *)(r1 + 0x8)
03aa28 (+0dd0): r2 = *(u64 *)(r1 + 0x0)
03aa30 (+0dd8): r1 = r10
03aa38 (+0de0): r1 += -0x428
03aa40 (+0de8): call 0x1080 ; call 0x42e48 / window 365
03aa48 (+0df0): if r0 == 0x0 goto +0x11 <.text+0x3a9b8> ; branch 0x3aad8 / relative 0xe80
03aa50 (+0df8): r1 = r6
03aa58 (+0e00): r2 = r0
03aa60 (+0e08): call 0x98b7 ; call 0x87020 / window 1002
03aa68 (+0e10): r2 = *(u64 *)(r10 - 0x598)
03aa70 (+0e18): r1 = *(u64 *)(r2 + 0x0)
03aa78 (+0e20): r1 += 0x1
03aa80 (+0e28): *(u64 *)(r2 + 0x0) = r1
03aa88 (+0e30): goto -0xb0 <.text+0x3a3f0> ; branch 0x3a510 / relative 0x8b8
03aa90 (+0e38): r2 = *(u32 *)(r10 - 0x1ec)
03aa98 (+0e40): r3 = *(u64 *)(r10 - 0x1e8)
03aaa0 (+0e48): r4 = *(u64 *)(r10 - 0x1e0)
03aaa8 (+0e50): r5 = *(u64 *)(r10 - 0x1d8)
03aab0 (+0e58): *(u64 *)(r6 + 0x18) = r5
03aab8 (+0e60): *(u64 *)(r6 + 0x10) = r4
03aac0 (+0e68): *(u64 *)(r6 + 0x8) = r3
03aac8 (+0e70): *(u32 *)(r6 + 0x4) = r2
03aad0 (+0e78): goto +0x9a <.text+0x3ae88> ; branch 0x3afa8 / relative 0x1350
03aad8 (+0e80): r2 = *(u64 *)(r10 - 0x598)
03aae0 (+0e88): r1 = *(u64 *)(r2 + 0x0)
03aae8 (+0e90): r1 += 0x1
03aaf0 (+0e98): *(u64 *)(r2 + 0x0) = r1
03aaf8 (+0ea0): r1 = *(u64 *)(r10 - 0x5c8)
03ab00 (+0ea8): if r1 != 0x0 goto +0x88 <.text+0x3ae28> ; branch 0x3af48 / relative 0x12f0
03ab08 (+0eb0): if r7 == r9 goto +0x1 <.text+0x3a9f8> ; branch 0x3ab18 / relative 0xec0
03ab10 (+0eb8): goto +0x86 <.text+0x3ae28> ; branch 0x3af48 / relative 0x12f0
03ab18 (+0ec0): r1 = *(u64 *)(r10 - 0x5d0)
03ab20 (+0ec8): r1 &= 0x1
03ab28 (+0ed0): if r1 != 0x0 goto +0x30 <.text+0x3ab90> ; branch 0x3acb0 / relative 0x1058
03ab30 (+0ed8): r1 = r10
03ab38 (+0ee0): r1 += -0x1e0
03ab40 (+0ee8): r2 = *(u64 *)(r10 - 0x5a8)
03ab48 (+0ef0): call -0x606f ; call 0xa7d8 / window 217
03ab50 (+0ef8): r8 = r10
03ab58 (+0f00): r8 += -0x30
03ab60 (+0f08): r1 = r8
03ab68 (+0f10): r2 = *(u64 *)(r10 - 0x5b8)
03ab70 (+0f18): call -0x6074 ; call 0xa7d8 / window 217
03ab78 (+0f20): r7 = r10
03ab80 (+0f28): r7 += -0x2f8
03ab88 (+0f30): r1 = r7
03ab90 (+0f38): r2 = *(u64 *)(r10 - 0x5c0)
03ab98 (+0f40): call -0x6079 ; call 0xa7d8 / window 217
03aba0 (+0f48): r1 = r10
03aba8 (+0f50): r1 += -0x1b0
03abb0 (+0f58): r2 = *(u64 *)(r10 - 0x5a0)
03abb8 (+0f60): call -0x607d ; call 0xa7d8 / window 217
03abc0 (+0f68): r1 = 0x1
03abc8 (+0f70): *(u64 *)(r10 - 0x120) = r1
03abd0 (+0f78): r1 = r10
03abd8 (+0f80): r1 += -0x180
03abe0 (+0f88): r2 = r8
03abe8 (+0f90): r3 = 0x30
03abf0 (+0f98): call 0xbc74 ; call 0x98f98 / window 1246
03abf8 (+0fa0): r1 = 0x0
03ac00 (+0fa8): *(u64 *)(r10 - 0x1f0) = r1
03ac08 (+0fb0): r1 = r10
03ac10 (+0fb8): r1 += -0x150
03ac18 (+0fc0): r2 = r7
03ac20 (+0fc8): r3 = 0x30
03ac28 (+0fd0): call 0xbc6d ; call 0x98f98 / window 1246
03ac30 (+0fd8): r1 = r10
03ac38 (+0fe0): r1 += -0x60
03ac40 (+0fe8): r2 = r10
03ac48 (+0ff0): r2 += -0x1f0
03ac50 (+0ff8): call 0x776b ; call 0x767b0 / window 775
03ac58 (+1000): r1 = *(u32 *)(r10 - 0x60)
03ac60 (+1008): if r1 == 0x16 goto +0x5c <.text+0x3ae28> ; branch 0x3af48 / relative 0x12f0
03ac68 (+1010): r2 = *(u32 *)(r10 - 0x44)
03ac70 (+1018): *(u32 *)(r10 - 0x68) = r2
03ac78 (+1020): r3 = *(u64 *)(r10 - 0x4c)
03ac80 (+1028): *(u64 *)(r10 - 0x70) = r3
03ac88 (+1030): r4 = *(u64 *)(r10 - 0x54)
03ac90 (+1038): *(u64 *)(r10 - 0x78) = r4
03ac98 (+1040): r5 = *(u64 *)(r10 - 0x5c)
03aca0 (+1048): *(u64 *)(r10 - 0x80) = r5
03aca8 (+1050): goto +0x6e <.text+0x3af00> ; branch 0x3b020 / relative 0x13c8
03acb0 (+1058): r1 = r10
03acb8 (+1060): r1 += -0x1f0
03acc0 (+1068): r2 = r10
03acc8 (+1070): r2 += -0x578
03acd0 (+1078): call -0x736f ; call 0x1160 / window 20
03acd8 (+1080): r1 = *(u32 *)(r10 - 0x1f0)
03ace0 (+1088): if r1 != 0x16 goto +0x4e <.text+0x3ae38> ; branch 0x3af58 / relative 0x1300
03ace8 (+1090): r7 = *(u64 *)(r10 - 0x1e8)
03acf0 (+1098): r2 = *(u64 *)(r7 + 0x0)
03acf8 (+10a0): r1 = r10
03ad00 (+10a8): r1 += -0x580
03ad08 (+10b0): call -0x55c2 ; call 0xff00 / window 280
03ad10 (+10b8): r9 = *(u8 *)(r10 - 0x57f)
03ad18 (+10c0): r1 = *(u8 *)(r10 - 0x580)
03ad20 (+10c8): r1 &= 0x1
03ad28 (+10d0): if r1 == 0x0 goto +0x1 <.text+0x3ac18> ; branch 0x3ad38 / relative 0x10e0
03ad30 (+10d8): goto +0x50 <.text+0x3ae98> ; branch 0x3afb8 / relative 0x1360
03ad38 (+10e0): r1 = r10
03ad40 (+10e8): r1 += -0x590
03ad48 (+10f0): r2 = r8
03ad50 (+10f8): call 0x969e ; call 0x86248 / window 990
03ad58 (+1100): r1 = r10
03ad60 (+1108): r1 += -0xa1
03ad68 (+1110): *(u64 *)(r10 - 0x2c8) = r1
03ad70 (+1118): r1 = 0x9a140 ll ; pointer 0x9a140; data32hex 6275726e4b696e644e6f6e650100496e76616c6964204f7074696f6e20726570
03ad80 (+1128): *(u64 *)(r10 - 0x2d8) = r1
03ad88 (+1130): r1 = 0x8
03ad90 (+1138): *(u64 *)(r10 - 0x2f0) = r1
03ad98 (+1140): r1 = 0x9a210 ll ; pointer 0x9a210; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
03ada8 (+1150): *(u64 *)(r10 - 0x2f8) = r1
03adb0 (+1158): r1 = *(u64 *)(r10 - 0x588)
03adb8 (+1160): *(u64 *)(r10 - 0x2e0) = r1
03adc0 (+1168): r1 = *(u64 *)(r10 - 0x590)
03adc8 (+1170): *(u64 *)(r10 - 0x2e8) = r1
03add0 (+1178): *(u8 *)(r10 - 0xa1) = r9
03add8 (+1180): r9 = 0x1
03ade0 (+1188): *(u64 *)(r10 - 0x2c0) = r9
03ade8 (+1190): r1 = 0x4
03adf0 (+1198): *(u64 *)(r10 - 0x2d0) = r1
03adf8 (+11a0): r1 = r10
03ae00 (+11a8): r1 += -0x1e0
03ae08 (+11b0): r2 = *(u64 *)(r10 - 0x5a8)
03ae10 (+11b8): call -0x60c8 ; call 0xa7d8 / window 217
03ae18 (+11c0): r8 = r10
03ae20 (+11c8): r8 += -0x60
03ae28 (+11d0): r1 = r8
03ae30 (+11d8): r2 = r7
03ae38 (+11e0): call -0x60cd ; call 0xa7d8 / window 217
03ae40 (+11e8): r7 = r10
03ae48 (+11f0): r7 += -0x30
03ae50 (+11f8): r1 = r7
03ae58 (+1200): r2 = *(u64 *)(r10 - 0x5c0)
03ae60 (+1208): call -0x60d2 ; call 0xa7d8 / window 217
03ae68 (+1210): r1 = r10
03ae70 (+1218): r1 += -0x1b0
03ae78 (+1220): r2 = *(u64 *)(r10 - 0x5a0)
03ae80 (+1228): call -0x60d6 ; call 0xa7d8 / window 217
03ae88 (+1230): *(u64 *)(r10 - 0x120) = r9
03ae90 (+1238): r1 = r10
03ae98 (+1240): r1 += -0x180
03aea0 (+1248): r2 = r8
03aea8 (+1250): r3 = 0x30
03aeb0 (+1258): call 0xbc1c ; call 0x98f98 / window 1246
03aeb8 (+1260): r1 = 0x4
03aec0 (+1268): *(u64 *)(r10 - 0x1e8) = r1
03aec8 (+1270): r1 = r10
03aed0 (+1278): r1 += -0x2f8
03aed8 (+1280): *(u64 *)(r10 - 0x1f0) = r1
03aee0 (+1288): r1 = r10
03aee8 (+1290): r1 += -0x150
03aef0 (+1298): r2 = r7
03aef8 (+12a0): r3 = 0x30
03af00 (+12a8): call 0xbc12 ; call 0x98f98 / window 1246
03af08 (+12b0): r1 = r10
03af10 (+12b8): r1 += -0x80
03af18 (+12c0): r2 = r10
03af20 (+12c8): r2 += -0x1f0
03af28 (+12d0): call 0x7710 ; call 0x767b0 / window 775
03af30 (+12d8): r1 = *(u32 *)(r10 - 0x80)
03af38 (+12e0): if r1 == 0x16 goto +0x1 <.text+0x3ae28> ; branch 0x3af48 / relative 0x12f0
03af40 (+12e8): goto +0x13 <.text+0x3aec0> ; branch 0x3afe0 / relative 0x1388
03af48 (+12f0): r1 = 0x16
03af50 (+12f8): goto +0xa <.text+0x3ae88> ; branch 0x3afa8 / relative 0x1350
03af58 (+1300): r2 = *(u64 *)(r10 - 0x1e0)
03af60 (+1308): *(u64 *)(r10 - 0x2f8) = r2
03af68 (+1310): r3 = *(u64 *)(r10 - 0x1d8)
03af70 (+1318): *(u64 *)(r10 - 0x2f0) = r3
03af78 (+1320): r4 = *(u32 *)(r10 - 0x1ec)
03af80 (+1328): r5 = *(u64 *)(r10 - 0x1e8)
03af88 (+1330): *(u64 *)(r6 + 0x18) = r3
03af90 (+1338): *(u64 *)(r6 + 0x10) = r2
03af98 (+1340): *(u64 *)(r6 + 0x8) = r5
03afa0 (+1348): *(u32 *)(r6 + 0x4) = r4
03afa8 (+1350): *(u32 *)(r6 + 0x0) = r1
03afb0 (+1358): goto -0x155 <.text+0x3a3f0> ; branch 0x3a510 / relative 0x8b8
03afb8 (+1360): r1 = 0x0
03afc0 (+1368): *(u32 *)(r6 + 0x0) = r1
03afc8 (+1370): r1 = r9
03afd0 (+1378): *(u32 *)(r6 + 0x4) = r1
03afd8 (+1380): goto -0x15a <.text+0x3a3f0> ; branch 0x3a510 / relative 0x8b8
03afe0 (+1388): r2 = *(u32 *)(r10 - 0x64)
03afe8 (+1390): *(u32 *)(r10 - 0x88) = r2
03aff0 (+1398): r3 = *(u64 *)(r10 - 0x6c)
03aff8 (+13a0): *(u64 *)(r10 - 0x90) = r3
03b000 (+13a8): r4 = *(u64 *)(r10 - 0x74)
03b008 (+13b0): *(u64 *)(r10 - 0x98) = r4
03b010 (+13b8): r5 = *(u64 *)(r10 - 0x7c)
03b018 (+13c0): *(u64 *)(r10 - 0xa0) = r5
03b020 (+13c8): *(u32 *)(r6 + 0x1c) = r2
03b028 (+13d0): *(u64 *)(r6 + 0x14) = r3
03b030 (+13d8): *(u64 *)(r6 + 0xc) = r4
03b038 (+13e0): *(u64 *)(r6 + 0x4) = r5
03b040 (+13e8): goto -0x14 <.text+0x3ae88> ; branch 0x3afa8 / relative 0x1350
