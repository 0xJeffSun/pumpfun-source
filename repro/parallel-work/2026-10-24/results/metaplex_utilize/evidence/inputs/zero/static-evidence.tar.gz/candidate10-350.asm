03cd20 (+0000): r9 = r3
03cd28 (+0008): r8 = r1
03cd30 (+0010): r3 = *(u64 *)(r5 - 0xff8)
03cd38 (+0018): if r3 == 0x0 goto +0x1c <.text+0x3cd00> ; branch 0x3ce20 / relative 0x100
03cd40 (+0020): *(u64 *)(r10 - 0x920) = r4
03cd48 (+0028): *(u64 *)(r10 - 0x928) = r2
03cd50 (+0030): r6 = *(u64 *)(r5 - 0x1000)
03cd58 (+0038): r1 = r10
03cd60 (+0040): r1 += -0x6c8
03cd68 (+0048): r2 = r6
03cd70 (+0050): call -0x6cf2 ; call 0x65e8 / window 154
03cd78 (+0058): r7 = *(u32 *)(r10 - 0x6c8)
03cd80 (+0060): if r7 == 0x3a goto +0x1 <.text+0x3cc70> ; branch 0x3cd90 / relative 0x70
03cd88 (+0068): goto +0x16 <.text+0x3cd20> ; branch 0x3ce40 / relative 0x120
03cd90 (+0070): r1 = 0x2
03cd98 (+0078): r2 = *(u8 *)(r6 + 0x0)
03cda0 (+0080): if r2 > 0x30 goto +0x8 <.text+0x3ccc8> ; branch 0x3cde8 / relative 0xc8
03cda8 (+0088): r3 = 0x1
03cdb0 (+0090): r3 <<= r2
03cdb8 (+0098): r2 = 0x100000001036f ll
03cdc8 (+00a8): r3 &= r2
03cdd0 (+00b0): if r3 != 0x0 goto +0x1 <.text+0x3ccc0> ; branch 0x3cde0 / relative 0xc0
03cdd8 (+00b8): goto +0x1 <.text+0x3ccc8> ; branch 0x3cde8 / relative 0xc8
03cde0 (+00c0): r1 = 0x0
03cde8 (+00c8): r2 = 0x4b
03cdf0 (+00d0): *(u32 *)(r8 + 0x4) = r2
03cdf8 (+00d8): *(u32 *)(r8 + 0x0) = r1
03ce00 (+00e0): r1 = r10
03ce08 (+00e8): r1 += -0x6c8
03ce10 (+00f0): call -0x73e0 ; call 0x2f18 / window 52
03ce18 (+00f8): goto +0x3 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03ce20 (+0100): r1 = 0xbd00000000 ll
03ce30 (+0110): *(u64 *)(r8 + 0x0) = r1
03ce38 (+0118): exit
03ce40 (+0120): *(u64 *)(r10 - 0x930) = r8
03ce48 (+0128): r1 = *(u64 *)(r10 - 0x6b8)
03ce50 (+0130): *(u64 *)(r10 - 0x818) = r1
03ce58 (+0138): r1 = *(u64 *)(r10 - 0x6b0)
03ce60 (+0140): *(u64 *)(r10 - 0x810) = r1
03ce68 (+0148): r1 = *(u64 *)(r10 - 0x6a8)
03ce70 (+0150): *(u64 *)(r10 - 0x808) = r1
03ce78 (+0158): r6 = *(u64 *)(r10 - 0x6c4)
03ce80 (+0160): r8 = *(u32 *)(r10 - 0x6bc)
03ce88 (+0168): r1 = r10
03ce90 (+0170): r1 += -0x800
03ce98 (+0178): r2 = r10
03cea0 (+0180): r2 += -0x6a0
03cea8 (+0188): r3 = 0x138
03ceb0 (+0190): call 0xb823 ; call 0x98fd0 / window 1246
03ceb8 (+0198): *(u32 *)(r10 - 0x81c) = r8
03cec0 (+01a0): *(u64 *)(r10 - 0x824) = r6
03cec8 (+01a8): *(u32 *)(r10 - 0x828) = r7
03ced0 (+01b0): r1 = *(u64 *)(r10 - 0x928)
03ced8 (+01b8): *(u64 *)(r10 - 0x6c8) = r1
03cee0 (+01c0): r1 = r10
03cee8 (+01c8): r1 += -0x838
03cef0 (+01d0): *(u64 *)(r10 - 0x938) = r9
03cef8 (+01d8): r2 = r9
03cf00 (+01e0): r3 = *(u64 *)(r10 - 0x920)
03cf08 (+01e8): call 0x76f9 ; call 0x786d8 / window 802
03cf10 (+01f0): r1 = r10
03cf18 (+01f8): r1 += -0x820
03cf20 (+0200): *(u64 *)(r10 - 0x940) = r1
03cf28 (+0208): r1 = r10
03cf30 (+0210): r1 += -0x818
03cf38 (+0218): *(u64 *)(r10 - 0x948) = r1
03cf40 (+0220): r9 = *(u64 *)(r10 - 0x838)
03cf48 (+0228): r6 = *(u64 *)(r10 - 0x830)
03cf50 (+0230): r6 += 0x18
03cf58 (+0238): r8 = 0x3
03cf60 (+0240): r7 = r6
03cf68 (+0248): r7 += -0x18
03cf70 (+0250): if r7 == r9 goto +0x23 <.text+0x3cf70> ; branch 0x3d090 / relative 0x370
03cf78 (+0258): r2 = r10
03cf80 (+0260): r2 += -0x6c8
03cf88 (+0268): r1 = r6
03cf90 (+0270): call -0x745c ; call 0x2cb8 / window 41
03cf98 (+0278): if r0 == 0x0 goto +0x1c <.text+0x3cf60> ; branch 0x3d080 / relative 0x360
03cfa0 (+0280): r1 = r7
03cfa8 (+0288): call 0x904d ; call 0x85218 / window 981
03cfb0 (+0290): if r0 != 0x0 goto +0x19 <.text+0x3cf60> ; branch 0x3d080 / relative 0x360
03cfb8 (+0298): r2 = *(u64 *)(r6 - 0x8)
03cfc0 (+02a0): r2 += 0x10
03cfc8 (+02a8): r1 = r10
03cfd0 (+02b0): r1 += -0x848
03cfd8 (+02b8): r3 = 0x9f400 ll ; pointer 0x9f400; data32hex 00000000fea909001c00000000000000870100002a00000000000000fea90900
03cfe8 (+02c8): call -0x72e2 ; call 0x38e0 / window 87
03cff0 (+02d0): r3 = *(u64 *)(r10 - 0x848)
03cff8 (+02d8): r2 = *(u64 *)(r3 + 0x8)
03d000 (+02e0): if r2 == 0x0 goto +0x2b0 <.text+0x3e468> ; branch 0x3e588 / relative 0x1868
03d008 (+02e8): r1 = *(u64 *)(r10 - 0x840)
03d010 (+02f0): r3 = *(u64 *)(r3 + 0x0)
03d018 (+02f8): r4 = *(u8 *)(r3 + 0x0)
03d020 (+0300): if r4 == 0xb goto +0x1 <.text+0x3cf10> ; branch 0x3d030 / relative 0x310
03d028 (+0308): goto +0x7 <.text+0x3cf48> ; branch 0x3d068 / relative 0x348
03d030 (+0310): if r8 > r2 goto +0x2af <.text+0x3e490> ; branch 0x3e5b0 / relative 0x1890
03d038 (+0318): r2 = *(u8 *)(r3 + 0x2)
03d040 (+0320): r3 = *(u64 *)(r1 + 0x0)
03d048 (+0328): r3 += -0x1
03d050 (+0330): *(u64 *)(r1 + 0x0) = r3
03d058 (+0338): if r2 == 0x1 goto +0x6 <.text+0x3cf70> ; branch 0x3d090 / relative 0x370
03d060 (+0340): goto +0x3 <.text+0x3cf60> ; branch 0x3d080 / relative 0x360
03d068 (+0348): r2 = *(u64 *)(r1 + 0x0)
03d070 (+0350): r2 += -0x1
03d078 (+0358): *(u64 *)(r1 + 0x0) = r2
03d080 (+0360): r6 += 0x30
03d088 (+0368): goto -0x26 <.text+0x3ce40> ; branch 0x3cf60 / relative 0x240
03d090 (+0370): r1 = *(u32 *)(r10 - 0x828)
03d098 (+0378): if r7 == r9 goto +0x1 <.text+0x3cf88> ; branch 0x3d0a8 / relative 0x388
03d0a0 (+0380): if r1 != 0x2f goto +0x41 <.text+0x3d190> ; branch 0x3d2b0 / relative 0x590
03d0a8 (+0388): if r1 == 0x29 goto +0xc4 <.text+0x3d5b0> ; branch 0x3d6d0 / relative 0x9b0
03d0b0 (+0390): r8 = *(u64 *)(r10 - 0x930)
03d0b8 (+0398): r9 = *(u64 *)(r10 - 0x938)
03d0c0 (+03a0): if r1 == 0x2a goto +0x50 <.text+0x3d228> ; branch 0x3d348 / relative 0x628
03d0c8 (+03a8): if r1 == 0x2b goto +0x1bf <.text+0x3dda8> ; branch 0x3dec8 / relative 0x11a8
03d0d0 (+03b0): if r1 == 0x2c goto +0x87 <.text+0x3d3f0> ; branch 0x3d510 / relative 0x7f0
03d0d8 (+03b8): if r1 == 0x2d goto +0x65 <.text+0x3d2e8> ; branch 0x3d408 / relative 0x6e8
03d0e0 (+03c0): if r1 == 0x2e goto +0x70 <.text+0x3d348> ; branch 0x3d468 / relative 0x748
03d0e8 (+03c8): if r1 == 0x2f goto +0x1d5 <.text+0x3de78> ; branch 0x3df98 / relative 0x1278
03d0f0 (+03d0): if r1 == 0x30 goto +0x1d1 <.text+0x3de60> ; branch 0x3df80 / relative 0x1260
03d0f8 (+03d8): if r1 == 0x31 goto +0xa7 <.text+0x3d518> ; branch 0x3d638 / relative 0x918
03d100 (+03e0): if r1 == 0x32 goto +0x1a5 <.text+0x3dd10> ; branch 0x3de30 / relative 0x1110
03d108 (+03e8): if r1 == 0x34 goto +0x18c <.text+0x3dc50> ; branch 0x3dd70 / relative 0x1050
03d110 (+03f0): if r1 == 0x35 goto +0x197 <.text+0x3dcb0> ; branch 0x3ddd0 / relative 0x10b0
03d118 (+03f8): if r1 == 0x36 goto +0xcc <.text+0x3d660> ; branch 0x3d780 / relative 0xa60
03d120 (+0400): if r1 == 0x37 goto +0x93 <.text+0x3d4a0> ; branch 0x3d5c0 / relative 0x8a0
03d128 (+0408): if r1 == 0x38 goto +0xc1 <.text+0x3d618> ; branch 0x3d738 / relative 0xa18
03d130 (+0410): if r1 == 0x39 goto +0x1 <.text+0x3d020> ; branch 0x3d140 / relative 0x420
03d138 (+0418): goto +0x1df <.text+0x3df18> ; branch 0x3e038 / relative 0x1318
03d140 (+0420): r1 = 0x9aa1a ll ; pointer 0x9aa1a; data32hex 49583a20436c6f7365204163636f756e747349583a20526573697a6549583a20
03d150 (+0430): r2 = 0x12
03d158 (+0438): call -0x1 ; external sol_log_
03d160 (+0440): r1 = 0x5
03d168 (+0448): r2 = *(u64 *)(r10 - 0x920)
03d170 (+0450): if r1 > r2 goto +0x265 <.text+0x3e380> ; branch 0x3e4a0 / relative 0x1780
03d178 (+0458): r1 = r10
03d180 (+0460): r1 += -0x6c8
03d188 (+0468): r2 = r9
03d190 (+0470): r3 = 0x999f8 ll ; pointer 0x999f8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03d1a0 (+0480): call -0x5aaf ; call 0xfc30 / window 275
03d1a8 (+0488): r1 = *(u32 *)(r10 - 0x6c8)
03d1b0 (+0490): if r1 == 0x16 goto +0x1 <.text+0x3d0a0> ; branch 0x3d1c0 / relative 0x4a0
03d1b8 (+0498): goto +0x252 <.text+0x3e330> ; branch 0x3e450 / relative 0x1730
03d1c0 (+04a0): r6 = r9
03d1c8 (+04a8): r9 += 0x60
03d1d0 (+04b0): r1 = r9
03d1d8 (+04b8): call 0x9007 ; call 0x85218 / window 981
03d1e0 (+04c0): if r0 != 0x0 goto +0x1 <.text+0x3d0d0> ; branch 0x3d1f0 / relative 0x4d0
03d1e8 (+04c8): goto +0x259 <.text+0x3e398> ; branch 0x3e4b8 / relative 0x1798
03d1f0 (+04d0): r1 = r6
03d1f8 (+04d8): r1 += 0x78
03d200 (+04e0): r2 = 0x9ed98 ll ; pointer 0x9ed98; data32hex 00000000189a090000000000f89a09000000000048a409002200000000000000
03d210 (+04f0): call -0x74ac ; call 0x2cb8 / window 41
03d218 (+04f8): r7 = 0x1
03d220 (+0500): if r0 == 0x0 goto +0x252 <.text+0x3e398> ; branch 0x3e4b8 / relative 0x1798
03d228 (+0508): r6 += 0x90
03d230 (+0510): r1 = r10
03d238 (+0518): r1 += -0x6c8
03d240 (+0520): r2 = r6
03d248 (+0528): call 0x7296 ; call 0x76700 / window 773
03d250 (+0530): r1 = *(u32 *)(r10 - 0x6c8)
03d258 (+0538): if r1 == 0x16 goto +0x1 <.text+0x3d148> ; branch 0x3d268 / relative 0x548
03d260 (+0540): goto +0x256 <.text+0x3e3f8> ; branch 0x3e518 / relative 0x17f8
03d268 (+0548): r1 = *(u64 *)(r6 + 0x0)
03d270 (+0550): r2 = 0x99958 ll ; pointer 0x99958; data32hex a3a58e4c1ed793790e47a3fcb85ca0eb51391e8c227ff80def9440974ff283f8
03d280 (+0560): call -0x74af ; call 0x2d10 / window 44
03d288 (+0568): if r0 != 0x0 goto +0x1 <.text+0x3d178> ; branch 0x3d298 / relative 0x578
03d290 (+0570): goto +0x2e7 <.text+0x3e8b0> ; branch 0x3e9d0 / relative 0x1cb0
03d298 (+0578): r1 = 0xbc00000000 ll
03d2a8 (+0588): goto +0x274 <.text+0x3e530> ; branch 0x3e650 / relative 0x1930
03d2b0 (+0590): r2 = 0x9b00000000 ll
03d2c0 (+05a0): r3 = *(u64 *)(r10 - 0x930)
03d2c8 (+05a8): *(u64 *)(r3 + 0x0) = r2
03d2d0 (+05b0): r2 = r1
03d2d8 (+05b8): r2 += -0x34
03d2e0 (+05c0): r3 = 0x2
03d2e8 (+05c8): if r3 > r2 goto -0x97 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03d2f0 (+05d0): if r1 == 0x29 goto -0x98 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03d2f8 (+05d8): if r1 == 0x2a goto +0x29a <.text+0x3e6b0> ; branch 0x3e7d0 / relative 0x1ab0
03d300 (+05e0): if r1 == 0x2b goto +0x28b <.text+0x3e640> ; branch 0x3e760 / relative 0x1a40
03d308 (+05e8): if r1 == 0x2c goto +0x29d <.text+0x3e6d8> ; branch 0x3e7f8 / relative 0x1ad8
03d310 (+05f0): if r1 == 0x2d goto -0x9c <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03d318 (+05f8): if r1 == 0x2e goto +0x291 <.text+0x3e688> ; branch 0x3e7a8 / relative 0x1a88
03d320 (+0600): if r1 == 0x2f goto +0x290 <.text+0x3e688> ; branch 0x3e7a8 / relative 0x1a88
03d328 (+0608): if r1 == 0x31 goto +0x286 <.text+0x3e640> ; branch 0x3e760 / relative 0x1a40
03d330 (+0610): if r1 == 0x32 goto +0x289 <.text+0x3e660> ; branch 0x3e780 / relative 0x1a60
03d338 (+0618): if r1 == 0x37 goto -0xa1 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03d340 (+0620): goto +0x279 <.text+0x3e5f0> ; branch 0x3e710 / relative 0x19f0
03d348 (+0628): r1 = 0x9aa8b ll ; pointer 0x9aa8b; data32hex 49583a2043726561746549583a205472616e73666572204f7574204f66204573
03d358 (+0638): r2 = 0xa
03d360 (+0640): call -0x1 ; external sol_log_
03d368 (+0648): r6 = r10
03d370 (+0650): r6 += -0x6c8
03d378 (+0658): r1 = r6
03d380 (+0660): r2 = *(u64 *)(r10 - 0x940)
03d388 (+0668): r3 = 0x108
03d390 (+0670): call 0xb787 ; call 0x98fd0 / window 1246
03d398 (+0678): r1 = r8
03d3a0 (+0680): r2 = *(u64 *)(r10 - 0x928)
03d3a8 (+0688): r3 = r9
03d3b0 (+0690): r4 = *(u64 *)(r10 - 0x920)
03d3b8 (+0698): r5 = r6
03d3c0 (+06a0): call -0x291b ; call 0x28af0 / window 321
03d3c8 (+06a8): r6 = 0x0
03d3d0 (+06b0): r1 = 0x1
03d3d8 (+06b8): r2 = 0x1
03d3e0 (+06c0): r3 = 0x1
03d3e8 (+06c8): r4 = 0x1
03d3f0 (+06d0): r5 = 0x1
03d3f8 (+06d8): r0 = 0x1
03d400 (+06e0): goto +0x252 <.text+0x3e578> ; branch 0x3e698 / relative 0x1978
03d408 (+06e8): r6 = *(u32 *)(r10 - 0x820)
03d410 (+06f0): r1 = 0x9aa75 ll ; pointer 0x9aa75; data32hex 49583a205265766f6b6549583a2044656c656761746549583a20437265617465
03d420 (+0700): r2 = 0xa
03d428 (+0708): call -0x1 ; external sol_log_
03d430 (+0710): r1 = r8
03d438 (+0718): r2 = *(u64 *)(r10 - 0x928)
03d440 (+0720): r3 = r9
03d448 (+0728): r4 = *(u64 *)(r10 - 0x920)
03d450 (+0730): r5 = r6
03d458 (+0738): call -0x39c4 ; call 0x20640 / window 313
03d460 (+0740): goto +0x23f <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03d468 (+0748): r1 = 0x9a230 ll ; pointer 0x9a230; data32hex 49583a204c6f636b44656c65676174656d65746164617461646561646c6f636b
03d478 (+0758): r2 = 0x8
03d480 (+0760): call -0x1 ; external sol_log_
03d488 (+0768): r6 = r10
03d490 (+0770): r6 += -0x6c8
03d498 (+0778): r1 = r6
03d4a0 (+0780): r2 = *(u64 *)(r10 - 0x940)
03d4a8 (+0788): r3 = 0x38
03d4b0 (+0790): call 0xb763 ; call 0x98fd0 / window 1246
03d4b8 (+0798): r1 = r8
03d4c0 (+07a0): r2 = *(u64 *)(r10 - 0x928)
03d4c8 (+07a8): r3 = r9
03d4d0 (+07b0): r4 = *(u64 *)(r10 - 0x920)
03d4d8 (+07b8): r5 = r6
03d4e0 (+07c0): call -0xe1a ; call 0x36418 / window 341
03d4e8 (+07c8): r4 = 0x0
03d4f0 (+07d0): r1 = 0x1
03d4f8 (+07d8): r2 = 0x1
03d500 (+07e0): r3 = 0x1
03d508 (+07e8): goto +0x22e <.text+0x3e560> ; branch 0x3e680 / relative 0x1960
03d510 (+07f0): r1 = 0x9aa7f ll ; pointer 0x9aa7f; data32hex 49583a2044656c656761746549583a2043726561746549583a205472616e7366
03d520 (+0800): r2 = 0xc
03d528 (+0808): call -0x1 ; external sol_log_
03d530 (+0810): r6 = r10
03d538 (+0818): r6 += -0x6c8
03d540 (+0820): r1 = r6
03d548 (+0828): r2 = *(u64 *)(r10 - 0x940)
03d550 (+0830): r3 = 0x60
03d558 (+0838): call 0xb74e ; call 0x98fd0 / window 1246
03d560 (+0840): r1 = r8
03d568 (+0848): r2 = *(u64 *)(r10 - 0x928)
03d570 (+0850): r3 = r9
03d578 (+0858): r4 = *(u64 *)(r10 - 0x920)
03d580 (+0860): r5 = r6
03d588 (+0868): call -0x402e ; call 0x1d420 / window 311
03d590 (+0870): r5 = 0x0
03d598 (+0878): r1 = 0x1
03d5a0 (+0880): r2 = 0x1
03d5a8 (+0888): r3 = 0x1
03d5b0 (+0890): r4 = 0x1
03d5b8 (+0898): goto +0x219 <.text+0x3e568> ; branch 0x3e688 / relative 0x1968
03d5c0 (+08a0): r6 = *(u64 *)(r10 - 0x818)
03d5c8 (+08a8): r7 = *(u32 *)(r10 - 0x820)
03d5d0 (+08b0): r1 = 0x9aa36 ll ; pointer 0x9aa36; data32hex 49583a205072696e7449583a20556e76657269667949583a2056657269667949
03d5e0 (+08c0): r2 = 0x9
03d5e8 (+08c8): call -0x1 ; external sol_log_
03d5f0 (+08d0): *(u64 *)(r10 - 0x1000) = r7
03d5f8 (+08d8): *(u64 *)(r10 - 0xff8) = r6
03d600 (+08e0): r5 = r10
03d608 (+08e8): r1 = r8
03d610 (+08f0): r2 = *(u64 *)(r10 - 0x928)
03d618 (+08f8): r3 = r9
03d620 (+0900): r4 = *(u64 *)(r10 - 0x920)
03d628 (+0908): call -0x22c2 ; call 0x2c020 / window 325
03d630 (+0910): goto +0x205 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03d638 (+0918): r1 = 0x9aa5f ll ; pointer 0x9aa5f; data32hex 49583a205472616e7366657249583a20556e6c6f636b49583a205265766f6b65
03d648 (+0928): r2 = 0xc
03d650 (+0930): call -0x1 ; external sol_log_
03d658 (+0938): r6 = r10
03d660 (+0940): r6 += -0x6c8
03d668 (+0948): r1 = r6
03d670 (+0950): r2 = *(u64 *)(r10 - 0x940)
03d678 (+0958): r3 = 0x40
03d680 (+0960): call 0xb729 ; call 0x98fd0 / window 1246
03d688 (+0968): r1 = r8
03d690 (+0970): r2 = *(u64 *)(r10 - 0x928)
03d698 (+0978): r3 = r9
03d6a0 (+0980): r4 = *(u64 *)(r10 - 0x920)
03d6a8 (+0988): r5 = r6
03d6b0 (+0990): call -0x1c17 ; call 0x2f600 / window 335
03d6b8 (+0998): r2 = 0x0
03d6c0 (+09a0): r1 = 0x1
03d6c8 (+09a8): goto +0x1f4 <.text+0x3e550> ; branch 0x3e670 / relative 0x1950
03d6d0 (+09b0): r6 = *(u64 *)(r10 - 0x818)
03d6d8 (+09b8): r1 = 0x9a1e8 ll ; pointer 0x9a1e8; data32hex 49583a204275726e4370694775617264446561646c6f636b4e6f74466f756e64
03d6e8 (+09c8): r2 = 0x8
03d6f0 (+09d0): call -0x1 ; external sol_log_
03d6f8 (+09d8): *(u64 *)(r10 - 0xff8) = r6
03d700 (+09e0): r5 = r10
03d708 (+09e8): r1 = *(u64 *)(r10 - 0x930)
03d710 (+09f0): r2 = *(u64 *)(r10 - 0x928)
03d718 (+09f8): r3 = *(u64 *)(r10 - 0x938)
03d720 (+0a00): r4 = *(u64 *)(r10 - 0x920)
03d728 (+0a08): call -0x57e8 ; call 0x117f0 / window 296
03d730 (+0a10): goto +0x1e5 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03d738 (+0a18): r1 = 0x9aa2c ll ; pointer 0x9aa2c; data32hex 49583a20526573697a6549583a205072696e7449583a20556e76657269667949
03d748 (+0a28): r2 = 0xa
03d750 (+0a30): call -0x1 ; external sol_log_
03d758 (+0a38): r1 = r8
03d760 (+0a40): r3 = r9
03d768 (+0a48): r4 = *(u64 *)(r10 - 0x920)
03d770 (+0a50): call -0x10b1 ; call 0x351f0 / window 340
03d778 (+0a58): goto +0x1dc <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03d780 (+0a60): r1 = *(u64 *)(r10 - 0x928)
03d788 (+0a68): *(u64 *)(r10 - 0x568) = r1
03d790 (+0a70): *(u64 *)(r10 - 0x360) = r9
03d798 (+0a78): r1 = *(u64 *)(r10 - 0x920)
03d7a0 (+0a80): r1 *= 0x30
03d7a8 (+0a88): r9 += r1
03d7b0 (+0a90): *(u64 *)(r10 - 0x368) = r9
03d7b8 (+0a98): r1 = r10
03d7c0 (+0aa0): r1 += -0x6c8
03d7c8 (+0aa8): r2 = r10
03d7d0 (+0ab0): r2 += -0x368
03d7d8 (+0ab8): call 0x89b8 ; call 0x825a0 / window 881
03d7e0 (+0ac0): r1 = *(u32 *)(r10 - 0x6c8)
03d7e8 (+0ac8): if r1 != 0x16 goto +0x183 <.text+0x3e2e8> ; branch 0x3e408 / relative 0x16e8
03d7f0 (+0ad0): r6 = *(u64 *)(r10 - 0x6c0)
03d7f8 (+0ad8): r1 = r10
03d800 (+0ae0): r1 += -0x6c8
03d808 (+0ae8): r2 = r6
03d810 (+0af0): call 0x71dd ; call 0x76700 / window 773
03d818 (+0af8): r1 = *(u32 *)(r10 - 0x6c8)
03d820 (+0b00): if r1 == 0x16 goto +0x1 <.text+0x3d710> ; branch 0x3d830 / relative 0xb10
03d828 (+0b08): goto +0x184 <.text+0x3e330> ; branch 0x3e450 / relative 0x1730
03d830 (+0b10): r1 = *(u64 *)(r6 + 0x0)
03d838 (+0b18): r2 = 0x99878 ll ; pointer 0x99878; data32hex 0508ec7b72c55f8e93b1ddeaa5430a586a71dd99c930a32917770924ce7191ea
03d848 (+0b28): call -0x7568 ; call 0x2d10 / window 44
03d850 (+0b30): if r0 != 0x0 goto +0x1a3 <.text+0x3e450> ; branch 0x3e570 / relative 0x1850
03d858 (+0b38): r1 = r10
03d860 (+0b40): r1 += -0x6c8
03d868 (+0b48): r2 = r10
03d870 (+0b50): r2 += -0x368
03d878 (+0b58): call 0x89a4 ; call 0x825a0 / window 881
03d880 (+0b60): r1 = *(u32 *)(r10 - 0x6c8)
03d888 (+0b68): if r1 == 0x16 goto +0x1 <.text+0x3d778> ; branch 0x3d898 / relative 0xb78
03d890 (+0b70): goto +0x16e <.text+0x3e2e8> ; branch 0x3e408 / relative 0x16e8
03d898 (+0b78): r1 = *(u64 *)(r10 - 0x6c0)
03d8a0 (+0b80): *(u64 *)(r10 - 0x938) = r1
03d8a8 (+0b88): r1 = *(u64 *)(r1 + 0x0)
03d8b0 (+0b90): r2 = 0x99978 ll ; pointer 0x99978; data32hex 18be35e87ce34452616c90e106e97a0043af8fc70d41525c347dfeb4bee1df89
03d8c0 (+0ba0): call -0x7577 ; call 0x2d10 / window 44
03d8c8 (+0ba8): if r0 != 0x0 goto +0x22c <.text+0x3e910> ; branch 0x3ea30 / relative 0x1d10
03d8d0 (+0bb0): r6 = *(u64 *)(r10 - 0x360)
03d8d8 (+0bb8): r1 = *(u64 *)(r10 - 0x368)
03d8e0 (+0bc0): if r6 != r1 goto +0x1 <.text+0x3d7d0> ; branch 0x3d8f0 / relative 0xbd0
03d8e8 (+0bc8): goto +0x43a <.text+0x3f9a0> ; branch 0x3fac0 / relative 0x2da0
03d8f0 (+0bd0): r1 = r6
03d8f8 (+0bd8): r1 += 0x30
03d900 (+0be0): *(u64 *)(r10 - 0x360) = r1
03d908 (+0be8): r1 = r6
03d910 (+0bf0): r1 += 0x18
03d918 (+0bf8): r2 = r10
03d920 (+0c00): r2 += -0x568
03d928 (+0c08): call -0x758b ; call 0x2cd8 / window 42
03d930 (+0c10): if r0 != 0x0 goto +0x21f <.text+0x3e910> ; branch 0x3ea30 / relative 0x1d10
03d938 (+0c18): *(u64 *)(r10 - 0x920) = r6
03d940 (+0c20): r2 = *(u64 *)(r6 + 0x10)
03d948 (+0c28): r2 += 0x10
03d950 (+0c30): r1 = r10
03d958 (+0c38): r1 += -0x888
03d960 (+0c40): r3 = 0x9f0b8 ll ; pointer 0x9f0b8; data32hex 00000000b89a090020000000000000002a0000002600000000000000b89a0900
03d970 (+0c50): call -0x7413 ; call 0x38e0 / window 87
03d978 (+0c58): r2 = *(u64 *)(r10 - 0x888)
03d980 (+0c60): r3 = *(u64 *)(r2 + 0x8)
03d988 (+0c68): r1 = 0x9a17d ll ; pointer 0x9a17d; data32hex 00496e76616c6964204f7074696f6e20726570726573656e746174696f6e3a20
03d998 (+0c78): if r3 == 0x0 goto +0x1 <.text+0x3d888> ; branch 0x3d9a8 / relative 0xc88
03d9a0 (+0c80): r1 = *(u64 *)(r2 + 0x0)
03d9a8 (+0c88): r1 = *(u8 *)(r1 + 0x0)
03d9b0 (+0c90): r6 = *(u64 *)(r10 - 0x880)
03d9b8 (+0c98): call -0x7a23 ; call 0x8a8 / window 11
03d9c0 (+0ca0): r7 = r0
03d9c8 (+0ca8): r1 = *(u64 *)(r6 + 0x0)
03d9d0 (+0cb0): r1 += -0x1
03d9d8 (+0cb8): *(u64 *)(r6 + 0x0) = r1
03d9e0 (+0cc0): r8 = 0xbf
03d9e8 (+0cc8): r9 = 0x0
03d9f0 (+0cd0): r7 <<= 0x20
03d9f8 (+0cd8): r7 >>= 0x20
03da00 (+0ce0): if r7 == 0xf goto +0x3e9 <.text+0x3f830> ; branch 0x3f950 / relative 0x2c30
03da08 (+0ce8): r1 = r10
03da10 (+0cf0): r1 += -0x6c8
03da18 (+0cf8): call 0x99a1 ; call 0x8a728 / window 1033
03da20 (+0d00): r9 = *(u32 *)(r10 - 0x6c8)
03da28 (+0d08): if r9 != 0x16 goto +0x3e0 <.text+0x3f810> ; branch 0x3f930 / relative 0x2c10
03da30 (+0d10): r1 = *(u64 *)(r10 - 0x6b0)
03da38 (+0d18): *(u64 *)(r10 - 0x120) = r1
03da40 (+0d20): r1 = *(u64 *)(r10 - 0x6b8)
03da48 (+0d28): *(u64 *)(r10 - 0x128) = r1
03da50 (+0d30): r1 = *(u64 *)(r10 - 0x6c0)
03da58 (+0d38): *(u64 *)(r10 - 0x130) = r1
03da60 (+0d40): r6 = *(u64 *)(r10 - 0x920)
03da68 (+0d48): r1 = r6
03da70 (+0d50): call 0x8ee6 ; call 0x851a8 / window 980
03da78 (+0d58): r1 = r10
03da80 (+0d60): r1 += -0x130
03da88 (+0d68): r2 = r0
03da90 (+0d70): call 0x939e ; call 0x87788 / window 1009
03da98 (+0d78): *(u64 *)(r10 - 0x928) = r0
03daa0 (+0d80): if r7 == 0x0 goto +0xd <.text+0x3d9f0> ; branch 0x3db10 / relative 0xdf0
03daa8 (+0d88): r8 = 0xbf
03dab0 (+0d90): r9 = 0x0
03dab8 (+0d98): if r7 == 0x4 goto +0x1 <.text+0x3d9a8> ; branch 0x3dac8 / relative 0xda8
03dac0 (+0da0): goto +0x3d1 <.text+0x3f830> ; branch 0x3f950 / relative 0x2c30
03dac8 (+0da8): r1 = *(u64 *)(r10 - 0x920)
03dad0 (+0db0): call 0x8ec1 ; call 0x850e0 / window 979
03dad8 (+0db8): r6 = r0
03dae0 (+0dc0): r8 = 0x33
03dae8 (+0dc8): r4 = *(u64 *)(r10 - 0x928)
03daf0 (+0dd0): if r4 > r6 goto +0x3cb <.text+0x3f830> ; branch 0x3f950 / relative 0x2c30
03daf8 (+0dd8): r1 = *(u64 *)(r10 - 0x928)
03db00 (+0de0): r6 -= r1
03db08 (+0de8): goto +0x9 <.text+0x3da38> ; branch 0x3db58 / relative 0xe38
03db10 (+0df0): r1 = r6
03db18 (+0df8): r2 = 0x99a18 ll ; pointer 0x99a18; data32hex 0000000000000000000000000000000000000000000000000000000000000000
03db28 (+0e08): call 0x8f84 ; call 0x85750 / window 988
03db30 (+0e10): r1 = r6
03db38 (+0e18): call 0x8eb4 ; call 0x850e0 / window 979
03db40 (+0e20): r6 = r0
03db48 (+0e28): r1 = 0x0
03db50 (+0e30): *(u64 *)(r10 - 0x928) = r1
03db58 (+0e38): r1 = *(u64 *)(r10 - 0x938)
03db60 (+0e40): call 0x8eaf ; call 0x850e0 / window 979
03db68 (+0e48): r7 = r0
03db70 (+0e50): r7 += r6
03db78 (+0e58): r9 = 0x0
03db80 (+0e60): r4 = 0x1
03db88 (+0e68): if r0 > r7 goto +0x1 <.text+0x3da78> ; branch 0x3db98 / relative 0xe78
03db90 (+0e70): r4 = 0x0
03db98 (+0e78): r8 = 0x33
03dba0 (+0e80): r4 &= 0x1
03dba8 (+0e88): if r4 != 0x0 goto +0x3b4 <.text+0x3f830> ; branch 0x3f950 / relative 0x2c30
03dbb0 (+0e90): r1 = *(u64 *)(r10 - 0x938)
03dbb8 (+0e98): r2 = *(u64 *)(r1 + 0x8)
03dbc0 (+0ea0): r2 += 0x10
03dbc8 (+0ea8): r1 = r10
03dbd0 (+0eb0): r1 += -0x898
03dbd8 (+0eb8): r3 = 0x9f0d0 ll ; pointer 0x9f0d0; data32hex 00000000b89a09002000000000000000480000001a00000000000000b89a0900
03dbe8 (+0ec8): call -0x7474 ; call 0x3850 / window 86
03dbf0 (+0ed0): r1 = *(u64 *)(r10 - 0x898)
03dbf8 (+0ed8): r1 = *(u64 *)(r1 + 0x0)
03dc00 (+0ee0): r2 = *(u64 *)(r10 - 0x890)
03dc08 (+0ee8): *(u64 *)(r1 + 0x0) = r7
03dc10 (+0ef0): r1 = *(u64 *)(r2 + 0x0)
03dc18 (+0ef8): r1 += 0x1
03dc20 (+0f00): *(u64 *)(r2 + 0x0) = r1
03dc28 (+0f08): r6 = *(u64 *)(r10 - 0x920)
03dc30 (+0f10): r2 = *(u64 *)(r6 + 0x8)
03dc38 (+0f18): r2 += 0x10
03dc40 (+0f20): r1 = r10
03dc48 (+0f28): r1 += -0x8a8
03dc50 (+0f30): r3 = 0x9f0e8 ll ; pointer 0x9f0e8; data32hex 00000000b89a090020000000000000004b0000001d000000000000004ba70900
03dc60 (+0f40): call -0x7483 ; call 0x3850 / window 86
03dc68 (+0f48): r1 = *(u64 *)(r10 - 0x8a8)
03dc70 (+0f50): r1 = *(u64 *)(r1 + 0x0)
03dc78 (+0f58): r2 = *(u64 *)(r10 - 0x8a0)
03dc80 (+0f60): r3 = *(u64 *)(r10 - 0x928)
03dc88 (+0f68): *(u64 *)(r1 + 0x0) = r3
03dc90 (+0f70): r1 = *(u64 *)(r2 + 0x0)
03dc98 (+0f78): r1 += 0x1
03dca0 (+0f80): *(u64 *)(r2 + 0x0) = r1
03dca8 (+0f88): r1 = r6
03dcb0 (+0f90): call 0x8e9e ; call 0x851a8 / window 980
03dcb8 (+0f98): r6 = r0
03dcc0 (+0fa0): if r6 == 0x0 goto +0x391 <.text+0x3f830> ; branch 0x3f950 / relative 0x2c30
03dcc8 (+0fa8): r1 = r10
03dcd0 (+0fb0): r1 += -0x6c8
03dcd8 (+0fb8): r2 = *(u64 *)(r10 - 0x920)
03dce0 (+0fc0): call 0x8f00 ; call 0x854e8 / window 986
03dce8 (+0fc8): r9 = *(u32 *)(r10 - 0x6c8)
03dcf0 (+0fd0): if r9 != 0x16 goto +0x387 <.text+0x3f810> ; branch 0x3f930 / relative 0x2c10
03dcf8 (+0fd8): r6 += -0x1
03dd00 (+0fe0): r1 = *(u64 *)(r10 - 0x6b8)
03dd08 (+0fe8): r2 = *(u64 *)(r10 - 0x6c0)
03dd10 (+0ff0): r3 = *(u64 *)(r2 + 0x8)
03dd18 (+0ff8): if r3 > r6 goto +0x1 <.text+0x3dc08> ; branch 0x3dd28 / relative 0x1008
03dd20 (+1000): goto +0x4 <.text+0x3dc28> ; branch 0x3dd48 / relative 0x1028
03dd28 (+1008): r2 = *(u64 *)(r2 + 0x0)
03dd30 (+1010): r2 += r6
03dd38 (+1018): r3 = 0x0
03dd40 (+1020): *(u8 *)(r2 + 0x0) = r3
03dd48 (+1028): r2 = *(u64 *)(r1 + 0x0)
03dd50 (+1030): r2 += 0x1
03dd58 (+1038): *(u64 *)(r1 + 0x0) = r2
03dd60 (+1040): r8 = *(u64 *)(r10 - 0x930)
03dd68 (+1048): goto -0x94 <.text+0x3d7b0> ; branch 0x3d8d0 / relative 0xbb0
03dd70 (+1050): r6 = *(u32 *)(r10 - 0x820)
03dd78 (+1058): r1 = 0x9aa4b ll ; pointer 0x9aa4b; data32hex 49583a2056657269667949583a2055706461746549583a205472616e73666572
03dd88 (+1068): r2 = 0xa
03dd90 (+1070): call -0x1 ; external sol_log_
03dd98 (+1078): r1 = r8
03dda0 (+1080): r2 = *(u64 *)(r10 - 0x928)
03dda8 (+1088): r3 = r9
03ddb0 (+1090): r4 = *(u64 *)(r10 - 0x920)
03ddb8 (+1098): r5 = r6
03ddc0 (+10a0): call -0x58f ; call 0x3b150 / window 348
03ddc8 (+10a8): goto +0x112 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03ddd0 (+10b0): r6 = *(u32 *)(r10 - 0x820)
03ddd8 (+10b8): r1 = 0x9aa3f ll ; pointer 0x9aa3f; data32hex 49583a20556e76657269667949583a2056657269667949583a20557064617465
03dde8 (+10c8): r2 = 0xc
03ddf0 (+10d0): call -0x1 ; external sol_log_
03ddf8 (+10d8): r1 = r8
03de00 (+10e0): r2 = *(u64 *)(r10 - 0x928)
03de08 (+10e8): r3 = r9
03de10 (+10f0): r4 = *(u64 *)(r10 - 0x920)
03de18 (+10f8): r5 = r6
03de20 (+1100): call -0x404 ; call 0x3be08 / window 349
03de28 (+1108): goto +0x106 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03de30 (+1110): r1 = 0x9aa55 ll ; pointer 0x9aa55; data32hex 49583a2055706461746549583a205472616e7366657249583a20556e6c6f636b
03de40 (+1120): r2 = 0xa
03de48 (+1128): call -0x1 ; external sol_log_
03de50 (+1130): r6 = r10
03de58 (+1138): r6 += -0x6c8
03de60 (+1140): r1 = r6
03de68 (+1148): r2 = *(u64 *)(r10 - 0x940)
03de70 (+1150): r3 = 0x158
03de78 (+1158): call 0xb62a ; call 0x98fd0 / window 1246
03de80 (+1160): r1 = r8
03de88 (+1168): r2 = *(u64 *)(r10 - 0x928)
03de90 (+1170): r3 = r9
03de98 (+1178): r4 = *(u64 *)(r10 - 0x920)
03dea0 (+1180): r5 = r6
03dea8 (+1188): call -0x178f ; call 0x32238 / window 337
03deb0 (+1190): r2 = 0x1
03deb8 (+1198): r1 = 0x0
03dec0 (+11a0): goto +0xf5 <.text+0x3e550> ; branch 0x3e670 / relative 0x1950
03dec8 (+11a8): r1 = 0x9a1d0 ll ; pointer 0x9a1d0; data32hex 49583a204d696e742028627974657320446174614974656d49583a204275726e
03ded8 (+11b8): r2 = 0x8
03dee0 (+11c0): call -0x1 ; external sol_log_
03dee8 (+11c8): r6 = r10
03def0 (+11d0): r6 += -0x6c8
03def8 (+11d8): r1 = r6
03df00 (+11e0): r2 = *(u64 *)(r10 - 0x940)
03df08 (+11e8): r3 = 0x40
03df10 (+11f0): call 0xb617 ; call 0x98fd0 / window 1246
03df18 (+11f8): r1 = r8
03df20 (+1200): r2 = *(u64 *)(r10 - 0x928)
03df28 (+1208): r3 = r9
03df30 (+1210): r4 = *(u64 *)(r10 - 0x920)
03df38 (+1218): r5 = r6
03df40 (+1220): call -0x286b ; call 0x29bf0 / window 323
03df48 (+1228): r0 = 0x0
03df50 (+1230): r1 = 0x1
03df58 (+1238): r2 = 0x1
03df60 (+1240): r3 = 0x1
03df68 (+1248): r4 = 0x1
03df70 (+1250): r5 = 0x1
03df78 (+1258): goto +0xe2 <.text+0x3e570> ; branch 0x3e690 / relative 0x1970
03df80 (+1260): r1 = 0x4b00000000 ll
03df90 (+1270): goto +0xa2 <.text+0x3e388> ; branch 0x3e4a8 / relative 0x1788
03df98 (+1278): r1 = 0x9aa6b ll ; pointer 0x9aa6b; data32hex 49583a20556e6c6f636b49583a205265766f6b6549583a2044656c6567617465
03dfa8 (+1288): r2 = 0xa
03dfb0 (+1290): call -0x1 ; external sol_log_
03dfb8 (+1298): r6 = r10
03dfc0 (+12a0): r6 += -0x6c8
03dfc8 (+12a8): r1 = r6
03dfd0 (+12b0): r2 = *(u64 *)(r10 - 0x940)
03dfd8 (+12b8): r3 = 0x38
03dfe0 (+12c0): call 0xb5fd ; call 0x98fd0 / window 1246
03dfe8 (+12c8): r1 = r8
03dff0 (+12d0): r2 = *(u64 *)(r10 - 0x928)
03dff8 (+12d8): r3 = r9
03e000 (+12e0): r4 = *(u64 *)(r10 - 0x920)
03e008 (+12e8): r5 = r6
03e010 (+12f0): call -0xf4d ; call 0x365b0 / window 342
03e018 (+12f8): r3 = 0x0
03e020 (+1300): r1 = 0x1
03e028 (+1308): r2 = 0x1
03e030 (+1310): goto +0xc8 <.text+0x3e558> ; branch 0x3e678 / relative 0x1958
03e038 (+1318): r1 = *(u64 *)(r10 - 0x928)
03e040 (+1320): *(u64 *)(r10 - 0x438) = r1
03e048 (+1328): r1 = r10
03e050 (+1330): r1 += -0x8b8
03e058 (+1338): r2 = r9
03e060 (+1340): r3 = *(u64 *)(r10 - 0x920)
03e068 (+1348): call 0x74cd ; call 0x786d8 / window 802
03e070 (+1350): r1 = r10
03e078 (+1358): r1 += -0x110
03e080 (+1360): *(u64 *)(r10 - 0x958) = r1
03e088 (+1368): r1 = r10
03e090 (+1370): r1 += -0x12b
03e098 (+1378): *(u64 *)(r10 - 0x960) = r1
03e0a0 (+1380): r1 = r10
03e0a8 (+1388): r1 += -0x6a8
03e0b0 (+1390): *(u64 *)(r10 - 0x968) = r1
03e0b8 (+1398): r1 = r10
03e0c0 (+13a0): r1 += -0x6c3
03e0c8 (+13a8): *(u64 *)(r10 - 0x950) = r1
03e0d0 (+13b0): r1 = r10
03e0d8 (+13b8): r1 += -0xe8
03e0e0 (+13c0): *(u64 *)(r10 - 0x980) = r1
03e0e8 (+13c8): r1 = r10
03e0f0 (+13d0): r1 += -0x24
03e0f8 (+13d8): *(u64 *)(r10 - 0x970) = r1
03e100 (+13e0): r1 = r10
03e108 (+13e8): r1 += -0x5bc
03e110 (+13f0): *(u64 *)(r10 - 0x978) = r1
03e118 (+13f8): r8 = *(u64 *)(r10 - 0x8b8)
03e120 (+1400): r7 = *(u64 *)(r10 - 0x8b0)
03e128 (+1408): r7 += 0x18
03e130 (+1410): *(u64 *)(r10 - 0x988) = r8
03e138 (+1418): r9 = 0x0
03e140 (+1420): r6 = r7
03e148 (+1428): r6 += -0x18
03e150 (+1430): if r6 == r8 goto +0x9b <.text+0x3e510> ; branch 0x3e630 / relative 0x1910
03e158 (+1438): r2 = r10
03e160 (+1440): r2 += -0x438
03e168 (+1448): r1 = r7
03e170 (+1450): call -0x7698 ; call 0x2cb8 / window 41
03e178 (+1458): if r0 == 0x0 goto +0x3 <.text+0x3e078> ; branch 0x3e198 / relative 0x1478
03e180 (+1460): r1 = r6
03e188 (+1468): call 0x8e11 ; call 0x85218 / window 981
03e190 (+1470): if r0 == 0x0 goto +0xd <.text+0x3e0e0> ; branch 0x3e200 / relative 0x14e0
03e198 (+1478): r1 = r6
03e1a0 (+1480): r2 = 0x9f3f8 ll ; pointer 0x9f3f8; data32hex 000000009898090000000000fea909001c00000000000000870100002a000000
03e1b0 (+1490): call -0x76a0 ; call 0x2cb8 / window 41
03e1b8 (+1498): r9 = 0x1
03e1c0 (+14a0): if r0 != 0x0 goto +0x8d <.text+0x3e510> ; branch 0x3e630 / relative 0x1910
03e1c8 (+14a8): r1 = r7
03e1d0 (+14b0): r2 = 0x9f3f8 ll ; pointer 0x9f3f8; data32hex 000000009898090000000000fea909001c00000000000000870100002a000000
03e1e0 (+14c0): call -0x76a6 ; call 0x2cb8 / window 41
03e1e8 (+14c8): if r0 != 0x0 goto +0x88 <.text+0x3e510> ; branch 0x3e630 / relative 0x1910
03e1f0 (+14d0): r7 += 0x30
03e1f8 (+14d8): goto -0x19 <.text+0x3e018> ; branch 0x3e138 / relative 0x1418
03e200 (+14e0): r2 = *(u64 *)(r7 - 0x8)
03e208 (+14e8): r2 += 0x10
03e210 (+14f0): r1 = r10
03e218 (+14f8): r1 += -0x8c8
03e220 (+1500): r3 = 0x9f3c8 ll ; pointer 0x9f3c8; data32hex 00000000fea909001c000000000000006c0100003300000000000000fea90900
03e230 (+1510): call -0x752b ; call 0x38e0 / window 87
03e238 (+1518): r1 = *(u64 *)(r10 - 0x8c8)
03e240 (+1520): r2 = *(u64 *)(r1 + 0x8)
03e248 (+1528): if r2 == 0x0 goto +0x3f9 <.text+0x400f8> ; branch 0x40218 / relative 0x34f8
03e250 (+1530): r2 = *(u64 *)(r10 - 0x8c0)
03e258 (+1538): r1 = *(u64 *)(r1 + 0x0)
03e260 (+1540): r1 = *(u8 *)(r1 + 0x0)
03e268 (+1548): r3 = *(u64 *)(r2 + 0x0)
03e270 (+1550): r3 += -0x1
03e278 (+1558): *(u64 *)(r2 + 0x0) = r3
03e280 (+1560): if r1 == 0x4 goto +0x1 <.text+0x3e170> ; branch 0x3e290 / relative 0x1570
03e288 (+1568): goto -0x14 <.text+0x3e0d0> ; branch 0x3e1f0 / relative 0x14d0
03e290 (+1570): r1 = r10
03e298 (+1578): r1 += -0x6c8
03e2a0 (+1580): r2 = r6
03e2a8 (+1588): call 0x13a9 ; call 0x47ff8 / window 419
03e2b0 (+1590): r2 = *(u64 *)(r10 - 0x950)
03e2b8 (+1598): r1 = *(u64 *)(r2 + 0x0)
03e2c0 (+15a0): *(u64 *)(r10 - 0x368) = r1
03e2c8 (+15a8): r1 = *(u64 *)(r2 + 0x8)
03e2d0 (+15b0): *(u64 *)(r10 - 0x360) = r1
03e2d8 (+15b8): r1 = *(u64 *)(r2 + 0x10)
03e2e0 (+15c0): *(u64 *)(r10 - 0x358) = r1
03e2e8 (+15c8): r1 = *(u32 *)(r2 + 0x17)
03e2f0 (+15d0): *(u32 *)(r10 - 0x351) = r1
03e2f8 (+15d8): r9 = *(u8 *)(r10 - 0x6c4)
03e300 (+15e0): r6 = *(u32 *)(r10 - 0x6c8)
03e308 (+15e8): r8 = *(u32 *)(r10 - 0x5c0)
03e310 (+15f0): if r8 == 0x2 goto +0x58 <.text+0x3e4b8> ; branch 0x3e5d8 / relative 0x18b8
03e318 (+15f8): r1 = *(u64 *)(r10 - 0x958)
03e320 (+1600): r2 = *(u64 *)(r10 - 0x968)
03e328 (+1608): r3 = 0xe8
03e330 (+1610): call 0xb593 ; call 0x98fd0 / window 1246
03e338 (+1618): r1 = *(u64 *)(r10 - 0x970)
03e340 (+1620): r2 = *(u64 *)(r10 - 0x978)
03e348 (+1628): r3 = 0x24
03e350 (+1630): call 0xb58f ; call 0x98fd0 / window 1246
03e358 (+1638): *(u8 *)(r10 - 0x12c) = r9
03e360 (+1640): *(u32 *)(r10 - 0x130) = r6
03e368 (+1648): r1 = *(u32 *)(r10 - 0x351)
03e370 (+1650): r2 = *(u64 *)(r10 - 0x960)
03e378 (+1658): *(u32 *)(r2 + 0x17) = r1
03e380 (+1660): r1 = *(u64 *)(r10 - 0x358)
03e388 (+1668): *(u64 *)(r2 + 0x10) = r1
03e390 (+1670): r1 = *(u64 *)(r10 - 0x360)
03e398 (+1678): *(u64 *)(r2 + 0x8) = r1
03e3a0 (+1680): r1 = *(u64 *)(r10 - 0x368)
03e3a8 (+1688): *(u64 *)(r2 + 0x0) = r1
03e3b0 (+1690): *(u32 *)(r10 - 0x28) = r8
03e3b8 (+1698): r1 = *(u32 *)(r10 - 0x7c)
03e3c0 (+16a0): if r1 == 0x6 goto +0x4 <.text+0x3e2c8> ; branch 0x3e3e8 / relative 0x16c8
03e3c8 (+16a8): r2 = 0xfffffffe ll
03e3d8 (+16b8): r1 &= r2
03e3e0 (+16c0): if r1 == 0x4 goto +0xe4 <.text+0x3e9e8> ; branch 0x3eb08 / relative 0x1de8
03e3e8 (+16c8): r1 = *(u64 *)(r10 - 0x980)
03e3f0 (+16d0): call -0x766b ; call 0x30a0 / window 59
03e3f8 (+16d8): r8 = *(u64 *)(r10 - 0x988)
03e400 (+16e0): goto -0x43 <.text+0x3e0d0> ; branch 0x3e1f0 / relative 0x14d0
03e408 (+16e8): r2 = *(u32 *)(r10 - 0x6c4)
03e410 (+16f0): r3 = *(u64 *)(r10 - 0x6c0)
03e418 (+16f8): r4 = *(u64 *)(r10 - 0x6b0)
03e420 (+1700): *(u64 *)(r8 + 0x18) = r4
03e428 (+1708): r4 = *(u64 *)(r10 - 0x6b8)
03e430 (+1710): *(u64 *)(r8 + 0x10) = r4
03e438 (+1718): *(u64 *)(r8 + 0x8) = r3
03e440 (+1720): *(u32 *)(r8 + 0x4) = r2
03e448 (+1728): goto +0x8 <.text+0x3e370> ; branch 0x3e490 / relative 0x1770
03e450 (+1730): r2 = *(u32 *)(r10 - 0x6ac)
03e458 (+1738): *(u32 *)(r8 + 0x1c) = r2
03e460 (+1740): r2 = *(u64 *)(r10 - 0x6b4)
03e468 (+1748): *(u64 *)(r8 + 0x14) = r2
03e470 (+1750): r2 = *(u64 *)(r10 - 0x6bc)
03e478 (+1758): *(u64 *)(r8 + 0xc) = r2
03e480 (+1760): r2 = *(u64 *)(r10 - 0x6c4)
03e488 (+1768): *(u64 *)(r8 + 0x4) = r2
03e490 (+1770): *(u32 *)(r8 + 0x0) = r1
03e498 (+1778): goto +0x38 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03e4a0 (+1780): r1 = 0xa
03e4a8 (+1788): *(u64 *)(r8 + 0x0) = r1
03e4b0 (+1790): goto +0x35 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03e4b8 (+1798): r1 = r10
03e4c0 (+17a0): r1 += -0x6c8
03e4c8 (+17a8): r2 = r9
03e4d0 (+17b0): r3 = 0x9ccbe ll ; pointer 0x9ccbe; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03e4e0 (+17c0): r4 = 0x2
03e4e8 (+17c8): call -0x5d15 ; call 0xfc48 / window 276
03e4f0 (+17d0): r1 = *(u32 *)(r10 - 0x6c8)
03e4f8 (+17d8): if r1 != 0x16 goto +0x3 <.text+0x3e3f8> ; branch 0x3e518 / relative 0x17f8
03e500 (+17e0): r7 = 0x0
03e508 (+17e8): r6 = *(u64 *)(r10 - 0x938)
03e510 (+17f0): goto -0x25e <.text+0x3d108> ; branch 0x3d228 / relative 0x508
03e518 (+17f8): r2 = *(u32 *)(r10 - 0x6ac)
03e520 (+1800): r3 = *(u64 *)(r10 - 0x930)
03e528 (+1808): *(u32 *)(r3 + 0x1c) = r2
03e530 (+1810): r2 = *(u64 *)(r10 - 0x6b4)
03e538 (+1818): *(u64 *)(r3 + 0x14) = r2
03e540 (+1820): r2 = *(u64 *)(r10 - 0x6bc)
03e548 (+1828): *(u64 *)(r3 + 0xc) = r2
03e550 (+1830): r2 = *(u64 *)(r10 - 0x6c4)
03e558 (+1838): *(u64 *)(r3 + 0x4) = r2
03e560 (+1840): *(u32 *)(r3 + 0x0) = r1
03e568 (+1848): goto +0x1e <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03e570 (+1850): r1 = 0x700000000 ll
03e580 (+1860): goto -0x1c <.text+0x3e388> ; branch 0x3e4a8 / relative 0x1788
03e588 (+1868): r1 = 0x0
03e590 (+1870): r2 = 0x0
03e598 (+1878): r3 = 0x9f418 ll ; pointer 0x9f418; data32hex 00000000fea909001c00000000000000890100001100000000000000fea90900
03e5a8 (+1888): goto +0x3 <.text+0x3e4a8> ; branch 0x3e5c8 / relative 0x18a8
03e5b0 (+1890): r1 = 0x2
03e5b8 (+1898): r3 = 0x9f430 ll ; pointer 0x9f430; data32hex 00000000fea909001c000000000000008a01000015000000000000007cad0900
03e5c8 (+18a8): call 0xa41c ; call 0x906b0 / window 1172
03e5d0 (+18b0): call -0x1 ; external abort
03e5d8 (+18b8): r1 = *(u64 *)(r10 - 0x368)
03e5e0 (+18c0): *(u64 *)(r10 - 0x568) = r1
03e5e8 (+18c8): r1 = *(u64 *)(r10 - 0x360)
03e5f0 (+18d0): *(u64 *)(r10 - 0x560) = r1
03e5f8 (+18d8): r1 = *(u64 *)(r10 - 0x358)
03e600 (+18e0): *(u64 *)(r10 - 0x558) = r1
03e608 (+18e8): r1 = *(u32 *)(r10 - 0x351)
03e610 (+18f0): *(u32 *)(r10 - 0x551) = r1
03e618 (+18f8): r1 = r6
03e620 (+1900): if r1 == 0x16 goto +0x1 <.text+0x3e510> ; branch 0x3e630 / relative 0x1910
03e628 (+1908): goto +0x88 <.text+0x3e950> ; branch 0x3ea70 / relative 0x1d50
03e630 (+1910): r9 &= 0xff
03e638 (+1918): if r9 == 0x0 goto +0x3a <.text+0x3e6f0> ; branch 0x3e810 / relative 0x1af0
03e640 (+1920): r1 = 0x9900000000 ll
03e650 (+1930): r2 = *(u64 *)(r10 - 0x930)
03e658 (+1938): *(u64 *)(r2 + 0x0) = r1
03e660 (+1940): r1 = 0x1
03e668 (+1948): r2 = 0x1
03e670 (+1950): r3 = 0x1
03e678 (+1958): r4 = 0x1
03e680 (+1960): r5 = 0x1
03e688 (+1968): r0 = 0x1
03e690 (+1970): r6 = 0x1
03e698 (+1978): r7 = *(u32 *)(r10 - 0x828)
03e6a0 (+1980): r8 = r7
03e6a8 (+1988): r8 += -0x34
03e6b0 (+1990): r9 = 0x2
03e6b8 (+1998): if r9 > r8 goto -0x311 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e6c0 (+19a0): if r7 == 0x29 goto -0x312 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e6c8 (+19a8): if r7 == 0x2a goto +0x1e <.text+0x3e6a0> ; branch 0x3e7c0 / relative 0x1aa0
03e6d0 (+19b0): if r7 == 0x2b goto +0xb <.text+0x3e610> ; branch 0x3e730 / relative 0x1a10
03e6d8 (+19b8): if r7 == 0x2c goto +0x21 <.text+0x3e6c8> ; branch 0x3e7e8 / relative 0x1ac8
03e6e0 (+19c0): if r7 == 0x2d goto -0x316 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e6e8 (+19c8): if r7 == 0x2e goto +0x15 <.text+0x3e678> ; branch 0x3e798 / relative 0x1a78
03e6f0 (+19d0): if r7 == 0x2f goto +0x9 <.text+0x3e620> ; branch 0x3e740 / relative 0x1a20
03e6f8 (+19d8): if r7 == 0x31 goto +0xa <.text+0x3e630> ; branch 0x3e750 / relative 0x1a30
03e700 (+19e0): if r7 == 0x32 goto +0xe <.text+0x3e658> ; branch 0x3e778 / relative 0x1a58
03e708 (+19e8): if r7 == 0x37 goto -0x31b <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e710 (+19f0): r1 = r10
03e718 (+19f8): r1 += -0x828
03e720 (+1a00): call -0x76a2 ; call 0x3218 / window 66
03e728 (+1a08): goto -0x31f <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e730 (+1a10): if r0 != 0x0 goto +0x5 <.text+0x3e640> ; branch 0x3e760 / relative 0x1a40
03e738 (+1a18): goto -0x321 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e740 (+1a20): if r3 != 0x0 goto +0xc <.text+0x3e688> ; branch 0x3e7a8 / relative 0x1a88
03e748 (+1a28): goto -0x323 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e750 (+1a30): if r2 != 0x0 goto +0x1 <.text+0x3e640> ; branch 0x3e760 / relative 0x1a40
03e758 (+1a38): goto -0x325 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e760 (+1a40): r1 = r10
03e768 (+1a48): r1 += -0x810
03e770 (+1a50): goto +0x7 <.text+0x3e690> ; branch 0x3e7b0 / relative 0x1a90
03e778 (+1a58): if r1 == 0x0 goto -0x329 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e780 (+1a60): r1 = *(u64 *)(r10 - 0x940)
03e788 (+1a68): call -0x7680 ; call 0x3390 / window 68
03e790 (+1a70): goto -0x32c <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e798 (+1a78): if r4 != 0x0 goto +0x1 <.text+0x3e688> ; branch 0x3e7a8 / relative 0x1a88
03e7a0 (+1a80): goto -0x32e <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e7a8 (+1a88): r1 = *(u64 *)(r10 - 0x948)
03e7b0 (+1a90): call -0x75f2 ; call 0x3828 / window 85
03e7b8 (+1a98): goto -0x331 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e7c0 (+1aa0): if r6 != 0x0 goto +0x1 <.text+0x3e6b0> ; branch 0x3e7d0 / relative 0x1ab0
03e7c8 (+1aa8): goto -0x333 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e7d0 (+1ab0): r1 = *(u64 *)(r10 - 0x948)
03e7d8 (+1ab8): call -0x76e8 ; call 0x30a0 / window 59
03e7e0 (+1ac0): goto -0x336 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e7e8 (+1ac8): if r5 != 0x0 goto +0x1 <.text+0x3e6d8> ; branch 0x3e7f8 / relative 0x1ad8
03e7f0 (+1ad0): goto -0x338 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e7f8 (+1ad8): r1 = *(u64 *)(r10 - 0x940)
03e800 (+1ae0): call -0x7677 ; call 0x3450 / window 69
03e808 (+1ae8): goto -0x33b <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
03e810 (+1af0): r1 = r10
03e818 (+1af8): r1 += -0x6c8
03e820 (+1b00): r2 = r10
03e828 (+1b08): r2 += -0x828
03e830 (+1b10): r3 = 0x160
03e838 (+1b18): call 0xb4f2 ; call 0x98fd0 / window 1246
03e840 (+1b20): r1 = *(u32 *)(r10 - 0x6c8)
03e848 (+1b28): if r1 == 0x0 goto +0x3f <.text+0x3e928> ; branch 0x3ea48 / relative 0x1d28
03e850 (+1b30): if r1 == 0x1 goto +0x3e <.text+0x3e928> ; branch 0x3ea48 / relative 0x1d28
03e858 (+1b38): if r1 == 0x2 goto +0x3d <.text+0x3e928> ; branch 0x3ea48 / relative 0x1d28
03e860 (+1b40): r9 = *(u64 *)(r10 - 0x930)
03e868 (+1b48): if r1 == 0x3 goto +0x28 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e870 (+1b50): if r1 == 0x4 goto +0xa6 <.text+0x3ec88> ; branch 0x3eda8 / relative 0x2088
03e878 (+1b58): if r1 == 0x5 goto +0x26 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e880 (+1b60): if r1 == 0x6 goto +0x25 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e888 (+1b68): if r1 == 0x7 goto +0xad <.text+0x3ecd8> ; branch 0x3edf8 / relative 0x20d8
03e890 (+1b70): if r1 == 0x8 goto +0x23 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e898 (+1b78): if r1 == 0x9 goto +0x22 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e8a0 (+1b80): if r1 == 0xa goto +0x21 <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e8a8 (+1b88): if r1 == 0xb goto +0x1d3 <.text+0x3f628> ; branch 0x3f748 / relative 0x2a28
03e8b0 (+1b90): if r1 == 0xc goto +0x1cb <.text+0x3f5f0> ; branch 0x3f710 / relative 0x29f0
03e8b8 (+1b98): if r1 == 0xd goto +0x1e <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e8c0 (+1ba0): if r1 == 0xe goto +0xb0 <.text+0x3ed28> ; branch 0x3ee48 / relative 0x2128
03e8c8 (+1ba8): if r1 == 0xf goto +0x1e5 <.text+0x3f6d8> ; branch 0x3f7f8 / relative 0x2ad8
03e8d0 (+1bb0): if r1 == 0x10 goto +0x1b <.text+0x3e890> ; branch 0x3e9b0 / relative 0x1c90
03e8d8 (+1bb8): if r1 == 0x11 goto +0xdf <.text+0x3eeb8> ; branch 0x3efd8 / relative 0x22b8
03e8e0 (+1bc0): if r1 == 0x12 goto +0x1d8 <.text+0x3f688> ; branch 0x3f7a8 / relative 0x2a88
03e8e8 (+1bc8): if r1 == 0x13 goto +0x1ae <.text+0x3f540> ; branch 0x3f660 / relative 0x2940
03e8f0 (+1bd0): if r1 == 0x14 goto +0x12e <.text+0x3f148> ; branch 0x3f268 / relative 0x2548
03e8f8 (+1bd8): if r1 == 0x15 goto +0x139 <.text+0x3f1a8> ; branch 0x3f2c8 / relative 0x25a8
03e900 (+1be0): if r1 == 0x16 goto +0x1b7 <.text+0x3f5a0> ; branch 0x3f6c0 / relative 0x29a0
03e908 (+1be8): if r1 == 0x17 goto +0x141 <.text+0x3f1f8> ; branch 0x3f318 / relative 0x25f8
03e910 (+1bf0): if r1 == 0x18 goto +0x14a <.text+0x3f248> ; branch 0x3f368 / relative 0x2648
03e918 (+1bf8): if r1 == 0x19 goto +0xaf <.text+0x3ed78> ; branch 0x3ee98 / relative 0x2178
03e920 (+1c00): if r1 == 0x1a goto +0xe1 <.text+0x3ef10> ; branch 0x3f030 / relative 0x2310
03e928 (+1c08): if r1 == 0x1b goto +0xb7 <.text+0x3edc8> ; branch 0x3eee8 / relative 0x21c8
03e930 (+1c10): if r1 == 0x1c goto +0x150 <.text+0x3f298> ; branch 0x3f3b8 / relative 0x2698
03e938 (+1c18): if r1 == 0x1d goto +0xe8 <.text+0x3ef60> ; branch 0x3f080 / relative 0x2360
03e940 (+1c20): if r1 == 0x1e goto +0xbe <.text+0x3ee18> ; branch 0x3ef38 / relative 0x2218
03e948 (+1c28): if r1 == 0x1f goto +0x157 <.text+0x3f2e8> ; branch 0x3f408 / relative 0x26e8
03e950 (+1c30): if r1 == 0x20 goto +0xef <.text+0x3efb0> ; branch 0x3f0d0 / relative 0x23b0
03e958 (+1c38): if r1 == 0x21 goto +0x15f <.text+0x3f338> ; branch 0x3f458 / relative 0x2738
03e960 (+1c40): if r1 == 0x22 goto +0xf7 <.text+0x3f000> ; branch 0x3f120 / relative 0x2400
03e968 (+1c48): if r1 == 0x23 goto +0x188 <.text+0x3f490> ; branch 0x3f5b0 / relative 0x2890
03e970 (+1c50): if r1 == 0x24 goto +0x191 <.text+0x3f4e0> ; branch 0x3f600 / relative 0x28e0
03e978 (+1c58): if r1 == 0x25 goto +0xc1 <.text+0x3ee68> ; branch 0x3ef88 / relative 0x2268
03e980 (+1c60): if r1 == 0x26 goto +0xff <.text+0x3f060> ; branch 0x3f180 / relative 0x2460
03e988 (+1c68): if r1 == 0x27 goto +0x107 <.text+0x3f0a8> ; branch 0x3f1c8 / relative 0x24a8
03e990 (+1c70): if r1 == 0x28 goto +0x10f <.text+0x3f0f0> ; branch 0x3f210 / relative 0x24f0
03e998 (+1c78): r1 = 0x2
03e9a0 (+1c80): *(u32 *)(r9 + 0x0) = r1
03e9a8 (+1c88): goto +0x3ab <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03e9b0 (+1c90): r1 = 0x4b00000000 ll
03e9c0 (+1ca0): *(u64 *)(r9 + 0x0) = r1
03e9c8 (+1ca8): goto +0x3a7 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03e9d0 (+1cb0): r6 = *(u64 *)(r10 - 0x938)
03e9d8 (+1cb8): r8 = r6
03e9e0 (+1cc0): r8 += 0xc0
03e9e8 (+1cc8): r1 = *(u64 *)(r8 + 0x0)
03e9f0 (+1cd0): r2 = 0x999d8 ll ; pointer 0x999d8; data32hex ed03481d8df777ace755769e3a84e6deed48a87f333232b4b73496de27798786
03ea00 (+1ce0): call -0x779f ; call 0x2d10 / window 44
03ea08 (+1ce8): if r0 != 0x0 goto +0x1 <.text+0x3e8f8> ; branch 0x3ea18 / relative 0x1cf8
03ea10 (+1cf0): goto +0x21 <.text+0x3ea00> ; branch 0x3eb20 / relative 0x1e00
03ea18 (+1cf8): r1 = 0xbf00000000 ll
03ea28 (+1d08): goto -0x7c <.text+0x3e530> ; branch 0x3e650 / relative 0x1930
03ea30 (+1d10): r1 = 0xbf00000000 ll
03ea40 (+1d20): goto -0xb4 <.text+0x3e388> ; branch 0x3e4a8 / relative 0x1788
03ea48 (+1d28): r1 = 0x4b00000000 ll
03ea58 (+1d38): r2 = *(u64 *)(r10 - 0x930)
03ea60 (+1d40): *(u64 *)(r2 + 0x0) = r1
03ea68 (+1d48): goto +0x393 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ea70 (+1d50): r1 = *(u32 *)(r10 - 0x551)
03ea78 (+1d58): *(u32 *)(r10 - 0x221) = r1
03ea80 (+1d60): r1 = *(u64 *)(r10 - 0x558)
03ea88 (+1d68): *(u64 *)(r10 - 0x228) = r1
03ea90 (+1d70): r1 = *(u64 *)(r10 - 0x560)
03ea98 (+1d78): *(u64 *)(r10 - 0x230) = r1
03eaa0 (+1d80): r2 = *(u64 *)(r10 - 0x568)
03eaa8 (+1d88): *(u64 *)(r10 - 0x238) = r2
03eab0 (+1d90): r3 = *(u32 *)(r10 - 0x221)
03eab8 (+1d98): r4 = *(u64 *)(r10 - 0x930)
03eac0 (+1da0): *(u32 *)(r4 + 0x1c) = r3
03eac8 (+1da8): r3 = *(u64 *)(r10 - 0x228)
03ead0 (+1db0): *(u64 *)(r4 + 0x15) = r3
03ead8 (+1db8): *(u64 *)(r4 + 0xd) = r1
03eae0 (+1dc0): *(u64 *)(r4 + 0x5) = r2
03eae8 (+1dc8): *(u8 *)(r4 + 0x4) = r9
03eaf0 (+1dd0): *(u32 *)(r4 + 0x0) = r6
03eaf8 (+1dd8): r1 = *(u32 *)(r10 - 0x828)
03eb00 (+1de0): goto -0x307 <.text+0x3d1b0> ; branch 0x3d2d0 / relative 0x5b0
03eb08 (+1de8): r1 = *(u64 *)(r10 - 0x980)
03eb10 (+1df0): call -0x774f ; call 0x30a0 / window 59
03eb18 (+1df8): goto -0x9c <.text+0x3e520> ; branch 0x3e640 / relative 0x1920
03eb20 (+1e00): *(u64 *)(r10 - 0x928) = r8
03eb28 (+1e08): r6 += 0x30
03eb30 (+1e10): r1 = r10
03eb38 (+1e18): r1 += -0x858
03eb40 (+1e20): r2 = 0x999f8 ll ; pointer 0x999f8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03eb50 (+1e30): call 0x8ee5 ; call 0x86280 / window 990
03eb58 (+1e38): r2 = *(u64 *)(r9 + 0x0)
03eb60 (+1e40): r1 = *(u64 *)(r10 - 0x858)
03eb68 (+1e48): *(u64 *)(r10 - 0x920) = r1
03eb70 (+1e50): r8 = *(u64 *)(r10 - 0x850)
03eb78 (+1e58): r1 = r10
03eb80 (+1e60): r1 += -0x868
03eb88 (+1e68): call 0x8ede ; call 0x86280 / window 990
03eb90 (+1e70): r1 = 0x7
03eb98 (+1e78): *(u64 *)(r10 - 0x690) = r1
03eba0 (+1e80): r1 = 0x9a285 ll ; pointer 0x9a285; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
03ebb0 (+1e90): *(u64 *)(r10 - 0x698) = r1
03ebb8 (+1e98): *(u64 *)(r10 - 0x6b0) = r8
03ebc0 (+1ea0): r1 = *(u64 *)(r10 - 0x920)
03ebc8 (+1ea8): *(u64 *)(r10 - 0x6b8) = r1
03ebd0 (+1eb0): r1 = 0x8
03ebd8 (+1eb8): *(u64 *)(r10 - 0x6c0) = r1
03ebe0 (+1ec0): r1 = 0x9a240 ll ; pointer 0x9a240; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
03ebf0 (+1ed0): *(u64 *)(r10 - 0x6c8) = r1
03ebf8 (+1ed8): r1 = *(u64 *)(r10 - 0x860)
03ec00 (+1ee0): *(u64 *)(r10 - 0x6a0) = r1
03ec08 (+1ee8): r1 = *(u64 *)(r10 - 0x868)
03ec10 (+1ef0): *(u64 *)(r10 - 0x6a8) = r1
03ec18 (+1ef8): r1 = r10
03ec20 (+1f00): r1 += -0x438
03ec28 (+1f08): r2 = r10
03ec30 (+1f10): r2 += -0x6c8
03ec38 (+1f18): call -0x681b ; call 0xab68 / window 226
03ec40 (+1f20): r4 = *(u64 *)(r10 - 0x430)
03ec48 (+1f28): r5 = *(u64 *)(r10 - 0x428)
03ec50 (+1f30): r1 = r10
03ec58 (+1f38): r1 += -0x6c8
03ec60 (+1f40): r2 = 0x999f8 ll ; pointer 0x999f8; data32hex 0b7065b1e3d17c45389d527f6b04c3cd58b86c731aa0fdb549b6d1bc03f82946
03ec70 (+1f50): *(u64 *)(r10 - 0x920) = r6
03ec78 (+1f58): r3 = r6
03ec80 (+1f60): call -0x5e17 ; call 0xfbd0 / window 273
03ec88 (+1f68): r1 = *(u32 *)(r10 - 0x6c8)
03ec90 (+1f70): if r1 == 0x16 goto +0x1 <.text+0x3eb80> ; branch 0x3eca0 / relative 0x1f80
03ec98 (+1f78): goto +0x14 <.text+0x3ec20> ; branch 0x3ed40 / relative 0x2020
03eca0 (+1f80): r1 = r10
03eca8 (+1f88): r1 += -0x6c8
03ecb0 (+1f90): r2 = *(u64 *)(r10 - 0x938)
03ecb8 (+1f98): call 0x1267 ; call 0x47ff8 / window 419
03ecc0 (+1fa0): r6 = *(u32 *)(r10 - 0x5c0)
03ecc8 (+1fa8): if r6 != 0x2 goto +0x197 <.text+0x3f868> ; branch 0x3f988 / relative 0x2c68
03ecd0 (+1fb0): r1 = *(u64 *)(r10 - 0x6b0)
03ecd8 (+1fb8): *(u64 *)(r10 - 0x350) = r1
03ece0 (+1fc0): r2 = *(u64 *)(r10 - 0x6b8)
03ece8 (+1fc8): *(u64 *)(r10 - 0x358) = r2
03ecf0 (+1fd0): r3 = *(u64 *)(r10 - 0x6c0)
03ecf8 (+1fd8): *(u64 *)(r10 - 0x360) = r3
03ed00 (+1fe0): r4 = *(u64 *)(r10 - 0x6c8)
03ed08 (+1fe8): *(u64 *)(r10 - 0x368) = r4
03ed10 (+1ff0): r5 = *(u64 *)(r10 - 0x930)
03ed18 (+1ff8): *(u64 *)(r5 + 0x18) = r1
03ed20 (+2000): *(u64 *)(r5 + 0x10) = r2
03ed28 (+2008): *(u64 *)(r5 + 0x8) = r3
03ed30 (+2010): *(u64 *)(r5 + 0x0) = r4
03ed38 (+2018): goto +0x1ac <.text+0x3f980> ; branch 0x3faa0 / relative 0x2d80
03ed40 (+2020): r2 = *(u8 *)(r10 - 0x6c4)
03ed48 (+2028): r3 = *(u32 *)(r10 - 0x6ac)
03ed50 (+2030): r4 = *(u64 *)(r10 - 0x930)
03ed58 (+2038): *(u32 *)(r4 + 0x1c) = r3
03ed60 (+2040): r3 = *(u64 *)(r10 - 0x6b3)
03ed68 (+2048): *(u64 *)(r4 + 0x15) = r3
03ed70 (+2050): r3 = *(u64 *)(r10 - 0x6bb)
03ed78 (+2058): *(u64 *)(r4 + 0xd) = r3
03ed80 (+2060): r3 = *(u64 *)(r10 - 0x6c3)
03ed88 (+2068): *(u64 *)(r4 + 0x5) = r3
03ed90 (+2070): *(u8 *)(r4 + 0x4) = r2
03ed98 (+2078): *(u32 *)(r4 + 0x0) = r1
03eda0 (+2080): goto +0x19f <.text+0x3f980> ; branch 0x3faa0 / relative 0x2d80
03eda8 (+2088): r1 = 0x9ad5b ll ; pointer 0x9ad5b; data32hex 49583a20557064617465207072696d6172792073616c652076696120746f6b65
03edb8 (+2098): r2 = 0x21
03edc0 (+20a0): call -0x1 ; external sol_log_
03edc8 (+20a8): r1 = r9
03edd0 (+20b0): r2 = *(u64 *)(r10 - 0x928)
03edd8 (+20b8): r3 = *(u64 *)(r10 - 0x938)
03ede0 (+20c0): r4 = *(u64 *)(r10 - 0x920)
03ede8 (+20c8): call -0x1436 ; call 0x34c40 / window 339
03edf0 (+20d0): goto +0x322 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03edf8 (+20d8): r1 = 0x9ad4a ll ; pointer 0x9ad4a; data32hex 49583a205369676e204d6574616461746149583a20557064617465207072696d
03ee08 (+20e8): r2 = 0x11
03ee10 (+20f0): call -0x1 ; external sol_log_
03ee18 (+20f8): r1 = r9
03ee20 (+2100): r2 = *(u64 *)(r10 - 0x928)
03ee28 (+2108): r3 = *(u64 *)(r10 - 0x938)
03ee30 (+2110): r4 = *(u64 *)(r10 - 0x920)
03ee38 (+2118): call -0x1fce ; call 0x2efd0 / window 332
03ee40 (+2120): goto +0x318 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ee48 (+2128): r1 = 0x9ace4 ll ; pointer 0x9ace4; data32hex 49583a2050756666204d6574616461746149583a20436f6e76657274204d6173
03ee58 (+2138): r2 = 0x11
03ee60 (+2140): call -0x1 ; external sol_log_
03ee68 (+2148): r1 = r9
03ee70 (+2150): r2 = *(u64 *)(r10 - 0x928)
03ee78 (+2158): r3 = *(u64 *)(r10 - 0x938)
03ee80 (+2160): r4 = *(u64 *)(r10 - 0x920)
03ee88 (+2168): call -0x2220 ; call 0x2dd90 / window 329
03ee90 (+2170): goto +0x30e <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ee98 (+2178): r1 = 0x9ab69 ll ; pointer 0x9ab69; data32hex 49583a2053657420616e642056657269667920436f6c6c656374696f6e49583a
03eea8 (+2188): r2 = 0x1d
03eeb0 (+2190): call -0x1 ; external sol_log_
03eeb8 (+2198): r1 = r9
03eec0 (+21a0): r2 = *(u64 *)(r10 - 0x928)
03eec8 (+21a8): r3 = *(u64 *)(r10 - 0x938)
03eed0 (+21b0): r4 = *(u64 *)(r10 - 0x920)
03eed8 (+21b8): call -0x4c24 ; call 0x18dc0 / window 303
03eee0 (+21c0): goto +0x304 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03eee8 (+21c8): r1 = 0x9abe6 ll ; pointer 0x9abe6; data32hex 49583a20546861772044656c656761746564204163636f756e7449583a204672
03eef8 (+21d8): r2 = 0x1a
03ef00 (+21e0): call -0x1 ; external sol_log_
03ef08 (+21e8): r1 = r9
03ef10 (+21f0): r2 = *(u64 *)(r10 - 0x928)
03ef18 (+21f8): r3 = *(u64 *)(r10 - 0x938)
03ef20 (+2200): r4 = *(u64 *)(r10 - 0x920)
03ef28 (+2208): call -0x2dc2 ; call 0x28120 / window 320
03ef30 (+2210): goto +0x2fa <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ef38 (+2218): r1 = 0x9aba3 ll ; pointer 0x9aba3; data32hex 49583a2056657269667920436f6c6c656374696f6e20563249583a204275726e
03ef48 (+2228): r2 = 0x18
03ef50 (+2230): call -0x1 ; external sol_log_
03ef58 (+2238): r1 = r9
03ef60 (+2240): r2 = *(u64 *)(r10 - 0x928)
03ef68 (+2248): r3 = *(u64 *)(r10 - 0x938)
03ef70 (+2250): r4 = *(u64 *)(r10 - 0x920)
03ef78 (+2258): call -0x4524 ; call 0x1c660 / window 309
03ef80 (+2260): goto +0x2f0 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ef88 (+2268): r1 = 0x9aae0 ll ; pointer 0x9aae0; data32hex 49583a204275726e2045646974696f6e204e465449583a20427562626c656775
03ef98 (+2278): r2 = 0x14
03efa0 (+2280): call -0x1 ; external sol_log_
03efa8 (+2288): r1 = r9
03efb0 (+2290): r2 = *(u64 *)(r10 - 0x928)
03efb8 (+2298): r3 = *(u64 *)(r10 - 0x938)
03efc0 (+22a0): r4 = *(u64 *)(r10 - 0x920)
03efc8 (+22a8): call -0x56ee ; call 0x13860 / window 297
03efd0 (+22b0): goto +0x2e6 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03efd8 (+22b8): r1 = *(u64 *)(r10 - 0x6b8)
03efe0 (+22c0): *(u64 *)(r10 - 0x948) = r1
03efe8 (+22c8): r1 = *(u64 *)(r10 - 0x6c0)
03eff0 (+22d0): *(u64 *)(r10 - 0x940) = r1
03eff8 (+22d8): r1 = 0x9acad ll ; pointer 0x9acad; data32hex 563320437265617465204d61737465722045646974696f6e49583a2055706461
03f008 (+22e8): r2 = 0x18
03f010 (+22f0): call -0x1 ; external sol_log_
03f018 (+22f8): r1 = *(u64 *)(r10 - 0x920)
03f020 (+2300): if r1 > 0x7 goto +0x155 <.text+0x3f9b0> ; branch 0x3fad0 / relative 0x2db0
03f028 (+2308): goto +0xeb <.text+0x3f668> ; branch 0x3f788 / relative 0x2a68
03f030 (+2310): r1 = 0x9ac00 ll ; pointer 0x9ac00; data32hex 49583a20467265657a652044656c656761746564204163636f756e7449583a20
03f040 (+2320): r2 = 0x1c
03f048 (+2328): call -0x1 ; external sol_log_
03f050 (+2330): r1 = r9
03f058 (+2338): r2 = *(u64 *)(r10 - 0x928)
03f060 (+2340): r3 = *(u64 *)(r10 - 0x938)
03f068 (+2348): r4 = *(u64 *)(r10 - 0x920)
03f070 (+2350): call -0x2f25 ; call 0x27750 / window 319
03f078 (+2358): goto +0x2d1 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f080 (+2360): r1 = 0x9abbb ll ; pointer 0x9abbb; data32hex 49583a204275726e204e465449583a2052656d6f76652043726561746f722056
03f090 (+2370): r2 = 0xc
03f098 (+2378): call -0x1 ; external sol_log_
03f0a0 (+2380): r1 = r9
03f0a8 (+2388): r2 = *(u64 *)(r10 - 0x928)
03f0b0 (+2390): r3 = *(u64 *)(r10 - 0x938)
03f0b8 (+2398): r4 = *(u64 *)(r10 - 0x920)
03f0c0 (+23a0): call -0x560d ; call 0x14060 / window 298
03f0c8 (+23a8): goto +0x2c7 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f0d0 (+23b0): r1 = 0x9ab69 ll ; pointer 0x9ab69; data32hex 49583a2053657420616e642056657269667920436f6c6c656374696f6e49583a
03f0e0 (+23c0): r2 = 0x1d
03f0e8 (+23c8): call -0x1 ; external sol_log_
03f0f0 (+23d0): r1 = r9
03f0f8 (+23d8): r2 = *(u64 *)(r10 - 0x928)
03f100 (+23e0): r3 = *(u64 *)(r10 - 0x938)
03f108 (+23e8): r4 = *(u64 *)(r10 - 0x920)
03f110 (+23f0): call -0x4b1f ; call 0x19820 / window 304
03f118 (+23f8): goto +0x2bd <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f120 (+2400): r6 = *(u64 *)(r10 - 0x6c0)
03f128 (+2408): r1 = 0x9ab33 ll ; pointer 0x9ab33; data32hex 49583a2053657420436f6c6c656374696f6e2053697a6549583a204372656174
03f138 (+2418): r2 = 0x17
03f140 (+2420): call -0x1 ; external sol_log_
03f148 (+2428): r1 = r9
03f150 (+2430): r2 = *(u64 *)(r10 - 0x928)
03f158 (+2438): r3 = *(u64 *)(r10 - 0x938)
03f160 (+2440): r4 = *(u64 *)(r10 - 0x920)
03f168 (+2448): r5 = r6
03f170 (+2450): call -0x49e8 ; call 0x1a238 / window 305
03f178 (+2458): goto +0x2b1 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f180 (+2460): r1 = 0x9aac7 ll ; pointer 0x9aac7; data32hex 49583a2043726561746520457363726f77204163636f756e7449583a20427572
03f190 (+2470): r2 = 0x19
03f198 (+2478): call -0x1 ; external sol_log_
03f1a0 (+2480): r1 = r9
03f1a8 (+2488): r3 = *(u64 *)(r10 - 0x938)
03f1b0 (+2490): r4 = *(u64 *)(r10 - 0x920)
03f1b8 (+2498): call -0x3691 ; call 0x23d38 / window 316
03f1c0 (+24a0): goto +0x2a8 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f1c8 (+24a8): r1 = 0x9aaaf ll ; pointer 0x9aaaf; data32hex 49583a20436c6f736520457363726f77204163636f756e7449583a2043726561
03f1d8 (+24b8): r2 = 0x18
03f1e0 (+24c0): call -0x1 ; external sol_log_
03f1e8 (+24c8): r1 = r9
03f1f0 (+24d0): r3 = *(u64 *)(r10 - 0x938)
03f1f8 (+24d8): r4 = *(u64 *)(r10 - 0x920)
03f200 (+24e0): call -0x3858 ; call 0x22f48 / window 315
03f208 (+24e8): goto +0x29f <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f210 (+24f0): r6 = *(u64 *)(r10 - 0x6c0)
03f218 (+24f8): r1 = 0x9aa95 ll ; pointer 0x9aa95; data32hex 49583a205472616e73666572204f7574204f6620457363726f7749583a20436c
03f228 (+2508): r2 = 0x1a
03f230 (+2510): call -0x1 ; external sol_log_
03f238 (+2518): r1 = r9
03f240 (+2520): r3 = *(u64 *)(r10 - 0x938)
03f248 (+2528): r4 = *(u64 *)(r10 - 0x920)
03f250 (+2530): r5 = r6
03f258 (+2538): call -0x33e9 ; call 0x25318 / window 318
03f260 (+2540): goto +0x294 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f268 (+2548): r6 = *(u64 *)(r10 - 0x6c0)
03f270 (+2550): r1 = 0x9ac6a ll ; pointer 0x9ac6a; data32hex 49583a20417070726f76652055736520417574686f7269747949583a20557365
03f280 (+2560): r2 = 0x19
03f288 (+2568): call -0x1 ; external sol_log_
03f290 (+2570): r1 = r9
03f298 (+2578): r2 = *(u64 *)(r10 - 0x928)
03f2a0 (+2580): r3 = *(u64 *)(r10 - 0x938)
03f2a8 (+2588): r4 = *(u64 *)(r10 - 0x920)
03f2b0 (+2590): r5 = r6
03f2b8 (+2598): call -0xe10 ; call 0x38240 / window 344
03f2c0 (+25a0): goto +0x288 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f2c8 (+25a8): r1 = 0x9ac52 ll ; pointer 0x9ac52; data32hex 49583a205265766f6b652055736520417574686f7269747949583a2041707072
03f2d8 (+25b8): r2 = 0x18
03f2e0 (+25c0): call -0x1 ; external sol_log_
03f2e8 (+25c8): r1 = r9
03f2f0 (+25d0): r2 = *(u64 *)(r10 - 0x928)
03f2f8 (+25d8): r3 = *(u64 *)(r10 - 0x938)
03f300 (+25e0): r4 = *(u64 *)(r10 - 0x920)
03f308 (+25e8): call -0xc41 ; call 0x39108 / window 345
03f310 (+25f0): goto +0x27e <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f318 (+25f8): r1 = 0x99b38 ll ; pointer 0x99b38; data32hex 49583a20417070726f766520436f6c6c656374696f6e20417574686f72697479
03f328 (+2608): r2 = 0x20
03f330 (+2610): call -0x1 ; external sol_log_
03f338 (+2618): r1 = r9
03f340 (+2620): r2 = *(u64 *)(r10 - 0x928)
03f348 (+2628): r3 = *(u64 *)(r10 - 0x938)
03f350 (+2630): r4 = *(u64 *)(r10 - 0x920)
03f358 (+2638): call -0x4ee0 ; call 0x17c60 / window 301
03f360 (+2640): goto +0x274 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f368 (+2648): r1 = 0x9ac1c ll ; pointer 0x9ac1c; data32hex 49583a205265766f6b6520436f6c6c656374696f6e20417574686f7269747949
03f378 (+2658): r2 = 0x1f
03f380 (+2660): call -0x1 ; external sol_log_
03f388 (+2668): r1 = r9
03f390 (+2670): r2 = *(u64 *)(r10 - 0x928)
03f398 (+2678): r3 = *(u64 *)(r10 - 0x938)
03f3a0 (+2680): r4 = *(u64 *)(r10 - 0x920)
03f3a8 (+2688): call -0x4d70 ; call 0x18830 / window 302
03f3b0 (+2690): goto +0x26a <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f3b8 (+2698): r1 = 0x9abc7 ll ; pointer 0x9abc7; data32hex 49583a2052656d6f76652043726561746f7220566572696669636174696f6e49
03f3c8 (+26a8): r2 = 0x1f
03f3d0 (+26b0): call -0x1 ; external sol_log_
03f3d8 (+26b8): r1 = r9
03f3e0 (+26c0): r2 = *(u64 *)(r10 - 0x928)
03f3e8 (+26c8): r3 = *(u64 *)(r10 - 0x938)
03f3f0 (+26d0): r4 = *(u64 *)(r10 - 0x920)
03f3f8 (+26d8): call -0x2239 ; call 0x2e238 / window 330
03f400 (+26e0): goto +0x260 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f408 (+26e8): r1 = 0x9ab86 ll ; pointer 0x9ab86; data32hex 49583a20556e7665726966792053697a656420436f6c6c656374696f6e49583a
03f418 (+26f8): r2 = 0x1d
03f420 (+2700): call -0x1 ; external sol_log_
03f428 (+2708): r1 = r9
03f430 (+2710): r2 = *(u64 *)(r10 - 0x928)
03f438 (+2718): r3 = *(u64 *)(r10 - 0x938)
03f440 (+2720): r4 = *(u64 *)(r10 - 0x920)
03f448 (+2728): call -0x4841 ; call 0x1b248 / window 307
03f450 (+2730): goto +0x256 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f458 (+2738): r6 = r10
03f460 (+2740): r6 += -0x368
03f468 (+2748): r2 = r10
03f470 (+2750): r2 += -0x6c0
03f478 (+2758): r1 = r6
03f480 (+2760): r3 = 0xa8
03f488 (+2768): call 0xb368 ; call 0x98fd0 / window 1246
03f490 (+2770): r1 = *(u64 *)(r10 - 0x617)
03f498 (+2778): *(u64 *)(r10 - 0x568) = r1
03f4a0 (+2780): r1 = *(u64 *)(r10 - 0x60f)
03f4a8 (+2788): *(u64 *)(r10 - 0x560) = r1
03f4b0 (+2790): r1 = *(u64 *)(r10 - 0x608)
03f4b8 (+2798): *(u64 *)(r10 - 0x559) = r1
03f4c0 (+27a0): r8 = *(u8 *)(r10 - 0x618)
03f4c8 (+27a8): r1 = 0x9ab4a ll ; pointer 0x9ab4a; data32hex 49583a20437265617465204d65746164617461204163636f756e747320763349
03f4d8 (+27b8): r2 = 0x1f
03f4e0 (+27c0): call -0x1 ; external sol_log_
03f4e8 (+27c8): r7 = r10
03f4f0 (+27d0): r7 += -0x130
03f4f8 (+27d8): r1 = r7
03f500 (+27e0): r2 = r6
03f508 (+27e8): r3 = 0xa8
03f510 (+27f0): call 0xb357 ; call 0x98fd0 / window 1246
03f518 (+27f8): r1 = *(u64 *)(r10 - 0x559)
03f520 (+2800): *(u64 *)(r10 - 0x230) = r1
03f528 (+2808): r1 = *(u64 *)(r10 - 0x561)
03f530 (+2810): *(u64 *)(r10 - 0x238) = r1
03f538 (+2818): r8 &= 0x1
03f540 (+2820): *(u64 *)(r10 - 0xff8) = r8
03f548 (+2828): r1 = r10
03f550 (+2830): r1 += -0x238
03f558 (+2838): *(u64 *)(r10 - 0xff0) = r1
03f560 (+2840): *(u64 *)(r10 - 0x1000) = r7
03f568 (+2848): r5 = r10
03f570 (+2850): r1 = r9
03f578 (+2858): r2 = *(u64 *)(r10 - 0x928)
03f580 (+2860): r3 = *(u64 *)(r10 - 0x938)
03f588 (+2868): r4 = *(u64 *)(r10 - 0x920)
03f590 (+2870): call -0x2b9f ; call 0x298a0 / window 322
03f598 (+2878): r2 = 0x0
03f5a0 (+2880): r1 = 0x1
03f5a8 (+2888): goto +0x22d <.text+0x405f8> ; branch 0x40718 / relative 0x39f8
03f5b0 (+2890): r1 = 0x9ab1d ll ; pointer 0x9ab1d; data32hex 49583a2053657420546f6b656e205374616e6461726449583a2053657420436f
03f5c0 (+28a0): r2 = 0x16
03f5c8 (+28a8): call -0x1 ; external sol_log_
03f5d0 (+28b0): r1 = r9
03f5d8 (+28b8): r2 = *(u64 *)(r10 - 0x928)
03f5e0 (+28c0): r3 = *(u64 *)(r10 - 0x938)
03f5e8 (+28c8): r4 = *(u64 *)(r10 - 0x920)
03f5f0 (+28d0): call -0x21f1 ; call 0x2e670 / window 331
03f5f8 (+28d8): goto +0x221 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f600 (+28e0): r6 = *(u64 *)(r10 - 0x6c0)
03f608 (+28e8): r1 = 0x9aaf4 ll ; pointer 0x9aaf4; data32hex 49583a20427562626c6567756d2050726f6772616d2053657420436f6c6c6563
03f618 (+28f8): r2 = 0x29
03f620 (+2900): call -0x1 ; external sol_log_
03f628 (+2908): r1 = r9
03f630 (+2910): r2 = *(u64 *)(r10 - 0x928)
03f638 (+2918): r3 = *(u64 *)(r10 - 0x938)
03f640 (+2920): r4 = *(u64 *)(r10 - 0x920)
03f648 (+2928): r5 = r6
03f650 (+2930): call -0x5c64 ; call 0x11338 / window 295
03f658 (+2938): goto +0x215 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f660 (+2940): r6 = *(u64 *)(r10 - 0x6c0)
03f668 (+2948): r1 = 0x9ac83 ll ; pointer 0x9ac83; data32hex 49583a205573652f5574696c697a6520546f6b656e49583a2056657269667920
03f678 (+2958): r2 = 0x15
03f680 (+2960): call -0x1 ; external sol_log_
03f688 (+2968): r1 = r9
03f690 (+2970): r2 = *(u64 *)(r10 - 0x928)
03f698 (+2978): r3 = *(u64 *)(r10 - 0x938)
03f6a0 (+2980): r4 = *(u64 *)(r10 - 0x920)
03f6a8 (+2988): r5 = r6
03f6b0 (+2990): call -0xb4b ; call 0x39c60 / window 346
03f6b8 (+2998): goto +0x209 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f6c0 (+29a0): r1 = 0x9ac3b ll ; pointer 0x9ac3b; data32hex 49583a20556e76657269667920436f6c6c656374696f6e49583a205265766f6b
03f6d0 (+29b0): r2 = 0x17
03f6d8 (+29b8): call -0x1 ; external sol_log_
03f6e0 (+29c0): r1 = r9
03f6e8 (+29c8): r2 = *(u64 *)(r10 - 0x928)
03f6f0 (+29d0): r3 = *(u64 *)(r10 - 0x938)
03f6f8 (+29d8): r4 = *(u64 *)(r10 - 0x920)
03f700 (+29e0): call -0x49ee ; call 0x1a798 / window 306
03f708 (+29e8): goto +0x1ff <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f710 (+29f0): r1 = 0x9acf5 ll ; pointer 0x9acf5; data32hex 49583a20436f6e76657274204d61737465722045646974696f6e20563120746f
03f720 (+2a00): r2 = 0x23
03f728 (+2a08): call -0x1 ; external sol_log_
03f730 (+2a10): r1 = *(u64 *)(r10 - 0x920)
03f738 (+2a18): if r1 > 0x2 goto +0xd5 <.text+0x3fcc8> ; branch 0x3fde8 / relative 0x30c8
03f740 (+2a20): goto +0x8 <.text+0x3f668> ; branch 0x3f788 / relative 0x2a68
03f748 (+2a28): r1 = *(u64 *)(r10 - 0x6c0)
03f750 (+2a30): *(u64 *)(r10 - 0x940) = r1
03f758 (+2a38): r1 = 0x9ad18 ll ; pointer 0x9ad18; data32hex 49583a204d696e74204e65772045646974696f6e2066726f6d204d6173746572
03f768 (+2a48): r2 = 0x32
03f770 (+2a50): call -0x1 ; external sol_log_
03f778 (+2a58): r1 = *(u64 *)(r10 - 0x920)
03f780 (+2a60): if r1 > 0xc goto +0x7f <.text+0x3fa60> ; branch 0x3fb80 / relative 0x2e60
03f788 (+2a68): r1 = 0xa
03f790 (+2a70): r2 = *(u64 *)(r10 - 0x930)
03f798 (+2a78): *(u32 *)(r2 + 0x0) = r1
03f7a0 (+2a80): goto +0x1ec <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f7a8 (+2a88): r1 = 0x9ac98 ll ; pointer 0x9ac98; data32hex 49583a2056657269667920436f6c6c656374696f6e563320437265617465204d
03f7b8 (+2a98): r2 = 0x15
03f7c0 (+2aa0): call -0x1 ; external sol_log_
03f7c8 (+2aa8): r1 = r9
03f7d0 (+2ab0): r2 = *(u64 *)(r10 - 0x928)
03f7d8 (+2ab8): r3 = *(u64 *)(r10 - 0x938)
03f7e0 (+2ac0): r4 = *(u64 *)(r10 - 0x920)
03f7e8 (+2ac8): call -0x474e ; call 0x1bd80 / window 308
03f7f0 (+2ad0): goto +0x1e2 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03f7f8 (+2ad8): r6 = r10
03f800 (+2ae0): r6 += -0x130
03f808 (+2ae8): r2 = r10
03f810 (+2af0): r2 += -0x6c0
03f818 (+2af8): r1 = r6
03f820 (+2b00): r3 = 0xc9
03f828 (+2b08): call 0xb2f4 ; call 0x98fd0 / window 1246
03f830 (+2b10): r8 = *(u8 *)(r10 - 0x5f6)
03f838 (+2b18): r9 = *(u8 *)(r10 - 0x5f7)
03f840 (+2b20): r1 = 0x9acc5 ll ; pointer 0x9acc5; data32hex 49583a20557064617465204d65746164617461204163636f756e747320763249
03f850 (+2b30): r2 = 0x1f
03f858 (+2b38): call -0x1 ; external sol_log_
03f860 (+2b40): r7 = r10
03f868 (+2b48): r7 += -0x368
03f870 (+2b50): r1 = r7
03f878 (+2b58): r2 = r6
03f880 (+2b60): r3 = 0xa8
03f888 (+2b68): call 0xb2e8 ; call 0x98fd0 / window 1246
03f890 (+2b70): r6 = r10
03f898 (+2b78): r6 += -0x568
03f8a0 (+2b80): r2 = r10
03f8a8 (+2b88): r2 += -0x88
03f8b0 (+2b90): r1 = r6
03f8b8 (+2b98): r3 = 0x21
03f8c0 (+2ba0): call 0xb2e1 ; call 0x98fd0 / window 1246
03f8c8 (+2ba8): *(u64 *)(r10 - 0xff0) = r9
03f8d0 (+2bb0): *(u64 *)(r10 - 0xfe8) = r8
03f8d8 (+2bb8): *(u64 *)(r10 - 0xff8) = r6
03f8e0 (+2bc0): *(u64 *)(r10 - 0x1000) = r7
03f8e8 (+2bc8): r5 = r10
03f8f0 (+2bd0): r1 = *(u64 *)(r10 - 0x930)
03f8f8 (+2bd8): r2 = *(u64 *)(r10 - 0x928)
03f900 (+2be0): r3 = *(u64 *)(r10 - 0x938)
03f908 (+2be8): r4 = *(u64 *)(r10 - 0x920)
03f910 (+2bf0): call -0x16e4 ; call 0x341f8 / window 338
03f918 (+2bf8): r2 = 0x1
03f920 (+2c00): r1 = 0x0
03f928 (+2c08): goto +0x1bd <.text+0x405f8> ; branch 0x40718 / relative 0x39f8
03f930 (+2c10): r3 = *(u64 *)(r10 - 0x6b0)
03f938 (+2c18): r2 = *(u64 *)(r10 - 0x6b8)
03f940 (+2c20): r1 = *(u64 *)(r10 - 0x6c0)
03f948 (+2c28): r8 = *(u32 *)(r10 - 0x6c4)
03f950 (+2c30): r4 = *(u64 *)(r10 - 0x930)
03f958 (+2c38): *(u64 *)(r4 + 0x18) = r3
03f960 (+2c40): *(u64 *)(r4 + 0x10) = r2
03f968 (+2c48): *(u64 *)(r4 + 0x8) = r1
03f970 (+2c50): *(u32 *)(r4 + 0x4) = r8
03f978 (+2c58): *(u32 *)(r4 + 0x0) = r9
03f980 (+2c60): goto -0x265 <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03f988 (+2c68): r8 = r10
03f990 (+2c70): r8 += -0x368
03f998 (+2c78): r2 = r10
03f9a0 (+2c80): r2 += -0x6c8
03f9a8 (+2c88): r1 = r8
03f9b0 (+2c90): r3 = 0x108
03f9b8 (+2c98): call 0xb2c2 ; call 0x98fd0 / window 1246
03f9c0 (+2ca0): r1 = r10
03f9c8 (+2ca8): r1 += -0x24
03f9d0 (+2cb0): r2 = r10
03f9d8 (+2cb8): r2 += -0x5bc
03f9e0 (+2cc0): r3 = 0x24
03f9e8 (+2cc8): call 0xb2bc ; call 0x98fd0 / window 1246
03f9f0 (+2cd0): r1 = r10
03f9f8 (+2cd8): r1 += -0x130
03fa00 (+2ce0): r2 = r8
03fa08 (+2ce8): r3 = 0x108
03fa10 (+2cf0): call 0xb2b7 ; call 0x98fd0 / window 1246
03fa18 (+2cf8): *(u32 *)(r10 - 0x28) = r6
03fa20 (+2d00): r1 = r10
03fa28 (+2d08): r1 += -0x10c
03fa30 (+2d10): *(u64 *)(r10 - 0x6c8) = r1
03fa38 (+2d18): r1 = r10
03fa40 (+2d20): r1 += -0x6c8
03fa48 (+2d28): r2 = r9
03fa50 (+2d30): call -0x79b0 ; call 0x2cd8 / window 42
03fa58 (+2d38): if r0 != 0x0 goto +0x1 <.text+0x3f948> ; branch 0x3fa68 / relative 0x2d48
03fa60 (+2d40): goto +0xa7 <.text+0x3fe80> ; branch 0x3ffa0 / relative 0x3280
03fa68 (+2d48): r1 = 0xf00000000 ll
03fa78 (+2d58): r2 = *(u64 *)(r10 - 0x930)
03fa80 (+2d60): *(u64 *)(r2 + 0x0) = r1
03fa88 (+2d68): r1 = r10
03fa90 (+2d70): r1 += -0xe8
03fa98 (+2d78): call -0x7940 ; call 0x30a0 / window 59
03faa0 (+2d80): r1 = r10
03faa8 (+2d88): r1 += -0x438
03fab0 (+2d90): call -0x7937 ; call 0x3100 / window 60
03fab8 (+2d98): goto -0x28c <.text+0x3e540> ; branch 0x3e660 / relative 0x1940
03fac0 (+2da0): r1 = 0x16
03fac8 (+2da8): goto -0x2c8 <.text+0x3e370> ; branch 0x3e490 / relative 0x1770
03fad0 (+2db0): r2 = *(u64 *)(r10 - 0x938)
03fad8 (+2db8): r2 += 0xf0
03fae0 (+2dc0): r1 = r10
03fae8 (+2dc8): r1 += -0x130
03faf0 (+2dd0): *(u64 *)(r10 - 0x920) = r2
03faf8 (+2dd8): call 0x109f ; call 0x47ff8 / window 419
03fb00 (+2de0): r9 = *(u32 *)(r10 - 0x28)
03fb08 (+2de8): if r9 != 0x2 goto +0xa8 <.text+0x3ff30> ; branch 0x40050 / relative 0x3330
03fb10 (+2df0): r1 = *(u64 *)(r10 - 0x118)
03fb18 (+2df8): *(u64 *)(r10 - 0x350) = r1
03fb20 (+2e00): r2 = *(u64 *)(r10 - 0x120)
03fb28 (+2e08): *(u64 *)(r10 - 0x358) = r2
03fb30 (+2e10): r3 = *(u64 *)(r10 - 0x128)
03fb38 (+2e18): *(u64 *)(r10 - 0x360) = r3
03fb40 (+2e20): r4 = *(u64 *)(r10 - 0x130)
03fb48 (+2e28): *(u64 *)(r10 - 0x368) = r4
03fb50 (+2e30): r5 = *(u64 *)(r10 - 0x930)
03fb58 (+2e38): *(u64 *)(r5 + 0x18) = r1
03fb60 (+2e40): *(u64 *)(r5 + 0x10) = r2
03fb68 (+2e48): *(u64 *)(r5 + 0x8) = r3
03fb70 (+2e50): *(u64 *)(r5 + 0x0) = r4
03fb78 (+2e58): goto +0x171 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03fb80 (+2e60): r1 = *(u64 *)(r10 - 0x938)
03fb88 (+2e68): r1 = *(u64 *)(r1 + 0x210)
03fb90 (+2e70): r2 = 0x99a78 ll ; pointer 0x99a78; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03fba0 (+2e80): call -0x79d3 ; call 0x2d10 / window 44
03fba8 (+2e88): if r0 != 0x0 goto +0xca <.text+0x400e0> ; branch 0x40200 / relative 0x34e0
03fbb0 (+2e90): r3 = *(u64 *)(r10 - 0x938)
03fbb8 (+2e98): r6 = r3
03fbc0 (+2ea0): r6 += 0x120
03fbc8 (+2ea8): r1 = r10
03fbd0 (+2eb0): r1 += -0x130
03fbd8 (+2eb8): r2 = r6
03fbe0 (+2ec0): call 0x123f ; call 0x48de0 / window 427
03fbe8 (+2ec8): r1 = *(u32 *)(r10 - 0x130)
03fbf0 (+2ed0): if r1 == 0x16 goto +0x1 <.text+0x3fae0> ; branch 0x3fc00 / relative 0x2ee0
03fbf8 (+2ed8): goto +0x69 <.text+0x3fe28> ; branch 0x3ff48 / relative 0x3228
03fc00 (+2ee0): r1 = *(u64 *)(r10 - 0x938)
03fc08 (+2ee8): r2 = r1
03fc10 (+2ef0): r2 += 0x240
03fc18 (+2ef8): *(u64 *)(r10 - 0x920) = r2
03fc20 (+2f00): r2 = r1
03fc28 (+2f08): r2 += 0x210
03fc30 (+2f10): *(u64 *)(r10 - 0x948) = r2
03fc38 (+2f18): r2 = r1
03fc40 (+2f20): r2 += 0x1e0
03fc48 (+2f28): *(u64 *)(r10 - 0x950) = r2
03fc50 (+2f30): r2 = r1
03fc58 (+2f38): r2 += 0x1b0
03fc60 (+2f40): *(u64 *)(r10 - 0x958) = r2
03fc68 (+2f48): r5 = r1
03fc70 (+2f50): r5 += 0x180
03fc78 (+2f58): r0 = r1
03fc80 (+2f60): r0 += 0x150
03fc88 (+2f68): r8 = r1
03fc90 (+2f70): r8 += 0xf0
03fc98 (+2f78): r9 = r1
03fca0 (+2f80): r9 += 0xc0
03fca8 (+2f88): r3 = r1
03fcb0 (+2f90): r3 += 0x90
03fcb8 (+2f98): r7 = r1
03fcc0 (+2fa0): r7 += 0x60
03fcc8 (+2fa8): r2 = r1
03fcd0 (+2fb0): r2 += 0x30
03fcd8 (+2fb8): r4 = *(u64 *)(r10 - 0x920)
03fce0 (+2fc0): *(u64 *)(r10 - 0xc0) = r4
03fce8 (+2fc8): r4 = *(u64 *)(r10 - 0x948)
03fcf0 (+2fd0): *(u64 *)(r10 - 0xc8) = r4
03fcf8 (+2fd8): r4 = *(u64 *)(r10 - 0x950)
03fd00 (+2fe0): *(u64 *)(r10 - 0xd0) = r4
03fd08 (+2fe8): r4 = *(u64 *)(r10 - 0x958)
03fd10 (+2ff0): *(u64 *)(r10 - 0xd8) = r4
03fd18 (+2ff8): *(u64 *)(r10 - 0xe0) = r5
03fd20 (+3000): *(u64 *)(r10 - 0xe8) = r0
03fd28 (+3008): *(u64 *)(r10 - 0xf0) = r6
03fd30 (+3010): *(u64 *)(r10 - 0xf8) = r8
03fd38 (+3018): *(u64 *)(r10 - 0x100) = r9
03fd40 (+3020): *(u64 *)(r10 - 0x108) = r3
03fd48 (+3028): *(u64 *)(r10 - 0x110) = r7
03fd50 (+3030): *(u64 *)(r10 - 0x118) = r2
03fd58 (+3038): *(u64 *)(r10 - 0x120) = r1
03fd60 (+3040): r1 = 0x0
03fd68 (+3048): *(u64 *)(r10 - 0x130) = r1
03fd70 (+3050): *(u64 *)(r10 - 0x128) = r1
03fd78 (+3058): r1 = r10
03fd80 (+3060): r1 += -0x368
03fd88 (+3068): r3 = r10
03fd90 (+3070): r3 += -0x130
03fd98 (+3078): r2 = *(u64 *)(r10 - 0x928)
03fda0 (+3080): r4 = *(u64 *)(r10 - 0x940)
03fda8 (+3088): call 0x12a5 ; call 0x492d8 / window 429
03fdb0 (+3090): r1 = *(u32 *)(r10 - 0x368)
03fdb8 (+3098): if r1 == 0x16 goto +0x1 <.text+0x3fca8> ; branch 0x3fdc8 / relative 0x30a8
03fdc0 (+30a0): goto +0x110 <.text+0x40528> ; branch 0x40648 / relative 0x3928
03fdc8 (+30a8): r1 = *(u64 *)(r10 - 0x930)
03fdd0 (+30b0): r2 = *(u64 *)(r10 - 0x938)
03fdd8 (+30b8): call 0x126f ; call 0x49158 / window 428
03fde0 (+30c0): goto +0x124 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03fde8 (+30c8): r1 = r10
03fdf0 (+30d0): r1 += -0x130
03fdf8 (+30d8): r2 = *(u64 *)(r10 - 0x938)
03fe00 (+30e0): r3 = *(u64 *)(r10 - 0x928)
03fe08 (+30e8): call -0x603c ; call 0xfc30 / window 275
03fe10 (+30f0): r1 = *(u32 *)(r10 - 0x130)
03fe18 (+30f8): if r1 != 0x16 goto +0x25 <.text+0x3fe28> ; branch 0x3ff48 / relative 0x3228
03fe20 (+3100): r7 = *(u64 *)(r10 - 0x938)
03fe28 (+3108): r7 += 0x30
03fe30 (+3110): r1 = r10
03fe38 (+3118): r1 += -0x130
03fe40 (+3120): r2 = r7
03fe48 (+3128): r3 = 0x99a78 ll ; pointer 0x99a78; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03fe58 (+3138): call -0x6046 ; call 0xfc30 / window 275
03fe60 (+3140): r1 = *(u32 *)(r10 - 0x130)
03fe68 (+3148): if r1 == 0x16 goto +0x1 <.text+0x3fd58> ; branch 0x3fe78 / relative 0x3158
03fe70 (+3150): goto +0x1a <.text+0x3fe28> ; branch 0x3ff48 / relative 0x3228
03fe78 (+3158): r8 = *(u64 *)(r10 - 0x938)
03fe80 (+3160): r8 += 0x60
03fe88 (+3168): r1 = r10
03fe90 (+3170): r1 += -0x130
03fe98 (+3178): r2 = r8
03fea0 (+3180): r3 = 0x99a78 ll ; pointer 0x99a78; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03feb0 (+3190): call -0x6051 ; call 0xfc30 / window 275
03feb8 (+3198): r1 = *(u32 *)(r10 - 0x130)
03fec0 (+31a0): if r1 == 0x16 goto +0x1 <.text+0x3fdb0> ; branch 0x3fed0 / relative 0x31b0
03fec8 (+31a8): goto +0xf <.text+0x3fe28> ; branch 0x3ff48 / relative 0x3228
03fed0 (+31b0): r1 = r10
03fed8 (+31b8): r1 += -0x130
03fee0 (+31c0): r2 = *(u64 *)(r10 - 0x938)
03fee8 (+31c8): call 0xdcf ; call 0x46d68 / window 412
03fef0 (+31d0): r6 = *(u64 *)(r10 - 0x120)
03fef8 (+31d8): if r6 != 0x2 goto +0x11a <.text+0x406b0> ; branch 0x407d0 / relative 0x3ab0
03ff00 (+31e0): r1 = *(u64 *)(r10 - 0x100)
03ff08 (+31e8): *(u64 *)(r10 - 0x550) = r1
03ff10 (+31f0): r2 = *(u64 *)(r10 - 0x108)
03ff18 (+31f8): *(u64 *)(r10 - 0x558) = r2
03ff20 (+3200): r3 = *(u64 *)(r10 - 0x110)
03ff28 (+3208): *(u64 *)(r10 - 0x560) = r3
03ff30 (+3210): r4 = *(u64 *)(r10 - 0x118)
03ff38 (+3218): *(u64 *)(r10 - 0x568) = r4
03ff40 (+3220): goto -0x7f <.text+0x3fa30> ; branch 0x3fb50 / relative 0x2e30
03ff48 (+3228): r2 = *(u32 *)(r10 - 0x114)
03ff50 (+3230): r3 = *(u64 *)(r10 - 0x930)
03ff58 (+3238): *(u32 *)(r3 + 0x1c) = r2
03ff60 (+3240): r2 = *(u64 *)(r10 - 0x11c)
03ff68 (+3248): *(u64 *)(r3 + 0x14) = r2
03ff70 (+3250): r2 = *(u64 *)(r10 - 0x124)
03ff78 (+3258): *(u64 *)(r3 + 0xc) = r2
03ff80 (+3260): r2 = *(u64 *)(r10 - 0x12c)
03ff88 (+3268): *(u64 *)(r3 + 0x4) = r2
03ff90 (+3270): *(u32 *)(r3 + 0x0) = r1
03ff98 (+3278): goto +0xed <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
03ffa0 (+3280): if r7 != 0x0 goto +0x1 <.text+0x3fe90> ; branch 0x3ffb0 / relative 0x3290
03ffa8 (+3288): goto +0x52 <.text+0x40120> ; branch 0x40240 / relative 0x3520
03ffb0 (+3290): r1 = r10
03ffb8 (+3298): r1 += -0x6c8
03ffc0 (+32a0): r2 = *(u64 *)(r10 - 0x928)
03ffc8 (+32a8): r3 = *(u64 *)(r10 - 0x938)
03ffd0 (+32b0): call 0x6c8b ; call 0x76430 / window 772
03ffd8 (+32b8): r1 = *(u32 *)(r10 - 0x6c8)
03ffe0 (+32c0): if r1 != 0x16 goto +0x137 <.text+0x40880> ; branch 0x409a0 / relative 0x3c80
03ffe8 (+32c8): r1 = *(u64 *)(r10 - 0x920)
03fff0 (+32d0): call 0x8a36 ; call 0x851a8 / window 980
03fff8 (+32d8): if r0 == 0x0 goto +0x6 <.text+0x3ff10> ; branch 0x40030 / relative 0x3310
040000 (+32e0): r1 = *(u64 *)(r10 - 0x938)
040008 (+32e8): r1 += 0x48
040010 (+32f0): r2 = 0x9ef18 ll ; pointer 0x9ef18; data32hex 00000000f89909000000000016a5090022000000000000005200000026000000
040020 (+3300): call -0x7a6e ; call 0x2cb8 / window 41
040028 (+3308): if r0 != 0x0 goto +0x126 <.text+0x40840> ; branch 0x40960 / relative 0x3c40
040030 (+3310): r1 = 0x16
040038 (+3318): r2 = *(u64 *)(r10 - 0x930)
040040 (+3320): *(u32 *)(r2 + 0x0) = r1
040048 (+3328): goto -0xb9 <.text+0x3f968> ; branch 0x3fa88 / relative 0x2d68
040050 (+3330): r6 = r10
040058 (+3338): r6 += -0x368
040060 (+3340): r2 = r10
040068 (+3348): r2 += -0x130
040070 (+3350): r1 = r6
040078 (+3358): r3 = 0x108
040080 (+3360): call 0xb1e9 ; call 0x98fd0 / window 1246
040088 (+3368): r1 = r10
040090 (+3370): r1 += -0x45c
040098 (+3378): r2 = r10
0400a0 (+3380): r2 += -0x24
0400a8 (+3388): r3 = 0x24
0400b0 (+3390): call 0xb1e3 ; call 0x98fd0 / window 1246
0400b8 (+3398): r1 = r10
0400c0 (+33a0): r1 += -0x568
0400c8 (+33a8): r2 = r6
0400d0 (+33b0): r3 = 0x108
0400d8 (+33b8): call 0xb1de ; call 0x98fd0 / window 1246
0400e0 (+33c0): *(u32 *)(r10 - 0x460) = r9
0400e8 (+33c8): r1 = *(u64 *)(r10 - 0x938)
0400f0 (+33d0): r2 = *(u64 *)(r1 + 0x40)
0400f8 (+33d8): r2 += 0x10
040100 (+33e0): r1 = r10
040108 (+33e8): r1 += -0x8d8
040110 (+33f0): r3 = 0x9f020 ll ; pointer 0x9f020; data32hex 00000000e0a609003900000000000000260000003b0000000000000098990900
040120 (+3400): call -0x7909 ; call 0x38e0 / window 87
040128 (+3408): r1 = *(u64 *)(r10 - 0x8d8)
040130 (+3410): r2 = *(u64 *)(r1 + 0x0)
040138 (+3418): r3 = *(u64 *)(r1 + 0x8)
040140 (+3420): r9 = *(u64 *)(r10 - 0x8d0)
040148 (+3428): r1 = r10
040150 (+3430): r1 += -0x130
040158 (+3438): call 0x2bef ; call 0x560d8 / window 451
040160 (+3440): r7 = *(u32 *)(r10 - 0x130)
040168 (+3448): if r7 == 0x2 goto +0x1 <.text+0x40058> ; branch 0x40178 / relative 0x3458
040170 (+3450): goto +0x3d <.text+0x40240> ; branch 0x40360 / relative 0x3640
040178 (+3458): r1 = *(u64 *)(r10 - 0x110)
040180 (+3460): *(u64 *)(r10 - 0x34c) = r1
040188 (+3468): r2 = *(u64 *)(r10 - 0x118)
040190 (+3470): *(u64 *)(r10 - 0x354) = r2
040198 (+3478): r3 = *(u64 *)(r10 - 0x120)
0401a0 (+3480): *(u64 *)(r10 - 0x35c) = r3
0401a8 (+3488): r4 = *(u64 *)(r10 - 0x128)
0401b0 (+3490): *(u64 *)(r10 - 0x364) = r4
0401b8 (+3498): r5 = *(u64 *)(r10 - 0x930)
0401c0 (+34a0): *(u64 *)(r5 + 0x18) = r1
0401c8 (+34a8): *(u64 *)(r5 + 0x10) = r2
0401d0 (+34b0): *(u64 *)(r5 + 0x8) = r3
0401d8 (+34b8): *(u64 *)(r5 + 0x0) = r4
0401e0 (+34c0): r1 = *(u64 *)(r9 + 0x0)
0401e8 (+34c8): r1 += -0x1
0401f0 (+34d0): *(u64 *)(r9 + 0x0) = r1
0401f8 (+34d8): goto +0x9e <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
040200 (+34e0): r1 = 0x3e00000000 ll
040210 (+34f0): goto -0x2f8 <.text+0x3e938> ; branch 0x3ea58 / relative 0x1d38
040218 (+34f8): r1 = 0x0
040220 (+3500): r2 = 0x0
040228 (+3508): r3 = 0x9f3e0 ll ; pointer 0x9f3e0; data32hex 00000000fea909001c000000000000006c010000210000000000000098980900
040238 (+3518): goto -0x38f <.text+0x3e4a8> ; branch 0x3e5c8 / relative 0x18a8
040240 (+3520): r1 = *(u64 *)(r10 - 0x938)
040248 (+3528): r2 = *(u64 *)(r1 + 0x70)
040250 (+3530): r2 += 0x10
040258 (+3538): r1 = r10
040260 (+3540): r1 += -0x878
040268 (+3548): r3 = 0x9eed0 ll ; pointer 0x9eed0; data32hex 0000000016a5090022000000000000003d0000004f0000000000000016a50900
040278 (+3558): call -0x7934 ; call 0x38e0 / window 87
040280 (+3560): r1 = *(u64 *)(r10 - 0x878)
040288 (+3568): r2 = *(u64 *)(r1 + 0x0)
040290 (+3570): r3 = *(u64 *)(r1 + 0x8)
040298 (+3578): r1 = *(u64 *)(r10 - 0x870)
0402a0 (+3580): *(u64 *)(r10 - 0x958) = r1
0402a8 (+3588): r1 = r10
0402b0 (+3590): r1 += -0x6c8
0402b8 (+3598): call 0x776a ; call 0x7be10 / window 850
0402c0 (+35a0): r1 = *(u32 *)(r10 - 0x6b8)
0402c8 (+35a8): *(u64 *)(r10 - 0x950) = r1
0402d0 (+35b0): if r1 != 0x2 goto +0x28e <.text+0x41628> ; branch 0x41748 / relative 0x4a28
0402d8 (+35b8): r1 = *(u64 *)(r10 - 0x698)
0402e0 (+35c0): *(u64 *)(r10 - 0x21c) = r1
0402e8 (+35c8): r2 = *(u64 *)(r10 - 0x6a0)
0402f0 (+35d0): *(u64 *)(r10 - 0x224) = r2
0402f8 (+35d8): r3 = *(u64 *)(r10 - 0x6a8)
040300 (+35e0): *(u64 *)(r10 - 0x22c) = r3
040308 (+35e8): r4 = *(u64 *)(r10 - 0x6b0)
040310 (+35f0): *(u64 *)(r10 - 0x234) = r4
040318 (+35f8): r5 = *(u64 *)(r10 - 0x930)
040320 (+3600): *(u64 *)(r5 + 0x18) = r1
040328 (+3608): *(u64 *)(r5 + 0x10) = r2
040330 (+3610): *(u64 *)(r5 + 0x8) = r3
040338 (+3618): *(u64 *)(r5 + 0x0) = r4
040340 (+3620): r2 = *(u64 *)(r10 - 0x958)
040348 (+3628): r1 = *(u64 *)(r2 + 0x0)
040350 (+3630): r1 += -0x1
040358 (+3638): goto -0x11c <.text+0x3f960> ; branch 0x3fa80 / relative 0x2d60
040360 (+3640): r6 = r10
040368 (+3648): r6 += -0x368
040370 (+3650): r2 = r10
040378 (+3658): r2 += -0x12c
040380 (+3660): r1 = r6
040388 (+3668): r3 = 0x24
040390 (+3670): call 0xb187 ; call 0x98fd0 / window 1246
040398 (+3678): r1 = r10
0403a0 (+3680): r1 += -0x410
0403a8 (+3688): r2 = r10
0403b0 (+3690): r2 += -0x108
0403b8 (+3698): r3 = 0x30
0403c0 (+36a0): call 0xb181 ; call 0x98fd0 / window 1246
0403c8 (+36a8): r1 = r10
0403d0 (+36b0): r1 += -0x434
0403d8 (+36b8): r2 = r6
0403e0 (+36c0): r3 = 0x24
0403e8 (+36c8): call 0xb17c ; call 0x98fd0 / window 1246
0403f0 (+36d0): *(u32 *)(r10 - 0x438) = r7
0403f8 (+36d8): r1 = *(u64 *)(r9 + 0x0)
040400 (+36e0): r1 += -0x1
040408 (+36e8): *(u64 *)(r9 + 0x0) = r1
040410 (+36f0): r1 = r10
040418 (+36f8): r1 += -0x8e8
040420 (+3700): r8 = *(u64 *)(r10 - 0x928)
040428 (+3708): r2 = r8
040430 (+3710): call 0x8bc9 ; call 0x86280 / window 990
040438 (+3718): r9 = *(u64 *)(r10 - 0x938)
040440 (+3720): r2 = *(u64 *)(r9 + 0x30)
040448 (+3728): r6 = *(u64 *)(r10 - 0x8e8)
040450 (+3730): r7 = *(u64 *)(r10 - 0x8e0)
040458 (+3738): r1 = r10
040460 (+3740): r1 += -0x8f8
040468 (+3748): *(u64 *)(r10 - 0x950) = r2
040470 (+3750): call 0x8bc1 ; call 0x86280 / window 990
040478 (+3758): r1 = 0x7
040480 (+3760): *(u64 *)(r10 - 0xf8) = r1
040488 (+3768): r1 = 0x9a285 ll ; pointer 0x9a285; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
040498 (+3778): *(u64 *)(r10 - 0x100) = r1
0404a0 (+3780): *(u64 *)(r10 - 0x118) = r7
0404a8 (+3788): *(u64 *)(r10 - 0x120) = r6
0404b0 (+3790): r1 = 0x8
0404b8 (+3798): *(u64 *)(r10 - 0x128) = r1
0404c0 (+37a0): r1 = 0x9a240 ll ; pointer 0x9a240; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
0404d0 (+37b0): *(u64 *)(r10 - 0x130) = r1
0404d8 (+37b8): r1 = *(u64 *)(r10 - 0x8f0)
0404e0 (+37c0): *(u64 *)(r10 - 0x108) = r1
0404e8 (+37c8): r1 = *(u64 *)(r10 - 0x8f8)
0404f0 (+37d0): *(u64 *)(r10 - 0x110) = r1
0404f8 (+37d8): r1 = r10
040500 (+37e0): r1 += -0x368
040508 (+37e8): r4 = r10
040510 (+37f0): r4 += -0x130
040518 (+37f8): r2 = r8
040520 (+3800): r3 = r9
040528 (+3808): r5 = 0x4
040530 (+3810): call -0x612d ; call 0xfbd0 / window 273
040538 (+3818): r1 = *(u32 *)(r10 - 0x368)
040540 (+3820): if r1 == 0x16 goto +0x1 <.text+0x40430> ; branch 0x40550 / relative 0x3830
040548 (+3828): goto +0x28 <.text+0x40570> ; branch 0x40690 / relative 0x3970
040550 (+3830): r2 = *(u64 *)(r10 - 0x938)
040558 (+3838): r2 += 0x120
040560 (+3840): r6 = *(u8 *)(r10 - 0x364)
040568 (+3848): r1 = r10
040570 (+3850): r1 += -0x130
040578 (+3858): r8 = r2
040580 (+3860): call -0x6114 ; call 0xfce8 / window 277
040588 (+3868): r1 = *(u32 *)(r10 - 0x130)
040590 (+3870): if r1 == 0x16 goto +0x1 <.text+0x40480> ; branch 0x405a0 / relative 0x3880
040598 (+3878): goto +0xa <.text+0x404d0> ; branch 0x405f0 / relative 0x38d0
0405a0 (+3880): r3 = *(u64 *)(r10 - 0x938)
0405a8 (+3888): r3 += 0x90
0405b0 (+3890): r1 = r10
0405b8 (+3898): r1 += -0x130
0405c0 (+38a0): r2 = r10
0405c8 (+38a8): r2 += -0x438
0405d0 (+38b0): r9 = r3
0405d8 (+38b8): call -0x6210 ; call 0xf560 / window 270
0405e0 (+38c0): r1 = *(u32 *)(r10 - 0x130)
0405e8 (+38c8): if r1 == 0x16 goto +0x8a <.text+0x40920> ; branch 0x40a40 / relative 0x3d20
0405f0 (+38d0): r2 = *(u32 *)(r10 - 0x114)
0405f8 (+38d8): r3 = *(u64 *)(r10 - 0x930)
040600 (+38e0): *(u32 *)(r3 + 0x1c) = r2
040608 (+38e8): r2 = *(u64 *)(r10 - 0x11c)
040610 (+38f0): *(u64 *)(r3 + 0x14) = r2
040618 (+38f8): r2 = *(u64 *)(r10 - 0x124)
040620 (+3900): *(u64 *)(r3 + 0xc) = r2
040628 (+3908): r2 = *(u64 *)(r10 - 0x12c)
040630 (+3910): *(u64 *)(r3 + 0x4) = r2
040638 (+3918): *(u32 *)(r3 + 0x0) = r1
040640 (+3920): goto +0x15 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
040648 (+3928): r2 = *(u32 *)(r10 - 0x34c)
040650 (+3930): r3 = *(u64 *)(r10 - 0x930)
040658 (+3938): *(u32 *)(r3 + 0x1c) = r2
040660 (+3940): r2 = *(u64 *)(r10 - 0x354)
040668 (+3948): *(u64 *)(r3 + 0x14) = r2
040670 (+3950): r2 = *(u64 *)(r10 - 0x35c)
040678 (+3958): *(u64 *)(r3 + 0xc) = r2
040680 (+3960): r2 = *(u64 *)(r10 - 0x364)
040688 (+3968): goto -0xe1 <.text+0x3fe68> ; branch 0x3ff88 / relative 0x3268
040690 (+3970): r2 = *(u8 *)(r10 - 0x364)
040698 (+3978): r3 = *(u32 *)(r10 - 0x34c)
0406a0 (+3980): r4 = *(u64 *)(r10 - 0x930)
0406a8 (+3988): *(u32 *)(r4 + 0x1c) = r3
0406b0 (+3990): r3 = *(u64 *)(r10 - 0x353)
0406b8 (+3998): *(u64 *)(r4 + 0x15) = r3
0406c0 (+39a0): r3 = *(u64 *)(r10 - 0x35b)
0406c8 (+39a8): *(u64 *)(r4 + 0xd) = r3
0406d0 (+39b0): r3 = *(u64 *)(r10 - 0x363)
0406d8 (+39b8): *(u64 *)(r4 + 0x5) = r3
0406e0 (+39c0): *(u8 *)(r4 + 0x4) = r2
0406e8 (+39c8): *(u32 *)(r4 + 0x0) = r1
0406f0 (+39d0): r1 = r10
0406f8 (+39d8): r1 += -0x520
040700 (+39e0): call -0x7acd ; call 0x30a0 / window 59
040708 (+39e8): r1 = 0x1
040710 (+39f0): r2 = 0x1
040718 (+39f8): r3 = *(u32 *)(r10 - 0x6c8)
040720 (+3a00): if r3 > 0x28 goto +0x8 <.text+0x40648> ; branch 0x40768 / relative 0x3a48
040728 (+3a08): r4 = 0x1
040730 (+3a10): r4 <<= r3
040738 (+3a18): r5 = 0x114001a2800 ll
040748 (+3a28): r4 &= r5
040750 (+3a30): if r4 != 0x0 goto -0x724 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
040758 (+3a38): if r3 == 0xf goto +0x4 <.text+0x40660> ; branch 0x40780 / relative 0x3a60
040760 (+3a40): if r3 == 0x21 goto +0x9 <.text+0x40690> ; branch 0x407b0 / relative 0x3a90
040768 (+3a48): r1 = r10
040770 (+3a50): r1 += -0x6c8
040778 (+3a58): goto -0x40c <.text+0x3e600> ; branch 0x3e720 / relative 0x1a00
040780 (+3a60): if r1 != 0x0 goto +0x1 <.text+0x40670> ; branch 0x40790 / relative 0x3a70
040788 (+3a68): goto -0x72b <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
040790 (+3a70): r1 = r10
040798 (+3a78): r1 += -0x6c0
0407a0 (+3a80): call -0x7a0a ; call 0x3758 / window 81
0407a8 (+3a88): goto -0x72f <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
0407b0 (+3a90): if r2 == 0x0 goto -0x730 <.text+0x3cd18> ; branch 0x3ce38 / relative 0x118
0407b8 (+3a98): r1 = r10
0407c0 (+3aa0): r1 += -0x6c0
0407c8 (+3aa8): goto -0x3ff <.text+0x3e6b8> ; branch 0x3e7d8 / relative 0x1ab8
0407d0 (+3ab0): r1 = *(u64 *)(r10 - 0x128)
0407d8 (+3ab8): *(u64 *)(r10 - 0x360) = r1
0407e0 (+3ac0): r1 = *(u64 *)(r10 - 0x130)
0407e8 (+3ac8): *(u64 *)(r10 - 0x368) = r1
0407f0 (+3ad0): r1 = *(u64 *)(r10 - 0x118)
0407f8 (+3ad8): *(u64 *)(r10 - 0x568) = r1
040800 (+3ae0): r1 = *(u64 *)(r10 - 0x110)
040808 (+3ae8): *(u64 *)(r10 - 0x560) = r1
040810 (+3af0): r1 = *(u64 *)(r10 - 0x108)
040818 (+3af8): *(u64 *)(r10 - 0x558) = r1
040820 (+3b00): r1 = *(u64 *)(r10 - 0x100)
040828 (+3b08): *(u64 *)(r10 - 0x550) = r1
040830 (+3b10): r1 = r10
040838 (+3b18): r1 += -0x330
040840 (+3b20): r2 = r10
040848 (+3b28): r2 += -0xf8
040850 (+3b30): r3 = 0x28
040858 (+3b38): call 0xb0ee ; call 0x98fd0 / window 1246
040860 (+3b40): *(u64 *)(r10 - 0x358) = r6
040868 (+3b48): r1 = *(u64 *)(r10 - 0x568)
040870 (+3b50): *(u64 *)(r10 - 0x350) = r1
040878 (+3b58): r1 = *(u64 *)(r10 - 0x560)
040880 (+3b60): *(u64 *)(r10 - 0x348) = r1
040888 (+3b68): r1 = *(u64 *)(r10 - 0x558)
040890 (+3b70): *(u64 *)(r10 - 0x340) = r1
040898 (+3b78): r1 = *(u64 *)(r10 - 0x550)
0408a0 (+3b80): *(u64 *)(r10 - 0x338) = r1
0408a8 (+3b88): r1 = r10
0408b0 (+3b90): r1 += -0x130
0408b8 (+3b98): r2 = r8
0408c0 (+3ba0): call -0x6270 ; call 0xf548 / window 269
0408c8 (+3ba8): r1 = *(u32 *)(r10 - 0x130)
0408d0 (+3bb0): if r1 == 0x2 goto +0x24 <.text+0x408d8> ; branch 0x409f8 / relative 0x3cd8
0408d8 (+3bb8): r6 = *(u64 *)(r10 - 0x108)
0408e0 (+3bc0): r1 = r10
0408e8 (+3bc8): r1 += -0x130
0408f0 (+3bd0): r2 = r7
0408f8 (+3bd8): call -0x6277 ; call 0xf548 / window 269
040900 (+3be0): r1 = *(u32 *)(r10 - 0x130)
040908 (+3be8): if r1 == 0x2 goto +0x1d <.text+0x408d8> ; branch 0x409f8 / relative 0x3cd8
040910 (+3bf0): r9 = *(u64 *)(r10 - 0x108)
040918 (+3bf8): r2 = *(u64 *)(r7 + 0x0)
040920 (+3c00): r1 = r10
040928 (+3c08): r1 += -0x328
040930 (+3c10): call -0x7b85 ; call 0x2d10 / window 44
040938 (+3c18): if r0 != 0x0 goto +0x1 <.text+0x40828> ; branch 0x40948 / relative 0x3c28
040940 (+3c20): goto +0x3b <.text+0x40a00> ; branch 0x40b20 / relative 0x3e00
040948 (+3c28): r1 = 0x1d00000000 ll
040958 (+3c38): goto -0x3e1 <.text+0x3e938> ; branch 0x3ea58 / relative 0x1d38
040960 (+3c40): r1 = r10
040968 (+3c48): r1 += -0x6c8
040970 (+3c50): r2 = *(u64 *)(r10 - 0x928)
040978 (+3c58): r3 = *(u64 *)(r10 - 0x920)
040980 (+3c60): call 0x6b55 ; call 0x76430 / window 772
040988 (+3c68): r1 = *(u32 *)(r10 - 0x6c8)
040990 (+3c70): if r1 != 0x16 goto +0x1 <.text+0x40880> ; branch 0x409a0 / relative 0x3c80
040998 (+3c78): goto -0x12e <.text+0x3ff10> ; branch 0x40030 / relative 0x3310
0409a0 (+3c80): r2 = *(u32 *)(r10 - 0x6ac)
0409a8 (+3c88): r3 = *(u64 *)(r10 - 0x930)
0409b0 (+3c90): *(u32 *)(r3 + 0x1c) = r2
0409b8 (+3c98): r2 = *(u64 *)(r10 - 0x6b4)
0409c0 (+3ca0): *(u64 *)(r3 + 0x14) = r2
0409c8 (+3ca8): r2 = *(u64 *)(r10 - 0x6bc)
0409d0 (+3cb0): *(u64 *)(r3 + 0xc) = r2
0409d8 (+3cb8): r2 = *(u64 *)(r10 - 0x6c4)
0409e0 (+3cc0): *(u64 *)(r3 + 0x4) = r2
0409e8 (+3cc8): *(u32 *)(r3 + 0x0) = r1
0409f0 (+3cd0): goto -0x1ee <.text+0x3f968> ; branch 0x3fa88 / relative 0x2d68
0409f8 (+3cd8): r1 = *(u64 *)(r10 - 0x110)
040a00 (+3ce0): *(u64 *)(r10 - 0x54c) = r1
040a08 (+3ce8): r2 = *(u64 *)(r10 - 0x118)
040a10 (+3cf0): *(u64 *)(r10 - 0x554) = r2
040a18 (+3cf8): r3 = *(u64 *)(r10 - 0x120)
040a20 (+3d00): *(u64 *)(r10 - 0x55c) = r3
040a28 (+3d08): r4 = *(u64 *)(r10 - 0x128)
040a30 (+3d10): *(u64 *)(r10 - 0x564) = r4
040a38 (+3d18): goto -0x1de <.text+0x3fa30> ; branch 0x3fb50 / relative 0x2e30
040a40 (+3d20): r1 = r10
040a48 (+3d28): r1 += -0x130
040a50 (+3d30): r2 = *(u64 *)(r10 - 0x920)
040a58 (+3d38): r3 = *(u64 *)(r10 - 0x928)
040a60 (+3d40): call -0x61c7 ; call 0xfc30 / window 275
040a68 (+3d48): r1 = *(u32 *)(r10 - 0x130)
040a70 (+3d50): if r1 == 0x16 goto +0x1 <.text+0x40960> ; branch 0x40a80 / relative 0x3d60
040a78 (+3d58): goto -0x92 <.text+0x404d0> ; branch 0x405f0 / relative 0x38d0
040a80 (+3d60): r2 = *(u64 *)(r10 - 0x938)
040a88 (+3d68): r2 += 0x30
040a90 (+3d70): r3 = *(u64 *)(r8 + 0x0)
040a98 (+3d78): r1 = r10
040aa0 (+3d80): r1 += -0x130
040aa8 (+3d88): r7 = r2
040ab0 (+3d90): call -0x61d1 ; call 0xfc30 / window 275
040ab8 (+3d98): r1 = *(u32 *)(r10 - 0x130)
040ac0 (+3da0): if r1 == 0x16 goto +0x1 <.text+0x409b0> ; branch 0x40ad0 / relative 0x3db0
040ac8 (+3da8): goto -0x9c <.text+0x404d0> ; branch 0x405f0 / relative 0x38d0
040ad0 (+3db0): r1 = r10
040ad8 (+3db8): r1 += -0x544
040ae0 (+3dc0): r2 = *(u64 *)(r10 - 0x950)
040ae8 (+3dc8): call -0x7bbc ; call 0x2d10 / window 44
040af0 (+3dd0): if r0 != 0x0 goto +0xe <.text+0x40a48> ; branch 0x40b68 / relative 0x3e48
040af8 (+3dd8): r1 = *(u8 *)(r10 - 0x408)
040b00 (+3de0): if r1 == 0x0 goto +0x15 <.text+0x40a90> ; branch 0x40bb0 / relative 0x3e90
040b08 (+3de8): r1 = 0x1800000000 ll
040b18 (+3df8): goto +0xb <.text+0x40a58> ; branch 0x40b78 / relative 0x3e58
040b20 (+3e00): r2 = *(u64 *)(r8 + 0x0)
040b28 (+3e08): r1 = r10
040b30 (+3e10): r1 += -0x348
040b38 (+3e18): call -0x7bc6 ; call 0x2d10 / window 44
040b40 (+3e20): if r0 != 0x0 goto +0x1 <.text+0x40a30> ; branch 0x40b50 / relative 0x3e30
040b48 (+3e28): goto +0x8 <.text+0x40a70> ; branch 0x40b90 / relative 0x3e70
040b50 (+3e30): r1 = 0x1c00000000 ll
040b60 (+3e40): goto -0x422 <.text+0x3e938> ; branch 0x3ea58 / relative 0x1d38
040b68 (+3e48): r1 = 0xf00000000 ll
040b78 (+3e58): r2 = *(u64 *)(r10 - 0x930)
040b80 (+3e60): *(u64 *)(r2 + 0x0) = r1
040b88 (+3e68): goto -0x94 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
040b90 (+3e70): if r6 == 0x0 goto +0xe <.text+0x40ae8> ; branch 0x40c08 / relative 0x3ee8
040b98 (+3e78): r1 = 0x4500000000 ll
040ba8 (+3e88): goto -0x42b <.text+0x3e938> ; branch 0x3ea58 / relative 0x1d38
040bb0 (+3e90): r1 = *(u64 *)(r10 - 0x938)
040bb8 (+3e98): r1 += 0x150
040bc0 (+3ea0): *(u64 *)(r10 - 0x958) = r1
040bc8 (+3ea8): r2 = 0x9ed98 ll ; pointer 0x9ed98; data32hex 00000000189a090000000000f89a09000000000048a409002200000000000000
040bd8 (+3eb8): call -0x7be1 ; call 0x2cd8 / window 42
040be0 (+3ec0): if r0 != 0x0 goto +0x1 <.text+0x40ad0> ; branch 0x40bf0 / relative 0x3ed0
040be8 (+3ec8): goto +0x7 <.text+0x40b08> ; branch 0x40c28 / relative 0x3f08
040bf0 (+3ed0): r1 = 0x7e00000000 ll
040c00 (+3ee0): goto -0x12 <.text+0x40a58> ; branch 0x40b78 / relative 0x3e58
040c08 (+3ee8): if r9 == 0x0 goto +0x64 <.text+0x40e10> ; branch 0x40f30 / relative 0x4210
040c10 (+3ef0): r1 = 0x4600000000 ll
040c20 (+3f00): goto -0x43a <.text+0x3e938> ; branch 0x3ea58 / relative 0x1d38
040c28 (+3f08): r3 = *(u64 *)(r10 - 0x938)
040c30 (+3f10): r3 += 0x60
040c38 (+3f18): r1 = r10
040c40 (+3f20): r1 += -0x130
040c48 (+3f28): r2 = r10
040c50 (+3f30): r2 += -0x568
040c58 (+3f38): call -0x63e1 ; call 0xed58 / window 263
040c60 (+3f40): r1 = *(u32 *)(r10 - 0x130)
040c68 (+3f48): if r1 == 0x16 goto +0x1 <.text+0x40b58> ; branch 0x40c78 / relative 0x3f58
040c70 (+3f50): goto -0xd1 <.text+0x404d0> ; branch 0x405f0 / relative 0x38d0
040c78 (+3f58): r1 = *(u64 *)(r10 - 0x410)
040c80 (+3f60): if r1 == 0x1 goto +0x1 <.text+0x40b70> ; branch 0x40c90 / relative 0x3f70
040c88 (+3f68): goto +0x72 <.text+0x40f00> ; branch 0x41020 / relative 0x4300
040c90 (+3f70): r1 = *(u64 *)(r10 - 0x938)
040c98 (+3f78): r1 += 0xc0
040ca0 (+3f80): *(u64 *)(r10 - 0x960) = r1
040ca8 (+3f88): r1 = r10
040cb0 (+3f90): r1 += -0x908
040cb8 (+3f98): r2 = *(u64 *)(r10 - 0x928)
040cc0 (+3fa0): call 0x8ab7 ; call 0x86280 / window 990
040cc8 (+3fa8): r1 = *(u64 *)(r10 - 0x908)
040cd0 (+3fb0): *(u64 *)(r10 - 0x968) = r1
040cd8 (+3fb8): r1 = *(u64 *)(r10 - 0x900)
040ce0 (+3fc0): *(u64 *)(r10 - 0x970) = r1
040ce8 (+3fc8): r1 = r10
040cf0 (+3fd0): r1 += -0x918
040cf8 (+3fd8): r2 = *(u64 *)(r10 - 0x950)
040d00 (+3fe0): call 0x8aaf ; call 0x86280 / window 990
040d08 (+3fe8): r1 = 0x1
040d10 (+3ff0): *(u64 *)(r10 - 0x398) = r1
040d18 (+3ff8): r1 = r10
040d20 (+4000): r1 += -0x389
040d28 (+4008): *(u64 *)(r10 - 0x3a0) = r1
040d30 (+4010): r1 = 0x7
040d38 (+4018): *(u64 *)(r10 - 0x3a8) = r1
040d40 (+4020): r1 = 0x9a285 ll ; pointer 0x9a285; data32hex 65646974696f6e70726f6772616d2f7372632f617373657274696f6e732f6564
040d50 (+4030): *(u64 *)(r10 - 0x3b0) = r1
040d58 (+4038): r1 = *(u64 *)(r10 - 0x970)
040d60 (+4040): *(u64 *)(r10 - 0x3c8) = r1
040d68 (+4048): r1 = *(u64 *)(r10 - 0x968)
040d70 (+4050): *(u64 *)(r10 - 0x3d0) = r1
040d78 (+4058): r1 = 0x8
040d80 (+4060): *(u64 *)(r10 - 0x3d8) = r1
040d88 (+4068): r1 = 0x9a240 ll ; pointer 0x9a240; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
040d98 (+4078): *(u64 *)(r10 - 0x3e0) = r1
040da0 (+4080): r1 = *(u64 *)(r10 - 0x910)
040da8 (+4088): *(u64 *)(r10 - 0x3b8) = r1
040db0 (+4090): r1 = *(u64 *)(r10 - 0x918)
040db8 (+4098): *(u64 *)(r10 - 0x3c0) = r1
040dc0 (+40a0): *(u8 *)(r10 - 0x389) = r6
040dc8 (+40a8): r2 = *(u64 *)(r10 - 0x928)
040dd0 (+40b0): r1 = *(u64 *)(r2 + 0x18)
040dd8 (+40b8): *(u64 *)(r10 - 0x118) = r1
040de0 (+40c0): r1 = *(u64 *)(r2 + 0x10)
040de8 (+40c8): *(u64 *)(r10 - 0x120) = r1
040df0 (+40d0): r1 = *(u64 *)(r2 + 0x8)
040df8 (+40d8): *(u64 *)(r10 - 0x128) = r1
040e00 (+40e0): r1 = *(u64 *)(r2 + 0x0)
040e08 (+40e8): *(u64 *)(r10 - 0x130) = r1
040e10 (+40f0): r1 = r10
040e18 (+40f8): r1 += -0x3e0
040e20 (+4100): *(u64 *)(r10 - 0xff0) = r1
040e28 (+4108): r1 = 0x5
040e30 (+4110): *(u64 *)(r10 - 0xfe8) = r1
040e38 (+4118): r1 = 0x14
040e40 (+4120): *(u64 *)(r10 - 0xff8) = r1
040e48 (+4128): r1 = *(u64 *)(r10 - 0x960)
040e50 (+4130): *(u64 *)(r10 - 0x1000) = r1
040e58 (+4138): r1 = r10
040e60 (+4140): r1 += -0x368
040e68 (+4148): r2 = r10
040e70 (+4150): r2 += -0x130
040e78 (+4158): r5 = r10
040e80 (+4160): r3 = *(u64 *)(r10 - 0x938)
040e88 (+4168): r4 = *(u64 *)(r10 - 0x958)
040e90 (+4170): call 0x68b0 ; call 0x75418 / window 770
040e98 (+4178): r1 = *(u32 *)(r10 - 0x368)
040ea0 (+4180): if r1 == 0x16 goto +0x1 <.text+0x40d90> ; branch 0x40eb0 / relative 0x4190
040ea8 (+4188): goto +0x65 <.text+0x410b8> ; branch 0x411d8 / relative 0x44b8
040eb0 (+4190): r1 = r10
040eb8 (+4198): r1 += -0x130
040ec0 (+41a0): r2 = *(u64 *)(r10 - 0x938)
040ec8 (+41a8): call 0xb87 ; call 0x46b08 / window 411
040ed0 (+41b0): r1 = *(u64 *)(r10 - 0x130)
040ed8 (+41b8): if r1 == 0x0 goto +0x68 <.text+0x41100> ; branch 0x41220 / relative 0x4500
040ee0 (+41c0): r1 = *(u64 *)(r10 - 0x128)
040ee8 (+41c8): r2 = *(u64 *)(r10 - 0x110)
040ef0 (+41d0): r3 = *(u64 *)(r10 - 0x930)
040ef8 (+41d8): *(u64 *)(r3 + 0x18) = r2
040f00 (+41e0): r2 = *(u64 *)(r10 - 0x118)
040f08 (+41e8): *(u64 *)(r3 + 0x10) = r2
040f10 (+41f0): r2 = *(u64 *)(r10 - 0x120)
040f18 (+41f8): *(u64 *)(r3 + 0x8) = r2
040f20 (+4200): *(u64 *)(r3 + 0x0) = r1
040f28 (+4208): goto -0x108 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
040f30 (+4210): r1 = r10
040f38 (+4218): r1 += -0x130
040f40 (+4220): r2 = *(u64 *)(r10 - 0x938)
040f48 (+4228): call 0x88b3 ; call 0x854e8 / window 986
040f50 (+4230): r1 = *(u32 *)(r10 - 0x130)
040f58 (+4238): if r1 == 0x16 goto +0x1 <.text+0x40e48> ; branch 0x40f68 / relative 0x4248
040f60 (+4240): goto +0x43 <.text+0x41060> ; branch 0x41180 / relative 0x4460
040f68 (+4248): r6 = *(u64 *)(r10 - 0x120)
040f70 (+4250): r1 = *(u64 *)(r10 - 0x128)
040f78 (+4258): r2 = *(u64 *)(r1 + 0x8)
040f80 (+4260): r1 = *(u64 *)(r1 + 0x0)
040f88 (+4268): r3 = *(u64 *)(r10 - 0x350)
040f90 (+4270): *(u64 *)(r10 - 0x118) = r3
040f98 (+4278): r3 = *(u64 *)(r10 - 0x358)
040fa0 (+4280): *(u64 *)(r10 - 0x120) = r3
040fa8 (+4288): r3 = *(u64 *)(r10 - 0x360)
040fb0 (+4290): *(u64 *)(r10 - 0x128) = r3
040fb8 (+4298): r3 = 0x6
040fc0 (+42a0): *(u32 *)(r10 - 0x130) = r3
040fc8 (+42a8): r3 = r10
040fd0 (+42b0): r3 += -0x130
040fd8 (+42b8): call -0x744c ; call 0x6d80 / window 166
040fe0 (+42c0): if r0 == 0x0 goto +0xa <.text+0x40f18> ; branch 0x41038 / relative 0x4318
040fe8 (+42c8): r1 = *(u64 *)(r10 - 0x930)
040ff0 (+42d0): r2 = r0
040ff8 (+42d8): call 0x8c0b ; call 0x87058 / window 1002
041000 (+42e0): r1 = *(u64 *)(r6 + 0x0)
041008 (+42e8): r1 += 0x1
041010 (+42f0): *(u64 *)(r6 + 0x0) = r1
041018 (+42f8): goto -0x123 <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
041020 (+4300): r1 = 0x1000000000 ll
041030 (+4310): goto -0x98 <.text+0x40a58> ; branch 0x40b78 / relative 0x3e58
041038 (+4318): r1 = *(u64 *)(r6 + 0x0)
041040 (+4320): r1 += 0x1
041048 (+4328): *(u64 *)(r6 + 0x0) = r1
041050 (+4330): r7 = *(u64 *)(r10 - 0x938)
041058 (+4338): r1 = r7
041060 (+4340): call 0x8828 ; call 0x851a8 / window 980
041068 (+4348): r6 = r0
041070 (+4350): r1 = r10
041078 (+4358): r1 += -0x130
041080 (+4360): r2 = r7
041088 (+4368): call 0x888b ; call 0x854e8 / window 986
041090 (+4370): r1 = *(u32 *)(r10 - 0x130)
041098 (+4378): if r1 == 0x16 goto +0x1 <.text+0x40f88> ; branch 0x410a8 / relative 0x4388
0410a0 (+4380): goto +0x1b <.text+0x41060> ; branch 0x41180 / relative 0x4460
0410a8 (+4388): r1 = 0x2
0410b0 (+4390): if r1 > r6 goto +0xc4 <.text+0x415b8> ; branch 0x416d8 / relative 0x49b8
0410b8 (+4398): r4 = *(u64 *)(r10 - 0x128)
0410c0 (+43a0): r1 = r6
0410c8 (+43a8): r1 += -0x2
0410d0 (+43b0): r2 = *(u64 *)(r4 + 0x8)
0410d8 (+43b8): if r2 > r1 goto +0x1 <.text+0x40fc8> ; branch 0x410e8 / relative 0x43c8
0410e0 (+43c0): goto +0xc5 <.text+0x415f0> ; branch 0x41710 / relative 0x49f0
0410e8 (+43c8): r3 = *(u64 *)(r10 - 0x120)
0410f0 (+43d0): r2 = *(u64 *)(r4 + 0x0)
0410f8 (+43d8): r2 += r1
041100 (+43e0): r1 = 0x0
041108 (+43e8): *(u8 *)(r2 + 0x0) = r1
041110 (+43f0): r6 += -0x1
041118 (+43f8): r2 = *(u64 *)(r4 + 0x8)
041120 (+4400): if r2 > r6 goto +0x1 <.text+0x41010> ; branch 0x41130 / relative 0x4410
041128 (+4408): goto +0xbf <.text+0x41608> ; branch 0x41728 / relative 0x4a08
041130 (+4410): r2 = *(u64 *)(r4 + 0x0)
041138 (+4418): r2 += r6
041140 (+4420): *(u8 *)(r2 + 0x0) = r1
041148 (+4428): r1 = 0x16
041150 (+4430): r2 = *(u64 *)(r10 - 0x930)
041158 (+4438): *(u32 *)(r2 + 0x0) = r1
041160 (+4440): r1 = *(u64 *)(r3 + 0x0)
041168 (+4448): r1 += 0x1
041170 (+4450): *(u64 *)(r3 + 0x0) = r1
041178 (+4458): goto -0x14f <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
041180 (+4460): r2 = *(u32 *)(r10 - 0x12c)
041188 (+4468): r3 = *(u64 *)(r10 - 0x128)
041190 (+4470): r4 = *(u64 *)(r10 - 0x120)
041198 (+4478): r5 = *(u64 *)(r10 - 0x118)
0411a0 (+4480): r0 = *(u64 *)(r10 - 0x930)
0411a8 (+4488): *(u64 *)(r0 + 0x18) = r5
0411b0 (+4490): *(u64 *)(r0 + 0x10) = r4
0411b8 (+4498): *(u64 *)(r0 + 0x8) = r3
0411c0 (+44a0): *(u32 *)(r0 + 0x4) = r2
0411c8 (+44a8): *(u32 *)(r0 + 0x0) = r1
0411d0 (+44b0): goto -0x15a <.text+0x405e8> ; branch 0x40708 / relative 0x39e8
0411d8 (+44b8): r2 = *(u32 *)(r10 - 0x34c)
0411e0 (+44c0): r3 = *(u64 *)(r10 - 0x930)
0411e8 (+44c8): *(u32 *)(r3 + 0x1c) = r2
0411f0 (+44d0): r2 = *(u64 *)(r10 - 0x354)
0411f8 (+44d8): *(u64 *)(r3 + 0x14) = r2
041200 (+44e0): r2 = *(u64 *)(r10 - 0x35c)
041208 (+44e8): *(u64 *)(r3 + 0xc) = r2
041210 (+44f0): r2 = *(u64 *)(r10 - 0x364)
041218 (+44f8): goto -0x17e <.text+0x40510> ; branch 0x40630 / relative 0x3910
041220 (+4500): r1 = *(u64 *)(r10 - 0x128)
041228 (+4508): *(u64 *)(r10 - 0x388) = r1
041230 (+4510): r1 = *(u64 *)(r10 - 0x948)
041238 (+4518): *(u64 *)(r10 - 0x370) = r1
041240 (+4520): r1 = *(u64 *)(r10 - 0x940)
041248 (+4528): *(u64 *)(r10 - 0x378) = r1
041250 (+4530): r1 = 0x0
041258 (+4538): *(u64 *)(r10 - 0x380) = r1
041260 (+4540): r1 = 0x6
041268 (+4548): *(u32 *)(r10 - 0x388) = r1
041270 (+4550): r1 = r10
041278 (+4558): r1 += -0x130
041280 (+4560): r2 = *(u64 *)(r10 - 0x938)
041288 (+4568): call 0x884b ; call 0x854e8 / window 986
041290 (+4570): r1 = *(u32 *)(r10 - 0x130)
041298 (+4578): if r1 == 0x16 goto +0x1 <.text+0x41188> ; branch 0x412a8 / relative 0x4588
0412a0 (+4580): goto +0xf <.text+0x41200> ; branch 0x41320 / relative 0x4600
0412a8 (+4588): r6 = *(u64 *)(r10 - 0x120)
0412b0 (+4590): r1 = *(u64 *)(r10 - 0x128)
0412b8 (+4598): r2 = *(u64 *)(r1 + 0x8)
0412c0 (+45a0): r1 = *(u64 *)(r1 + 0x0)
0412c8 (+45a8): r3 = r10
0412d0 (+45b0): r3 += -0x388
0412d8 (+45b8): call -0x74ac ; call 0x6d80 / window 166
0412e0 (+45c0): if r0 == 0x0 goto +0x12 <.text+0x41258> ; branch 0x41378 / relative 0x4658
0412e8 (+45c8): r1 = *(u64 *)(r10 - 0x930)
0412f0 (+45d0): r2 = r0
0412f8 (+45d8): call 0x8bab ; call 0x87058 / window 1002
041300 (+45e0): r1 = *(u64 *)(r6 + 0x0)
041308 (+45e8): r1 += 0x1
041310 (+45f0): *(u64 *)(r6 + 0x0) = r1
041318 (+45f8): goto -0x186 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
041320 (+4600): r2 = *(u32 *)(r10 - 0x12c)
041328 (+4608): r3 = *(u64 *)(r10 - 0x128)
041330 (+4610): r4 = *(u64 *)(r10 - 0x120)
041338 (+4618): r5 = *(u64 *)(r10 - 0x118)
041340 (+4620): r0 = *(u64 *)(r10 - 0x930)
041348 (+4628): *(u64 *)(r0 + 0x18) = r5
041350 (+4630): *(u64 *)(r0 + 0x10) = r4
041358 (+4638): *(u64 *)(r0 + 0x8) = r3
041360 (+4640): *(u32 *)(r0 + 0x4) = r2
041368 (+4648): *(u32 *)(r0 + 0x0) = r1
041370 (+4650): goto -0x191 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
041378 (+4658): r1 = *(u64 *)(r6 + 0x0)
041380 (+4660): r1 += 0x1
041388 (+4668): *(u64 *)(r6 + 0x0) = r1
041390 (+4670): r1 = *(u64 *)(r10 - 0x938)
041398 (+4678): r1 = *(u8 *)(r1 + 0x119)
0413a0 (+4680): if r1 == 0x0 goto +0x14 <.text+0x41328> ; branch 0x41448 / relative 0x4728
0413a8 (+4688): r1 = r10
0413b0 (+4690): r1 += -0x130
0413b8 (+4698): r2 = *(u64 *)(r10 - 0x920)
0413c0 (+46a0): call 0xd86 ; call 0x47ff8 / window 419
0413c8 (+46a8): r6 = *(u32 *)(r10 - 0x28)
0413d0 (+46b0): if r6 != 0x2 goto +0x11 <.text+0x41340> ; branch 0x41460 / relative 0x4740
0413d8 (+46b8): r1 = *(u64 *)(r10 - 0x118)
0413e0 (+46c0): *(u64 *)(r10 - 0x220) = r1
0413e8 (+46c8): r2 = *(u64 *)(r10 - 0x120)
0413f0 (+46d0): *(u64 *)(r10 - 0x228) = r2
0413f8 (+46d8): r3 = *(u64 *)(r10 - 0x128)
041400 (+46e0): *(u64 *)(r10 - 0x230) = r3
041408 (+46e8): r4 = *(u64 *)(r10 - 0x130)
041410 (+46f0): *(u64 *)(r10 - 0x238) = r4
041418 (+46f8): r5 = *(u64 *)(r10 - 0x930)
041420 (+4700): *(u64 *)(r5 + 0x18) = r1
041428 (+4708): *(u64 *)(r5 + 0x10) = r2
041430 (+4710): *(u64 *)(r5 + 0x8) = r3
041438 (+4718): *(u64 *)(r5 + 0x0) = r4
041440 (+4720): goto -0x1ab <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
041448 (+4728): r1 = 0xcb00000000 ll
041458 (+4738): goto -0x11d <.text+0x40a58> ; branch 0x40b78 / relative 0x3e58
041460 (+4740): r1 = r10
041468 (+4748): r1 += -0x238
041470 (+4750): *(u64 *)(r10 - 0x928) = r1
041478 (+4758): r2 = r10
041480 (+4760): r2 += -0x130
041488 (+4768): r3 = 0x108
041490 (+4770): call 0xaf67 ; call 0x98fd0 / window 1246
041498 (+4778): r1 = r10
0414a0 (+4780): r1 += -0x25c
0414a8 (+4788): r2 = r10
0414b0 (+4790): r2 += -0x24
0414b8 (+4798): r3 = 0x24
0414c0 (+47a0): call 0xaf61 ; call 0x98fd0 / window 1246
0414c8 (+47a8): r1 = r10
0414d0 (+47b0): r1 += -0x368
0414d8 (+47b8): r2 = *(u64 *)(r10 - 0x928)
0414e0 (+47c0): r3 = 0x108
0414e8 (+47c8): call 0xaf5c ; call 0x98fd0 / window 1246
0414f0 (+47d0): *(u32 *)(r10 - 0x260) = r6
0414f8 (+47d8): r1 = 0x0
041500 (+47e0): *(u32 *)(r10 - 0x2b4) = r1
041508 (+47e8): r1 = r10
041510 (+47f0): r1 += -0x130
041518 (+47f8): r2 = *(u64 *)(r10 - 0x920)
041520 (+4800): call 0x87f8 ; call 0x854e8 / window 986
041528 (+4808): r1 = *(u32 *)(r10 - 0x130)
041530 (+4810): if r1 == 0x16 goto +0x1 <.text+0x41420> ; branch 0x41540 / relative 0x4820
041538 (+4818): goto +0xf <.text+0x41498> ; branch 0x415b8 / relative 0x4898
041540 (+4820): r6 = *(u64 *)(r10 - 0x120)
041548 (+4828): r1 = *(u64 *)(r10 - 0x128)
041550 (+4830): r2 = *(u64 *)(r1 + 0x8)
041558 (+4838): r1 = *(u64 *)(r1 + 0x0)
041560 (+4840): r3 = r10
041568 (+4848): r3 += -0x368
041570 (+4850): call -0x751b ; call 0x6ca0 / window 162
041578 (+4858): if r0 == 0x0 goto +0x15 <.text+0x41508> ; branch 0x41628 / relative 0x4908
041580 (+4860): r1 = *(u64 *)(r10 - 0x930)
041588 (+4868): r2 = r0
041590 (+4870): call 0x8b58 ; call 0x87058 / window 1002
041598 (+4878): r1 = *(u64 *)(r6 + 0x0)
0415a0 (+4880): r1 += 0x1
0415a8 (+4888): *(u64 *)(r6 + 0x0) = r1
0415b0 (+4890): goto +0xa <.text+0x414e8> ; branch 0x41608 / relative 0x48e8
0415b8 (+4898): r2 = *(u32 *)(r10 - 0x12c)
0415c0 (+48a0): r3 = *(u64 *)(r10 - 0x128)
0415c8 (+48a8): r4 = *(u64 *)(r10 - 0x120)
0415d0 (+48b0): r5 = *(u64 *)(r10 - 0x118)
0415d8 (+48b8): r0 = *(u64 *)(r10 - 0x930)
0415e0 (+48c0): *(u64 *)(r0 + 0x18) = r5
0415e8 (+48c8): *(u64 *)(r0 + 0x10) = r4
0415f0 (+48d0): *(u64 *)(r0 + 0x8) = r3
0415f8 (+48d8): *(u32 *)(r0 + 0x4) = r2
041600 (+48e0): *(u32 *)(r0 + 0x0) = r1
041608 (+48e8): r1 = r10
041610 (+48f0): r1 += -0x320
041618 (+48f8): call -0x7cb0 ; call 0x30a0 / window 59
041620 (+4900): goto -0x1e7 <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
041628 (+4908): r1 = *(u64 *)(r6 + 0x0)
041630 (+4910): r1 += 0x1
041638 (+4918): *(u64 *)(r6 + 0x0) = r1
041640 (+4920): r1 = r10
041648 (+4928): r1 += -0x320
041650 (+4930): call -0x7cb7 ; call 0x30a0 / window 59
041658 (+4938): r3 = *(u64 *)(r10 - 0x938)
041660 (+4940): r2 = *(u64 *)(r3 + 0x0)
041668 (+4948): *(u64 *)(r10 - 0x1000) = r9
041670 (+4950): *(u64 *)(r10 - 0xff8) = r8
041678 (+4958): r1 = r10
041680 (+4960): r1 += -0x130
041688 (+4968): r5 = r10
041690 (+4970): r4 = r7
041698 (+4978): call 0x2ac8 ; call 0x56ce0 / window 458
0416a0 (+4980): r1 = *(u32 *)(r10 - 0x130)
0416a8 (+4988): if r1 == 0x16 goto +0x1 <.text+0x41598> ; branch 0x416b8 / relative 0x4998
0416b0 (+4990): goto -0x219 <.text+0x404d0> ; branch 0x405f0 / relative 0x38d0
0416b8 (+4998): r1 = 0x16
0416c0 (+49a0): r2 = *(u64 *)(r10 - 0x930)
0416c8 (+49a8): *(u32 *)(r2 + 0x0) = r1
0416d0 (+49b0): goto -0x1fd <.text+0x405d0> ; branch 0x406f0 / relative 0x39d0
0416d8 (+49b8): r1 = 0x9a2b0 ll ; pointer 0x9a2b0; data32hex 617474656d707420746f2073756274726163742077697468206f766572666c6f
0416e8 (+49c8): r2 = 0x21
0416f0 (+49d0): r3 = 0x9efd8 ll ; pointer 0x9efd8; data32hex 00000000a0a609004000000000000000390000000a00000000000000a0a60900
041700 (+49e0): call 0x9dc9 ; call 0x90550 / window 1169
041708 (+49e8): call -0x1 ; external abort
041710 (+49f0): r3 = 0x9eff0 ll ; pointer 0x9eff0; data32hex 00000000a0a609004000000000000000390000000500000000000000a0a60900
041720 (+4a00): goto -0x62c <.text+0x3e4a8> ; branch 0x3e5c8 / relative 0x18a8
041728 (+4a08): r1 = r6
041730 (+4a10): r3 = 0x9f008 ll ; pointer 0x9f008; data32hex 00000000a0a6090040000000000000003a0000000500000000000000e0a60900
041740 (+4a20): goto -0x630 <.text+0x3e4a8> ; branch 0x3e5c8 / relative 0x18a8
041748 (+4a28): r6 = r10
041750 (+4a30): r6 += -0x238
041758 (+4a38): r2 = r10
041760 (+4a40): r2 += -0x6b4
041768 (+4a48): r1 = r6
041770 (+4a50): r3 = 0x24
041778 (+4a58): call 0xaf0a ; call 0x98fd0 / window 1246
041780 (+4a60): r7 = r10
041788 (+4a68): r7 += -0x368
041790 (+4a70): r2 = r10
041798 (+4a78): r2 += -0x690
0417a0 (+4a80): r1 = r7
0417a8 (+4a88): r3 = 0x30
0417b0 (+4a90): call 0xaf03 ; call 0x98fd0 / window 1246
0417b8 (+4a98): r9 = r10
0417c0 (+4aa0): r9 += -0x6c8
0417c8 (+4aa8): r1 = r9
0417d0 (+4ab0): r2 = r6
0417d8 (+4ab8): r3 = 0x24
0417e0 (+4ac0): call 0xaefd ; call 0x98fd0 / window 1246
0417e8 (+4ac8): r1 = r10
0417f0 (+4ad0): r1 += -0x6a4
0417f8 (+4ad8): r2 = r7
041800 (+4ae0): r3 = 0x30
041808 (+4ae8): call 0xaef8 ; call 0x98fd0 / window 1246
041810 (+4af0): r6 = r10
041818 (+4af8): r6 += -0x568
041820 (+4b00): r1 = r6
041828 (+4b08): r2 = r9
041830 (+4b10): r3 = 0x54
041838 (+4b18): call 0xaef2 ; call 0x98fd0 / window 1246
041840 (+4b20): r2 = *(u64 *)(r10 - 0x958)
041848 (+4b28): r1 = *(u64 *)(r2 + 0x0)
041850 (+4b30): r1 += -0x1
041858 (+4b38): *(u64 *)(r2 + 0x0) = r1
041860 (+4b40): r1 = *(u64 *)(r10 - 0x950)
041868 (+4b48): *(u32 *)(r10 - 0x6c8) = r1
041870 (+4b50): r1 = r10
041878 (+4b58): r1 += -0x6c4
041880 (+4b60): r2 = r6
041888 (+4b68): r3 = 0x54
041890 (+4b70): call 0xaee7 ; call 0x98fd0 / window 1246
041898 (+4b78): r1 = r10
0418a0 (+4b80): r1 += -0x368
0418a8 (+4b88): r2 = r10
0418b0 (+4b90): r2 += -0x6c8
0418b8 (+4b98): r3 = 0x9eee8 ll ; pointer 0x9eee8; data32hex 0000000016a50900220000000000000041000000240000000000000016a50900
0418c8 (+4ba8): call -0x7acc ; call 0x4270 / window 95
0418d0 (+4bb0): r1 = *(u64 *)(r10 - 0x340)
0418d8 (+4bb8): if r1 == 0x0 goto +0x14 <.text+0x41860> ; branch 0x41980 / relative 0x4c60
0418e0 (+4bc0): r1 = *(u64 *)(r10 - 0x950)
0418e8 (+4bc8): *(u32 *)(r10 - 0x6c8) = r1
0418f0 (+4bd0): r1 = r10
0418f8 (+4bd8): r1 += -0x6c4
041900 (+4be0): r2 = r10
041908 (+4be8): r2 += -0x568
041910 (+4bf0): r3 = 0x54
041918 (+4bf8): call 0xaed6 ; call 0x98fd0 / window 1246
041920 (+4c00): r1 = r10
041928 (+4c08): r1 += -0x368
041930 (+4c10): r2 = r10
041938 (+4c18): r2 += -0x6c8
041940 (+4c20): r3 = 0x9ef20 ll ; pointer 0x9ef20; data32hex 0000000016a50900220000000000000052000000260000000000000016a50900
041950 (+4c30): call -0x7add ; call 0x4270 / window 95
041958 (+4c38): r1 = *(u64 *)(r10 - 0x340)
041960 (+4c40): if r1 == 0x0 goto +0x2c <.text+0x419a8> ; branch 0x41ac8 / relative 0x4da8
041968 (+4c48): r1 = 0xa000000000 ll
041978 (+4c58): goto -0x3e1 <.text+0x3f958> ; branch 0x3fa78 / relative 0x2d58
041980 (+4c60): r1 = *(u64 *)(r10 - 0x950)
041988 (+4c68): *(u32 *)(r10 - 0x6c8) = r1
041990 (+4c70): r1 = r10
041998 (+4c78): r1 += -0x6c4
0419a0 (+4c80): r2 = r10
0419a8 (+4c88): r2 += -0x568
0419b0 (+4c90): r3 = 0x54
0419b8 (+4c98): call 0xaec2 ; call 0x98fd0 / window 1246
0419c0 (+4ca0): r1 = r10
0419c8 (+4ca8): r1 += -0x368
0419d0 (+4cb0): r2 = r10
0419d8 (+4cb8): r2 += -0x6c8
0419e0 (+4cc0): r3 = 0x9ef00 ll ; pointer 0x9ef00; data32hex 0000000016a509002200000000000000430000001700000000000000f8990900
0419f0 (+4cd0): call -0x7af1 ; call 0x4270 / window 95
0419f8 (+4cd8): r1 = *(u32 *)(r10 - 0x368)
041a00 (+4ce0): if r1 == 0x0 goto -0x34b <.text+0x3fe90> ; branch 0x3ffb0 / relative 0x3290
041a08 (+4ce8): r1 = *(u64 *)(r10 - 0x34c)
041a10 (+4cf0): *(u64 *)(r10 - 0x220) = r1
041a18 (+4cf8): r1 = *(u64 *)(r10 - 0x354)
041a20 (+4d00): *(u64 *)(r10 - 0x228) = r1
041a28 (+4d08): r1 = *(u64 *)(r10 - 0x35c)
041a30 (+4d10): *(u64 *)(r10 - 0x230) = r1
041a38 (+4d18): r1 = *(u64 *)(r10 - 0x364)
041a40 (+4d20): *(u64 *)(r10 - 0x238) = r1
041a48 (+4d28): r1 = *(u64 *)(r10 - 0x920)
041a50 (+4d30): r2 = *(u64 *)(r1 + 0x0)
041a58 (+4d38): r1 = r10
041a60 (+4d40): r1 += -0x238
041a68 (+4d48): call 0x8567 ; call 0x845a8 / window 955
041a70 (+4d50): if r0 != 0x0 goto -0x359 <.text+0x3fe90> ; branch 0x3ffb0 / relative 0x3290
041a78 (+4d58): r6 = r10
041a80 (+4d60): r6 += -0x6c8
041a88 (+4d68): r1 = r6
041a90 (+4d70): call 0x8310 ; call 0x83318 / window 915
041a98 (+4d78): r1 = r10
041aa0 (+4d80): r1 += -0x238
041aa8 (+4d88): r2 = r6
041ab0 (+4d90): call 0x855e ; call 0x845a8 / window 955
041ab8 (+4d98): if r0 != 0x0 goto -0x362 <.text+0x3fe90> ; branch 0x3ffb0 / relative 0x3290
041ac0 (+4da0): goto -0x3d <.text+0x417c0> ; branch 0x418e0 / relative 0x4bc0
041ac8 (+4da8): r1 = *(u64 *)(r10 - 0x950)
041ad0 (+4db0): *(u32 *)(r10 - 0x6c8) = r1
041ad8 (+4db8): r1 = r10
041ae0 (+4dc0): r1 += -0x6c4
041ae8 (+4dc8): r2 = r10
041af0 (+4dd0): r2 += -0x568
041af8 (+4dd8): r3 = 0x54
041b00 (+4de0): call 0xae99 ; call 0x98fd0 / window 1246
041b08 (+4de8): r1 = r10
041b10 (+4df0): r1 += -0x368
041b18 (+4df8): r2 = r10
041b20 (+4e00): r2 += -0x6c8
041b28 (+4e08): r3 = 0x9ef38 ll ; pointer 0x9ef38; data32hex 0000000016a50900220000000000000054000000260000000000000038a50900
041b38 (+4e18): call -0x7b1a ; call 0x4270 / window 95
041b40 (+4e20): r1 = *(u32 *)(r10 - 0x368)
041b48 (+4e28): r2 = 0x0
041b50 (+4e30): r3 = *(u64 *)(r10 - 0x930)
041b58 (+4e38): *(u32 *)(r3 + 0x0) = r2
041b60 (+4e40): if r1 != 0x0 goto +0x2 <.text+0x41a58> ; branch 0x41b78 / relative 0x4e58
041b68 (+4e48): r1 = 0xca
041b70 (+4e50): goto +0x1 <.text+0x41a60> ; branch 0x41b80 / relative 0x4e60
041b78 (+4e58): r1 = 0xa
041b80 (+4e60): r2 = *(u64 *)(r10 - 0x930)
041b88 (+4e68): *(u32 *)(r2 + 0x4) = r1
041b90 (+4e70): goto -0x422 <.text+0x3f968> ; branch 0x3fa88 / relative 0x2d68
