0030a0: r6 = r1
0030a8: call -0x7
0030b0: r1 = r6
0030b8: r1 += 0x18
0030c0: call -0xa
0030c8: r1 = r6
0030d0: r1 += 0x30
0030d8: call -0xd
0030e0: r6 += 0x50
0030e8: r1 = r6
0030f0: call -0x41
0030f8: exit
