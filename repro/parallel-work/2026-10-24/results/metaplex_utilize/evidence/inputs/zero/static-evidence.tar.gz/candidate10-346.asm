039c60 (+0000): r9 = r5
039c68 (+0008): r7 = r4
039c70 (+0010): r8 = r2
039c78 (+0018): r6 = r1
039c80 (+0020): r1 = 0x0
039c88 (+0028): *(u64 *)(r10 - 0x568) = r1
039c90 (+0030): *(u64 *)(r10 - 0x570) = r3
039c98 (+0038): r1 = r7
039ca0 (+0040): r1 *= 0x30
039ca8 (+0048): r3 += r1
039cb0 (+0050): *(u64 *)(r10 - 0x578) = r3
039cb8 (+0058): r1 = r10
039cc0 (+0060): r1 += -0x1f0
039cc8 (+0068): r2 = r10
039cd0 (+0070): r2 += -0x578
039cd8 (+0078): call -0x7170 ; call 0x1160 / window 20
039ce0 (+0080): r1 = *(u32 *)(r10 - 0x1f0)
039ce8 (+0088): if r1 != 0x16 goto +0x64 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039cf0 (+0090): r1 = *(u64 *)(r10 - 0x1e8)
039cf8 (+0098): *(u64 *)(r10 - 0x598) = r1
039d00 (+00a0): r1 = r10
039d08 (+00a8): r1 += -0x1f0
039d10 (+00b0): r2 = r10
039d18 (+00b8): r2 += -0x578
039d20 (+00c0): call -0x7179 ; call 0x1160 / window 20
039d28 (+00c8): r1 = *(u32 *)(r10 - 0x1f0)
039d30 (+00d0): if r1 == 0x16 goto +0x1 <.text+0x39c20> ; branch 0x39d40 / relative 0xe0
039d38 (+00d8): goto +0x5a <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039d40 (+00e0): r1 = *(u64 *)(r10 - 0x1e8)
039d48 (+00e8): *(u64 *)(r10 - 0x5a0) = r1
039d50 (+00f0): r1 = r10
039d58 (+00f8): r1 += -0x1f0
039d60 (+0100): r2 = r10
039d68 (+0108): r2 += -0x578
039d70 (+0110): call -0x7183 ; call 0x1160 / window 20
039d78 (+0118): r1 = *(u32 *)(r10 - 0x1f0)
039d80 (+0120): if r1 == 0x16 goto +0x1 <.text+0x39c70> ; branch 0x39d90 / relative 0x130
039d88 (+0128): goto +0x50 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039d90 (+0130): r1 = *(u64 *)(r10 - 0x1e8)
039d98 (+0138): *(u64 *)(r10 - 0x5a8) = r1
039da0 (+0140): r1 = r10
039da8 (+0148): r1 += -0x1f0
039db0 (+0150): r2 = r10
039db8 (+0158): r2 += -0x578
039dc0 (+0160): call -0x718d ; call 0x1160 / window 20
039dc8 (+0168): r1 = *(u32 *)(r10 - 0x1f0)
039dd0 (+0170): if r1 == 0x16 goto +0x1 <.text+0x39cc0> ; branch 0x39de0 / relative 0x180
039dd8 (+0178): goto +0x46 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039de0 (+0180): r1 = *(u64 *)(r10 - 0x1e8)
039de8 (+0188): *(u64 *)(r10 - 0x5b0) = r1
039df0 (+0190): r1 = r10
039df8 (+0198): r1 += -0x1f0
039e00 (+01a0): r2 = r10
039e08 (+01a8): r2 += -0x578
039e10 (+01b0): call -0x7197 ; call 0x1160 / window 20
039e18 (+01b8): r1 = *(u32 *)(r10 - 0x1f0)
039e20 (+01c0): if r1 == 0x16 goto +0x1 <.text+0x39d10> ; branch 0x39e30 / relative 0x1d0
039e28 (+01c8): goto +0x3c <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039e30 (+01d0): r1 = *(u64 *)(r10 - 0x1e8)
039e38 (+01d8): *(u64 *)(r10 - 0x5b8) = r1
039e40 (+01e0): r1 = r10
039e48 (+01e8): r1 += -0x1f0
039e50 (+01f0): r2 = r10
039e58 (+01f8): r2 += -0x578
039e60 (+0200): call -0x71a1 ; call 0x1160 / window 20
039e68 (+0208): r1 = *(u32 *)(r10 - 0x1f0)
039e70 (+0210): if r1 == 0x16 goto +0x1 <.text+0x39d60> ; branch 0x39e80 / relative 0x220
039e78 (+0218): goto +0x32 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039e80 (+0220): r1 = *(u64 *)(r10 - 0x1e8)
039e88 (+0228): *(u64 *)(r10 - 0x5c0) = r1
039e90 (+0230): r1 = r10
039e98 (+0238): r1 += -0x1f0
039ea0 (+0240): r2 = r10
039ea8 (+0248): r2 += -0x578
039eb0 (+0250): call -0x71ab ; call 0x1160 / window 20
039eb8 (+0258): r1 = *(u32 *)(r10 - 0x1f0)
039ec0 (+0260): if r1 == 0x16 goto +0x1 <.text+0x39db0> ; branch 0x39ed0 / relative 0x270
039ec8 (+0268): goto +0x28 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039ed0 (+0270): r1 = r10
039ed8 (+0278): r1 += -0x1f0
039ee0 (+0280): r2 = r10
039ee8 (+0288): r2 += -0x578
039ef0 (+0290): call -0x71b3 ; call 0x1160 / window 20
039ef8 (+0298): r1 = *(u32 *)(r10 - 0x1f0)
039f00 (+02a0): if r1 == 0x16 goto +0x1 <.text+0x39df0> ; branch 0x39f10 / relative 0x2b0
039f08 (+02a8): goto +0x20 <.text+0x39ef0> ; branch 0x3a010 / relative 0x3b0
039f10 (+02b0): r1 = r10
039f18 (+02b8): r1 += -0x578
039f20 (+02c0): call -0x6bf9 ; call 0x3f60 / window 89
039f28 (+02c8): *(u64 *)(r10 - 0x5c8) = r0
039f30 (+02d0): r1 = r10
039f38 (+02d8): r1 += -0x1f0
039f40 (+02e0): r2 = *(u64 *)(r10 - 0x598)
039f48 (+02e8): call 0x1c15 ; call 0x47ff8 / window 419
039f50 (+02f0): r2 = 0x1
039f58 (+02f8): r1 = 0x1
039f60 (+0300): if r7 == 0xb goto +0x1 <.text+0x39e50> ; branch 0x39f70 / relative 0x310
039f68 (+0308): r1 = 0x0
039f70 (+0310): if r7 == 0xa goto +0x1 <.text+0x39e60> ; branch 0x39f80 / relative 0x320
039f78 (+0318): r2 = 0x0
039f80 (+0320): r3 = *(u64 *)(r10 - 0x5c8)
039f88 (+0328): if r3 == 0x0 goto +0x1 <.text+0x39e78> ; branch 0x39f98 / relative 0x338
039f90 (+0330): r2 = r1
039f98 (+0338): r7 = *(u32 *)(r10 - 0xe8)
039fa0 (+0340): if r7 != 0x2 goto +0x19 <.text+0x39f50> ; branch 0x3a070 / relative 0x410
039fa8 (+0348): r1 = *(u64 *)(r10 - 0x1d8)
039fb0 (+0350): *(u64 *)(r10 - 0x410) = r1
039fb8 (+0358): r2 = *(u64 *)(r10 - 0x1e0)
039fc0 (+0360): *(u64 *)(r10 - 0x418) = r2
039fc8 (+0368): r3 = *(u64 *)(r10 - 0x1e8)
039fd0 (+0370): *(u64 *)(r10 - 0x420) = r3
039fd8 (+0378): r4 = *(u64 *)(r10 - 0x1f0)
039fe0 (+0380): *(u64 *)(r10 - 0x428) = r4
039fe8 (+0388): *(u64 *)(r6 + 0x18) = r1
039ff0 (+0390): *(u64 *)(r6 + 0x10) = r2
039ff8 (+0398): *(u64 *)(r6 + 0x8) = r3
03a000 (+03a0): *(u64 *)(r6 + 0x0) = r4
03a008 (+03a8): goto +0xb <.text+0x39f48> ; branch 0x3a068 / relative 0x408
03a010 (+03b0): r2 = *(u64 *)(r10 - 0x1e0)
03a018 (+03b8): *(u64 *)(r10 - 0x428) = r2
03a020 (+03c0): r3 = *(u64 *)(r10 - 0x1d8)
03a028 (+03c8): *(u64 *)(r10 - 0x420) = r3
03a030 (+03d0): r4 = *(u32 *)(r10 - 0x1ec)
03a038 (+03d8): r5 = *(u64 *)(r10 - 0x1e8)
03a040 (+03e0): *(u64 *)(r6 + 0x18) = r3
03a048 (+03e8): *(u64 *)(r6 + 0x10) = r2
03a050 (+03f0): *(u64 *)(r6 + 0x8) = r5
03a058 (+03f8): *(u32 *)(r6 + 0x4) = r4
03a060 (+0400): *(u32 *)(r6 + 0x0) = r1
03a068 (+0408): exit
03a070 (+0410): *(u64 *)(r10 - 0x5d0) = r2
03a078 (+0418): r1 = r10
03a080 (+0420): r1 += -0x428
03a088 (+0428): *(u64 *)(r10 - 0x5c8) = r1
03a090 (+0430): r2 = r10
03a098 (+0438): r2 += -0x1f0
03a0a0 (+0440): r3 = 0x108
03a0a8 (+0448): call 0xbde4 ; call 0x98fd0 / window 1246
03a0b0 (+0450): r1 = r10
03a0b8 (+0458): r1 += -0x44c
03a0c0 (+0460): r2 = r10
03a0c8 (+0468): r2 += -0xe4
03a0d0 (+0470): r3 = 0x24
03a0d8 (+0478): call 0xbdde ; call 0x98fd0 / window 1246
03a0e0 (+0480): r1 = r10
03a0e8 (+0488): r1 += -0x558
03a0f0 (+0490): r2 = *(u64 *)(r10 - 0x5c8)
03a0f8 (+0498): r3 = 0x108
03a100 (+04a0): call 0xbdd9 ; call 0x98fd0 / window 1246
03a108 (+04a8): *(u32 *)(r10 - 0x450) = r7
03a110 (+04b0): r1 = *(u32 *)(r10 - 0x478)
03a118 (+04b8): if r1 == 0x3 goto +0x6 <.text+0x3a030> ; branch 0x3a150 / relative 0x4f0
03a120 (+04c0): r1 = *(u32 *)(r10 - 0x4a4)
03a128 (+04c8): if r1 == 0x6 goto +0x1 <.text+0x3a018> ; branch 0x3a138 / relative 0x4d8
03a130 (+04d0): goto +0xa <.text+0x3a068> ; branch 0x3a188 / relative 0x528
03a138 (+04d8): r1 = 0x8700000000 ll
03a148 (+04e8): goto +0x2 <.text+0x3a040> ; branch 0x3a160 / relative 0x500
03a150 (+04f0): r1 = 0x5500000000 ll
03a160 (+0500): *(u64 *)(r6 + 0x0) = r1
03a168 (+0508): r1 = r10
03a170 (+0510): r1 += -0x510
03a178 (+0518): call -0x6e1c ; call 0x30a0 / window 59
03a180 (+0520): goto -0x24 <.text+0x39f48> ; branch 0x3a068 / relative 0x408
03a188 (+0528): if r1 > 0x5 goto -0xb <.text+0x3a018> ; branch 0x3a138 / relative 0x4d8
03a190 (+0530): r2 = 0x1
03a198 (+0538): r2 <<= r1
03a1a0 (+0540): r2 &= 0x39
03a1a8 (+0548): if r2 != 0x0 goto +0x1 <.text+0x3a098> ; branch 0x3a1b8 / relative 0x558
03a1b0 (+0550): goto -0x10 <.text+0x3a018> ; branch 0x3a138 / relative 0x4d8
03a1b8 (+0558): r1 = *(u64 *)(r10 - 0x5c0)
03a1c0 (+0560): r1 = *(u64 *)(r1 + 0x0)
03a1c8 (+0568): r2 = 0x99a78 ll ; pointer 0x99a78; data32hex 06ddf6e1d765a193d9cbe146ceeb79ac1cb485ed5f5b37913a8cf5857eff00a9
03a1d8 (+0578): call -0x6e9a ; call 0x2d10 / window 44
03a1e0 (+0580): if r0 != 0x0 goto +0x1 <.text+0x3a0d0> ; branch 0x3a1f0 / relative 0x590
03a1e8 (+0588): goto +0x3 <.text+0x3a0e8> ; branch 0x3a208 / relative 0x5a8
03a1f0 (+0590): r1 = 0x3e00000000 ll
03a200 (+05a0): goto -0x15 <.text+0x3a040> ; branch 0x3a160 / relative 0x500
03a208 (+05a8): r1 = r10
03a210 (+05b0): r1 += -0x1f0
03a218 (+05b8): r2 = *(u64 *)(r10 - 0x5b0)
03a220 (+05c0): call 0x789b ; call 0x76700 / window 773
03a228 (+05c8): r1 = *(u32 *)(r10 - 0x1f0)
03a230 (+05d0): if r1 == 0x16 goto +0x1 <.text+0x3a120> ; branch 0x3a240 / relative 0x5e0
03a238 (+05d8): goto +0x25 <.text+0x3a248> ; branch 0x3a368 / relative 0x708
03a240 (+05e0): r1 = *(u64 *)(r10 - 0x5a8)
03a248 (+05e8): *(u64 *)(r10 - 0xff8) = r1
03a250 (+05f0): r1 = *(u64 *)(r10 - 0x5a0)
03a258 (+05f8): *(u64 *)(r10 - 0xff0) = r1
03a260 (+0600): r1 = r10
03a268 (+0608): r1 += -0x558
03a270 (+0610): *(u64 *)(r10 - 0x1000) = r1
03a278 (+0618): r1 = r10
03a280 (+0620): r1 += -0x1f0
03a288 (+0628): r5 = r10
03a290 (+0630): r2 = r8
03a298 (+0638): r3 = *(u64 *)(r10 - 0x5b8)
03a2a0 (+0640): r7 = *(u64 *)(r10 - 0x598)
03a2a8 (+0648): r4 = r7
03a2b0 (+0650): call -0x5698 ; call 0xedf8 / window 264
03a2b8 (+0658): r1 = *(u32 *)(r10 - 0x1f0)
03a2c0 (+0660): if r1 == 0x16 goto +0x1 <.text+0x3a1b0> ; branch 0x3a2d0 / relative 0x670
03a2c8 (+0668): goto +0x13 <.text+0x3a248> ; branch 0x3a368 / relative 0x708
03a2d0 (+0670): r1 = r10
03a2d8 (+0678): r1 += -0x1f0
03a2e0 (+0680): r2 = r7
03a2e8 (+0688): call 0x1ba1 ; call 0x47ff8 / window 419
03a2f0 (+0690): r7 = *(u32 *)(r10 - 0xe8)
03a2f8 (+0698): if r7 != 0x2 goto +0x1b <.text+0x3a2b8> ; branch 0x3a3d8 / relative 0x778
03a300 (+06a0): r1 = *(u64 *)(r10 - 0x1d8)
03a308 (+06a8): *(u64 *)(r10 - 0x2e0) = r1
03a310 (+06b0): r2 = *(u64 *)(r10 - 0x1e0)
03a318 (+06b8): *(u64 *)(r10 - 0x2e8) = r2
03a320 (+06c0): r3 = *(u64 *)(r10 - 0x1e8)
03a328 (+06c8): *(u64 *)(r10 - 0x2f0) = r3
03a330 (+06d0): r4 = *(u64 *)(r10 - 0x1f0)
03a338 (+06d8): *(u64 *)(r10 - 0x2f8) = r4
03a340 (+06e0): *(u64 *)(r6 + 0x18) = r1
03a348 (+06e8): *(u64 *)(r6 + 0x10) = r2
03a350 (+06f0): *(u64 *)(r6 + 0x8) = r3
03a358 (+06f8): *(u64 *)(r6 + 0x0) = r4
03a360 (+0700): goto -0x40 <.text+0x3a048> ; branch 0x3a168 / relative 0x508
03a368 (+0708): r2 = *(u32 *)(r10 - 0x1d4)
03a370 (+0710): *(u32 *)(r10 - 0x410) = r2
03a378 (+0718): r3 = *(u64 *)(r10 - 0x1dc)
03a380 (+0720): *(u64 *)(r10 - 0x418) = r3
03a388 (+0728): r4 = *(u64 *)(r10 - 0x1e4)
03a390 (+0730): *(u64 *)(r10 - 0x420) = r4
03a398 (+0738): r5 = *(u64 *)(r10 - 0x1ec)
03a3a0 (+0740): *(u64 *)(r10 - 0x428) = r5
03a3a8 (+0748): *(u32 *)(r6 + 0x1c) = r2
03a3b0 (+0750): *(u64 *)(r6 + 0x14) = r3
03a3b8 (+0758): *(u64 *)(r6 + 0xc) = r4
03a3c0 (+0760): *(u64 *)(r6 + 0x4) = r5
03a3c8 (+0768): *(u32 *)(r6 + 0x0) = r1
03a3d0 (+0770): goto -0x4e <.text+0x3a048> ; branch 0x3a168 / relative 0x508
03a3d8 (+0778): r1 = r10
03a3e0 (+0780): r1 += -0x2f8
03a3e8 (+0788): *(u64 *)(r10 - 0x5c8) = r1
03a3f0 (+0790): r2 = r10
03a3f8 (+0798): r2 += -0x1f0
03a400 (+07a0): r3 = 0x108
03a408 (+07a8): call 0xbd78 ; call 0x98fd0 / window 1246
03a410 (+07b0): r1 = r10
03a418 (+07b8): r1 += -0x31c
03a420 (+07c0): r2 = r10
03a428 (+07c8): r2 += -0xe4
03a430 (+07d0): r3 = 0x24
03a438 (+07d8): call 0xbd72 ; call 0x98fd0 / window 1246
03a440 (+07e0): r1 = r10
03a448 (+07e8): r1 += -0x428
03a450 (+07f0): r2 = *(u64 *)(r10 - 0x5c8)
03a458 (+07f8): r3 = 0x108
03a460 (+0800): call 0xbd6d ; call 0x98fd0 / window 1246
03a468 (+0808): *(u32 *)(r10 - 0x320) = r7
03a470 (+0810): r1 = *(u64 *)(r10 - 0x338)
03a478 (+0818): *(u64 *)(r10 - 0x1e0) = r1
03a480 (+0820): r1 = *(u64 *)(r10 - 0x340)
03a488 (+0828): *(u64 *)(r10 - 0x1e8) = r1
03a490 (+0830): r1 = *(u64 *)(r10 - 0x348)
03a498 (+0838): *(u64 *)(r10 - 0x1f0) = r1
03a4a0 (+0840): r1 = r10
03a4a8 (+0848): r1 += -0xc0
03a4b0 (+0850): r2 = r10
03a4b8 (+0858): r2 += -0x1f0
03a4c0 (+0860): r3 = 0x9f380 ll ; pointer 0x9f380; data32hex 00000000a9a909002500000000000000510000002700000000000000cea90900
03a4d0 (+0870): call -0x6c43 ; call 0x42c0 / window 96
03a4d8 (+0878): r1 = *(u32 *)(r10 - 0xc0)
03a4e0 (+0880): *(u64 *)(r10 - 0x5c8) = r1
03a4e8 (+0888): if r9 == 0x0 goto +0xa <.text+0x3a420> ; branch 0x3a540 / relative 0x8e0
03a4f0 (+0890): r1 = *(u64 *)(r10 - 0xb0)
03a4f8 (+0898): if r9 > r1 goto +0x4 <.text+0x3a400> ; branch 0x3a520 / relative 0x8c0
03a500 (+08a0): r7 = *(u64 *)(r10 - 0xb8)
03a508 (+08a8): if r9 > r7 goto +0x2 <.text+0x3a400> ; branch 0x3a520 / relative 0x8c0
03a510 (+08b0): if r9 > r7 goto +0x1 <.text+0x3a400> ; branch 0x3a520 / relative 0x8c0
03a518 (+08b8): goto +0x6 <.text+0x3a430> ; branch 0x3a550 / relative 0x8f0
03a520 (+08c0): r1 = 0x5600000000 ll
03a530 (+08d0): *(u64 *)(r6 + 0x0) = r1
03a538 (+08d8): goto +0x152 <.text+0x3aeb0> ; branch 0x3afd0 / relative 0x1370
03a540 (+08e0): r7 = *(u64 *)(r10 - 0xb8)
03a548 (+08e8): goto -0x8 <.text+0x3a3f0> ; branch 0x3a510 / relative 0x8b0
03a550 (+08f0): r1 = *(u64 *)(r10 - 0xb0)
03a558 (+08f8): *(u64 *)(r10 - 0x338) = r1
03a560 (+0900): r1 = *(u64 *)(r10 - 0x5c8)
03a568 (+0908): *(u32 *)(r10 - 0x348) = r1
03a570 (+0910): r1 = r7
03a578 (+0918): r1 -= r9
03a580 (+0920): *(u64 *)(r10 - 0x340) = r1
03a588 (+0928): r1 = *(u64 *)(r10 - 0x5d0)
03a590 (+0930): r1 &= 0x1
03a598 (+0938): if r1 != 0x0 goto +0x8 <.text+0x3a4c0> ; branch 0x3a5e0 / relative 0x980
03a5a0 (+0940): r1 = *(u64 *)(r10 - 0x5b0)
03a5a8 (+0948): r2 = *(u64 *)(r10 - 0x5b8)
03a5b0 (+0950): call -0x6f1c ; call 0x2cd8 / window 42
03a5b8 (+0958): if r0 != 0x0 goto +0x1 <.text+0x3a4a8> ; branch 0x3a5c8 / relative 0x968
03a5c0 (+0960): goto +0x85 <.text+0x3a8d0> ; branch 0x3a9f0 / relative 0xd90
03a5c8 (+0968): r1 = 0x6200000000 ll
03a5d8 (+0978): goto -0x16 <.text+0x3a410> ; branch 0x3a530 / relative 0x8d0
03a5e0 (+0980): r1 = r10
03a5e8 (+0988): r1 += -0x1f0
03a5f0 (+0990): r2 = r10
03a5f8 (+0998): r2 += -0x578
03a600 (+09a0): call -0x7295 ; call 0x1160 / window 20
03a608 (+09a8): r1 = *(u32 *)(r10 - 0x1f0)
03a610 (+09b0): if r1 != 0x16 goto +0x12c <.text+0x3ae58> ; branch 0x3af78 / relative 0x1318
03a618 (+09b8): r2 = *(u64 *)(r10 - 0x1e8)
03a620 (+09c0): r1 = r10
03a628 (+09c8): r1 += -0x1f0
03a630 (+09d0): *(u64 *)(r10 - 0x5d8) = r2
03a638 (+09d8): call 0x95d5 ; call 0x854e8 / window 986
03a640 (+09e0): r1 = *(u32 *)(r10 - 0x1f0)
03a648 (+09e8): if r1 == 0x16 goto +0x1 <.text+0x3a538> ; branch 0x3a658 / relative 0x9f8
03a650 (+09f0): goto +0x8b <.text+0x3a990> ; branch 0x3aab0 / relative 0xe50
03a658 (+09f8): r1 = *(u64 *)(r10 - 0x1e0)
03a660 (+0a00): *(u64 *)(r10 - 0x5e0) = r1
03a668 (+0a08): r1 = *(u64 *)(r10 - 0x1e8)
03a670 (+0a10): *(u64 *)(r10 - 0x5e8) = r1
03a678 (+0a18): r1 = *(u64 *)(r1 + 0x8)
03a680 (+0a20): if r1 == 0x0 goto +0x39 <.text+0x3a730> ; branch 0x3a850 / relative 0xbf0
03a688 (+0a28): r1 = r10
03a690 (+0a30): r1 += -0x1f0
03a698 (+0a38): r2 = *(u64 *)(r10 - 0x5d8)
03a6a0 (+0a40): r3 = r8
03a6a8 (+0a48): call -0x5550 ; call 0xfc30 / window 275
03a6b0 (+0a50): r1 = *(u32 *)(r10 - 0x1f0)
03a6b8 (+0a58): if r1 == 0x16 goto +0x1 <.text+0x3a5a8> ; branch 0x3a6c8 / relative 0xa68
03a6c0 (+0a60): goto +0x24 <.text+0x3a6c8> ; branch 0x3a7e8 / relative 0xb88
03a6c8 (+0a68): r1 = r10
03a6d0 (+0a70): r1 += -0x1f0
03a6d8 (+0a78): r2 = r8
03a6e0 (+0a80): r3 = *(u64 *)(r10 - 0x5d8)
03a6e8 (+0a88): r4 = *(u64 *)(r10 - 0x5b0)
03a6f0 (+0a90): r5 = *(u64 *)(r10 - 0x5a8)
03a6f8 (+0a98): call -0x54e8 ; call 0xffc0 / window 281
03a700 (+0aa0): r1 = *(u32 *)(r10 - 0x1f0)
03a708 (+0aa8): if r1 == 0x16 goto +0x1 <.text+0x3a5f8> ; branch 0x3a718 / relative 0xab8
03a710 (+0ab0): goto +0x2b <.text+0x3a750> ; branch 0x3a870 / relative 0xc10
03a718 (+0ab8): r1 = *(u8 *)(r10 - 0x1ec)
03a720 (+0ac0): *(u64 *)(r10 - 0x5b0) = r1
03a728 (+0ac8): r1 = *(u64 *)(r10 - 0x5e8)
03a730 (+0ad0): r3 = *(u64 *)(r1 + 0x8)
03a738 (+0ad8): r2 = *(u64 *)(r1 + 0x0)
03a740 (+0ae0): r1 = r10
03a748 (+0ae8): r1 += -0x1f0
03a750 (+0af0): call 0x15d9 ; call 0x45620 / window 396
03a758 (+0af8): r1 = *(u32 *)(r10 - 0x1f0)
03a760 (+0b00): if r1 == 0x16 goto +0x1 <.text+0x3a650> ; branch 0x3a770 / relative 0xb10
03a768 (+0b08): goto +0xf <.text+0x3a6c8> ; branch 0x3a7e8 / relative 0xb88
03a770 (+0b10): r1 = *(u64 *)(r10 - 0x1e0)
03a778 (+0b18): *(u64 *)(r10 - 0x28) = r1
03a780 (+0b20): r2 = *(u64 *)(r10 - 0x1e8)
03a788 (+0b28): *(u64 *)(r10 - 0x30) = r2
03a790 (+0b30): r1 = *(u64 *)(r10 - 0x1d8)
03a798 (+0b38): *(u64 *)(r10 - 0x20) = r1
03a7a0 (+0b40): r1 &= 0xff
03a7a8 (+0b48): if r1 != 0x0 goto +0x2b <.text+0x3a7e8> ; branch 0x3a908 / relative 0xca8
03a7b0 (+0b50): r2 <<= 0x20
03a7b8 (+0b58): r2 >>= 0x20
03a7c0 (+0b60): if r2 == 0x8 goto +0x1 <.text+0x3a6b0> ; branch 0x3a7d0 / relative 0xb70
03a7c8 (+0b68): goto +0x27 <.text+0x3a7e8> ; branch 0x3a908 / relative 0xca8
03a7d0 (+0b70): r1 = *(u64 *)(r10 - 0x5b0)
03a7d8 (+0b78): *(u8 *)(r10 - 0x20) = r1
03a7e0 (+0b80): goto +0x27 <.text+0x3a800> ; branch 0x3a920 / relative 0xcc0
03a7e8 (+0b88): r2 = *(u32 *)(r10 - 0x1d4)
03a7f0 (+0b90): *(u32 *)(r10 - 0x2e0) = r2
03a7f8 (+0b98): r3 = *(u64 *)(r10 - 0x1dc)
03a800 (+0ba0): *(u64 *)(r10 - 0x2e8) = r3
03a808 (+0ba8): r4 = *(u64 *)(r10 - 0x1e4)
03a810 (+0bb0): *(u64 *)(r10 - 0x2f0) = r4
03a818 (+0bb8): r5 = *(u64 *)(r10 - 0x1ec)
03a820 (+0bc0): *(u64 *)(r10 - 0x2f8) = r5
03a828 (+0bc8): *(u32 *)(r6 + 0x1c) = r2
03a830 (+0bd0): *(u64 *)(r6 + 0x14) = r3
03a838 (+0bd8): *(u64 *)(r6 + 0xc) = r4
03a840 (+0be0): *(u64 *)(r6 + 0x4) = r5
03a848 (+0be8): goto +0x14 <.text+0x3a7d0> ; branch 0x3a8f0 / relative 0xc90
03a850 (+0bf0): r1 = 0x5400000000 ll
03a860 (+0c00): *(u64 *)(r6 + 0x0) = r1
03a868 (+0c08): goto +0x11 <.text+0x3a7d8> ; branch 0x3a8f8 / relative 0xc98
03a870 (+0c10): r2 = *(u32 *)(r10 - 0x1d4)
03a878 (+0c18): *(u32 *)(r10 - 0x2e1) = r2
03a880 (+0c20): r2 = *(u64 *)(r10 - 0x1db)
03a888 (+0c28): *(u64 *)(r10 - 0x2e8) = r2
03a890 (+0c30): r2 = *(u64 *)(r10 - 0x1eb)
03a898 (+0c38): *(u64 *)(r10 - 0x2f8) = r2
03a8a0 (+0c40): r3 = *(u64 *)(r10 - 0x1e3)
03a8a8 (+0c48): *(u64 *)(r10 - 0x2f0) = r3
03a8b0 (+0c50): r4 = *(u8 *)(r10 - 0x1ec)
03a8b8 (+0c58): r5 = *(u32 *)(r10 - 0x2e1)
03a8c0 (+0c60): *(u32 *)(r6 + 0x1c) = r5
03a8c8 (+0c68): r5 = *(u64 *)(r10 - 0x2e8)
03a8d0 (+0c70): *(u64 *)(r6 + 0x15) = r5
03a8d8 (+0c78): *(u64 *)(r6 + 0xd) = r3
03a8e0 (+0c80): *(u64 *)(r6 + 0x5) = r2
03a8e8 (+0c88): *(u8 *)(r6 + 0x4) = r4
03a8f0 (+0c90): *(u32 *)(r6 + 0x0) = r1
03a8f8 (+0c98): r2 = *(u64 *)(r10 - 0x5e0)
03a900 (+0ca0): goto +0x31 <.text+0x3a970> ; branch 0x3aa90 / relative 0xe30
03a908 (+0ca8): r2 = *(u64 *)(r10 - 0x5b0)
03a910 (+0cb0): if r1 == r2 goto +0x1 <.text+0x3a800> ; branch 0x3a920 / relative 0xcc0
03a918 (+0cb8): goto +0x13 <.text+0x3a898> ; branch 0x3a9b8 / relative 0xd58
03a920 (+0cc0): r1 = *(u64 *)(r10 - 0x28)
03a928 (+0cc8): if r9 > r1 goto +0x1 <.text+0x3a818> ; branch 0x3a938 / relative 0xcd8
03a930 (+0cd0): goto +0x3 <.text+0x3a830> ; branch 0x3a950 / relative 0xcf0
03a938 (+0cd8): r1 = 0x5600000000 ll
03a948 (+0ce8): goto -0x1e <.text+0x3a740> ; branch 0x3a860 / relative 0xc00
03a950 (+0cf0): r1 -= r9
03a958 (+0cf8): *(u64 *)(r10 - 0x28) = r1
03a960 (+0d00): r1 = *(u64 *)(r10 - 0x5e8)
03a968 (+0d08): r2 = *(u64 *)(r1 + 0x8)
03a970 (+0d10): r1 = *(u64 *)(r1 + 0x0)
03a978 (+0d18): r3 = r10
03a980 (+0d20): r3 += -0x30
03a988 (+0d28): call -0x676d ; call 0x6e28 / window 169
03a990 (+0d30): if r0 == 0x0 goto +0x7 <.text+0x3a8b0> ; branch 0x3a9d0 / relative 0xd70
03a998 (+0d38): r1 = r6
03a9a0 (+0d40): r2 = r0
03a9a8 (+0d48): call 0x98d5 ; call 0x87058 / window 1002
03a9b0 (+0d50): goto -0x18 <.text+0x3a7d8> ; branch 0x3a8f8 / relative 0xc98
03a9b8 (+0d58): r1 = 0x5900000000 ll
03a9c8 (+0d68): goto -0x2e <.text+0x3a740> ; branch 0x3a860 / relative 0xc00
03a9d0 (+0d70): r2 = *(u64 *)(r10 - 0x5e0)
03a9d8 (+0d78): r1 = *(u64 *)(r2 + 0x0)
03a9e0 (+0d80): r1 += 0x1
03a9e8 (+0d88): *(u64 *)(r2 + 0x0) = r1
03a9f0 (+0d90): r1 = r10
03a9f8 (+0d98): r1 += -0x1f0
03aa00 (+0da0): r2 = *(u64 *)(r10 - 0x598)
03aa08 (+0da8): call 0x955b ; call 0x854e8 / window 986
03aa10 (+0db0): r1 = *(u32 *)(r10 - 0x1f0)
03aa18 (+0db8): if r1 == 0x16 goto +0x1 <.text+0x3a908> ; branch 0x3aa28 / relative 0xdc8
03aa20 (+0dc0): goto +0x11 <.text+0x3a990> ; branch 0x3aab0 / relative 0xe50
03aa28 (+0dc8): r1 = *(u64 *)(r10 - 0x1e0)
03aa30 (+0dd0): *(u64 *)(r10 - 0x598) = r1
03aa38 (+0dd8): r1 = *(u64 *)(r10 - 0x1e8)
03aa40 (+0de0): r3 = *(u64 *)(r1 + 0x8)
03aa48 (+0de8): r2 = *(u64 *)(r1 + 0x0)
03aa50 (+0df0): r1 = r10
03aa58 (+0df8): r1 += -0x428
03aa60 (+0e00): call 0x1083 ; call 0x42e80 / window 365
03aa68 (+0e08): if r0 == 0x0 goto +0x11 <.text+0x3a9d8> ; branch 0x3aaf8 / relative 0xe98
03aa70 (+0e10): r1 = r6
03aa78 (+0e18): r2 = r0
03aa80 (+0e20): call 0x98ba ; call 0x87058 / window 1002
03aa88 (+0e28): r2 = *(u64 *)(r10 - 0x598)
03aa90 (+0e30): r1 = *(u64 *)(r2 + 0x0)
03aa98 (+0e38): r1 += 0x1
03aaa0 (+0e40): *(u64 *)(r2 + 0x0) = r1
03aaa8 (+0e48): goto +0xa4 <.text+0x3aeb0> ; branch 0x3afd0 / relative 0x1370
03aab0 (+0e50): r2 = *(u32 *)(r10 - 0x1ec)
03aab8 (+0e58): r3 = *(u64 *)(r10 - 0x1e8)
03aac0 (+0e60): r4 = *(u64 *)(r10 - 0x1e0)
03aac8 (+0e68): r5 = *(u64 *)(r10 - 0x1d8)
03aad0 (+0e70): *(u64 *)(r6 + 0x18) = r5
03aad8 (+0e78): *(u64 *)(r6 + 0x10) = r4
03aae0 (+0e80): *(u64 *)(r6 + 0x8) = r3
03aae8 (+0e88): *(u32 *)(r6 + 0x4) = r2
03aaf0 (+0e90): goto +0x9a <.text+0x3aea8> ; branch 0x3afc8 / relative 0x1368
03aaf8 (+0e98): r2 = *(u64 *)(r10 - 0x598)
03ab00 (+0ea0): r1 = *(u64 *)(r2 + 0x0)
03ab08 (+0ea8): r1 += 0x1
03ab10 (+0eb0): *(u64 *)(r2 + 0x0) = r1
03ab18 (+0eb8): r1 = *(u64 *)(r10 - 0x5c8)
03ab20 (+0ec0): if r1 != 0x0 goto +0x88 <.text+0x3ae48> ; branch 0x3af68 / relative 0x1308
03ab28 (+0ec8): if r7 == r9 goto +0x1 <.text+0x3aa18> ; branch 0x3ab38 / relative 0xed8
03ab30 (+0ed0): goto +0x86 <.text+0x3ae48> ; branch 0x3af68 / relative 0x1308
03ab38 (+0ed8): r1 = *(u64 *)(r10 - 0x5d0)
03ab40 (+0ee0): r1 &= 0x1
03ab48 (+0ee8): if r1 != 0x0 goto +0x30 <.text+0x3abb0> ; branch 0x3acd0 / relative 0x1070
03ab50 (+0ef0): r1 = r10
03ab58 (+0ef8): r1 += -0x1e0
03ab60 (+0f00): r2 = *(u64 *)(r10 - 0x5a8)
03ab68 (+0f08): call -0x6073 ; call 0xa7d8 / window 217
03ab70 (+0f10): r8 = r10
03ab78 (+0f18): r8 += -0x30
03ab80 (+0f20): r1 = r8
03ab88 (+0f28): r2 = *(u64 *)(r10 - 0x5b8)
03ab90 (+0f30): call -0x6078 ; call 0xa7d8 / window 217
03ab98 (+0f38): r7 = r10
03aba0 (+0f40): r7 += -0x2f8
03aba8 (+0f48): r1 = r7
03abb0 (+0f50): r2 = *(u64 *)(r10 - 0x5c0)
03abb8 (+0f58): call -0x607d ; call 0xa7d8 / window 217
03abc0 (+0f60): r1 = r10
03abc8 (+0f68): r1 += -0x1b0
03abd0 (+0f70): r2 = *(u64 *)(r10 - 0x5a0)
03abd8 (+0f78): call -0x6081 ; call 0xa7d8 / window 217
03abe0 (+0f80): r1 = 0x1
03abe8 (+0f88): *(u64 *)(r10 - 0x120) = r1
03abf0 (+0f90): r1 = r10
03abf8 (+0f98): r1 += -0x180
03ac00 (+0fa0): r2 = r8
03ac08 (+0fa8): r3 = 0x30
03ac10 (+0fb0): call 0xbc77 ; call 0x98fd0 / window 1246
03ac18 (+0fb8): r1 = 0x0
03ac20 (+0fc0): *(u64 *)(r10 - 0x1f0) = r1
03ac28 (+0fc8): r1 = r10
03ac30 (+0fd0): r1 += -0x150
03ac38 (+0fd8): r2 = r7
03ac40 (+0fe0): r3 = 0x30
03ac48 (+0fe8): call 0xbc70 ; call 0x98fd0 / window 1246
03ac50 (+0ff0): r1 = r10
03ac58 (+0ff8): r1 += -0x60
03ac60 (+1000): r2 = r10
03ac68 (+1008): r2 += -0x1f0
03ac70 (+1010): call 0x776e ; call 0x767e8 / window 775
03ac78 (+1018): r1 = *(u32 *)(r10 - 0x60)
03ac80 (+1020): if r1 == 0x16 goto +0x5c <.text+0x3ae48> ; branch 0x3af68 / relative 0x1308
03ac88 (+1028): r2 = *(u32 *)(r10 - 0x44)
03ac90 (+1030): *(u32 *)(r10 - 0x68) = r2
03ac98 (+1038): r3 = *(u64 *)(r10 - 0x4c)
03aca0 (+1040): *(u64 *)(r10 - 0x70) = r3
03aca8 (+1048): r4 = *(u64 *)(r10 - 0x54)
03acb0 (+1050): *(u64 *)(r10 - 0x78) = r4
03acb8 (+1058): r5 = *(u64 *)(r10 - 0x5c)
03acc0 (+1060): *(u64 *)(r10 - 0x80) = r5
03acc8 (+1068): goto +0x71 <.text+0x3af38> ; branch 0x3b058 / relative 0x13f8
03acd0 (+1070): r1 = r10
03acd8 (+1078): r1 += -0x1f0
03ace0 (+1080): r2 = r10
03ace8 (+1088): r2 += -0x578
03acf0 (+1090): call -0x7373 ; call 0x1160 / window 20
03acf8 (+1098): r1 = *(u32 *)(r10 - 0x1f0)
03ad00 (+10a0): if r1 != 0x16 goto +0x4e <.text+0x3ae58> ; branch 0x3af78 / relative 0x1318
03ad08 (+10a8): r7 = *(u64 *)(r10 - 0x1e8)
03ad10 (+10b0): r2 = *(u64 *)(r7 + 0x0)
03ad18 (+10b8): r1 = r10
03ad20 (+10c0): r1 += -0x580
03ad28 (+10c8): call -0x55c6 ; call 0xff00 / window 280
03ad30 (+10d0): r9 = *(u8 *)(r10 - 0x57f)
03ad38 (+10d8): r1 = *(u8 *)(r10 - 0x580)
03ad40 (+10e0): r1 &= 0x1
03ad48 (+10e8): if r1 == 0x0 goto +0x1 <.text+0x3ac38> ; branch 0x3ad58 / relative 0x10f8
03ad50 (+10f0): goto +0x53 <.text+0x3aed0> ; branch 0x3aff0 / relative 0x1390
03ad58 (+10f8): r1 = r10
03ad60 (+1100): r1 += -0x590
03ad68 (+1108): r2 = r8
03ad70 (+1110): call 0x96a1 ; call 0x86280 / window 990
03ad78 (+1118): r1 = r10
03ad80 (+1120): r1 += -0xa1
03ad88 (+1128): *(u64 *)(r10 - 0x2c8) = r1
03ad90 (+1130): r1 = 0x9a170 ll ; pointer 0x9a170; data32hex 6275726e4b696e644e6f6e650100496e76616c6964204f7074696f6e20726570
03ada0 (+1140): *(u64 *)(r10 - 0x2d8) = r1
03ada8 (+1148): r1 = 0x8
03adb0 (+1150): *(u64 *)(r10 - 0x2f0) = r1
03adb8 (+1158): r1 = 0x9a240 ll ; pointer 0x9a240; data32hex 6d65746164617461646561646c6f636b7372632f617373657274696f6e732e72
03adc8 (+1168): *(u64 *)(r10 - 0x2f8) = r1
03add0 (+1170): r1 = *(u64 *)(r10 - 0x588)
03add8 (+1178): *(u64 *)(r10 - 0x2e0) = r1
03ade0 (+1180): r1 = *(u64 *)(r10 - 0x590)
03ade8 (+1188): *(u64 *)(r10 - 0x2e8) = r1
03adf0 (+1190): *(u8 *)(r10 - 0xa1) = r9
03adf8 (+1198): r9 = 0x1
03ae00 (+11a0): *(u64 *)(r10 - 0x2c0) = r9
03ae08 (+11a8): r1 = 0x4
03ae10 (+11b0): *(u64 *)(r10 - 0x2d0) = r1
03ae18 (+11b8): r1 = r10
03ae20 (+11c0): r1 += -0x1e0
03ae28 (+11c8): r2 = *(u64 *)(r10 - 0x5a8)
03ae30 (+11d0): call -0x60cc ; call 0xa7d8 / window 217
03ae38 (+11d8): r8 = r10
03ae40 (+11e0): r8 += -0x60
03ae48 (+11e8): r1 = r8
03ae50 (+11f0): r2 = r7
03ae58 (+11f8): call -0x60d1 ; call 0xa7d8 / window 217
03ae60 (+1200): r7 = r10
03ae68 (+1208): r7 += -0x30
03ae70 (+1210): r1 = r7
03ae78 (+1218): r2 = *(u64 *)(r10 - 0x5c0)
03ae80 (+1220): call -0x60d6 ; call 0xa7d8 / window 217
03ae88 (+1228): r1 = r10
03ae90 (+1230): r1 += -0x1b0
03ae98 (+1238): r2 = *(u64 *)(r10 - 0x5a0)
03aea0 (+1240): call -0x60da ; call 0xa7d8 / window 217
03aea8 (+1248): *(u64 *)(r10 - 0x120) = r9
03aeb0 (+1250): r1 = r10
03aeb8 (+1258): r1 += -0x180
03aec0 (+1260): r2 = r8
03aec8 (+1268): r3 = 0x30
03aed0 (+1270): call 0xbc1f ; call 0x98fd0 / window 1246
03aed8 (+1278): r1 = 0x4
03aee0 (+1280): *(u64 *)(r10 - 0x1e8) = r1
03aee8 (+1288): r1 = r10
03aef0 (+1290): r1 += -0x2f8
03aef8 (+1298): *(u64 *)(r10 - 0x1f0) = r1
03af00 (+12a0): r1 = r10
03af08 (+12a8): r1 += -0x150
03af10 (+12b0): r2 = r7
03af18 (+12b8): r3 = 0x30
03af20 (+12c0): call 0xbc15 ; call 0x98fd0 / window 1246
03af28 (+12c8): r1 = r10
03af30 (+12d0): r1 += -0x80
03af38 (+12d8): r2 = r10
03af40 (+12e0): r2 += -0x1f0
03af48 (+12e8): call 0x7713 ; call 0x767e8 / window 775
03af50 (+12f0): r1 = *(u32 *)(r10 - 0x80)
03af58 (+12f8): if r1 == 0x16 goto +0x1 <.text+0x3ae48> ; branch 0x3af68 / relative 0x1308
03af60 (+1300): goto +0x16 <.text+0x3aef8> ; branch 0x3b018 / relative 0x13b8
03af68 (+1308): r1 = 0x16
03af70 (+1310): goto +0xa <.text+0x3aea8> ; branch 0x3afc8 / relative 0x1368
03af78 (+1318): r2 = *(u64 *)(r10 - 0x1e0)
03af80 (+1320): *(u64 *)(r10 - 0x2f8) = r2
03af88 (+1328): r3 = *(u64 *)(r10 - 0x1d8)
03af90 (+1330): *(u64 *)(r10 - 0x2f0) = r3
03af98 (+1338): r4 = *(u32 *)(r10 - 0x1ec)
03afa0 (+1340): r5 = *(u64 *)(r10 - 0x1e8)
03afa8 (+1348): *(u64 *)(r6 + 0x18) = r3
03afb0 (+1350): *(u64 *)(r6 + 0x10) = r2
03afb8 (+1358): *(u64 *)(r6 + 0x8) = r5
03afc0 (+1360): *(u32 *)(r6 + 0x4) = r4
03afc8 (+1368): *(u32 *)(r6 + 0x0) = r1
03afd0 (+1370): r1 = r10
03afd8 (+1378): r1 += -0x3e0
03afe0 (+1380): call -0x6fe9 ; call 0x30a0 / window 59
03afe8 (+1388): goto -0x1d1 <.text+0x3a048> ; branch 0x3a168 / relative 0x508
03aff0 (+1390): r1 = 0x0
03aff8 (+1398): *(u32 *)(r6 + 0x0) = r1
03b000 (+13a0): r1 = r9
03b008 (+13a8): *(u32 *)(r6 + 0x4) = r1
03b010 (+13b0): goto -0x9 <.text+0x3aeb0> ; branch 0x3afd0 / relative 0x1370
03b018 (+13b8): r2 = *(u32 *)(r10 - 0x64)
03b020 (+13c0): *(u32 *)(r10 - 0x88) = r2
03b028 (+13c8): r3 = *(u64 *)(r10 - 0x6c)
03b030 (+13d0): *(u64 *)(r10 - 0x90) = r3
03b038 (+13d8): r4 = *(u64 *)(r10 - 0x74)
03b040 (+13e0): *(u64 *)(r10 - 0x98) = r4
03b048 (+13e8): r5 = *(u64 *)(r10 - 0x7c)
03b050 (+13f0): *(u64 *)(r10 - 0xa0) = r5
03b058 (+13f8): *(u32 *)(r6 + 0x1c) = r2
03b060 (+1400): *(u64 *)(r6 + 0x14) = r3
03b068 (+1408): *(u64 *)(r6 + 0xc) = r4
03b070 (+1410): *(u64 *)(r6 + 0x4) = r5
03b078 (+1418): goto -0x17 <.text+0x3aea8> ; branch 0x3afc8 / relative 0x1368
