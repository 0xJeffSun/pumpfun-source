#!/usr/bin/env python3
"""Decode static control-flow evidence only. Does not execute SBF or a fixture."""
from pathlib import Path
import hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'))
from elf_reader import Elf
paths={'original':'evidence/dependencies/token_metadata/deployed.so','candidate10':'work/metaplex-recovered-build-40157158772/metaplex-rebuild-40157158772/token_metadata.so'}
E={s:Elf(ROOT/p) for s,p in paths.items()}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
branch_sites={
 'original':[0x38ad0,0x38ae0,0x38c90,0x3a4d0,0x3a4e0,0x3a4f0,0x3a528],
 'candidate10':[0x38ad0,0x38ae0,0x38ae8,0x38b00,0x3a4e8,0x3a4f8,0x3a508,0x3a510,0x3a518,0x3a538,0x3a548]}
branches=[]
for side,sites in branch_sites.items():
 e=E[side]
 for at in sites:
  opcode,regs,displacement,imm=struct.unpack_from('<BBhi',e.b,at)
  assert opcode&7==5 and opcode not in [0x85,0x8d,0x95]
  target=at+8+8*displacement
  branches.append({'side':side,'at':hex(at),'raw_hex':e.b[at:at+8].hex(),'opcode':hex(opcode),'dst_reg':regs&15,'src_reg':regs>>4,'signed_displacement_in_8_byte_slots':displacement,'immediate':imm,'target_calculation':f'{at:#x} + 8 + 8 * ({displacement}) = {target:#x}','target':hex(target)})
errors=[]
for side,at in [('original',0x38c80),('candidate10',0x38af0),('original',0x3a4f8),('candidate10',0x3a520)]:
 e=E[side];assert e.b[at]==0x18
 value=struct.unpack_from('<I',e.b,at+4)[0]|struct.unpack_from('<I',e.b,at+12)[0]<<32
 assert value==86<<32
 errors.append({'side':side,'at':hex(at),'raw_hex':e.b[at:at+16].hex(),'loaded_u64':hex(value),'custom_error':86,'enum':'MetadataError::NotEnoughUses'})
helper_rows=[]
for n in [59,96,166,980,986]:
 row={'ordinal':n}
 for side,e in E.items():
  a,b=e.entries[n:n+2]; row[side]={'start':hex(a),'bytes':b-a,'raw_sha256':hashlib.sha256(e.b[a:b]).hexdigest(),'normalized_sha256':hashlib.sha256(e.normalized[a:b]).hexdigest()}
 row['normalized_bodies_equal']=row['original']['normalized_sha256']==row['candidate10']['normalized_sha256'];assert row['normalized_bodies_equal'];helper_rows.append(row)
prior=ROOT/'work/metaplex-static-mapping/mapping.md'
(W/'prior-mapping.unmodified.md').write_bytes(prior.read_bytes())
prior_errors=[{'line':i,'text':line} for i,line in enumerate(prior.read_text().splitlines(),1) if 'bypasses `number_of_uses' in line or 'edge to`0x3a530`' in line]
result={'kind':'Static decode and dataflow, not runtime receipts','branches':branches,'error_blocks':errors,'helpers':helper_rows,'prior_mapping':{'path':str(prior.relative_to(ROOT)),'sha256':sha(prior),'incorrect_inferences':prior_errors,'correction':'Both original zero-count branches target NotEnoughUses error, not the success continuations stated in the earlier mapping. Earlier artifact retained unchanged.'},'source_predicates':{'344':{'original':'n == 0 || n > remaining','candidate10':'n > 0 && n > remaining','minimal_behavioral_correction':'Reject zero uses with ||; retain check position after allocation and all earlier validations.'},'346':{'original':'n == 0 || n > total || n > remaining','candidate10':'n > 0 && (n > total || n > remaining), followed by checked subtraction','minimal_behavioral_correction':'Reject zero uses with ||; retain pre-subtraction position and all authorization/account checks.'}},'source_order_350':{'original':['data_len980','try_borrow_mut_data986','serialize166','release mutable borrow','try_borrow_mut_data986','clear length-2 and length-1'], 'candidate10':['try_borrow_mut_data986','serialize166','release mutable borrow','data_len980','try_borrow_mut_data986','clear length-2 and length-1'],'supported_source_order_adjustment':'Move the existing data_len statement before borsh::to_writer, without changing either borrow or the two clearing writes. No runtime behavioral difference for ordinary valid account state established.'},'scope':{'builds':0,'runtime_probes':0,'program_source_edits':0,'binary_edits':0}}
(W/'exact-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'branches_decoded':len(branches),'error_blocks_decoded':len(errors),'unchanged_helper_windows':len(helper_rows),'prior_wrong_claims':len(prior_errors)}))
