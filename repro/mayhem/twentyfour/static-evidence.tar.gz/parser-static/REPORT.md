# Mayhem PumpSwap parser static handoff

Scope: read-only analysis of captured original Mayhem ELF (`a87fa9f866272514e6acb852b668c4a08aeb173d56c883039991d114d1199bdb`). This directory contains bounded original disassembly excerpts and uncompiled source drafts only. No candidate/main files, executable bytes, live transactions, or runtime fixtures were changed by this lane.

`accounts-draft.rs` provides both 31-account buy and 29-account sell declarations. `codecs-draft.rs` provides the two external AMM account layouts. These drafts need normal candidate build and differential verification. All addresses below are original ELF file offsets; relative calls/branches in excerpts were recalculated from raw instructions because labels in the initial disassembly have a 0x120 bias.

## Account declarations

Buy parser begins `0x46378`, sell parser `0x4cc98`. Sell omits buy positions22/23 (both volume accounts) and otherwise retains order and constraints.

| Buy index | Account | Type and outer checks |
|---:|---|---|
|0|trader|Signer, mut|
|1|global_params|Box<Account<GlobalParams>>, mut, Mayhem seeds `global-params`, bump, has_one trader|
|2|mayhem_state|Box<Account<MayhemState>>, mut, Mayhem seeds `mayhem-state` + mint, bump|
|3|mint|Box<InterfaceAccount<Mint>>, no explicit mut|
|4|mayhem_token_vault|Box<InterfaceAccount<TokenAccount>>, ATA(mint,sol_vault,mint.owner), mut|
|5|mayhem_quote_vault|Box<InterfaceAccount<TokenAccount>>, init_if_needed, payer trader, ATA(quote_mint,sol_vault,quote_token_program), rent exemption, mut|
|6|sol_vault|Unchecked, Mayhem seeds `sol-vault`, bump, mut|
|7|system_program|System Program (existing CheckedSystemProgram diagnostic implementation applies)|
|8|quote_token_program|Interface<TokenInterface> AND explicit address Tokenkeg|
|9|base_token_program|Program<Token2022>|
|10|associated_token_program|Program<AssociatedToken>|
|11|pool|Box<Account<SwapPool>>, AMM owner/discriminator, mut; no outer seeds or has_one checks|
|12|global_config|Box<Account<SwapGlobalConfig>>, AMM owner/discriminator; readonly, no outer seeds|
|13|quote_mint|Unchecked, no typed Mint parse|
|14|pool_base_token_account|Box<InterfaceAccount<TokenAccount>>, mut; no outer token-mint/ATA constraints|
|15|pool_quote_token_account|Box<InterfaceAccount<TokenAccount>>, mut; no outer token-mint/ATA constraints|
|16|protocol_fee_recipient|Unchecked, mut|
|17|protocol_fee_recipient_token_account|Box<InterfaceAccount<TokenAccount>>, ATA(quote_mint,protocol_fee_recipient,quote_token_program), mut|
|18|pump_swap_event_authority|Unchecked, no outer seeds|
|19|pump_swap_program|Unchecked, explicit AMM address; no Program executable check|
|20|coin_creator_vault_ata|Box<InterfaceAccount<TokenAccount>>, ATA(quote_mint,coin_creator_vault_authority,quote_token_program), mut|
|21|coin_creator_vault_authority|Unchecked|
|22|global_volume_accumulator|Unchecked, mut (buy only)|
|23|user_volume_accumulator|Unchecked, mut (buy only)|
|24|fee_config|Unchecked|
|25|fee_program|Unchecked|
|26|event_authority|Unchecked, Mayhem seeds `__event_authority`, bump|
|27|program|Program<MayhemRecovered>|
|28|pool_v2|Unchecked, **Mayhem** seeds `pool-v2` + mint, bump, readonly|
|29|buyback_recipient|Unchecked, readonly|
|30|buyback_recipient_ata|Unchecked, mut|

Key original checks:

- Type calls in buy: pool `0x47458 -> 0x4d60 -> 0xa0b0 -> 0x7130`; config `0x47508 -> 0x4a10 -> 0xa358 -> 0x62e8`; typed token accounts `0x47678/0x47728/0x47880/0x47a38 -> 0x50b0 -> 0x2d78`. Quote mint is consumed directly at `0x47560..0x47620`, without a Mint parser.
- Quote interface parse `0x472a8 -> 0x120` does not establish Token2022 support: fixed Tokenkeg address comparisons `0x49568..0x495c8`, error2012 at `0x4a720`. Parent independently confirmed normal signed stable SPL Token success and stable Token2022 rejection2012.
- Quote ATA initialization helper `0x4aeb0`: if account owner is System, invoke the real ATA creation helper at `0x4b0c0 -> 0x901b0`, then typed TokenAccount decode `0x4b0e8 -> 0x3ea8`; check token mint at `0x4b3b0`, token authority at `0x4b428`, actual owner against quote token program at `0x4b488`, derived ATA at `0x4b638`. Outer parser applies mut at `0x48310`, rent at `0x48560`, and error2005 at `0x48700`.
- Anchor1.0 duplicate mutable-account checks follow init and rent, before ordinary constraints (`0x486b0..0x48d28`), error2040. The local existing Anchor1.0 enum names this `ConstraintDuplicateMutableAccount`; use the ordinary derive rather than hand-invent checks.
- Trader mut at `0x48d80`; global seeds `0x48dd8`, global mut `0x48e88`, global has_one `0x48f10`; state seeds `0x49030`, state mut `0x490e0`; base ATA owner/program `0x49120..0x49190`, authority `0x49238..0x49270`, derivation `0x49378`, mut `0x49418`.
- Sol seeds `0x49470`, mut `0x49520`; pool/basepool/quotepool/protocolrecipient mut `0x495d0..0x49640`; protocol ATA program/authority/address/mut `0x49648..0x49900`; AMM address `0x49940..0x499a0`; creator ATA owner/authority/address/mut `0x499a8..0x49c50`.
- Both buy volume accounts explicitly require mut at `0x49c58` and `0x49c70`, error blocks `0x4ace8` and `0x4ad30` name global_volume_accumulator and user_volume_accumulator respectively. Event seeds `0x49cd0`; pool-v2 seeds `0x49e58`, with the same Mayhem program-id input as global/state/sol/event; buyback ATA mut `0x49f00`.
- Pool/global-config accounts are external-owner types; Anchor exits do not serialize them as Mayhem-owned accounts. Do not write a truncated old config prefix over actual AMM CPI state.

## Embedded codecs

`SwapPool` has the same287-byte full field order as current captured AMM Pool. Its owner comparison is AMM at `0x71b8`; discriminator is `f19a6d0411b16dbc` at `0x8ebb8`. The Mayhem wrapper at `0x17d8` computes the current serialized287-byte size, and for **every** shorter input zero-fills a287-byte allocation and copies all supplied input bytes (`0x1f78..0x2008`), then calls the ordinary checked decoder `0x8eb78`. At length>=287 it calls the checked decoder directly (`0x2058..0x2070`). Thus partial tail fields are retained and zero-completed rather than discarded by version boundary. Inputs shorter than8 reach the checked decoder only after padding; the resulting error is discriminator mismatch3002, not discriminator-not-found3001. This codec does not imply the underlying AMM CPI accepts these short states.

`SwapGlobalConfig` uses an older strict418-byte prefix, not the current907/940/949-byte AMM decoder. Owner AMM at `0x6308..0x6378`; checked decoder `0x744a8`, discriminator `95089ccaa0fcb0d9`; unpadded Borsh decoder `0x74890`. Layout: admin8, lpfee40, protocolfee48, disable_flags56, eight recipients57..313, creatorfee313, admin_set_creator_authority321, whitelist353, reserved_recipient385, bool mayhem_mode_enabled417. Tail account data is ignored. bool417 must decode as0/1; there are no later reserved-recipient/buyback/boost fields in this embedded type. Discriminator errors use type names `Pool` and `GlobalConfig` before derive attaches outer account names; source-file/line diagnostics in drafts remain intentionally unclaimed.

Remaining work belongs to parent: clean SBF build, ordinary signed differential account-length/owner/discriminator/ATA/mut matrices, actual CPI/account/state/event equality and all inherited regressions. No runtime parity is claimed for these source drafts.

## CPI metas and errors follow-up

Original fixed meta builders are buy `0x78370` and sell `0x7afb8`; decoded34-byte AccountMeta records are saved in `buy-fixed-metas.json` and `sell-fixed-metas.json` with exact flag-store offsets. Both set only CPI index1 (Mayhem sol-vault PDA) as signer. The fixed buy23 writable indices are `{0,1,5,6,7,8,10,17,19,20}`; fixed sell21 writable indices are `{0,1,5,6,7,8,10,17}`. In particular protocol_fee_recipient CPIindex9 is readonly despite the outer account's mut constraint; buy global_volume_accumulator CPIindex19 is writable.

The fixed buy23 order is pool, sol-vault, global_config, base_mint, quote_mint, mayhem_base_vault, mayhem_quote_vault, pool_base_account, pool_quote_account, protocol_recipient, protocol_recipient_ATA, base_token_program, quote_token_program, System, ATA_program, AMM_event_authority, AMM_program, creator_ATA, creator_authority, global_volume, user_volume, fee_config, fee_program. Sell21 omits both volume accounts. Both append the two selected buyback accounts as remaining accounts, forwarding each AccountInfo's signer/writable bytes rather than forcing constants (`buy0x75d48..0x75d80`, analogous sell loop). In the ordinary accepted fixture the appended buyback recipient is readonly and ATA writable; outer surplus writable privileges can change appended CPI flags and should be preserved. The Mayhem-derived pool_v2 is not in these CPI arrays.

Buy payload discriminator `66063d1201daebea`, two little-endian u64 fields, one bool byte (25bytes total); sell `33e685a4017f83ad`, two little-endian u64 fields (24bytes). These follow original helper stores `0x75a98..0x75ac0` and `0x76fe8..0x77008`; no candidate bytes were copied from the original.

Both CPI error wrappers construct error6010, enum `PumpSwapCpiFailed`, exact message `Pump Swap CPI call failed`; source `programs/mayhem-program/src/instructions/pump_amm_interface.rs`, original buy line376 (`0x175b8=0x178`) and sell line568 (`0x1bb58=0x238`). The initial advisory message misstated the sell line as557;568 is the verified value. Buy/sell nested-VM exceptions can remain underlying runtime errors as in previously accepted handlers; source diagnostics are not evidence of instruction/state parity by themselves.

Although the enum defines PumpSwapCpiSlippage6013, these two handlers' price guards use **PumpCpiSlippage6012**. Buy assigns enum12 at `0x15578` and ORs6000 at `0x15860`. Sell assigns enum12 at `0x17cb0`, stores it at stack-0x6f0, rejected bounds load it at `0x17fe0`, and OR6000 at `0x18108`. Reusing existing SellError::PumpCpiSlippage6012 is therefore correct here.

Parent reports build01 baseline native/stable candidate parity and has integrated these static findings into isolated build02. This lane did not run those transactions and does not independently claim that runtime result.
