"""Read-only validation that every saved asm instruction equals original ELF bytes."""
from pathlib import Path
import hashlib,json,re,struct
D=Path(__file__).resolve().parent
R=next(p for p in D.parents if (p/'evidence/original/mayhem/deployed.so').is_file())
B=(R/'evidence/original/mayhem/deployed.so').read_bytes()
assert hashlib.sha256(B).hexdigest()=='a87fa9f866272514e6acb852b668c4a08aeb173d56c883039991d114d1199bdb'
counts={}
for f in sorted(D.glob('*.asm')):
 n=0
 for line in f.read_text().splitlines():
  at,raw,*_=line.split(' ',2);at=int(at[:-1],16);raw=bytes.fromhex(raw)
  assert B[at:at+len(raw)]==raw,(f,hex(at))
  if '; true_call ' in line:assert int(line.rsplit('; true_call ',1)[1],16)==at+8+8*struct.unpack_from('<i',raw,4)[0]
  if '; true_branch ' in line:assert int(line.rsplit('; true_branch ',1)[1],16)==at+8+8*struct.unpack_from('<h',raw,2)[0]
  n+=1
 counts[f.name]=n
for side in ['buy','sell']:
 expected=json.loads((D/f'{side}-fixed-metas.json').read_text());actual=[]
 for line in (D/f'{side}-cpi-metas.asm').read_text().splitlines():
  m=re.search(r'^([a-f0-9]+).*sth \[r1 \+ 0x([a-f0-9]+)\], 0x([a-f0-9]+)',line)
  if not m:continue
  off=int(m[2],16);v=int(m[3],16);assert (off-32)%34==0
  actual.append({'cpi_index':(off-32)//34,'at':int(m[1],16),'signer':v&255,'writable':v>>8})
 assert actual==expected,side
print(json.dumps({'original_sha256':hashlib.sha256(B).hexdigest(),'verified_instructions':sum(counts.values()),'excerpts':counts,'fixed_meta_tables_verified':True},indent=2))
