from pathlib import Path
import json
D=Path(__file__).resolve().parent
for instruction in ['buy_pump_swap','sell_pump_swap']:
 buy=instruction.startswith('buy');count=31 if buy else 29;rows=[]
 def add(name,**kw):rows.append(dict(name=name,**kw))
 def mutation(name,idx,**kw):add(name,mutations={str(idx):kw})
 add('baseline');add('missing_quote_vault',missing_quote_vault=True);add('quote_prebalance',quote_tokens=10**7);add('unsigned_trader',unsigned_trader=True);add('extra_account',extra_account=True);add('trailing_payload',trailing='11223344')
 for value in [0,1,10**9,10**10,10**11,10**12,(1<<64)-1]:add(f'tokens_{value}',tokens=value)
 for value in [0,1,9999,10000,10001,65535]:add(f'retained_{value}',retained=value)
 for value in [0,1,9999,10000,10001,65535]:add(f'tolerance_{value}',tolerance=value)
 for value in [0,1,182495693113,1<<64,(1<<128)-1]:add(f'reference_{value}',reference=value)
 for key in ['cap','stable_cap','threshold','stable_threshold']:
  for value in [0,1,182495,18246860,(1<<64)-1]:add(f'{key}_{value}',**{key:value,'status':0})
 for value in [0,1,2,255]:add(f'paused_{value}',paused=value)
 for value in [0,1,2,3,255]:add(f'status_{value}',status=value)
 for value in [99,100,101,-1]:add(f'deadline_{value}',deadline=value)
 for last,interval,now in [(0,100,100),(99,2,100),(99,1,100),(100,1,100),(-1,1,100),((1<<63)-1,1,100),(1,1,-1),(1,0,100)]:add(f'rate_{last}_{interval}_{now}',last=last,interval=interval,now=now)
 for value in [-(1<<127),-122946690721,-122946690720,-125882,-1,0,1,10**9,(1<<64)-1,(1<<127)-1]:add(f'virtual_{value}',virtual_quote=value)
 for key in ['global_risk','coin_risk','stable_global_risk','stable_coin_risk']:
  for value in [0,1,16207579,16207580,16207581,18246860,18246861,(1<<64)-1]:add(f'{key}_{value}',**{key:value})
 for key in ['global_sol','global_stable','state_quote','state_tokens']:
  for value in [-(1<<127),-10**12,-1,0,1,10**12,1<<64,(1<<127)-1]:add(f'{key}_{value}',**{key:value})
 for length in range(20):add(f'payload_length_{length}',payload_length=length)
 for n in range(count+1):add(f'account_count_{n}',account_count=n)
 for idx in range(count):add(f'readonly_{idx}',readonly=[idx]);add(f'wrong_key_{idx}',wrong_keys=[idx])
 for idx in [1,2,3,4,5,6,11,12,13,14,15,17,20]:mutation(f'system_owner_{idx}',idx,system_owner=True)
 for idx in [1,2,11,12]:mutation(f'discriminator_{idx}',idx,bytes=[[0,255]])
 for idx,lens in [(1,[0,7,8,253,254,318]),(2,[0,7,8,97,98,170]),(3,[0,81,82]),(4,[0,164,165]),(5,[0,164,165]),(11,[0,7,8,210,211,242,243,244,245,260,261,269,270,271,286,287,300]),(12,[0,7,8,321,353,385,417,418,419]),(13,[0,81,82]),(14,[0,164,165]),(15,[0,164,165]),(17,[0,164,165]),(20,[0,164,165])]:
  for length in lens:mutation(f'length_{idx}_{length}',idx,length=length)
 for idx in [1,2,3,4,5,11,12,14,15,17,20]:mutation(f'low_lamports_{idx}',idx,lamports=1)
 for idx in [4,5,14,15,17,20]:
  for offset in [0,32]:mutation(f'token_pubkey_{idx}_{offset}',idx,pubkey=[[offset,'11111111111111111111111111111111']])
  for state in [0,2,3,255]:mutation(f'token_state_{idx}_{state}',idx,bytes=[[108,state]])
 for idx in [14,15]:
  for value in [0,1,2,10**9,(1<<64)-1]:mutation(f'pool_tokens_{idx}_{value}',idx,u64=[[64,value]])
 for offset in [243,244,270]:
  for value in [0,1,2,255]:mutation(f'pool_bool_{offset}_{value}',11,bytes=[[offset,value]])
 for value in [0,1,2,255]:mutation(f'config_bool_417_{value}',12,bytes=[[417,value]])
 for value in [0,1,2,4,8,16,31,255]:mutation(f'config_flags_{value}',12,bytes=[[56,value]])
 assert len({r['name'] for r in rows})==len(rows)
 (D/(instruction+'-cases.json')).write_text(json.dumps({'scope':'Ordinary trader/payer signatures; synthetic stored business state. Malformed account and missing signature cases are negative tests; original authorization unchanged. No transfer-fee extension probes or live transactions.','cases':rows},indent=2)+'\n');print(instruction,len(rows))
