from pathlib import Path
import json,subprocess,concurrent.futures,sys
D=Path(__file__).resolve().parent;R=D.parents[1];out=D/'regression-02';out.mkdir(exist_ok=False)
old=json.loads((R/'work/mayhem-buy-v2-followup/regression-02/commands.json').read_text());commands={}
for name,row in old.items():
 command=[v.replace('work/mayhem-buy-v2-followup/build-02','work/mayhem-pump-swap-followup/build-02').replace('work/mayhem-buy-v2-followup/regression-02','work/mayhem-pump-swap-followup/regression-02') for v in row['command']];command[0]=sys.executable;commands[name]=command
for family in ['native','token','token22']:commands['buy-v2-'+family]=[sys.executable,'scripts/mayhem_buy_v2_differential.py','--candidate','work/mayhem-pump-swap-followup/build-02/artifacts/mayhem_recovered.so','--cases','repro/mayhem/twentytwo/buy-v2-cases.json','--family',family,'--output',f'work/mayhem-pump-swap-followup/regression-02/buy-v2-{family}.json']
def run(item):
 name,cmd=item
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 return name,{'command':cmd,'returncode':r.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=dict(pool.map(run,commands.items()))
(out/'commands.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({n:r['returncode'] for n,r in results.items()},indent=2));raise SystemExit(any(r['returncode'] for r in results.values()))
