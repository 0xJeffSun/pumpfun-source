from pathlib import Path
import base64,json,struct,hashlib
from solders.transaction import Transaction
D=Path(__file__).resolve().parent
FIELDS=[('side',1),('sol_vault',32),('mint',32),('sol_amount',8),('token_amount',8),('sol_vault_balance',8),('token_vault_balance',8),('state_sol_deployed',16),('state_token_net',16),('virtual_sol',8),('virtual_tokens',8),('global_sol_deployed',16),('timestamp',8),('end_timestamp',8),('real_sol',8),('real_tokens',8),('version',4),('retained_reserve_bps',2),('quote_amount',8),('quote_vault_balance',8),('state_quote_deployed',16),('virtual_quote',8),('global_quote_deployed',16),('real_quote',8),('quote_mint',32)]
from solders.pubkey import Pubkey
rows=[]
for p in sorted(D.glob('original-*.json')):
 d=json.loads(p.read_text());tx=Transaction.from_bytes(base64.b64decode(d['transaction_base64']));outer=[str(tx.message.account_keys[i]) for i in tx.message.instructions[-1].accounts];inners=[]
 for group in d['metadata']['inner_instructions']:
  for ins in group:
   raw=ins['instruction'];pid=str(tx.message.account_keys[raw['programIdIndex']]);data=bytes(raw['data'][1:]);accounts=[str(tx.message.account_keys[i]) for i in raw['accounts'][1:]]
   if ins['stackHeight']==2:inners.append({'program':pid,'data_hex':data.hex(),'outer_indices':[outer.index(k) if k in outer else None for k in accounts]})
 events=[]
 for log in d['metadata']['logs']:
  if not log.startswith('Program data: '):continue
  raw=base64.b64decode(log[14:]);
  if raw[:8]!=bytes.fromhex('31487b2d6e40b085'):continue
  assert len(raw)==303;off=8;event={}
  for key,n in FIELDS:
   value=raw[off:off+n];off+=n;event[key]=str(Pubkey(value)) if n==32 else int.from_bytes(value,'little',signed=n==16 or key in ['timestamp','end_timestamp'])
  events.append(event)
 c=d['case'];b=d['inputs']['pool_base'];q=d['inputs']['pool_quote'];t=c.get('tokens',10**9);budget=q*t//(b+t);cap=c.get('stable_cap',0) if c.get('token_quote') else c.get('cap',0)
 if cap:budget=min(cap,budget)
 budget=min(budget,q*(10000-c.get('retained',9000))//10000)
 isbuy=c.get('instruction','buy_pump_swap').startswith('buy');amount=budget*b//(q+budget if isbuy else q-budget);limit=budget if isbuy else max(0,budget-1)
 rows.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'error':d['error'],'signature_verified':all(tx.verify_with_results()),'expected_cpi_amounts':[amount,limit],'inner':inners,'events':events})
(D/'original-receipt-analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['file'],r['error'],r['expected_cpi_amounts'],r['events'])
