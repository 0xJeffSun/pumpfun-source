from pathlib import Path
D=Path(__file__).resolve().parent;S=D/'crate/src'
codecs=(D/'parser-static/codecs-draft.rs').read_text().replace('//! Static codec reconstruction; not compiled or runtime-validated.','//! External AMM codecs recovered from original Mayhem decoding routines.').replace('const AMM_ID:','pub const AMM_ID:')
codecs+='\n#[error_code]\npub enum PumpSwapError {\n #[msg("Pump Swap CPI failed")]PumpSwapCpiFailed=10,\n}\n'
(S/'instructions/pump_swap_types.rs').write_text(codecs)
a=(D/'parser-static/accounts-draft.rs').read_text();header=a[:a.index('#[derive(Accounts)]')];header=header.replace('use crate::{GlobalParams};','use crate::{GlobalParams,MayhemError};\nuse crate::state::MayhemStatus;\nuse anchor_lang::solana_program::{instruction::Instruction,program::invoke_signed};\nuse super::sell::{SellEvent,SellError};\nuse super::buy::BuyError;\nuse super::pump_swap_types::{SwapPool,SwapGlobalConfig,AMM_ID,PumpSwapError};\nconst WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");');header=header.replace('const AMM_ID:Pubkey=pubkey!("pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA");\n','')
for side in ['buy','sell']:
 marker='#[derive(Accounts)]\npub struct '+side.title()+'PumpSwap';accounts=a[a.index(marker):];accounts=accounts[:accounts.index('\n}\n')+3]
 (S/f'instructions/{side}_pump_swap.rs').write_text(header+accounts+'\n'+(D/f'{side}-handler-draft.rs').read_text())
p=S/'instructions/mod.rs';s=p.read_text();
for m in ['pump_swap_types','buy_pump_swap','sell_pump_swap']:
 if f'pub mod {m};' not in s:s+=f'\npub mod {m};\n'
p.write_text(s)
p=S/'lib.rs';s=p.read_text().replace('implementation: 22 recovered','implementation: 24 recovered');s=s.replace('pub use instructions::buy_v2::*;','pub use instructions::buy_v2::*;\npub use instructions::buy_pump_swap::*;\npub use instructions::sell_pump_swap::*;')
marker='    pub fn buy_v2('
s=s.replace(marker,'    pub fn buy_pump_swap(ctx: Context<BuyPumpSwap>, reference: u128, tolerance_bps: u16, retained_reserve_bps: u16) -> Result<()> { instructions::buy_pump_swap::handler(ctx, reference, tolerance_bps, retained_reserve_bps) }\n    pub fn sell_pump_swap(ctx: Context<SellPumpSwap>, reference: u128, tolerance_bps: u16, retained_reserve_bps: u16) -> Result<()> { instructions::sell_pump_swap::handler(ctx, reference, tolerance_bps, retained_reserve_bps) }\n'+marker);p.write_text(s)
