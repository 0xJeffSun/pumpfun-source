from pathlib import Path
import hashlib,json,re,struct
D=Path(__file__).resolve().parent;R=D.parents[1];blob=(R/'evidence/original/mayhem/deployed.so').read_bytes();asm=R/'work/disassembly/mayhem.asm';ranges=[('buy-wrapper',0x820f8,0x82438),('buy-parser',0x46378,0x4aeb0),('buy-handler',0x14e60,0x17468),('buy-helper',0x17468,0x17668),('sell-wrapper',0x81db8,0x820f8),('sell-parser',0x4cc98,0x51578),('sell-handler',0x17668,0x1ba08),('sell-helper',0x1ba08,0x1bc08),('buy-budget',0x2d3d0,0x2d8b8),('sell-budget',0x2d8b8,0x2dd18)];rows=[]
for name,start,end in ranges:
 out=[];calls=[]
 for line in asm.read_text().splitlines():
  m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2} )+)\s+(.*)',line)
  if not m:continue
  at=int(m[1],16)
  if not start<=at<end:continue
  raw=bytes.fromhex(m[2]);assert blob[at:at+len(raw)]==raw;text=m[3];op=raw[0]
  if op==0x85 and raw[1]==0x10:
   target=at+8+8*struct.unpack_from('<i',raw,4)[0];text+=' ; true_call '+hex(target);calls.append([hex(at),hex(target)])
  elif op&7==5 and op not in (0x85,0x95,0x8d):text+=' ; true_branch '+hex(at+8+8*struct.unpack_from('<h',raw,2)[0])
  if op==0x18 and len(raw)==16:
   value=struct.unpack_from('<I',raw,4)[0]+(struct.unpack_from('<I',raw,12)[0]<<32)
   if 0xad000<=value<len(blob):text+=' ; BYTES '+repr(blob[value:value+64])
   elif 0x2020202020202020<value<0x7f7f7f7f7f7f7f7f:
    b=value.to_bytes(8,'little')
    if all(32<=v<127 for v in b):text+=' ; ASCII '+repr(b)
  out.append(f'{at:06x}: {raw.hex()} {text}')
 p=D/(name+'.asm');p.write_text('\n'.join(out)+'\n');rows.append({'path':str(p.relative_to(R)),'start':start,'end_exclusive':end,'instructions':len(out),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'calls':calls})
(D/'static-provenance.json').write_text(json.dumps({'scope':'Original byte-checked bounded excerpts; end offsets are not all asserted source function boundaries.','original_sha256':hashlib.sha256(blob).hexdigest(),'disassembly_sha256':hashlib.sha256(asm.read_bytes()).hexdigest(),'excerpts':rows},indent=2)+'\n')
