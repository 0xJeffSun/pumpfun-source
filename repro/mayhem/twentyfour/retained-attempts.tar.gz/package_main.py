from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile,subprocess,sys,platform,importlib.metadata
import solders.solders as sb
R=Path.cwd();D=R/'work/mayhem-pump-swap-followup';P=R/'repro/mayhem/twentyfour';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
def archive(out,items):
 buf=io.BytesIO();seen=set()
 with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as t:
  for src,name in sorted(items,key=lambda r:r[1]):
   assert name not in seen,name;seen.add(name);info=tarfile.TarInfo(name);b=src.read_bytes();info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
 out.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
def freeze(src,name,count):
 j=json.loads(src.read_text());assert j['candidate_sha256']==digest and j['case_count']==count and not j['mismatches'];assert len(j['cases'])==count
 for path,h in j.get('harness_sha256',{}).items():assert sha(R/path)==h,path
 f=P/f'{name}-differential.json.gz';f.write_bytes(gzip.compress(src.read_bytes(),mtime=0));rec={'cases':count,'mismatches':0,'receipt':str(f.relative_to(R)),'compressed_sha256':sha(f)}
 if 'successful_original_cases' in j:rec.update(successes=j['successful_original_cases'],rejections=count-j['successful_original_cases'],signed_transactions=2*count,normalized_log_differences=j.get('normalized_log_differences',[]))
 return rec
main=json.loads((P/'build-comparison.json').read_text());digest=sha(P/'mayhem_recovered.so');assert digest=='9e4e19dfb3b3fefbec13ecfc0d43ffd2ff0bea7b74ac7b2fe14126d23c79c05b'
assert (P/'mayhem_recovered.so').read_bytes()==(D/'build-02/artifacts/mayhem_recovered.so').read_bytes()
for path,h in main['source_sha256'].items():assert sha(R/path)==h,path
assert all(v['returncode']==0 for v in json.loads((D/'regression-02/commands.json').read_text()).values())
suites={}
for name,count in [('admin',1051),('fee_recipient',306),('extend',301),('withdraw',274),('quote_withdraw',329),('sweeps',692),('sell',396),('buy',486),('sell-v2-native',473),('sell-v2-token',473),('sell-v2-token22',473),('buy-v2-native',613),('buy-v2-token',613),('buy-v2-token22',613)]:suites[name]=freeze(D/f'regression-02/{name}.json',name,count)
assert sum(v['cases'] for v in suites.values())==7093
new={}
for side,count in [('buy',419),('sell',413)]:
 new[side]={}
 for fam in ['native','token','token22']:new[side][fam]=freeze(D/f'main-{side}_pump_swap-{fam}.json',f'{side}-pump-swap-{fam}',count)
assert sum(v['successes'] for f in new.values() for v in f.values())==680
burn=json.loads((P/'burn-sequences/verification.json').read_text());assert burn['candidate_sha256']==digest and burn['success'] and burn['case_count']==6
shutil.copy2(R/'repro/mayhem/twentytwo/captured-fixtures.tar.gz',P/'captured-fixtures.tar.gz');shutil.copy2(R/'repro/mayhem/twentytwo/source-snapshot.tar.gz',P/'inherited-main22-source-snapshot.tar.gz');shutil.copy2(D/'main22-prepromotion-verification.json',P/'predecessor-verification.json');shutil.copy2(D/'static-provenance.json',P/'static-provenance.json')
sources=[R/path for path in main['source_sha256']]+[R/'programs/mayhem/README.md'];archive(P/'source-snapshot.tar.gz',[(p,str(p.relative_to(R))) for p in sources])
tests=[R/'scripts'/x for x in ['build_partial_candidate.py','build_source_manifest.py','compare.py','mayhem_pump_swap_fixture.py','mayhem_pump_swap_differential.py','verify_mayhem_pump_swap.py','mayhem_buy_v2_fixture.py','mayhem_buy_v2_differential.py','verify_mayhem_buy_v2.py','mayhem_sell_v2_fixture.py','mayhem_sell_v2_differential.py','verify_mayhem_sell_v2.py','mayhem_buy_fixture.py','mayhem_buy_differential.py','verify_mayhem_buy.py','mayhem_sell_fixture.py','mayhem_sell_differential.py','verify_mayhem_sell.py','pump_trade_fixture.py','mayhem_burn_sequence.py','verify_mayhem_burn_sequence.py']+[f'mayhem_validate_{name}.py' for name in ['admin','fee_recipient','extend','withdraw','quote_withdraw','sweeps']]]+[P/'buy-pump-swap-cases.json',P/'sell-pump-swap-cases.json',R/'repro/mayhem/twentytwo/buy-v2-cases.json',R/'repro/mayhem/twentyone/sell-v2-cases.json',R/'repro/mayhem/twenty/buy-cases.json',R/'repro/mayhem/nineteen/sell-cases.json']
archive(P/'test-snapshot.tar.gz',[(p,str(p.relative_to(R))) for p in tests]);testhashes={str(p.relative_to(R)):sha(p) for p in tests};write(P/'test-source-sha256.json',testhashes)
inputs=[R/f'evidence/original/{name}/{f}' for name in ['mayhem','pump','pump_amm','pump_fees'] for f in ['deployed.so','capture.json']]+[R/f'evidence/dependencies/{name}/{f}' for name in ['spl_token','spl_token_2022','associated_token'] for f in ['deployed.so','capture.json']]+[R/'research/imported-lab/analysis/pump_fun'/x for x in ['curve-fresh-trades-v3-signed-surfpool.json','amm-v2-trade-fixture.json','config-snapshot.json']]+[P/'captured-fixtures.tar.gz']+[p for p in tests if p.suffix=='.json']
write(P/'runtime-manifest.json',{'scope':'Exact ordinary-signature local runtime inputs; trades use explicitly synthetic business states, burn uses genuine snapshots. No network or broadcast.','python_version':sys.version,'python_executable_sha256':sha(Path(sys.executable)),'platform':platform.platform(),'solders_version':importlib.metadata.version('solders'),'solders_binary_sha256':sha(Path(sb.__file__)),'signature_verification':True,'blockhash_check':True,'candidate_sha256':digest,'inputs_sha256':{str(p.relative_to(R)):sha(p) for p in inputs},'test_source_sha256':testhashes})
archive(P/'static-evidence.tar.gz',[(p,str(p.relative_to(D))) for p in D.glob('*.asm')]+[(p,str(p.relative_to(D))) for p in (D/'parser-static').rglob('*') if p.is_file()]+[(D/'static-provenance.json','static-provenance.json')])
retained=[]
for num in ['01','02']:
 b=D/f'build-{num}'
 for name in ['build-attempt.json','build-comparison.json','build.log','artifacts/mayhem_recovered.so']:retained.append((b/name,str((b/name).relative_to(D))))
 retained.append((D/f'build-{num}-source.tar.gz',f'build-{num}-source.tar.gz'))
for p in D.iterdir():
 if p.is_file() and p.name not in ['main22-prepromotion-verification.json'] and (p.suffix in ['.py','.rs'] or p.name.startswith(('original-','baseline-','matrix-','verification-'))):retained.append((p,p.name))
retained.extend((p,str(p.relative_to(D))) for p in (D/'regression-02').glob('*.log'));retained.append((D/'regression-02/commands.json','regression-02/commands.json'));archive(P/'retained-attempts.tar.gz',retained)
summary={'scope':'Twenty-four recovered Mayhem handlers; partial historical-program reconstruction.','candidate_sha256':digest,'candidate_bytes':(P/'mayhem_recovered.so').stat().st_size,'original_sha256':main['comparison']['original_sha256'],'full_byte_equality':False,'main_source_sha256':main['source_sha256'],'main_scratch_whole_file_identity':True,'pump_swap_families':new,'pump_swap_cases':2496,'pump_swap_successes':680,'pump_swap_rejections':1816,'pump_swap_signed_transactions':4992,'inherited_suites':suites,'inherited_cases_including_burn':7099,'burn_instruction_comparisons':6,'burn_sequences':3,'burn_signed_transactions':12,'total_instruction_comparisons':9595,'total_signed_transactions':19190,'suite_count':21,'legacy_receipt_source_metadata':'Six inherited admin suites record then-current main22 source hashes while executing the byte-identical combined24 scratch candidate. The predecessor source snapshot and actual integrated source closure are both preserved.','diagnostic_differences':'26 new panic cases retain source-location differences; eight zero-effective-reserve cases also differ in unwrap-message detail. Errors/full watched state/rollback/events/CPIs match.','historical_pump_swap_replay':False,'retained_attempts':'Build01 baseline only; static follow-up corrected CPI flags/error text in build02. First full-matrix harness stopped before arbitrary replacement signer transaction construction; fixture replaced that key with a separate ordinarily signing test-owned keypair, preserving original authorization.'};write(P/'summary.json',summary)
for side in new:
 for fam in new[side]:subprocess.run([sys.executable,'scripts/verify_mayhem_pump_swap.py','--candidate',str(P/'mayhem_recovered.so'),'--receipts',str(P/f'{side}-pump-swap-{fam}-differential.json.gz'),'--output',str(P/f'{side}-pump-swap-{fam}-verification.json')],check=True,stdout=subprocess.DEVNULL)
for side in ['buy','sell']:
 for fam in ['native','token','token22']:subprocess.run([sys.executable,f'scripts/verify_mayhem_{side}_v2.py','--candidate',str(P/'mayhem_recovered.so'),'--receipts',str(P/f'{side}-v2-{fam}-differential.json.gz'),'--output',str(P/f'{side}-v2-{fam}-verification.json')],check=True,stdout=subprocess.DEVNULL)
 subprocess.run([sys.executable,f'scripts/verify_mayhem_{side}.py','--candidate',str(P/'mayhem_recovered.so'),'--receipts',str(P/f'{side}-differential.json.gz'),'--output',str(P/f'{side}-verification.json')],check=True,stdout=subprocess.DEVNULL)
status=json.loads((R/'repro/status.json').read_text())['mayhem'];assert len(status['implemented_handlers'])==22;status['implemented_handlers']+=['buy_pump_swap','sell_pump_swap'];status.update(candidate_artifact='repro/mayhem/twentyfour/mayhem_recovered.so',comparison_report='repro/mayhem/twentyfour/build-comparison.json',build_log='repro/mayhem/twentyfour/build.log',validated_cases=9595)
status['validation_reports']=[v['receipt'] for v in suites.values()]+[v['receipt'] for families in new.values() for v in families.values()]+['repro/mayhem/twentyfour/burn-sequences/verification.json'];status['genuine_snapshot_sequences'].update(report='repro/mayhem/twentyfour/burn-sequences/comparison.json',verification='repro/mayhem/twentyfour/burn-sequences/verification.json')
for side in ['buy','sell']:
 status[f'{side}_validation'].update(report=f'repro/mayhem/twentyfour/{side}-differential.json.gz',verification=f'repro/mayhem/twentyfour/{side}-verification.json')
 for fam in ['native','token','token22']:status[f'{side}_v2_validation']['families'][fam].update(suites[f'{side}-v2-{fam}'],verification=f'repro/mayhem/twentyfour/{side}-v2-{fam}-verification.json')
 fams=new[side];total=sum(v['cases'] for v in fams.values());succ=sum(v['successes'] for v in fams.values());status[f'{side}_pump_swap_validation']={'synthetic_cases':total,'successful_cases':succ,'rejection_cases':total-succ,'signed_transactions':2*total,'families':{k:dict(v,verification=f'repro/mayhem/twentyfour/{side}-pump-swap-{k}-verification.json') for k,v in fams.items()},'historical_replay':False}
write(D/'main-status-entry.json',status)
manifest={str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='manifest.json'};write(P/'manifest.json',{'scope':'Immutable main24 candidate; full-file main/scratch identity; synthetic trade/genuine burn scope.','files':manifest})
owned=['programs/mayhem/README.md','programs/mayhem/src/lib.rs','programs/mayhem/src/instructions/mod.rs','programs/mayhem/src/instructions/buy_pump_swap.rs','programs/mayhem/src/instructions/sell_pump_swap.rs','programs/mayhem/src/instructions/pump_swap_types.rs','audit/mayhem/RECOVERY.md','scripts/mayhem_pump_swap_fixture.py','scripts/mayhem_pump_swap_differential.py','scripts/verify_mayhem_pump_swap.py']+[str(p.relative_to(R)) for p in sorted(P.rglob('*')) if p.is_file()];write(D/'owned-files.json',owned)
print(json.dumps({'files':len(manifest),'bytes':sum(p.stat().st_size for p in P.rglob('*') if p.is_file()),'candidate_sha256':digest,'cases':9595,'source_files':len(main['source_sha256']),'test_inputs':len(tests),'runtime_inputs':len(inputs),'retained_files':len(retained)},indent=2))
