from pathlib import Path
D=Path(__file__).resolve().parent
for side in ['buy','sell']:
 s=(D/f'crate/src/instructions/{side}_v2.rs').read_text();s=s[s.index('fn math()->Error'):];s=s.replace(f'Context<{side.title()}V2>',f'Context<{side.title()}PumpSwap>')
 s=s.replace('a.mayhem_base_token_vault','a.mayhem_token_vault').replace('a.mayhem_quote_token_vault','a.mayhem_quote_vault')
 s=s.replace(' a.mayhem_state.field_89=now as u64;',' a.mayhem_state.field_89=now as u64;\n let effective_quote=u64::try_from((a.pool_quote_token_account.amount as i128).checked_add(a.pool.virtual_quote_reserves).ok_or_else(math)?).map_err(|_|math())?;')
 s=s.replace('a.bonding_curve.real_sol_reserves','effective_quote')
 s=s.replace(' let c=&a.bonding_curve;\n let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;',' let vt=a.pool_base_token_account.amount as u128;let vs=effective_quote as u128;')
 s=s.replace('c.real_sol_reserves as u128','effective_quote as u128').replace('.min(c.real_token_reserves)','')
 start=s.index(' let infos=');end=s.index(' let after_quote=',start)
 fields=['pool','sol_vault','global_config','mint','quote_mint','mayhem_token_vault','mayhem_quote_vault','pool_base_token_account','pool_quote_token_account','protocol_fee_recipient','protocol_fee_recipient_token_account','base_token_program','quote_token_program','system_program','associated_token_program','pump_swap_event_authority','pump_swap_program','coin_creator_vault_ata','coin_creator_vault_authority']
 writable=[True,True,False,False,False,True,True,True,True,False,True,False,False,False,False,False,False,True,False]
 if side=='buy':fields+=['global_volume_accumulator','user_volume_accumulator'];writable+=[False,True]
 fields+=['fee_config','fee_program','buyback_recipient','buyback_recipient_ata'];writable+=[False,False,False,True]
 cpi=' let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];\n'
 if side=='buy':cpi+=' if native {\n  let ix=anchor_lang::solana_program::system_instruction::transfer(&a.sol_vault.key(),&a.mayhem_quote_vault.key(),output);\n  invoke_signed(&ix,&[a.sol_vault.to_account_info(),a.mayhem_quote_vault.to_account_info(),a.system_program.to_account_info()],&[seeds])?;\n  invoke_signed(&Instruction{program_id:a.quote_token_program.key(),accounts:vec![AccountMeta::new(a.mayhem_quote_vault.key(),false)],data:vec![17]},&[a.mayhem_quote_vault.to_account_info(),a.quote_token_program.to_account_info()],&[seeds])?;\n  a.mayhem_quote_vault.reload()?;\n }\n'
 cpi+=' let infos=['+','.join('a.'+f+'.to_account_info()' for f in fields)+'];\n let writable=['+','.join(str(w).lower() for w in writable)+'];\n let metas=infos.iter().enumerate().map(|(i,info)|if writable[i]{AccountMeta::new(*info.key,i==1)}else{AccountMeta::new_readonly(*info.key,i==1)}).collect();\n'
 cpi+=' let mut data=vec!['+('0x66,0x06,0x3d,0x12,0x01,0xda,0xeb,0xea' if side=='buy' else '0x33,0xe6,0x85,0xa4,0x01,0x7f,0x83,0xad')+'];data.extend_from_slice(&input.to_le_bytes());data.extend_from_slice(&'+('output' if side=='buy' else 'minimum')+'.to_le_bytes());'+('data.push(0);' if side=='buy' else '')+'\n'
 cpi+=' require!(invoke_signed(&Instruction{program_id:AMM_ID,accounts:metas,data},&infos,&[seeds]).is_ok(),PumpSwapError::PumpSwapCpiFailed);\n if native {invoke_signed(&Instruction{program_id:a.quote_token_program.key(),accounts:vec![AccountMeta::new(a.mayhem_quote_vault.key(),false),AccountMeta::new(a.sol_vault.key(),false),AccountMeta::new_readonly(a.sol_vault.key(),true)],data:vec![9]},&[a.mayhem_quote_vault.to_account_info(),a.sol_vault.to_account_info(),a.sol_vault.to_account_info(),a.quote_token_program.to_account_info()],&[seeds])?;}\n a.mayhem_token_vault.reload()?;a.pool_base_token_account.reload()?;a.pool_quote_token_account.reload()?;if !native{a.mayhem_quote_vault.reload()?;}\n'
 s=s[:start]+cpi+s[end:]
 s=s.replace('a.bonding_curve.virtual_sol_reserves','a.pool_quote_token_account.amount').replace('a.bonding_curve.virtual_token_reserves','a.pool_base_token_account.amount').replace('a.bonding_curve.real_token_reserves','a.pool_base_token_account.amount')
 # Events observe actual post-CPI reserves, not the synthetic virtual reserve used in sizing.
 s=s.replace('real_sol:if native{effective_quote}', 'real_sol:if native{a.pool_quote_token_account.amount}').replace('real_quote:effective_quote','real_quote:a.pool_quote_token_account.amount')
 (D/f'{side}-handler-draft.rs').write_text(s)
