from pathlib import Path
import gzip,hashlib,io,json,tarfile,subprocess,sys
R=Path.cwd();D=R/'work/mayhem-pump-swap-followup';P=R/'repro/mayhem/twentyfour';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bh=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((P/'manifest.json').read_text())['files'];assert set(m)=={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='manifest.json'}
for name,h in m.items():assert sha(P/name)==h,name
c=json.loads((P/'build-comparison.json').read_text());digest=sha(P/'mayhem_recovered.so');assert c['comparison']['candidate_sha256']==digest
for name,h in c['source_sha256'].items():assert sha(R/name)==h,name
with tarfile.open(P/'source-snapshot.tar.gz') as t:
 for name,h in c['source_sha256'].items():assert bh(t.extractfile(name).read())==h,name
runtime=json.loads((P/'runtime-manifest.json').read_text());tests=json.loads((P/'test-source-sha256.json').read_text());assert tests==runtime['test_source_sha256'];assert 'scripts/build_source_manifest.py' in tests
with tarfile.open(P/'test-snapshot.tar.gz') as t:
 assert set(t.getnames())==set(tests)
 for name,h in tests.items():assert sha(R/name)==h==bh(t.extractfile(name).read()),name
for name,h in runtime['inputs_sha256'].items():assert sha(R/name)==h,name
with tarfile.open(P/'inherited-main22-source-snapshot.tar.gz') as t:oldsrc={name:bh(t.extractfile(name).read()) for name in t.getnames()}
comparisons=successes=0
for f in sorted(P.glob('*-differential.json.gz')):
 name=f.name.removesuffix('-differential.json.gz');j=json.loads(gzip.decompress(f.read_bytes()));assert j['candidate_sha256']==digest and not j['mismatches'];assert j['case_count']==len(j['cases']);comparisons+=j['case_count']
 for path,h in j.get('harness_sha256',{}).items():assert sha(R/path)==h,path
 for path,h in j.get('source_sha256',{}).items():assert (oldsrc.get(path) if path.startswith('programs/mayhem/') else sha(R/path))==h,path
 if name in ['buy','sell'] or '-v2-' in name or '-pump-swap-' in name:
  v=json.loads((P/f'{name}-verification.json').read_text());assert v['receipt_sha256']==sha(f) and v['candidate_sha256']==digest and v['case_count']==j['case_count'] and not v['mismatches']
  if '-pump-swap-' in name:successes+=v['successful_cases']
assert comparisons==9589 and successes==680
burn=json.loads((P/'burn-sequences/verification.json').read_text());assert burn['candidate_sha256']==digest and burn['success'] and burn['case_count']==6;comparisons+=6;assert comparisons==9595
with tarfile.open(P/'retained-attempts.tar.gz') as outer:
 assert not any('/target/' in name or '/.git/' in name or 'keypair' in name for name in outer.getnames())
 for name in ['build-01','build-02']:
  comparison=json.loads(outer.extractfile(f'{name}/build-comparison.json').read());binary=outer.extractfile(f'{name}/artifacts/mayhem_recovered.so').read();assert bh(binary)==comparison['comparison']['candidate_sha256']
  with tarfile.open(fileobj=io.BytesIO(outer.extractfile(f'{name}-source.tar.gz').read())) as t:
   for path,h in comparison['source_sha256'].items():
    n=str(Path(path).relative_to('work/mayhem-pump-swap-followup/crate'));assert bh(t.extractfile(n).read())==h,(name,n)
  if name=='build-02':assert binary==(P/'mayhem_recovered.so').read_bytes()
with tarfile.open(P/'static-evidence.tar.gz') as t:
 child=json.loads(t.extractfile('parser-static/manifest.json').read())
 for row in child['files']:
  name=str(Path(row['path']).relative_to('work/mayhem-pump-swap-followup'));assert bh(t.extractfile(name).read())==row['sha256'],name
old=R/'repro/mayhem/twentytwo';om=json.loads((old/'manifest.json').read_text())['files'];assert all(sha(old/name)==h for name,h in om.items())
fixtures=D/'portable-burn-inputs';fixtures.mkdir(exist_ok=True)
with tarfile.open(P/'captured-fixtures.tar.gz') as t:t.extractall(fixtures,filter='data')
subprocess.run([sys.executable,'scripts/verify_mayhem_burn_sequence.py','--fixtures',str(fixtures),'--receipts',str(P/'burn-sequences')],check=True,stdout=subprocess.DEVNULL)
for name,h in m.items():assert sha(P/name)==h,name
status=json.loads((D/'main-status-entry.json').read_text());assert len(status['implemented_handlers'])==24 and status['validated_cases']==9595
for path in status['validation_reports']+[status['candidate_artifact'],status['comparison_report'],status['build_log']]:assert (R/path).is_file(),path
assert all(p.stat().st_size<100_000_000 for p in P.rglob('*') if p.is_file())
result={'package_files':len(m),'source_files':len(c['source_sha256']),'test_inputs':len(tests),'runtime_inputs':len(runtime['inputs_sha256']),'candidate_sha256':digest,'comparisons':comparisons,'signed_transactions':2*comparisons,'pump_swap_successes':successes,'prior22_package_unchanged':True,'whole_file_main_scratch_identity':True,'archive_hash_closure':True,'independent_verifiers_passed':True,'portable_burn_fixture_verification':True,'all_status_references_exist':True,'no_file_exceeds_100MB':True};(D/'package-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
