093510: stxdw [r10 - 0x98], r4
093518: stxdw [r10 - 0xa0], r3
093520: mov64 r9, r2
093528: ldxdw r7, [r9 + 0x18]
093530: ldxdw r3, [r9 + 0x10]
093538: ldxdw r4, [r9 + 0x8]
093540: ldxdw r2, [r5 - 0xfe8]
093548: ldxdw r6, [r5 - 0xff0]
093550: ldxdw r8, [r5 - 0xff8]
093558: ldxdw r5, [r5 - 0x1000]
093560: stxdw [r10 - 0x90], r5
093568: ldxdw r5, [r9 + 0x0]
093570: lddw r0, -0x21708a111e0922fa
093580: jne r5, r0, +0x9 ; branch 0x935d0
093588: lddw r0, -0x2532931b43a2bde8
093598: jne r4, r0, +0x6 ; branch 0x935d0
0935a0: lddw r0, 0x270db9834dfc1ab6
0935b0: jne r3, r0, +0x3 ; branch 0x935d0
0935b8: lddw r0, -0x3745e27d7064202
0935c8: jeq r7, r0, +0xc ; branch 0x93630
0935d0: lddw r0, -0x6c5e9a281e0922fa
0935e0: jne r5, r0, +0x2c ; branch 0x93748
0935e8: lddw r5, -0x53861431b91e3427
0935f8: jne r4, r5, +0x29 ; branch 0x93748
093600: lddw r4, -0x6ec8a4a0127a4be4
093610: jne r3, r4, +0x26 ; branch 0x93748
093618: lddw r3, -0x56ff00817a0a73c6
093628: jne r7, r3, +0x23 ; branch 0x93748
093630: stxdw [r10 - 0xa8], r1
093638: stxdw [r10 - 0x48], r2
093640: stw [r10 - 0x50], 0x8
093648: mov64 r1, r10
093650: add64 r1, -0x80
093658: mov64 r2, r10
093660: add64 r2, -0x50
093668: call -0x18f ; call 0x929f8
093670: mov64 r7, r6
093678: add64 r7, 0x3
093680: mov64 r1, 0x1
093688: jlt r7, r6, +0x1 ; branch 0x93698
093690: mov64 r1, 0x0
093698: stxdw [r10 - 0xb0], r9
0936a0: and64 r1, 0x1
0936a8: jne r1, 0x0, +0x8e ; branch 0x93b20
0936b0: mov64 r1, 0x0
0936b8: stxdw [r10 - 0x88], r1
0936c0: mov64 r1, r7
0936c8: mov64 r2, 0x0
0936d0: mov64 r3, 0x22
0936d8: mov64 r4, 0x0
0936e0: call 0x3213 ; call 0xac780
0936e8: mov64 r9, r0
0936f0: mov64 r2, 0x1
0936f8: jne r1, 0x0, +0x1 ; branch 0x93708
093700: mov64 r2, 0x0
093708: and64 r2, 0x1
093710: jne r2, 0x0, +0x1 ; branch 0x93720
093718: jsge r9, 0x0, +0xa ; branch 0x93770
093720: ldxdw r1, [r10 - 0x88]
093728: mov64 r2, r9
093730: lddw r3, 0xb1d10 ; rodata b'\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1c\x06\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1f\x06\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00$\x06\x00\x00\x12\x00\x00\x00\x00\x00\x00'
093740: call 0x2020 ; call 0xa3848
093748: lddw r2, -0x8000000000000000
093758: stxdw [r1 + 0x0], r2
093760: stw [r1 + 0x8], 0x6
093768: ja +0x75 ; branch 0x93b18
093770: call -0x2031 ; call 0x835f0
093778: mov64 r1, 0x1
093780: stxdw [r10 - 0x88], r1
093788: mov64 r1, r9
093790: mov64 r2, 0x1
093798: call -0x20c2 ; call 0x83190
0937a0: jeq r0, 0x0, -0x11 ; branch 0x93720
0937a8: mov64 r9, 0x1
0937b0: jeq r6, 0x0, +0x1 ; branch 0x937c0
0937b8: mov64 r9, 0x0
0937c0: stxdw [r10 - 0x60], r0
0937c8: stxdw [r10 - 0x68], r7
0937d0: ldxdw r2, [r10 - 0xa0]
0937d8: ldxdw r1, [r2 + 0x18]
0937e0: stxdw [r0 + 0x18], r1
0937e8: ldxdw r1, [r2 + 0x10]
0937f0: stxdw [r0 + 0x10], r1
0937f8: ldxdw r1, [r2 + 0x8]
093800: stxdw [r0 + 0x8], r1
093808: ldxdw r1, [r2 + 0x0]
093810: stxdw [r0 + 0x0], r1
093818: sth [r0 + 0x20], 0x100
093820: ldxdw r2, [r10 - 0x98]
093828: ldxdw r1, [r2 + 0x0]
093830: stxdw [r0 + 0x22], r1
093838: ldxdw r1, [r2 + 0x8]
093840: stxdw [r0 + 0x2a], r1
093848: ldxdw r1, [r2 + 0x10]
093850: stxdw [r0 + 0x32], r1
093858: ldxdw r1, [r2 + 0x18]
093860: stxdw [r0 + 0x3a], r1
093868: sth [r0 + 0x42], 0x100
093870: stdw [r10 - 0x58], 0x2
093878: jne r7, 0x2, +0x6 ; branch 0x938b0
093880: mov64 r1, r10
093888: add64 r1, -0x68
093890: lddw r2, 0xb1d28 ; rodata b'\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1f\x06\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00$\x06\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x009\x06\x00\x00+\x00\x00\x00\x00\x00\x00'
0938a0: call 0xf57 ; call 0x9b360
0938a8: ldxdw r0, [r10 - 0x60]
0938b0: ldxdw r2, [r10 - 0x90]
0938b8: ldxdw r1, [r2 + 0x18]
0938c0: stxdw [r0 + 0x5c], r1
0938c8: ldxdw r1, [r2 + 0x10]
0938d0: stxdw [r0 + 0x54], r1
0938d8: ldxdw r1, [r2 + 0x8]
0938e0: stxdw [r0 + 0x4c], r1
0938e8: ldxdw r1, [r2 + 0x0]
0938f0: stxdw [r0 + 0x44], r1
0938f8: stxb [r0 + 0x64], r9
093900: stb [r0 + 0x65], 0x0
093908: stdw [r10 - 0x58], 0x3
093910: jeq r6, 0x0, +0x26 ; branch 0x93a48
093918: mov64 r7, 0x3
093920: mov64 r9, 0x0
093928: lsh64 r6, 0x3
093930: ja +0x11 ; branch 0x939c0
093938: add64 r8, 0x8
093940: ldxdw r1, [r10 - 0x60]
093948: add64 r1, r9
093950: ldxdw r2, [r10 - 0x38]
093958: stxdw [r1 + 0x7e], r2
093960: ldxdw r2, [r10 - 0x40]
093968: stxdw [r1 + 0x76], r2
093970: ldxdw r2, [r10 - 0x48]
093978: stxdw [r1 + 0x6e], r2
093980: ldxdw r2, [r10 - 0x50]
093988: stxdw [r1 + 0x66], r2
093990: sth [r1 + 0x86], 0x1
093998: add64 r9, 0x22
0939a0: add64 r7, 0x1
0939a8: stxdw [r10 - 0x58], r7
0939b0: add64 r6, -0x8
0939b8: jeq r6, 0x0, +0x11 ; branch 0x93a48
0939c0: ldxdw r1, [r8 + 0x0]
0939c8: ldxdw r2, [r1 + 0x18]
0939d0: stxdw [r10 - 0x38], r2
0939d8: ldxdw r2, [r1 + 0x10]
0939e0: stxdw [r10 - 0x40], r2
0939e8: ldxdw r2, [r1 + 0x8]
0939f0: stxdw [r10 - 0x48], r2
0939f8: ldxdw r1, [r1 + 0x0]
093a00: stxdw [r10 - 0x50], r1
093a08: ldxdw r1, [r10 - 0x68]
093a10: jne r7, r1, -0x1c ; branch 0x93938
093a18: mov64 r1, r10
093a20: add64 r1, -0x68
093a28: lddw r2, 0xb1d40 ; rodata b'\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00$\x06\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x009\x06\x00\x00+\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x009\x06\x00\x00\x18\x00\x00\x00\x00\x00\x00'
093a38: call 0xf24 ; call 0x9b360
093a40: ja -0x22 ; branch 0x93938
093a48: ldxdw r1, [r10 - 0x58]
093a50: stxdw [r10 - 0x40], r1
093a58: ldxdw r1, [r10 - 0x60]
093a60: stxdw [r10 - 0x48], r1
093a68: ldxdw r1, [r10 - 0x68]
093a70: stxdw [r10 - 0x50], r1
093a78: ldxdw r4, [r10 - 0xb0]
093a80: ldxdw r1, [r4 + 0x18]
093a88: ldxdw r2, [r4 + 0x10]
093a90: ldxdw r3, [r4 + 0x8]
093a98: ldxdw r4, [r4 + 0x0]
093aa0: ldxdw r5, [r10 - 0x80]
093aa8: stxdw [r10 - 0x38], r5
093ab0: ldxdw r5, [r10 - 0x78]
093ab8: stxdw [r10 - 0x30], r5
093ac0: ldxdw r5, [r10 - 0x70]
093ac8: stxdw [r10 - 0x28], r5
093ad0: stxdw [r10 - 0x20], r4
093ad8: stxdw [r10 - 0x18], r3
093ae0: stxdw [r10 - 0x10], r2
093ae8: stxdw [r10 - 0x8], r1
093af0: mov64 r2, r10
093af8: add64 r2, -0x50
093b00: ldxdw r1, [r10 - 0xa8]
093b08: mov64 r3, 0x50
093b10: call 0x2d4e ; call 0xaa588
093b18: exit
093b20: lddw r1, 0xb1cf8 ; rodata b'\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1c\x06\x00\x00+\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1c\x06\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00{\xcc\n\x00\x13\x00\x00\x00\x00\x00\x00\x00\x1f\x06\x00\x00\x0e\x00\x00\x00\x00\x00\x00'
093b30: call 0x29ed ; call 0xa8aa0
