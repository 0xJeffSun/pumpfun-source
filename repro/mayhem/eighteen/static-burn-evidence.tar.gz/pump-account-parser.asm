00a1c0: ldxdw r2, [r3 + 0x8]
00a1c8: jeq r2, 0x0, +0x8 ; branch 0xa210
00a1d0: add64 r2, -0x1
00a1d8: stxdw [r3 + 0x8], r2
00a1e0: ldxdw r2, [r3 + 0x0]
00a1e8: mov64 r4, r2
00a1f0: add64 r4, 0x30
00a1f8: stxdw [r3 + 0x0], r4
00a200: call -0x5af ; call 0x7490
00a208: ja +0x6 ; branch 0xa240
00a210: mov64 r6, r1
00a218: mov64 r1, 0xbbd
00a220: call 0x12078 ; call 0x9a5e8
00a228: stxdw [r6 + 0x8], r1
00a230: stxdw [r6 + 0x0], r0
00a238: stb [r6 + 0x51], 0x2
00a240: exit
