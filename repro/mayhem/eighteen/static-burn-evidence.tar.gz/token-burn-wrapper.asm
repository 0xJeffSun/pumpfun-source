090bc0: mov64 r7, r1
090bc8: ldxdw r4, [r7 + 0x18]
090bd0: ldxdw r3, [r7 + 0x48]
090bd8: ldxdw r1, [r7 + 0x78]
090be0: stxdw [r10 - 0xfe8], r2
090be8: stxdw [r10 - 0x1000], r1
090bf0: stdw [r10 - 0xff0], 0x0
090bf8: stdw [r10 - 0xff8], 0x8
090c00: mov64 r2, r7
090c08: add64 r2, 0xb8
090c10: mov64 r1, r10
090c18: add64 r1, -0x90
090c20: mov64 r5, r10
090c28: call 0x51c ; call 0x93510
090c30: ldxw r3, [r10 - 0x84]
090c38: ldxw r8, [r10 - 0x88]
090c40: ldxdw r9, [r10 - 0x90]
090c48: lddw r1, -0x8000000000000000
090c58: stxdw [r10 - 0xe8], r7
090c60: jne r9, r1, +0x4e ; branch 0x90ed8
090c68: mov64 r1, r8
090c70: mov64 r2, r3
090c78: call 0xd96 ; call 0x97930
090c80: mov64 r6, r0
090c88: stxdw [r10 - 0xf0], r1
090c90: ldxdw r1, [r7 + 0x20]
090c98: ldxdw r2, [r1 + 0x0]
090ca0: add64 r2, -0x1
090ca8: stxdw [r1 + 0x0], r2
090cb0: jne r2, 0x0, +0x3 ; branch 0x90cd0
090cb8: mov64 r1, r7
090cc0: add64 r1, 0x20
090cc8: call 0x1edb ; call 0xa03a8
090cd0: ldxdw r1, [r7 + 0x28]
090cd8: ldxdw r2, [r1 + 0x0]
090ce0: add64 r2, -0x1
090ce8: stxdw [r1 + 0x0], r2
090cf0: jne r2, 0x0, +0x3 ; branch 0x90d10
090cf8: mov64 r1, r7
090d00: add64 r1, 0x28
090d08: call 0x1ec9 ; call 0xa0358
090d10: ldxdw r1, [r7 + 0x50]
090d18: ldxdw r2, [r1 + 0x0]
090d20: add64 r2, -0x1
090d28: stxdw [r1 + 0x0], r2
090d30: jne r2, 0x0, +0x3 ; branch 0x90d50
090d38: mov64 r1, r7
090d40: add64 r1, 0x50
090d48: call 0x1ecb ; call 0xa03a8
090d50: ldxdw r1, [r7 + 0x58]
090d58: ldxdw r2, [r1 + 0x0]
090d60: add64 r2, -0x1
090d68: stxdw [r1 + 0x0], r2
090d70: jne r2, 0x0, +0x3 ; branch 0x90d90
090d78: mov64 r1, r7
090d80: add64 r1, 0x58
090d88: call 0x1eb9 ; call 0xa0358
090d90: ldxdw r1, [r7 + 0x80]
090d98: ldxdw r2, [r1 + 0x0]
090da0: add64 r2, -0x1
090da8: stxdw [r1 + 0x0], r2
090db0: jne r2, 0x0, +0x3 ; branch 0x90dd0
090db8: mov64 r1, r7
090dc0: add64 r1, 0x80
090dc8: call 0x1ebb ; call 0xa03a8
090dd0: ldxdw r1, [r7 + 0x88]
090dd8: ldxdw r2, [r1 + 0x0]
090de0: add64 r2, -0x1
090de8: stxdw [r1 + 0x0], r2
090df0: jne r2, 0x0, +0x3 ; branch 0x90e10
090df8: mov64 r1, r7
090e00: add64 r1, 0x88
090e08: call 0x1ea9 ; call 0xa0358
090e10: ldxdw r8, [r7 + 0x8]
090e18: ldxdw r7, [r7 + 0x10]
090e20: jeq r7, 0x0, +0x47 ; branch 0x91060
090e28: mov64 r9, r8
090e30: add64 r9, 0x10
090e38: ja +0x3 ; branch 0x90e58
090e40: add64 r9, 0x30
090e48: add64 r7, -0x1
090e50: jeq r7, 0x0, +0x41 ; branch 0x91060
090e58: ldxdw r1, [r9 - 0x8]
090e60: ldxdw r2, [r1 + 0x0]
090e68: add64 r2, -0x1
090e70: stxdw [r1 + 0x0], r2
090e78: jne r2, 0x0, +0x3 ; branch 0x90e98
090e80: mov64 r1, r9
090e88: add64 r1, -0x8
090e90: call 0x1ea2 ; call 0xa03a8
090e98: ldxdw r1, [r9 + 0x0]
090ea0: ldxdw r2, [r1 + 0x0]
090ea8: add64 r2, -0x1
090eb0: stxdw [r1 + 0x0], r2
090eb8: jne r2, 0x0, -0x10 ; branch 0x90e40
090ec0: mov64 r1, r9
090ec8: call 0x1e91 ; call 0xa0358
090ed0: ja -0x13 ; branch 0x90e40
090ed8: add64 r7, 0x78
090ee0: stxdw [r10 - 0xf0], r7
090ee8: ldxdw r7, [r10 - 0xe8]
090ef0: add64 r7, 0x48
090ef8: ldxdw r6, [r10 - 0xe8]
090f00: add64 r6, 0x18
090f08: mov64 r1, r10
090f10: add64 r1, -0xd0
090f18: mov64 r2, r10
090f20: add64 r2, -0x80
090f28: stxdw [r10 - 0xf8], r3
090f30: mov64 r3, 0x40
090f38: call 0x32c9 ; call 0xaa588
090f40: ldxdw r1, [r10 - 0xf8]
090f48: stxw [r10 - 0xd4], r1
090f50: stxw [r10 - 0xd8], r8
090f58: stxdw [r10 - 0xe0], r9
090f60: mov64 r8, r10
090f68: add64 r8, -0x90
090f70: mov64 r1, r8
090f78: mov64 r2, r7
090f80: ldxdw r7, [r10 - 0xe8]
090f88: mov64 r3, 0x30
090f90: call 0x32be ; call 0xaa588
090f98: mov64 r1, r10
090fa0: add64 r1, -0x60
090fa8: mov64 r2, r6
090fb0: mov64 r3, 0x30
090fb8: call 0x32b9 ; call 0xaa588
090fc0: mov64 r1, r10
090fc8: add64 r1, -0x30
090fd0: ldxdw r2, [r10 - 0xf0]
090fd8: mov64 r3, 0x30
090fe0: call 0x32b4 ; call 0xaa588
090fe8: ldxdw r4, [r7 + 0xa8]
090ff0: ldxdw r5, [r7 + 0xb0]
090ff8: mov64 r1, r10
091000: add64 r1, -0xe0
091008: mov64 r2, r8
091010: mov64 r3, 0x3
091018: call 0x149f ; call 0x9b518
091020: mov64 r3, r1
091028: mov64 r1, r0
091030: lsh64 r1, 0x20
091038: rsh64 r1, 0x20
091040: jne r1, 0x1a, +0x9 ; branch 0x91090
091048: mov64 r6, 0x2
091050: jne r9, 0x0, +0xe ; branch 0x910c8
091058: ja +0x12 ; branch 0x910f0
091060: ldxdw r1, [r10 - 0xe8]
091068: ldxdw r2, [r1 + 0x0]
091070: jeq r2, 0x0, +0x37 ; branch 0x91230
091078: mul64 r2, 0x30
091080: mov64 r1, r8
091088: ja +0x32 ; branch 0x91220
091090: mov64 r1, r0
091098: mov64 r2, r3
0910a0: call 0xd11 ; call 0x97930
0910a8: mov64 r6, r0
0910b0: stxdw [r10 - 0xf0], r1
0910b8: ldxdw r9, [r10 - 0xe0]
0910c0: jeq r9, 0x0, +0x5 ; branch 0x910f0
0910c8: mul64 r9, 0x22
0910d0: ldxdw r1, [r10 - 0xd8]
0910d8: mov64 r2, r9
0910e0: mov64 r3, 0x1
0910e8: call -0x1bca ; call 0x832a0
0910f0: ldxdw r2, [r10 - 0xc8]
0910f8: jeq r2, 0x0, +0x3 ; branch 0x91118
091100: ldxdw r1, [r10 - 0xc0]
091108: mov64 r3, 0x1
091110: call -0x1bcf ; call 0x832a0
091118: mov64 r1, r10
091120: add64 r1, -0x90
091128: call -0x284 ; call 0x8fd10
091130: ldxdw r9, [r7 + 0x8]
091138: ldxdw r7, [r7 + 0x10]
091140: jeq r7, 0x0, +0x16 ; branch 0x911f8
091148: mov64 r8, r9
091150: add64 r8, 0x10
091158: ja +0x3 ; branch 0x91178
091160: add64 r8, 0x30
091168: add64 r7, -0x1
091170: jeq r7, 0x0, +0x10 ; branch 0x911f8
091178: ldxdw r1, [r8 - 0x8]
091180: ldxdw r2, [r1 + 0x0]
091188: add64 r2, -0x1
091190: stxdw [r1 + 0x0], r2
091198: jne r2, 0x0, +0x3 ; branch 0x911b8
0911a0: mov64 r1, r8
0911a8: add64 r1, -0x8
0911b0: call 0x1e3e ; call 0xa03a8
0911b8: ldxdw r1, [r8 + 0x0]
0911c0: ldxdw r2, [r1 + 0x0]
0911c8: add64 r2, -0x1
0911d0: stxdw [r1 + 0x0], r2
0911d8: jne r2, 0x0, -0x10 ; branch 0x91160
0911e0: mov64 r1, r8
0911e8: call 0x1e2d ; call 0xa0358
0911f0: ja -0x13 ; branch 0x91160
0911f8: ldxdw r1, [r10 - 0xe8]
091200: ldxdw r2, [r1 + 0x0]
091208: jeq r2, 0x0, +0x4 ; branch 0x91230
091210: mul64 r2, 0x30
091218: mov64 r1, r9
091220: mov64 r3, 0x8
091228: call -0x1bf2 ; call 0x832a0
091230: mov64 r0, r6
091238: ldxdw r1, [r10 - 0xf0]
091240: exit
