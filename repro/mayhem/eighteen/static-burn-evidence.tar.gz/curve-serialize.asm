06dc00: mov64 r6, r2
06dc08: mov64 r7, r1
06dc10: mov64 r1, r6
06dc18: lddw r2, 0xacab8 ; rodata b'\x17\xb7\xf87`\xd8\xac`src/lib.rs\x00library/alloc/src/fmt.rs\x00programs/mayhem-program/src/ins'
06dc28: mov64 r3, 0x8
06dc30: call 0x535f ; call 0x97730
06dc38: jne r0, 0x0, +0x3d ; branch 0x6de28
06dc40: ldxdw r1, [r7 + 0x20]
06dc48: stxdw [r10 - 0x8], r1
06dc50: mov64 r2, r10
06dc58: add64 r2, -0x8
06dc60: mov64 r1, r6
06dc68: mov64 r3, 0x8
06dc70: call 0x5357 ; call 0x97730
06dc78: jne r0, 0x0, +0x35 ; branch 0x6de28
06dc80: ldxdw r1, [r7 + 0x28]
06dc88: stxdw [r10 - 0x8], r1
06dc90: mov64 r2, r10
06dc98: add64 r2, -0x8
06dca0: mov64 r1, r6
06dca8: mov64 r3, 0x8
06dcb0: call 0x534f ; call 0x97730
06dcb8: jne r0, 0x0, +0x2d ; branch 0x6de28
06dcc0: ldxdw r1, [r7 + 0x30]
06dcc8: stxdw [r10 - 0x8], r1
06dcd0: mov64 r2, r10
06dcd8: add64 r2, -0x8
06dce0: mov64 r1, r6
06dce8: mov64 r3, 0x8
06dcf0: call 0x5347 ; call 0x97730
06dcf8: jne r0, 0x0, +0x25 ; branch 0x6de28
06dd00: ldxdw r1, [r7 + 0x38]
06dd08: stxdw [r10 - 0x8], r1
06dd10: mov64 r2, r10
06dd18: add64 r2, -0x8
06dd20: mov64 r1, r6
06dd28: mov64 r3, 0x8
06dd30: call 0x533f ; call 0x97730
06dd38: jne r0, 0x0, +0x1d ; branch 0x6de28
06dd40: ldxdw r1, [r7 + 0x40]
06dd48: stxdw [r10 - 0x8], r1
06dd50: mov64 r2, r10
06dd58: add64 r2, -0x8
06dd60: mov64 r1, r6
06dd68: mov64 r3, 0x8
06dd70: call 0x5337 ; call 0x97730
06dd78: jne r0, 0x0, +0x15 ; branch 0x6de28
06dd80: ldxb r1, [r7 + 0x48]
06dd88: stxb [r10 - 0x8], r1
06dd90: mov64 r2, r10
06dd98: add64 r2, -0x8
06dda0: mov64 r1, r6
06dda8: mov64 r3, 0x1
06ddb0: call 0x532f ; call 0x97730
06ddb8: jne r0, 0x0, +0xd ; branch 0x6de28
06ddc0: mov64 r1, r6
06ddc8: mov64 r2, r7
06ddd0: mov64 r3, 0x20
06ddd8: call 0x532a ; call 0x97730
06dde0: jne r0, 0x0, +0x8 ; branch 0x6de28
06dde8: ldxb r1, [r7 + 0x49]
06ddf0: stxb [r10 - 0x8], r1
06ddf8: mov64 r2, r10
06de00: add64 r2, -0x8
06de08: mov64 r1, r6
06de10: mov64 r3, 0x1
06de18: call 0x5322 ; call 0x97730
06de20: jeq r0, 0x0, +0xe ; branch 0x6de98
06de28: mov64 r1, r0
06de30: and64 r1, 0x3
06de38: mov64 r2, r1
06de40: add64 r2, -0x2
06de48: jlt r2, 0x2, +0x6 ; branch 0x6de80
06de50: jeq r1, 0x0, +0x5 ; branch 0x6de80
06de58: ldxdw r1, [r0 + 0x7]
06de60: ldxdw r2, [r1 + 0x0]
06de68: jeq r2, 0x0, +0x2 ; branch 0x6de80
06de70: ldxdw r1, [r0 - 0x1]
06de78: callx r2
06de80: mov64 r1, 0xbbc
06de88: call 0x58eb ; call 0x9a5e8
06de90: exit
06de98: mov64 r0, 0x2
06dea0: ja -0x3 ; branch 0x6de90
