#!/usr/bin/env python3
"""Verify retained source-build provenance using file bytes only."""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = ROOT/'build-03'
attempt = json.loads((build/'build-attempt.json').read_text())
comparison = json.loads((build/'build-comparison.json').read_text())
static = json.loads((ROOT/'build-03-static-comparison.json').read_text())
assert attempt['returncode'] == 0 and attempt['source_unchanged']
assert attempt['source_sha256'] == attempt['source_after_sha256']
for path, expected in attempt['source_sha256'].items():
    assert sha(REPO/path) == expected, path
assert sha(build/'build.log') == attempt['build_log_sha256']
assert 'warning:' not in (build/'build.log').read_text()
assert (build/'sdk/syscalls.txt').stat().st_size == 0
assert sha(build/'artifacts/mayhem_burn_draft.so') == comparison['comparison']['candidate_sha256']
assert sha(REPO/'evidence/original/mayhem/deployed.so') == comparison['comparison']['original_sha256']
assert comparison['comparison']['full_byte_equality'] is False
assert set(static['undefined_symbols']['candidate']) <= set(static['undefined_symbols']['original'])
assert static['summary'] == {'selected_functions':46,'any_normalized_matches':12,
    'bounded_normalized_matches':12,'bounded_raw_equal':1}

# Resolve the actual ELF R8 seed-table pointers, without relocating or modifying the files.
decoded = []
for image,path,at in [('original',REPO/'evidence/original/mayhem/deployed.so',0xb13b0),
                     ('candidate',build/'artifacts/mayhem_burn_draft.so',0x22308)]:
    data = path.read_bytes()
    ptr = struct.unpack_from('<Q',data,at)[0] >> 32
    length = struct.unpack_from('<Q',data,at+8)[0]
    assert length == 2
    seeds = []
    for i in range(length):
        p,n = struct.unpack_from('<QQ',data,ptr+i*16)
        p >>= 32
        seeds.append({'pointer':hex(p),'length':n,'bytes':data[p:p+n].hex()})
    assert [x['bytes'] for x in seeds] == [b'__event_authority'.hex(),'fc']
    decoded.append({'image':image,'slice_at':hex(at),'pointer':hex(ptr),'length':length,'seeds':seeds})
assert decoded == json.loads((ROOT/'event-seeds.json').read_text())

# Hash evidence files only; exclude cache, build target and generated keypair files.
files = [p for p in ROOT.glob('*') if p.is_file()]
files += [p for p in (ROOT/'crate').rglob('*') if p.is_file()]
files += [p for p in (ROOT/'anchor-v1.0.0').rglob('*') if p.is_file()]
for n in ['build-attempt.json','build-comparison.json','build.log','candidate-symbols.txt','candidate.asm','artifacts/mayhem_burn_draft.so']:
    files.append(build/n)
manifest = {str(p.relative_to(ROOT)):sha(p) for p in sorted(files) if p.name != 'verified-hashes.json'}
(ROOT/'verified-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_unchanged':True,'compiler_returncode':0,
    'candidate_sha256':comparison['comparison']['candidate_sha256'],
    'static_summary':static['summary'],'evidence_files':len(manifest),'program_execution':False},indent=2))
