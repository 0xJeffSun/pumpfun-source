00d898: mov64 r7, r1
00d8a0: ldxdw r8, [r7 + 0x8]
00d8a8: ldxdw r6, [r8 + 0x1a8]
00d8b0: mov64 r1, r10
00d8b8: add64 r1, -0x150
00d8c0: call 0x122e1 ; call 0x9efd0
00d8c8: ldxw r1, [r10 - 0x150]
00d8d0: jeq r1, 0x1, +0x299 ; branch 0xeda0
00d8d8: ldxdw r1, [r10 - 0x128]
00d8e0: jsle r6, r1, +0x2a ; branch 0xda38
00d8e8: mov64 r1, r10
00d8f0: add64 r1, -0x78
00d8f8: lddw r2, 0xad060 ; rodata b'\x05\x00\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00poolcode\x0f\x00\x00\x00Kindkind\x13\x00\x00\x00\x05\x10\x00\x00\x03\x00\x00\x00Some\x10\x00\x00\x00 <= true\x06\x00\x00\x00Pool\x08\x00\x00\x00Non'
00d908: call 0x41b8 ; call 0x2e6d0
00d910: stdw [r10 - 0x48], 0x0
00d918: stdw [r10 - 0x50], 0x1
00d920: stdw [r10 - 0x58], 0x0
00d928: lddw r1, 0xb1238 ; rodata b'\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
00d938: stxdw [r10 - 0x30], r1
00d940: mov64 r1, r10
00d948: add64 r1, -0x58
00d950: stxdw [r10 - 0x38], r1
00d958: lddw r1, 0xe0000020
00d968: stxdw [r10 - 0x28], r1
00d970: mov64 r2, r10
00d978: add64 r2, -0x38
00d980: lddw r1, 0xad060 ; rodata b'\x05\x00\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00poolcode\x0f\x00\x00\x00Kindkind\x13\x00\x00\x00\x05\x10\x00\x00\x03\x00\x00\x00Some\x10\x00\x00\x00 <= true\x06\x00\x00\x00Pool\x08\x00\x00\x00Non'
00d990: call 0x4488 ; call 0x2fdd8
00d998: jne r0, 0x0, +0x28c ; branch 0xee00
00d9a0: ldxdw r1, [r10 - 0x48]
00d9a8: stxdw [r10 - 0x108], r1
00d9b0: ldxdw r1, [r10 - 0x50]
00d9b8: stxdw [r10 - 0x110], r1
00d9c0: ldxdw r1, [r10 - 0x58]
00d9c8: stxdw [r10 - 0x118], r1
00d9d0: ldxdw r1, [r10 - 0x78]
00d9d8: stxdw [r10 - 0x130], r1
00d9e0: ldxdw r1, [r10 - 0x70]
00d9e8: stxdw [r10 - 0x128], r1
00d9f0: ldxdw r1, [r10 - 0x68]
00d9f8: stxdw [r10 - 0x120], r1
00da00: lddw r1, 0xad4c4 ; rodata b'programs/mayhem-program/src/instructions/burn.rscalled `Result::unwrap()` o'
00da10: stxdw [r10 - 0x148], r1
00da18: stw [r10 - 0xb8], 0x1775
00da20: stb [r10 - 0x100], 0x2
00da28: stw [r10 - 0x138], 0x4e
00da30: ja +0x2b ; branch 0xdb90
00da38: ldxb r1, [r8 + 0x1c0]
00da40: jne r1, 0x2, +0x2f ; branch 0xdbc0
00da48: mov64 r1, r10
00da50: add64 r1, -0x78
00da58: lddw r2, 0xad05c ; rodata b'\x04\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00poolcode\x0f\x00\x00\x00Kindkind\x13\x00\x00\x00\x05\x10\x00\x00\x03\x00\x00\x00Some\x10\x00\x00\x00 <= true\x06\x00\x00\x00Pool\x08\x00\x00'
00da68: call 0x418c ; call 0x2e6d0
00da70: stdw [r10 - 0x48], 0x0
00da78: stdw [r10 - 0x50], 0x1
00da80: stdw [r10 - 0x58], 0x0
00da88: lddw r1, 0xb1238 ; rodata b'\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
00da98: stxdw [r10 - 0x30], r1
00daa0: mov64 r1, r10
00daa8: add64 r1, -0x58
00dab0: stxdw [r10 - 0x38], r1
00dab8: lddw r1, 0xe0000020
00dac8: stxdw [r10 - 0x28], r1
00dad0: mov64 r2, r10
00dad8: add64 r2, -0x38
00dae0: lddw r1, 0xad05c ; rodata b'\x04\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00poolcode\x0f\x00\x00\x00Kindkind\x13\x00\x00\x00\x05\x10\x00\x00\x03\x00\x00\x00Some\x10\x00\x00\x00 <= true\x06\x00\x00\x00Pool\x08\x00\x00'
00daf0: call 0x445c ; call 0x2fdd8
00daf8: jne r0, 0x0, +0x260 ; branch 0xee00
00db00: ldxdw r1, [r10 - 0x48]
00db08: stxdw [r10 - 0x108], r1
00db10: ldxdw r1, [r10 - 0x50]
00db18: stxdw [r10 - 0x110], r1
00db20: ldxdw r1, [r10 - 0x58]
00db28: stxdw [r10 - 0x118], r1
00db30: ldxdw r1, [r10 - 0x78]
00db38: stxdw [r10 - 0x130], r1
00db40: ldxdw r1, [r10 - 0x70]
00db48: stxdw [r10 - 0x128], r1
00db50: ldxdw r1, [r10 - 0x68]
00db58: stxdw [r10 - 0x120], r1
00db60: lddw r1, 0xad4c4 ; rodata b'programs/mayhem-program/src/instructions/burn.rscalled `Result::unwrap()` o'
00db70: stxdw [r10 - 0x148], r1
00db78: stw [r10 - 0xb8], 0x1774
00db80: stb [r10 - 0x100], 0x2
00db88: stw [r10 - 0x138], 0x52
00db90: stdw [r10 - 0x140], 0x30
00db98: stdw [r10 - 0x150], 0x0
00dba0: mov64 r1, r10
00dba8: add64 r1, -0x150
00dbb0: call 0x1139e ; call 0x978a8
00dbb8: exit
00dbc0: ldxdw r1, [r8 + 0xe8]
00dbc8: stxdw [r10 - 0x158], r1
00dbd0: ldxdw r1, [r8 + 0x1f8]
00dbd8: ldxdw r1, [r1 + 0x0]
00dbe0: ldxdw r2, [r1 + 0x18]
00dbe8: stxdw [r10 - 0x40], r2
00dbf0: ldxdw r2, [r1 + 0x10]
00dbf8: stxdw [r10 - 0x48], r2
00dc00: ldxdw r2, [r1 + 0x8]
00dc08: stxdw [r10 - 0x50], r2
00dc10: ldxdw r1, [r1 + 0x0]
00dc18: stxdw [r10 - 0x58], r1
00dc20: ldxdw r2, [r8 + 0x58]
00dc28: ldxdw r4, [r2 + 0x8]
00dc30: ldxdw r1, [r4 + 0x0]
00dc38: add64 r1, 0x1
00dc40: mov64 r3, 0x1
00dc48: jeq r1, 0x0, +0x1 ; branch 0xdc58
00dc50: mov64 r3, 0x0
00dc58: ldxdw r5, [r2 + 0x0]
00dc60: stxdw [r10 - 0x160], r5
00dc68: stxdw [r4 + 0x0], r1
00dc70: jeq r3, 0x1, +0x224 ; branch 0xed98
00dc78: ldxdw r0, [r2 + 0x10]
00dc80: ldxdw r1, [r0 + 0x0]
00dc88: add64 r1, 0x1
00dc90: mov64 r3, 0x1
00dc98: jeq r1, 0x0, +0x1 ; branch 0xdca8
00dca0: mov64 r3, 0x0
00dca8: stxdw [r0 + 0x0], r1
00dcb0: jeq r3, 0x1, +0x21c ; branch 0xed98
00dcb8: ldxdw r6, [r8 + 0xa0]
00dcc0: ldxdw r5, [r6 + 0x8]
00dcc8: ldxdw r1, [r5 + 0x0]
00dcd0: add64 r1, 0x1
00dcd8: mov64 r3, 0x1
00dce0: jeq r1, 0x0, +0x1 ; branch 0xdcf0
00dce8: mov64 r3, 0x0
00dcf0: ldxb r9, [r2 + 0x2a]
00dcf8: stxdw [r10 - 0x180], r9
00dd00: ldxb r9, [r2 + 0x29]
00dd08: stxdw [r10 - 0x178], r9
00dd10: ldxb r9, [r2 + 0x28]
00dd18: stxdw [r10 - 0x170], r9
00dd20: ldxdw r9, [r2 + 0x20]
00dd28: stxdw [r10 - 0x168], r9
00dd30: ldxdw r2, [r2 + 0x18]
00dd38: ldxdw r9, [r6 + 0x0]
00dd40: stxdw [r5 + 0x0], r1
00dd48: jeq r3, 0x1, +0x209 ; branch 0xed98
00dd50: stxdw [r10 - 0x190], r2
00dd58: stxdw [r10 - 0x188], r5
00dd60: ldxdw r5, [r6 + 0x10]
00dd68: ldxdw r1, [r5 + 0x0]
00dd70: add64 r1, 0x1
00dd78: mov64 r2, 0x1
00dd80: jeq r1, 0x0, +0x1 ; branch 0xdd90
00dd88: mov64 r2, 0x0
00dd90: stxdw [r5 + 0x0], r1
00dd98: jeq r2, 0x1, +0x1ff ; branch 0xed98
00dda0: stxdw [r10 - 0x198], r0
00dda8: stxdw [r10 - 0x1e0], r8
00ddb0: ldxdw r8, [r8 + 0x1c8]
00ddb8: ldxdw r0, [r8 + 0x8]
00ddc0: ldxdw r2, [r0 + 0x0]
00ddc8: add64 r2, 0x1
00ddd0: mov64 r3, 0x1
00ddd8: jeq r2, 0x0, +0x1 ; branch 0xdde8
00dde0: mov64 r3, 0x0
00dde8: ldxb r1, [r6 + 0x2a]
00ddf0: stxdw [r10 - 0x1b8], r1
00ddf8: ldxb r1, [r6 + 0x29]
00de00: stxdw [r10 - 0x1b0], r1
00de08: ldxb r1, [r6 + 0x28]
00de10: stxdw [r10 - 0x1a8], r1
00de18: ldxdw r1, [r6 + 0x20]
00de20: stxdw [r10 - 0x1a0], r1
00de28: ldxdw r1, [r6 + 0x18]
00de30: ldxdw r6, [r8 + 0x0]
00de38: stxdw [r0 + 0x0], r2
00de40: jeq r3, 0x1, +0x1ea ; branch 0xed98
00de48: stxdw [r10 - 0x1c0], r6
00de50: ldxdw r2, [r8 + 0x10]
00de58: ldxdw r3, [r2 + 0x0]
00de60: add64 r3, 0x1
00de68: mov64 r6, 0x1
00de70: jeq r3, 0x0, +0x1 ; branch 0xde80
00de78: mov64 r6, 0x0
00de80: stxdw [r2 + 0x0], r3
00de88: jeq r6, 0x1, +0x1e1 ; branch 0xed98
00de90: ldxdw r3, [r8 + 0x18]
00de98: ldxdw r6, [r8 + 0x20]
00dea0: stxdw [r10 - 0x1d8], r5
00dea8: stxdw [r10 - 0x1d0], r9
00deb0: ldxb r9, [r8 + 0x28]
00deb8: mov64 r5, r1
00dec0: ldxb r1, [r8 + 0x29]
00dec8: ldxb r8, [r8 + 0x2a]
00ded0: ldxb r7, [r7 + 0x21]
00ded8: stxdw [r10 - 0x1c8], r4
00dee0: mov64 r4, r10
00dee8: add64 r4, -0x1
00def0: stxdw [r10 - 0x28], r4
00def8: lddw r4, 0xad4a9 ; rodata b'sol-vault__event_authority\xfcprograms/mayhem-program/src/instructions/burn.rs'
00df08: stxdw [r10 - 0x38], r4
00df10: stxb [r10 - 0x1], r7
00df18: mov64 r4, r10
00df20: add64 r4, -0x38
00df28: stxdw [r10 - 0x78], r4
00df30: stxb [r10 - 0xae], r8
00df38: stxb [r10 - 0xaf], r1
00df40: stxb [r10 - 0xb0], r9
00df48: stxdw [r10 - 0xb8], r6
00df50: stxdw [r10 - 0xc0], r3
00df58: stxdw [r10 - 0xc8], r2
00df60: stxdw [r10 - 0xd0], r0
00df68: ldxdw r1, [r10 - 0x1c0]
00df70: stxdw [r10 - 0xd8], r1
00df78: ldxdw r1, [r10 - 0x1b8]
00df80: stxb [r10 - 0xde], r1
00df88: ldxdw r1, [r10 - 0x1b0]
00df90: stxb [r10 - 0xdf], r1
00df98: ldxdw r1, [r10 - 0x1a8]
00dfa0: stxb [r10 - 0xe0], r1
00dfa8: ldxdw r1, [r10 - 0x1a0]
00dfb0: stxdw [r10 - 0xe8], r1
00dfb8: stxdw [r10 - 0xf0], r5
00dfc0: ldxdw r1, [r10 - 0x1d8]
00dfc8: stxdw [r10 - 0xf8], r1
00dfd0: ldxdw r1, [r10 - 0x188]
00dfd8: stxdw [r10 - 0x100], r1
00dfe0: ldxdw r1, [r10 - 0x1d0]
00dfe8: stxdw [r10 - 0x108], r1
00dff0: ldxdw r1, [r10 - 0x180]
00dff8: stxb [r10 - 0x10e], r1
00e000: ldxdw r1, [r10 - 0x178]
00e008: stxb [r10 - 0x10f], r1
00e010: ldxdw r1, [r10 - 0x170]
00e018: stxb [r10 - 0x110], r1
00e020: ldxdw r1, [r10 - 0x168]
00e028: stxdw [r10 - 0x118], r1
00e030: ldxdw r1, [r10 - 0x190]
00e038: stxdw [r10 - 0x120], r1
00e040: ldxdw r1, [r10 - 0x198]
00e048: stxdw [r10 - 0x128], r1
00e050: ldxdw r1, [r10 - 0x1c8]
00e058: stxdw [r10 - 0x130], r1
00e060: ldxdw r1, [r10 - 0x160]
00e068: stxdw [r10 - 0x138], r1
00e070: stdw [r10 - 0x20], 0x1
00e078: stdw [r10 - 0x30], 0x9
00e080: stdw [r10 - 0x70], 0x2
00e088: mov64 r1, r10
00e090: add64 r1, -0x78
00e098: stxdw [r10 - 0xa8], r1
00e0a0: ldxdw r1, [r10 - 0x58]
00e0a8: stxdw [r10 - 0x98], r1
00e0b0: ldxdw r1, [r10 - 0x50]
00e0b8: stxdw [r10 - 0x90], r1
00e0c0: ldxdw r1, [r10 - 0x48]
00e0c8: stxdw [r10 - 0x88], r1
00e0d0: ldxdw r1, [r10 - 0x40]
00e0d8: stxdw [r10 - 0x80], r1
00e0e0: stdw [r10 - 0x140], 0x0
00e0e8: stdw [r10 - 0x148], 0x8
00e0f0: stdw [r10 - 0x150], 0x0
00e0f8: stdw [r10 - 0xa0], 0x1
00e100: mov64 r1, r10
00e108: add64 r1, -0x150
00e110: ldxdw r8, [r10 - 0x158]
00e118: mov64 r2, r8
00e120: call 0x10553 ; call 0x90bc0
00e128: jne r0, 0x2, -0xaf ; branch 0xdbb8
00e130: ldxdw r7, [r10 - 0x1e0]
00e138: stxdw [r7 + 0x1b8], r8
00e140: ldxdw r1, [r7 + 0x58]
00e148: ldxdw r1, [r1 + 0x0]
00e150: ldxdw r2, [r1 + 0x18]
00e158: stxdw [r10 - 0x60], r2
00e160: ldxdw r2, [r1 + 0x10]
00e168: stxdw [r10 - 0x68], r2
00e170: ldxdw r2, [r1 + 0x8]
00e178: stxdw [r10 - 0x70], r2
00e180: ldxdw r1, [r1 + 0x0]
00e188: stxdw [r10 - 0x78], r1
00e190: ldxdw r1, [r7 + 0x158]
00e198: ldxdw r1, [r1 + 0x0]
00e1a0: ldxdw r2, [r1 + 0x18]
00e1a8: stxdw [r10 - 0x40], r2
00e1b0: ldxdw r2, [r1 + 0x10]
00e1b8: stxdw [r10 - 0x48], r2
00e1c0: ldxdw r2, [r1 + 0x8]
00e1c8: stxdw [r10 - 0x50], r2
00e1d0: ldxdw r1, [r1 + 0x0]
00e1d8: stxdw [r10 - 0x58], r1
00e1e0: mov64 r1, r10
00e1e8: add64 r1, -0x38
00e1f0: call 0x121bb ; call 0x9efd0
00e1f8: ldxw r1, [r10 - 0x38]
00e200: jeq r1, 0x1, +0x189 ; branch 0xee50
00e208: ldxdw r1, [r10 - 0x78]
00e210: stxdw [r10 - 0x150], r1
00e218: ldxdw r1, [r10 - 0x70]
00e220: stxdw [r10 - 0x148], r1
00e228: ldxdw r1, [r10 - 0x68]
00e230: stxdw [r10 - 0x140], r1
00e238: ldxdw r1, [r10 - 0x60]
00e240: stxdw [r10 - 0x138], r1
00e248: ldxdw r1, [r10 - 0x58]
00e250: stxdw [r10 - 0x130], r1
00e258: ldxdw r1, [r10 - 0x50]
00e260: stxdw [r10 - 0x128], r1
00e268: ldxdw r1, [r10 - 0x48]
00e270: stxdw [r10 - 0x120], r1
00e278: ldxdw r1, [r10 - 0x40]
00e280: stxdw [r10 - 0x118], r1
00e288: ldxdw r6, [r10 - 0x10]
00e290: call 0xea6b ; call 0x835f0
00e298: lddw r1, 0x300000000
00e2a8: ldxdw r2, [r1 + 0x0]
00e2b0: mov64 r3, 0x0
00e2b8: mov64 r4, 0x1
00e2c0: mov64 r1, r2
00e2c8: add64 r1, -0x100
00e2d0: jle r1, r2, +0x8 ; branch 0xe318
00e2d8: jeq r4, 0x0, +0x9 ; branch 0xe328
00e2e0: lddw r1, 0x300007f00
00e2f0: jne r2, 0x0, +0xa ; branch 0xe348
00e2f8: lddw r2, 0x300000007
00e308: jgt r1, r2, +0xb ; branch 0xe368
00e310: ja +0xae ; branch 0xe888
00e318: mov64 r4, 0x0
00e320: jne r4, 0x0, -0x9 ; branch 0xe2e0
00e328: mov64 r3, r1
00e330: lddw r1, 0x300007f00
00e340: jeq r2, 0x0, -0xa ; branch 0xe2f8
00e348: mov64 r1, r3
00e350: lddw r2, 0x300000007
00e360: jle r1, r2, +0xa4 ; branch 0xe888
00e368: mov64 r9, r10
00e370: add64 r9, -0x130
00e378: lddw r2, 0x300000000
00e388: stxdw [r2 + 0x0], r1
00e390: stxdw [r1 + 0x8], r8
00e398: lddw r2, -0x51183ad8ad0a6df
00e3a8: stxdw [r1 + 0x0], r2
00e3b0: ldxdw r2, [r10 - 0x150]
00e3b8: stxdw [r1 + 0x10], r2
00e3c0: ldxdw r2, [r10 - 0x148]
00e3c8: stxdw [r1 + 0x18], r2
00e3d0: ldxdw r2, [r10 - 0x140]
00e3d8: stxdw [r1 + 0x20], r2
00e3e0: ldxdw r2, [r10 - 0x138]
00e3e8: stxdw [r1 + 0x28], r2
00e3f0: ldxdw r2, [r9 + 0x0]
00e3f8: stxdw [r1 + 0x30], r2
00e400: ldxdw r2, [r9 + 0x8]
00e408: stxdw [r1 + 0x38], r2
00e410: ldxdw r2, [r9 + 0x10]
00e418: stxdw [r1 + 0x40], r2
00e420: ldxdw r2, [r9 + 0x18]
00e428: stxdw [r1 + 0x48], r2
00e430: stxdw [r1 + 0x50], r6
00e438: stxdw [r10 - 0x38], r1
00e440: stdw [r10 - 0x30], 0x58
00e448: mov64 r1, r10
00e450: add64 r1, -0x38
00e458: mov64 r6, 0x1
00e460: mov64 r2, 0x1
00e468: call 0x116ad ; call 0x999d8
00e470: ldxdw r1, [r7 + 0x200]
00e478: ldxdw r4, [r1 + 0x8]
00e480: ldxdw r2, [r4 + 0x0]
00e488: add64 r2, 0x1
00e490: jeq r2, 0x0, +0x1 ; branch 0xe4a0
00e498: mov64 r6, 0x0
00e4a0: ldxdw r8, [r1 + 0x0]
00e4a8: stxdw [r4 + 0x0], r2
00e4b0: jeq r6, 0x1, +0x11c ; branch 0xed98
00e4b8: ldxdw r5, [r1 + 0x10]
00e4c0: ldxdw r2, [r5 + 0x0]
00e4c8: add64 r2, 0x1
00e4d0: mov64 r3, 0x1
00e4d8: jeq r2, 0x0, +0x1 ; branch 0xe4e8
00e4e0: mov64 r3, 0x0
00e4e8: stxdw [r10 - 0x160], r4
00e4f0: stxdw [r5 + 0x0], r2
00e4f8: jeq r3, 0x1, +0x113 ; branch 0xed98
00e500: stxdw [r10 - 0x168], r5
00e508: ldxb r2, [r1 + 0x2a]
00e510: stxdw [r10 - 0x190], r2
00e518: ldxb r2, [r1 + 0x29]
00e520: stxdw [r10 - 0x188], r2
00e528: ldxb r2, [r1 + 0x28]
00e530: stxdw [r10 - 0x180], r2
00e538: ldxdw r2, [r1 + 0x20]
00e540: stxdw [r10 - 0x178], r2
00e548: ldxdw r1, [r1 + 0x18]
00e550: stxdw [r10 - 0x170], r1
00e558: ldxdw r1, [r7 + 0x58]
00e560: ldxdw r1, [r1 + 0x0]
00e568: ldxdw r2, [r1 + 0x18]
00e570: stxdw [r10 - 0x60], r2
00e578: ldxdw r2, [r1 + 0x10]
00e580: stxdw [r10 - 0x68], r2
00e588: ldxdw r2, [r1 + 0x8]
00e590: stxdw [r10 - 0x70], r2
00e598: ldxdw r1, [r1 + 0x0]
00e5a0: stxdw [r10 - 0x78], r1
00e5a8: ldxdw r1, [r7 + 0x158]
00e5b0: ldxdw r1, [r1 + 0x0]
00e5b8: ldxdw r2, [r1 + 0x18]
00e5c0: stxdw [r10 - 0x40], r2
00e5c8: ldxdw r2, [r1 + 0x10]
00e5d0: stxdw [r10 - 0x48], r2
00e5d8: ldxdw r2, [r1 + 0x8]
00e5e0: stxdw [r10 - 0x50], r2
00e5e8: ldxdw r1, [r1 + 0x0]
00e5f0: stxdw [r10 - 0x58], r1
00e5f8: mov64 r1, r10
00e600: add64 r1, -0x38
00e608: call 0x12138 ; call 0x9efd0
00e610: ldxw r1, [r10 - 0x38]
00e618: jeq r1, 0x1, +0x112 ; branch 0xeeb0
00e620: ldxdw r1, [r10 - 0x78]
00e628: stxdw [r10 - 0x150], r1
00e630: ldxdw r1, [r10 - 0x70]
00e638: stxdw [r10 - 0x148], r1
00e640: ldxdw r1, [r10 - 0x68]
00e648: stxdw [r10 - 0x140], r1
00e650: ldxdw r1, [r10 - 0x60]
00e658: stxdw [r10 - 0x138], r1
00e660: ldxdw r1, [r10 - 0x58]
00e668: stxdw [r10 - 0x130], r1
00e670: ldxdw r1, [r10 - 0x50]
00e678: stxdw [r10 - 0x128], r1
00e680: ldxdw r1, [r10 - 0x48]
00e688: stxdw [r10 - 0x120], r1
00e690: ldxdw r1, [r10 - 0x40]
00e698: stxdw [r10 - 0x118], r1
00e6a0: ldxdw r6, [r10 - 0x10]
00e6a8: call 0xe9e8 ; call 0x835f0
00e6b0: lddw r1, 0x300000000
00e6c0: ldxdw r1, [r1 + 0x0]
00e6c8: mov64 r2, 0x0
00e6d0: mov64 r4, 0x1
00e6d8: mov64 r3, r1
00e6e0: add64 r3, -0x100
00e6e8: jle r3, r1, +0x28 ; branch 0xe830
00e6f0: jeq r4, 0x0, +0x29 ; branch 0xe840
00e6f8: lddw r7, 0x300007f00
00e708: jne r1, 0x0, +0x2a ; branch 0xe860
00e710: stxdw [r10 - 0x198], r8
00e718: lddw r1, 0x300000007
00e728: jle r7, r1, +0x2b ; branch 0xe888
00e730: lddw r8, 0x300000000
00e740: stxdw [r8 + 0x0], r7
00e748: ldxdw r1, [r10 - 0x158]
00e750: stxdw [r7 + 0x8], r1
00e758: lddw r1, -0x51183ad8ad0a6df
00e768: stxdw [r7 + 0x0], r1
00e770: ldxdw r1, [r10 - 0x150]
00e778: stxdw [r7 + 0x10], r1
00e780: ldxdw r1, [r10 - 0x148]
00e788: stxdw [r7 + 0x18], r1
00e790: ldxdw r1, [r10 - 0x140]
00e798: stxdw [r7 + 0x20], r1
00e7a0: ldxdw r1, [r10 - 0x138]
00e7a8: stxdw [r7 + 0x28], r1
00e7b0: ldxdw r1, [r9 + 0x0]
00e7b8: stxdw [r7 + 0x30], r1
00e7c0: ldxdw r1, [r9 + 0x8]
00e7c8: stxdw [r7 + 0x38], r1
00e7d0: ldxdw r1, [r9 + 0x10]
00e7d8: stxdw [r7 + 0x40], r1
00e7e0: ldxdw r1, [r9 + 0x18]
00e7e8: stxdw [r7 + 0x48], r1
00e7f0: stxdw [r7 + 0x50], r6
00e7f8: mov64 r1, 0x0
00e800: mov64 r6, 0x60
00e808: jsge r6, 0x0, +0x14 ; branch 0xe8b0
00e810: mov64 r2, 0x60
00e818: lddw r3, 0xb1378 ; rodata b'\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x90\x13\x0b\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
00e828: call 0x12a03 ; call 0xa3848
00e830: mov64 r4, 0x0
00e838: jne r4, 0x0, -0x29 ; branch 0xe6f8
00e840: mov64 r2, r3
00e848: lddw r7, 0x300007f00
00e858: jeq r1, 0x0, -0x2a ; branch 0xe710
00e860: mov64 r7, r2
00e868: stxdw [r10 - 0x198], r8
00e870: lddw r1, 0x300000007
00e880: jgt r7, r1, -0x2b ; branch 0xe730
00e888: mov64 r1, 0x1
00e890: mov64 r2, 0x100
00e898: lddw r3, 0xb1998 ; rodata b'\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00\n\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xe4\xca\n\x00;\x00\x00\x00\x00\x00\x00\x00\x1b\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00{\xce\n\x00;\x00\x00\x00\x00\x00\x00\x00\r\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00'
00e8a8: call 0x129f3 ; call 0xa3848
00e8b0: call 0xe9a7 ; call 0x835f0
00e8b8: ldxdw r1, [r8 + 0x0]
00e8c0: lddw r3, 0x300008000
00e8d0: jeq r1, 0x0, +0x1 ; branch 0xe8e0
00e8d8: mov64 r3, r1
00e8e0: mov64 r2, r3
00e8e8: sub64 r2, r6
00e8f0: mov64 r6, 0x0
00e8f8: mov64 r1, 0x1
00e900: mov64 r4, 0x1
00e908: jle r2, r3, +0x5 ; branch 0xe938
00e910: jeq r4, 0x0, +0x6 ; branch 0xe948
00e918: lddw r2, 0x300000007
00e928: jgt r6, r2, +0x7 ; branch 0xe968
00e930: ja -0x25 ; branch 0xe810
00e938: mov64 r4, 0x0
00e940: jne r4, 0x0, -0x6 ; branch 0xe918
00e948: mov64 r6, r2
00e950: lddw r2, 0x300000007
00e960: jle r6, r2, -0x2b ; branch 0xe810
00e968: lddw r1, 0x300000000
00e978: stxdw [r1 + 0x0], r6
00e980: lddw r1, 0x1d9acb512ea545e4
00e990: stxdw [r6 + 0x0], r1
00e998: mov64 r1, 0x0
00e9a0: mov64 r2, r6
00e9a8: add64 r2, r1
00e9b0: mov64 r3, r7
00e9b8: add64 r3, r1
00e9c0: ldxb r3, [r3 + 0x0]
00e9c8: stxb [r2 + 0x8], r3
00e9d0: add64 r1, 0x1
00e9d8: jne r1, 0x58, -0x8 ; branch 0xe9a0
00e9e0: call 0xe981 ; call 0x835f0
00e9e8: lddw r1, 0x300000000
00e9f8: ldxdw r2, [r1 + 0x0]
00ea00: mov64 r1, r2
00ea08: add64 r1, -0x22
00ea10: mov64 r3, 0x0
00ea18: mov64 r4, 0x1
00ea20: ldxdw r8, [r10 - 0x1e0]
00ea28: jle r1, r2, +0x40 ; branch 0xec30
00ea30: jeq r4, 0x0, +0x41 ; branch 0xec40
00ea38: lddw r1, 0x300007fde
00ea48: jne r2, 0x0, +0x42 ; branch 0xec60
00ea50: lddw r2, 0x300000008
00ea60: jlt r1, r2, +0x43 ; branch 0xec80
00ea68: lddw r2, 0x300000000
00ea78: stxdw [r2 + 0x0], r1
00ea80: ldxdw r7, [r10 - 0x198]
00ea88: ldxdw r2, [r7 + 0x0]
00ea90: ldxdw r3, [r7 + 0x8]
00ea98: ldxdw r4, [r7 + 0x10]
00eaa0: ldxdw r5, [r7 + 0x18]
00eaa8: stxdw [r1 + 0x18], r5
00eab0: stxdw [r1 + 0x10], r4
00eab8: stxdw [r1 + 0x8], r3
00eac0: stxdw [r1 + 0x0], r2
00eac8: sth [r1 + 0x20], 0x1
00ead0: stxdw [r10 - 0x30], r1
00ead8: stdw [r10 - 0x28], 0x1
00eae0: stdw [r10 - 0x38], 0x1
00eae8: mov64 r9, r10
00eaf0: add64 r9, -0x150
00eaf8: mov64 r5, r10
00eb00: add64 r5, -0x38
00eb08: mov64 r1, r9
00eb10: lddw r2, 0xadeed ; rodata b'\x05*\xe5\xd7\xa7\xda\xa7$\xa6\xea\xb0\xa7)T\x91\x85Z\xd4\xa0g\x16`gLN\x03EY\x80=e\xa3programs/mayhem-program/src/lib.rsInstructi'
00eb20: mov64 r3, r6
00eb28: mov64 r4, 0x60
00eb30: call 0x123ad ; call 0xa08a0
00eb38: ldxdw r1, [r10 - 0x190]
00eb40: stxb [r10 - 0xe], r1
00eb48: ldxdw r1, [r10 - 0x188]
00eb50: stxb [r10 - 0xf], r1
00eb58: ldxdw r1, [r10 - 0x180]
00eb60: stxb [r10 - 0x10], r1
00eb68: ldxdw r1, [r10 - 0x178]
00eb70: stxdw [r10 - 0x18], r1
00eb78: ldxdw r1, [r10 - 0x170]
00eb80: stxdw [r10 - 0x20], r1
00eb88: ldxdw r1, [r10 - 0x168]
00eb90: stxdw [r10 - 0x28], r1
00eb98: ldxdw r1, [r10 - 0x160]
00eba0: stxdw [r10 - 0x30], r1
00eba8: stxdw [r10 - 0x38], r7
00ebb0: mov64 r2, r10
00ebb8: add64 r2, -0x38
00ebc0: mov64 r1, r9
00ebc8: mov64 r3, 0x1
00ebd0: lddw r4, 0xb13b0 ; rodata b'\x00\x00\x00\x00\x90\x13\x0b\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb0\x97\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00n\x00\x00\x00!\x00\x00\x00\x00\x00\x00'
00ebe0: mov64 r5, 0x1
00ebe8: call 0x11925 ; call 0x9b518
00ebf0: mov64 r2, r1
00ebf8: mov64 r1, r0
00ec00: lsh64 r1, 0x20
00ec08: rsh64 r1, 0x20
00ec10: jne r1, 0x1a, +0x10 ; branch 0xec98
00ec18: mov64 r0, 0x2
00ec20: ldxdw r3, [r10 - 0x160]
00ec28: ja +0x10 ; branch 0xecb0
00ec30: mov64 r4, 0x0
00ec38: jne r4, 0x0, -0x41 ; branch 0xea38
00ec40: mov64 r3, r1
00ec48: lddw r1, 0x300007fde
00ec58: jeq r2, 0x0, -0x42 ; branch 0xea50
00ec60: mov64 r1, r3
00ec68: lddw r2, 0x300000008
00ec78: jge r1, r2, -0x43 ; branch 0xea68
00ec80: mov64 r1, 0x1
00ec88: mov64 r2, 0x22
00ec90: call 0x1297a ; call 0xa3868
00ec98: mov64 r1, r0
00eca0: call 0x11191 ; call 0x97930
00eca8: ldxdw r3, [r10 - 0x30]
00ecb0: ldxdw r2, [r3 + 0x0]
00ecb8: add64 r2, -0x1
00ecc0: stxdw [r3 + 0x0], r2
00ecc8: jne r2, 0x0, +0x8 ; branch 0xed10
00ecd0: mov64 r2, r10
00ecd8: add64 r2, -0x30
00ece0: mov64 r6, r1
00ece8: mov64 r1, r2
00ecf0: mov64 r7, r0
00ecf8: call 0x122d5 ; call 0xa03a8
00ed00: mov64 r1, r6
00ed08: mov64 r0, r7
00ed10: ldxdw r2, [r10 - 0x28]
00ed18: ldxdw r3, [r2 + 0x0]
00ed20: add64 r3, -0x1
00ed28: stxdw [r2 + 0x0], r3
00ed30: jne r3, 0x0, +0x8 ; branch 0xed78
00ed38: mov64 r2, r10
00ed40: add64 r2, -0x28
00ed48: mov64 r6, r1
00ed50: mov64 r1, r2
00ed58: mov64 r7, r0
00ed60: call 0x122be ; call 0xa0358
00ed68: mov64 r1, r6
00ed70: mov64 r0, r7
00ed78: jne r0, 0x2, -0x239 ; branch 0xdbb8
00ed80: stb [r8 + 0x1c0], 0x2
00ed88: mov64 r0, 0x2
00ed90: ja -0x23c ; branch 0xdbb8
00ed98: call -0x1
00eda0: ldxdw r1, [r10 - 0x14c]
00eda8: stxdw [r10 - 0x38], r1
00edb0: mov64 r3, r10
00edb8: add64 r3, -0x38
00edc0: lddw r1, 0xad4f4 ; rodata b'called `Result::unwrap()` on an `Err` valueAccount already has more than Ac'
00edd0: mov64 r2, 0x2b
00edd8: lddw r4, 0xb13c0 ; rodata b'\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb0\x97\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00n\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00h\x00\x00'
00ede8: lddw r5, 0xb1410 ; rodata b'\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00M\x00\x00\x004\x00\x00\x00\x00\x00\x00\x00\x1f\xd5\n\x00\x1e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\xca\n\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xe4\xca\n\x00;\x00\x00\x00\x00\x00\x00\x00^\x00\x00'
00edf8: call 0x12b7d ; call 0xa49e8
00ee00: mov64 r3, r10
00ee08: add64 r3, -0x1
00ee10: lddw r1, 0xad019 ; rodata b'a Display implementation returned an error unexpectedlyfalse\x00\x00\x00\x0e\x00\x00\x00\x04\x00\x00\x00\x05\x00\x00\x00'
00ee20: mov64 r2, 0x37
00ee28: lddw r4, 0xb1268 ; rodata b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x18\x8d\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\x0e\x0b\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\xe8\x01\x00'
00ee38: lddw r5, 0xb1288 ; rodata b'\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\x0e\x0b\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\xe8\x01\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xc0\xd0\n\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb6\xce\n\x00Z\x00\x00'
00ee48: call 0x12b73 ; call 0xa49e8
00ee50: ldxdw r1, [r10 - 0x34]
00ee58: stxdw [r10 - 0x150], r1
00ee60: mov64 r3, r10
00ee68: add64 r3, -0x150
00ee70: lddw r1, 0xad4f4 ; rodata b'called `Result::unwrap()` on an `Err` valueAccount already has more than Ac'
00ee80: mov64 r2, 0x2b
00ee88: lddw r4, 0xb13c0 ; rodata b'\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb0\x97\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00n\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00h\x00\x00'
00ee98: lddw r5, 0xb13f8 ; rodata b'\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00h\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00M\x00\x00\x004\x00\x00\x00\x00\x00\x00\x00\x1f\xd5\n\x00\x1e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\xca\n\x00\x08\x00\x00'
00eea8: call 0x12b67 ; call 0xa49e8
00eeb0: ldxdw r1, [r10 - 0x34]
00eeb8: stxdw [r10 - 0x150], r1
00eec0: mov64 r3, r10
00eec8: add64 r3, -0x150
00eed0: lddw r1, 0xad4f4 ; rodata b'called `Result::unwrap()` on an `Err` valueAccount already has more than Ac'
00eee0: mov64 r2, 0x2b
00eee8: lddw r4, 0xb13c0 ; rodata b'\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb0\x97\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00n\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00h\x00\x00'
00eef8: lddw r5, 0xb13e0 ; rodata b'\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00n\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00h\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00M\x00\x00\x004\x00\x00\x00\x00\x00\x00'
00ef08: call 0x12b5b ; call 0xa49e8
