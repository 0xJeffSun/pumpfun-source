02e6d0: mov64 r6, r1
02e6d8: ldxw r7, [r2 + 0x0]
02e6e0: call 0xa9e1 ; call 0x835f0
02e6e8: lddw r1, 0x300000000
02e6f8: ldxdw r1, [r1 + 0x0]
02e700: mov64 r2, r1
02e708: jsgt r7, 0x9, +0x10 ; branch 0x2e790
02e710: jsgt r7, 0x4, +0x1f ; branch 0x2e810
02e718: jsle r7, 0x1, +0x44 ; branch 0x2e940
02e720: jeq r7, 0x2, +0x8c ; branch 0x2eb88
02e728: jne r7, 0x3, +0xda ; branch 0x2ee00
02e730: add64 r2, -0x11
02e738: mov64 r3, 0x0
02e740: mov64 r4, 0x1
02e748: jle r2, r1, +0x173 ; branch 0x2f2e8
02e750: jeq r4, 0x0, +0x174 ; branch 0x2f2f8
02e758: lddw r2, 0x300007fef
02e768: jne r1, 0x0, +0x175 ; branch 0x2f318
02e770: lddw r1, 0x300000007
02e780: jgt r2, r1, +0x176 ; branch 0x2f338
02e788: ja +0x2b0 ; branch 0x2fd10
02e790: jsgt r7, 0xe, +0x1e ; branch 0x2e888
02e798: jsle r7, 0xb, +0x41 ; branch 0x2e9a8
02e7a0: jeq r7, 0xc, +0x90 ; branch 0x2ec28
02e7a8: jne r7, 0xd, +0xd6 ; branch 0x2ee60
02e7b0: add64 r2, -0x13
02e7b8: mov64 r3, 0x0
02e7c0: mov64 r4, 0x1
02e7c8: jle r2, r1, +0x179 ; branch 0x2f398
02e7d0: jeq r4, 0x0, +0x17a ; branch 0x2f3a8
02e7d8: lddw r2, 0x300007fed
02e7e8: jne r1, 0x0, +0x17b ; branch 0x2f3c8
02e7f0: lddw r1, 0x300000007
02e800: jgt r2, r1, +0x17c ; branch 0x2f3e8
02e808: ja +0x2aa ; branch 0x2fd60
02e810: jsle r7, 0x6, +0x3f ; branch 0x2ea10
02e818: jeq r7, 0x7, +0x8d ; branch 0x2ec88
02e820: jne r7, 0x8, +0xd3 ; branch 0x2eec0
02e828: add64 r2, -0xd
02e830: mov64 r3, 0x0
02e838: mov64 r4, 0x1
02e840: jle r2, r1, +0x180 ; branch 0x2f448
02e848: jeq r4, 0x0, +0x181 ; branch 0x2f458
02e850: lddw r2, 0x300007ff3
02e860: jne r1, 0x0, +0x182 ; branch 0x2f478
02e868: lddw r1, 0x300000007
02e878: jgt r2, r1, +0x183 ; branch 0x2f498
02e880: ja +0x296 ; branch 0x2fd38
02e888: jsle r7, 0x10, +0x48 ; branch 0x2ead0
02e890: jeq r7, 0x11, +0x94 ; branch 0x2ed38
02e898: jne r7, 0x12, +0xd0 ; branch 0x2ef20
02e8a0: add64 r2, -0xb
02e8a8: mov64 r3, 0x0
02e8b0: mov64 r4, 0x1
02e8b8: jle r2, r1, +0x184 ; branch 0x2f4e0
02e8c0: jeq r4, 0x0, +0x185 ; branch 0x2f4f0
02e8c8: lddw r2, 0x300007ff5
02e8d8: jne r1, 0x0, +0x186 ; branch 0x2f510
02e8e0: lddw r1, 0x300000007
02e8f0: jle r2, r1, +0x187 ; branch 0x2f530
02e8f8: lddw r1, 0x300000000
02e908: stxdw [r1 + 0x0], r2
02e910: lddw r1, 0x4264696c61766e49
02e920: stxdw [r2 + 0x0], r1
02e928: mov64 r1, 0xb
02e930: stw [r2 + 0x7], 0x706d7542
02e938: ja +0x276 ; branch 0x2fcf0
02e940: add64 r2, -0xd
02e948: mov64 r3, 0x0
02e950: mov64 r4, 0x1
02e958: jne r7, 0x0, +0xc4 ; branch 0x2ef80
02e960: jle r2, r1, +0x1d2 ; branch 0x2f7f8
02e968: jeq r4, 0x0, +0x1d3 ; branch 0x2f808
02e970: lddw r2, 0x300007ff3
02e980: jne r1, 0x0, +0x1d4 ; branch 0x2f828
02e988: lddw r1, 0x300000007
02e998: jgt r2, r1, +0x1d5 ; branch 0x2f848
02e9a0: ja +0x272 ; branch 0x2fd38
02e9a8: jne r7, 0xa, +0xc3 ; branch 0x2efc8
02e9b0: add64 r2, -0x11
02e9b8: mov64 r3, 0x0
02e9c0: mov64 r4, 0x1
02e9c8: jle r2, r1, +0x1d8 ; branch 0x2f890
02e9d0: jeq r4, 0x0, +0x1d9 ; branch 0x2f8a0
02e9d8: lddw r2, 0x300007fef
02e9e8: jne r1, 0x0, +0x1da ; branch 0x2f8c0
02e9f0: lddw r1, 0x300000007
02ea00: jgt r2, r1, +0x1db ; branch 0x2f8e0
02ea08: ja +0x260 ; branch 0x2fd10
02ea10: jne r7, 0x5, +0xc2 ; branch 0x2f028
02ea18: add64 r2, -0x12
02ea20: mov64 r3, 0x0
02ea28: mov64 r4, 0x1
02ea30: jle r2, r1, +0x1e1 ; branch 0x2f940
02ea38: jeq r4, 0x0, +0x1e2 ; branch 0x2f950
02ea40: lddw r2, 0x300007fee
02ea50: jne r1, 0x0, +0x1e3 ; branch 0x2f970
02ea58: lddw r1, 0x300000007
02ea68: jle r2, r1, +0x1e4 ; branch 0x2f990
02ea70: lddw r1, 0x300000000
02ea80: stxdw [r1 + 0x0], r2
02ea88: lddw r1, 0x646e45746f4e6564
02ea98: stxdw [r2 + 0x8], r1
02eaa0: lddw r1, 0x6f4d6d656879614d
02eab0: stxdw [r2 + 0x0], r1
02eab8: mov64 r1, 0x12
02eac0: sth [r2 + 0x10], 0x6465
02eac8: ja +0x244 ; branch 0x2fcf0
02ead0: jne r7, 0xf, +0xb6 ; branch 0x2f088
02ead8: add64 r2, -0xe
02eae0: mov64 r3, 0x0
02eae8: mov64 r4, 0x1
02eaf0: jle r2, r1, +0x1d8 ; branch 0x2f9b8
02eaf8: jeq r4, 0x0, +0x1d9 ; branch 0x2f9c8
02eb00: lddw r2, 0x300007ff2
02eb10: jne r1, 0x0, +0x1da ; branch 0x2f9e8
02eb18: lddw r1, 0x300000007
02eb28: jle r2, r1, +0x1db ; branch 0x2fa08
02eb30: lddw r1, 0x300000000
02eb40: stxdw [r1 + 0x0], r2
02eb48: lddw r1, 0x74696d694c657461
02eb58: stxdw [r2 + 0x6], r1
02eb60: lddw r1, 0x7461526564617254
02eb70: stxdw [r2 + 0x0], r1
02eb78: mov64 r1, 0xe
02eb80: ja +0x22d ; branch 0x2fcf0
02eb88: add64 r2, -0xc
02eb90: mov64 r3, 0x0
02eb98: mov64 r4, 0x1
02eba0: jle r2, r1, +0xa8 ; branch 0x2f0e8
02eba8: jeq r4, 0x0, +0xa9 ; branch 0x2f0f8
02ebb0: lddw r2, 0x300007ff4
02ebc0: jne r1, 0x0, +0xaa ; branch 0x2f118
02ebc8: lddw r1, 0x300000007
02ebd8: jle r2, r1, +0xab ; branch 0x2f138
02ebe0: lddw r1, 0x300000000
02ebf0: stxdw [r1 + 0x0], r2
02ebf8: lddw r1, 0x7265764f6874614d
02ec08: stxdw [r2 + 0x0], r1
02ec10: mov64 r1, 0xc
02ec18: stw [r2 + 0x8], 0x776f6c66
02ec20: ja +0x219 ; branch 0x2fcf0
02ec28: add64 r2, -0xf
02ec30: mov64 r3, 0x0
02ec38: mov64 r4, 0x1
02ec40: jle r2, r1, +0xa3 ; branch 0x2f160
02ec48: jeq r4, 0x0, +0xa4 ; branch 0x2f170
02ec50: lddw r2, 0x300007ff1
02ec60: jne r1, 0x0, +0xa5 ; branch 0x2f190
02ec68: lddw r1, 0x300000007
02ec78: jgt r2, r1, +0xa6 ; branch 0x2f1b0
02ec80: ja +0x220 ; branch 0x2fd88
02ec88: add64 r2, -0x10
02ec90: mov64 r3, 0x0
02ec98: mov64 r4, 0x1
02eca0: jle r2, r1, +0xaa ; branch 0x2f1f8
02eca8: jeq r4, 0x0, +0xab ; branch 0x2f208
02ecb0: lddw r2, 0x300007ff0
02ecc0: jne r1, 0x0, +0xac ; branch 0x2f228
02ecc8: lddw r1, 0x300000007
02ecd8: jle r2, r1, +0xad ; branch 0x2f248
02ece0: lddw r1, 0x300000000
02ecf0: stxdw [r1 + 0x0], r2
02ecf8: lddw r1, 0x6465646565637845
02ed08: stxdw [r2 + 0x8], r1
02ed10: lddw r1, 0x6b7369526e696f43
02ed20: stxdw [r2 + 0x0], r1
02ed28: mov64 r1, 0x10
02ed30: ja +0x1f7 ; branch 0x2fcf0
02ed38: add64 r2, -0x18
02ed40: mov64 r3, 0x0
02ed48: mov64 r4, 0x1
02ed50: jle r2, r1, +0xa3 ; branch 0x2f270
02ed58: jeq r4, 0x0, +0xa4 ; branch 0x2f280
02ed60: lddw r2, 0x300007fe8
02ed70: jne r1, 0x0, +0xa5 ; branch 0x2f2a0
02ed78: lddw r1, 0x300000007
02ed88: jle r2, r1, +0xa6 ; branch 0x2f2c0
02ed90: lddw r1, 0x300000000
02eda0: stxdw [r1 + 0x0], r2
02eda8: lddw r1, 0x6465646565637845
02edb8: stxdw [r2 + 0x10], r1
02edc0: lddw r1, 0x73746e6569706963
02edd0: stxdw [r2 + 0x8], r1
02edd8: lddw r1, 0x655265654678614d
02ede8: stxdw [r2 + 0x0], r1
02edf0: mov64 r1, 0x18
02edf8: ja +0x1de ; branch 0x2fcf0
02ee00: add64 r2, -0xf
02ee08: mov64 r3, 0x0
02ee10: mov64 r4, 0x1
02ee18: jle r2, r1, +0xe7 ; branch 0x2f558
02ee20: jeq r4, 0x0, +0xe8 ; branch 0x2f568
02ee28: lddw r2, 0x300007ff1
02ee38: jne r1, 0x0, +0xe9 ; branch 0x2f588
02ee40: lddw r1, 0x300000007
02ee50: jgt r2, r1, +0xea ; branch 0x2f5a8
02ee58: ja +0x1e5 ; branch 0x2fd88
02ee60: add64 r2, -0x11
02ee68: mov64 r3, 0x0
02ee70: mov64 r4, 0x1
02ee78: jle r2, r1, +0xf0 ; branch 0x2f600
02ee80: jeq r4, 0x0, +0xf1 ; branch 0x2f610
02ee88: lddw r2, 0x300007fef
02ee98: jne r1, 0x0, +0xf2 ; branch 0x2f630
02eea0: lddw r1, 0x300000007
02eeb0: jgt r2, r1, +0xf3 ; branch 0x2f650
02eeb8: ja +0x1ca ; branch 0x2fd10
02eec0: add64 r2, -0x13
02eec8: mov64 r3, 0x0
02eed0: mov64 r4, 0x1
02eed8: jle r2, r1, +0xf7 ; branch 0x2f698
02eee0: jeq r4, 0x0, +0xf8 ; branch 0x2f6a8
02eee8: lddw r2, 0x300007fed
02eef8: jne r1, 0x0, +0xf9 ; branch 0x2f6c8
02ef00: lddw r1, 0x300000007
02ef10: jgt r2, r1, +0xfa ; branch 0x2f6e8
02ef18: ja +0x1c8 ; branch 0x2fd60
02ef20: add64 r2, -0x11
02ef28: mov64 r3, 0x0
02ef30: mov64 r4, 0x1
02ef38: jle r2, r1, +0x101 ; branch 0x2f748
02ef40: jeq r4, 0x0, +0x102 ; branch 0x2f758
02ef48: lddw r2, 0x300007fef
02ef58: jne r1, 0x0, +0x103 ; branch 0x2f778
02ef60: lddw r1, 0x300000007
02ef70: jgt r2, r1, +0x104 ; branch 0x2f798
02ef78: ja +0x1b2 ; branch 0x2fd10
02ef80: jle r2, r1, +0x155 ; branch 0x2fa30
02ef88: jeq r4, 0x0, +0x156 ; branch 0x2fa40
02ef90: lddw r2, 0x300007ff3
02efa0: jne r1, 0x0, +0x157 ; branch 0x2fa60
02efa8: lddw r1, 0x300000007
02efb8: jgt r2, r1, +0x158 ; branch 0x2fa80
02efc0: ja +0x1ae ; branch 0x2fd38
02efc8: add64 r2, -0x17
02efd0: mov64 r3, 0x0
02efd8: mov64 r4, 0x1
02efe0: jle r2, r1, +0x15e ; branch 0x2fad8
02efe8: jeq r4, 0x0, +0x15f ; branch 0x2fae8
02eff0: lddw r2, 0x300007fe9
02f000: jne r1, 0x0, +0x160 ; branch 0x2fb08
02f008: lddw r1, 0x300000007
02f018: jgt r2, r1, +0x161 ; branch 0x2fb28
02f020: ja +0x1b1 ; branch 0x2fdb0
02f028: add64 r2, -0x13
02f030: mov64 r3, 0x0
02f038: mov64 r4, 0x1
02f040: jle r2, r1, +0x168 ; branch 0x2fb88
02f048: jeq r4, 0x0, +0x169 ; branch 0x2fb98
02f050: lddw r2, 0x300007fed
02f060: jne r1, 0x0, +0x16a ; branch 0x2fbb8
02f068: lddw r1, 0x300000007
02f078: jgt r2, r1, +0x16b ; branch 0x2fbd8
02f080: ja +0x19b ; branch 0x2fd60
02f088: add64 r2, -0x17
02f090: mov64 r3, 0x0
02f098: mov64 r4, 0x1
02f0a0: jle r2, r1, +0x172 ; branch 0x2fc38
02f0a8: jeq r4, 0x0, +0x173 ; branch 0x2fc48
02f0b0: lddw r2, 0x300007fe9
02f0c0: jne r1, 0x0, +0x174 ; branch 0x2fc68
02f0c8: lddw r1, 0x300000007
02f0d8: jgt r2, r1, +0x175 ; branch 0x2fc88
02f0e0: ja +0x199 ; branch 0x2fdb0
02f0e8: mov64 r4, 0x0
02f0f0: jne r4, 0x0, -0xa9 ; branch 0x2ebb0
02f0f8: mov64 r3, r2
02f100: lddw r2, 0x300007ff4
02f110: jeq r1, 0x0, -0xaa ; branch 0x2ebc8
02f118: mov64 r2, r3
02f120: lddw r1, 0x300000007
02f130: jgt r2, r1, -0xab ; branch 0x2ebe0
02f138: mov64 r1, 0x1
02f140: mov64 r2, 0xc
02f148: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02f158: call 0xe8dd ; call 0xa3848
02f160: mov64 r4, 0x0
02f168: jne r4, 0x0, -0xa4 ; branch 0x2ec50
02f170: mov64 r3, r2
02f178: lddw r2, 0x300007ff1
02f188: jeq r1, 0x0, -0xa5 ; branch 0x2ec68
02f190: mov64 r2, r3
02f198: lddw r1, 0x300000007
02f1a8: jle r2, r1, +0x17b ; branch 0x2fd88
02f1b0: lddw r1, 0x300000000
02f1c0: stxdw [r1 + 0x0], r2
02f1c8: lddw r1, 0x6567617070696c53
02f1d8: stxdw [r2 + 0x7], r1
02f1e0: lddw r1, 0x53697043706d7550
02f1f0: ja +0x7e ; branch 0x2f5e8
02f1f8: mov64 r4, 0x0
02f200: jne r4, 0x0, -0xab ; branch 0x2ecb0
02f208: mov64 r3, r2
02f210: lddw r2, 0x300007ff0
02f220: jeq r1, 0x0, -0xac ; branch 0x2ecc8
02f228: mov64 r2, r3
02f230: lddw r1, 0x300000007
02f240: jgt r2, r1, -0xad ; branch 0x2ece0
02f248: mov64 r1, 0x1
02f250: mov64 r2, 0x10
02f258: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02f268: call 0xe8bb ; call 0xa3848
02f270: mov64 r4, 0x0
02f278: jne r4, 0x0, -0xa4 ; branch 0x2ed60
02f280: mov64 r3, r2
02f288: lddw r2, 0x300007fe8
02f298: jeq r1, 0x0, -0xa5 ; branch 0x2ed78
02f2a0: mov64 r2, r3
02f2a8: lddw r1, 0x300000007
02f2b8: jgt r2, r1, -0xa6 ; branch 0x2ed90
02f2c0: mov64 r1, 0x1
02f2c8: mov64 r2, 0x18
02f2d0: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02f2e0: call 0xe8ac ; call 0xa3848
02f2e8: mov64 r4, 0x0
02f2f0: jne r4, 0x0, -0x174 ; branch 0x2e758
02f2f8: mov64 r3, r2
02f300: lddw r2, 0x300007fef
02f310: jeq r1, 0x0, -0x175 ; branch 0x2e770
02f318: mov64 r2, r3
02f320: lddw r1, 0x300000007
02f330: jle r2, r1, +0x13b ; branch 0x2fd10
02f338: lddw r1, 0x300000000
02f348: stxdw [r1 + 0x0], r2
02f350: lddw r1, 0x6f4c6f6f54736576
02f360: stxdw [r2 + 0x8], r1
02f368: lddw r1, 0x72657365526c6f53
02f378: stxdw [r2 + 0x0], r1
02f380: mov64 r1, 0x11
02f388: stb [r2 + 0x10], 0x77
02f390: ja +0x12b ; branch 0x2fcf0
02f398: mov64 r4, 0x0
02f3a0: jne r4, 0x0, -0x17a ; branch 0x2e7d8
02f3a8: mov64 r3, r2
02f3b0: lddw r2, 0x300007fed
02f3c0: jeq r1, 0x0, -0x17b ; branch 0x2e7f0
02f3c8: mov64 r2, r3
02f3d0: lddw r1, 0x300000007
02f3e0: jle r2, r1, +0x12f ; branch 0x2fd60
02f3e8: lddw r1, 0x300000000
02f3f8: stxdw [r1 + 0x0], r2
02f400: lddw r1, 0x7070696c53697043
02f410: stxdw [r2 + 0x8], r1
02f418: lddw r1, 0x70617753706d7550
02f428: stxdw [r2 + 0x0], r1
02f430: mov64 r1, 0x13
02f438: stw [r2 + 0xf], 0x65676170
02f440: ja +0x115 ; branch 0x2fcf0
02f448: mov64 r4, 0x0
02f450: jne r4, 0x0, -0x181 ; branch 0x2e850
02f458: mov64 r3, r2
02f460: lddw r2, 0x300007ff3
02f470: jeq r1, 0x0, -0x182 ; branch 0x2e868
02f478: mov64 r2, r3
02f480: lddw r1, 0x300000007
02f490: jle r2, r1, +0x114 ; branch 0x2fd38
02f498: lddw r1, 0x300000000
02f4a8: stxdw [r1 + 0x0], r2
02f4b0: lddw r1, 0x64656c6961466970
02f4c0: stxdw [r2 + 0x5], r1
02f4c8: lddw r1, 0x46697043706d7550
02f4d8: ja +0xbc ; branch 0x2fac0
02f4e0: mov64 r4, 0x0
02f4e8: jne r4, 0x0, -0x185 ; branch 0x2e8c8
02f4f0: mov64 r3, r2
02f4f8: lddw r2, 0x300007ff5
02f508: jeq r1, 0x0, -0x186 ; branch 0x2e8e0
02f510: mov64 r2, r3
02f518: lddw r1, 0x300000007
02f528: jgt r2, r1, -0x187 ; branch 0x2e8f8
02f530: mov64 r1, 0x1
02f538: mov64 r2, 0xb
02f540: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02f550: call 0xe85e ; call 0xa3848
02f558: mov64 r4, 0x0
02f560: jne r4, 0x0, -0xe8 ; branch 0x2ee28
02f568: mov64 r3, r2
02f570: lddw r2, 0x300007ff1
02f580: jeq r1, 0x0, -0xe9 ; branch 0x2ee40
02f588: mov64 r2, r3
02f590: lddw r1, 0x300000007
02f5a0: jle r2, r1, +0xfc ; branch 0x2fd88
02f5a8: lddw r1, 0x300000000
02f5b8: stxdw [r1 + 0x0], r2
02f5c0: lddw r1, 0x6465646e4565646f
02f5d0: stxdw [r2 + 0x7], r1
02f5d8: lddw r1, 0x6f4d6d656879614d
02f5e8: stxdw [r2 + 0x0], r1
02f5f0: mov64 r1, 0xf
02f5f8: ja +0xde ; branch 0x2fcf0
02f600: mov64 r4, 0x0
02f608: jne r4, 0x0, -0xf1 ; branch 0x2ee88
02f610: mov64 r3, r2
02f618: lddw r2, 0x300007fef
02f628: jeq r1, 0x0, -0xf2 ; branch 0x2eea0
02f630: mov64 r2, r3
02f638: lddw r1, 0x300000007
02f648: jle r2, r1, +0xd8 ; branch 0x2fd10
02f650: lddw r1, 0x300000000
02f660: stxdw [r1 + 0x0], r2
02f668: lddw r1, 0x696d694c65746152
02f678: stxdw [r2 + 0x8], r1
02f680: lddw r1, 0x7761726468746957
02f690: ja +0x28 ; branch 0x2f7d8
02f698: mov64 r4, 0x0
02f6a0: jne r4, 0x0, -0xf8 ; branch 0x2eee8
02f6a8: mov64 r3, r2
02f6b0: lddw r2, 0x300007fed
02f6c0: jeq r1, 0x0, -0xf9 ; branch 0x2ef00
02f6c8: mov64 r2, r3
02f6d0: lddw r1, 0x300000007
02f6e0: jle r2, r1, +0xcf ; branch 0x2fd60
02f6e8: lddw r1, 0x300000000
02f6f8: stxdw [r1 + 0x0], r2
02f700: lddw r1, 0x667265764f687461
02f710: stxdw [r2 + 0x8], r1
02f718: lddw r1, 0x4d697043706d7550
02f728: stxdw [r2 + 0x0], r1
02f730: mov64 r1, 0x13
02f738: stw [r2 + 0xf], 0x776f6c66
02f740: ja +0xb5 ; branch 0x2fcf0
02f748: mov64 r4, 0x0
02f750: jne r4, 0x0, -0x102 ; branch 0x2ef48
02f758: mov64 r3, r2
02f760: lddw r2, 0x300007fef
02f770: jeq r1, 0x0, -0x103 ; branch 0x2ef60
02f778: mov64 r2, r3
02f780: lddw r1, 0x300000007
02f790: jle r2, r1, +0xaf ; branch 0x2fd10
02f798: lddw r1, 0x300000000
02f7a8: stxdw [r1 + 0x0], r2
02f7b0: lddw r1, 0x696d694c65746152
02f7c0: stxdw [r2 + 0x8], r1
02f7c8: lddw r1, 0x6565467065657753
02f7d8: stxdw [r2 + 0x0], r1
02f7e0: mov64 r1, 0x11
02f7e8: stb [r2 + 0x10], 0x74
02f7f0: ja +0x9f ; branch 0x2fcf0
02f7f8: mov64 r4, 0x0
02f800: jne r4, 0x0, -0x1d3 ; branch 0x2e970
02f808: mov64 r3, r2
02f810: lddw r2, 0x300007ff3
02f820: jeq r1, 0x0, -0x1d4 ; branch 0x2e988
02f828: mov64 r2, r3
02f830: lddw r1, 0x300000007
02f840: jle r2, r1, +0x9e ; branch 0x2fd38
02f848: lddw r1, 0x300000000
02f858: stxdw [r1 + 0x0], r2
02f860: lddw r1, 0x646573756150676e
02f870: stxdw [r2 + 0x5], r1
02f878: lddw r1, 0x50676e6964617254
02f888: ja +0x46 ; branch 0x2fac0
02f890: mov64 r4, 0x0
02f898: jne r4, 0x0, -0x1d9 ; branch 0x2e9d8
02f8a0: mov64 r3, r2
02f8a8: lddw r2, 0x300007fef
02f8b8: jeq r1, 0x0, -0x1da ; branch 0x2e9f0
02f8c0: mov64 r2, r3
02f8c8: lddw r1, 0x300000007
02f8d8: jle r2, r1, +0x86 ; branch 0x2fd10
02f8e0: lddw r1, 0x300000000
02f8f0: stxdw [r1 + 0x0], r2
02f8f8: lddw r1, 0x656c696146697043
02f908: stxdw [r2 + 0x8], r1
02f910: lddw r1, 0x70617753706d7550
02f920: stxdw [r2 + 0x0], r1
02f928: mov64 r1, 0x11
02f930: stb [r2 + 0x10], 0x64
02f938: ja +0x76 ; branch 0x2fcf0
02f940: mov64 r4, 0x0
02f948: jne r4, 0x0, -0x1e2 ; branch 0x2ea40
02f950: mov64 r3, r2
02f958: lddw r2, 0x300007fee
02f968: jeq r1, 0x0, -0x1e3 ; branch 0x2ea58
02f970: mov64 r2, r3
02f978: lddw r1, 0x300000007
02f988: jgt r2, r1, -0x1e4 ; branch 0x2ea70
02f990: mov64 r1, 0x1
02f998: mov64 r2, 0x12
02f9a0: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02f9b0: call 0xe7d2 ; call 0xa3848
02f9b8: mov64 r4, 0x0
02f9c0: jne r4, 0x0, -0x1d9 ; branch 0x2eb00
02f9c8: mov64 r3, r2
02f9d0: lddw r2, 0x300007ff2
02f9e0: jeq r1, 0x0, -0x1da ; branch 0x2eb18
02f9e8: mov64 r2, r3
02f9f0: lddw r1, 0x300000007
02fa00: jgt r2, r1, -0x1db ; branch 0x2eb30
02fa08: mov64 r1, 0x1
02fa10: mov64 r2, 0xe
02fa18: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fa28: call 0xe7c3 ; call 0xa3848
02fa30: mov64 r4, 0x0
02fa38: jne r4, 0x0, -0x156 ; branch 0x2ef90
02fa40: mov64 r3, r2
02fa48: lddw r2, 0x300007ff3
02fa58: jeq r1, 0x0, -0x157 ; branch 0x2efa8
02fa60: mov64 r2, r3
02fa68: lddw r1, 0x300000007
02fa78: jle r2, r1, +0x57 ; branch 0x2fd38
02fa80: lddw r1, 0x300000000
02fa90: stxdw [r1 + 0x0], r2
02fa98: lddw r1, 0x657669746341676e
02faa8: stxdw [r2 + 0x5], r1
02fab0: lddw r1, 0x41676e6964617254
02fac0: stxdw [r2 + 0x0], r1
02fac8: mov64 r1, 0xd
02fad0: ja +0x43 ; branch 0x2fcf0
02fad8: mov64 r4, 0x0
02fae0: jne r4, 0x0, -0x15f ; branch 0x2eff0
02fae8: mov64 r3, r2
02faf0: lddw r2, 0x300007fe9
02fb00: jeq r1, 0x0, -0x160 ; branch 0x2f008
02fb08: mov64 r2, r3
02fb10: lddw r1, 0x300000007
02fb20: jle r2, r1, +0x51 ; branch 0x2fdb0
02fb28: lddw r1, 0x300000000
02fb38: stxdw [r1 + 0x0], r2
02fb40: lddw r1, 0x776f6c667265764f
02fb50: stxdw [r2 + 0xf], r1
02fb58: lddw r1, 0x4f6874614d697043
02fb68: stxdw [r2 + 0x8], r1
02fb70: lddw r1, 0x70617753706d7550
02fb80: ja +0x2b ; branch 0x2fce0
02fb88: mov64 r4, 0x0
02fb90: jne r4, 0x0, -0x169 ; branch 0x2f050
02fb98: mov64 r3, r2
02fba0: lddw r2, 0x300007fed
02fbb0: jeq r1, 0x0, -0x16a ; branch 0x2f068
02fbb8: mov64 r2, r3
02fbc0: lddw r1, 0x300000007
02fbd0: jle r2, r1, +0x31 ; branch 0x2fd60
02fbd8: lddw r1, 0x300000000
02fbe8: stxdw [r1 + 0x0], r2
02fbf0: lddw r1, 0x65656378456b7369
02fc00: stxdw [r2 + 0x8], r1
02fc08: lddw r1, 0x526c6c617265764f
02fc18: stxdw [r2 + 0x0], r1
02fc20: mov64 r1, 0x13
02fc28: stw [r2 + 0xf], 0x64656465
02fc30: ja +0x17 ; branch 0x2fcf0
02fc38: mov64 r4, 0x0
02fc40: jne r4, 0x0, -0x173 ; branch 0x2f0b0
02fc48: mov64 r3, r2
02fc50: lddw r2, 0x300007fe9
02fc60: jeq r1, 0x0, -0x174 ; branch 0x2f0c8
02fc68: mov64 r2, r3
02fc70: lddw r1, 0x300000007
02fc80: jle r2, r1, +0x25 ; branch 0x2fdb0
02fc88: lddw r1, 0x300000000
02fc98: stxdw [r1 + 0x0], r2
02fca0: lddw r1, 0x646574726f707075
02fcb0: stxdw [r2 + 0xf], r1
02fcb8: lddw r1, 0x7553746f4e657079
02fcc8: stxdw [r2 + 0x8], r1
02fcd0: lddw r1, 0x54746e756f636341
02fce0: stxdw [r2 + 0x0], r1
02fce8: mov64 r1, 0x17
02fcf0: stxdw [r6 + 0x8], r2
02fcf8: stxdw [r6 + 0x10], r1
02fd00: stxdw [r6 + 0x0], r1
02fd08: exit
02fd10: mov64 r1, 0x1
02fd18: mov64 r2, 0x11
02fd20: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fd30: call 0xe762 ; call 0xa3848
02fd38: mov64 r1, 0x1
02fd40: mov64 r2, 0xd
02fd48: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fd58: call 0xe75d ; call 0xa3848
02fd60: mov64 r1, 0x1
02fd68: mov64 r2, 0x13
02fd70: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fd80: call 0xe758 ; call 0xa3848
02fd88: mov64 r1, 0x1
02fd90: mov64 r2, 0xf
02fd98: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fda8: call 0xe753 ; call 0xa3848
02fdb0: mov64 r1, 0x1
02fdb8: mov64 r2, 0x17
02fdc0: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
02fdd0: call 0xe74e ; call 0xa3848
