#!/usr/bin/env python3
"""Hash reviewed static windows. Does not load or execute the SBF program."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
ORIGINAL = REPO / 'evidence/original/mayhem/deployed.so'
EXPECTED = 'a87fa9f866272514e6acb852b668c4a08aeb173d56c883039991d114d1199bdb'
sha = lambda data: hashlib.sha256(data).hexdigest()
b = ORIGINAL.read_bytes()
assert sha(b) == EXPECTED
windows = {}
for path in sorted(ROOT.glob('*.asm')):
    lines = path.read_text().splitlines()
    start, end = int(lines[0].split(':')[0], 16), int(lines[-1].split(':')[0], 16) + 8
    windows[path.name] = dict(start=hex(start), end_exclusive=hex(end),
        byte_length=end-start, original_bytes_sha256=sha(b[start:end]),
        annotation_sha256=sha(path.read_bytes()))

observations = [
    ('deadline_signed_compare', 0xd8e0, 8), ('deadline_error_6005', 0xda18, 8),
    ('status_guard', 0xda38, 16), ('ended_error_6004', 0xdb78, 8),
    ('vault_amount_load', 0xdbc0, 8), ('burn_call', 0xe120, 8),
    ('burned_amount_store', 0xe138, 8), ('first_event_clock', 0xe1f0, 8),
    ('log_event_call', 0xe468, 8), ('second_event_clock', 0xe608, 8),
    ('event_cpi_prefix', 0xe980, 16), ('event_meta_flags', 0xeac8, 8),
    ('event_invoke_signed', 0xebe8, 8), ('ended_store', 0xed80, 8),
    ('token_burn_tag', 0x93640, 8), ('state_discriminator', 0xacaa8, 8),
    ('curve_discriminator', 0xacab8, 8),
]
evidence = {
    'scope': 'Static review and compilation only; no instruction execution or transaction replay.',
    'original': {'path': str(ORIGINAL.relative_to(REPO)), 'sha256': EXPECTED, 'size': len(b)},
    'windows': windows,
    'observations': {name: {'offset':hex(at), 'hex':b[at:at+n].hex(), 'sha256':sha(b[at:at+n])}
                     for name, at, n in observations},
    'discriminators': {name: hashlib.sha256(name.encode()).digest()[:8].hex()
                      for name in ['account:MayhemState', 'account:BondingCurve', 'event:BurnEvent', 'global:burn_tokens']},
    'source_files': {str(p.relative_to(ROOT)):sha(p.read_bytes())
                     for p in sorted((ROOT/'crate').rglob('*')) if p.is_file()
                     and (p.suffix == '.rs' or p.name in ['Cargo.toml', 'Cargo.lock'])},
    'anchor_sources': json.loads((ROOT/'anchor-source-provenance.json').read_text()),
}
assert evidence['observations']['state_discriminator']['hex'] == evidence['discriminators']['account:MayhemState']
assert evidence['observations']['curve_discriminator']['hex'] == evidence['discriminators']['account:BondingCurve']
for rel, meta in evidence['anchor_sources']['files'].items():
    assert sha((ROOT/'anchor-v1.0.0'/rel).read_bytes()) == meta['sha256']
(ROOT/'static-evidence.json').write_text(json.dumps(evidence, indent=2)+'\n')
print(json.dumps({'original_sha256': EXPECTED, 'windows':len(windows), 'source_files':len(evidence['source_files'])}))
