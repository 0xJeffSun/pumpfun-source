0999d8: call -0x1
0999e0: exit
