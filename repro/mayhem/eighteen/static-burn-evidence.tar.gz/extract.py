from pathlib import Path
import json,re,struct,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent.parent;b=(REPO/'evidence/original/mayhem/deployed.so').read_bytes();s=struct.unpack_from('<Q',b,40)[0];z,n,k=struct.unpack_from('<HHH',b,58);hs=[struct.unpack_from('<IIQQQQIIQQ',b,s+i*z) for i in range(n)];h=hs[k];names=b[h[4]:h[4]+h[5]];ss={names[h[0]:].split(b'\0',1)[0].decode():h for h in hs};t=ss['.text'];lo,hi=t[4],t[4]+t[5];h=ss['.rel.dyn'];rels={struct.unpack_from('<QQ',b,i)[0]:struct.unpack_from('<QQ',b,i)[1]&0xffffffff for i in range(h[4],h[4]+h[5],16)};calls={};entries={lo}
for a in range(lo,hi,8):
 if b[a]==0x85 and b[a+1]==0x10 and rels.get(a)!=10:
  target=a+8+8*struct.unpack_from('<i',b,a+4)[0];calls[a]=target
  if lo<=target<hi:entries.add(target)
entries=sorted(entries)
asm={}
for line in (REPO/'work/disassembly/mayhem.asm').read_text().splitlines():
 m=re.match(r'\s*([0-9a-f]+):\s*(?:[0-9a-f]{2} )+\s+(.+)',line)
 if m:asm[int(m[1],16)]=m[2]
def dump(name,start,end=None):
 end=end or next(x for x in entries if x>start);out=[]
 for at,mn in asm.items():
  if not start<=at<end:continue
  mn=re.sub(r' <[^>]*>','',mn)
  if at in calls:mn+=f' ; call {calls[at]:#x}'
  if b[at]&7==5 and b[at] not in [0x85,0x8d,0x95]:mn+=f' ; branch {at+8+8*struct.unpack_from("<h",b,at+2)[0]:#x}'
  if b[at]==0x18:
   ptr=struct.unpack_from('<I',b,at+4)[0]
   if hi<=ptr<len(b):mn+=' ; rodata '+repr(b[ptr:ptr+75])
  out.append(f'{at:06x}: {mn}')
 (ROOT/(name+'.asm')).write_text('\n'.join(out)+'\n');return (hex(start),hex(end),end-start)
if __name__=='__main__':
 for label,start in [('state-account-deserialize',0x7848),('state-serialize',0x685f0),('error-name',0x2e6d0),('error-message',0x2fdd8),('burn',0xd898),('accounts',0x38670),('exit',0x3afb8)]:print(label,dump(label,start))
