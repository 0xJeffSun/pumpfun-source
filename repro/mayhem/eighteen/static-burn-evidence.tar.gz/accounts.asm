038670: mov64 r7, r5
038678: mov64 r8, r3
038680: stxdw [r10 - 0x4f0], r2
038688: mov64 r6, r1
038690: mov64 r1, r10
038698: add64 r1, -0x4e0
0386a0: mov64 r5, r10
0386a8: call -0x5caf ; call 0xa138
0386b0: ldxdw r9, [r10 - 0x4d8]
0386b8: ldxdw r1, [r10 - 0x4e0]
0386c0: stxdw [r10 - 0x4e8], r1
0386c8: ldxb r1, [r10 - 0x477]
0386d0: jne r1, 0x2, +0x1a ; branch 0x387a8
0386d8: call 0x95e2 ; call 0x835f0
0386e0: lddw r1, 0x300000000
0386f0: ldxdw r2, [r1 + 0x0]
0386f8: mov64 r1, r2
038700: add64 r1, -0xc
038708: mov64 r3, 0x0
038710: mov64 r4, 0x1
038718: jgt r1, r2, +0x44 ; branch 0x38940
038720: mov64 r4, 0x0
038728: ldxdw r5, [r10 - 0x4e8]
038730: jeq r4, 0x0, +0x43 ; branch 0x38950
038738: lddw r1, 0x300007ff4
038748: jeq r2, 0x0, +0x44 ; branch 0x38970
038750: mov64 r1, r3
038758: mov64 r2, r5
038760: and64 r2, 0x1
038768: lddw r2, 0x300000007
038778: jgt r1, r2, +0x43 ; branch 0x38998
038780: mov64 r1, 0x1
038788: mov64 r2, 0xc
038790: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
0387a0: call 0xd614 ; call 0xa3848
0387a8: stxdw [r10 - 0x4f8], r1
0387b0: ldxdw r7, [r7 - 0xff8]
0387b8: mov64 r1, r10
0387c0: add64 r1, -0x468
0387c8: mov64 r2, r10
0387d0: add64 r2, -0x4d0
0387d8: mov64 r3, 0x59
0387e0: call 0xe3b4 ; call 0xaa588
0387e8: ldxw r1, [r10 - 0x476]
0387f0: stxw [r10 - 0x470], r1
0387f8: ldxh r1, [r10 - 0x472]
038800: stxh [r10 - 0x46c], r1
038808: mov64 r1, r10
038810: add64 r1, -0x408
038818: mov64 r5, r10
038820: mov64 r3, r8
038828: call -0x6b68 ; call 0x2cf0
038830: ldxw r1, [r10 - 0x408]
038838: jne r1, 0x2, +0x3a ; branch 0x38a10
038840: ldxdw r8, [r10 - 0x3f8]
038848: ldxdw r7, [r10 - 0x400]
038850: call 0x95b3 ; call 0x835f0
038858: lddw r1, 0x300000000
038868: ldxdw r2, [r1 + 0x0]
038870: mov64 r1, r2
038878: add64 r1, -0x4
038880: mov64 r3, 0x0
038888: mov64 r4, 0x1
038890: jgt r1, r2, +0x79 ; branch 0x38c60
038898: mov64 r4, 0x0
0388a0: jeq r4, 0x0, +0x78 ; branch 0x38c68
0388a8: lddw r1, 0x300007ffc
0388b8: jeq r2, 0x0, +0x79 ; branch 0x38c88
0388c0: mov64 r1, r3
0388c8: lddw r2, 0x300000007
0388d8: jeq r7, 0x1, +0x78 ; branch 0x38ca0
0388e0: jle r1, r2, +0x78 ; branch 0x38ca8
0388e8: lddw r2, 0x300000000
0388f8: stxdw [r2 + 0x0], r1
038900: stw [r1 + 0x0], 0x746e696d
038908: ldxdw r2, [r8 + 0x0]
038910: stxdw [r8 + 0x10], r1
038918: stdw [r8 + 0x18], 0x4
038920: stdw [r8 + 0x8], 0x4
038928: stdw [r8 + 0x0], 0x1
038930: stxdw [r6 + 0x10], r8
038938: ja +0x61 ; branch 0x38c48
038940: ldxdw r5, [r10 - 0x4e8]
038948: jne r4, 0x0, -0x43 ; branch 0x38738
038950: mov64 r3, r1
038958: lddw r1, 0x300007ff4
038968: jne r2, 0x0, -0x44 ; branch 0x38750
038970: mov64 r2, r5
038978: and64 r2, 0x1
038980: lddw r2, 0x300000007
038990: jle r1, r2, -0x43 ; branch 0x38780
038998: lddw r2, 0x300000000
0389a8: stxdw [r2 + 0x0], r1
0389b0: lddw r2, 0x735f6d656879616d
0389c0: stxdw [r1 + 0x0], r2
0389c8: stw [r1 + 0x8], 0x65746174
0389d0: ldxdw r2, [r9 + 0x0]
0389d8: stxdw [r9 + 0x10], r1
0389e0: stdw [r9 + 0x18], 0xc
0389e8: stdw [r9 + 0x8], 0xc
0389f0: stdw [r9 + 0x0], 0x1
0389f8: stxdw [r6 + 0x10], r9
038a00: stxdw [r6 + 0x8], r5
038a08: ja +0x48 ; branch 0x38c50
038a10: stxdw [r10 - 0x510], r7
038a18: stxdw [r10 - 0x528], r1
038a20: ldxdw r1, [r10 - 0x3f8]
038a28: stxdw [r10 - 0x520], r1
038a30: ldxdw r1, [r10 - 0x400]
038a38: stxdw [r10 - 0x518], r1
038a40: ldxw r1, [r10 - 0x404]
038a48: stxdw [r10 - 0x530], r1
038a50: mov64 r1, r10
038a58: add64 r1, -0x368
038a60: mov64 r2, r10
038a68: add64 r2, -0x3f0
038a70: mov64 r3, 0x40
038a78: call 0xe361 ; call 0xaa588
038a80: ldxdw r1, [r10 - 0x3a8]
038a88: stxdw [r10 - 0x388], r1
038a90: ldxdw r1, [r10 - 0x3a0]
038a98: stxdw [r10 - 0x380], r1
038aa0: ldxdw r1, [r10 - 0x398]
038aa8: stxdw [r10 - 0x378], r1
038ab0: ldxdw r1, [r10 - 0x390]
038ab8: stxdw [r10 - 0x370], r1
038ac0: ldxdw r1, [r10 - 0x3b0]
038ac8: stxdw [r10 - 0x508], r1
038ad0: mov64 r1, r10
038ad8: add64 r1, -0x328
038ae0: mov64 r5, r10
038ae8: mov64 r3, r8
038af0: call -0x6bb0 ; call 0x2d78
038af8: ldxdw r1, [r10 - 0x320]
038b00: stxdw [r10 - 0x500], r1
038b08: ldxdw r7, [r10 - 0x328]
038b10: ldxw r1, [r10 - 0x278]
038b18: jne r1, 0x2, +0x36 ; branch 0x38cd0
038b20: call 0x9559 ; call 0x835f0
038b28: lddw r1, 0x300000000
038b38: ldxdw r2, [r1 + 0x0]
038b40: mov64 r1, r2
038b48: add64 r1, -0x12
038b50: mov64 r3, 0x0
038b58: mov64 r4, 0x1
038b60: jgt r1, r2, +0x5d ; branch 0x38e50
038b68: mov64 r4, 0x0
038b70: jeq r4, 0x0, +0x5c ; branch 0x38e58
038b78: lddw r1, 0x300007fee
038b88: jeq r2, 0x0, +0x1 ; branch 0x38b98
038b90: mov64 r1, r3
038b98: mov64 r2, r7
038ba0: and64 r2, 0x1
038ba8: lddw r2, 0x300000007
038bb8: ldxdw r3, [r10 - 0x500]
038bc0: jle r1, r2, +0x426 ; branch 0x3acf8
038bc8: lddw r2, 0x300000000
038bd8: stxdw [r2 + 0x0], r1
038be0: lddw r2, 0x7561765f6e656b6f
038bf0: stxdw [r1 + 0x8], r2
038bf8: lddw r2, 0x745f6d656879616d
038c08: stxdw [r1 + 0x0], r2
038c10: sth [r1 + 0x10], 0x746c
038c18: ldxdw r2, [r3 + 0x0]
038c20: stxdw [r3 + 0x10], r1
038c28: stdw [r3 + 0x18], 0x12
038c30: stdw [r3 + 0x8], 0x12
038c38: stdw [r3 + 0x0], 0x1
038c40: stxdw [r6 + 0x10], r3
038c48: stxdw [r6 + 0x8], r7
038c50: stw [r6 + 0x0], 0x2
038c58: exit
038c60: jne r4, 0x0, -0x78 ; branch 0x388a8
038c68: mov64 r3, r1
038c70: lddw r1, 0x300007ffc
038c80: jne r2, 0x0, -0x79 ; branch 0x388c0
038c88: lddw r2, 0x300000007
038c98: jne r7, 0x1, -0x78 ; branch 0x388e0
038ca0: jgt r1, r2, -0x78 ; branch 0x388e8
038ca8: mov64 r1, 0x1
038cb0: mov64 r2, 0x4
038cb8: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
038cc8: call 0xd56f ; call 0xa3848
038cd0: stxdw [r10 - 0x560], r1
038cd8: ldxdw r1, [r10 - 0x310]
038ce0: stxdw [r10 - 0x1b8], r1
038ce8: ldxdw r1, [r10 - 0x318]
038cf0: stxdw [r10 - 0x1c0], r1
038cf8: ldxdw r1, [r10 - 0x300]
038d00: stxdw [r10 - 0x1e0], r1
038d08: ldxdw r1, [r10 - 0x2f8]
038d10: stxdw [r10 - 0x1d8], r1
038d18: ldxdw r1, [r10 - 0x2f0]
038d20: stxdw [r10 - 0x1d0], r1
038d28: ldxdw r1, [r10 - 0x2e8]
038d30: stxdw [r10 - 0x1c8], r1
038d38: ldxdw r1, [r10 - 0x308]
038d40: stxdw [r10 - 0x538], r1
038d48: ldxdw r1, [r10 - 0x2e0]
038d50: stxdw [r10 - 0x540], r1
038d58: ldxdw r1, [r10 - 0x2d8]
038d60: stxdw [r10 - 0x548], r1
038d68: ldxdw r1, [r10 - 0x2d0]
038d70: stxdw [r10 - 0x550], r1
038d78: ldxdw r1, [r10 - 0x2c8]
038d80: stxdw [r10 - 0x558], r1
038d88: mov64 r1, r10
038d90: add64 r1, -0x228
038d98: mov64 r2, r10
038da0: add64 r2, -0x2c0
038da8: mov64 r3, 0x48
038db0: call 0xe2fa ; call 0xaa588
038db8: ldxw r1, [r10 - 0x254]
038dc0: stxw [r10 - 0x230], r1
038dc8: ldxdw r1, [r10 - 0x25c]
038dd0: stxdw [r10 - 0x238], r1
038dd8: ldxdw r1, [r10 - 0x264]
038de0: stxdw [r10 - 0x240], r1
038de8: ldxdw r1, [r10 - 0x26c]
038df0: stxdw [r10 - 0x248], r1
038df8: ldxdw r1, [r10 - 0x274]
038e00: stxdw [r10 - 0x250], r1
038e08: ldxdw r1, [r8 + 0x8]
038e10: jeq r1, 0x0, +0xd ; branch 0x38e80
038e18: add64 r1, -0x1
038e20: stxdw [r8 + 0x8], r1
038e28: ldxdw r1, [r8 + 0x0]
038e30: stxdw [r10 - 0x568], r1
038e38: add64 r1, 0x30
038e40: stxdw [r8 + 0x0], r1
038e48: ja +0xa ; branch 0x38ea0
038e50: jne r4, 0x0, -0x5c ; branch 0x38b78
038e58: mov64 r3, r1
038e60: lddw r1, 0x300007fee
038e70: jne r2, 0x0, -0x5d ; branch 0x38b90
038e78: ja -0x5d ; branch 0x38b98
038e80: mov64 r1, 0xbbd
038e88: call 0xc2eb ; call 0x9a5e8
038e90: jne r0, 0x2, +0x70 ; branch 0x39218
038e98: stxdw [r10 - 0x568], r1
038ea0: mov64 r1, r10
038ea8: add64 r1, -0x58
038eb0: mov64 r5, r10
038eb8: mov64 r3, r8
038ec0: call -0x5da1 ; call 0xa1c0
038ec8: ldxb r1, [r10 - 0x7]
038ed0: jne r1, 0x2, +0x23 ; branch 0x38ff0
038ed8: ldxdw r8, [r10 - 0x50]
038ee0: ldxdw r7, [r10 - 0x58]
038ee8: call 0x94e0 ; call 0x835f0
038ef0: lddw r1, 0x300000000
038f00: ldxdw r2, [r1 + 0x0]
038f08: mov64 r1, r2
038f10: add64 r1, -0xd
038f18: mov64 r3, 0x0
038f20: mov64 r4, 0x1
038f28: jgt r1, r2, +0x2e ; branch 0x390a0
038f30: mov64 r4, 0x0
038f38: jeq r4, 0x0, +0x2d ; branch 0x390a8
038f40: lddw r1, 0x300007ff3
038f50: jeq r2, 0x0, +0x2e ; branch 0x390c8
038f58: mov64 r1, r3
038f60: lddw r2, 0x300000007
038f70: jeq r7, 0x1, +0x2d ; branch 0x390e0
038f78: jle r1, r2, +0x2d ; branch 0x390e8
038f80: lddw r2, 0x300000000
038f90: stxdw [r2 + 0x0], r1
038f98: lddw r2, 0x65767275635f676e
038fa8: stxdw [r1 + 0x5], r2
038fb0: lddw r2, 0x5f676e69646e6f62
038fc0: stxdw [r1 + 0x0], r2
038fc8: ldxdw r2, [r8 + 0x0]
038fd0: stxdw [r8 + 0x10], r1
038fd8: stdw [r8 + 0x18], 0xd
038fe0: stdw [r8 + 0x8], 0xd
038fe8: ja -0xd9 ; branch 0x38928
038ff0: call 0x94bf ; call 0x835f0
038ff8: lddw r1, 0x300000000
039008: ldxdw r5, [r1 + 0x0]
039010: mov64 r3, r5
039018: add64 r3, -0x58
039020: mov64 r2, 0x0
039028: mov64 r4, 0x1
039030: jgt r3, r5, +0x1b ; branch 0x39110
039038: mov64 r4, 0x0
039040: jeq r4, 0x0, +0x1a ; branch 0x39118
039048: lddw r1, 0x300007fa8
039058: jeq r5, 0x0, +0x1b ; branch 0x39138
039060: and64 r2, -0x8
039068: mov64 r1, r2
039070: lddw r2, 0x300000007
039080: jgt r1, r2, +0x19 ; branch 0x39150
039088: mov64 r1, 0x8
039090: mov64 r2, 0x58
039098: call 0xd4f9 ; call 0xa3868
0390a0: jne r4, 0x0, -0x2d ; branch 0x38f40
0390a8: mov64 r3, r1
0390b0: lddw r1, 0x300007ff3
0390c0: jne r2, 0x0, -0x2e ; branch 0x38f58
0390c8: lddw r2, 0x300000007
0390d8: jne r7, 0x1, -0x2d ; branch 0x38f78
0390e0: jgt r1, r2, -0x2d ; branch 0x38f80
0390e8: mov64 r1, 0x1
0390f0: mov64 r2, 0xd
0390f8: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
039108: call 0xd4e7 ; call 0xa3848
039110: jne r4, 0x0, -0x1a ; branch 0x39048
039118: mov64 r2, r3
039120: lddw r1, 0x300007fa8
039130: jne r5, 0x0, -0x1b ; branch 0x39060
039138: lddw r2, 0x300000007
039148: jle r1, r2, -0x19 ; branch 0x39088
039150: lddw r2, 0x300000000
039160: stxdw [r2 + 0x0], r1
039168: mov64 r2, r10
039170: add64 r2, -0x58
039178: stxdw [r10 - 0x570], r1
039180: mov64 r3, 0x58
039188: call 0xe27f ; call 0xaa588
039190: ldxdw r1, [r8 + 0x8]
039198: jeq r1, 0x0, +0x3d ; branch 0x39388
0391a0: ldxdw r2, [r8 + 0x0]
0391a8: stxdw [r10 - 0x578], r2
0391b0: add64 r2, 0x30
0391b8: stxdw [r8 + 0x0], r2
0391c0: add64 r1, -0x1
0391c8: stxdw [r8 + 0x8], r1
0391d0: jeq r1, 0x0, +0x3b ; branch 0x393b0
0391d8: ldxdw r2, [r8 + 0x0]
0391e0: stxdw [r10 - 0x580], r2
0391e8: add64 r2, 0x30
0391f0: stxdw [r8 + 0x0], r2
0391f8: add64 r1, -0x1
039200: stxdw [r8 + 0x8], r1
039208: jne r1, 0x0, +0x48 ; branch 0x39450
039210: ja +0x38 ; branch 0x393d8
039218: mov64 r8, r0
039220: mov64 r7, r1
039228: call 0x9478 ; call 0x835f0
039230: lddw r1, 0x300000000
039240: ldxdw r2, [r1 + 0x0]
039248: mov64 r1, r2
039250: add64 r1, -0x9
039258: mov64 r3, 0x0
039260: mov64 r4, 0x1
039268: jgt r1, r2, +0x1c ; branch 0x39350
039270: mov64 r4, 0x0
039278: jeq r4, 0x0, +0x1b ; branch 0x39358
039280: lddw r1, 0x300007ff7
039290: mov64 r4, r8
039298: jeq r2, 0x0, +0x1 ; branch 0x392a8
0392a0: mov64 r1, r3
0392a8: mov64 r2, r4
0392b0: and64 r2, 0x1
0392b8: lddw r2, 0x300000007
0392c8: mov64 r3, r7
0392d0: jle r1, r2, +0x381 ; branch 0x3aee0
0392d8: lddw r2, 0x300000000
0392e8: stxdw [r2 + 0x0], r1
0392f0: lddw r2, 0x6c7561765f6c6f73
039300: stxdw [r1 + 0x0], r2
039308: stb [r1 + 0x8], 0x74
039310: ldxdw r2, [r3 + 0x0]
039318: stxdw [r3 + 0x10], r1
039320: stdw [r3 + 0x18], 0x9
039328: stdw [r3 + 0x8], 0x9
039330: stdw [r3 + 0x0], 0x1
039338: stxdw [r6 + 0x10], r3
039340: stxdw [r6 + 0x8], r4
039348: ja -0xe0 ; branch 0x38c50
039350: jne r4, 0x0, -0x1b ; branch 0x39280
039358: mov64 r3, r1
039360: lddw r1, 0x300007ff7
039370: mov64 r4, r8
039378: jne r2, 0x0, -0x1c ; branch 0x392a0
039380: ja -0x1c ; branch 0x392a8
039388: mov64 r1, 0xbbd
039390: call 0xc24a ; call 0x9a5e8
039398: mov64 r2, r1
0393a0: jne r0, 0x2, +0x55 ; branch 0x39650
0393a8: stxdw [r10 - 0x578], r2
0393b0: mov64 r1, 0xbbd
0393b8: call 0xc245 ; call 0x9a5e8
0393c0: mov64 r2, r1
0393c8: jne r0, 0x2, +0x7 ; branch 0x39408
0393d0: stxdw [r10 - 0x580], r2
0393d8: mov64 r1, 0xbbd
0393e0: call 0xc240 ; call 0x9a5e8
0393e8: mov64 r2, r1
0393f0: jne r0, 0x2, +0x12 ; branch 0x39488
0393f8: stxdw [r10 - 0x588], r2
039400: ja +0x17 ; branch 0x394c0
039408: mov64 r1, r0
039410: lddw r3, 0xadbee ; rodata b'pump_programpump_event_authoritymayhem-statebonding-curveaccountwsol_mintfe'
039420: mov64 r4, 0xc
039428: call -0x6ae4 ; call 0x3d10
039430: jne r0, 0x2, +0x2af ; branch 0x3a9b0
039438: stxdw [r10 - 0x580], r1
039440: ldxdw r1, [r8 + 0x8]
039448: jeq r1, 0x0, -0xf ; branch 0x393d8
039450: add64 r1, -0x1
039458: stxdw [r8 + 0x8], r1
039460: ldxdw r1, [r8 + 0x0]
039468: stxdw [r10 - 0x588], r1
039470: add64 r1, 0x30
039478: stxdw [r8 + 0x0], r1
039480: ja +0x7 ; branch 0x394c0
039488: mov64 r1, r0
039490: lddw r3, 0xadbfa ; rodata b'pump_event_authoritymayhem-statebonding-curveaccountwsol_mintfee_recipientf'
0394a0: mov64 r4, 0x14
0394a8: call -0x6af4 ; call 0x3d10
0394b0: jne r0, 0x2, +0x29f ; branch 0x3a9b0
0394b8: stxdw [r10 - 0x588], r1
0394c0: mov64 r1, r10
0394c8: add64 r1, -0x1b0
0394d0: mov64 r5, r10
0394d8: mov64 r3, r8
0394e0: call -0x5e21 ; call 0xa3e0
0394e8: ldxdw r2, [r10 - 0x1a8]
0394f0: ldxdw r1, [r10 - 0x1b0]
0394f8: jne r1, 0x2, +0x2 ; branch 0x39510
039500: stxdw [r10 - 0x590], r2
039508: ja +0x6 ; branch 0x39540
039510: lddw r3, 0xadaf4 ; rodata b'system_programglobal-paramsglobal_paramsprograms/mayhem-program/src/instruc'
039520: mov64 r4, 0xe
039528: call -0x6b04 ; call 0x3d10
039530: jne r0, 0x2, +0x28f ; branch 0x3a9b0
039538: stxdw [r10 - 0x590], r1
039540: mov64 r1, r10
039548: add64 r1, -0x1a0
039550: mov64 r5, r10
039558: mov64 r3, r8
039560: call -0x7289 ; call 0x120
039568: ldxdw r2, [r10 - 0x198]
039570: ldxdw r1, [r10 - 0x1a0]
039578: jeq r1, 0x2, +0x6 ; branch 0x395b0
039580: lddw r3, 0xadb89 ; rodata b'token_programassociated_token_programadmin_quote_atamayhem_statemayhem_toke'
039590: mov64 r4, 0xd
039598: call -0x6b12 ; call 0x3d10
0395a0: mov64 r2, r1
0395a8: jne r0, 0x2, +0x2a ; branch 0x39700
0395b0: stxdw [r10 - 0x598], r2
0395b8: ldxdw r3, [r8 + 0x8]
0395c0: jeq r3, 0x0, +0x1b ; branch 0x396a0
0395c8: ldxdw r1, [r8 + 0x0]
0395d0: mov64 r2, r1
0395d8: add64 r2, 0x30
0395e0: stxdw [r8 + 0x0], r2
0395e8: add64 r3, -0x1
0395f0: stxdw [r8 + 0x8], r3
0395f8: stxdw [r10 - 0x5a0], r1
039600: jeq r3, 0x0, +0x18 ; branch 0x396c8
039608: stxdw [r10 - 0x5a8], r7
039610: add64 r3, -0x1
039618: stxdw [r8 + 0x8], r3
039620: ldxdw r1, [r8 + 0x0]
039628: stxdw [r10 - 0x5b0], r1
039630: add64 r1, 0x30
039638: stxdw [r8 + 0x0], r1
039640: ldxdw r8, [r10 - 0x4e8]
039648: ja +0x20 ; branch 0x39750
039650: mov64 r1, r0
039658: lddw r3, 0xadbe8 ; rodata b'globalpump_programpump_event_authoritymayhem-statebonding-curveaccountwsol_'
039668: mov64 r4, 0x6
039670: call -0x6b2d ; call 0x3d10
039678: jne r0, 0x2, +0x266 ; branch 0x3a9b0
039680: stxdw [r10 - 0x578], r1
039688: ldxdw r1, [r8 + 0x8]
039690: jne r1, 0x0, -0x98 ; branch 0x391d8
039698: ja -0x5e ; branch 0x393b0
0396a0: mov64 r1, 0xbbd
0396a8: call 0xc1e7 ; call 0x9a5e8
0396b0: mov64 r2, r1
0396b8: jne r0, 0x2, +0x6e ; branch 0x39a30
0396c0: stxdw [r10 - 0x5a0], r2
0396c8: mov64 r1, 0xbbd
0396d0: call 0xc1e2 ; call 0x9a5e8
0396d8: mov64 r2, r1
0396e0: ldxdw r8, [r10 - 0x4e8]
0396e8: jne r0, 0x2, +0x4 ; branch 0x39710
0396f0: stxdw [r10 - 0x5b0], r2
0396f8: ja +0x9 ; branch 0x39748
039700: stxdw [r6 + 0x10], r2
039708: ja +0x255 ; branch 0x3a9b8
039710: mov64 r1, r0
039718: lddw r3, 0xadb5c ; rodata b'programsol_vaultquote_mintsol_vault_quote_atatoken_programassociated_token_'
039728: mov64 r4, 0x7
039730: call -0x6b45 ; call 0x3d10
039738: jne r0, 0x2, +0x24e ; branch 0x3a9b0
039740: stxdw [r10 - 0x5b0], r1
039748: stxdw [r10 - 0x5a8], r7
039750: lddw r1, 0xb1340 ; rodata b'\x00\x00\x00\x00\x88\xca\n\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00'
039760: ldxdw r2, [r1 + 0x18]
039768: stxdw [r10 - 0x40], r2
039770: ldxdw r2, [r1 + 0x10]
039778: stxdw [r10 - 0x48], r2
039780: ldxdw r2, [r1 + 0x8]
039788: stxdw [r10 - 0x50], r2
039790: ldxdw r1, [r1 + 0x0]
039798: stxdw [r10 - 0x58], r1
0397a0: stdw [r10 - 0x38], 0x0
0397a8: stdw [r10 - 0x30], 0x0
0397b0: mov64 r7, r10
0397b8: add64 r7, -0x190
0397c0: mov64 r2, r10
0397c8: add64 r2, -0x58
0397d0: mov64 r1, r7
0397d8: mov64 r3, 0x30
0397e0: call 0xe1b4 ; call 0xaa588
0397e8: ldxdw r1, [r8 + 0x0]
0397f0: ldxdw r2, [r1 + 0x18]
0397f8: stxdw [r10 - 0x148], r2
039800: ldxdw r2, [r1 + 0x10]
039808: stxdw [r10 - 0x150], r2
039810: ldxdw r2, [r1 + 0x8]
039818: stxdw [r10 - 0x158], r2
039820: ldxdw r1, [r1 + 0x0]
039828: stxdw [r10 - 0x160], r1
039830: mov64 r2, r10
039838: add64 r2, -0x160
039840: mov64 r1, r7
039848: call -0x5d9c ; call 0xab70
039850: jeq r0, 0x0, +0x8 ; branch 0x39898
039858: mov64 r1, 0x7f8
039860: call 0xc1b0 ; call 0x9a5e8
039868: mov64 r2, r1
039870: mov64 r1, r0
039878: lddw r3, 0xadbbd ; rodata b'mayhem_statemayhem_token_vaultbonding_curveglobalpump_programpump_event_aut'
039888: mov64 r4, 0xc
039890: ja +0x2f ; branch 0x39a10
039898: ldxdw r7, [r10 - 0x508]
0398a0: ldxdw r1, [r7 + 0x0]
0398a8: ldxdw r2, [r1 + 0x18]
0398b0: stxdw [r10 - 0x128], r2
0398b8: ldxdw r2, [r1 + 0x10]
0398c0: stxdw [r10 - 0x130], r2
0398c8: ldxdw r2, [r1 + 0x8]
0398d0: stxdw [r10 - 0x138], r2
0398d8: ldxdw r1, [r1 + 0x0]
0398e0: stxdw [r10 - 0x140], r1
0398e8: mov64 r1, r10
0398f0: add64 r1, -0x190
0398f8: mov64 r2, r10
039900: add64 r2, -0x140
039908: call -0x5db4 ; call 0xab70
039910: jeq r0, 0x0, +0x8 ; branch 0x39958
039918: mov64 r1, 0x7f8
039920: call 0xc198 ; call 0x9a5e8
039928: mov64 r2, r1
039930: mov64 r1, r0
039938: lddw r3, 0xad0bc ; rodata b'mintInvalid bool representation: Error\x00\x00\x00\x00\x00\x00The given account is not mutabl'
039948: mov64 r4, 0x4
039950: ja +0x17 ; branch 0x39a10
039958: ldxdw r1, [r10 - 0x538]
039960: ldxdw r1, [r1 + 0x0]
039968: ldxdw r2, [r1 + 0x18]
039970: stxdw [r10 - 0x108], r2
039978: ldxdw r2, [r1 + 0x10]
039980: stxdw [r10 - 0x110], r2
039988: ldxdw r2, [r1 + 0x8]
039990: stxdw [r10 - 0x118], r2
039998: ldxdw r1, [r1 + 0x0]
0399a0: stxdw [r10 - 0x120], r1
0399a8: mov64 r1, r10
0399b0: add64 r1, -0x190
0399b8: mov64 r2, r10
0399c0: add64 r2, -0x120
0399c8: call -0x5dcc ; call 0xab70
0399d0: jeq r0, 0x0, +0x15 ; branch 0x39a80
0399d8: mov64 r1, 0x7f8
0399e0: call 0xc180 ; call 0x9a5e8
0399e8: mov64 r2, r1
0399f0: mov64 r1, r0
0399f8: lddw r3, 0xadbc9 ; rodata b'mayhem_token_vaultbonding_curveglobalpump_programpump_event_authoritymayhem'
039a08: mov64 r4, 0x12
039a10: call -0x6ba1 ; call 0x3d10
039a18: stxdw [r6 + 0x8], r0
039a20: stxdw [r6 + 0x10], r1
039a28: ja -0x1bc ; branch 0x38c50
039a30: mov64 r1, r0
039a38: lddw r3, 0xadb4d ; rodata b'event_authorityprogramsol_vaultquote_mintsol_vault_quote_atatoken_programas'
039a48: mov64 r4, 0xf
039a50: call -0x6ba9 ; call 0x3d10
039a58: jne r0, 0x2, +0x1ea ; branch 0x3a9b0
039a60: ldxdw r3, [r8 + 0x8]
039a68: stxdw [r10 - 0x5a0], r1
039a70: jne r3, 0x0, -0x8e ; branch 0x39608
039a78: ja -0x77 ; branch 0x396c8
039a80: ldxdw r1, [r10 - 0x570]
039a88: ldxdw r1, [r1 + 0x0]
039a90: ldxdw r1, [r1 + 0x0]
039a98: ldxdw r2, [r1 + 0x18]
039aa0: stxdw [r10 - 0xe8], r2
039aa8: ldxdw r2, [r1 + 0x10]
039ab0: stxdw [r10 - 0xf0], r2
039ab8: ldxdw r2, [r1 + 0x8]
039ac0: stxdw [r10 - 0xf8], r2
039ac8: ldxdw r1, [r1 + 0x0]
039ad0: stxdw [r10 - 0x100], r1
039ad8: mov64 r1, r10
039ae0: add64 r1, -0x190
039ae8: mov64 r2, r10
039af0: add64 r2, -0x100
039af8: call -0x5df2 ; call 0xab70
039b00: jeq r0, 0x0, +0x9 ; branch 0x39b50
039b08: mov64 r1, 0x7f8
039b10: call 0xc15a ; call 0x9a5e8
039b18: mov64 r2, r1
039b20: mov64 r1, r0
039b28: lddw r3, 0xadbdb ; rodata b'bonding_curveglobalpump_programpump_event_authoritymayhem-statebonding-curv'
039b38: mov64 r4, 0xd
039b40: call -0x6bc7 ; call 0x3d10
039b48: ja +0x1cc ; branch 0x3a9b0
039b50: ldxdw r1, [r7 + 0x0]
039b58: ldxdw r2, [r1 + 0x18]
039b60: stxdw [r10 - 0x178], r2
039b68: ldxdw r2, [r1 + 0x10]
039b70: stxdw [r10 - 0x180], r2
039b78: ldxdw r2, [r1 + 0x8]
039b80: stxdw [r10 - 0x188], r2
039b88: ldxdw r1, [r1 + 0x0]
039b90: stxdw [r10 - 0x190], r1
039b98: mov64 r1, r10
039ba0: add64 r1, -0x190
039ba8: stxdw [r10 - 0x70], r1
039bb0: lddw r1, 0xadc0e ; rodata b'mayhem-statebonding-curveaccountwsol_mintfee_recipientfee_recipient_atatrad'
039bc0: stxdw [r10 - 0x80], r1
039bc8: stdw [r10 - 0x68], 0x20
039bd0: stdw [r10 - 0x78], 0xc
039bd8: stb [r10 - 0xa0], 0xff
039be0: mov64 r1, r10
039be8: add64 r1, -0x80
039bf0: mov64 r4, r10
039bf8: add64 r4, -0x58
039c00: mov64 r5, r10
039c08: add64 r5, -0xa0
039c10: mov64 r2, 0x2
039c18: ldxdw r3, [r10 - 0x4f0]
039c20: call -0x1
039c28: jne r0, 0x0, +0x1ed ; branch 0x3ab98
039c30: ldxdw r4, [r10 - 0x40]
039c38: ldxdw r3, [r10 - 0x48]
039c40: ldxdw r8, [r10 - 0x50]
039c48: ldxdw r7, [r10 - 0x58]
039c50: ldxb r1, [r10 - 0xa0]
039c58: ldxdw r2, [r10 - 0x510]
039c60: stxb [r2 + 0x0], r1
039c68: ldxdw r1, [r10 - 0x4e8]
039c70: ldxdw r1, [r1 + 0x0]
039c78: ldxdw r2, [r1 + 0x0]
039c80: jne r2, r7, +0x16f ; branch 0x3a800
039c88: ldxdw r2, [r1 + 0x8]
039c90: jne r2, r8, +0x16d ; branch 0x3a800
039c98: ldxdw r2, [r1 + 0x10]
039ca0: jne r2, r3, +0x16b ; branch 0x3a800
039ca8: ldxdw r1, [r1 + 0x18]
039cb0: jne r1, r4, +0x169 ; branch 0x3a800
039cb8: ldxdw r1, [r10 - 0x4e8]
039cc0: ldxb r1, [r1 + 0x29]
039cc8: jeq r1, 0x0, +0x185 ; branch 0x3a8f8
039cd0: ldxdw r2, [r10 - 0x508]
039cd8: ldxb r1, [r2 + 0x29]
039ce0: jeq r1, 0x0, +0x18b ; branch 0x3a940
039ce8: mov64 r1, r10
039cf0: add64 r1, -0x58
039cf8: call -0x60ee ; call 0x9590
039d00: ldxdw r1, [r10 - 0x40]
039d08: ldxdw r3, [r1 + 0x0]
039d10: ldxdw r2, [r10 - 0x538]
039d18: ldxdw r2, [r2 + 0x18]
039d20: ldxdw r4, [r2 + 0x0]
039d28: jne r4, r3, +0x18b ; branch 0x3a988
039d30: ldxdw r3, [r1 + 0x8]
039d38: ldxdw r4, [r2 + 0x8]
039d40: jne r4, r3, +0x188 ; branch 0x3a988
039d48: ldxdw r3, [r1 + 0x10]
039d50: ldxdw r4, [r2 + 0x10]
039d58: jne r4, r3, +0x185 ; branch 0x3a988
039d60: ldxdw r1, [r1 + 0x18]
039d68: ldxdw r2, [r2 + 0x18]
039d70: jne r2, r1, +0x182 ; branch 0x3a988
039d78: mov64 r1, r10
039d80: add64 r1, -0x58
039d88: call -0x63d6 ; call 0x7ee0
039d90: ldxdw r1, [r10 - 0x568]
039d98: ldxdw r1, [r1 + 0x0]
039da0: ldxdw r2, [r1 + 0x18]
039da8: stxdw [r10 - 0xc8], r2
039db0: ldxdw r2, [r1 + 0x10]
039db8: stxdw [r10 - 0xd0], r2
039dc0: ldxdw r2, [r1 + 0x8]
039dc8: stxdw [r10 - 0xd8], r2
039dd0: ldxdw r1, [r1 + 0x0]
039dd8: stxdw [r10 - 0xe0], r1
039de0: ldxdw r1, [r10 - 0xe0]
039de8: ldxdw r2, [r10 - 0x540]
039df0: jne r2, r1, +0x17a ; branch 0x3a9c8
039df8: ldxdw r1, [r10 - 0xd8]
039e00: ldxdw r2, [r10 - 0x548]
039e08: jne r2, r1, +0x177 ; branch 0x3a9c8
039e10: ldxdw r1, [r10 - 0xd0]
039e18: ldxdw r2, [r10 - 0x550]
039e20: jne r2, r1, +0x174 ; branch 0x3a9c8
039e28: ldxdw r1, [r10 - 0xc8]
039e30: ldxdw r2, [r10 - 0x558]
039e38: jne r2, r1, +0x171 ; branch 0x3a9c8
039e40: ldxdw r2, [r10 - 0x508]
039e48: ldxdw r1, [r2 + 0x0]
039e50: ldxdw r3, [r1 + 0x18]
039e58: stxdw [r10 - 0x68], r3
039e60: ldxdw r3, [r1 + 0x10]
039e68: stxdw [r10 - 0x70], r3
039e70: ldxdw r3, [r1 + 0x8]
039e78: stxdw [r10 - 0x78], r3
039e80: ldxdw r1, [r1 + 0x0]
039e88: stxdw [r10 - 0x80], r1
039e90: mov64 r7, r10
039e98: add64 r7, -0x58
039ea0: mov64 r1, r7
039ea8: call -0x6124 ; call 0x9590
039eb0: ldxdw r1, [r10 - 0x40]
039eb8: ldxdw r2, [r1 + 0x0]
039ec0: stxdw [r10 - 0x190], r2
039ec8: ldxdw r2, [r1 + 0x8]
039ed0: stxdw [r10 - 0x188], r2
039ed8: ldxdw r2, [r1 + 0x10]
039ee0: stxdw [r10 - 0x180], r2
039ee8: ldxdw r1, [r1 + 0x18]
039ef0: stxdw [r10 - 0x178], r1
039ef8: mov64 r1, r10
039f00: add64 r1, -0xc0
039f08: mov64 r2, r10
039f10: add64 r2, -0xe0
039f18: mov64 r3, r10
039f20: add64 r3, -0x80
039f28: mov64 r4, r10
039f30: add64 r4, -0x190
039f38: call 0xb7a8 ; call 0x95c80
039f40: mov64 r1, r7
039f48: call -0x640e ; call 0x7ee0
039f50: ldxdw r1, [r10 - 0x538]
039f58: ldxdw r1, [r1 + 0x0]
039f60: ldxdw r2, [r1 + 0x18]
039f68: stxdw [r10 - 0x5c0], r2
039f70: ldxdw r2, [r1 + 0x10]
039f78: stxdw [r10 - 0x5b8], r2
039f80: ldxdw r8, [r1 + 0x8]
039f88: ldxdw r7, [r1 + 0x0]
039f90: ldxdw r1, [r10 - 0xc0]
039f98: jne r7, r1, +0x15e ; branch 0x3aa90
039fa0: ldxdw r1, [r10 - 0xb8]
039fa8: jne r8, r1, +0x15c ; branch 0x3aa90
039fb0: ldxdw r1, [r10 - 0xb0]
039fb8: ldxdw r2, [r10 - 0x5b8]
039fc0: jne r2, r1, +0x159 ; branch 0x3aa90
039fc8: ldxdw r1, [r10 - 0xa8]
039fd0: ldxdw r2, [r10 - 0x5c0]
039fd8: jne r2, r1, +0x156 ; branch 0x3aa90
039fe0: ldxdw r1, [r10 - 0x538]
039fe8: ldxb r1, [r1 + 0x29]
039ff0: jeq r1, 0x0, +0x16b ; branch 0x3ab50
039ff8: stb [r10 - 0x190], 0xff
03a000: mov64 r4, r10
03a008: add64 r4, -0x58
03a010: mov64 r5, r10
03a018: add64 r5, -0x190
03a020: lddw r1, 0xb1988 ; rodata b'\x00\x00\x00\x00\xa9\xd4\n\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00\n\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xe4\xca\n\x00;\x00\x00\x00\x00\x00\x00\x00\x1b\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00{\xce\n\x00;\x00\x00'
03a030: mov64 r2, 0x1
03a038: ldxdw r3, [r10 - 0x4f0]
03a040: call -0x1
03a048: jne r0, 0x0, +0x169 ; branch 0x3ab98
03a050: ldxdw r1, [r10 - 0x40]
03a058: stxdw [r10 - 0x5c0], r1
03a060: ldxdw r1, [r10 - 0x48]
03a068: stxdw [r10 - 0x5b8], r1
03a070: ldxdw r8, [r10 - 0x50]
03a078: ldxdw r7, [r10 - 0x58]
03a080: ldxb r1, [r10 - 0x190]
03a088: ldxdw r2, [r10 - 0x510]
03a090: stxb [r2 + 0x1], r1
03a098: ldxdw r1, [r10 - 0x568]
03a0a0: ldxdw r1, [r1 + 0x0]
03a0a8: ldxdw r2, [r1 + 0x0]
03a0b0: jne r2, r7, +0x168 ; branch 0x3abf8
03a0b8: ldxdw r2, [r1 + 0x8]
03a0c0: jne r2, r8, +0x166 ; branch 0x3abf8
03a0c8: ldxdw r2, [r1 + 0x10]
03a0d0: ldxdw r3, [r10 - 0x5b8]
03a0d8: jne r2, r3, +0x163 ; branch 0x3abf8
03a0e0: ldxdw r1, [r1 + 0x18]
03a0e8: ldxdw r2, [r10 - 0x5c0]
03a0f0: jne r1, r2, +0x160 ; branch 0x3abf8
03a0f8: ldxdw r1, [r10 - 0x568]
03a100: ldxb r1, [r1 + 0x29]
03a108: jeq r1, 0x0, +0x174 ; branch 0x3acb0
03a110: ldxdw r1, [r10 - 0x508]
03a118: ldxdw r1, [r1 + 0x0]
03a120: ldxdw r2, [r1 + 0x18]
03a128: stxdw [r10 - 0x68], r2
03a130: ldxdw r2, [r1 + 0x10]
03a138: stxdw [r10 - 0x70], r2
03a140: ldxdw r2, [r1 + 0x8]
03a148: stxdw [r10 - 0x78], r2
03a150: ldxdw r1, [r1 + 0x0]
03a158: stxdw [r10 - 0x80], r1
03a160: mov64 r1, r10
03a168: add64 r1, -0x80
03a170: stxdw [r10 - 0x90], r1
03a178: lddw r1, 0xadc1a ; rodata b'bonding-curveaccountwsol_mintfee_recipientfee_recipient_atatraderquote_toke'
03a188: stxdw [r10 - 0xa0], r1
03a190: stdw [r10 - 0x88], 0x20
03a198: stdw [r10 - 0x98], 0xd
03a1a0: lddw r1, -0x4fe7920249d4a29b
03a1b0: stxdw [r10 - 0x178], r1
03a1b8: lddw r1, 0x3bffd2f597cb8951
03a1c8: stxdw [r10 - 0x180], r1
03a1d0: lddw r1, -0x55a4e84097ea24bc
03a1e0: stxdw [r10 - 0x188], r1
03a1e8: lddw r1, -0x30a5996c091fa9ff
03a1f8: stxdw [r10 - 0x190], r1
03a200: stb [r10 - 0x59], 0xff
03a208: mov64 r1, r10
03a210: add64 r1, -0xa0
03a218: mov64 r3, r10
03a220: add64 r3, -0x190
03a228: mov64 r4, r10
03a230: add64 r4, -0x58
03a238: mov64 r5, r10
03a240: add64 r5, -0x59
03a248: mov64 r2, 0x2
03a250: call -0x1
03a258: jne r0, 0x0, +0x127 ; branch 0x3ab98
03a260: ldxdw r1, [r10 - 0x40]
03a268: stxdw [r10 - 0x5c0], r1
03a270: ldxdw r1, [r10 - 0x48]
03a278: stxdw [r10 - 0x5b8], r1
03a280: ldxdw r7, [r10 - 0x50]
03a288: ldxdw r8, [r10 - 0x58]
03a290: ldxb r1, [r10 - 0x59]
03a298: ldxdw r2, [r10 - 0x510]
03a2a0: stxb [r2 + 0x2], r1
03a2a8: ldxdw r1, [r10 - 0x570]
03a2b0: ldxdw r1, [r1 + 0x0]
03a2b8: ldxdw r2, [r1 + 0x0]
03a2c0: ldxdw r3, [r2 + 0x0]
03a2c8: jne r3, r8, +0x14a ; branch 0x3ad20
03a2d0: ldxdw r3, [r2 + 0x8]
03a2d8: jne r3, r7, +0x148 ; branch 0x3ad20
03a2e0: ldxdw r3, [r2 + 0x10]
03a2e8: ldxdw r4, [r10 - 0x5b8]
03a2f0: jne r3, r4, +0x145 ; branch 0x3ad20
03a2f8: ldxdw r2, [r2 + 0x18]
03a300: ldxdw r3, [r10 - 0x5c0]
03a308: jne r2, r3, +0x142 ; branch 0x3ad20
03a310: ldxb r1, [r1 + 0x29]
03a318: jeq r1, 0x0, +0x15b ; branch 0x3adf8
03a320: ldxdw r1, [r10 - 0x580]
03a328: ldxdw r1, [r1 + 0x0]
03a330: ldxdw r2, [r1 + 0x18]
03a338: stxdw [r10 - 0x5c0], r2
03a340: ldxdw r2, [r1 + 0x10]
03a348: stxdw [r10 - 0x5b8], r2
03a350: ldxdw r8, [r1 + 0x8]
03a358: ldxdw r7, [r1 + 0x0]
03a360: lddw r1, -0x30a5996c091fa9ff
03a370: jne r7, r1, +0x152 ; branch 0x3ae08
03a378: lddw r1, -0x55a4e84097ea24bc
03a388: jne r8, r1, +0x14f ; branch 0x3ae08
03a390: lddw r1, 0x3bffd2f597cb8951
03a3a0: ldxdw r2, [r10 - 0x5b8]
03a3a8: jne r2, r1, +0x14b ; branch 0x3ae08
03a3b0: lddw r1, -0x4fe7920249d4a29b
03a3c0: ldxdw r2, [r10 - 0x5c0]
03a3c8: jne r2, r1, +0x147 ; branch 0x3ae08
03a3d0: stb [r10 - 0x190], 0xff
03a3d8: mov64 r4, r10
03a3e0: add64 r4, -0x58
03a3e8: mov64 r5, r10
03a3f0: add64 r5, -0x190
03a3f8: lddw r1, 0xb1978 ; rodata b'\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xa9\xd4\n\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00;\xcb\n\x001\x00\x00\x00\x00\x00\x00\x00\n\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xe4\xca\n\x00;\x00\x00\x00\x00\x00\x00\x00\x1b\x00\x00'
03a408: mov64 r2, 0x1
03a410: ldxdw r3, [r10 - 0x4f0]
03a418: call -0x1
03a420: jne r0, 0x0, +0xee ; branch 0x3ab98
03a428: ldxdw r1, [r10 - 0x40]
03a430: stxdw [r10 - 0x5b8], r1
03a438: ldxdw r1, [r10 - 0x48]
03a440: stxdw [r10 - 0x4f0], r1
03a448: ldxdw r8, [r10 - 0x50]
03a450: ldxdw r7, [r10 - 0x58]
03a458: ldxb r1, [r10 - 0x190]
03a460: ldxdw r2, [r10 - 0x510]
03a468: stxb [r2 + 0x3], r1
03a470: ldxdw r1, [r10 - 0x5a0]
03a478: ldxdw r1, [r1 + 0x0]
03a480: ldxdw r2, [r1 + 0x0]
03a488: jne r2, r7, +0x14f ; branch 0x3af08
03a490: ldxdw r2, [r1 + 0x8]
03a498: jne r2, r8, +0x14d ; branch 0x3af08
03a4a0: ldxdw r2, [r1 + 0x10]
03a4a8: ldxdw r3, [r10 - 0x4f0]
03a4b0: jne r2, r3, +0x14a ; branch 0x3af08
03a4b8: ldxdw r1, [r1 + 0x18]
03a4c0: ldxdw r2, [r10 - 0x5b8]
03a4c8: jne r1, r2, +0x147 ; branch 0x3af08
03a4d0: mov64 r1, r6
03a4d8: add64 r1, 0x168
03a4e0: mov64 r2, r10
03a4e8: add64 r2, -0x468
03a4f0: mov64 r3, 0x59
03a4f8: call 0xe011 ; call 0xaa588
03a500: ldxw r1, [r10 - 0x470]
03a508: stxw [r6 + 0x1c2], r1
03a510: ldxh r1, [r10 - 0x46c]
03a518: stxh [r6 + 0x1c6], r1
03a520: mov64 r1, r6
03a528: add64 r1, 0x18
03a530: mov64 r2, r10
03a538: add64 r2, -0x368
03a540: mov64 r3, 0x40
03a548: call 0xe007 ; call 0xaa588
03a550: ldxdw r1, [r10 - 0x370]
03a558: stxdw [r6 + 0x78], r1
03a560: ldxdw r1, [r10 - 0x378]
03a568: stxdw [r6 + 0x70], r1
03a570: ldxdw r1, [r10 - 0x380]
03a578: stxdw [r6 + 0x68], r1
03a580: ldxdw r1, [r10 - 0x388]
03a588: stxdw [r6 + 0x60], r1
03a590: ldxdw r1, [r10 - 0x1c0]
03a598: stxdw [r6 + 0x90], r1
03a5a0: ldxdw r1, [r10 - 0x1b8]
03a5a8: stxdw [r6 + 0x98], r1
03a5b0: ldxdw r1, [r10 - 0x1d8]
03a5b8: stxdw [r6 + 0xb0], r1
03a5c0: ldxdw r1, [r10 - 0x1c8]
03a5c8: stxdw [r6 + 0xc0], r1
03a5d0: ldxdw r1, [r10 - 0x1e0]
03a5d8: stxdw [r6 + 0xa8], r1
03a5e0: ldxdw r1, [r10 - 0x1d0]
03a5e8: stxdw [r6 + 0xb8], r1
03a5f0: mov64 r1, r6
03a5f8: add64 r1, 0xe8
03a600: mov64 r2, r10
03a608: add64 r2, -0x228
03a610: mov64 r3, 0x48
03a618: call 0xdfed ; call 0xaa588
03a620: ldxw r1, [r10 - 0x230]
03a628: ldxdw r2, [r10 - 0x238]
03a630: ldxdw r3, [r10 - 0x240]
03a638: ldxdw r4, [r10 - 0x248]
03a640: ldxdw r5, [r10 - 0x250]
03a648: ldxdw r0, [r10 - 0x528]
03a650: stxw [r6 + 0x0], r0
03a658: ldxdw r0, [r10 - 0x530]
03a660: stxw [r6 + 0x4], r0
03a668: ldxdw r0, [r10 - 0x560]
03a670: stxw [r6 + 0x130], r0
03a678: ldxdw r0, [r10 - 0x4f8]
03a680: stxb [r6 + 0x1c1], r0
03a688: ldxdw r0, [r10 - 0x5b0]
03a690: stxdw [r6 + 0x208], r0
03a698: ldxdw r0, [r10 - 0x5a0]
03a6a0: stxdw [r6 + 0x200], r0
03a6a8: ldxdw r0, [r10 - 0x598]
03a6b0: stxdw [r6 + 0x1f8], r0
03a6b8: ldxdw r0, [r10 - 0x590]
03a6c0: stxdw [r6 + 0x1f0], r0
03a6c8: ldxdw r0, [r10 - 0x588]
03a6d0: stxdw [r6 + 0x1e8], r0
03a6d8: ldxdw r0, [r10 - 0x580]
03a6e0: stxdw [r6 + 0x1e0], r0
03a6e8: ldxdw r0, [r10 - 0x578]
03a6f0: stxdw [r6 + 0x1d8], r0
03a6f8: ldxdw r0, [r10 - 0x570]
03a700: stxdw [r6 + 0x1d0], r0
03a708: ldxdw r0, [r10 - 0x568]
03a710: stxdw [r6 + 0x1c8], r0
03a718: stxdw [r6 + 0x160], r9
03a720: ldxdw r0, [r10 - 0x4e8]
03a728: stxdw [r6 + 0x158], r0
03a730: ldxdw r0, [r10 - 0x558]
03a738: stxdw [r6 + 0xe0], r0
03a740: ldxdw r0, [r10 - 0x550]
03a748: stxdw [r6 + 0xd8], r0
03a750: ldxdw r0, [r10 - 0x548]
03a758: stxdw [r6 + 0xd0], r0
03a760: ldxdw r0, [r10 - 0x540]
03a768: stxdw [r6 + 0xc8], r0
03a770: ldxdw r0, [r10 - 0x538]
03a778: stxdw [r6 + 0xa0], r0
03a780: ldxdw r0, [r10 - 0x500]
03a788: stxdw [r6 + 0x88], r0
03a790: ldxdw r0, [r10 - 0x5a8]
03a798: stxdw [r6 + 0x80], r0
03a7a0: ldxdw r0, [r10 - 0x508]
03a7a8: stxdw [r6 + 0x58], r0
03a7b0: ldxdw r0, [r10 - 0x520]
03a7b8: stxdw [r6 + 0x10], r0
03a7c0: ldxdw r0, [r10 - 0x518]
03a7c8: stxdw [r6 + 0x8], r0
03a7d0: stxdw [r6 + 0x134], r5
03a7d8: stxdw [r6 + 0x13c], r4
03a7e0: stxdw [r6 + 0x144], r3
03a7e8: stxdw [r6 + 0x14c], r2
03a7f0: stxw [r6 + 0x154], r1
03a7f8: ja -0x375 ; branch 0x38c58
03a800: mov64 r1, 0x7d6
03a808: stxdw [r10 - 0x4f0], r3
03a810: mov64 r9, r4
03a818: call 0xbfb9 ; call 0x9a5e8
03a820: mov64 r2, r1
03a828: mov64 r1, r0
03a830: lddw r3, 0xadbbd ; rodata b'mayhem_statemayhem_token_vaultbonding_curveglobalpump_programpump_event_aut'
03a840: mov64 r4, 0xc
03a848: call -0x6d68 ; call 0x3d10
03a850: mov64 r2, r1
03a858: ldxdw r1, [r10 - 0x4e8]
03a860: ldxdw r1, [r1 + 0x0]
03a868: ldxdw r3, [r1 + 0x18]
03a870: stxdw [r10 - 0x40], r3
03a878: ldxdw r3, [r1 + 0x10]
03a880: stxdw [r10 - 0x48], r3
03a888: ldxdw r3, [r1 + 0x8]
03a890: stxdw [r10 - 0x50], r3
03a898: ldxdw r1, [r1 + 0x0]
03a8a0: stxdw [r10 - 0x58], r1
03a8a8: stxdw [r10 - 0x20], r9
03a8b0: ldxdw r1, [r10 - 0x4f0]
03a8b8: stxdw [r10 - 0x28], r1
03a8c0: stxdw [r10 - 0x30], r8
03a8c8: stxdw [r10 - 0x38], r7
03a8d0: mov64 r3, r10
03a8d8: add64 r3, -0x58
03a8e0: mov64 r1, r0
03a8e8: call 0xba21 ; call 0x979f8
03a8f0: ja +0x17 ; branch 0x3a9b0
03a8f8: mov64 r1, 0x7d0
03a900: call 0xbf9c ; call 0x9a5e8
03a908: mov64 r2, r1
03a910: mov64 r1, r0
03a918: lddw r3, 0xadbbd ; rodata b'mayhem_statemayhem_token_vaultbonding_curveglobalpump_programpump_event_aut'
03a928: mov64 r4, 0xc
03a930: call -0x6d85 ; call 0x3d10
03a938: ja +0xe ; branch 0x3a9b0
03a940: mov64 r1, 0x7d0
03a948: call 0xbf93 ; call 0x9a5e8
03a950: mov64 r2, r1
03a958: mov64 r1, r0
03a960: lddw r3, 0xad0bc ; rodata b'mintInvalid bool representation: Error\x00\x00\x00\x00\x00\x00The given account is not mutabl'
03a970: mov64 r4, 0x4
03a978: call -0x6d8e ; call 0x3d10
03a980: ja +0x5 ; branch 0x3a9b0
03a988: mov64 r1, r10
03a990: add64 r1, -0x58
03a998: call -0x6558 ; call 0x7ee0
03a9a0: mov64 r1, 0x7e7
03a9a8: call 0xbf87 ; call 0x9a5e8
03a9b0: stxdw [r6 + 0x10], r1
03a9b8: stxdw [r6 + 0x8], r0
03a9c0: ja -0x3af ; branch 0x38c50
03a9c8: mov64 r1, 0x7df
03a9d0: call 0xbf82 ; call 0x9a5e8
03a9d8: mov64 r2, r1
03a9e0: mov64 r1, r0
03a9e8: lddw r3, 0xadbc9 ; rodata b'mayhem_token_vaultbonding_curveglobalpump_programpump_event_authoritymayhem'
03a9f8: mov64 r4, 0x12
03aa00: call -0x6d9f ; call 0x3d10
03aa08: mov64 r2, r1
03aa10: ldxdw r1, [r10 - 0x558]
03aa18: stxdw [r10 - 0x40], r1
03aa20: ldxdw r1, [r10 - 0x550]
03aa28: stxdw [r10 - 0x48], r1
03aa30: ldxdw r1, [r10 - 0x548]
03aa38: stxdw [r10 - 0x50], r1
03aa40: ldxdw r1, [r10 - 0x540]
03aa48: stxdw [r10 - 0x58], r1
03aa50: ldxdw r1, [r10 - 0xe0]
03aa58: stxdw [r10 - 0x38], r1
03aa60: ldxdw r1, [r10 - 0xd8]
03aa68: stxdw [r10 - 0x30], r1
03aa70: ldxdw r1, [r10 - 0xd0]
03aa78: stxdw [r10 - 0x28], r1
03aa80: ldxdw r1, [r10 - 0xc8]
03aa88: ja +0x16 ; branch 0x3ab40
03aa90: mov64 r1, 0x7d9
03aa98: call 0xbf69 ; call 0x9a5e8
03aaa0: mov64 r2, r1
03aaa8: mov64 r1, r0
03aab0: lddw r3, 0xadbc9 ; rodata b'mayhem_token_vaultbonding_curveglobalpump_programpump_event_authoritymayhem'
03aac0: mov64 r4, 0x12
03aac8: call -0x6db8 ; call 0x3d10
03aad0: mov64 r2, r1
03aad8: ldxdw r1, [r10 - 0x5c0]
03aae0: stxdw [r10 - 0x40], r1
03aae8: ldxdw r1, [r10 - 0x5b8]
03aaf0: stxdw [r10 - 0x48], r1
03aaf8: stxdw [r10 - 0x50], r8
03ab00: stxdw [r10 - 0x58], r7
03ab08: ldxdw r1, [r10 - 0xc0]
03ab10: stxdw [r10 - 0x38], r1
03ab18: ldxdw r1, [r10 - 0xb8]
03ab20: stxdw [r10 - 0x30], r1
03ab28: ldxdw r1, [r10 - 0xb0]
03ab30: stxdw [r10 - 0x28], r1
03ab38: ldxdw r1, [r10 - 0xa8]
03ab40: stxdw [r10 - 0x20], r1
03ab48: ja -0x50 ; branch 0x3a8d0
03ab50: mov64 r1, 0x7d0
03ab58: call 0xbf51 ; call 0x9a5e8
03ab60: mov64 r2, r1
03ab68: mov64 r1, r0
03ab70: lddw r3, 0xadbc9 ; rodata b'mayhem_token_vaultbonding_curveglobalpump_programpump_event_authoritymayhem'
03ab80: mov64 r4, 0x12
03ab88: call -0x6dd0 ; call 0x3d10
03ab90: ja -0x3d ; branch 0x3a9b0
03ab98: lddw r1, 0xb11f8 ; rodata b'\x00\x00\x00\x00\xcb\xcf\n\x001\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\xcd\n\x00\x10\x00\x00\x00\x00\x00\x00\x00\x17\x01\x00\x00 \x00\x00\x00\x00\x00\x00\x00\xfc\xcf\n\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00'
03aba8: stxdw [r10 - 0x58], r1
03abb0: stdw [r10 - 0x38], 0x0
03abb8: stdw [r10 - 0x50], 0x1
03abc0: stdw [r10 - 0x40], 0x0
03abc8: stdw [r10 - 0x48], 0x8
03abd0: mov64 r1, r10
03abd8: add64 r1, -0x58
03abe0: lddw r2, 0xb1208 ; rodata b'\x00\x00\x00\x00\x08\xcd\n\x00\x10\x00\x00\x00\x00\x00\x00\x00\x17\x01\x00\x00 \x00\x00\x00\x00\x00\x00\x00\xfc\xcf\n\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
03abf0: call 0xd392 ; call 0xa4888
03abf8: mov64 r1, 0x7d6
03ac00: call 0xbf3c ; call 0x9a5e8
03ac08: mov64 r2, r1
03ac10: mov64 r1, r0
03ac18: lddw r3, 0xadb63 ; rodata b'sol_vaultquote_mintsol_vault_quote_atatoken_programassociated_token_program'
03ac28: mov64 r4, 0x9
03ac30: call -0x6de5 ; call 0x3d10
03ac38: mov64 r2, r1
03ac40: ldxdw r1, [r10 - 0x568]
03ac48: ldxdw r1, [r1 + 0x0]
03ac50: ldxdw r3, [r1 + 0x18]
03ac58: stxdw [r10 - 0x40], r3
03ac60: ldxdw r3, [r1 + 0x10]
03ac68: stxdw [r10 - 0x48], r3
03ac70: ldxdw r3, [r1 + 0x8]
03ac78: stxdw [r10 - 0x50], r3
03ac80: ldxdw r1, [r1 + 0x0]
03ac88: stxdw [r10 - 0x58], r1
03ac90: ldxdw r1, [r10 - 0x5c0]
03ac98: stxdw [r10 - 0x20], r1
03aca0: ldxdw r1, [r10 - 0x5b8]
03aca8: ja -0x7f ; branch 0x3a8b8
03acb0: mov64 r1, 0x7d0
03acb8: call 0xbf25 ; call 0x9a5e8
03acc0: mov64 r2, r1
03acc8: mov64 r1, r0
03acd0: lddw r3, 0xadb63 ; rodata b'sol_vaultquote_mintsol_vault_quote_atatoken_programassociated_token_program'
03ace0: mov64 r4, 0x9
03ace8: call -0x6dfc ; call 0x3d10
03acf0: ja -0x69 ; branch 0x3a9b0
03acf8: mov64 r1, 0x1
03ad00: mov64 r2, 0x12
03ad08: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03ad18: call 0xd165 ; call 0xa3848
03ad20: mov64 r1, 0x7d6
03ad28: call 0xbf17 ; call 0x9a5e8
03ad30: mov64 r2, r1
03ad38: mov64 r1, r0
03ad40: lddw r3, 0xadbdb ; rodata b'bonding_curveglobalpump_programpump_event_authoritymayhem-statebonding-curv'
03ad50: mov64 r4, 0xd
03ad58: call -0x6e0a ; call 0x3d10
03ad60: mov64 r2, r1
03ad68: ldxdw r1, [r10 - 0x570]
03ad70: ldxdw r1, [r1 + 0x0]
03ad78: ldxdw r1, [r1 + 0x0]
03ad80: ldxdw r3, [r1 + 0x0]
03ad88: ldxdw r4, [r1 + 0x8]
03ad90: ldxdw r5, [r1 + 0x10]
03ad98: ldxdw r1, [r1 + 0x18]
03ada0: stxdw [r10 - 0x38], r8
03ada8: stxdw [r10 - 0x30], r7
03adb0: ldxdw r7, [r10 - 0x5b8]
03adb8: stxdw [r10 - 0x28], r7
03adc0: ldxdw r7, [r10 - 0x5c0]
03adc8: stxdw [r10 - 0x20], r7
03add0: stxdw [r10 - 0x40], r1
03add8: stxdw [r10 - 0x48], r5
03ade0: stxdw [r10 - 0x50], r4
03ade8: stxdw [r10 - 0x58], r3
03adf0: ja -0xa5 ; branch 0x3a8d0
03adf8: mov64 r1, 0x7d0
03ae00: ja -0x25f ; branch 0x39b10
03ae08: mov64 r1, 0x7dc
03ae10: call 0xbefa ; call 0x9a5e8
03ae18: mov64 r2, r1
03ae20: mov64 r1, r0
03ae28: lddw r3, 0xadbee ; rodata b'pump_programpump_event_authoritymayhem-statebonding-curveaccountwsol_mintfe'
03ae38: mov64 r4, 0xc
03ae40: call -0x6e27 ; call 0x3d10
03ae48: mov64 r2, r1
03ae50: lddw r1, -0x30a5996c091fa9ff
03ae60: stxdw [r10 - 0x38], r1
03ae68: ldxdw r1, [r10 - 0x5c0]
03ae70: stxdw [r10 - 0x40], r1
03ae78: ldxdw r1, [r10 - 0x5b8]
03ae80: stxdw [r10 - 0x48], r1
03ae88: stxdw [r10 - 0x50], r8
03ae90: stxdw [r10 - 0x58], r7
03ae98: lddw r1, -0x55a4e84097ea24bc
03aea8: stxdw [r10 - 0x30], r1
03aeb0: lddw r1, 0x3bffd2f597cb8951
03aec0: stxdw [r10 - 0x28], r1
03aec8: lddw r1, -0x4fe7920249d4a29b
03aed8: ja -0x74 ; branch 0x3ab40
03aee0: mov64 r1, 0x1
03aee8: mov64 r2, 0x9
03aef0: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03af00: call 0xd128 ; call 0xa3848
03af08: mov64 r1, 0x7d6
03af10: call 0xbeda ; call 0x9a5e8
03af18: mov64 r2, r1
03af20: mov64 r1, r0
03af28: lddw r3, 0xadb4d ; rodata b'event_authorityprogramsol_vaultquote_mintsol_vault_quote_atatoken_programas'
03af38: mov64 r4, 0xf
03af40: call -0x6e47 ; call 0x3d10
03af48: mov64 r2, r1
03af50: ldxdw r1, [r10 - 0x5a0]
03af58: ldxdw r1, [r1 + 0x0]
03af60: ldxdw r3, [r1 + 0x18]
03af68: stxdw [r10 - 0x40], r3
03af70: ldxdw r3, [r1 + 0x10]
03af78: stxdw [r10 - 0x48], r3
03af80: ldxdw r3, [r1 + 0x8]
03af88: stxdw [r10 - 0x50], r3
03af90: ldxdw r1, [r1 + 0x0]
03af98: stxdw [r10 - 0x58], r1
03afa0: ldxdw r1, [r10 - 0x5b8]
03afa8: stxdw [r10 - 0x20], r1
03afb0: ja -0xe1 ; branch 0x3a8b0
