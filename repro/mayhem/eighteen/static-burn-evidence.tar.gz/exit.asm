03afb8: mov64 r7, r1
03afc0: ldxdw r1, [r2 + 0x18]
03afc8: stxdw [r10 - 0x20], r1
03afd0: ldxdw r3, [r2 + 0x10]
03afd8: ldxdw r8, [r2 + 0x8]
03afe0: ldxdw r9, [r2 + 0x0]
03afe8: lddw r1, 0x24a7daa7d7e52a05
03aff8: stxdw [r10 - 0x28], r3
03b000: jne r9, r1, +0x18 ; branch 0x3b0c8
03b008: lddw r1, -0x7a6eabd6584f155a
03b018: jne r8, r1, +0x15 ; branch 0x3b0c8
03b020: lddw r1, 0x4c67601667a0d45a
03b030: jne r3, r1, +0x12 ; branch 0x3b0c8
03b038: lddw r1, -0x5c9ac27fa6bafcb2
03b048: ldxdw r2, [r10 - 0x20]
03b050: jne r2, r1, +0xe ; branch 0x3b0c8
03b058: ldxdw r6, [r7 + 0x158]
03b060: mov64 r1, r6
03b068: call 0xb8fb ; call 0x97848
03b070: ldxdw r3, [r10 - 0x28]
03b078: jne r0, 0x0, +0x9 ; branch 0x3b0c8
03b080: ldxdw r6, [r6 + 0x10]
03b088: ldxdw r1, [r6 + 0x10]
03b090: jeq r1, 0x0, +0x4f ; branch 0x3b310
03b098: mov64 r1, 0xb
03b0a0: mov64 r2, 0x0
03b0a8: call 0xb910 ; call 0x97930
03b0b0: mov64 r6, r0
03b0b8: ldxdw r3, [r10 - 0x28]
03b0c0: jne r6, 0x2, +0x5a ; branch 0x3b398
03b0c8: ldxdw r1, [r7 + 0x60]
03b0d0: jne r1, r9, +0x14 ; branch 0x3b178
03b0d8: ldxdw r1, [r7 + 0x68]
03b0e0: jne r1, r8, +0x12 ; branch 0x3b178
03b0e8: ldxdw r1, [r7 + 0x70]
03b0f0: jne r1, r3, +0x10 ; branch 0x3b178
03b0f8: ldxdw r1, [r7 + 0x78]
03b100: ldxdw r2, [r10 - 0x20]
03b108: jne r1, r2, +0xd ; branch 0x3b178
03b110: ldxdw r6, [r7 + 0x58]
03b118: mov64 r1, r6
03b120: call 0xb8e4 ; call 0x97848
03b128: ldxdw r3, [r10 - 0x28]
03b130: jne r0, 0x0, +0x8 ; branch 0x3b178
03b138: ldxdw r1, [r6 + 0x10]
03b140: ldxdw r1, [r1 + 0x10]
03b148: jeq r1, 0x0, +0x5 ; branch 0x3b178
03b150: mov64 r1, 0xb
03b158: mov64 r2, 0x0
03b160: call 0xb8f9 ; call 0x97930
03b168: ldxdw r3, [r10 - 0x28]
03b170: jne r0, 0x2, +0xbb ; branch 0x3b750
03b178: ldxdw r1, [r7 + 0x80]
03b180: jne r1, r9, +0x14 ; branch 0x3b228
03b188: ldxdw r1, [r7 + 0x88]
03b190: jne r1, r8, +0x12 ; branch 0x3b228
03b198: ldxdw r1, [r7 + 0x90]
03b1a0: jne r1, r3, +0x10 ; branch 0x3b228
03b1a8: ldxdw r1, [r7 + 0x98]
03b1b0: ldxdw r2, [r10 - 0x20]
03b1b8: jne r1, r2, +0xd ; branch 0x3b228
03b1c0: ldxdw r6, [r7 + 0xa0]
03b1c8: mov64 r1, r6
03b1d0: call 0xb8ce ; call 0x97848
03b1d8: ldxdw r3, [r10 - 0x28]
03b1e0: jne r0, 0x0, +0x8 ; branch 0x3b228
03b1e8: ldxdw r1, [r6 + 0x10]
03b1f0: ldxdw r1, [r1 + 0x10]
03b1f8: jeq r1, 0x0, +0x5 ; branch 0x3b228
03b200: mov64 r1, 0xb
03b208: mov64 r2, 0x0
03b210: call 0xb8e3 ; call 0x97930
03b218: ldxdw r3, [r10 - 0x28]
03b220: jne r0, 0x2, +0xcd ; branch 0x3b890
03b228: mov64 r6, 0x2
03b230: lddw r1, -0x30a5996c091fa9ff
03b240: jne r9, r1, +0xf ; branch 0x3b2c0
03b248: lddw r1, -0x55a4e84097ea24bc
03b258: jne r8, r1, +0xc ; branch 0x3b2c0
03b260: lddw r1, 0x3bffd2f597cb8951
03b270: jne r3, r1, +0x9 ; branch 0x3b2c0
03b278: lddw r1, -0x4fe7920249d4a29b
03b288: ldxdw r2, [r10 - 0x20]
03b290: jne r2, r1, +0x5 ; branch 0x3b2c0
03b298: ldxdw r7, [r7 + 0x1d0]
03b2a0: ldxdw r8, [r7 + 0x0]
03b2a8: mov64 r1, r8
03b2b0: call 0xb8b2 ; call 0x97848
03b2b8: jeq r0, 0x0, +0x1 ; branch 0x3b2c8
03b2c0: ja +0xe1 ; branch 0x3b9d0
03b2c8: ldxdw r6, [r8 + 0x10]
03b2d0: ldxdw r1, [r6 + 0x10]
03b2d8: jeq r1, 0x0, +0x49 ; branch 0x3b528
03b2e0: mov64 r1, 0xb
03b2e8: mov64 r2, 0x0
03b2f0: call 0xb8c7 ; call 0x97930
03b2f8: mov64 r6, 0x2
03b300: jne r0, 0x2, +0x54 ; branch 0x3b5a8
03b308: ja +0xd8 ; branch 0x3b9d0
03b310: stdw [r6 + 0x10], -0x1
03b318: ldxdw r1, [r6 + 0x18]
03b320: ldxdw r2, [r6 + 0x20]
03b328: stxdw [r10 - 0x10], r2
03b330: stxdw [r10 - 0x18], r1
03b338: stdw [r10 - 0x8], 0x0
03b340: mov64 r1, r7
03b348: add64 r1, 0x160
03b350: mov64 r2, r10
03b358: add64 r2, -0x18
03b360: call 0x5a51 ; call 0x685f0
03b368: ldxdw r2, [r6 + 0x10]
03b370: add64 r2, 0x1
03b378: stxdw [r6 + 0x10], r2
03b380: mov64 r6, r0
03b388: ldxdw r3, [r10 - 0x28]
03b390: jeq r6, 0x2, -0x5a ; branch 0x3b0c8
03b398: mov64 r7, r1
03b3a0: call 0x9049 ; call 0x835f0
03b3a8: lddw r1, 0x300000000
03b3b8: ldxdw r3, [r1 + 0x0]
03b3c0: mov64 r1, r3
03b3c8: add64 r1, -0xc
03b3d0: mov64 r4, 0x0
03b3d8: mov64 r2, 0x1
03b3e0: jgt r1, r3, +0x11 ; branch 0x3b470
03b3e8: mov64 r2, 0x0
03b3f0: jeq r2, 0x0, +0x10 ; branch 0x3b478
03b3f8: lddw r2, 0x300007ff4
03b408: mov64 r1, r7
03b410: jeq r3, 0x0, +0x11 ; branch 0x3b4a0
03b418: mov64 r2, r4
03b420: mov64 r3, r6
03b428: and64 r3, 0x1
03b430: lddw r3, 0x300000007
03b440: jgt r2, r3, +0x10 ; branch 0x3b4c8
03b448: mov64 r1, 0x1
03b450: mov64 r2, 0xc
03b458: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03b468: call 0xd07b ; call 0xa3848
03b470: jne r2, 0x0, -0x10 ; branch 0x3b3f8
03b478: mov64 r4, r1
03b480: lddw r2, 0x300007ff4
03b490: mov64 r1, r7
03b498: jne r3, 0x0, -0x11 ; branch 0x3b418
03b4a0: mov64 r3, r6
03b4a8: and64 r3, 0x1
03b4b0: lddw r3, 0x300000007
03b4c0: jle r2, r3, -0x10 ; branch 0x3b448
03b4c8: lddw r3, 0x300000000
03b4d8: stxdw [r3 + 0x0], r2
03b4e0: lddw r3, 0x735f6d656879616d
03b4f0: stxdw [r2 + 0x0], r3
03b4f8: stw [r2 + 0x8], 0x65746174
03b500: ldxdw r3, [r1 + 0x0]
03b508: stdw [r1 + 0x8], 0xc
03b510: stdw [r1 + 0x0], 0x1
03b518: mov64 r3, 0xc
03b520: ja +0x93 ; branch 0x3b9c0
03b528: stdw [r6 + 0x10], -0x1
03b530: ldxdw r1, [r6 + 0x18]
03b538: ldxdw r2, [r6 + 0x20]
03b540: stxdw [r10 - 0x10], r2
03b548: stxdw [r10 - 0x18], r1
03b550: stdw [r10 - 0x8], 0x0
03b558: add64 r7, 0x8
03b560: mov64 r2, r10
03b568: add64 r2, -0x18
03b570: mov64 r1, r7
03b578: call 0x64d0 ; call 0x6dc00
03b580: ldxdw r2, [r6 + 0x10]
03b588: add64 r2, 0x1
03b590: stxdw [r6 + 0x10], r2
03b598: mov64 r6, 0x2
03b5a0: jeq r0, 0x2, +0x85 ; branch 0x3b9d0
03b5a8: mov64 r7, r1
03b5b0: mov64 r6, r0
03b5b8: call 0x9006 ; call 0x835f0
03b5c0: lddw r1, 0x300000000
03b5d0: ldxdw r3, [r1 + 0x0]
03b5d8: mov64 r1, r3
03b5e0: add64 r1, -0xd
03b5e8: mov64 r4, 0x0
03b5f0: mov64 r2, 0x1
03b5f8: jgt r1, r3, +0x11 ; branch 0x3b688
03b600: mov64 r2, 0x0
03b608: jeq r2, 0x0, +0x10 ; branch 0x3b690
03b610: lddw r2, 0x300007ff3
03b620: mov64 r1, r7
03b628: jeq r3, 0x0, +0x11 ; branch 0x3b6b8
03b630: mov64 r2, r4
03b638: mov64 r3, r6
03b640: and64 r3, 0x1
03b648: lddw r3, 0x300000007
03b658: jgt r2, r3, +0x10 ; branch 0x3b6e0
03b660: mov64 r1, 0x1
03b668: mov64 r2, 0xd
03b670: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03b680: call 0xd038 ; call 0xa3848
03b688: jne r2, 0x0, -0x10 ; branch 0x3b610
03b690: mov64 r4, r1
03b698: lddw r2, 0x300007ff3
03b6a8: mov64 r1, r7
03b6b0: jne r3, 0x0, -0x11 ; branch 0x3b630
03b6b8: mov64 r3, r6
03b6c0: and64 r3, 0x1
03b6c8: lddw r3, 0x300000007
03b6d8: jle r2, r3, -0x10 ; branch 0x3b660
03b6e0: lddw r3, 0x300000000
03b6f0: stxdw [r3 + 0x0], r2
03b6f8: lddw r3, 0x65767275635f676e
03b708: stxdw [r2 + 0x5], r3
03b710: lddw r3, 0x5f676e69646e6f62
03b720: stxdw [r2 + 0x0], r3
03b728: ldxdw r3, [r1 + 0x0]
03b730: stdw [r1 + 0x8], 0xd
03b738: stdw [r1 + 0x0], 0x1
03b740: mov64 r3, 0xd
03b748: ja +0x4e ; branch 0x3b9c0
03b750: mov64 r8, 0x0
03b758: mov64 r7, r0
03b760: mov64 r6, r1
03b768: call 0x8fd0 ; call 0x835f0
03b770: lddw r1, 0x300000000
03b780: ldxdw r3, [r1 + 0x0]
03b788: mov64 r1, r3
03b790: add64 r1, -0x4
03b798: mov64 r2, 0x1
03b7a0: jgt r1, r3, +0x16 ; branch 0x3b858
03b7a8: mov64 r2, 0x0
03b7b0: jeq r2, 0x0, +0x15 ; branch 0x3b860
03b7b8: lddw r2, 0x300007ffc
03b7c8: mov64 r1, r6
03b7d0: jeq r3, 0x0, +0x1 ; branch 0x3b7e0
03b7d8: mov64 r2, r8
03b7e0: mov64 r6, r7
03b7e8: mov64 r3, r6
03b7f0: and64 r3, 0x1
03b7f8: lddw r3, 0x300000007
03b808: jle r2, r3, +0x41 ; branch 0x3ba18
03b810: lddw r3, 0x300000000
03b820: stxdw [r3 + 0x0], r2
03b828: stw [r2 + 0x0], 0x746e696d
03b830: ldxdw r3, [r1 + 0x0]
03b838: stdw [r1 + 0x8], 0x4
03b840: stdw [r1 + 0x0], 0x1
03b848: mov64 r3, 0x4
03b850: ja +0x2d ; branch 0x3b9c0
03b858: jne r2, 0x0, -0x15 ; branch 0x3b7b8
03b860: mov64 r8, r1
03b868: lddw r2, 0x300007ffc
03b878: mov64 r1, r6
03b880: jne r3, 0x0, -0x16 ; branch 0x3b7d8
03b888: ja -0x16 ; branch 0x3b7e0
03b890: mov64 r8, 0x0
03b898: mov64 r7, r0
03b8a0: mov64 r6, r1
03b8a8: call 0x8fa8 ; call 0x835f0
03b8b0: lddw r1, 0x300000000
03b8c0: ldxdw r3, [r1 + 0x0]
03b8c8: mov64 r1, r3
03b8d0: add64 r1, -0x12
03b8d8: mov64 r2, 0x1
03b8e0: jgt r1, r3, +0x1f ; branch 0x3b9e0
03b8e8: mov64 r2, 0x0
03b8f0: jeq r2, 0x0, +0x1e ; branch 0x3b9e8
03b8f8: lddw r2, 0x300007fee
03b908: mov64 r1, r6
03b910: jeq r3, 0x0, +0x1 ; branch 0x3b920
03b918: mov64 r2, r8
03b920: mov64 r6, r7
03b928: mov64 r3, r6
03b930: and64 r3, 0x1
03b938: lddw r3, 0x300000007
03b948: jle r2, r3, +0x1e ; branch 0x3ba40
03b950: lddw r3, 0x300000000
03b960: stxdw [r3 + 0x0], r2
03b968: lddw r3, 0x7561765f6e656b6f
03b978: stxdw [r2 + 0x8], r3
03b980: lddw r3, 0x745f6d656879616d
03b990: stxdw [r2 + 0x0], r3
03b998: sth [r2 + 0x10], 0x746c
03b9a0: ldxdw r3, [r1 + 0x0]
03b9a8: stdw [r1 + 0x8], 0x12
03b9b0: stdw [r1 + 0x0], 0x1
03b9b8: mov64 r3, 0x12
03b9c0: stxdw [r1 + 0x18], r3
03b9c8: stxdw [r1 + 0x10], r2
03b9d0: mov64 r0, r6
03b9d8: exit
03b9e0: jne r2, 0x0, -0x1e ; branch 0x3b8f8
03b9e8: mov64 r8, r1
03b9f0: lddw r2, 0x300007fee
03ba00: mov64 r1, r6
03ba08: jne r3, 0x0, -0x1f ; branch 0x3b918
03ba10: ja -0x1f ; branch 0x3b920
03ba18: mov64 r1, 0x1
03ba20: mov64 r2, 0x4
03ba28: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03ba38: call 0xcfc1 ; call 0xa3848
03ba40: mov64 r1, 0x1
03ba48: mov64 r2, 0x12
03ba50: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
03ba60: call 0xcfbc ; call 0xa3848
