0685f0: mov64 r6, r2
0685f8: mov64 r7, r1
068600: mov64 r1, r6
068608: lddw r2, 0xacaa8 ; rodata b'\xb1\xfd\xbf}\xcb\x16\x86kDeadlock\x17\xb7\xf87`\xd8\xac`src/lib.rs\x00library/alloc/src/fmt.rs\x00programs/mayhem'
068618: mov64 r3, 0x8
068620: call 0x5e21 ; call 0x97730
068628: jne r0, 0x0, +0x49 ; branch 0x68878
068630: ldxdw r1, [r7 + 0x40]
068638: stxdw [r10 - 0x10], r1
068640: mov64 r2, r10
068648: add64 r2, -0x10
068650: mov64 r1, r6
068658: mov64 r3, 0x8
068660: call 0x5e19 ; call 0x97730
068668: jne r0, 0x0, +0x41 ; branch 0x68878
068670: ldxdw r1, [r7 + 0x48]
068678: stxdw [r10 - 0x10], r1
068680: mov64 r2, r10
068688: add64 r2, -0x10
068690: mov64 r1, r6
068698: mov64 r3, 0x8
0686a0: call 0x5e11 ; call 0x97730
0686a8: jne r0, 0x0, +0x39 ; branch 0x68878
0686b0: mov64 r1, r6
0686b8: mov64 r2, r7
0686c0: mov64 r3, 0x20
0686c8: call 0x5e0c ; call 0x97730
0686d0: jne r0, 0x0, +0x34 ; branch 0x68878
0686d8: ldxdw r1, [r7 + 0x20]
0686e0: ldxdw r2, [r7 + 0x28]
0686e8: stxdw [r10 - 0x8], r2
0686f0: stxdw [r10 - 0x10], r1
0686f8: mov64 r2, r10
068700: add64 r2, -0x10
068708: mov64 r1, r6
068710: mov64 r3, 0x10
068718: call 0x5e02 ; call 0x97730
068720: jne r0, 0x0, +0x2a ; branch 0x68878
068728: ldxdw r1, [r7 + 0x30]
068730: ldxdw r2, [r7 + 0x38]
068738: stxdw [r10 - 0x8], r2
068740: stxdw [r10 - 0x10], r1
068748: mov64 r2, r10
068750: add64 r2, -0x10
068758: mov64 r1, r6
068760: mov64 r3, 0x10
068768: call 0x5df8 ; call 0x97730
068770: jne r0, 0x0, +0x20 ; branch 0x68878
068778: ldxb r1, [r7 + 0x61]
068780: stxb [r10 - 0x10], r1
068788: mov64 r2, r10
068790: add64 r2, -0x10
068798: mov64 r1, r6
0687a0: mov64 r3, 0x1
0687a8: call 0x5df0 ; call 0x97730
0687b0: jne r0, 0x0, +0x18 ; branch 0x68878
0687b8: ldxdw r1, [r7 + 0x50]
0687c0: stxdw [r10 - 0x10], r1
0687c8: mov64 r2, r10
0687d0: add64 r2, -0x10
0687d8: mov64 r1, r6
0687e0: mov64 r3, 0x8
0687e8: call 0x5de8 ; call 0x97730
0687f0: jne r0, 0x0, +0x10 ; branch 0x68878
0687f8: ldxb r1, [r7 + 0x60]
068800: stxb [r10 - 0x10], r1
068808: mov64 r2, r10
068810: add64 r2, -0x10
068818: mov64 r1, r6
068820: mov64 r3, 0x1
068828: call 0x5de0 ; call 0x97730
068830: jne r0, 0x0, +0x8 ; branch 0x68878
068838: ldxdw r1, [r7 + 0x58]
068840: stxdw [r10 - 0x10], r1
068848: mov64 r2, r10
068850: add64 r2, -0x10
068858: mov64 r1, r6
068860: mov64 r3, 0x8
068868: call 0x5dd8 ; call 0x97730
068870: jeq r0, 0x0, +0xe ; branch 0x688e8
068878: mov64 r1, r0
068880: and64 r1, 0x3
068888: mov64 r2, r1
068890: add64 r2, -0x2
068898: jlt r2, 0x2, +0x6 ; branch 0x688d0
0688a0: jeq r1, 0x0, +0x5 ; branch 0x688d0
0688a8: ldxdw r1, [r0 + 0x7]
0688b0: ldxdw r2, [r1 + 0x0]
0688b8: jeq r2, 0x0, +0x2 ; branch 0x688d0
0688c0: ldxdw r1, [r0 - 0x1]
0688c8: callx r2
0688d0: mov64 r1, 0xbbc
0688d8: call 0x63a1 ; call 0x9a5e8
0688e0: exit
0688e8: mov64 r0, 0x2
0688f0: ja -0x3 ; branch 0x688e0
