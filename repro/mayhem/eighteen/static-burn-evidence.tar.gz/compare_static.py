#!/usr/bin/env python3
"""Read-only instruction-window matching; no executable or normalized bytes are written."""
from pathlib import Path
import hashlib,json,re,struct
ROOT=Path(__file__).resolve().parent;REPO=next(p for p in ROOT.parents if (p/'evidence/original/mayhem/deployed.so').is_file())
class Elf:
 def __init__(self,path):
  self.path=path;self.b=path.read_bytes();b=self.b;off=struct.unpack_from('<Q',b,40)[0];size,count,ni=struct.unpack_from('<HHH',b,58);self.raw=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(count)];ns=self.raw[ni];names=b[ns[4]:ns[4]+ns[5]];self.secs={names[s[0]:].split(b'\0',1)[0].decode():s for s in self.raw};self.text=self.secs['.text'];self.lo=self.text[4];self.hi=self.lo+self.text[5];self.symbols={};self.undefined=set();self.funcs=[]
  for kind in ['.dynsym','.symtab']:
   if kind not in self.secs:continue
   s=self.secs[kind];st=self.raw[s[6]];strings=b[st[4]:st[4]+st[5]]
   for i,p in enumerate(range(s[4],s[4]+s[5],24)):
    n,info,_,idx,value,length=struct.unpack_from('<IBBHQQ',b,p);name=strings[n:].split(b'\0',1)[0].decode()
    if kind=='.dynsym':
     self.symbols[i]=name
     if idx==0 and name:self.undefined.add(name)
    if info&15==2 and length and self.lo<=value<self.hi:self.funcs.append({'name':name,'start':value,'size':length})
  self.relocations={};self.entries={f['start'] for f in self.funcs};entry=struct.unpack_from('<Q',b,24)[0]
  if self.lo<=entry<self.hi:self.entries.add(entry)
  if '.rel.dyn' in self.secs:
   s=self.secs['.rel.dyn']
   for i in range(s[4],s[4]+s[5],16):
    at,info=struct.unpack_from('<QQ',b,i);typ=info&0xffffffff;symbol=self.symbols.get(info>>32,'');self.relocations[at]={'type':typ,'symbol':symbol}
    if typ==8:
     ptr=(struct.unpack_from('<I',b,at+4)[0] | (struct.unpack_from('<I',b,at+12)[0]<<32)) if self.lo<=at<self.hi and b[at]==0x18 else struct.unpack_from('<Q',b,at)[0]>>32
     if self.lo<=ptr<self.hi and ptr%8==0:self.entries.add(ptr)
  self.calls={};norm=bytearray(b)
  for at in range(self.lo,self.hi,8):
   # Relocated external calls also use src=1 with imm=-1; they are not
   # self-calls or independent function-entry evidence.
   if b[at]==0x85 and b[at+1]==0x10 and self.relocations.get(at,{}).get('type')!=10:
    imm=struct.unpack_from('<i',b,at+4)[0];target=at+8+imm*8;self.calls[at]=target;norm[at+4:at+8]=bytes(4)
    if self.lo<=target<self.hi and target%8==0:self.entries.add(target)
   if at in self.relocations:
    typ=self.relocations[at]['type']
    if typ==8 and b[at]==0x18:norm[at+4:at+8]=bytes(4);norm[at+12:at+16]=bytes(4)
    elif typ==10 and b[at]==0x85:norm[at+4:at+8]=bytes(4)
  self.normalized=bytes(norm);self.entries=sorted(self.entries)
 def pattern(self,start,size):
  return [{'offset':at-start,**r} for at,r in sorted(self.relocations.items()) if start<=at<start+size]
 def callsites(self,start,size):return [{'offset':at-start,'target':target} for at,target in self.calls.items() if start<=at<start+size]
 def identity(self):return {'path':str(self.path.relative_to(REPO)),'sha256':hashlib.sha256(self.b).hexdigest(),'text_sha256':hashlib.sha256(self.b[self.lo:self.hi]).hexdigest()}

# Parser adapted from the recorded compiler-family static matcher.
# Only in-memory masks are used; no executable bytes are written.
import argparse
p=argparse.ArgumentParser();p.add_argument('--build',default='build-03');args=p.parse_args()
folder=ROOT/args.build
orig=Elf(REPO/'evidence/original/mayhem/deployed.so')
candidate=Elf(folder/'artifacts/mayhem_burn_draft.so')
unstripped=Elf(folder/'target/sbf-solana-solana/release/mayhem_burn_draft.so')
assert candidate.b[candidate.lo:candidate.hi]==unstripped.b[unstripped.lo:unstripped.hi]
selected={}
for f in unstripped.funcs:
 if any(x in f['name'] for x in ['mayhem_burn_draft', 'anchor_spl', 'spl_token_2022', 'anchor_lang', 'borsh']):
  selected.setdefault((f['start'], f['size']), []).append(f['name'])
results=[]
for (start,size),names in sorted(selected.items()):
 needle=candidate.normalized[start:start+size];body=candidate.b[start:start+size];position=orig.lo;matches=[]
 while (at:=orig.normalized.find(needle,position,orig.hi))>=0:
  position=at+1
  if at%8 or candidate.pattern(start,size)!=orig.pattern(at,size):continue
  end=next((x for x in orig.entries if x>at),None)
  matches.append({'original_start':at,'bytes':size,'inferred_entry':at in orig.entries,'end_is_next_entry':end==at+size,'raw_equality':body==orig.b[at:at+size],'original_raw_sha256':hashlib.sha256(orig.b[at:at+size]).hexdigest(),'calls':orig.callsites(at,size)})
 results.append({'names':names,'candidate_start':start,'bytes':size,'candidate_raw_sha256':hashlib.sha256(body).hexdigest(),'normalized_sha256':hashlib.sha256(needle).hexdigest(),'relocations':candidate.pattern(start,size),'calls':candidate.callsites(start,size),'matches':matches})
mapping={r['candidate_start']:r['matches'][0]['original_start'] for r in results if len(r['matches'])==1 and r['matches'][0]['inferred_entry']}
for r in results:
 for m in r['matches']:
  actual={c['offset']:c['target'] for c in m['calls']}
  m['mapped_call_checks']=[{'offset':c['offset'],'candidate_target':c['target'],'mapped_original_target':mapping[c['target']],'actual_original_target':actual.get(c['offset']),'equal':mapping[c['target']]==actual.get(c['offset'])} for c in r['calls'] if c['target'] in mapping]
  m['mapped_calls_consistent']=all(c['equal'] for c in m['mapped_call_checks'])
known={'handler':(0xd898,0xef10),'accounts':(0x38670,0x3afb8),'exit':(0x3afb8,0x3ba68),'status_decoder':(0x68470,0x685f0),'token_burn_wrapper':(0x90bc0,0x91248),'token_burn_instruction':(0x93510,0x93b38)}
report={'method':'Exact complete candidate function-body search in original .text after masking only relative internal call immediates and ELF relocation immediates in memory. Exclude R10 syscalls from internal calls. Require exact relocation offsets/types/symbols. No executable patching; matching instruction shapes alone are not semantic equivalence.','original':orig.identity(),'candidate':candidate.identity(),'unstripped':unstripped.identity(),'original_reviewed_windows':{n:{'start':a,'bytes':z-a,'sha256':hashlib.sha256(orig.b[a:z]).hexdigest()} for n,(a,z) in known.items()},'functions':results,'undefined_symbols':{'original':sorted(orig.undefined),'candidate':sorted(candidate.undefined)}}
report['summary']={'selected_functions':len(results),'any_normalized_matches':sum(bool(r['matches']) for r in results),'bounded_normalized_matches':sum(any(m['inferred_entry'] and m['end_is_next_entry'] and m['mapped_calls_consistent'] for m in r['matches']) for r in results),'bounded_raw_equal':sum(any(m['inferred_entry'] and m['end_is_next_entry'] and m['raw_equality'] for m in r['matches']) for r in results)}
(ROOT/(args.build+'-static-comparison.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['summary'],indent=2))
for r in results:
 if 'mayhem_burn_draft' in ' '.join(r['names']) or 'token_2022' in ' '.join(r['names']):print(r['names'][0],r['bytes'],[(hex(m['original_start']),m['end_is_next_entry'],m['raw_equality']) for m in r['matches']])
