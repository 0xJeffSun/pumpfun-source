009590: ldxdw r3, [r2 + 0x8]
009598: ldxdw r5, [r3 + 0x0]
0095a0: add64 r5, 0x1
0095a8: mov64 r0, 0x1
0095b0: jeq r5, 0x0, +0x1 ; branch 0x95c0
0095b8: mov64 r0, 0x0
0095c0: ldxdw r4, [r2 + 0x0]
0095c8: stxdw [r3 + 0x0], r5
0095d0: jeq r0, 0x1, +0x16 ; branch 0x9688
0095d8: ldxdw r5, [r2 + 0x10]
0095e0: ldxdw r0, [r5 + 0x0]
0095e8: add64 r0, 0x1
0095f0: mov64 r6, 0x1
0095f8: jeq r0, 0x0, +0x1 ; branch 0x9608
009600: mov64 r6, 0x0
009608: stxdw [r5 + 0x0], r0
009610: jeq r6, 0x1, +0xe ; branch 0x9688
009618: ldxdw r0, [r2 + 0x18]
009620: ldxdw r6, [r2 + 0x20]
009628: ldxb r7, [r2 + 0x28]
009630: ldxb r8, [r2 + 0x29]
009638: ldxb r2, [r2 + 0x2a]
009640: stxb [r1 + 0x2a], r2
009648: stxb [r1 + 0x29], r8
009650: stxb [r1 + 0x28], r7
009658: stxdw [r1 + 0x20], r6
009660: stxdw [r1 + 0x18], r0
009668: stxdw [r1 + 0x10], r5
009670: stxdw [r1 + 0x8], r3
009678: stxdw [r1 + 0x0], r4
009680: exit
009688: call -0x1
