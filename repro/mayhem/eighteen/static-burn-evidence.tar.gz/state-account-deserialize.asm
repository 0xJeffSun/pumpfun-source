007848: mov64 r6, r1
007850: ldxdw r7, [r2 + 0x18]
007858: ldxdw r1, [r7 + 0x0]
007860: jeq r1, 0x0, +0x28 ; branch 0x79a8
007868: lddw r3, 0x24a7daa7d7e52a05
007878: jne r1, r3, +0x2b ; branch 0x79d8
007880: ldxdw r1, [r7 + 0x8]
007888: lddw r3, -0x7a6eabd6584f155a
007898: jne r1, r3, +0x27 ; branch 0x79d8
0078a0: ldxdw r1, [r7 + 0x10]
0078a8: lddw r3, 0x4c67601667a0d45a
0078b8: jne r1, r3, +0x23 ; branch 0x79d8
0078c0: ldxdw r1, [r7 + 0x18]
0078c8: lddw r3, -0x5c9ac27fa6bafcb2
0078d8: jne r1, r3, +0x1f ; branch 0x79d8
0078e0: ldxdw r7, [r2 + 0x10]
0078e8: ldxdw r1, [r7 + 0x10]
0078f0: lddw r3, 0x7fffffffffffffff
007900: jge r1, r3, +0x39 ; branch 0x7ad0
007908: stxdw [r10 - 0x80], r2
007910: add64 r1, 0x1
007918: stxdw [r7 + 0x10], r1
007920: ldxdw r1, [r7 + 0x18]
007928: ldxdw r2, [r7 + 0x20]
007930: stxdw [r10 - 0x70], r2
007938: stxdw [r10 - 0x78], r1
007940: mov64 r1, r10
007948: add64 r1, -0x68
007950: mov64 r2, r10
007958: add64 r2, -0x78
007960: call 0xc1f2 ; call 0x688f8
007968: ldxdw r8, [r10 - 0x60]
007970: ldxdw r1, [r10 - 0x68]
007978: ldxb r9, [r10 - 0x7]
007980: jne r9, 0x2, +0x37 ; branch 0x7b40
007988: stxdw [r6 + 0x8], r8
007990: stxdw [r6 + 0x0], r1
007998: stb [r6 + 0x69], 0x2
0079a0: ja +0x44 ; branch 0x7bc8
0079a8: ldxdw r1, [r7 + 0x8]
0079b0: jne r1, 0x0, +0x4 ; branch 0x79d8
0079b8: ldxdw r1, [r7 + 0x10]
0079c0: jne r1, 0x0, +0x2 ; branch 0x79d8
0079c8: ldxdw r1, [r7 + 0x18]
0079d0: jeq r1, 0x0, +0x23 ; branch 0x7af0
0079d8: mov64 r1, 0xbbf
0079e0: call 0x12580 ; call 0x9a5e8
0079e8: mov64 r2, r1
0079f0: ldxdw r1, [r7 + 0x18]
0079f8: stxdw [r10 - 0x50], r1
007a00: ldxdw r1, [r7 + 0x10]
007a08: stxdw [r10 - 0x58], r1
007a10: ldxdw r1, [r7 + 0x8]
007a18: stxdw [r10 - 0x60], r1
007a20: ldxdw r1, [r7 + 0x0]
007a28: stxdw [r10 - 0x68], r1
007a30: lddw r1, 0x24a7daa7d7e52a05
007a40: stxdw [r10 - 0x48], r1
007a48: lddw r1, -0x7a6eabd6584f155a
007a58: stxdw [r10 - 0x40], r1
007a60: lddw r1, 0x4c67601667a0d45a
007a70: stxdw [r10 - 0x38], r1
007a78: lddw r1, -0x5c9ac27fa6bafcb2
007a88: stxdw [r10 - 0x30], r1
007a90: mov64 r3, r10
007a98: add64 r3, -0x68
007aa0: mov64 r1, r0
007aa8: call 0x11fe9 ; call 0x979f8
007ab0: stxdw [r6 + 0x8], r1
007ab8: stxdw [r6 + 0x0], r0
007ac0: stb [r6 + 0x69], 0x2
007ac8: exit
007ad0: mov64 r1, 0xb
007ad8: mov64 r2, 0x0
007ae0: call 0x11fc9 ; call 0x97930
007ae8: ja -0x8 ; branch 0x7ab0
007af0: mov64 r8, r2
007af8: mov64 r1, r2
007b00: call 0x1311e ; call 0xa03f8
007b08: jeq r0, 0x0, +0x1b ; branch 0x7be8
007b10: ldxdw r1, [r7 + 0x0]
007b18: mov64 r2, r8
007b20: lddw r3, 0x24a7daa7d7e52a05
007b30: jeq r1, r3, -0x57 ; branch 0x7880
007b38: ja -0x2d ; branch 0x79d8
007b40: stxdw [r10 - 0x88], r1
007b48: mov64 r1, r6
007b50: add64 r1, 0x18
007b58: mov64 r2, r10
007b60: add64 r2, -0x58
007b68: mov64 r3, 0x51
007b70: call 0x14542 ; call 0xaa588
007b78: ldxw r1, [r10 - 0x6]
007b80: stxw [r6 + 0x6a], r1
007b88: ldxh r1, [r10 - 0x2]
007b90: stxh [r6 + 0x6e], r1
007b98: stxb [r6 + 0x69], r9
007ba0: stxdw [r6 + 0x10], r8
007ba8: ldxdw r1, [r10 - 0x88]
007bb0: stxdw [r6 + 0x8], r1
007bb8: ldxdw r1, [r10 - 0x80]
007bc0: stxdw [r6 + 0x0], r1
007bc8: ldxdw r1, [r7 + 0x10]
007bd0: add64 r1, -0x1
007bd8: stxdw [r7 + 0x10], r1
007be0: ja -0x24 ; branch 0x7ac8
007be8: mov64 r1, 0xbc4
007bf0: call 0x1253e ; call 0x9a5e8
007bf8: ja -0x2a ; branch 0x7ab0
