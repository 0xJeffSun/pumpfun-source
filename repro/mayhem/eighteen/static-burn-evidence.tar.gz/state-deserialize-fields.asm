068ce0: mov64 r3, r2
068ce8: mov64 r6, r1
068cf0: ldxdw r2, [r3 + 0x8]
068cf8: jlt r2, 0x8, +0xbb ; branch 0x692d8
068d00: ldxdw r8, [r3 + 0x0]
068d08: mov64 r1, r2
068d10: add64 r1, -0x8
068d18: jle r1, 0x7, +0x1a ; branch 0x68df0
068d20: mov64 r3, r1
068d28: and64 r3, -0x8
068d30: jeq r3, 0x8, +0x17 ; branch 0x68df0
068d38: mov64 r3, r2
068d40: add64 r3, -0x18
068d48: jle r3, 0x1f, +0x14 ; branch 0x68df0
068d50: ldxdw r4, [r8 + 0x8]
068d58: ldxdw r5, [r8 + 0x10]
068d60: ldxdw r7, [r8 + 0x1e]
068d68: ldxb r3, [r8 + 0x26]
068d70: stxb [r10 - 0x38], r3
068d78: ldxw r3, [r8 + 0x18]
068d80: stxw [r10 - 0x60], r3
068d88: ldxh r3, [r8 + 0x1c]
068d90: stxh [r10 - 0x5c], r3
068d98: stxdw [r10 - 0x40], r7
068da0: ldxdw r0, [r10 - 0x3f]
068da8: ldxdw r3, [r8 + 0x27]
068db0: stxdw [r10 - 0x78], r3
068db8: ldxdw r3, [r8 + 0x2f]
068dc0: stxdw [r10 - 0x70], r3
068dc8: ldxb r3, [r8 + 0x37]
068dd0: stxb [r10 - 0x68], r3
068dd8: and64 r1, -0x10
068de0: jeq r1, 0x30, +0x1 ; branch 0x68df0
068de8: jne r1, 0x40, +0x1f ; branch 0x68ee8
068df0: add64 r8, r2
068df8: lddw r1, 0xb1220 ; rodata b'\x00\x00\x00\x00\xfc\xcf\n\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00'
068e08: call 0x7364 ; call 0xa2930
068e10: mov64 r7, r0
068e18: stxdw [r10 - 0x88], r8
068e20: stdw [r10 - 0x80], 0x0
068e28: stxdw [r10 - 0x58], r7
068e30: mov64 r1, 0xbbb
068e38: call 0x62f5 ; call 0x9a5e8
068e40: mov64 r2, r7
068e48: and64 r2, 0x3
068e50: mov64 r3, r2
068e58: add64 r3, -0x2
068e60: jlt r3, 0x2, +0xb ; branch 0x68ec0
068e68: jeq r2, 0x0, +0xa ; branch 0x68ec0
068e70: ldxdw r2, [r7 + 0x7]
068e78: ldxdw r3, [r2 + 0x0]
068e80: jeq r3, 0x0, +0x7 ; branch 0x68ec0
068e88: ldxdw r2, [r7 - 0x1]
068e90: mov64 r7, r1
068e98: mov64 r1, r2
068ea0: mov64 r8, r0
068ea8: callx r3
068eb0: mov64 r1, r7
068eb8: mov64 r0, r8
068ec0: stxdw [r6 + 0x8], r1
068ec8: stxdw [r6 + 0x0], r0
068ed0: mov64 r9, 0x2
068ed8: stxb [r6 + 0x61], r9
068ee0: exit
068ee8: ldxdw r3, [r8 + 0x40]
068ef0: ldxdw r9, [r8 + 0x38]
068ef8: ldxdw r1, [r8 + 0x50]
068f00: stxdw [r10 - 0x98], r1
068f08: ldxdw r1, [r8 + 0x48]
068f10: stxdw [r10 - 0x90], r1
068f18: mov64 r1, r2
068f20: add64 r1, -0x58
068f28: stxdw [r10 - 0x80], r1
068f30: jeq r1, 0x0, +0xe ; branch 0x68fa8
068f38: stxdw [r10 - 0xa0], r3
068f40: ldxb r3, [r8 + 0x58]
068f48: mov64 r1, r8
068f50: add64 r1, 0x59
068f58: stxdw [r10 - 0x88], r1
068f60: mov64 r1, r2
068f68: add64 r1, -0x59
068f70: stxdw [r10 - 0x80], r1
068f78: stxb [r10 - 0x59], r3
068f80: jeq r3, 0x0, +0xb ; branch 0x68fe0
068f88: jne r3, 0x1, +0x1f ; branch 0x69088
068f90: stxdw [r10 - 0xa8], r9
068f98: mov64 r9, 0x1
068fa0: ja +0x9 ; branch 0x68ff0
068fa8: add64 r8, 0x58
068fb0: lddw r1, 0xb1220 ; rodata b'\x00\x00\x00\x00\xfc\xcf\n\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00'
068fc0: call 0x732d ; call 0xa2930
068fc8: mov64 r7, r0
068fd0: stxdw [r10 - 0x88], r8
068fd8: ja -0x37 ; branch 0x68e28
068fe0: stxdw [r10 - 0xa8], r9
068fe8: mov64 r9, 0x0
068ff0: jle r1, 0x7, -0x41 ; branch 0x68df0
068ff8: stxdw [r10 - 0xc0], r0
069000: stxdw [r10 - 0xb8], r5
069008: stxdw [r10 - 0xb0], r4
069010: add64 r2, -0x61
069018: ldxdw r1, [r8 + 0x59]
069020: stxdw [r10 - 0xc8], r1
069028: stxdw [r10 - 0x80], r2
069030: add64 r8, 0x61
069038: stxdw [r10 - 0x88], r8
069040: mov64 r1, r10
069048: add64 r1, -0x40
069050: mov64 r2, r10
069058: add64 r2, -0x88
069060: call -0x17f ; call 0x68470
069068: ldxb r1, [r10 - 0x40]
069070: jeq r1, 0x0, +0x1c ; branch 0x69158
069078: ldxdw r7, [r10 - 0x38]
069080: ja -0x4c ; branch 0x68e28
069088: lddw r1, 0xb12b8 ; rodata b'\x00\x00\x00\x00\xc0\xd0\n\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb6\xce\n\x00Z\x00\x00\x00\x00\x00\x00\x00.\x02\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb8}\x00\x00\x00\x00\x00'
069098: stxdw [r10 - 0x40], r1
0690a0: mov64 r1, r10
0690a8: add64 r1, -0x10
0690b0: stxdw [r10 - 0x30], r1
0690b8: lddw r1, 0xa9458
0690c8: stxdw [r10 - 0x8], r1
0690d0: mov64 r1, r10
0690d8: add64 r1, -0x59
0690e0: stxdw [r10 - 0x10], r1
0690e8: stdw [r10 - 0x20], 0x0
0690f0: stdw [r10 - 0x38], 0x1
0690f8: stdw [r10 - 0x28], 0x1
069100: mov64 r7, r10
069108: add64 r7, -0x58
069110: mov64 r2, r10
069118: add64 r2, -0x40
069120: mov64 r1, r7
069128: call 0x74f8 ; call 0xa38f0
069130: mov64 r1, 0x15
069138: mov64 r2, r7
069140: call 0x5293 ; call 0x925e0
069148: mov64 r7, r0
069150: ja -0x66 ; branch 0x68e28
069158: ldxdw r8, [r10 - 0x88]
069160: ldxdw r1, [r10 - 0x80]
069168: jgt r1, 0x7, +0x2 ; branch 0x69180
069170: add64 r8, r1
069178: ja -0x71 ; branch 0x68df8
069180: ldxb r1, [r10 - 0x3f]
069188: ldxdw r2, [r8 + 0x0]
069190: ldxh r3, [r10 - 0x5c]
069198: stxh [r10 - 0x54], r3
0691a0: ldxw r3, [r10 - 0x60]
0691a8: stxw [r10 - 0x58], r3
0691b0: stxb [r10 - 0x52], r7
0691b8: ldxb r3, [r10 - 0x68]
0691c0: stxb [r10 - 0x21], r3
0691c8: ldxdw r3, [r10 - 0x70]
0691d0: stxdw [r10 - 0x29], r3
0691d8: ldxdw r3, [r10 - 0x78]
0691e0: stxdw [r10 - 0x31], r3
0691e8: ldxdw r3, [r10 - 0xc0]
0691f0: stxdw [r10 - 0x51], r3
0691f8: stxdw [r10 - 0x39], r3
069200: ldxdw r3, [r10 - 0x58]
069208: stxdw [r10 - 0x40], r3
069210: ldxdw r3, [r10 - 0x30]
069218: stxdw [r6 + 0x10], r3
069220: ldxdw r3, [r10 - 0x38]
069228: stxdw [r6 + 0x8], r3
069230: ldxdw r3, [r10 - 0x40]
069238: ldxdw r4, [r10 - 0x28]
069240: ldxdw r5, [r10 - 0xa0]
069248: stxdw [r6 + 0x28], r5
069250: ldxdw r5, [r10 - 0xa8]
069258: stxdw [r6 + 0x20], r5
069260: ldxdw r5, [r10 - 0x98]
069268: stxdw [r6 + 0x38], r5
069270: ldxdw r5, [r10 - 0x90]
069278: stxdw [r6 + 0x30], r5
069280: ldxdw r5, [r10 - 0xb0]
069288: stxdw [r6 + 0x40], r5
069290: ldxdw r5, [r10 - 0xb8]
069298: stxdw [r6 + 0x48], r5
0692a0: ldxdw r5, [r10 - 0xc8]
0692a8: stxdw [r6 + 0x50], r5
0692b0: stxdw [r6 + 0x58], r2
0692b8: stxb [r6 + 0x60], r1
0692c0: stxdw [r6 + 0x18], r4
0692c8: stxdw [r6 + 0x0], r3
0692d0: ja -0x80 ; branch 0x68ed8
0692d8: mov64 r1, 0x8
0692e0: lddw r3, 0xb1a38 ; rodata b'\x00\x00\x00\x00r\xcf\n\x00%\x00\x00\x00\x00\x00\x00\x00\xf9\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xdf\xde\n\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x97\xcf\n\x00#\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x97\xcf\n\x00#\x00\x00'
0692f0: call 0x7c90 ; call 0xa7778
