02fdd8: mov64 r3, r1
02fde0: ldxdw r1, [r2 + 0x0]
02fde8: ldxdw r2, [r2 + 0x8]
02fdf0: ldxdw r4, [r2 + 0x18]
02fdf8: ldxw r2, [r3 + 0x0]
02fe00: jsgt r2, 0x9, +0x8 ; branch 0x2fe48
02fe08: jsgt r2, 0x4, +0xf ; branch 0x2fe88
02fe10: jsle r2, 0x1, +0x1b ; branch 0x2fef0
02fe18: jeq r2, 0x2, +0x2e ; branch 0x2ff90
02fe20: jne r2, 0x3, +0x3d ; branch 0x30010
02fe28: lddw r2, 0xad93b ; rodata b'Too little sol reservesMayhem mode endedMayhem mode not endedOverall risk t'
02fe38: mov64 r3, 0x17
02fe40: ja +0x58 ; branch 0x30108
02fe48: jsgt r2, 0xe, +0xd ; branch 0x2feb8
02fe50: jsle r2, 0xb, +0x18 ; branch 0x2ff18
02fe58: jeq r2, 0xc, +0x2a ; branch 0x2ffb0
02fe60: jne r2, 0xd, +0x39 ; branch 0x30030
02fe68: lddw r2, 0xada3d ; rodata b'Price impact exceeds slippage tolerance in Pump Swap CPI callWithdraw Rate '
02fe78: mov64 r3, 0x3d
02fe80: ja +0x50 ; branch 0x30108
02fe88: jsle r2, 0x6, +0x16 ; branch 0x2ff40
02fe90: jeq r2, 0x7, +0x27 ; branch 0x2ffd0
02fe98: jne r2, 0x8, +0x36 ; branch 0x30050
02fea0: lddw r2, 0xad997 ; rodata b'Pump CPI call failedMath Overflow in Pump CPI callPump Swap CPI call failed'
02feb0: ja +0x39 ; branch 0x30080
02feb8: jsle r2, 0x10, +0x15 ; branch 0x2ff68
02fec0: jeq r2, 0x11, +0x25 ; branch 0x2fff0
02fec8: jne r2, 0x12, +0x34 ; branch 0x30070
02fed0: lddw r2, 0xadac6 ; rodata b'Invalid bump providedSweep fee Rate limitadminsystem_programglobal-paramsgl'
02fee0: mov64 r3, 0x15
02fee8: ja +0x43 ; branch 0x30108
02fef0: jne r2, 0x0, +0x33 ; branch 0x30090
02fef8: lddw r2, 0xad90c ; rodata b'Trading is pausedTrading is activeMath overflowToo little sol reservesMayhe'
02ff08: mov64 r3, 0x11
02ff10: ja +0x3e ; branch 0x30108
02ff18: jne r2, 0xa, +0x32 ; branch 0x300b0
02ff20: lddw r2, 0xad9c9 ; rodata b'Pump Swap CPI call failedMath Overflow in Pump Swap CPI callPrice impact ex'
02ff30: mov64 r3, 0x19
02ff38: ja +0x39 ; branch 0x30108
02ff40: jne r2, 0x5, +0x31 ; branch 0x300d0
02ff48: lddw r2, 0xad963 ; rodata b'Mayhem mode not endedOverall risk tolerance exceededPump CPI call failedMat'
02ff58: mov64 r3, 0x15
02ff60: ja +0x34 ; branch 0x30108
02ff68: jne r2, 0xf, +0x30 ; branch 0x300f0
02ff70: lddw r2, 0xad7c8 ; rodata b'Trade Rate limitAccountNotSignerPermissionDeniedtrader_quote_ataAddrNotAvai'
02ff80: mov64 r3, 0x10
02ff88: ja +0x2f ; branch 0x30108
02ff90: lddw r2, 0xad92e ; rodata b'Math overflowToo little sol reservesMayhem mode endedMayhem mode not endedO'
02ffa0: mov64 r3, 0xd
02ffa8: ja +0x2b ; branch 0x30108
02ffb0: lddw r2, 0xada05 ; rodata b'Price impact exceeds slippage tolerance in Pump CPI callPrice impact exceed'
02ffc0: mov64 r3, 0x38
02ffc8: ja +0x27 ; branch 0x30108
02ffd0: lddw r2, 0xad208 ; rodata b'Per coin risk tolerance exceededAn owner constraint was violatedProgramErro'
02ffe0: mov64 r3, 0x20
02ffe8: ja +0x23 ; branch 0x30108
02fff0: lddw r2, 0xadaa7 ; rodata b'Only 8 fee recipients supportedInvalid bump providedSweep fee Rate limitadm'
030000: mov64 r3, 0x1f
030008: ja +0x1f ; branch 0x30108
030010: lddw r2, 0xad952 ; rodata b'Mayhem mode endedMayhem mode not endedOverall risk tolerance exceededPump C'
030020: mov64 r3, 0x11
030028: ja +0x1b ; branch 0x30108
030030: lddw r2, 0xada7a ; rodata b'Withdraw Rate limitAccount type not supportedOnly 8 fee recipients supporte'
030040: mov64 r3, 0x13
030048: ja +0x17 ; branch 0x30108
030050: lddw r2, 0xad9ab ; rodata b'Math Overflow in Pump CPI callPump Swap CPI call failedMath Overflow in Pum'
030060: mov64 r3, 0x1e
030068: ja +0x13 ; branch 0x30108
030070: lddw r2, 0xadadb ; rodata b'Sweep fee Rate limitadminsystem_programglobal-paramsglobal_paramsprograms/m'
030080: mov64 r3, 0x14
030088: ja +0xf ; branch 0x30108
030090: lddw r2, 0xad91d ; rodata b'Trading is activeMath overflowToo little sol reservesMayhem mode endedMayhe'
0300a0: mov64 r3, 0x11
0300a8: ja +0xb ; branch 0x30108
0300b0: lddw r2, 0xad9e2 ; rodata b'Math Overflow in Pump Swap CPI callPrice impact exceeds slippage tolerance '
0300c0: mov64 r3, 0x23
0300c8: ja +0x7 ; branch 0x30108
0300d0: lddw r2, 0xad978 ; rodata b'Overall risk tolerance exceededPump CPI call failedMath Overflow in Pump CP'
0300e0: mov64 r3, 0x1f
0300e8: ja +0x3 ; branch 0x30108
0300f0: lddw r2, 0xada8d ; rodata b'Account type not supportedOnly 8 fee recipients supportedInvalid bump provi'
030100: mov64 r3, 0x1a
030108: callx r4
030110: exit
030118: mov64 r4, r2
030120: ldxw r1, [r1 + 0x0]
030128: lsh64 r1, 0x3
030130: lddw r3, 0xae198 ; rodata b'\r\x00\x00\x00\x00\x00\x00\x00\r\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x00\x00\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\r\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00'
030140: add64 r3, r1
030148: lddw r2, 0xb1a90 ; rodata b'\x00\x00\x00\x00\xbb\xd6\n\x00\x00\x00\x00\x00\xc8\xd6\n\x00\x00\x00\x00\x00\xd5\xd6\n\x00\x00\x00\x00\x00\xe1\xd6\n\x00\x00\x00\x00\x00\xf2\xd6\n\x00\x00\x00\x00\x00\x01\xd7\n\x00\x00\x00\x00\x00\x13\xd7\n\x00\x00\x00\x00\x00X\xd7\n\x00\x00\x00\x00\x008\xd8\n\x00\x00\x00\x00'
030158: add64 r2, r1
030160: ldxdw r2, [r2 + 0x0]
030168: ldxdw r3, [r3 + 0x0]
030170: mov64 r1, r4
030178: call 0xece4 ; call 0xa68a0
030180: exit
