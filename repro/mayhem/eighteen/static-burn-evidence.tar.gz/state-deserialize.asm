0688f8: mov64 r6, r1
068900: ldxdw r1, [r2 + 0x8]
068908: jge r1, 0x8, +0x5 ; branch 0x68938
068910: mov64 r1, 0xbb9
068918: call 0x6399 ; call 0x9a5e8
068920: stxdw [r6 + 0x8], r1
068928: stxdw [r6 + 0x0], r0
068930: ja +0x58 ; branch 0x68bf8
068938: ldxdw r1, [r2 + 0x0]
068940: ldxdw r1, [r1 + 0x0]
068948: lddw r3, 0x6b8616cb7dbffdb1
068958: jne r1, r3, +0x3 ; branch 0x68978
068960: mov64 r1, r6
068968: call 0x6e ; call 0x68ce0
068970: ja +0x51 ; branch 0x68c00
068978: mov64 r1, r10
068980: add64 r1, -0x48
068988: lddw r2, 0xad0ac ; rodata b'\xba\x0b\x00\x00\n\x00\x00\x00\x11\x00\x00\x00    mintInvalid bool representation: Error\x00\x00\x00\x00\x00\x00The given accou'
068998: call 0x6209 ; call 0x999e8
0689a0: stdw [r10 - 0x20], 0x0
0689a8: stdw [r10 - 0x28], 0x1
0689b0: stdw [r10 - 0x30], 0x0
0689b8: lddw r1, 0xb1238 ; rodata b'\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
0689c8: stxdw [r10 - 0x10], r1
0689d0: mov64 r1, r10
0689d8: add64 r1, -0x30
0689e0: stxdw [r10 - 0x18], r1
0689e8: lddw r1, 0xe0000020
0689f8: stxdw [r10 - 0x8], r1
068a00: mov64 r2, r10
068a08: add64 r2, -0x18
068a10: lddw r1, 0xad0ac ; rodata b'\xba\x0b\x00\x00\n\x00\x00\x00\x11\x00\x00\x00    mintInvalid bool representation: Error\x00\x00\x00\x00\x00\x00The given accou'
068a20: call 0x63c1 ; call 0x9a830
068a28: jne r0, 0x0, +0x4c ; branch 0x68c90
068a30: ldxdw r1, [r10 - 0x20]
068a38: stxdw [r10 - 0xa0], r1
068a40: ldxdw r1, [r10 - 0x28]
068a48: stxdw [r10 - 0xa8], r1
068a50: ldxdw r1, [r10 - 0x30]
068a58: stxdw [r10 - 0xb0], r1
068a60: ldxdw r1, [r10 - 0x48]
068a68: stxdw [r10 - 0xc8], r1
068a70: ldxdw r1, [r10 - 0x40]
068a78: stxdw [r10 - 0xc0], r1
068a80: ldxdw r1, [r10 - 0x38]
068a88: stxdw [r10 - 0xb8], r1
068a90: lddw r1, 0xad697 ; rodata b'programs/mayhem-program/src/state.rsTradingPausedTradingActiveMathOverflowS'
068aa0: stxdw [r10 - 0xe0], r1
068aa8: stw [r10 - 0x50], 0xbba
068ab0: stb [r10 - 0x98], 0x2
068ab8: stw [r10 - 0xd0], 0x1f9
068ac0: stdw [r10 - 0xd8], 0x24
068ac8: stdw [r10 - 0xe8], 0x0
068ad0: mov64 r1, r10
068ad8: add64 r1, -0xe8
068ae0: call 0x5db8 ; call 0x978a8
068ae8: mov64 r7, r0
068af0: mov64 r8, r1
068af8: call 0x355e ; call 0x835f0
068b00: lddw r1, 0x300000000
068b10: ldxdw r2, [r1 + 0x0]
068b18: mov64 r3, 0x0
068b20: mov64 r4, 0x1
068b28: mov64 r1, r2
068b30: add64 r1, -0xb
068b38: jle r1, r2, +0x19 ; branch 0x68c08
068b40: jeq r4, 0x0, +0x1a ; branch 0x68c18
068b48: lddw r1, 0x300007ff5
068b58: jne r2, 0x0, +0x1b ; branch 0x68c38
068b60: mov64 r2, r7
068b68: and64 r2, 0x1
068b70: lddw r2, 0x300000007
068b80: jle r1, r2, +0x1c ; branch 0x68c68
068b88: lddw r2, 0x300000000
068b98: stxdw [r2 + 0x0], r1
068ba0: lddw r2, 0x74536d656879614d
068bb0: stxdw [r1 + 0x0], r2
068bb8: stw [r1 + 0x7], 0x65746174
068bc0: ldxdw r2, [r8 + 0x0]
068bc8: stxdw [r8 + 0x10], r1
068bd0: stdw [r8 + 0x18], 0xb
068bd8: stdw [r8 + 0x8], 0xb
068be0: stdw [r8 + 0x0], 0x1
068be8: stxdw [r6 + 0x8], r8
068bf0: stxdw [r6 + 0x0], r7
068bf8: stb [r6 + 0x61], 0x2
068c00: exit
068c08: mov64 r4, 0x0
068c10: jne r4, 0x0, -0x1a ; branch 0x68b48
068c18: mov64 r3, r1
068c20: lddw r1, 0x300007ff5
068c30: jeq r2, 0x0, -0x1b ; branch 0x68b60
068c38: mov64 r1, r3
068c40: mov64 r2, r7
068c48: and64 r2, 0x1
068c50: lddw r2, 0x300000007
068c60: jgt r1, r2, -0x1c ; branch 0x68b88
068c68: mov64 r1, 0x1
068c70: mov64 r2, 0xb
068c78: lddw r3, 0xb1360 ; rodata b'\x00\x00\x00\x00}\xcd\n\x00T\x00\x00\x00\x00\x00\x00\x00\xc1\x01\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x10\xcf\n\x00b\x00\x00\x00\x00\x00\x00\x00\xeb\x07\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\xb2\xd4\n\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc3\xd4\n\x00\x01\x00\x00'
068c88: call 0x7577 ; call 0xa3848
068c90: mov64 r3, r10
068c98: add64 r3, -0xe8
068ca0: lddw r1, 0xad019 ; rodata b'a Display implementation returned an error unexpectedlyfalse\x00\x00\x00\x0e\x00\x00\x00\x04\x00\x00\x00\x05\x00\x00\x00'
068cb0: mov64 r2, 0x37
068cb8: lddw r4, 0xb1268 ; rodata b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x18\x8d\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\x0e\x0b\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\xe8\x01\x00'
068cc8: lddw r5, 0xb1288 ; rodata b'\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\x0e\x0b\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00(\xcd\n\x00U\x00\x00\x00\x00\x00\x00\x00\xe8\x01\x00\x00\x17\x00\x00\x00\x00\x00\x00\x00\xc0\xd0\n\x00\x1d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb6\xce\n\x00Z\x00\x00'
068cd8: call 0x77a1 ; call 0xa49e8
