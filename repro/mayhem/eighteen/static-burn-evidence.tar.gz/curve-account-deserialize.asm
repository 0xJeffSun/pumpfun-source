007490: mov64 r6, r1
007498: ldxdw r7, [r2 + 0x18]
0074a0: ldxdw r1, [r7 + 0x0]
0074a8: jeq r1, 0x0, +0x28 ; branch 0x75f0
0074b0: lddw r3, -0x30a5996c091fa9ff
0074c0: jne r1, r3, +0x2b ; branch 0x7620
0074c8: ldxdw r1, [r7 + 0x8]
0074d0: lddw r3, -0x55a4e84097ea24bc
0074e0: jne r1, r3, +0x27 ; branch 0x7620
0074e8: ldxdw r1, [r7 + 0x10]
0074f0: lddw r3, 0x3bffd2f597cb8951
007500: jne r1, r3, +0x23 ; branch 0x7620
007508: ldxdw r1, [r7 + 0x18]
007510: lddw r3, -0x4fe7920249d4a29b
007520: jne r1, r3, +0x1f ; branch 0x7620
007528: ldxdw r7, [r2 + 0x10]
007530: ldxdw r1, [r7 + 0x10]
007538: lddw r3, 0x7fffffffffffffff
007548: jge r1, r3, +0x39 ; branch 0x7718
007550: stxdw [r10 - 0x68], r2
007558: add64 r1, 0x1
007560: stxdw [r7 + 0x10], r1
007568: ldxdw r1, [r7 + 0x18]
007570: ldxdw r2, [r7 + 0x20]
007578: stxdw [r10 - 0x58], r2
007580: stxdw [r10 - 0x60], r1
007588: mov64 r1, r10
007590: add64 r1, -0x50
007598: mov64 r2, r10
0075a0: add64 r2, -0x60
0075a8: call 0xcd1f ; call 0x6dea8
0075b0: ldxdw r8, [r10 - 0x48]
0075b8: ldxdw r1, [r10 - 0x50]
0075c0: ldxb r9, [r10 - 0x7]
0075c8: jne r9, 0x2, +0x37 ; branch 0x7788
0075d0: stxdw [r6 + 0x8], r8
0075d8: stxdw [r6 + 0x0], r1
0075e0: stb [r6 + 0x51], 0x2
0075e8: ja +0x44 ; branch 0x7810
0075f0: ldxdw r1, [r7 + 0x8]
0075f8: jne r1, 0x0, +0x4 ; branch 0x7620
007600: ldxdw r1, [r7 + 0x10]
007608: jne r1, 0x0, +0x2 ; branch 0x7620
007610: ldxdw r1, [r7 + 0x18]
007618: jeq r1, 0x0, +0x23 ; branch 0x7738
007620: mov64 r1, 0xbbf
007628: call 0x125f7 ; call 0x9a5e8
007630: mov64 r2, r1
007638: ldxdw r1, [r7 + 0x18]
007640: stxdw [r10 - 0x38], r1
007648: ldxdw r1, [r7 + 0x10]
007650: stxdw [r10 - 0x40], r1
007658: ldxdw r1, [r7 + 0x8]
007660: stxdw [r10 - 0x48], r1
007668: ldxdw r1, [r7 + 0x0]
007670: stxdw [r10 - 0x50], r1
007678: lddw r1, -0x30a5996c091fa9ff
007688: stxdw [r10 - 0x30], r1
007690: lddw r1, -0x55a4e84097ea24bc
0076a0: stxdw [r10 - 0x28], r1
0076a8: lddw r1, 0x3bffd2f597cb8951
0076b8: stxdw [r10 - 0x20], r1
0076c0: lddw r1, -0x4fe7920249d4a29b
0076d0: stxdw [r10 - 0x18], r1
0076d8: mov64 r3, r10
0076e0: add64 r3, -0x50
0076e8: mov64 r1, r0
0076f0: call 0x12060 ; call 0x979f8
0076f8: stxdw [r6 + 0x8], r1
007700: stxdw [r6 + 0x0], r0
007708: stb [r6 + 0x51], 0x2
007710: exit
007718: mov64 r1, 0xb
007720: mov64 r2, 0x0
007728: call 0x12040 ; call 0x97930
007730: ja -0x8 ; branch 0x76f8
007738: mov64 r8, r2
007740: mov64 r1, r2
007748: call 0x13195 ; call 0xa03f8
007750: jeq r0, 0x0, +0x1b ; branch 0x7830
007758: ldxdw r1, [r7 + 0x0]
007760: mov64 r2, r8
007768: lddw r3, -0x30a5996c091fa9ff
007778: jeq r1, r3, -0x57 ; branch 0x74c8
007780: ja -0x2d ; branch 0x7620
007788: stxdw [r10 - 0x70], r1
007790: mov64 r1, r6
007798: add64 r1, 0x18
0077a0: mov64 r2, r10
0077a8: add64 r2, -0x40
0077b0: mov64 r3, 0x39
0077b8: call 0x145b9 ; call 0xaa588
0077c0: ldxw r1, [r10 - 0x6]
0077c8: stxw [r6 + 0x52], r1
0077d0: ldxh r1, [r10 - 0x2]
0077d8: stxh [r6 + 0x56], r1
0077e0: stxb [r6 + 0x51], r9
0077e8: stxdw [r6 + 0x10], r8
0077f0: ldxdw r1, [r10 - 0x70]
0077f8: stxdw [r6 + 0x8], r1
007800: ldxdw r1, [r10 - 0x68]
007808: stxdw [r6 + 0x0], r1
007810: ldxdw r1, [r7 + 0x10]
007818: add64 r1, -0x1
007820: stxdw [r7 + 0x10], r1
007828: ja -0x24 ; branch 0x7710
007830: mov64 r1, 0xbc4
007838: call 0x125b5 ; call 0x9a5e8
007840: ja -0x2a ; branch 0x76f8
