068470: mov64 r6, r1
068478: ldxdw r3, [r2 + 0x8]
068480: jeq r3, 0x0, +0xb ; branch 0x684e0
068488: add64 r3, -0x1
068490: ldxdw r4, [r2 + 0x0]
068498: ldxb r1, [r4 + 0x0]
0684a0: stxdw [r2 + 0x8], r3
0684a8: add64 r4, 0x1
0684b0: stxdw [r2 + 0x0], r4
0684b8: stxb [r10 - 0x59], r1
0684c0: jgt r1, 0x2, +0x9 ; branch 0x68510
0684c8: stxb [r6 + 0x1], r1
0684d0: mov64 r1, 0x0
0684d8: ja +0x20 ; branch 0x685e0
0684e0: lddw r1, 0xb1220 ; rodata b'\x00\x00\x00\x00\xfc\xcf\n\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xd8~\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00h\x8f\x00\x00\x00\x00\x00\x00H\x8d\x00\x00\x00\x00\x00\x00\xb0~\x00\x00\x00\x00\x00'
0684f0: call 0x7487 ; call 0xa2930
0684f8: stxdw [r6 + 0x8], r0
068500: stb [r6 + 0x0], 0x1
068508: ja +0x1b ; branch 0x685e8
068510: lddw r1, 0xb1a28 ; rodata b'\x00\x00\x00\x00\xb4\xde\n\x00\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00r\xcf\n\x00%\x00\x00\x00\x00\x00\x00\x00\xf9\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xdf\xde\n\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x97\xcf\n\x00#\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00'
068520: stxdw [r10 - 0x40], r1
068528: mov64 r1, r10
068530: add64 r1, -0x10
068538: stxdw [r10 - 0x30], r1
068540: lddw r1, 0x7e50
068550: stxdw [r10 - 0x8], r1
068558: mov64 r1, r10
068560: add64 r1, -0x59
068568: stxdw [r10 - 0x10], r1
068570: stdw [r10 - 0x20], 0x0
068578: stdw [r10 - 0x38], 0x1
068580: stdw [r10 - 0x28], 0x1
068588: mov64 r7, r10
068590: add64 r7, -0x58
068598: mov64 r2, r10
0685a0: add64 r2, -0x40
0685a8: mov64 r1, r7
0685b0: call 0x7667 ; call 0xa38f0
0685b8: mov64 r1, 0x15
0685c0: mov64 r2, r7
0685c8: call 0x5402 ; call 0x925e0
0685d0: stxdw [r6 + 0x8], r0
0685d8: mov64 r1, 0x1
0685e0: stxb [r6 + 0x0], r1
0685e8: exit
