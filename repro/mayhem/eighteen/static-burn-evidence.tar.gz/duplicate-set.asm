00ab70: mov64 r7, r2
00ab78: mov64 r6, r1
00ab80: ldxdw r2, [r6 + 0x28]
00ab88: ldxdw r1, [r6 + 0x20]
00ab90: mov64 r3, r7
00ab98: call -0x559 ; call 0x80d8
00aba0: ldxdw r1, [r6 + 0x10]
00aba8: stxdw [r10 - 0x30], r6
00abb0: jeq r1, 0x0, +0x92 ; branch 0xb048
00abb8: mov64 r9, 0x0
00abc0: ldxdw r1, [r7 + 0x18]
00abc8: stxdw [r10 - 0x10], r1
00abd0: ldxdw r1, [r7 + 0x10]
00abd8: stxdw [r10 - 0x8], r1
00abe0: ldxdw r5, [r7 + 0x8]
00abe8: stxdw [r10 - 0x38], r7
00abf0: ldxdw r8, [r7 + 0x0]
00abf8: mov64 r2, r0
00ac00: rsh64 r2, 0x39
00ac08: lddw r1, 0x101010101010101
00ac18: stxdw [r10 - 0x40], r2
00ac20: mov64 r7, r2
00ac28: mul64 r7, r1
00ac30: ldxdw r3, [r6 + 0x8]
00ac38: ldxdw r1, [r6 + 0x0]
00ac40: lddw r2, 0x218a392cd3d5dbf
00ac50: mov64 r4, r7
00ac58: mov64 r6, 0x0
00ac60: stxdw [r10 - 0x28], r6
00ac68: stxdw [r10 - 0x48], r4
00ac70: stxdw [r10 - 0x20], r9
00ac78: and64 r0, r3
00ac80: mov64 r6, r1
00ac88: add64 r6, r0
00ac90: ldxdw r7, [r6 + 0x0]
00ac98: stxdw [r10 - 0x18], r7
00aca0: xor64 r7, r4
00aca8: mov64 r9, r7
00acb0: lddw r4, -0x101010101010101
00acc0: add64 r9, r4
00acc8: xor64 r7, -0x1
00acd0: and64 r7, r9
00acd8: lddw r4, -0x7f7f7f7f7f7f7f80
00ace8: and64 r7, r4
00acf0: jne r7, 0x0, +0x22 ; branch 0xae08
00acf8: ldxdw r7, [r10 - 0x18]
00ad00: lddw r4, -0x7f7f7f7f7f7f7f80
00ad10: and64 r7, r4
00ad18: ldxdw r9, [r10 - 0x20]
00ad20: ldxdw r4, [r10 - 0x50]
00ad28: ldxdw r6, [r10 - 0x28]
00ad30: jeq r6, 0x1, +0xe ; branch 0xada8
00ad38: jeq r7, 0x0, +0x34 ; branch 0xaee0
00ad40: mov64 r4, r7
00ad48: neg64 r4
00ad50: mov64 r6, r7
00ad58: and64 r6, r4
00ad60: mul64 r6, r2
00ad68: rsh64 r6, 0x3a
00ad70: lddw r4, 0xac9d8 ; rodata b'\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e\x1c\t"\x14(\x05\x11\x1a&\x0f.\x1d0\n\x1f#6\x152)9?\x06\x0c\x12\x18\x1b!\'\x10%-/\x1e518>\x0b\x17 $,47=\x16+3<*;:\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e'
00ad80: add64 r4, r6
00ad88: ldxb r4, [r4 + 0x0]
00ad90: rsh64 r4, 0x3
00ad98: add64 r4, r0
00ada0: and64 r4, r3
00ada8: ldxdw r6, [r10 - 0x18]
00adb0: lsh64 r6, 0x1
00adb8: and64 r7, r6
00adc0: jne r7, 0x0, +0x29 ; branch 0xaf10
00adc8: stxdw [r10 - 0x50], r4
00add0: mov64 r4, 0x1
00add8: stxdw [r10 - 0x28], r4
00ade0: ja +0x21 ; branch 0xaef0
00ade8: mov64 r7, r6
00adf0: add64 r7, -0x1
00adf8: and64 r7, r6
00ae00: jeq r7, 0x0, -0x22 ; branch 0xacf8
00ae08: mov64 r6, r7
00ae10: neg64 r7
00ae18: mov64 r9, r6
00ae20: and64 r9, r7
00ae28: mul64 r9, r2
00ae30: rsh64 r9, 0x3a
00ae38: lddw r7, 0xac9d8 ; rodata b'\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e\x1c\t"\x14(\x05\x11\x1a&\x0f.\x1d0\n\x1f#6\x152)9?\x06\x0c\x12\x18\x1b!\'\x10%-/\x1e518>\x0b\x17 $,47=\x16+3<*;:\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e'
00ae48: add64 r7, r9
00ae50: ldxb r9, [r7 + 0x0]
00ae58: rsh64 r9, 0x3
00ae60: add64 r9, r0
00ae68: and64 r9, r3
00ae70: lsh64 r9, 0x5
00ae78: mov64 r7, r1
00ae80: sub64 r7, r9
00ae88: ldxdw r9, [r7 - 0x20]
00ae90: jne r8, r9, -0x16 ; branch 0xade8
00ae98: ldxdw r9, [r7 - 0x18]
00aea0: jne r5, r9, -0x18 ; branch 0xade8
00aea8: ldxdw r9, [r7 - 0x10]
00aeb0: ldxdw r4, [r10 - 0x8]
00aeb8: jne r4, r9, -0x1b ; branch 0xade8
00aec0: ldxdw r7, [r7 - 0x8]
00aec8: ldxdw r9, [r10 - 0x10]
00aed0: jne r9, r7, -0x1e ; branch 0xade8
00aed8: ja +0x2b ; branch 0xb038
00aee0: mov64 r4, 0x0
00aee8: stxdw [r10 - 0x28], r4
00aef0: add64 r9, 0x8
00aef8: add64 r0, r9
00af00: ldxdw r4, [r10 - 0x48]
00af08: ja -0x54 ; branch 0xac70
00af10: mov64 r2, r1
00af18: add64 r2, r4
00af20: ldxb r2, [r2 + 0x0]
00af28: lsh64 r2, 0x38
00af30: arsh64 r2, 0x38
00af38: jsge r2, 0x0, +0x2b ; branch 0xb098
00af40: and64 r2, 0x1
00af48: ldxdw r0, [r10 - 0x30]
00af50: ldxdw r5, [r0 + 0x10]
00af58: sub64 r5, r2
00af60: stxdw [r0 + 0x10], r5
00af68: mov64 r2, r1
00af70: add64 r2, r4
00af78: ldxdw r5, [r10 - 0x40]
00af80: stxb [r2 + 0x0], r5
00af88: mov64 r2, r4
00af90: add64 r2, -0x8
00af98: and64 r2, r3
00afa0: mov64 r3, r1
00afa8: add64 r3, r2
00afb0: stxb [r3 + 0x8], r5
00afb8: ldxdw r2, [r0 + 0x18]
00afc0: add64 r2, 0x1
00afc8: stxdw [r0 + 0x18], r2
00afd0: lsh64 r4, 0x5
00afd8: sub64 r1, r4
00afe0: ldxdw r3, [r10 - 0x38]
00afe8: ldxdw r2, [r3 + 0x18]
00aff0: stxdw [r1 - 0x8], r2
00aff8: ldxdw r2, [r3 + 0x10]
00b000: stxdw [r1 - 0x10], r2
00b008: ldxdw r2, [r3 + 0x8]
00b010: stxdw [r1 - 0x18], r2
00b018: ldxdw r2, [r3 + 0x0]
00b020: stxdw [r1 - 0x20], r2
00b028: mov64 r0, 0x0
00b030: exit
00b038: mov64 r0, 0x1
00b040: ja -0x3 ; branch 0xb030
00b048: mov64 r3, r6
00b050: add64 r3, 0x20
00b058: mov64 r1, r6
00b060: mov64 r2, 0x1
00b068: mov64 r4, 0x1
00b070: mov64 r6, r0
00b078: call 0x17 ; call 0xb138
00b080: mov64 r0, r6
00b088: ldxdw r6, [r10 - 0x30]
00b090: ja -0x9c ; branch 0xabb8
00b098: ldxdw r2, [r1 + 0x0]
00b0a0: lddw r4, -0x7f7f7f7f7f7f7f80
00b0b0: and64 r2, r4
00b0b8: mov64 r4, r2
00b0c0: neg64 r4
00b0c8: and64 r2, r4
00b0d0: lddw r4, 0x218a392cd3d5dbf
00b0e0: mul64 r2, r4
00b0e8: rsh64 r2, 0x3a
00b0f0: lddw r4, 0xac9d8 ; rodata b'\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e\x1c\t"\x14(\x05\x11\x1a&\x0f.\x1d0\n\x1f#6\x152)9?\x06\x0c\x12\x18\x1b!\'\x10%-/\x1e518>\x0b\x17 $,47=\x16+3<*;:\x00\x01\x02\x07\x03\r\x08\x13\x04\x19\x0e'
00b100: add64 r4, r2
00b108: ldxb r4, [r4 + 0x0]
00b110: rsh64 r4, 0x3
00b118: mov64 r2, r1
00b120: add64 r2, r4
00b128: ldxb r2, [r2 + 0x0]
00b130: ja -0x3f ; branch 0xaf40
