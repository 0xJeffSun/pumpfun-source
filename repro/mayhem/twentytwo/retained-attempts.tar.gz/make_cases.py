from pathlib import Path
import json,copy
R=Path.cwd();D=R/'work/mayhem-buy-v2-followup';v=json.loads((R/'repro/mayhem/twentyone/sell-v2-cases.json').read_text());b=json.loads((R/'repro/mayhem/twenty/buy-cases.json').read_text())
def remap(c,m):
 c=copy.deepcopy(c)
 for name in ['wrong_keys','readonly']:
  if name in c:c[name]=[m[x] for x in c[name]]
 for name in ['mutations','replace_keys']:
  if name in c:c[name]={str(m[int(k)]):v for k,v in c[name].items()}
 if 'swap_accounts' in c:c['swap_accounts']=[[m[x] for x in pair] for pair in c['swap_accounts']]
 return c
rows=[remap(c,{i:i+(i>=23) for i in range(31)}) for c in v['cases']];names={c['name'] for c in rows}
m={0:0,1:1,2:2,3:3,4:6,5:8,6:9,7:10,8:12,9:13,10:15,11:17,12:18,13:21,14:22,15:23,16:24,17:26,18:27,19:28,20:29,22:30}
for c in b['cases']:
 if c['name'] not in names and c['name'] not in ['wrong_v2_program','wrong_key_bonding_curve_v2']:rows.append(remap(c,m));names.add(c['name'])
rows.append({'name':'missing_account_31','account_count':31})
for field in ['stable_global_risk','stable_token_risk']:
 for n in [0,1,2795,2796,2797,(1<<64)-1]:rows.append({'name':f'{field}_{n}',field:n})
for amount in [0,1,2795,2796,2797]:rows.append({'name':f'quote_vault_amount_{amount}','mutations':{'7':{'u64':[[64,amount]]}}})
for val in [(1<<127)-1,(1<<127)-2796,(1<<64),-2797,-2796,-2795]:rows.append({'name':f'buy_global_stable_{val}','global_stable':val})
for field in ['global_stable','state_sol']:
 for val in [-2797,-2796,-2795,(1<<64)-2796,(1<<64)-2795]:
  for limit in [0,1,2]:rows.append({'name':f'token_quote_{field}_post_risk_{val}_{limit}',field:val,('stable_global_risk' if field=='global_stable' else 'stable_token_risk'):limit})
assert len({c['name'] for c in rows})==len(rows)
(D/'cases.json').write_text(json.dumps({'scope':'Synthetic test-owned buy_v2 fixtures. Account mutations are normal simulator setup; all original authorizations remain active. Base sell_v2 cases remapped for inserted global volume, plus legacy-buy risk/cap/funding/volume coverage and quote-specific risk boundaries.','cases':rows,'excluded_fixture_constructions':v['excluded_fixture_constructions'],'exclusion_reason':v['exclusion_reason']},indent=2)+'\n');print(len(rows))
p=D/'probe.py';s=p.read_text().replace("c.get('stable_global_risk',(1<<64)-1)","c.get('stable_global_risk',c.get('global_risk',(1<<64)-1))").replace("c.get('stable_token_risk',(1<<64)-1)","c.get('stable_token_risk',c.get('token_risk',(1<<64)-1))");p.write_text(s)
s=(R/'scripts/mayhem_sell_v2_differential.py').read_text().replace('import mayhem_sell_v2_fixture as p','import probe as p').replace("D/'mayhem_sell_v2_fixture.py'","D/'probe.py'");(D/'differential.py').write_text(s)
