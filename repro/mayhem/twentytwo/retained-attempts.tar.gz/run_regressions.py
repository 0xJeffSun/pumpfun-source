from pathlib import Path
import subprocess,json,concurrent.futures,sys
D=Path('work/mayhem-buy-v2-followup');out=D/'regression-01';out.mkdir(exist_ok=True);binary=D/'build-01/artifacts/mayhem_recovered.so'
commands={name:[sys.executable,f'scripts/mayhem_validate_{name}.py','--candidate',str(binary),'--output',str(out/f'{name}.json')] for name in ['admin','fee_recipient','extend','withdraw','quote_withdraw','sweeps']}
commands['sell']=[sys.executable,'scripts/mayhem_sell_differential.py','--candidate',str(binary),'--output',str(out/'sell.json')]
commands['buy']=[sys.executable,'scripts/mayhem_buy_differential.py','--candidate',str(binary),'--cases','repro/mayhem/twenty/buy-cases.json','--output',str(out/'buy.json')]
commands['burn']=[sys.executable,'scripts/mayhem_burn_sequence.py','--candidate',str(binary),'--output',str(out/'burn'),'--fixtures','work/mayhem-burn-fixtures']
for family in ['native','token','token22']:
 commands[f'sell-v2-{family}']=[sys.executable,'scripts/mayhem_sell_v2_differential.py','--candidate',str(binary),'--cases','repro/mayhem/twentyone/sell-v2-cases.json','--family',family,'--output',str(out/f'sell-v2-{family}.json')]
def run(row):
 name,cmd=row
 with (out/f'{name}.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return name,{'command':cmd,'returncode':r.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:results=dict(e.map(run,commands.items()))
(out/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(row['returncode'] for row in results.values()))
