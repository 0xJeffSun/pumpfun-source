from pathlib import Path
import subprocess,sys,json
D=Path('work/mayhem-buy-v2-followup');binary=D/'build-02/artifacts/mayhem_recovered.so';rows=[]
for family in ['native','token','token22']:
 p=D/f'comparison-02-{family}.json';j=json.loads(p.read_text());assert j['case_count']==613 and not j['mismatches'];out=D/f'verification-02-{family}.json'
 subprocess.run([sys.executable,str(D/'verify_receipts.py'),'--candidate',str(binary),'--receipts',str(p),'--output',str(out)],check=True,stdout=subprocess.DEVNULL);rows.append({'family':family,'cases':613,'successes':j['successful_original_cases'],'verification':str(out)})
r=D/'regression-02';commands=json.loads((r/'commands.json').read_text());assert all(v['returncode']==0 for v in commands.values())
old=0
for p in r.glob('*.json'):
 if p.name=='commands.json':continue
 j=json.loads(p.read_text())
 if 'cases' in j:assert not j['mismatches'];old+=j['case_count']
assert old==5254,old
for name in ['buy','sell']:
 subprocess.run([sys.executable,f'scripts/verify_mayhem_{name}.py','--candidate',str(binary),'--receipts',str(r/f'{name}.json'),'--output',str(r/f'{name}-verification.json')],check=True,stdout=subprocess.DEVNULL)
for family in ['native','token','token22']:
 subprocess.run([sys.executable,'scripts/verify_mayhem_sell_v2.py','--candidate',str(binary),'--receipts',str(r/f'sell-v2-{family}.json'),'--output',str(r/f'sell-v2-{family}-verification.json')],check=True,stdout=subprocess.DEVNULL)
subprocess.run([sys.executable,'scripts/verify_mayhem_burn_sequence.py','--fixtures','work/mayhem-burn-fixtures','--receipts',str(r/'burn')],check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'new':rows,'inherited':old+6,'total':old+6+1839},indent=2))
