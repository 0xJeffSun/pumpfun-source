from pathlib import Path
import subprocess,sys,concurrent.futures,json
D=Path('work/mayhem-sell-v2-followup')
def run(family):
 cmd=[sys.executable,str(D/'differential.py'),'--family',family,'--candidate',str(D/'build-01/artifacts/mayhem_recovered.so'),'--output',str(D/f'comparison-03-{family}.json')]
 with (D/f'comparison-03-{family}.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 print(family,r.returncode,flush=True);return family,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:results=dict(e.map(run,['native','token','token22']))
(D/'matrix-03-exits.json').write_text(json.dumps(results,indent=2)+'\n')
