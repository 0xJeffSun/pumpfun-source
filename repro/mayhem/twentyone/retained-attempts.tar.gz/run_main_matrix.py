from pathlib import Path
import subprocess,sys,concurrent.futures,json
D=Path('work/mayhem-sell-v2-followup');P=Path('repro/mayhem/twentyone')
def run(family):
 cmd=[sys.executable,'scripts/mayhem_sell_v2_differential.py','--cases',str(P/'sell-v2-cases.json'),'--family',family,'--candidate',str(P/'mayhem_recovered.so'),'--output',str(D/f'main-{family}.json')]
 with (D/f'main-{family}.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 print(family,r.returncode,flush=True);return family,{'command':cmd,'returncode':r.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:results=dict(e.map(run,['native','token','token22']))
(D/'main-matrix-exits.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(v['returncode']==0 for v in results.values())
