    a030: 79 32 08 00 00 00 00 00      	ldxdw r2, [r3 + 0x8]
    a038: 15 02 08 00 00 00 00 00      	jeq r2, 0x0, +0x8 <.text+0x9f60>
    a040: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
    a048: 7b 23 08 00 00 00 00 00      	stxdw [r3 + 0x8], r2
    a050: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
    a058: bf 24 00 00 00 00 00 00      	mov64 r4, r2
    a060: 07 04 00 00 30 00 00 00      	add64 r4, 0x30
    a068: 7b 43 00 00 00 00 00 00      	stxdw [r3 + 0x0], r4
    a070: 85 10 00 00 cc 1a 01 00      	call 0x11acc
    a078: 05 00 05 00 00 00 00 00      	ja +0x5 <.text+0x9f88>
    a080: bf 16 00 00 00 00 00 00      	mov64 r6, r1
    a088: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
    a090: 85 10 00 00 aa 20 01 00      	call 0x120aa
    a098: 7b 16 08 00 00 00 00 00      	stxdw [r6 + 0x8], r1
    a0a0: 7b 06 00 00 00 00 00 00      	stxdw [r6 + 0x0], r0
    a0a8: 95 00 00 00 00 00 00 00      	exit
    a138: 79 32 08 00 00 00 00 00      	ldxdw r2, [r3 + 0x8]
    a140: 15 02 08 00 00 00 00 00      	jeq r2, 0x0, +0x8 <.text+0xa068>
    a148: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
    a150: 7b 23 08 00 00 00 00 00      	stxdw [r3 + 0x8], r2
    a158: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
    a160: bf 24 00 00 00 00 00 00      	mov64 r4, r2
    a168: 07 04 00 00 30 00 00 00      	add64 r4, 0x30
    a170: 7b 43 00 00 00 00 00 00      	stxdw [r3 + 0x0], r4
    a178: 85 10 00 00 d9 fa ff ff      	call -0x527
    a180: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0xa098>
    a188: bf 16 00 00 00 00 00 00      	mov64 r6, r1
    a190: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
    a198: 85 10 00 00 89 20 01 00      	call 0x12089
    a1a0: 7b 16 08 00 00 00 00 00      	stxdw [r6 + 0x8], r1
    a1a8: 7b 06 00 00 00 00 00 00      	stxdw [r6 + 0x0], r0
    a1b0: 72 06 69 00 02 00 00 00      	stb [r6 + 0x69], 0x2
    a1b8: 95 00 00 00 00 00 00 00      	exit
    d898: bf 17 00 00 00 00 00 00      	mov64 r7, r1
    d8a0: 79 78 08 00 00 00 00 00      	ldxdw r8, [r7 + 0x8]
    d8a8: 79 86 a8 01 00 00 00 00      	ldxdw r6, [r8 + 0x1a8]
    d8b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    d8b8: 07 01 00 00 b0 fe ff ff      	add64 r1, -0x150
    d8c0: 85 10 00 00 e1 22 01 00      	call 0x122e1
    d8c8: 61 a1 b0 fe 00 00 00 00      	ldxw r1, [r10 - 0x150]
    d8d0: 15 01 99 02 01 00 00 00      	jeq r1, 0x1, +0x299 <.text+0xec80>
    d8d8: 79 a1 d8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x128]
    d8e0: dd 16 2a 00 00 00 00 00      	jsle r6, r1, +0x2a <.text+0xd918>
    d8e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    d8f0: 07 01 00 00 88 ff ff ff      	add64 r1, -0x78
    d8f8: 18 02 00 00 60 d0 0a 00 00 00 00 00 00 00 00 00      	lddw r2, 0xad060
    d908: 85 10 00 00 b8 41 00 00      	call 0x41b8
    d910: 7a 0a b8 ff 00 00 00 00      	stdw [r10 - 0x48], 0x0
    d918: 7a 0a b0 ff 01 00 00 00      	stdw [r10 - 0x50], 0x1
    d920: 7a 0a a8 ff 00 00 00 00      	stdw [r10 - 0x58], 0x0
    d928: 18 01 00 00 38 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1238
    d938: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
    d940: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    d948: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
    d950: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
    d958: 18 01 00 00 20 00 00 e0 00 00 00 00 00 00 00 00      	lddw r1, 0xe0000020
    d968: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
    d970: bf a2 00 00 00 00 00 00      	mov64 r2, r10
    d978: 07 02 00 00 c8 ff ff ff      	add64 r2, -0x38
    d980: 18 01 00 00 60 d0 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad060
    d990: 85 10 00 00 88 44 00 00      	call 0x4488
    d998: 55 00 8c 02 00 00 00 00      	jne r0, 0x0, +0x28c <.text+0xece0>
    d9a0: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
    d9a8: 7b 1a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r1
    d9b0: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
    d9b8: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
    d9c0: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
    d9c8: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
    d9d0: 79 a1 88 ff 00 00 00 00      	ldxdw r1, [r10 - 0x78]
    d9d8: 7b 1a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r1
    d9e0: 79 a1 90 ff 00 00 00 00      	ldxdw r1, [r10 - 0x70]
    d9e8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
    d9f0: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
    d9f8: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
    da00: 18 01 00 00 c4 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad4c4
    da10: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
    da18: 62 0a 48 ff 75 17 00 00      	stw [r10 - 0xb8], 0x1775
    da20: 72 0a 00 ff 02 00 00 00      	stb [r10 - 0x100], 0x2
    da28: 62 0a c8 fe 4e 00 00 00      	stw [r10 - 0x138], 0x4e
    da30: 05 00 2b 00 00 00 00 00      	ja +0x2b <.text+0xda70>
    da38: 71 81 c0 01 00 00 00 00      	ldxb r1, [r8 + 0x1c0]
    da40: 55 01 2f 00 02 00 00 00      	jne r1, 0x2, +0x2f <.text+0xdaa0>
    da48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    da50: 07 01 00 00 88 ff ff ff      	add64 r1, -0x78
    da58: 18 02 00 00 5c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r2, 0xad05c
    da68: 85 10 00 00 8c 41 00 00      	call 0x418c
    da70: 7a 0a b8 ff 00 00 00 00      	stdw [r10 - 0x48], 0x0
    da78: 7a 0a b0 ff 01 00 00 00      	stdw [r10 - 0x50], 0x1
    da80: 7a 0a a8 ff 00 00 00 00      	stdw [r10 - 0x58], 0x0
    da88: 18 01 00 00 38 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1238
    da98: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
    daa0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    daa8: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
    dab0: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
    dab8: 18 01 00 00 20 00 00 e0 00 00 00 00 00 00 00 00      	lddw r1, 0xe0000020
    dac8: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
    dad0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
    dad8: 07 02 00 00 c8 ff ff ff      	add64 r2, -0x38
    dae0: 18 01 00 00 5c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad05c
    daf0: 85 10 00 00 5c 44 00 00      	call 0x445c
    daf8: 55 00 60 02 00 00 00 00      	jne r0, 0x0, +0x260 <.text+0xece0>
    db00: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
    db08: 7b 1a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r1
    db10: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
    db18: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
    db20: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
    db28: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
    db30: 79 a1 88 ff 00 00 00 00      	ldxdw r1, [r10 - 0x78]
    db38: 7b 1a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r1
    db40: 79 a1 90 ff 00 00 00 00      	ldxdw r1, [r10 - 0x70]
    db48: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
    db50: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
    db58: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
    db60: 18 01 00 00 c4 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad4c4
    db70: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
    db78: 62 0a 48 ff 74 17 00 00      	stw [r10 - 0xb8], 0x1774
    db80: 72 0a 00 ff 02 00 00 00      	stb [r10 - 0x100], 0x2
    db88: 62 0a c8 fe 52 00 00 00      	stw [r10 - 0x138], 0x52
    db90: 7a 0a c0 fe 30 00 00 00      	stdw [r10 - 0x140], 0x30
    db98: 7a 0a b0 fe 00 00 00 00      	stdw [r10 - 0x150], 0x0
    dba0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    dba8: 07 01 00 00 b0 fe ff ff      	add64 r1, -0x150
    dbb0: 85 10 00 00 9e 13 01 00      	call 0x1139e
    dbb8: 95 00 00 00 00 00 00 00      	exit
    dbc0: 79 81 e8 00 00 00 00 00      	ldxdw r1, [r8 + 0xe8]
    dbc8: 7b 1a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r1
    dbd0: 79 81 f8 01 00 00 00 00      	ldxdw r1, [r8 + 0x1f8]
    dbd8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    dbe0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
    dbe8: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
    dbf0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
    dbf8: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
    dc00: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
    dc08: 7b 2a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r2
    dc10: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    dc18: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
    dc20: 79 82 58 00 00 00 00 00      	ldxdw r2, [r8 + 0x58]
    dc28: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
    dc30: 79 41 00 00 00 00 00 00      	ldxdw r1, [r4 + 0x0]
    dc38: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
    dc40: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    dc48: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <.text+0xdb38>
    dc50: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    dc58: 79 25 00 00 00 00 00 00      	ldxdw r5, [r2 + 0x0]
    dc60: 7b 5a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r5
    dc68: 7b 14 00 00 00 00 00 00      	stxdw [r4 + 0x0], r1
    dc70: 15 03 24 02 01 00 00 00      	jeq r3, 0x1, +0x224 <.text+0xec78>
    dc78: 79 20 10 00 00 00 00 00      	ldxdw r0, [r2 + 0x10]
    dc80: 79 01 00 00 00 00 00 00      	ldxdw r1, [r0 + 0x0]
    dc88: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
    dc90: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    dc98: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <.text+0xdb88>
    dca0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    dca8: 7b 10 00 00 00 00 00 00      	stxdw [r0 + 0x0], r1
    dcb0: 15 03 1c 02 01 00 00 00      	jeq r3, 0x1, +0x21c <.text+0xec78>
    dcb8: 79 86 a0 00 00 00 00 00      	ldxdw r6, [r8 + 0xa0]
    dcc0: 79 65 08 00 00 00 00 00      	ldxdw r5, [r6 + 0x8]
    dcc8: 79 51 00 00 00 00 00 00      	ldxdw r1, [r5 + 0x0]
    dcd0: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
    dcd8: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    dce0: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <.text+0xdbd0>
    dce8: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    dcf0: 71 29 2a 00 00 00 00 00      	ldxb r9, [r2 + 0x2a]
    dcf8: 7b 9a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r9
    dd00: 71 29 29 00 00 00 00 00      	ldxb r9, [r2 + 0x29]
    dd08: 7b 9a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r9
    dd10: 71 29 28 00 00 00 00 00      	ldxb r9, [r2 + 0x28]
    dd18: 7b 9a 90 fe 00 00 00 00      	stxdw [r10 - 0x170], r9
    dd20: 79 29 20 00 00 00 00 00      	ldxdw r9, [r2 + 0x20]
    dd28: 7b 9a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r9
    dd30: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
    dd38: 79 69 00 00 00 00 00 00      	ldxdw r9, [r6 + 0x0]
    dd40: 7b 15 00 00 00 00 00 00      	stxdw [r5 + 0x0], r1
    dd48: 15 03 09 02 01 00 00 00      	jeq r3, 0x1, +0x209 <.text+0xec78>
    dd50: 7b 2a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r2
    dd58: 7b 5a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r5
    dd60: 79 65 10 00 00 00 00 00      	ldxdw r5, [r6 + 0x10]
    dd68: 79 51 00 00 00 00 00 00      	ldxdw r1, [r5 + 0x0]
    dd70: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
    dd78: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
    dd80: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <.text+0xdc70>
    dd88: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
    dd90: 7b 15 00 00 00 00 00 00      	stxdw [r5 + 0x0], r1
    dd98: 15 02 ff 01 01 00 00 00      	jeq r2, 0x1, +0x1ff <.text+0xec78>
    dda0: 7b 0a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r0
    dda8: 7b 8a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r8
    ddb0: 79 88 c8 01 00 00 00 00      	ldxdw r8, [r8 + 0x1c8]
    ddb8: 79 80 08 00 00 00 00 00      	ldxdw r0, [r8 + 0x8]
    ddc0: 79 02 00 00 00 00 00 00      	ldxdw r2, [r0 + 0x0]
    ddc8: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
    ddd0: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    ddd8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0xdcc8>
    dde0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    dde8: 71 61 2a 00 00 00 00 00      	ldxb r1, [r6 + 0x2a]
    ddf0: 7b 1a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r1
    ddf8: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
    de00: 7b 1a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r1
    de08: 71 61 28 00 00 00 00 00      	ldxb r1, [r6 + 0x28]
    de10: 7b 1a 58 fe 00 00 00 00      	stxdw [r10 - 0x1a8], r1
    de18: 79 61 20 00 00 00 00 00      	ldxdw r1, [r6 + 0x20]
    de20: 7b 1a 60 fe 00 00 00 00      	stxdw [r10 - 0x1a0], r1
    de28: 79 61 18 00 00 00 00 00      	ldxdw r1, [r6 + 0x18]
    de30: 79 86 00 00 00 00 00 00      	ldxdw r6, [r8 + 0x0]
    de38: 7b 20 00 00 00 00 00 00      	stxdw [r0 + 0x0], r2
    de40: 15 03 ea 01 01 00 00 00      	jeq r3, 0x1, +0x1ea <.text+0xec78>
    de48: 7b 6a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r6
    de50: 79 82 10 00 00 00 00 00      	ldxdw r2, [r8 + 0x10]
    de58: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
    de60: 07 03 00 00 01 00 00 00      	add64 r3, 0x1
    de68: b7 06 00 00 01 00 00 00      	mov64 r6, 0x1
    de70: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <.text+0xdd60>
    de78: b7 06 00 00 00 00 00 00      	mov64 r6, 0x0
    de80: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
    de88: 15 06 e1 01 01 00 00 00      	jeq r6, 0x1, +0x1e1 <.text+0xec78>
    de90: 79 83 18 00 00 00 00 00      	ldxdw r3, [r8 + 0x18]
    de98: 79 86 20 00 00 00 00 00      	ldxdw r6, [r8 + 0x20]
    dea0: 7b 5a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r5
    dea8: 7b 9a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r9
    deb0: 71 89 28 00 00 00 00 00      	ldxb r9, [r8 + 0x28]
    deb8: bf 15 00 00 00 00 00 00      	mov64 r5, r1
    dec0: 71 81 29 00 00 00 00 00      	ldxb r1, [r8 + 0x29]
    dec8: 71 88 2a 00 00 00 00 00      	ldxb r8, [r8 + 0x2a]
    ded0: 71 77 21 00 00 00 00 00      	ldxb r7, [r7 + 0x21]
    ded8: 7b 4a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r4
    dee0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
    dee8: 07 04 00 00 ff ff ff ff      	add64 r4, -0x1
    def0: 7b 4a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r4
    def8: 18 04 00 00 a9 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r4, 0xad4a9
    df08: 7b 4a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r4
    df10: 73 7a ff ff 00 00 00 00      	stxb [r10 - 0x1], r7
    df18: bf a4 00 00 00 00 00 00      	mov64 r4, r10
    df20: 07 04 00 00 c8 ff ff ff      	add64 r4, -0x38
    df28: 7b 4a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r4
    df30: 73 8a 52 ff 00 00 00 00      	stxb [r10 - 0xae], r8
    df38: 73 1a 51 ff 00 00 00 00      	stxb [r10 - 0xaf], r1
    df40: 73 9a 50 ff 00 00 00 00      	stxb [r10 - 0xb0], r9
    df48: 7b 6a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r6
    df50: 7b 3a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r3
    df58: 7b 2a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r2
    df60: 7b 0a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r0
    df68: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
    df70: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
    df78: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
    df80: 73 1a 22 ff 00 00 00 00      	stxb [r10 - 0xde], r1
    df88: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
    df90: 73 1a 21 ff 00 00 00 00      	stxb [r10 - 0xdf], r1
    df98: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
    dfa0: 73 1a 20 ff 00 00 00 00      	stxb [r10 - 0xe0], r1
    dfa8: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
    dfb0: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
    dfb8: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
    dfc0: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
    dfc8: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
    dfd0: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
    dfd8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
    dfe0: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
    dfe8: 7b 1a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r1
    dff0: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
    dff8: 73 1a f2 fe 00 00 00 00      	stxb [r10 - 0x10e], r1
    e000: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
    e008: 73 1a f1 fe 00 00 00 00      	stxb [r10 - 0x10f], r1
    e010: 79 a1 90 fe 00 00 00 00      	ldxdw r1, [r10 - 0x170]
    e018: 73 1a f0 fe 00 00 00 00      	stxb [r10 - 0x110], r1
    e020: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
    e028: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
    e030: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
    e038: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
    e040: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
    e048: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
    e050: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
    e058: 7b 1a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r1
    e060: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
    e068: 7b 1a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r1
    e070: 7a 0a e0 ff 01 00 00 00      	stdw [r10 - 0x20], 0x1
    e078: 7a 0a d0 ff 09 00 00 00      	stdw [r10 - 0x30], 0x9
    e080: 7a 0a 90 ff 02 00 00 00      	stdw [r10 - 0x70], 0x2
    e088: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    e090: 07 01 00 00 88 ff ff ff      	add64 r1, -0x78
    e098: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
    e0a0: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
    e0a8: 7b 1a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r1
    e0b0: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
    e0b8: 7b 1a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r1
    e0c0: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
    e0c8: 7b 1a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r1
    e0d0: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
    e0d8: 7b 1a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r1
    e0e0: 7a 0a c0 fe 00 00 00 00      	stdw [r10 - 0x140], 0x0
    e0e8: 7a 0a b8 fe 08 00 00 00      	stdw [r10 - 0x148], 0x8
    e0f0: 7a 0a b0 fe 00 00 00 00      	stdw [r10 - 0x150], 0x0
    e0f8: 7a 0a 60 ff 01 00 00 00      	stdw [r10 - 0xa0], 0x1
    e100: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    e108: 07 01 00 00 b0 fe ff ff      	add64 r1, -0x150
    e110: 79 a8 a8 fe 00 00 00 00      	ldxdw r8, [r10 - 0x158]
    e118: bf 82 00 00 00 00 00 00      	mov64 r2, r8
    e120: 85 10 00 00 53 05 01 00      	call 0x10553
    e128: 55 00 51 ff 02 00 00 00      	jne r0, 0x2, -0xaf <.text+0xda98>
    e130: 79 a7 20 fe 00 00 00 00      	ldxdw r7, [r10 - 0x1e0]
    e138: 7b 87 b8 01 00 00 00 00      	stxdw [r7 + 0x1b8], r8
    e140: 79 71 58 00 00 00 00 00      	ldxdw r1, [r7 + 0x58]
    e148: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e150: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
    e158: 7b 2a a0 ff 00 00 00 00      	stxdw [r10 - 0x60], r2
    e160: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
    e168: 7b 2a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r2
    e170: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
    e178: 7b 2a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r2
    e180: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e188: 7b 1a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r1
    e190: 79 71 58 01 00 00 00 00      	ldxdw r1, [r7 + 0x158]
    e198: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e1a0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
    e1a8: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
    e1b0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
    e1b8: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
    e1c0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
    e1c8: 7b 2a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r2
    e1d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e1d8: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
    e1e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    e1e8: 07 01 00 00 c8 ff ff ff      	add64 r1, -0x38
    e1f0: 85 10 00 00 bb 21 01 00      	call 0x121bb
    e1f8: 61 a1 c8 ff 00 00 00 00      	ldxw r1, [r10 - 0x38]
    e200: 15 01 89 01 01 00 00 00      	jeq r1, 0x1, +0x189 <.text+0xed30>
    e208: 79 a1 88 ff 00 00 00 00      	ldxdw r1, [r10 - 0x78]
    e210: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
    e218: 79 a1 90 ff 00 00 00 00      	ldxdw r1, [r10 - 0x70]
    e220: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
    e228: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
    e230: 7b 1a c0 fe 00 00 00 00      	stxdw [r10 - 0x140], r1
    e238: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
    e240: 7b 1a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r1
    e248: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
    e250: 7b 1a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r1
    e258: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
    e260: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
    e268: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
    e270: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
    e278: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
    e280: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
    e288: 79 a6 f0 ff 00 00 00 00      	ldxdw r6, [r10 - 0x10]
    e290: 85 10 00 00 6b ea 00 00      	call 0xea6b
    e298: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
    e2a8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
    e2b0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    e2b8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
    e2c0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
    e2c8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
    e2d0: bd 21 08 00 00 00 00 00      	jle r1, r2, +0x8 <.text+0xe1f8>
    e2d8: 15 04 09 00 00 00 00 00      	jeq r4, 0x0, +0x9 <.text+0xe208>
    e2e0: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
    e2f0: 55 02 0a 00 00 00 00 00      	jne r2, 0x0, +0xa <.text+0xe228>
    e2f8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
    e308: 2d 21 0b 00 00 00 00 00      	jgt r1, r2, +0xb <.text+0xe248>
    e310: 05 00 ae 00 00 00 00 00      	ja +0xae <.text+0xe768>
    e318: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
    e320: 55 04 f7 ff 00 00 00 00      	jne r4, 0x0, -0x9 <.text+0xe1c0>
    e328: bf 13 00 00 00 00 00 00      	mov64 r3, r1
    e330: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
    e340: 15 02 f6 ff 00 00 00 00      	jeq r2, 0x0, -0xa <.text+0xe1d8>
    e348: bf 31 00 00 00 00 00 00      	mov64 r1, r3
    e350: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
    e360: bd 21 a4 00 00 00 00 00      	jle r1, r2, +0xa4 <.text+0xe768>
    e368: bf a9 00 00 00 00 00 00      	mov64 r9, r10
    e370: 07 09 00 00 d0 fe ff ff      	add64 r9, -0x130
    e378: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
    e388: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
    e390: 7b 81 08 00 00 00 00 00      	stxdw [r1 + 0x8], r8
    e398: 18 02 00 00 21 59 2f 75 00 00 00 00 52 7c ee fa      	lddw r2, -0x51183ad8ad0a6df
    e3a8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
    e3b0: 79 a2 b0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x150]
    e3b8: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
    e3c0: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
    e3c8: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
    e3d0: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
    e3d8: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
    e3e0: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
    e3e8: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
    e3f0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
    e3f8: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
    e400: 79 92 08 00 00 00 00 00      	ldxdw r2, [r9 + 0x8]
    e408: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
    e410: 79 92 10 00 00 00 00 00      	ldxdw r2, [r9 + 0x10]
    e418: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
    e420: 79 92 18 00 00 00 00 00      	ldxdw r2, [r9 + 0x18]
    e428: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
    e430: 7b 61 50 00 00 00 00 00      	stxdw [r1 + 0x50], r6
    e438: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
    e440: 7a 0a d0 ff 58 00 00 00      	stdw [r10 - 0x30], 0x58
    e448: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    e450: 07 01 00 00 c8 ff ff ff      	add64 r1, -0x38
    e458: b7 06 00 00 01 00 00 00      	mov64 r6, 0x1
    e460: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
    e468: 85 10 00 00 ad 16 01 00      	call 0x116ad
    e470: 79 71 00 02 00 00 00 00      	ldxdw r1, [r7 + 0x200]
    e478: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
    e480: 79 42 00 00 00 00 00 00      	ldxdw r2, [r4 + 0x0]
    e488: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
    e490: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0xe380>
    e498: b7 06 00 00 00 00 00 00      	mov64 r6, 0x0
    e4a0: 79 18 00 00 00 00 00 00      	ldxdw r8, [r1 + 0x0]
    e4a8: 7b 24 00 00 00 00 00 00      	stxdw [r4 + 0x0], r2
    e4b0: 15 06 1c 01 01 00 00 00      	jeq r6, 0x1, +0x11c <.text+0xec78>
    e4b8: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
    e4c0: 79 52 00 00 00 00 00 00      	ldxdw r2, [r5 + 0x0]
    e4c8: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
    e4d0: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    e4d8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0xe3c8>
    e4e0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    e4e8: 7b 4a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r4
    e4f0: 7b 25 00 00 00 00 00 00      	stxdw [r5 + 0x0], r2
    e4f8: 15 03 13 01 01 00 00 00      	jeq r3, 0x1, +0x113 <.text+0xec78>
    e500: 7b 5a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r5
    e508: 71 12 2a 00 00 00 00 00      	ldxb r2, [r1 + 0x2a]
    e510: 7b 2a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r2
    e518: 71 12 29 00 00 00 00 00      	ldxb r2, [r1 + 0x29]
    e520: 7b 2a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r2
    e528: 71 12 28 00 00 00 00 00      	ldxb r2, [r1 + 0x28]
    e530: 7b 2a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r2
    e538: 79 12 20 00 00 00 00 00      	ldxdw r2, [r1 + 0x20]
    e540: 7b 2a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r2
    e548: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
    e550: 7b 1a 90 fe 00 00 00 00      	stxdw [r10 - 0x170], r1
    e558: 79 71 58 00 00 00 00 00      	ldxdw r1, [r7 + 0x58]
    e560: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e568: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
    e570: 7b 2a a0 ff 00 00 00 00      	stxdw [r10 - 0x60], r2
    e578: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
    e580: 7b 2a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r2
    e588: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
    e590: 7b 2a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r2
    e598: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e5a0: 7b 1a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r1
    e5a8: 79 71 58 01 00 00 00 00      	ldxdw r1, [r7 + 0x158]
    e5b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e5b8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
    e5c0: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
    e5c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
    e5d0: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
    e5d8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
    e5e0: 7b 2a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r2
    e5e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e5f0: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
    e5f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
    e600: 07 01 00 00 c8 ff ff ff      	add64 r1, -0x38
    e608: 85 10 00 00 38 21 01 00      	call 0x12138
    e610: 61 a1 c8 ff 00 00 00 00      	ldxw r1, [r10 - 0x38]
    e618: 15 01 12 01 01 00 00 00      	jeq r1, 0x1, +0x112 <.text+0xed90>
    e620: 79 a1 88 ff 00 00 00 00      	ldxdw r1, [r10 - 0x78]
    e628: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
    e630: 79 a1 90 ff 00 00 00 00      	ldxdw r1, [r10 - 0x70]
    e638: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
    e640: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
    e648: 7b 1a c0 fe 00 00 00 00      	stxdw [r10 - 0x140], r1
    e650: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
    e658: 7b 1a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r1
    e660: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
    e668: 7b 1a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r1
    e670: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
    e678: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
    e680: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
    e688: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
    e690: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
    e698: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
    e6a0: 79 a6 f0 ff 00 00 00 00      	ldxdw r6, [r10 - 0x10]
    e6a8: 85 10 00 00 e8 e9 00 00      	call 0xe9e8
    e6b0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
    e6c0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
    e6c8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
    e6d0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
    e6d8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
    e6e0: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
    e6e8: bd 13 28 00 00 00 00 00      	jle r3, r1, +0x28 <.text+0xe710>
    e6f0: 15 04 29 00 00 00 00 00      	jeq r4, 0x0, +0x29 <.text+0xe720>
    e6f8: 18 07 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f00
    e708: 55 01 2a 00 00 00 00 00      	jne r1, 0x0, +0x2a <.text+0xe740>
    e710: 7b 8a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r8
    e718: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
    e728: bd 17 2b 00 00 00 00 00      	jle r7, r1, +0x2b <.text+0xe768>
    e730: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
    e740: 7b 78 00 00 00 00 00 00      	stxdw [r8 + 0x0], r7
    e748: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
    e750: 7b 17 08 00 00 00 00 00      	stxdw [r7 + 0x8], r1
    e758: 18 01 00 00 21 59 2f 75 00 00 00 00 52 7c ee fa      	lddw r1, -0x51183ad8ad0a6df
    e768: 7b 17 00 00 00 00 00 00      	stxdw [r7 + 0x0], r1
    e770: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
    e778: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
    e780: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
    e788: 7b 17 18 00 00 00 00 00      	stxdw [r7 + 0x18], r1
    e790: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
    e798: 7b 17 20 00 00 00 00 00      	stxdw [r7 + 0x20], r1
    e7a0: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
    e7a8: 7b 17 28 00 00 00 00 00      	stxdw [r7 + 0x28], r1
    e7b0: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
    e7b8: 7b 17 30 00 00 00 00 00      	stxdw [r7 + 0x30], r1
    e7c0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
    e7c8: 7b 17 38 00 00 00 00 00      	stxdw [r7 + 0x38], r1
    e7d0: 79 91 10 00 00 00 00 00      	ldxdw r1, [r9 + 0x10]
    e7d8: 7b 17 40 00 00 00 00 00      	stxdw [r7 + 0x40], r1
    e7e0: 79 91 18 00 00 00 00 00      	ldxdw r1, [r9 + 0x18]
    e7e8: 7b 17 48 00 00 00 00 00      	stxdw [r7 + 0x48], r1
    e7f0: 7b 67 50 00 00 00 00 00      	stxdw [r7 + 0x50], r6
    e7f8: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
    e800: b7 06 00 00 60 00 00 00      	mov64 r6, 0x60
    e808: 75 06 14 00 00 00 00 00      	jsge r6, 0x0, +0x14 <.text+0xe790>
    e810: b7 02 00 00 60 00 00 00      	mov64 r2, 0x60
    e818: 18 03 00 00 78 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1378
    e828: 85 10 00 00 03 2a 01 00      	call 0x12a03
    e830: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
    e838: 55 04 d7 ff 00 00 00 00      	jne r4, 0x0, -0x29 <.text+0xe5d8>
    e840: bf 32 00 00 00 00 00 00      	mov64 r2, r3
    e848: 18 07 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f00
    e858: 15 01 d6 ff 00 00 00 00      	jeq r1, 0x0, -0x2a <.text+0xe5f0>
    e860: bf 27 00 00 00 00 00 00      	mov64 r7, r2
    e868: 7b 8a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r8
    e870: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
    e880: 2d 17 d5 ff 00 00 00 00      	jgt r7, r1, -0x2b <.text+0xe610>
    e888: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
    e890: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
    e898: 18 03 00 00 98 19 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1998
    e8a8: 85 10 00 00 f3 29 01 00      	call 0x129f3
    e8b0: 85 10 00 00 a7 e9 00 00      	call 0xe9a7
    e8b8: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
    e8c0: 18 03 00 00 00 80 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300008000
    e8d0: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <.text+0xe7c0>
    e8d8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
    e8e0: bf 32 00 00 00 00 00 00      	mov64 r2, r3
    e8e8: 1f 62 00 00 00 00 00 00      	sub64 r2, r6
    e8f0: b7 06 00 00 00 00 00 00      	mov64 r6, 0x0
    e8f8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
    e900: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
    e908: bd 32 05 00 00 00 00 00      	jle r2, r3, +0x5 <.text+0xe818>
    e910: 15 04 06 00 00 00 00 00      	jeq r4, 0x0, +0x6 <.text+0xe828>
    e918: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
    e928: 2d 26 07 00 00 00 00 00      	jgt r6, r2, +0x7 <.text+0xe848>
    e930: 05 00 db ff 00 00 00 00      	ja -0x25 <.text+0xe6f0>
    e938: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
    e940: 55 04 fa ff 00 00 00 00      	jne r4, 0x0, -0x6 <.text+0xe7f8>
    e948: bf 26 00 00 00 00 00 00      	mov64 r6, r2
    e950: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
    e960: bd 26 d5 ff 00 00 00 00      	jle r6, r2, -0x2b <.text+0xe6f0>
    e968: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
    e978: 7b 61 00 00 00 00 00 00      	stxdw [r1 + 0x0], r6
    e980: 18 01 00 00 e4 45 a5 2e 00 00 00 00 51 cb 9a 1d      	lddw r1, 0x1d9acb512ea545e4
    e990: 7b 16 00 00 00 00 00 00      	stxdw [r6 + 0x0], r1
    e998: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
    e9a0: bf 62 00 00 00 00 00 00      	mov64 r2, r6
    e9a8: 0f 12 00 00 00 00 00 00      	add64 r2, r1
    e9b0: bf 73 00 00 00 00 00 00      	mov64 r3, r7
    e9b8: 0f 13 00 00 00 00 00 00      	add64 r3, r1
    e9c0: 71 33 00 00 00 00 00 00      	ldxb r3, [r3 + 0x0]
    e9c8: 73 32 08 00 00 00 00 00      	stxb [r2 + 0x8], r3
    e9d0: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
    e9d8: 55 01 f8 ff 58 00 00 00      	jne r1, 0x58, -0x8 <.text+0xe880>
    e9e0: 85 10 00 00 81 e9 00 00      	call 0xe981
    e9e8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
    e9f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
    ea00: bf 21 00 00 00 00 00 00      	mov64 r1, r2
    ea08: 07 01 00 00 de ff ff ff      	add64 r1, -0x22
    ea10: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
    ea18: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
    ea20: 79 a8 20 fe 00 00 00 00      	ldxdw r8, [r10 - 0x1e0]
    ea28: bd 21 40 00 00 00 00 00      	jle r1, r2, +0x40 <.text+0xeb10>
    ea30: 15 04 41 00 00 00 00 00      	jeq r4, 0x0, +0x41 <.text+0xeb20>
    ea38: 18 01 00 00 de 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fde
    ea48: 55 02 42 00 00 00 00 00      	jne r2, 0x0, +0x42 <.text+0xeb40>
    ea50: 18 02 00 00 08 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000008
    ea60: ad 21 43 00 00 00 00 00      	jlt r1, r2, +0x43 <.text+0xeb60>
    ea68: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
    ea78: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
    ea80: 79 a7 68 fe 00 00 00 00      	ldxdw r7, [r10 - 0x198]
    ea88: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
    ea90: 79 73 08 00 00 00 00 00      	ldxdw r3, [r7 + 0x8]
    ea98: 79 74 10 00 00 00 00 00      	ldxdw r4, [r7 + 0x10]
    eaa0: 79 75 18 00 00 00 00 00      	ldxdw r5, [r7 + 0x18]
    eaa8: 7b 51 18 00 00 00 00 00      	stxdw [r1 + 0x18], r5
    eab0: 7b 41 10 00 00 00 00 00      	stxdw [r1 + 0x10], r4
    eab8: 7b 31 08 00 00 00 00 00      	stxdw [r1 + 0x8], r3
    eac0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
    eac8: 6a 01 20 00 01 00 00 00      	sth [r1 + 0x20], 0x1
    ead0: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
    ead8: 7a 0a d8 ff 01 00 00 00      	stdw [r10 - 0x28], 0x1
    eae0: 7a 0a c8 ff 01 00 00 00      	stdw [r10 - 0x38], 0x1
    eae8: bf a9 00 00 00 00 00 00      	mov64 r9, r10
    eaf0: 07 09 00 00 b0 fe ff ff      	add64 r9, -0x150
    eaf8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
    eb00: 07 05 00 00 c8 ff ff ff      	add64 r5, -0x38
    eb08: bf 91 00 00 00 00 00 00      	mov64 r1, r9
    eb10: 18 02 00 00 ed de 0a 00 00 00 00 00 00 00 00 00      	lddw r2, 0xadeed
    eb20: bf 63 00 00 00 00 00 00      	mov64 r3, r6
    eb28: b7 04 00 00 60 00 00 00      	mov64 r4, 0x60
    eb30: 85 10 00 00 ad 23 01 00      	call 0x123ad
    eb38: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
    eb40: 73 1a f2 ff 00 00 00 00      	stxb [r10 - 0xe], r1
    eb48: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
    eb50: 73 1a f1 ff 00 00 00 00      	stxb [r10 - 0xf], r1
    eb58: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
    eb60: 73 1a f0 ff 00 00 00 00      	stxb [r10 - 0x10], r1
    eb68: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
    eb70: 7b 1a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r1
    eb78: 79 a1 90 fe 00 00 00 00      	ldxdw r1, [r10 - 0x170]
    eb80: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
    eb88: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
    eb90: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
    eb98: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
    eba0: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
    eba8: 7b 7a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r7
    ebb0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
    ebb8: 07 02 00 00 c8 ff ff ff      	add64 r2, -0x38
    ebc0: bf 91 00 00 00 00 00 00      	mov64 r1, r9
    ebc8: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
    ebd0: 18 04 00 00 b0 13 0b 00 00 00 00 00 00 00 00 00      	lddw r4, 0xb13b0
    ebe0: b7 05 00 00 01 00 00 00      	mov64 r5, 0x1
    ebe8: 85 10 00 00 25 19 01 00      	call 0x11925
    ebf0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
    ebf8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
    ec00: 67 01 00 00 20 00 00 00      	lsh64 r1, 0x20
    ec08: 77 01 00 00 20 00 00 00      	rsh64 r1, 0x20
    ec10: 55 01 10 00 1a 00 00 00      	jne r1, 0x1a, +0x10 <.text+0xeb78>
    ec18: b7 00 00 00 02 00 00 00      	mov64 r0, 0x2
    ec20: 79 a3 a0 fe 00 00 00 00      	ldxdw r3, [r10 - 0x160]
    ec28: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0xeb90>
    ec30: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
    ec38: 55 04 bf ff 00 00 00 00      	jne r4, 0x0, -0x41 <.text+0xe918>
    ec40: bf 13 00 00 00 00 00 00      	mov64 r3, r1
    ec48: 18 01 00 00 de 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fde
    ec58: 15 02 be ff 00 00 00 00      	jeq r2, 0x0, -0x42 <.text+0xe930>
    ec60: bf 31 00 00 00 00 00 00      	mov64 r1, r3
    ec68: 18 02 00 00 08 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000008
    ec78: 3d 21 bd ff 00 00 00 00      	jge r1, r2, -0x43 <.text+0xe948>
    ec80: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
    ec88: b7 02 00 00 22 00 00 00      	mov64 r2, 0x22
    ec90: 85 10 00 00 7a 29 01 00      	call 0x1297a
    ec98: bf 01 00 00 00 00 00 00      	mov64 r1, r0
    eca0: 85 10 00 00 91 11 01 00      	call 0x11191
    eca8: 79 a3 d0 ff 00 00 00 00      	ldxdw r3, [r10 - 0x30]
    ecb0: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
    ecb8: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
    ecc0: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
    ecc8: 55 02 08 00 00 00 00 00      	jne r2, 0x0, +0x8 <.text+0xebf0>
    ecd0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
    ecd8: 07 02 00 00 d0 ff ff ff      	add64 r2, -0x30
    ece0: bf 16 00 00 00 00 00 00      	mov64 r6, r1
    ece8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
    ecf0: bf 07 00 00 00 00 00 00      	mov64 r7, r0
    ecf8: 85 10 00 00 d5 22 01 00      	call 0x122d5
    ed00: bf 61 00 00 00 00 00 00      	mov64 r1, r6
    ed08: bf 70 00 00 00 00 00 00      	mov64 r0, r7
    ed10: 79 a2 d8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x28]
    ed18: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
    ed20: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
    ed28: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
    ed30: 55 03 08 00 00 00 00 00      	jne r3, 0x0, +0x8 <.text+0xec58>
    ed38: bf a2 00 00 00 00 00 00      	mov64 r2, r10
    ed40: 07 02 00 00 d8 ff ff ff      	add64 r2, -0x28
    ed48: bf 16 00 00 00 00 00 00      	mov64 r6, r1
    ed50: bf 21 00 00 00 00 00 00      	mov64 r1, r2
    ed58: bf 07 00 00 00 00 00 00      	mov64 r7, r0
    ed60: 85 10 00 00 be 22 01 00      	call 0x122be
    ed68: bf 61 00 00 00 00 00 00      	mov64 r1, r6
    ed70: bf 70 00 00 00 00 00 00      	mov64 r0, r7
    ed78: 55 00 c7 fd 02 00 00 00      	jne r0, 0x2, -0x239 <.text+0xda98>
    ed80: 72 08 c0 01 02 00 00 00      	stb [r8 + 0x1c0], 0x2
    ed88: b7 00 00 00 02 00 00 00      	mov64 r0, 0x2
    ed90: 05 00 c4 fd 00 00 00 00      	ja -0x23c <.text+0xda98>
    ed98: 85 10 00 00 ff ff ff ff      	call -0x1
    eda0: 79 a1 b4 fe 00 00 00 00      	ldxdw r1, [r10 - 0x14c]
    eda8: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
    edb0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
    edb8: 07 03 00 00 c8 ff ff ff      	add64 r3, -0x38
    edc0: 18 01 00 00 f4 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad4f4
    edd0: b7 02 00 00 2b 00 00 00      	mov64 r2, 0x2b
    edd8: 18 04 00 00 c0 13 0b 00 00 00 00 00 00 00 00 00      	lddw r4, 0xb13c0
    ede8: 18 05 00 00 10 14 0b 00 00 00 00 00 00 00 00 00      	lddw r5, 0xb1410
    edf8: 85 10 00 00 7d 2b 01 00      	call 0x12b7d
    ee00: bf a3 00 00 00 00 00 00      	mov64 r3, r10
    ee08: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
    ee10: 18 01 00 00 19 d0 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad019
    ee20: b7 02 00 00 37 00 00 00      	mov64 r2, 0x37
    ee28: 18 04 00 00 68 12 0b 00 00 00 00 00 00 00 00 00      	lddw r4, 0xb1268
    ee38: 18 05 00 00 88 12 0b 00 00 00 00 00 00 00 00 00      	lddw r5, 0xb1288
    ee48: 85 10 00 00 73 2b 01 00      	call 0x12b73
    ee50: 79 a1 cc ff 00 00 00 00      	ldxdw r1, [r10 - 0x34]
    ee58: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
    ee60: bf a3 00 00 00 00 00 00      	mov64 r3, r10
    ee68: 07 03 00 00 b0 fe ff ff      	add64 r3, -0x150
    ee70: 18 01 00 00 f4 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad4f4
    ee80: b7 02 00 00 2b 00 00 00      	mov64 r2, 0x2b
    ee88: 18 04 00 00 c0 13 0b 00 00 00 00 00 00 00 00 00      	lddw r4, 0xb13c0
    ee98: 18 05 00 00 f8 13 0b 00 00 00 00 00 00 00 00 00      	lddw r5, 0xb13f8
    eea8: 85 10 00 00 67 2b 01 00      	call 0x12b67
    eeb0: 79 a1 cc ff 00 00 00 00      	ldxdw r1, [r10 - 0x34]
    eeb8: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
    eec0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
    eec8: 07 03 00 00 b0 fe ff ff      	add64 r3, -0x150
    eed0: 18 01 00 00 f4 d4 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad4f4
    eee0: b7 02 00 00 2b 00 00 00      	mov64 r2, 0x2b
    eee8: 18 04 00 00 c0 13 0b 00 00 00 00 00 00 00 00 00      	lddw r4, 0xb13c0
    eef8: 18 05 00 00 e0 13 0b 00 00 00 00 00 00 00 00 00      	lddw r5, 0xb13e0
    ef08: 85 10 00 00 5b 2b 01 00      	call 0x12b5b
   38670: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   38678: bf 38 00 00 00 00 00 00      	mov64 r8, r3
   38680: 7b 2a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r2
   38688: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   38690: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38698: 07 01 00 00 20 fb ff ff      	add64 r1, -0x4e0
   386a0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   386a8: 85 10 00 00 51 a3 ff ff      	call -0x5caf
   386b0: 79 a9 28 fb 00 00 00 00      	ldxdw r9, [r10 - 0x4d8]
   386b8: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   386c0: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   386c8: 71 a1 89 fb 00 00 00 00      	ldxb r1, [r10 - 0x477]
   386d0: 55 01 1a 00 02 00 00 00      	jne r1, 0x2, +0x1a <.text+0x38688>
   386d8: 85 10 00 00 e2 95 00 00      	call 0x95e2
   386e0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   386f0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   386f8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   38700: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   38708: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   38710: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   38718: 2d 21 44 00 00 00 00 00      	jgt r1, r2, +0x44 <.text+0x38820>
   38720: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   38728: 79 a5 18 fb 00 00 00 00      	ldxdw r5, [r10 - 0x4e8]
   38730: 15 04 43 00 00 00 00 00      	jeq r4, 0x0, +0x43 <.text+0x38830>
   38738: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   38748: 15 02 44 00 00 00 00 00      	jeq r2, 0x0, +0x44 <.text+0x38850>
   38750: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   38758: bf 52 00 00 00 00 00 00      	mov64 r2, r5
   38760: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   38768: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   38778: 2d 21 43 00 00 00 00 00      	jgt r1, r2, +0x43 <.text+0x38878>
   38780: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   38788: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   38790: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   387a0: 85 10 00 00 14 d6 00 00      	call 0xd614
   387a8: 7b 1a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r1
   387b0: 79 77 08 f0 00 00 00 00      	ldxdw r7, [r7 - 0xff8]
   387b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   387c0: 07 01 00 00 98 fb ff ff      	add64 r1, -0x468
   387c8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   387d0: 07 02 00 00 30 fb ff ff      	add64 r2, -0x4d0
   387d8: b7 03 00 00 59 00 00 00      	mov64 r3, 0x59
   387e0: 85 10 00 00 b4 e3 00 00      	call 0xe3b4
   387e8: 61 a1 8a fb 00 00 00 00      	ldxw r1, [r10 - 0x476]
   387f0: 63 1a 90 fb 00 00 00 00      	stxw [r10 - 0x470], r1
   387f8: 69 a1 8e fb 00 00 00 00      	ldxh r1, [r10 - 0x472]
   38800: 6b 1a 94 fb 00 00 00 00      	stxh [r10 - 0x46c], r1
   38808: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38810: 07 01 00 00 f8 fb ff ff      	add64 r1, -0x408
   38818: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   38820: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   38828: 85 10 00 00 98 94 ff ff      	call -0x6b68
   38830: 61 a1 f8 fb 00 00 00 00      	ldxw r1, [r10 - 0x408]
   38838: 55 01 3a 00 02 00 00 00      	jne r1, 0x2, +0x3a <.text+0x388f0>
   38840: 79 a8 08 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3f8]
   38848: 79 a7 00 fc 00 00 00 00      	ldxdw r7, [r10 - 0x400]
   38850: 85 10 00 00 b3 95 00 00      	call 0x95b3
   38858: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   38868: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   38870: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   38878: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   38880: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   38888: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   38890: 2d 21 79 00 00 00 00 00      	jgt r1, r2, +0x79 <.text+0x38b40>
   38898: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   388a0: 15 04 78 00 00 00 00 00      	jeq r4, 0x0, +0x78 <.text+0x38b48>
   388a8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   388b8: 15 02 79 00 00 00 00 00      	jeq r2, 0x0, +0x79 <.text+0x38b68>
   388c0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   388c8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   388d8: 15 07 78 00 01 00 00 00      	jeq r7, 0x1, +0x78 <.text+0x38b80>
   388e0: bd 21 78 00 00 00 00 00      	jle r1, r2, +0x78 <.text+0x38b88>
   388e8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   388f8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   38900: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   38908: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   38910: 7b 18 10 00 00 00 00 00      	stxdw [r8 + 0x10], r1
   38918: 7a 08 18 00 04 00 00 00      	stdw [r8 + 0x18], 0x4
   38920: 7a 08 08 00 04 00 00 00      	stdw [r8 + 0x8], 0x4
   38928: 7a 08 00 00 01 00 00 00      	stdw [r8 + 0x0], 0x1
   38930: 7b 86 10 00 00 00 00 00      	stxdw [r6 + 0x10], r8
   38938: 05 00 61 00 00 00 00 00      	ja +0x61 <.text+0x38b28>
   38940: 79 a5 18 fb 00 00 00 00      	ldxdw r5, [r10 - 0x4e8]
   38948: 55 04 bd ff 00 00 00 00      	jne r4, 0x0, -0x43 <.text+0x38618>
   38950: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   38958: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   38968: 55 02 bc ff 00 00 00 00      	jne r2, 0x0, -0x44 <.text+0x38630>
   38970: bf 52 00 00 00 00 00 00      	mov64 r2, r5
   38978: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   38980: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   38990: bd 21 bd ff 00 00 00 00      	jle r1, r2, -0x43 <.text+0x38660>
   38998: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   389a8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   389b0: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   389c0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   389c8: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   389d0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   389d8: 7b 19 10 00 00 00 00 00      	stxdw [r9 + 0x10], r1
   389e0: 7a 09 18 00 0c 00 00 00      	stdw [r9 + 0x18], 0xc
   389e8: 7a 09 08 00 0c 00 00 00      	stdw [r9 + 0x8], 0xc
   389f0: 7a 09 00 00 01 00 00 00      	stdw [r9 + 0x0], 0x1
   389f8: 7b 96 10 00 00 00 00 00      	stxdw [r6 + 0x10], r9
   38a00: 7b 56 08 00 00 00 00 00      	stxdw [r6 + 0x8], r5
   38a08: 05 00 48 00 00 00 00 00      	ja +0x48 <.text+0x38b30>
   38a10: 7b 7a f0 fa 00 00 00 00      	stxdw [r10 - 0x510], r7
   38a18: 7b 1a d8 fa 00 00 00 00      	stxdw [r10 - 0x528], r1
   38a20: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   38a28: 7b 1a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r1
   38a30: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   38a38: 7b 1a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r1
   38a40: 61 a1 fc fb 00 00 00 00      	ldxw r1, [r10 - 0x404]
   38a48: 7b 1a d0 fa 00 00 00 00      	stxdw [r10 - 0x530], r1
   38a50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38a58: 07 01 00 00 98 fc ff ff      	add64 r1, -0x368
   38a60: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   38a68: 07 02 00 00 10 fc ff ff      	add64 r2, -0x3f0
   38a70: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   38a78: 85 10 00 00 61 e3 00 00      	call 0xe361
   38a80: 79 a1 58 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a8]
   38a88: 7b 1a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r1
   38a90: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   38a98: 7b 1a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r1
   38aa0: 79 a1 68 fc 00 00 00 00      	ldxdw r1, [r10 - 0x398]
   38aa8: 7b 1a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r1
   38ab0: 79 a1 70 fc 00 00 00 00      	ldxdw r1, [r10 - 0x390]
   38ab8: 7b 1a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r1
   38ac0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   38ac8: 7b 1a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r1
   38ad0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38ad8: 07 01 00 00 d8 fc ff ff      	add64 r1, -0x328
   38ae0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   38ae8: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   38af0: 85 10 00 00 50 94 ff ff      	call -0x6bb0
   38af8: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   38b00: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   38b08: 79 a7 d8 fc 00 00 00 00      	ldxdw r7, [r10 - 0x328]
   38b10: 61 a1 88 fd 00 00 00 00      	ldxw r1, [r10 - 0x278]
   38b18: 55 01 36 00 02 00 00 00      	jne r1, 0x2, +0x36 <.text+0x38bb0>
   38b20: 85 10 00 00 59 95 00 00      	call 0x9559
   38b28: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   38b38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   38b40: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   38b48: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   38b50: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   38b58: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   38b60: 2d 21 5d 00 00 00 00 00      	jgt r1, r2, +0x5d <.text+0x38d30>
   38b68: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   38b70: 15 04 5c 00 00 00 00 00      	jeq r4, 0x0, +0x5c <.text+0x38d38>
   38b78: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   38b88: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x38a78>
   38b90: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   38b98: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   38ba0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   38ba8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   38bb8: 79 a3 00 fb 00 00 00 00      	ldxdw r3, [r10 - 0x500]
   38bc0: bd 21 26 04 00 00 00 00      	jle r1, r2, +0x426 <.text+0x3abd8>
   38bc8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   38bd8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   38be0: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   38bf0: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   38bf8: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   38c08: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   38c10: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   38c18: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   38c20: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   38c28: 7a 03 18 00 12 00 00 00      	stdw [r3 + 0x18], 0x12
   38c30: 7a 03 08 00 12 00 00 00      	stdw [r3 + 0x8], 0x12
   38c38: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   38c40: 7b 36 10 00 00 00 00 00      	stxdw [r6 + 0x10], r3
   38c48: 7b 76 08 00 00 00 00 00      	stxdw [r6 + 0x8], r7
   38c50: 62 06 00 00 02 00 00 00      	stw [r6 + 0x0], 0x2
   38c58: 95 00 00 00 00 00 00 00      	exit
   38c60: 55 04 88 ff 00 00 00 00      	jne r4, 0x0, -0x78 <.text+0x38788>
   38c68: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   38c70: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   38c80: 55 02 87 ff 00 00 00 00      	jne r2, 0x0, -0x79 <.text+0x387a0>
   38c88: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   38c98: 55 07 88 ff 01 00 00 00      	jne r7, 0x1, -0x78 <.text+0x387c0>
   38ca0: 2d 21 88 ff 00 00 00 00      	jgt r1, r2, -0x78 <.text+0x387c8>
   38ca8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   38cb0: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   38cb8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   38cc8: 85 10 00 00 6f d5 00 00      	call 0xd56f
   38cd0: 7b 1a a0 fa 00 00 00 00      	stxdw [r10 - 0x560], r1
   38cd8: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   38ce0: 7b 1a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r1
   38ce8: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   38cf0: 7b 1a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r1
   38cf8: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   38d00: 7b 1a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r1
   38d08: 79 a1 08 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2f8]
   38d10: 7b 1a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r1
   38d18: 79 a1 10 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2f0]
   38d20: 7b 1a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r1
   38d28: 79 a1 18 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2e8]
   38d30: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   38d38: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   38d40: 7b 1a c8 fa 00 00 00 00      	stxdw [r10 - 0x538], r1
   38d48: 79 a1 20 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2e0]
   38d50: 7b 1a c0 fa 00 00 00 00      	stxdw [r10 - 0x540], r1
   38d58: 79 a1 28 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2d8]
   38d60: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   38d68: 79 a1 30 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2d0]
   38d70: 7b 1a b0 fa 00 00 00 00      	stxdw [r10 - 0x550], r1
   38d78: 79 a1 38 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2c8]
   38d80: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   38d88: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38d90: 07 01 00 00 d8 fd ff ff      	add64 r1, -0x228
   38d98: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   38da0: 07 02 00 00 40 fd ff ff      	add64 r2, -0x2c0
   38da8: b7 03 00 00 48 00 00 00      	mov64 r3, 0x48
   38db0: 85 10 00 00 fa e2 00 00      	call 0xe2fa
   38db8: 61 a1 ac fd 00 00 00 00      	ldxw r1, [r10 - 0x254]
   38dc0: 63 1a d0 fd 00 00 00 00      	stxw [r10 - 0x230], r1
   38dc8: 79 a1 a4 fd 00 00 00 00      	ldxdw r1, [r10 - 0x25c]
   38dd0: 7b 1a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r1
   38dd8: 79 a1 9c fd 00 00 00 00      	ldxdw r1, [r10 - 0x264]
   38de0: 7b 1a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r1
   38de8: 79 a1 94 fd 00 00 00 00      	ldxdw r1, [r10 - 0x26c]
   38df0: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   38df8: 79 a1 8c fd 00 00 00 00      	ldxdw r1, [r10 - 0x274]
   38e00: 7b 1a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r1
   38e08: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   38e10: 15 01 0d 00 00 00 00 00      	jeq r1, 0x0, +0xd <.text+0x38d60>
   38e18: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   38e20: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   38e28: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   38e30: 7b 1a 98 fa 00 00 00 00      	stxdw [r10 - 0x568], r1
   38e38: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   38e40: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   38e48: 05 00 0a 00 00 00 00 00      	ja +0xa <.text+0x38d80>
   38e50: 55 04 a4 ff 00 00 00 00      	jne r4, 0x0, -0x5c <.text+0x38a58>
   38e58: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   38e60: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   38e70: 55 02 a3 ff 00 00 00 00      	jne r2, 0x0, -0x5d <.text+0x38a70>
   38e78: 05 00 a3 ff 00 00 00 00      	ja -0x5d <.text+0x38a78>
   38e80: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   38e88: 85 10 00 00 eb c2 00 00      	call 0xc2eb
   38e90: 55 00 70 00 02 00 00 00      	jne r0, 0x2, +0x70 <.text+0x390f8>
   38e98: 7b 1a 98 fa 00 00 00 00      	stxdw [r10 - 0x568], r1
   38ea0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   38ea8: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
   38eb0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   38eb8: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   38ec0: 85 10 00 00 5f a2 ff ff      	call -0x5da1
   38ec8: 71 a1 f9 ff 00 00 00 00      	ldxb r1, [r10 - 0x7]
   38ed0: 55 01 23 00 02 00 00 00      	jne r1, 0x2, +0x23 <.text+0x38ed0>
   38ed8: 79 a8 b0 ff 00 00 00 00      	ldxdw r8, [r10 - 0x50]
   38ee0: 79 a7 a8 ff 00 00 00 00      	ldxdw r7, [r10 - 0x58]
   38ee8: 85 10 00 00 e0 94 00 00      	call 0x94e0
   38ef0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   38f00: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   38f08: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   38f10: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   38f18: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   38f20: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   38f28: 2d 21 2e 00 00 00 00 00      	jgt r1, r2, +0x2e <.text+0x38f80>
   38f30: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   38f38: 15 04 2d 00 00 00 00 00      	jeq r4, 0x0, +0x2d <.text+0x38f88>
   38f40: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   38f50: 15 02 2e 00 00 00 00 00      	jeq r2, 0x0, +0x2e <.text+0x38fa8>
   38f58: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   38f60: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   38f70: 15 07 2d 00 01 00 00 00      	jeq r7, 0x1, +0x2d <.text+0x38fc0>
   38f78: bd 21 2d 00 00 00 00 00      	jle r1, r2, +0x2d <.text+0x38fc8>
   38f80: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   38f90: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   38f98: 18 02 00 00 6e 67 5f 63 00 00 00 00 75 72 76 65      	lddw r2, 0x65767275635f676e
   38fa8: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   38fb0: 18 02 00 00 62 6f 6e 64 00 00 00 00 69 6e 67 5f      	lddw r2, 0x5f676e69646e6f62
   38fc0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   38fc8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   38fd0: 7b 18 10 00 00 00 00 00      	stxdw [r8 + 0x10], r1
   38fd8: 7a 08 18 00 0d 00 00 00      	stdw [r8 + 0x18], 0xd
   38fe0: 7a 08 08 00 0d 00 00 00      	stdw [r8 + 0x8], 0xd
   38fe8: 05 00 27 ff 00 00 00 00      	ja -0xd9 <.text+0x38808>
   38ff0: 85 10 00 00 bf 94 00 00      	call 0x94bf
   38ff8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   39008: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   39010: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   39018: 07 03 00 00 a8 ff ff ff      	add64 r3, -0x58
   39020: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   39028: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   39030: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x38ff0>
   39038: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   39040: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x38ff8>
   39048: 18 01 00 00 a8 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fa8
   39058: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x39018>
   39060: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   39068: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   39070: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   39080: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x39030>
   39088: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   39090: b7 02 00 00 58 00 00 00      	mov64 r2, 0x58
   39098: 85 10 00 00 f9 d4 00 00      	call 0xd4f9
   390a0: 55 04 d3 ff 00 00 00 00      	jne r4, 0x0, -0x2d <.text+0x38e20>
   390a8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   390b0: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   390c0: 55 02 d2 ff 00 00 00 00      	jne r2, 0x0, -0x2e <.text+0x38e38>
   390c8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   390d8: 55 07 d3 ff 01 00 00 00      	jne r7, 0x1, -0x2d <.text+0x38e58>
   390e0: 2d 21 d3 ff 00 00 00 00      	jgt r1, r2, -0x2d <.text+0x38e60>
   390e8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   390f0: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   390f8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   39108: 85 10 00 00 e7 d4 00 00      	call 0xd4e7
   39110: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x38f28>
   39118: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   39120: 18 01 00 00 a8 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fa8
   39130: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x38f40>
   39138: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   39148: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x38f68>
   39150: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   39160: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   39168: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   39170: 07 02 00 00 a8 ff ff ff      	add64 r2, -0x58
   39178: 7b 1a 90 fa 00 00 00 00      	stxdw [r10 - 0x570], r1
   39180: b7 03 00 00 58 00 00 00      	mov64 r3, 0x58
   39188: 85 10 00 00 7f e2 00 00      	call 0xe27f
   39190: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   39198: 15 01 3d 00 00 00 00 00      	jeq r1, 0x0, +0x3d <.text+0x39268>
   391a0: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   391a8: 7b 2a 88 fa 00 00 00 00      	stxdw [r10 - 0x578], r2
   391b0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   391b8: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   391c0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   391c8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   391d0: 15 01 3b 00 00 00 00 00      	jeq r1, 0x0, +0x3b <.text+0x39290>
   391d8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   391e0: 7b 2a 80 fa 00 00 00 00      	stxdw [r10 - 0x580], r2
   391e8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   391f0: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   391f8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   39200: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   39208: 55 01 48 00 00 00 00 00      	jne r1, 0x0, +0x48 <.text+0x39330>
   39210: 05 00 38 00 00 00 00 00      	ja +0x38 <.text+0x392b8>
   39218: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   39220: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   39228: 85 10 00 00 78 94 00 00      	call 0x9478
   39230: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   39240: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   39248: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   39250: 07 01 00 00 f7 ff ff ff      	add64 r1, -0x9
   39258: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   39260: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   39268: 2d 21 1c 00 00 00 00 00      	jgt r1, r2, +0x1c <.text+0x39230>
   39270: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   39278: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x39238>
   39280: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   39290: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   39298: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x39188>
   392a0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   392a8: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   392b0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   392b8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   392c8: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   392d0: bd 21 81 03 00 00 00 00      	jle r1, r2, +0x381 <.text+0x3adc0>
   392d8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   392e8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   392f0: 18 02 00 00 73 6f 6c 5f 00 00 00 00 76 61 75 6c      	lddw r2, 0x6c7561765f6c6f73
   39300: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   39308: 72 01 08 00 74 00 00 00      	stb [r1 + 0x8], 0x74
   39310: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   39318: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   39320: 7a 03 18 00 09 00 00 00      	stdw [r3 + 0x18], 0x9
   39328: 7a 03 08 00 09 00 00 00      	stdw [r3 + 0x8], 0x9
   39330: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   39338: 7b 36 10 00 00 00 00 00      	stxdw [r6 + 0x10], r3
   39340: 7b 46 08 00 00 00 00 00      	stxdw [r6 + 0x8], r4
   39348: 05 00 20 ff 00 00 00 00      	ja -0xe0 <.text+0x38b30>
   39350: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x39160>
   39358: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   39360: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   39370: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   39378: 55 02 e4 ff 00 00 00 00      	jne r2, 0x0, -0x1c <.text+0x39180>
   39380: 05 00 e4 ff 00 00 00 00      	ja -0x1c <.text+0x39188>
   39388: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   39390: 85 10 00 00 4a c2 00 00      	call 0xc24a
   39398: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   393a0: 55 00 55 00 02 00 00 00      	jne r0, 0x2, +0x55 <.text+0x39530>
   393a8: 7b 2a 88 fa 00 00 00 00      	stxdw [r10 - 0x578], r2
   393b0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   393b8: 85 10 00 00 45 c2 00 00      	call 0xc245
   393c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   393c8: 55 00 07 00 02 00 00 00      	jne r0, 0x2, +0x7 <.text+0x392e8>
   393d0: 7b 2a 80 fa 00 00 00 00      	stxdw [r10 - 0x580], r2
   393d8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   393e0: 85 10 00 00 40 c2 00 00      	call 0xc240
   393e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   393f0: 55 00 12 00 02 00 00 00      	jne r0, 0x2, +0x12 <.text+0x39368>
   393f8: 7b 2a 78 fa 00 00 00 00      	stxdw [r10 - 0x588], r2
   39400: 05 00 17 00 00 00 00 00      	ja +0x17 <.text+0x393a0>
   39408: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39410: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   39420: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   39428: 85 10 00 00 1c 95 ff ff      	call -0x6ae4
   39430: 55 00 af 02 02 00 00 00      	jne r0, 0x2, +0x2af <.text+0x3a890>
   39438: 7b 1a 80 fa 00 00 00 00      	stxdw [r10 - 0x580], r1
   39440: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   39448: 15 01 f1 ff 00 00 00 00      	jeq r1, 0x0, -0xf <.text+0x392b8>
   39450: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   39458: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   39460: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   39468: 7b 1a 78 fa 00 00 00 00      	stxdw [r10 - 0x588], r1
   39470: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   39478: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   39480: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x393a0>
   39488: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39490: 18 03 00 00 fa db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbfa
   394a0: b7 04 00 00 14 00 00 00      	mov64 r4, 0x14
   394a8: 85 10 00 00 0c 95 ff ff      	call -0x6af4
   394b0: 55 00 9f 02 02 00 00 00      	jne r0, 0x2, +0x29f <.text+0x3a890>
   394b8: 7b 1a 78 fa 00 00 00 00      	stxdw [r10 - 0x588], r1
   394c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   394c8: 07 01 00 00 50 fe ff ff      	add64 r1, -0x1b0
   394d0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   394d8: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   394e0: 85 10 00 00 df a1 ff ff      	call -0x5e21
   394e8: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   394f0: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   394f8: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x393f0>
   39500: 7b 2a 70 fa 00 00 00 00      	stxdw [r10 - 0x590], r2
   39508: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x39420>
   39510: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   39520: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   39528: 85 10 00 00 fc 94 ff ff      	call -0x6b04
   39530: 55 00 8f 02 02 00 00 00      	jne r0, 0x2, +0x28f <.text+0x3a890>
   39538: 7b 1a 70 fa 00 00 00 00      	stxdw [r10 - 0x590], r1
   39540: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39548: 07 01 00 00 60 fe ff ff      	add64 r1, -0x1a0
   39550: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   39558: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   39560: 85 10 00 00 77 8d ff ff      	call -0x7289
   39568: 79 a2 68 fe 00 00 00 00      	ldxdw r2, [r10 - 0x198]
   39570: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   39578: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x39490>
   39580: 18 03 00 00 89 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb89
   39590: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   39598: 85 10 00 00 ee 94 ff ff      	call -0x6b12
   395a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   395a8: 55 00 2a 00 02 00 00 00      	jne r0, 0x2, +0x2a <.text+0x395e0>
   395b0: 7b 2a 68 fa 00 00 00 00      	stxdw [r10 - 0x598], r2
   395b8: 79 83 08 00 00 00 00 00      	ldxdw r3, [r8 + 0x8]
   395c0: 15 03 1b 00 00 00 00 00      	jeq r3, 0x0, +0x1b <.text+0x39580>
   395c8: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   395d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   395d8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   395e0: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   395e8: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   395f0: 7b 38 08 00 00 00 00 00      	stxdw [r8 + 0x8], r3
   395f8: 7b 1a 60 fa 00 00 00 00      	stxdw [r10 - 0x5a0], r1
   39600: 15 03 18 00 00 00 00 00      	jeq r3, 0x0, +0x18 <.text+0x395a8>
   39608: 7b 7a 58 fa 00 00 00 00      	stxdw [r10 - 0x5a8], r7
   39610: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   39618: 7b 38 08 00 00 00 00 00      	stxdw [r8 + 0x8], r3
   39620: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   39628: 7b 1a 50 fa 00 00 00 00      	stxdw [r10 - 0x5b0], r1
   39630: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   39638: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   39640: 79 a8 18 fb 00 00 00 00      	ldxdw r8, [r10 - 0x4e8]
   39648: 05 00 20 00 00 00 00 00      	ja +0x20 <.text+0x39630>
   39650: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39658: 18 03 00 00 e8 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbe8
   39668: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   39670: 85 10 00 00 d3 94 ff ff      	call -0x6b2d
   39678: 55 00 66 02 02 00 00 00      	jne r0, 0x2, +0x266 <.text+0x3a890>
   39680: 7b 1a 88 fa 00 00 00 00      	stxdw [r10 - 0x578], r1
   39688: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   39690: 55 01 68 ff 00 00 00 00      	jne r1, 0x0, -0x98 <.text+0x390b8>
   39698: 05 00 a2 ff 00 00 00 00      	ja -0x5e <.text+0x39290>
   396a0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   396a8: 85 10 00 00 e7 c1 00 00      	call 0xc1e7
   396b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   396b8: 55 00 6e 00 02 00 00 00      	jne r0, 0x2, +0x6e <.text+0x39910>
   396c0: 7b 2a 60 fa 00 00 00 00      	stxdw [r10 - 0x5a0], r2
   396c8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   396d0: 85 10 00 00 e2 c1 00 00      	call 0xc1e2
   396d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   396e0: 79 a8 18 fb 00 00 00 00      	ldxdw r8, [r10 - 0x4e8]
   396e8: 55 00 04 00 02 00 00 00      	jne r0, 0x2, +0x4 <.text+0x395f0>
   396f0: 7b 2a 50 fa 00 00 00 00      	stxdw [r10 - 0x5b0], r2
   396f8: 05 00 09 00 00 00 00 00      	ja +0x9 <.text+0x39628>
   39700: 7b 26 10 00 00 00 00 00      	stxdw [r6 + 0x10], r2
   39708: 05 00 55 02 00 00 00 00      	ja +0x255 <.text+0x3a898>
   39710: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39718: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   39728: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   39730: 85 10 00 00 bb 94 ff ff      	call -0x6b45
   39738: 55 00 4e 02 02 00 00 00      	jne r0, 0x2, +0x24e <.text+0x3a890>
   39740: 7b 1a 50 fa 00 00 00 00      	stxdw [r10 - 0x5b0], r1
   39748: 7b 7a 58 fa 00 00 00 00      	stxdw [r10 - 0x5a8], r7
   39750: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   39760: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39768: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
   39770: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39778: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
   39780: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39788: 7b 2a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r2
   39790: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39798: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   397a0: 7a 0a c8 ff 00 00 00 00      	stdw [r10 - 0x38], 0x0
   397a8: 7a 0a d0 ff 00 00 00 00      	stdw [r10 - 0x30], 0x0
   397b0: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   397b8: 07 07 00 00 70 fe ff ff      	add64 r7, -0x190
   397c0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   397c8: 07 02 00 00 a8 ff ff ff      	add64 r2, -0x58
   397d0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   397d8: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   397e0: 85 10 00 00 b4 e1 00 00      	call 0xe1b4
   397e8: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   397f0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   397f8: 7b 2a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r2
   39800: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39808: 7b 2a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r2
   39810: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39818: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   39820: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39828: 7b 1a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r1
   39830: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   39838: 07 02 00 00 a0 fe ff ff      	add64 r2, -0x160
   39840: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   39848: 85 10 00 00 64 a2 ff ff      	call -0x5d9c
   39850: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x39778>
   39858: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   39860: 85 10 00 00 b0 c1 00 00      	call 0xc1b0
   39868: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   39870: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39878: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   39888: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   39890: 05 00 2f 00 00 00 00 00      	ja +0x2f <.text+0x398f0>
   39898: 79 a7 f8 fa 00 00 00 00      	ldxdw r7, [r10 - 0x508]
   398a0: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   398a8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   398b0: 7b 2a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r2
   398b8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   398c0: 7b 2a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r2
   398c8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   398d0: 7b 2a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r2
   398d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   398e0: 7b 1a c0 fe 00 00 00 00      	stxdw [r10 - 0x140], r1
   398e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   398f0: 07 01 00 00 70 fe ff ff      	add64 r1, -0x190
   398f8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   39900: 07 02 00 00 c0 fe ff ff      	add64 r2, -0x140
   39908: 85 10 00 00 4c a2 ff ff      	call -0x5db4
   39910: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x39838>
   39918: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   39920: 85 10 00 00 98 c1 00 00      	call 0xc198
   39928: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   39930: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39938: 18 03 00 00 bc d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad0bc
   39948: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   39950: 05 00 17 00 00 00 00 00      	ja +0x17 <.text+0x398f0>
   39958: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   39960: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39968: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39970: 7b 2a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r2
   39978: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39980: 7b 2a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r2
   39988: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39990: 7b 2a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r2
   39998: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   399a0: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
   399a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   399b0: 07 01 00 00 70 fe ff ff      	add64 r1, -0x190
   399b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   399c0: 07 02 00 00 e0 fe ff ff      	add64 r2, -0x120
   399c8: 85 10 00 00 34 a2 ff ff      	call -0x5dcc
   399d0: 15 00 15 00 00 00 00 00      	jeq r0, 0x0, +0x15 <.text+0x39960>
   399d8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   399e0: 85 10 00 00 80 c1 00 00      	call 0xc180
   399e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   399f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   399f8: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   39a08: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   39a10: 85 10 00 00 5f 94 ff ff      	call -0x6ba1
   39a18: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   39a20: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   39a28: 05 00 44 fe 00 00 00 00      	ja -0x1bc <.text+0x38b30>
   39a30: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39a38: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   39a48: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   39a50: 85 10 00 00 57 94 ff ff      	call -0x6ba9
   39a58: 55 00 ea 01 02 00 00 00      	jne r0, 0x2, +0x1ea <.text+0x3a890>
   39a60: 79 83 08 00 00 00 00 00      	ldxdw r3, [r8 + 0x8]
   39a68: 7b 1a 60 fa 00 00 00 00      	stxdw [r10 - 0x5a0], r1
   39a70: 55 03 72 ff 00 00 00 00      	jne r3, 0x0, -0x8e <.text+0x394e8>
   39a78: 05 00 89 ff 00 00 00 00      	ja -0x77 <.text+0x395a8>
   39a80: 79 a1 90 fa 00 00 00 00      	ldxdw r1, [r10 - 0x570]
   39a88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39a90: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39a98: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39aa0: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   39aa8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39ab0: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   39ab8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39ac0: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   39ac8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39ad0: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   39ad8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39ae0: 07 01 00 00 70 fe ff ff      	add64 r1, -0x190
   39ae8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   39af0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   39af8: 85 10 00 00 0e a2 ff ff      	call -0x5df2
   39b00: 15 00 09 00 00 00 00 00      	jeq r0, 0x0, +0x9 <.text+0x39a30>
   39b08: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   39b10: 85 10 00 00 5a c1 00 00      	call 0xc15a
   39b18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   39b20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   39b28: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   39b38: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   39b40: 85 10 00 00 39 94 ff ff      	call -0x6bc7
   39b48: 05 00 cc 01 00 00 00 00      	ja +0x1cc <.text+0x3a890>
   39b50: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   39b58: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39b60: 7b 2a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r2
   39b68: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39b70: 7b 2a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r2
   39b78: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39b80: 7b 2a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r2
   39b88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39b90: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   39b98: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39ba0: 07 01 00 00 70 fe ff ff      	add64 r1, -0x190
   39ba8: 7b 1a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r1
   39bb0: 18 01 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xadc0e
   39bc0: 7b 1a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r1
   39bc8: 7a 0a 98 ff 20 00 00 00      	stdw [r10 - 0x68], 0x20
   39bd0: 7a 0a 88 ff 0c 00 00 00      	stdw [r10 - 0x78], 0xc
   39bd8: 72 0a 60 ff ff 00 00 00      	stb [r10 - 0xa0], 0xff
   39be0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39be8: 07 01 00 00 80 ff ff ff      	add64 r1, -0x80
   39bf0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   39bf8: 07 04 00 00 a8 ff ff ff      	add64 r4, -0x58
   39c00: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   39c08: 07 05 00 00 60 ff ff ff      	add64 r5, -0xa0
   39c10: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   39c18: 79 a3 10 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4f0]
   39c20: 85 10 00 00 ff ff ff ff      	call -0x1
   39c28: 55 00 ed 01 00 00 00 00      	jne r0, 0x0, +0x1ed <.text+0x3aa78>
   39c30: 79 a4 c0 ff 00 00 00 00      	ldxdw r4, [r10 - 0x40]
   39c38: 79 a3 b8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x48]
   39c40: 79 a8 b0 ff 00 00 00 00      	ldxdw r8, [r10 - 0x50]
   39c48: 79 a7 a8 ff 00 00 00 00      	ldxdw r7, [r10 - 0x58]
   39c50: 71 a1 60 ff 00 00 00 00      	ldxb r1, [r10 - 0xa0]
   39c58: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   39c60: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   39c68: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   39c70: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39c78: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   39c80: 5d 72 6f 01 00 00 00 00      	jne r2, r7, +0x16f <.text+0x3a6e0>
   39c88: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39c90: 5d 82 6d 01 00 00 00 00      	jne r2, r8, +0x16d <.text+0x3a6e0>
   39c98: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39ca0: 5d 32 6b 01 00 00 00 00      	jne r2, r3, +0x16b <.text+0x3a6e0>
   39ca8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   39cb0: 5d 41 69 01 00 00 00 00      	jne r1, r4, +0x169 <.text+0x3a6e0>
   39cb8: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   39cc0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   39cc8: 15 01 85 01 00 00 00 00      	jeq r1, 0x0, +0x185 <.text+0x3a7d8>
   39cd0: 79 a2 f8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x508]
   39cd8: 71 21 29 00 00 00 00 00      	ldxb r1, [r2 + 0x29]
   39ce0: 15 01 8b 01 00 00 00 00      	jeq r1, 0x0, +0x18b <.text+0x3a820>
   39ce8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39cf0: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
   39cf8: 85 10 00 00 12 9f ff ff      	call -0x60ee
   39d00: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   39d08: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   39d10: 79 a2 c8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x538]
   39d18: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   39d20: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   39d28: 5d 34 8b 01 00 00 00 00      	jne r4, r3, +0x18b <.text+0x3a868>
   39d30: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   39d38: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   39d40: 5d 34 88 01 00 00 00 00      	jne r4, r3, +0x188 <.text+0x3a868>
   39d48: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   39d50: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   39d58: 5d 34 85 01 00 00 00 00      	jne r4, r3, +0x185 <.text+0x3a868>
   39d60: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   39d68: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   39d70: 5d 12 82 01 00 00 00 00      	jne r2, r1, +0x182 <.text+0x3a868>
   39d78: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39d80: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
   39d88: 85 10 00 00 2a 9c ff ff      	call -0x63d6
   39d90: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   39d98: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39da0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39da8: 7b 2a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r2
   39db0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39db8: 7b 2a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r2
   39dc0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39dc8: 7b 2a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r2
   39dd0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39dd8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   39de0: 79 a1 20 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe0]
   39de8: 79 a2 c0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x540]
   39df0: 5d 12 7a 01 00 00 00 00      	jne r2, r1, +0x17a <.text+0x3a8a8>
   39df8: 79 a1 28 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd8]
   39e00: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   39e08: 5d 12 77 01 00 00 00 00      	jne r2, r1, +0x177 <.text+0x3a8a8>
   39e10: 79 a1 30 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd0]
   39e18: 79 a2 b0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x550]
   39e20: 5d 12 74 01 00 00 00 00      	jne r2, r1, +0x174 <.text+0x3a8a8>
   39e28: 79 a1 38 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc8]
   39e30: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   39e38: 5d 12 71 01 00 00 00 00      	jne r2, r1, +0x171 <.text+0x3a8a8>
   39e40: 79 a2 f8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x508]
   39e48: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   39e50: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   39e58: 7b 3a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r3
   39e60: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   39e68: 7b 3a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r3
   39e70: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   39e78: 7b 3a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r3
   39e80: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39e88: 7b 1a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r1
   39e90: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   39e98: 07 07 00 00 a8 ff ff ff      	add64 r7, -0x58
   39ea0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   39ea8: 85 10 00 00 dc 9e ff ff      	call -0x6124
   39eb0: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   39eb8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   39ec0: 7b 2a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r2
   39ec8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   39ed0: 7b 2a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r2
   39ed8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39ee0: 7b 2a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r2
   39ee8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   39ef0: 7b 1a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r1
   39ef8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   39f00: 07 01 00 00 40 ff ff ff      	add64 r1, -0xc0
   39f08: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   39f10: 07 02 00 00 20 ff ff ff      	add64 r2, -0xe0
   39f18: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   39f20: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   39f28: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   39f30: 07 04 00 00 70 fe ff ff      	add64 r4, -0x190
   39f38: 85 10 00 00 a8 b7 00 00      	call 0xb7a8
   39f40: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   39f48: 85 10 00 00 f2 9b ff ff      	call -0x640e
   39f50: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   39f58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   39f60: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   39f68: 7b 2a 40 fa 00 00 00 00      	stxdw [r10 - 0x5c0], r2
   39f70: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   39f78: 7b 2a 48 fa 00 00 00 00      	stxdw [r10 - 0x5b8], r2
   39f80: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   39f88: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   39f90: 79 a1 40 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc0]
   39f98: 5d 17 5e 01 00 00 00 00      	jne r7, r1, +0x15e <.text+0x3a970>
   39fa0: 79 a1 48 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb8]
   39fa8: 5d 18 5c 01 00 00 00 00      	jne r8, r1, +0x15c <.text+0x3a970>
   39fb0: 79 a1 50 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb0]
   39fb8: 79 a2 48 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5b8]
   39fc0: 5d 12 59 01 00 00 00 00      	jne r2, r1, +0x159 <.text+0x3a970>
   39fc8: 79 a1 58 ff 00 00 00 00      	ldxdw r1, [r10 - 0xa8]
   39fd0: 79 a2 40 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5c0]
   39fd8: 5d 12 56 01 00 00 00 00      	jne r2, r1, +0x156 <.text+0x3a970>
   39fe0: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   39fe8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   39ff0: 15 01 6b 01 00 00 00 00      	jeq r1, 0x0, +0x16b <.text+0x3aa30>
   39ff8: 72 0a 70 fe ff 00 00 00      	stb [r10 - 0x190], 0xff
   3a000: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   3a008: 07 04 00 00 a8 ff ff ff      	add64 r4, -0x58
   3a010: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   3a018: 07 05 00 00 70 fe ff ff      	add64 r5, -0x190
   3a020: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   3a030: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3a038: 79 a3 10 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4f0]
   3a040: 85 10 00 00 ff ff ff ff      	call -0x1
   3a048: 55 00 69 01 00 00 00 00      	jne r0, 0x0, +0x169 <.text+0x3aa78>
   3a050: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   3a058: 7b 1a 40 fa 00 00 00 00      	stxdw [r10 - 0x5c0], r1
   3a060: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
   3a068: 7b 1a 48 fa 00 00 00 00      	stxdw [r10 - 0x5b8], r1
   3a070: 79 a8 b0 ff 00 00 00 00      	ldxdw r8, [r10 - 0x50]
   3a078: 79 a7 a8 ff 00 00 00 00      	ldxdw r7, [r10 - 0x58]
   3a080: 71 a1 70 fe 00 00 00 00      	ldxb r1, [r10 - 0x190]
   3a088: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   3a090: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   3a098: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   3a0a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a0a8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   3a0b0: 5d 72 68 01 00 00 00 00      	jne r2, r7, +0x168 <.text+0x3aad8>
   3a0b8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   3a0c0: 5d 82 66 01 00 00 00 00      	jne r2, r8, +0x166 <.text+0x3aad8>
   3a0c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   3a0d0: 79 a3 48 fa 00 00 00 00      	ldxdw r3, [r10 - 0x5b8]
   3a0d8: 5d 32 63 01 00 00 00 00      	jne r2, r3, +0x163 <.text+0x3aad8>
   3a0e0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   3a0e8: 79 a2 40 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5c0]
   3a0f0: 5d 21 60 01 00 00 00 00      	jne r1, r2, +0x160 <.text+0x3aad8>
   3a0f8: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   3a100: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   3a108: 15 01 74 01 00 00 00 00      	jeq r1, 0x0, +0x174 <.text+0x3ab90>
   3a110: 79 a1 f8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x508]
   3a118: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a120: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   3a128: 7b 2a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r2
   3a130: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   3a138: 7b 2a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r2
   3a140: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   3a148: 7b 2a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r2
   3a150: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a158: 7b 1a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r1
   3a160: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   3a168: 07 01 00 00 80 ff ff ff      	add64 r1, -0x80
   3a170: 7b 1a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r1
   3a178: 18 01 00 00 1a dc 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xadc1a
   3a188: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   3a190: 7a 0a 78 ff 20 00 00 00      	stdw [r10 - 0x88], 0x20
   3a198: 7a 0a 68 ff 0d 00 00 00      	stdw [r10 - 0x98], 0xd
   3a1a0: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   3a1b0: 7b 1a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r1
   3a1b8: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   3a1c8: 7b 1a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r1
   3a1d0: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   3a1e0: 7b 1a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r1
   3a1e8: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   3a1f8: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   3a200: 72 0a a7 ff ff 00 00 00      	stb [r10 - 0x59], 0xff
   3a208: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   3a210: 07 01 00 00 60 ff ff ff      	add64 r1, -0xa0
   3a218: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   3a220: 07 03 00 00 70 fe ff ff      	add64 r3, -0x190
   3a228: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   3a230: 07 04 00 00 a8 ff ff ff      	add64 r4, -0x58
   3a238: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   3a240: 07 05 00 00 a7 ff ff ff      	add64 r5, -0x59
   3a248: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   3a250: 85 10 00 00 ff ff ff ff      	call -0x1
   3a258: 55 00 27 01 00 00 00 00      	jne r0, 0x0, +0x127 <.text+0x3aa78>
   3a260: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   3a268: 7b 1a 40 fa 00 00 00 00      	stxdw [r10 - 0x5c0], r1
   3a270: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
   3a278: 7b 1a 48 fa 00 00 00 00      	stxdw [r10 - 0x5b8], r1
   3a280: 79 a7 b0 ff 00 00 00 00      	ldxdw r7, [r10 - 0x50]
   3a288: 79 a8 a8 ff 00 00 00 00      	ldxdw r8, [r10 - 0x58]
   3a290: 71 a1 a7 ff 00 00 00 00      	ldxb r1, [r10 - 0x59]
   3a298: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   3a2a0: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   3a2a8: 79 a1 90 fa 00 00 00 00      	ldxdw r1, [r10 - 0x570]
   3a2b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a2b8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   3a2c0: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   3a2c8: 5d 83 4a 01 00 00 00 00      	jne r3, r8, +0x14a <.text+0x3ac00>
   3a2d0: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   3a2d8: 5d 73 48 01 00 00 00 00      	jne r3, r7, +0x148 <.text+0x3ac00>
   3a2e0: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   3a2e8: 79 a4 48 fa 00 00 00 00      	ldxdw r4, [r10 - 0x5b8]
   3a2f0: 5d 43 45 01 00 00 00 00      	jne r3, r4, +0x145 <.text+0x3ac00>
   3a2f8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   3a300: 79 a3 40 fa 00 00 00 00      	ldxdw r3, [r10 - 0x5c0]
   3a308: 5d 32 42 01 00 00 00 00      	jne r2, r3, +0x142 <.text+0x3ac00>
   3a310: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   3a318: 15 01 5b 01 00 00 00 00      	jeq r1, 0x0, +0x15b <.text+0x3acd8>
   3a320: 79 a1 80 fa 00 00 00 00      	ldxdw r1, [r10 - 0x580]
   3a328: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a330: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   3a338: 7b 2a 40 fa 00 00 00 00      	stxdw [r10 - 0x5c0], r2
   3a340: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   3a348: 7b 2a 48 fa 00 00 00 00      	stxdw [r10 - 0x5b8], r2
   3a350: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   3a358: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   3a360: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   3a370: 5d 17 52 01 00 00 00 00      	jne r7, r1, +0x152 <.text+0x3ace8>
   3a378: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   3a388: 5d 18 4f 01 00 00 00 00      	jne r8, r1, +0x14f <.text+0x3ace8>
   3a390: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   3a3a0: 79 a2 48 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5b8]
   3a3a8: 5d 12 4b 01 00 00 00 00      	jne r2, r1, +0x14b <.text+0x3ace8>
   3a3b0: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   3a3c0: 79 a2 40 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5c0]
   3a3c8: 5d 12 47 01 00 00 00 00      	jne r2, r1, +0x147 <.text+0x3ace8>
   3a3d0: 72 0a 70 fe ff 00 00 00      	stb [r10 - 0x190], 0xff
   3a3d8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   3a3e0: 07 04 00 00 a8 ff ff ff      	add64 r4, -0x58
   3a3e8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   3a3f0: 07 05 00 00 70 fe ff ff      	add64 r5, -0x190
   3a3f8: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   3a408: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3a410: 79 a3 10 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4f0]
   3a418: 85 10 00 00 ff ff ff ff      	call -0x1
   3a420: 55 00 ee 00 00 00 00 00      	jne r0, 0x0, +0xee <.text+0x3aa78>
   3a428: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   3a430: 7b 1a 48 fa 00 00 00 00      	stxdw [r10 - 0x5b8], r1
   3a438: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
   3a440: 7b 1a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r1
   3a448: 79 a8 b0 ff 00 00 00 00      	ldxdw r8, [r10 - 0x50]
   3a450: 79 a7 a8 ff 00 00 00 00      	ldxdw r7, [r10 - 0x58]
   3a458: 71 a1 70 fe 00 00 00 00      	ldxb r1, [r10 - 0x190]
   3a460: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   3a468: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   3a470: 79 a1 60 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5a0]
   3a478: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a480: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   3a488: 5d 72 4f 01 00 00 00 00      	jne r2, r7, +0x14f <.text+0x3ade8>
   3a490: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   3a498: 5d 82 4d 01 00 00 00 00      	jne r2, r8, +0x14d <.text+0x3ade8>
   3a4a0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   3a4a8: 79 a3 10 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4f0]
   3a4b0: 5d 32 4a 01 00 00 00 00      	jne r2, r3, +0x14a <.text+0x3ade8>
   3a4b8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   3a4c0: 79 a2 48 fa 00 00 00 00      	ldxdw r2, [r10 - 0x5b8]
   3a4c8: 5d 21 47 01 00 00 00 00      	jne r1, r2, +0x147 <.text+0x3ade8>
   3a4d0: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3a4d8: 07 01 00 00 68 01 00 00      	add64 r1, 0x168
   3a4e0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   3a4e8: 07 02 00 00 98 fb ff ff      	add64 r2, -0x468
   3a4f0: b7 03 00 00 59 00 00 00      	mov64 r3, 0x59
   3a4f8: 85 10 00 00 11 e0 00 00      	call 0xe011
   3a500: 61 a1 90 fb 00 00 00 00      	ldxw r1, [r10 - 0x470]
   3a508: 63 16 c2 01 00 00 00 00      	stxw [r6 + 0x1c2], r1
   3a510: 69 a1 94 fb 00 00 00 00      	ldxh r1, [r10 - 0x46c]
   3a518: 6b 16 c6 01 00 00 00 00      	stxh [r6 + 0x1c6], r1
   3a520: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3a528: 07 01 00 00 18 00 00 00      	add64 r1, 0x18
   3a530: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   3a538: 07 02 00 00 98 fc ff ff      	add64 r2, -0x368
   3a540: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   3a548: 85 10 00 00 07 e0 00 00      	call 0xe007
   3a550: 79 a1 90 fc 00 00 00 00      	ldxdw r1, [r10 - 0x370]
   3a558: 7b 16 78 00 00 00 00 00      	stxdw [r6 + 0x78], r1
   3a560: 79 a1 88 fc 00 00 00 00      	ldxdw r1, [r10 - 0x378]
   3a568: 7b 16 70 00 00 00 00 00      	stxdw [r6 + 0x70], r1
   3a570: 79 a1 80 fc 00 00 00 00      	ldxdw r1, [r10 - 0x380]
   3a578: 7b 16 68 00 00 00 00 00      	stxdw [r6 + 0x68], r1
   3a580: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   3a588: 7b 16 60 00 00 00 00 00      	stxdw [r6 + 0x60], r1
   3a590: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   3a598: 7b 16 90 00 00 00 00 00      	stxdw [r6 + 0x90], r1
   3a5a0: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   3a5a8: 7b 16 98 00 00 00 00 00      	stxdw [r6 + 0x98], r1
   3a5b0: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   3a5b8: 7b 16 b0 00 00 00 00 00      	stxdw [r6 + 0xb0], r1
   3a5c0: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   3a5c8: 7b 16 c0 00 00 00 00 00      	stxdw [r6 + 0xc0], r1
   3a5d0: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   3a5d8: 7b 16 a8 00 00 00 00 00      	stxdw [r6 + 0xa8], r1
   3a5e0: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   3a5e8: 7b 16 b8 00 00 00 00 00      	stxdw [r6 + 0xb8], r1
   3a5f0: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3a5f8: 07 01 00 00 e8 00 00 00      	add64 r1, 0xe8
   3a600: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   3a608: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   3a610: b7 03 00 00 48 00 00 00      	mov64 r3, 0x48
   3a618: 85 10 00 00 ed df 00 00      	call 0xdfed
   3a620: 61 a1 d0 fd 00 00 00 00      	ldxw r1, [r10 - 0x230]
   3a628: 79 a2 c8 fd 00 00 00 00      	ldxdw r2, [r10 - 0x238]
   3a630: 79 a3 c0 fd 00 00 00 00      	ldxdw r3, [r10 - 0x240]
   3a638: 79 a4 b8 fd 00 00 00 00      	ldxdw r4, [r10 - 0x248]
   3a640: 79 a5 b0 fd 00 00 00 00      	ldxdw r5, [r10 - 0x250]
   3a648: 79 a0 d8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x528]
   3a650: 63 06 00 00 00 00 00 00      	stxw [r6 + 0x0], r0
   3a658: 79 a0 d0 fa 00 00 00 00      	ldxdw r0, [r10 - 0x530]
   3a660: 63 06 04 00 00 00 00 00      	stxw [r6 + 0x4], r0
   3a668: 79 a0 a0 fa 00 00 00 00      	ldxdw r0, [r10 - 0x560]
   3a670: 63 06 30 01 00 00 00 00      	stxw [r6 + 0x130], r0
   3a678: 79 a0 08 fb 00 00 00 00      	ldxdw r0, [r10 - 0x4f8]
   3a680: 73 06 c1 01 00 00 00 00      	stxb [r6 + 0x1c1], r0
   3a688: 79 a0 50 fa 00 00 00 00      	ldxdw r0, [r10 - 0x5b0]
   3a690: 7b 06 08 02 00 00 00 00      	stxdw [r6 + 0x208], r0
   3a698: 79 a0 60 fa 00 00 00 00      	ldxdw r0, [r10 - 0x5a0]
   3a6a0: 7b 06 00 02 00 00 00 00      	stxdw [r6 + 0x200], r0
   3a6a8: 79 a0 68 fa 00 00 00 00      	ldxdw r0, [r10 - 0x598]
   3a6b0: 7b 06 f8 01 00 00 00 00      	stxdw [r6 + 0x1f8], r0
   3a6b8: 79 a0 70 fa 00 00 00 00      	ldxdw r0, [r10 - 0x590]
   3a6c0: 7b 06 f0 01 00 00 00 00      	stxdw [r6 + 0x1f0], r0
   3a6c8: 79 a0 78 fa 00 00 00 00      	ldxdw r0, [r10 - 0x588]
   3a6d0: 7b 06 e8 01 00 00 00 00      	stxdw [r6 + 0x1e8], r0
   3a6d8: 79 a0 80 fa 00 00 00 00      	ldxdw r0, [r10 - 0x580]
   3a6e0: 7b 06 e0 01 00 00 00 00      	stxdw [r6 + 0x1e0], r0
   3a6e8: 79 a0 88 fa 00 00 00 00      	ldxdw r0, [r10 - 0x578]
   3a6f0: 7b 06 d8 01 00 00 00 00      	stxdw [r6 + 0x1d8], r0
   3a6f8: 79 a0 90 fa 00 00 00 00      	ldxdw r0, [r10 - 0x570]
   3a700: 7b 06 d0 01 00 00 00 00      	stxdw [r6 + 0x1d0], r0
   3a708: 79 a0 98 fa 00 00 00 00      	ldxdw r0, [r10 - 0x568]
   3a710: 7b 06 c8 01 00 00 00 00      	stxdw [r6 + 0x1c8], r0
   3a718: 7b 96 60 01 00 00 00 00      	stxdw [r6 + 0x160], r9
   3a720: 79 a0 18 fb 00 00 00 00      	ldxdw r0, [r10 - 0x4e8]
   3a728: 7b 06 58 01 00 00 00 00      	stxdw [r6 + 0x158], r0
   3a730: 79 a0 a8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x558]
   3a738: 7b 06 e0 00 00 00 00 00      	stxdw [r6 + 0xe0], r0
   3a740: 79 a0 b0 fa 00 00 00 00      	ldxdw r0, [r10 - 0x550]
   3a748: 7b 06 d8 00 00 00 00 00      	stxdw [r6 + 0xd8], r0
   3a750: 79 a0 b8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x548]
   3a758: 7b 06 d0 00 00 00 00 00      	stxdw [r6 + 0xd0], r0
   3a760: 79 a0 c0 fa 00 00 00 00      	ldxdw r0, [r10 - 0x540]
   3a768: 7b 06 c8 00 00 00 00 00      	stxdw [r6 + 0xc8], r0
   3a770: 79 a0 c8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x538]
   3a778: 7b 06 a0 00 00 00 00 00      	stxdw [r6 + 0xa0], r0
   3a780: 79 a0 00 fb 00 00 00 00      	ldxdw r0, [r10 - 0x500]
   3a788: 7b 06 88 00 00 00 00 00      	stxdw [r6 + 0x88], r0
   3a790: 79 a0 58 fa 00 00 00 00      	ldxdw r0, [r10 - 0x5a8]
   3a798: 7b 06 80 00 00 00 00 00      	stxdw [r6 + 0x80], r0
   3a7a0: 79 a0 f8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x508]
   3a7a8: 7b 06 58 00 00 00 00 00      	stxdw [r6 + 0x58], r0
   3a7b0: 79 a0 e0 fa 00 00 00 00      	ldxdw r0, [r10 - 0x520]
   3a7b8: 7b 06 10 00 00 00 00 00      	stxdw [r6 + 0x10], r0
   3a7c0: 79 a0 e8 fa 00 00 00 00      	ldxdw r0, [r10 - 0x518]
   3a7c8: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   3a7d0: 7b 56 34 01 00 00 00 00      	stxdw [r6 + 0x134], r5
   3a7d8: 7b 46 3c 01 00 00 00 00      	stxdw [r6 + 0x13c], r4
   3a7e0: 7b 36 44 01 00 00 00 00      	stxdw [r6 + 0x144], r3
   3a7e8: 7b 26 4c 01 00 00 00 00      	stxdw [r6 + 0x14c], r2
   3a7f0: 63 16 54 01 00 00 00 00      	stxw [r6 + 0x154], r1
   3a7f8: 05 00 8b fc 00 00 00 00      	ja -0x375 <.text+0x38b38>
   3a800: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   3a808: 7b 3a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r3
   3a810: bf 49 00 00 00 00 00 00      	mov64 r9, r4
   3a818: 85 10 00 00 b9 bf 00 00      	call 0xbfb9
   3a820: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3a828: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3a830: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   3a840: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   3a848: 85 10 00 00 98 92 ff ff      	call -0x6d68
   3a850: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3a858: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   3a860: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a868: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   3a870: 7b 3a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r3
   3a878: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   3a880: 7b 3a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r3
   3a888: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   3a890: 7b 3a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r3
   3a898: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3a8a0: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   3a8a8: 7b 9a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r9
   3a8b0: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   3a8b8: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
   3a8c0: 7b 8a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r8
   3a8c8: 7b 7a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r7
   3a8d0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   3a8d8: 07 03 00 00 a8 ff ff ff      	add64 r3, -0x58
   3a8e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3a8e8: 85 10 00 00 21 ba 00 00      	call 0xba21
   3a8f0: 05 00 17 00 00 00 00 00      	ja +0x17 <.text+0x3a890>
   3a8f8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   3a900: 85 10 00 00 9c bf 00 00      	call 0xbf9c
   3a908: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3a910: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3a918: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   3a928: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   3a930: 85 10 00 00 7b 92 ff ff      	call -0x6d85
   3a938: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x3a890>
   3a940: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   3a948: 85 10 00 00 93 bf 00 00      	call 0xbf93
   3a950: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3a958: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3a960: 18 03 00 00 bc d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad0bc
   3a970: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   3a978: 85 10 00 00 72 92 ff ff      	call -0x6d8e
   3a980: 05 00 05 00 00 00 00 00      	ja +0x5 <.text+0x3a890>
   3a988: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   3a990: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
   3a998: 85 10 00 00 a8 9a ff ff      	call -0x6558
   3a9a0: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   3a9a8: 85 10 00 00 87 bf 00 00      	call 0xbf87
   3a9b0: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   3a9b8: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   3a9c0: 05 00 51 fc 00 00 00 00      	ja -0x3af <.text+0x38b30>
   3a9c8: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   3a9d0: 85 10 00 00 82 bf 00 00      	call 0xbf82
   3a9d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3a9e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3a9e8: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   3a9f8: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   3aa00: 85 10 00 00 61 92 ff ff      	call -0x6d9f
   3aa08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3aa10: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   3aa18: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   3aa20: 79 a1 b0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x550]
   3aa28: 7b 1a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r1
   3aa30: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   3aa38: 7b 1a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r1
   3aa40: 79 a1 c0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x540]
   3aa48: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   3aa50: 79 a1 20 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe0]
   3aa58: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
   3aa60: 79 a1 28 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd8]
   3aa68: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
   3aa70: 79 a1 30 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd0]
   3aa78: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
   3aa80: 79 a1 38 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc8]
   3aa88: 05 00 16 00 00 00 00 00      	ja +0x16 <.text+0x3aa20>
   3aa90: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   3aa98: 85 10 00 00 69 bf 00 00      	call 0xbf69
   3aaa0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3aaa8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3aab0: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   3aac0: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   3aac8: 85 10 00 00 48 92 ff ff      	call -0x6db8
   3aad0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3aad8: 79 a1 40 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5c0]
   3aae0: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   3aae8: 79 a1 48 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5b8]
   3aaf0: 7b 1a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r1
   3aaf8: 7b 8a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r8
   3ab00: 7b 7a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r7
   3ab08: 79 a1 40 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc0]
   3ab10: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
   3ab18: 79 a1 48 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb8]
   3ab20: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
   3ab28: 79 a1 50 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb0]
   3ab30: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
   3ab38: 79 a1 58 ff 00 00 00 00      	ldxdw r1, [r10 - 0xa8]
   3ab40: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   3ab48: 05 00 b0 ff 00 00 00 00      	ja -0x50 <.text+0x3a7b0>
   3ab50: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   3ab58: 85 10 00 00 51 bf 00 00      	call 0xbf51
   3ab60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ab68: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3ab70: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   3ab80: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   3ab88: 85 10 00 00 30 92 ff ff      	call -0x6dd0
   3ab90: 05 00 c3 ff 00 00 00 00      	ja -0x3d <.text+0x3a890>
   3ab98: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   3aba8: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   3abb0: 7a 0a c8 ff 00 00 00 00      	stdw [r10 - 0x38], 0x0
   3abb8: 7a 0a b0 ff 01 00 00 00      	stdw [r10 - 0x50], 0x1
   3abc0: 7a 0a c0 ff 00 00 00 00      	stdw [r10 - 0x40], 0x0
   3abc8: 7a 0a b8 ff 08 00 00 00      	stdw [r10 - 0x48], 0x8
   3abd0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   3abd8: 07 01 00 00 a8 ff ff ff      	add64 r1, -0x58
   3abe0: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   3abf0: 85 10 00 00 92 d3 00 00      	call 0xd392
   3abf8: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   3ac00: 85 10 00 00 3c bf 00 00      	call 0xbf3c
   3ac08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ac10: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3ac18: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   3ac28: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   3ac30: 85 10 00 00 1b 92 ff ff      	call -0x6de5
   3ac38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ac40: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   3ac48: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3ac50: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   3ac58: 7b 3a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r3
   3ac60: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   3ac68: 7b 3a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r3
   3ac70: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   3ac78: 7b 3a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r3
   3ac80: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3ac88: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   3ac90: 79 a1 40 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5c0]
   3ac98: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   3aca0: 79 a1 48 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5b8]
   3aca8: 05 00 81 ff 00 00 00 00      	ja -0x7f <.text+0x3a798>
   3acb0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   3acb8: 85 10 00 00 25 bf 00 00      	call 0xbf25
   3acc0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3acc8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3acd0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   3ace0: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   3ace8: 85 10 00 00 04 92 ff ff      	call -0x6dfc
   3acf0: 05 00 97 ff 00 00 00 00      	ja -0x69 <.text+0x3a890>
   3acf8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3ad00: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   3ad08: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3ad18: 85 10 00 00 65 d1 00 00      	call 0xd165
   3ad20: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   3ad28: 85 10 00 00 17 bf 00 00      	call 0xbf17
   3ad30: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ad38: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3ad40: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   3ad50: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   3ad58: 85 10 00 00 f6 91 ff ff      	call -0x6e0a
   3ad60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ad68: 79 a1 90 fa 00 00 00 00      	ldxdw r1, [r10 - 0x570]
   3ad70: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3ad78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3ad80: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3ad88: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   3ad90: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   3ad98: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   3ada0: 7b 8a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r8
   3ada8: 7b 7a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r7
   3adb0: 79 a7 48 fa 00 00 00 00      	ldxdw r7, [r10 - 0x5b8]
   3adb8: 7b 7a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r7
   3adc0: 79 a7 40 fa 00 00 00 00      	ldxdw r7, [r10 - 0x5c0]
   3adc8: 7b 7a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r7
   3add0: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   3add8: 7b 5a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r5
   3ade0: 7b 4a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r4
   3ade8: 7b 3a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r3
   3adf0: 05 00 5b ff 00 00 00 00      	ja -0xa5 <.text+0x3a7b0>
   3adf8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   3ae00: 05 00 a1 fd 00 00 00 00      	ja -0x25f <.text+0x399f0>
   3ae08: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   3ae10: 85 10 00 00 fa be 00 00      	call 0xbefa
   3ae18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ae20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3ae28: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   3ae38: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   3ae40: 85 10 00 00 d9 91 ff ff      	call -0x6e27
   3ae48: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3ae50: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   3ae60: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
   3ae68: 79 a1 40 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5c0]
   3ae70: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   3ae78: 79 a1 48 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5b8]
   3ae80: 7b 1a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r1
   3ae88: 7b 8a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r8
   3ae90: 7b 7a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r7
   3ae98: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   3aea8: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
   3aeb0: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   3aec0: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
   3aec8: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   3aed8: 05 00 8c ff 00 00 00 00      	ja -0x74 <.text+0x3aa20>
   3aee0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3aee8: b7 02 00 00 09 00 00 00      	mov64 r2, 0x9
   3aef0: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3af00: 85 10 00 00 28 d1 00 00      	call 0xd128
   3af08: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   3af10: 85 10 00 00 da be 00 00      	call 0xbeda
   3af18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3af20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   3af28: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   3af38: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   3af40: 85 10 00 00 b9 91 ff ff      	call -0x6e47
   3af48: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   3af50: 79 a1 60 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5a0]
   3af58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3af60: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   3af68: 7b 3a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r3
   3af70: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   3af78: 7b 3a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r3
   3af80: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   3af88: 7b 3a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r3
   3af90: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   3af98: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   3afa0: 79 a1 48 fa 00 00 00 00      	ldxdw r1, [r10 - 0x5b8]
   3afa8: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   3afb0: 05 00 1f ff 00 00 00 00      	ja -0xe1 <.text+0x3a790>
   3afb8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   3afc0: 79 21 18 00 00 00 00 00      	ldxdw r1, [r2 + 0x18]
   3afc8: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   3afd0: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   3afd8: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   3afe0: 79 29 00 00 00 00 00 00      	ldxdw r9, [r2 + 0x0]
   3afe8: 18 01 00 00 05 2a e5 d7 00 00 00 00 a7 da a7 24      	lddw r1, 0x24a7daa7d7e52a05
   3aff8: 7b 3a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r3
   3b000: 5d 19 18 00 00 00 00 00      	jne r9, r1, +0x18 <.text+0x3afa8>
   3b008: 18 01 00 00 a6 ea b0 a7 00 00 00 00 29 54 91 85      	lddw r1, -0x7a6eabd6584f155a
   3b018: 5d 18 15 00 00 00 00 00      	jne r8, r1, +0x15 <.text+0x3afa8>
   3b020: 18 01 00 00 5a d4 a0 67 00 00 00 00 16 60 67 4c      	lddw r1, 0x4c67601667a0d45a
   3b030: 5d 13 12 00 00 00 00 00      	jne r3, r1, +0x12 <.text+0x3afa8>
   3b038: 18 01 00 00 4e 03 45 59 00 00 00 00 80 3d 65 a3      	lddw r1, -0x5c9ac27fa6bafcb2
   3b048: 79 a2 e0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x20]
   3b050: 5d 12 0e 00 00 00 00 00      	jne r2, r1, +0xe <.text+0x3afa8>
   3b058: 79 76 58 01 00 00 00 00      	ldxdw r6, [r7 + 0x158]
   3b060: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b068: 85 10 00 00 fb b8 00 00      	call 0xb8fb
   3b070: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b078: 55 00 09 00 00 00 00 00      	jne r0, 0x0, +0x9 <.text+0x3afa8>
   3b080: 79 66 10 00 00 00 00 00      	ldxdw r6, [r6 + 0x10]
   3b088: 79 61 10 00 00 00 00 00      	ldxdw r1, [r6 + 0x10]
   3b090: 15 01 4f 00 00 00 00 00      	jeq r1, 0x0, +0x4f <.text+0x3b1f0>
   3b098: b7 01 00 00 0b 00 00 00      	mov64 r1, 0xb
   3b0a0: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b0a8: 85 10 00 00 10 b9 00 00      	call 0xb910
   3b0b0: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   3b0b8: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b0c0: 55 06 5a 00 02 00 00 00      	jne r6, 0x2, +0x5a <.text+0x3b278>
   3b0c8: 79 71 60 00 00 00 00 00      	ldxdw r1, [r7 + 0x60]
   3b0d0: 5d 91 14 00 00 00 00 00      	jne r1, r9, +0x14 <.text+0x3b058>
   3b0d8: 79 71 68 00 00 00 00 00      	ldxdw r1, [r7 + 0x68]
   3b0e0: 5d 81 12 00 00 00 00 00      	jne r1, r8, +0x12 <.text+0x3b058>
   3b0e8: 79 71 70 00 00 00 00 00      	ldxdw r1, [r7 + 0x70]
   3b0f0: 5d 31 10 00 00 00 00 00      	jne r1, r3, +0x10 <.text+0x3b058>
   3b0f8: 79 71 78 00 00 00 00 00      	ldxdw r1, [r7 + 0x78]
   3b100: 79 a2 e0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x20]
   3b108: 5d 21 0d 00 00 00 00 00      	jne r1, r2, +0xd <.text+0x3b058>
   3b110: 79 76 58 00 00 00 00 00      	ldxdw r6, [r7 + 0x58]
   3b118: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b120: 85 10 00 00 e4 b8 00 00      	call 0xb8e4
   3b128: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b130: 55 00 08 00 00 00 00 00      	jne r0, 0x0, +0x8 <.text+0x3b058>
   3b138: 79 61 10 00 00 00 00 00      	ldxdw r1, [r6 + 0x10]
   3b140: 79 11 10 00 00 00 00 00      	ldxdw r1, [r1 + 0x10]
   3b148: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x3b058>
   3b150: b7 01 00 00 0b 00 00 00      	mov64 r1, 0xb
   3b158: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b160: 85 10 00 00 f9 b8 00 00      	call 0xb8f9
   3b168: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b170: 55 00 bb 00 02 00 00 00      	jne r0, 0x2, +0xbb <.text+0x3b630>
   3b178: 79 71 80 00 00 00 00 00      	ldxdw r1, [r7 + 0x80]
   3b180: 5d 91 14 00 00 00 00 00      	jne r1, r9, +0x14 <.text+0x3b108>
   3b188: 79 71 88 00 00 00 00 00      	ldxdw r1, [r7 + 0x88]
   3b190: 5d 81 12 00 00 00 00 00      	jne r1, r8, +0x12 <.text+0x3b108>
   3b198: 79 71 90 00 00 00 00 00      	ldxdw r1, [r7 + 0x90]
   3b1a0: 5d 31 10 00 00 00 00 00      	jne r1, r3, +0x10 <.text+0x3b108>
   3b1a8: 79 71 98 00 00 00 00 00      	ldxdw r1, [r7 + 0x98]
   3b1b0: 79 a2 e0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x20]
   3b1b8: 5d 21 0d 00 00 00 00 00      	jne r1, r2, +0xd <.text+0x3b108>
   3b1c0: 79 76 a0 00 00 00 00 00      	ldxdw r6, [r7 + 0xa0]
   3b1c8: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b1d0: 85 10 00 00 ce b8 00 00      	call 0xb8ce
   3b1d8: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b1e0: 55 00 08 00 00 00 00 00      	jne r0, 0x0, +0x8 <.text+0x3b108>
   3b1e8: 79 61 10 00 00 00 00 00      	ldxdw r1, [r6 + 0x10]
   3b1f0: 79 11 10 00 00 00 00 00      	ldxdw r1, [r1 + 0x10]
   3b1f8: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x3b108>
   3b200: b7 01 00 00 0b 00 00 00      	mov64 r1, 0xb
   3b208: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b210: 85 10 00 00 e3 b8 00 00      	call 0xb8e3
   3b218: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b220: 55 00 cd 00 02 00 00 00      	jne r0, 0x2, +0xcd <.text+0x3b770>
   3b228: b7 06 00 00 02 00 00 00      	mov64 r6, 0x2
   3b230: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   3b240: 5d 19 0f 00 00 00 00 00      	jne r9, r1, +0xf <.text+0x3b1a0>
   3b248: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   3b258: 5d 18 0c 00 00 00 00 00      	jne r8, r1, +0xc <.text+0x3b1a0>
   3b260: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   3b270: 5d 13 09 00 00 00 00 00      	jne r3, r1, +0x9 <.text+0x3b1a0>
   3b278: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   3b288: 79 a2 e0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x20]
   3b290: 5d 12 05 00 00 00 00 00      	jne r2, r1, +0x5 <.text+0x3b1a0>
   3b298: 79 77 d0 01 00 00 00 00      	ldxdw r7, [r7 + 0x1d0]
   3b2a0: 79 78 00 00 00 00 00 00      	ldxdw r8, [r7 + 0x0]
   3b2a8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   3b2b0: 85 10 00 00 b2 b8 00 00      	call 0xb8b2
   3b2b8: 15 00 01 00 00 00 00 00      	jeq r0, 0x0, +0x1 <.text+0x3b1a8>
   3b2c0: 05 00 e1 00 00 00 00 00      	ja +0xe1 <.text+0x3b8b0>
   3b2c8: 79 86 10 00 00 00 00 00      	ldxdw r6, [r8 + 0x10]
   3b2d0: 79 61 10 00 00 00 00 00      	ldxdw r1, [r6 + 0x10]
   3b2d8: 15 01 49 00 00 00 00 00      	jeq r1, 0x0, +0x49 <.text+0x3b408>
   3b2e0: b7 01 00 00 0b 00 00 00      	mov64 r1, 0xb
   3b2e8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b2f0: 85 10 00 00 c7 b8 00 00      	call 0xb8c7
   3b2f8: b7 06 00 00 02 00 00 00      	mov64 r6, 0x2
   3b300: 55 00 54 00 02 00 00 00      	jne r0, 0x2, +0x54 <.text+0x3b488>
   3b308: 05 00 d8 00 00 00 00 00      	ja +0xd8 <.text+0x3b8b0>
   3b310: 7a 06 10 00 ff ff ff ff      	stdw [r6 + 0x10], -0x1
   3b318: 79 61 18 00 00 00 00 00      	ldxdw r1, [r6 + 0x18]
   3b320: 79 62 20 00 00 00 00 00      	ldxdw r2, [r6 + 0x20]
   3b328: 7b 2a f0 ff 00 00 00 00      	stxdw [r10 - 0x10], r2
   3b330: 7b 1a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r1
   3b338: 7a 0a f8 ff 00 00 00 00      	stdw [r10 - 0x8], 0x0
   3b340: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b348: 07 01 00 00 60 01 00 00      	add64 r1, 0x160
   3b350: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   3b358: 07 02 00 00 e8 ff ff ff      	add64 r2, -0x18
   3b360: 85 10 00 00 51 5a 00 00      	call 0x5a51
   3b368: 79 62 10 00 00 00 00 00      	ldxdw r2, [r6 + 0x10]
   3b370: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   3b378: 7b 26 10 00 00 00 00 00      	stxdw [r6 + 0x10], r2
   3b380: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   3b388: 79 a3 d8 ff 00 00 00 00      	ldxdw r3, [r10 - 0x28]
   3b390: 15 06 a6 ff 02 00 00 00      	jeq r6, 0x2, -0x5a <.text+0x3afa8>
   3b398: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   3b3a0: 85 10 00 00 49 90 00 00      	call 0x9049
   3b3a8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   3b3b8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b3c0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   3b3c8: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   3b3d0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   3b3d8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3b3e0: 2d 31 11 00 00 00 00 00      	jgt r1, r3, +0x11 <.text+0x3b350>
   3b3e8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b3f0: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x3b358>
   3b3f8: 18 02 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ff4
   3b408: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b410: 15 03 11 00 00 00 00 00      	jeq r3, 0x0, +0x11 <.text+0x3b380>
   3b418: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   3b420: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b428: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b430: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b440: 2d 32 10 00 00 00 00 00      	jgt r2, r3, +0x10 <.text+0x3b3a8>
   3b448: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3b450: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   3b458: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3b468: 85 10 00 00 7b d0 00 00      	call 0xd07b
   3b470: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x3b2d8>
   3b478: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   3b480: 18 02 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ff4
   3b490: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b498: 55 03 ef ff 00 00 00 00      	jne r3, 0x0, -0x11 <.text+0x3b2f8>
   3b4a0: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b4a8: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b4b0: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b4c0: bd 32 f0 ff 00 00 00 00      	jle r2, r3, -0x10 <.text+0x3b328>
   3b4c8: 18 03 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000000
   3b4d8: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
   3b4e0: 18 03 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r3, 0x735f6d656879616d
   3b4f0: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
   3b4f8: 62 02 08 00 74 61 74 65      	stw [r2 + 0x8], 0x65746174
   3b500: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b508: 7a 01 08 00 0c 00 00 00      	stdw [r1 + 0x8], 0xc
   3b510: 7a 01 00 00 01 00 00 00      	stdw [r1 + 0x0], 0x1
   3b518: b7 03 00 00 0c 00 00 00      	mov64 r3, 0xc
   3b520: 05 00 93 00 00 00 00 00      	ja +0x93 <.text+0x3b8a0>
   3b528: 7a 06 10 00 ff ff ff ff      	stdw [r6 + 0x10], -0x1
   3b530: 79 61 18 00 00 00 00 00      	ldxdw r1, [r6 + 0x18]
   3b538: 79 62 20 00 00 00 00 00      	ldxdw r2, [r6 + 0x20]
   3b540: 7b 2a f0 ff 00 00 00 00      	stxdw [r10 - 0x10], r2
   3b548: 7b 1a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r1
   3b550: 7a 0a f8 ff 00 00 00 00      	stdw [r10 - 0x8], 0x0
   3b558: 07 07 00 00 08 00 00 00      	add64 r7, 0x8
   3b560: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   3b568: 07 02 00 00 e8 ff ff ff      	add64 r2, -0x18
   3b570: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b578: 85 10 00 00 d0 64 00 00      	call 0x64d0
   3b580: 79 62 10 00 00 00 00 00      	ldxdw r2, [r6 + 0x10]
   3b588: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   3b590: 7b 26 10 00 00 00 00 00      	stxdw [r6 + 0x10], r2
   3b598: b7 06 00 00 02 00 00 00      	mov64 r6, 0x2
   3b5a0: 15 00 85 00 02 00 00 00      	jeq r0, 0x2, +0x85 <.text+0x3b8b0>
   3b5a8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   3b5b0: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   3b5b8: 85 10 00 00 06 90 00 00      	call 0x9006
   3b5c0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   3b5d0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b5d8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   3b5e0: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   3b5e8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   3b5f0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3b5f8: 2d 31 11 00 00 00 00 00      	jgt r1, r3, +0x11 <.text+0x3b568>
   3b600: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b608: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x3b570>
   3b610: 18 02 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ff3
   3b620: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b628: 15 03 11 00 00 00 00 00      	jeq r3, 0x0, +0x11 <.text+0x3b598>
   3b630: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   3b638: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b640: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b648: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b658: 2d 32 10 00 00 00 00 00      	jgt r2, r3, +0x10 <.text+0x3b5c0>
   3b660: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3b668: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   3b670: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3b680: 85 10 00 00 38 d0 00 00      	call 0xd038
   3b688: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x3b4f0>
   3b690: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   3b698: 18 02 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ff3
   3b6a8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   3b6b0: 55 03 ef ff 00 00 00 00      	jne r3, 0x0, -0x11 <.text+0x3b510>
   3b6b8: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b6c0: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b6c8: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b6d8: bd 32 f0 ff 00 00 00 00      	jle r2, r3, -0x10 <.text+0x3b540>
   3b6e0: 18 03 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000000
   3b6f0: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
   3b6f8: 18 03 00 00 6e 67 5f 63 00 00 00 00 75 72 76 65      	lddw r3, 0x65767275635f676e
   3b708: 7b 32 05 00 00 00 00 00      	stxdw [r2 + 0x5], r3
   3b710: 18 03 00 00 62 6f 6e 64 00 00 00 00 69 6e 67 5f      	lddw r3, 0x5f676e69646e6f62
   3b720: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
   3b728: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b730: 7a 01 08 00 0d 00 00 00      	stdw [r1 + 0x8], 0xd
   3b738: 7a 01 00 00 01 00 00 00      	stdw [r1 + 0x0], 0x1
   3b740: b7 03 00 00 0d 00 00 00      	mov64 r3, 0xd
   3b748: 05 00 4e 00 00 00 00 00      	ja +0x4e <.text+0x3b8a0>
   3b750: b7 08 00 00 00 00 00 00      	mov64 r8, 0x0
   3b758: bf 07 00 00 00 00 00 00      	mov64 r7, r0
   3b760: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   3b768: 85 10 00 00 d0 8f 00 00      	call 0x8fd0
   3b770: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   3b780: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b788: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   3b790: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   3b798: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3b7a0: 2d 31 16 00 00 00 00 00      	jgt r1, r3, +0x16 <.text+0x3b738>
   3b7a8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b7b0: 15 02 15 00 00 00 00 00      	jeq r2, 0x0, +0x15 <.text+0x3b740>
   3b7b8: 18 02 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ffc
   3b7c8: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b7d0: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <.text+0x3b6c0>
   3b7d8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   3b7e0: bf 76 00 00 00 00 00 00      	mov64 r6, r7
   3b7e8: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b7f0: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b7f8: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b808: bd 32 41 00 00 00 00 00      	jle r2, r3, +0x41 <.text+0x3b8f8>
   3b810: 18 03 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000000
   3b820: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
   3b828: 62 02 00 00 6d 69 6e 74      	stw [r2 + 0x0], 0x746e696d
   3b830: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b838: 7a 01 08 00 04 00 00 00      	stdw [r1 + 0x8], 0x4
   3b840: 7a 01 00 00 01 00 00 00      	stdw [r1 + 0x0], 0x1
   3b848: b7 03 00 00 04 00 00 00      	mov64 r3, 0x4
   3b850: 05 00 2d 00 00 00 00 00      	ja +0x2d <.text+0x3b8a0>
   3b858: 55 02 eb ff 00 00 00 00      	jne r2, 0x0, -0x15 <.text+0x3b698>
   3b860: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   3b868: 18 02 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007ffc
   3b878: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b880: 55 03 ea ff 00 00 00 00      	jne r3, 0x0, -0x16 <.text+0x3b6b8>
   3b888: 05 00 ea ff 00 00 00 00      	ja -0x16 <.text+0x3b6c0>
   3b890: b7 08 00 00 00 00 00 00      	mov64 r8, 0x0
   3b898: bf 07 00 00 00 00 00 00      	mov64 r7, r0
   3b8a0: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   3b8a8: 85 10 00 00 a8 8f 00 00      	call 0x8fa8
   3b8b0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   3b8c0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b8c8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   3b8d0: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   3b8d8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   3b8e0: 2d 31 1f 00 00 00 00 00      	jgt r1, r3, +0x1f <.text+0x3b8c0>
   3b8e8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   3b8f0: 15 02 1e 00 00 00 00 00      	jeq r2, 0x0, +0x1e <.text+0x3b8c8>
   3b8f8: 18 02 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007fee
   3b908: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3b910: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <.text+0x3b800>
   3b918: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   3b920: bf 76 00 00 00 00 00 00      	mov64 r6, r7
   3b928: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   3b930: 57 03 00 00 01 00 00 00      	and64 r3, 0x1
   3b938: 18 03 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000007
   3b948: bd 32 1e 00 00 00 00 00      	jle r2, r3, +0x1e <.text+0x3b920>
   3b950: 18 03 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r3, 0x300000000
   3b960: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
   3b968: 18 03 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r3, 0x7561765f6e656b6f
   3b978: 7b 32 08 00 00 00 00 00      	stxdw [r2 + 0x8], r3
   3b980: 18 03 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r3, 0x745f6d656879616d
   3b990: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
   3b998: 6a 02 10 00 6c 74 00 00      	sth [r2 + 0x10], 0x746c
   3b9a0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   3b9a8: 7a 01 08 00 12 00 00 00      	stdw [r1 + 0x8], 0x12
   3b9b0: 7a 01 00 00 01 00 00 00      	stdw [r1 + 0x0], 0x1
   3b9b8: b7 03 00 00 12 00 00 00      	mov64 r3, 0x12
   3b9c0: 7b 31 18 00 00 00 00 00      	stxdw [r1 + 0x18], r3
   3b9c8: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   3b9d0: bf 60 00 00 00 00 00 00      	mov64 r0, r6
   3b9d8: 95 00 00 00 00 00 00 00      	exit
   3b9e0: 55 02 e2 ff 00 00 00 00      	jne r2, 0x0, -0x1e <.text+0x3b7d8>
   3b9e8: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   3b9f0: 18 02 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300007fee
   3ba00: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   3ba08: 55 03 e1 ff 00 00 00 00      	jne r3, 0x0, -0x1f <.text+0x3b7f8>
   3ba10: 05 00 e1 ff 00 00 00 00      	ja -0x1f <.text+0x3b800>
   3ba18: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3ba20: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   3ba28: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3ba38: 85 10 00 00 c1 cf 00 00      	call 0xcfc1
   3ba40: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   3ba48: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   3ba50: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   3ba60: 85 10 00 00 bc cf 00 00      	call 0xcfbc
   46378: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   46380: 7b 4a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r4
   46388: bf 39 00 00 00 00 00 00      	mov64 r9, r3
   46390: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   46398: 7b 1a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r1
   463a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   463a8: 07 01 00 00 c0 fb ff ff      	add64 r1, -0x440
   463b0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   463b8: 85 10 00 00 8e 87 ff ff      	call -0x7872
   463c0: 79 a6 c8 fb 00 00 00 00      	ldxdw r6, [r10 - 0x438]
   463c8: 79 a8 c0 fb 00 00 00 00      	ldxdw r8, [r10 - 0x440]
   463d0: 55 08 2f 00 02 00 00 00      	jne r8, 0x2, +0x2f <.text+0x46430>
   463d8: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   463e0: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   463e8: 79 78 08 f0 00 00 00 00      	ldxdw r8, [r7 - 0xff8]
   463f0: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   463f8: 7b 6a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r6
   46400: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   46408: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   46410: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   46418: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   46420: 85 10 00 00 d5 87 ff ff      	call -0x782b
   46428: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   46430: 55 01 54 00 02 00 00 00      	jne r1, 0x2, +0x54 <.text+0x465b8>
   46438: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   46440: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   46448: 85 10 00 00 34 7a 00 00      	call 0x7a34
   46450: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   46460: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   46468: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46470: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   46478: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   46480: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46488: 2d 21 60 00 00 00 00 00      	jgt r1, r2, +0x60 <.text+0x46670>
   46490: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46498: 15 04 5f 00 00 00 00 00      	jeq r4, 0x0, +0x5f <.text+0x46678>
   464a0: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   464b0: 15 02 60 00 00 00 00 00      	jeq r2, 0x0, +0x60 <.text+0x46698>
   464b8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   464c0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   464d0: 15 06 5f 00 01 00 00 00      	jeq r6, 0x1, +0x5f <.text+0x466b0>
   464d8: bd 21 5f 00 00 00 00 00      	jle r1, r2, +0x5f <.text+0x466b8>
   464e0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   464f0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   464f8: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   46508: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   46510: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   46520: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   46528: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   46530: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   46538: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   46540: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   46548: 05 00 38 01 00 00 00 00      	ja +0x138 <.text+0x46df0>
   46550: 85 10 00 00 13 7a 00 00      	call 0x7a13
   46558: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   46568: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   46570: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46578: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   46580: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   46588: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46590: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <.text+0x464f8>
   46598: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   465a0: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <.text+0x46500>
   465a8: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   465b8: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x46520>
   465c0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   465c8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   465d0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   465d8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   465e8: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <.text+0x46548>
   465f0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   465f8: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   46600: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   46610: 85 10 00 00 46 ba 00 00      	call 0xba46
   46618: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <.text+0x46488>
   46620: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   46628: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   46638: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x464a0>
   46640: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   46648: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   46650: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46660: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <.text+0x464d0>
   46668: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   46678: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   46680: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   46688: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   46690: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   46698: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   466a0: 7a 06 18 00 06 00 00 00      	stdw [r6 + 0x18], 0x6
   466a8: 7a 06 08 00 06 00 00 00      	stdw [r6 + 0x8], 0x6
   466b0: 7a 06 00 00 01 00 00 00      	stdw [r6 + 0x0], 0x1
   466b8: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   466c0: 7b 61 10 00 00 00 00 00      	stxdw [r1 + 0x10], r6
   466c8: 7b 81 08 00 00 00 00 00      	stxdw [r1 + 0x8], r8
   466d0: 05 00 0b 01 00 00 00 00      	ja +0x10b <.text+0x46e10>
   466d8: 85 10 00 00 e2 79 00 00      	call 0x79e2
   466e0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   466f0: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   466f8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   46700: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   46708: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   46710: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46718: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x466e0>
   46720: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46728: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x466e8>
   46730: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   46740: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x46708>
   46748: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   46750: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46758: 7b 8a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r8
   46760: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46770: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x46728>
   46778: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   46780: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   46788: 85 10 00 00 1b ba 00 00      	call 0xba1b
   46790: 55 04 a1 ff 00 00 00 00      	jne r4, 0x0, -0x5f <.text+0x46380>
   46798: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   467a0: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   467b0: 55 02 a0 ff 00 00 00 00      	jne r2, 0x0, -0x60 <.text+0x46398>
   467b8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   467c8: 55 06 a1 ff 01 00 00 00      	jne r6, 0x1, -0x5f <.text+0x463b8>
   467d0: 2d 21 a1 ff 00 00 00 00      	jgt r1, r2, -0x5f <.text+0x463c0>
   467d8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   467e0: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   467e8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   467f8: 85 10 00 00 09 ba 00 00      	call 0xba09
   46800: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x46610>
   46808: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   46810: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   46820: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x46628>
   46828: 7b 8a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r8
   46830: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46840: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x46658>
   46848: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
   46858: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   46860: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   46868: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   46870: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   46878: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   46880: 85 10 00 00 a0 c7 00 00      	call 0xc7a0
   46888: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   46890: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   46898: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   468a0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   468a8: 85 10 00 00 11 87 ff ff      	call -0x78ef
   468b0: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   468b8: 55 01 1f 00 02 00 00 00      	jne r1, 0x2, +0x1f <.text+0x46898>
   468c0: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   468c8: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   468d0: 85 10 00 00 a3 79 00 00      	call 0x79a3
   468d8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   468e0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   468e8: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   468f0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   468f8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46900: 2d 21 2a 00 00 00 00 00      	jgt r1, r2, +0x2a <.text+0x46938>
   46908: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46910: 15 04 29 00 00 00 00 00      	jeq r4, 0x0, +0x29 <.text+0x46940>
   46918: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   46928: 15 02 2a 00 00 00 00 00      	jeq r2, 0x0, +0x2a <.text+0x46960>
   46930: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   46938: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46948: 15 06 29 00 01 00 00 00      	jeq r6, 0x1, +0x29 <.text+0x46978>
   46950: bd 21 29 00 00 00 00 00      	jle r1, r2, +0x29 <.text+0x46980>
   46958: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   46968: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   46970: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   46980: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   46988: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   46990: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   46998: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   469a0: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   469a8: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   469b0: 05 00 ab 00 00 00 00 00      	ja +0xab <.text+0x46df0>
   469b8: 85 10 00 00 86 79 00 00      	call 0x7986
   469c0: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   469c8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   469d0: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   469d8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   469e0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   469e8: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x469a8>
   469f0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   469f8: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x469b0>
   46a00: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   46a10: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x469d0>
   46a18: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   46a20: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46a28: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46a38: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x469e8>
   46a40: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   46a48: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   46a50: 85 10 00 00 c2 b9 00 00      	call 0xb9c2
   46a58: 55 04 d7 ff 00 00 00 00      	jne r4, 0x0, -0x29 <.text+0x467f8>
   46a60: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   46a68: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   46a78: 55 02 d6 ff 00 00 00 00      	jne r2, 0x0, -0x2a <.text+0x46810>
   46a80: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46a90: 55 06 d7 ff 01 00 00 00      	jne r6, 0x1, -0x29 <.text+0x46830>
   46a98: 2d 21 d7 ff 00 00 00 00      	jgt r1, r2, -0x29 <.text+0x46838>
   46aa0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   46aa8: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   46ab0: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   46ac0: 85 10 00 00 b0 b9 00 00      	call 0xb9b0
   46ac8: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x468e0>
   46ad0: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   46ad8: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   46ae8: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x468f8>
   46af0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46b00: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x46920>
   46b08: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   46b10: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   46b18: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   46b20: 7b 1a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r1
   46b28: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   46b30: 85 10 00 00 4a c7 00 00      	call 0xc74a
   46b38: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   46b40: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   46b48: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   46b50: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   46b58: 85 10 00 00 32 78 ff ff      	call -0x87ce
   46b60: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   46b68: 55 01 1c 00 02 00 00 00      	jne r1, 0x2, +0x1c <.text+0x46b30>
   46b70: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   46b78: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   46b80: 85 10 00 00 4d 79 00 00      	call 0x794d
   46b88: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   46b90: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46b98: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   46ba0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   46ba8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46bb0: 2d 21 27 00 00 00 00 00      	jgt r1, r2, +0x27 <.text+0x46bd0>
   46bb8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46bc0: 15 04 26 00 00 00 00 00      	jeq r4, 0x0, +0x26 <.text+0x46bd8>
   46bc8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   46bd8: 15 02 27 00 00 00 00 00      	jeq r2, 0x0, +0x27 <.text+0x46bf8>
   46be0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   46be8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46bf8: 15 06 26 00 01 00 00 00      	jeq r6, 0x1, +0x26 <.text+0x46c10>
   46c00: bd 21 26 00 00 00 00 00      	jle r1, r2, +0x26 <.text+0x46c18>
   46c08: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   46c18: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   46c20: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   46c28: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   46c30: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   46c38: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   46c40: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   46c48: 05 00 58 00 00 00 00 00      	ja +0x58 <.text+0x46df0>
   46c50: 85 10 00 00 33 79 00 00      	call 0x7933
   46c58: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   46c60: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   46c68: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   46c70: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   46c78: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46c80: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x46c40>
   46c88: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46c90: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x46c48>
   46c98: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   46ca8: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x46c68>
   46cb0: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   46cb8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46cc0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46cd0: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x46c80>
   46cd8: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   46ce0: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   46ce8: 85 10 00 00 6f b9 00 00      	call 0xb96f
   46cf0: 55 04 da ff 00 00 00 00      	jne r4, 0x0, -0x26 <.text+0x46aa8>
   46cf8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   46d00: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   46d10: 55 02 d9 ff 00 00 00 00      	jne r2, 0x0, -0x27 <.text+0x46ac0>
   46d18: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46d28: 55 06 da ff 01 00 00 00      	jne r6, 0x1, -0x26 <.text+0x46ae0>
   46d30: 2d 21 da ff 00 00 00 00      	jgt r1, r2, -0x26 <.text+0x46ae8>
   46d38: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   46d40: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   46d48: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   46d58: 85 10 00 00 5d b9 00 00      	call 0xb95d
   46d60: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x46b78>
   46d68: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   46d70: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   46d80: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x46b90>
   46d88: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46d98: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x46bb8>
   46da0: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   46da8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   46db0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   46db8: 7b 1a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r1
   46dc0: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   46dc8: 85 10 00 00 f7 c6 00 00      	call 0xc6f7
   46dd0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   46dd8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   46de0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   46de8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   46df0: 85 10 00 00 f0 77 ff ff      	call -0x8810
   46df8: 61 a1 b0 ff 00 00 00 00      	ldxw r1, [r10 - 0x50]
   46e00: 55 01 27 00 02 00 00 00      	jne r1, 0x2, +0x27 <.text+0x46e20>
   46e08: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   46e10: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   46e18: 85 10 00 00 fa 78 00 00      	call 0x78fa
   46e20: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   46e28: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46e30: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   46e38: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   46e40: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46e48: 2d 21 33 00 00 00 00 00      	jgt r1, r2, +0x33 <.text+0x46ec8>
   46e50: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46e58: 15 04 32 00 00 00 00 00      	jeq r4, 0x0, +0x32 <.text+0x46ed0>
   46e60: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   46e70: 15 02 33 00 00 00 00 00      	jeq r2, 0x0, +0x33 <.text+0x46ef0>
   46e78: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   46e80: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46e90: 15 06 32 00 01 00 00 00      	jeq r6, 0x1, +0x32 <.text+0x46f08>
   46e98: bd 21 32 00 00 00 00 00      	jle r1, r2, +0x32 <.text+0x46f10>
   46ea0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   46eb0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   46eb8: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   46ec8: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   46ed0: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   46ee0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   46ee8: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   46ef0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   46ef8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   46f00: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   46f08: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   46f10: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   46f18: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   46f20: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   46f28: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   46f30: 7a 01 00 00 00 00 00 00      	stdw [r1 + 0x0], 0x0
   46f38: 95 00 00 00 00 00 00 00      	exit
   46f40: 85 10 00 00 d5 78 00 00      	call 0x78d5
   46f48: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   46f50: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   46f58: 07 03 00 00 28 ff ff ff      	add64 r3, -0xd8
   46f60: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   46f68: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   46f70: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x46f38>
   46f78: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   46f80: 79 a8 90 fb 00 00 00 00      	ldxdw r8, [r10 - 0x470]
   46f88: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x46f48>
   46f90: 18 01 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f28
   46fa0: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x46f68>
   46fa8: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   46fb0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   46fb8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   46fc8: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x46f80>
   46fd0: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   46fd8: b7 02 00 00 d8 00 00 00      	mov64 r2, 0xd8
   46fe0: 85 10 00 00 10 b9 00 00      	call 0xb910
   46fe8: 55 04 ce ff 00 00 00 00      	jne r4, 0x0, -0x32 <.text+0x46d40>
   46ff0: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   46ff8: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   47008: 55 02 cd ff 00 00 00 00      	jne r2, 0x0, -0x33 <.text+0x46d58>
   47010: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   47020: 55 06 ce ff 01 00 00 00      	jne r6, 0x1, -0x32 <.text+0x46d78>
   47028: 2d 21 ce ff 00 00 00 00      	jgt r1, r2, -0x32 <.text+0x46d80>
   47030: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   47038: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   47040: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   47050: 85 10 00 00 fe b8 00 00      	call 0xb8fe
   47058: 79 a8 90 fb 00 00 00 00      	ldxdw r8, [r10 - 0x470]
   47060: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x46e70>
   47068: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   47070: 18 01 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f28
   47080: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x46e88>
   47088: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   47098: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x46eb0>
   470a0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   470b0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   470b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   470c0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   470c8: 7b 1a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r1
   470d0: b7 03 00 00 d8 00 00 00      	mov64 r3, 0xd8
   470d8: 85 10 00 00 95 c6 00 00      	call 0xc695
   470e0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   470e8: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x47040>
   470f0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   470f8: 7b 2a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r2
   47100: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   47108: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47110: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47118: bf 24 00 00 00 00 00 00      	mov64 r4, r2
   47120: 07 04 00 00 30 00 00 00      	add64 r4, 0x30
   47128: 7b 49 00 00 00 00 00 00      	stxdw [r9 + 0x0], r4
   47130: 15 03 0c 00 00 00 00 00      	jeq r3, 0x0, +0xc <.text+0x47078>
   47138: 07 01 00 00 fe ff ff ff      	add64 r1, -0x2
   47140: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   47148: 07 02 00 00 60 00 00 00      	add64 r2, 0x60
   47150: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47158: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x470d8>
   47160: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47168: 85 10 00 00 8f a6 00 00      	call 0xa68f
   47170: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   47178: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   47180: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   47188: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   47190: 05 00 b4 ff 00 00 00 00      	ja -0x4c <.text+0x46e18>
   47198: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   471a0: 85 10 00 00 88 a6 00 00      	call 0xa688
   471a8: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   471b0: 15 00 08 00 02 00 00 00      	jeq r0, 0x2, +0x8 <.text+0x470d8>
   471b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   471c0: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   471c8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   471d8: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   471e0: 85 10 00 00 65 79 ff ff      	call -0x869b
   471e8: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   471f0: 55 00 76 00 02 00 00 00      	jne r0, 0x2, +0x76 <.text+0x47488>
   471f8: 7b 4a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r4
   47200: 7b 4a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r4
   47208: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47210: 07 01 00 00 e8 fb ff ff      	add64 r1, -0x418
   47218: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47220: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47228: 85 10 00 00 36 86 ff ff      	call -0x79ca
   47230: 79 a2 f0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x410]
   47238: 79 a1 e8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x418]
   47240: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x47158>
   47248: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   47258: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   47260: 85 10 00 00 55 79 ff ff      	call -0x86ab
   47268: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47270: 55 00 b5 01 02 00 00 00      	jne r0, 0x2, +0x1b5 <.text+0x47f00>
   47278: 7b 2a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r2
   47280: 7b 2a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r2
   47288: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47290: 07 01 00 00 00 fc ff ff      	add64 r1, -0x400
   47298: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   472a0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   472a8: 85 10 00 00 ce 71 ff ff      	call -0x8e32
   472b0: 79 a2 08 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f8]
   472b8: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   472c0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x471d8>
   472c8: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   472d8: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   472e0: 85 10 00 00 45 79 ff ff      	call -0x86bb
   472e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   472f0: 55 00 a5 01 02 00 00 00      	jne r0, 0x2, +0x1a5 <.text+0x47f00>
   472f8: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   47300: 7b 2a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r2
   47308: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47310: 07 01 00 00 10 fc ff ff      	add64 r1, -0x3f0
   47318: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47320: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47328: 85 10 00 00 88 86 ff ff      	call -0x7978
   47330: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   47338: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   47340: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x47238>
   47348: 7b 2a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r2
   47350: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x47268>
   47358: 18 03 00 00 6e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc6e
   47368: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   47370: 85 10 00 00 33 79 ff ff      	call -0x86cd
   47378: 55 00 be ff 02 00 00 00      	jne r0, 0x2, -0x42 <.text+0x47050>
   47380: 7b 1a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r1
   47388: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47390: 07 01 00 00 28 fc ff ff      	add64 r1, -0x3d8
   47398: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   473a0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   473a8: 85 10 00 00 38 86 ff ff      	call -0x79c8
   473b0: 79 a2 30 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d0]
   473b8: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   473c0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x472d8>
   473c8: 18 03 00 00 96 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb96
   473d8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   473e0: 85 10 00 00 25 79 ff ff      	call -0x86db
   473e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   473f0: 55 00 85 01 02 00 00 00      	jne r0, 0x2, +0x185 <.text+0x47f00>
   473f8: 7b 2a 48 fb 00 00 00 00      	stxdw [r10 - 0x4b8], r2
   47400: 7b 2a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r2
   47408: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   47410: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   47418: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   47420: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   47428: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47430: 07 01 00 00 38 fc ff ff      	add64 r1, -0x3c8
   47438: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47440: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   47448: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47450: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47458: 85 10 00 00 20 7b ff ff      	call -0x84e0
   47460: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   47468: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   47470: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x47368>
   47478: 7b 2a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r2
   47480: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x47398>
   47488: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   47498: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   474a0: 85 10 00 00 0d 79 ff ff      	call -0x86f3
   474a8: 55 00 98 ff 02 00 00 00      	jne r0, 0x2, -0x68 <.text+0x47050>
   474b0: 7b 1a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r1
   474b8: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   474c0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   474c8: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   474d0: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   474d8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   474e0: 07 01 00 00 48 fc ff ff      	add64 r1, -0x3b8
   474e8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   474f0: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   474f8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47500: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47508: 85 10 00 00 a0 7a ff ff      	call -0x8560
   47510: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   47518: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   47520: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x47438>
   47528: 18 03 00 00 80 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc80
   47538: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   47540: 85 10 00 00 f9 78 ff ff      	call -0x8707
   47548: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47550: 55 00 59 01 02 00 00 00      	jne r0, 0x2, +0x159 <.text+0x47f00>
   47558: 7b 2a 38 fb 00 00 00 00      	stxdw [r10 - 0x4c8], r2
   47560: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   47568: 15 01 0a 00 00 00 00 00      	jeq r1, 0x0, +0xa <.text+0x474a0>
   47570: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   47578: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   47580: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47588: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   47590: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   47598: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   475a0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x474f8>
   475a8: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   475b0: 7b 41 10 00 00 00 00 00      	stxdw [r1 + 0x10], r4
   475b8: 05 00 4e 01 00 00 00 00      	ja +0x14e <.text+0x47f10>
   475c0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   475c8: 85 10 00 00 03 a6 00 00      	call 0xa603
   475d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   475d8: 15 00 07 00 02 00 00 00      	jeq r0, 0x2, +0x7 <.text+0x474f8>
   475e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   475e8: 18 03 00 00 6c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb6c
   475f8: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   47600: 85 10 00 00 e1 78 ff ff      	call -0x871f
   47608: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47610: 55 00 41 01 02 00 00 00      	jne r0, 0x2, +0x141 <.text+0x47f00>
   47618: 7b 2a 30 fb 00 00 00 00      	stxdw [r10 - 0x4d0], r2
   47620: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   47628: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   47630: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   47638: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   47640: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   47648: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47650: 07 01 00 00 60 fc ff ff      	add64 r1, -0x3a0
   47658: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47660: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   47668: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47670: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47678: 85 10 00 00 46 7b ff ff      	call -0x84ba
   47680: 79 a2 68 fc 00 00 00 00      	ldxdw r2, [r10 - 0x398]
   47688: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   47690: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x47588>
   47698: 7b 2a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r2
   476a0: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x475b8>
   476a8: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   476b8: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   476c0: 85 10 00 00 c9 78 ff ff      	call -0x8737
   476c8: 55 00 54 ff 02 00 00 00      	jne r0, 0x2, -0xac <.text+0x47050>
   476d0: 7b 1a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r1
   476d8: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   476e0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   476e8: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   476f0: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   476f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47700: 07 01 00 00 70 fc ff ff      	add64 r1, -0x390
   47708: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47710: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   47718: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47720: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47728: 85 10 00 00 30 7b ff ff      	call -0x84d0
   47730: 79 a2 78 fc 00 00 00 00      	ldxdw r2, [r10 - 0x388]
   47738: 79 a1 70 fc 00 00 00 00      	ldxdw r1, [r10 - 0x390]
   47740: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x47658>
   47748: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   47758: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   47760: 85 10 00 00 b5 78 ff ff      	call -0x874b
   47768: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47770: 55 00 15 01 02 00 00 00      	jne r0, 0x2, +0x115 <.text+0x47f00>
   47778: 7b 2a 20 fb 00 00 00 00      	stxdw [r10 - 0x4e0], r2
   47780: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   47788: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x476a8>
   47790: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   47798: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   477a0: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   477a8: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   477b0: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   477b8: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   477c0: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x47710>
   477c8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   477d0: 85 10 00 00 c2 a5 00 00      	call 0xa5c2
   477d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   477e0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x476d8>
   477e8: 7b 2a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r2
   477f0: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x47710>
   477f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47800: 18 03 00 00 bc dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcbc
   47810: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   47818: 85 10 00 00 9e 78 ff ff      	call -0x8762
   47820: 55 00 29 ff 02 00 00 00      	jne r0, 0x2, -0xd7 <.text+0x47050>
   47828: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   47830: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   47838: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   47840: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   47848: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   47850: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47858: 07 01 00 00 80 fc ff ff      	add64 r1, -0x380
   47860: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47868: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   47870: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47878: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47880: 85 10 00 00 05 7b ff ff      	call -0x84fb
   47888: 79 a2 88 fc 00 00 00 00      	ldxdw r2, [r10 - 0x378]
   47890: 79 a1 80 fc 00 00 00 00      	ldxdw r1, [r10 - 0x380]
   47898: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x477b0>
   478a0: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   478b0: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   478b8: 85 10 00 00 8a 78 ff ff      	call -0x8776
   478c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   478c8: 55 00 ea 00 02 00 00 00      	jne r0, 0x2, +0xea <.text+0x47f00>
   478d0: 7b 2a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r2
   478d8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   478e0: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x47838>
   478e8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   478f0: 7b 2a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r2
   478f8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47900: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47908: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   47910: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   47918: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x47860>
   47920: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   47928: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   47930: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   47938: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   47940: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   47948: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   47950: 05 00 12 00 00 00 00 00      	ja +0x12 <.text+0x478c8>
   47958: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47960: 85 10 00 00 90 a5 00 00      	call 0xa590
   47968: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47970: 55 00 40 00 02 00 00 00      	jne r0, 0x2, +0x40 <.text+0x47a58>
   47978: 7b 2a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r2
   47980: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47988: 85 10 00 00 8b a5 00 00      	call 0xa58b
   47990: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47998: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x47890>
   479a0: 7b 2a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r2
   479a8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x478c8>
   479b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   479b8: 18 03 00 00 0f dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd0f
   479c8: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   479d0: 85 10 00 00 67 78 ff ff      	call -0x8799
   479d8: 55 00 f2 fe 02 00 00 00      	jne r0, 0x2, -0x10e <.text+0x47050>
   479e0: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   479e8: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   479f0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   479f8: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   47a00: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   47a08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47a10: 07 01 00 00 90 fc ff ff      	add64 r1, -0x370
   47a18: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47a20: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   47a28: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47a30: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   47a38: 85 10 00 00 ce 7a ff ff      	call -0x8532
   47a40: 79 a7 98 fc 00 00 00 00      	ldxdw r7, [r10 - 0x368]
   47a48: 79 a1 90 fc 00 00 00 00      	ldxdw r1, [r10 - 0x370]
   47a50: 15 01 07 00 02 00 00 00      	jeq r1, 0x2, +0x7 <.text+0x47970>
   47a58: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   47a60: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   47a70: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   47a78: 85 10 00 00 52 78 ff ff      	call -0x87ae
   47a80: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   47a88: 55 00 1a 00 02 00 00 00      	jne r0, 0x2, +0x1a <.text+0x47a40>
   47a90: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47a98: 15 03 0e 00 00 00 00 00      	jeq r3, 0x0, +0xe <.text+0x479f0>
   47aa0: 79 98 00 00 00 00 00 00      	ldxdw r8, [r9 + 0x0]
   47aa8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   47ab0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47ab8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47ac0: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47ac8: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47ad0: 15 03 0b 00 00 00 00 00      	jeq r3, 0x0, +0xb <.text+0x47a10>
   47ad8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47ae0: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   47ae8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47af0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47af8: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47b00: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47b08: 05 00 1f 00 00 00 00 00      	ja +0x1f <.text+0x47ae8>
   47b10: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47b18: 85 10 00 00 59 a5 00 00      	call 0xa559
   47b20: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   47b28: 55 00 55 00 02 00 00 00      	jne r0, 0x2, +0x55 <.text+0x47cb8>
   47b30: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47b38: 85 10 00 00 55 a5 00 00      	call 0xa555
   47b40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47b48: 55 00 0f 00 02 00 00 00      	jne r0, 0x2, +0xf <.text+0x47aa8>
   47b50: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   47b58: 05 00 1d 00 00 00 00 00      	ja +0x1d <.text+0x47b28>
   47b60: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   47b68: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   47b70: 05 00 97 00 00 00 00 00      	ja +0x97 <.text+0x47f10>
   47b78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47b80: 18 03 00 00 f6 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcf6
   47b90: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   47b98: 85 10 00 00 2e 78 ff ff      	call -0x87d2
   47ba0: 55 00 b9 fe 02 00 00 00      	jne r0, 0x2, -0x147 <.text+0x47050>
   47ba8: 7b 1a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r1
   47bb0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   47bb8: 55 01 ac ff 00 00 00 00      	jne r1, 0x0, -0x54 <.text+0x47800>
   47bc0: 05 00 b7 ff 00 00 00 00      	ja -0x49 <.text+0x47860>
   47bc8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47bd0: 18 03 00 00 52 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd52
   47be0: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   47be8: 85 10 00 00 24 78 ff ff      	call -0x87dc
   47bf0: 55 00 af fe 02 00 00 00      	jne r0, 0x2, -0x151 <.text+0x47050>
   47bf8: 7b 1a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r1
   47c00: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47c08: 15 03 07 00 00 00 00 00      	jeq r3, 0x0, +0x7 <.text+0x47b28>
   47c10: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47c18: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   47c20: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47c28: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47c30: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47c38: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47c40: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x47b98>
   47c48: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47c50: 85 10 00 00 32 a5 00 00      	call 0xa532
   47c58: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47c60: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x47b58>
   47c68: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   47c70: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x47bd8>
   47c78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47c80: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   47c90: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   47c98: 85 10 00 00 0e 78 ff ff      	call -0x87f2
   47ca0: 55 00 99 fe 02 00 00 00      	jne r0, 0x2, -0x167 <.text+0x47050>
   47ca8: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   47cb0: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47cb8: 15 03 07 00 00 00 00 00      	jeq r3, 0x0, +0x7 <.text+0x47bd8>
   47cc0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47cc8: 7b 2a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r2
   47cd0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47cd8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47ce0: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47ce8: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47cf0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x47c48>
   47cf8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47d00: 85 10 00 00 1c a5 00 00      	call 0xa51c
   47d08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47d10: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x47c08>
   47d18: 7b 2a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r2
   47d20: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x47c88>
   47d28: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47d30: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   47d40: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   47d48: 85 10 00 00 f8 77 ff ff      	call -0x8808
   47d50: 55 00 83 fe 02 00 00 00      	jne r0, 0x2, -0x17d <.text+0x47050>
   47d58: 7b 1a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r1
   47d60: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47d68: 15 03 07 00 00 00 00 00      	jeq r3, 0x0, +0x7 <.text+0x47c88>
   47d70: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   47d78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47d80: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47d88: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47d90: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47d98: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47da0: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x47d48>
   47da8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47db0: 85 10 00 00 06 a5 00 00      	call 0xa506
   47db8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47dc0: 55 00 0d 00 02 00 00 00      	jne r0, 0x2, +0xd <.text+0x47d10>
   47dc8: 7b 2a f0 fa 00 00 00 00      	stxdw [r10 - 0x510], r2
   47dd0: 05 00 1b 00 00 00 00 00      	ja +0x1b <.text+0x47d90>
   47dd8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47de0: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   47de8: 18 03 00 00 36 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd36
   47df8: b7 04 00 00 1c 00 00 00      	mov64 r4, 0x1c
   47e00: 85 10 00 00 e1 77 ff ff      	call -0x881f
   47e08: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   47e10: 55 00 4f 00 02 00 00 00      	jne r0, 0x2, +0x4f <.text+0x47f70>
   47e18: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47e20: 55 03 96 ff 00 00 00 00      	jne r3, 0x0, -0x6a <.text+0x479b8>
   47e28: 05 00 a0 ff 00 00 00 00      	ja -0x60 <.text+0x47a10>
   47e30: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47e38: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   47e48: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   47e50: 85 10 00 00 d7 77 ff ff      	call -0x8829
   47e58: 55 00 62 fe 02 00 00 00      	jne r0, 0x2, -0x19e <.text+0x47050>
   47e60: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   47e68: 7b 1a f0 fa 00 00 00 00      	stxdw [r10 - 0x510], r1
   47e70: 15 03 07 00 00 00 00 00      	jeq r3, 0x0, +0x7 <.text+0x47d90>
   47e78: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   47e80: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   47e88: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   47e90: 7b 1a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r1
   47e98: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   47ea0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   47ea8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x47df8>
   47eb0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   47eb8: 85 10 00 00 e5 a4 00 00      	call 0xa4e5
   47ec0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47ec8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x47dc0>
   47ed0: 7b 2a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r2
   47ed8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x47df8>
   47ee0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   47ee8: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   47ef8: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   47f00: 85 10 00 00 c1 77 ff ff      	call -0x883f
   47f08: 55 00 4c fe 02 00 00 00      	jne r0, 0x2, -0x1b4 <.text+0x47050>
   47f10: 7b 1a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r1
   47f18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   47f20: 07 01 00 00 a0 fc ff ff      	add64 r1, -0x360
   47f28: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   47f30: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   47f38: 85 10 00 00 46 85 ff ff      	call -0x7aba
   47f40: 79 a2 a8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x358]
   47f48: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   47f50: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x47e68>
   47f58: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   47f68: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   47f70: 85 10 00 00 b3 77 ff ff      	call -0x884d
   47f78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   47f80: 55 00 13 00 02 00 00 00      	jne r0, 0x2, +0x13 <.text+0x47f00>
   47f88: 7b 2a c0 fa 00 00 00 00      	stxdw [r10 - 0x540], r2
   47f90: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   47f98: 7b 7a c8 fa 00 00 00 00      	stxdw [r10 - 0x538], r7
   47fa0: 7b 8a d8 fa 00 00 00 00      	stxdw [r10 - 0x528], r8
   47fa8: 15 01 12 00 00 00 00 00      	jeq r1, 0x0, +0x12 <.text+0x47f20>
   47fb0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47fb8: 7b 2a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r2
   47fc0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   47fc8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   47fd0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   47fd8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   47fe0: 15 01 0f 00 00 00 00 00      	jeq r1, 0x0, +0xf <.text+0x47f40>
   47fe8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   47ff0: 7b 2a d0 fa 00 00 00 00      	stxdw [r10 - 0x530], r2
   47ff8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   48000: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   48008: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   48010: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   48018: 05 00 19 00 00 00 00 00      	ja +0x19 <.text+0x47fc8>
   48020: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   48028: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   48030: 7b 01 08 00 00 00 00 00      	stxdw [r1 + 0x8], r0
   48038: 05 00 de fd 00 00 00 00      	ja -0x222 <.text+0x46e10>
   48040: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   48048: 85 10 00 00 b3 a4 00 00      	call 0xa4b3
   48050: 7b 1a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r1
   48058: 55 00 79 00 02 00 00 00      	jne r0, 0x2, +0x79 <.text+0x48308>
   48060: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   48068: 85 10 00 00 af a4 00 00      	call 0xa4af
   48070: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48078: 55 00 05 00 02 00 00 00      	jne r0, 0x2, +0x5 <.text+0x47f88>
   48080: 7b 2a d0 fa 00 00 00 00      	stxdw [r10 - 0x530], r2
   48088: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x48008>
   48090: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   48098: 7b 81 10 00 00 00 00 00      	stxdw [r1 + 0x10], r8
   480a0: 05 00 f1 ff 00 00 00 00      	ja -0xf <.text+0x47f10>
   480a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   480b0: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   480c0: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   480c8: 85 10 00 00 88 77 ff ff      	call -0x8878
   480d0: 7b 1a d0 fa 00 00 00 00      	stxdw [r10 - 0x530], r1
   480d8: 55 00 7a 00 02 00 00 00      	jne r0, 0x2, +0x7a <.text+0x48390>
   480e0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   480e8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x48008>
   480f0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   480f8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   48100: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   48108: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   48110: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   48118: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   48120: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x48070>
   48128: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   48130: 85 10 00 00 96 a4 00 00      	call 0xa496
   48138: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48140: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x48038>
   48148: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   48150: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x48070>
   48158: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48160: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   48170: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   48178: 85 10 00 00 72 77 ff ff      	call -0x888e
   48180: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   48188: 55 00 67 00 02 00 00 00      	jne r0, 0x2, +0x67 <.text+0x483a8>
   48190: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48198: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   481a0: 85 10 00 00 df ad 00 00      	call 0xaddf
   481a8: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   481b0: 55 01 04 00 01 00 00 00      	jne r1, 0x1, +0x4 <.text+0x480b8>
   481b8: 61 a2 08 ff 00 00 00 00      	ldxw r2, [r10 - 0xf8]
   481c0: 61 a1 04 ff 00 00 00 00      	ldxw r1, [r10 - 0xfc]
   481c8: 85 10 00 00 ec 9e 00 00      	call 0x9eec
   481d0: 05 00 f3 fd 00 00 00 00      	ja -0x20d <.text+0x47050>
   481d8: 79 a1 0c ff 00 00 00 00      	ldxdw r1, [r10 - 0xf4]
   481e0: 7b 1a b4 fc 00 00 00 00      	stxdw [r10 - 0x34c], r1
   481e8: 79 a1 14 ff 00 00 00 00      	ldxdw r1, [r10 - 0xec]
   481f0: 7b 1a bc fc 00 00 00 00      	stxdw [r10 - 0x344], r1
   481f8: 61 a1 1c ff 00 00 00 00      	ldxw r1, [r10 - 0xe4]
   48200: 63 1a c4 fc 00 00 00 00      	stxw [r10 - 0x33c], r1
   48208: 61 a1 08 ff 00 00 00 00      	ldxw r1, [r10 - 0xf8]
   48210: 63 1a b0 fc 00 00 00 00      	stxw [r10 - 0x350], r1
   48218: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48220: 07 01 00 00 f8 fb ff ff      	add64 r1, -0x408
   48228: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   48230: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48238: 07 01 00 00 e0 fb ff ff      	add64 r1, -0x420
   48240: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   48248: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48250: 07 01 00 00 58 fc ff ff      	add64 r1, -0x3a8
   48258: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   48260: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48268: 07 01 00 00 d8 fb ff ff      	add64 r1, -0x428
   48270: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   48278: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48280: 07 01 00 00 b8 fb ff ff      	add64 r1, -0x448
   48288: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   48290: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48298: 07 01 00 00 20 fc ff ff      	add64 r1, -0x3e0
   482a0: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   482a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   482b0: 07 01 00 00 d0 fb ff ff      	add64 r1, -0x430
   482b8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   482c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   482c8: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   482d0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   482d8: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   482e0: 85 10 00 00 79 05 00 00      	call 0x579
   482e8: 79 a3 d0 fc 00 00 00 00      	ldxdw r3, [r10 - 0x330]
   482f0: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   482f8: 55 01 31 00 02 00 00 00      	jne r1, 0x2, +0x31 <.text+0x48368>
   48300: 7b 3a b0 fa 00 00 00 00      	stxdw [r10 - 0x550], r3
   48308: 79 32 20 00 00 00 00 00      	ldxdw r2, [r3 + 0x20]
   48310: 71 21 29 00 00 00 00 00      	ldxb r1, [r2 + 0x29]
   48318: 15 01 3b 00 00 00 00 00      	jeq r1, 0x0, +0x3b <.text+0x483d8>
   48320: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   48328: 07 08 00 00 c8 fc ff ff      	add64 r8, -0x338
   48330: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   48338: 85 10 00 00 4a 82 ff ff      	call -0x7db6
   48340: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   48348: 85 10 00 00 15 b0 00 00      	call 0xb015
   48350: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   48358: 79 a1 b0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x550]
   48360: 79 12 20 00 00 00 00 00      	ldxdw r2, [r1 + 0x20]
   48368: bf a9 00 00 00 00 00 00      	mov64 r9, r10
   48370: 07 09 00 00 00 ff ff ff      	add64 r9, -0x100
   48378: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   48380: 85 10 00 00 41 82 ff ff      	call -0x7dbf
   48388: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48390: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   48398: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   483a0: 85 10 00 00 23 b0 00 00      	call 0xb023
   483a8: 61 a1 d8 fe 00 00 00 00      	ldxw r1, [r10 - 0x128]
   483b0: 55 01 31 00 01 00 00 00      	jne r1, 0x1, +0x31 <.text+0x48420>
   483b8: 61 a2 e0 fe 00 00 00 00      	ldxw r2, [r10 - 0x120]
   483c0: 61 a1 dc fe 00 00 00 00      	ldxw r1, [r10 - 0x124]
   483c8: 85 10 00 00 ac 9e 00 00      	call 0x9eac
   483d0: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   483d8: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   483e0: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   483e8: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   483f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   483f8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   48400: 85 10 00 00 5b 7f ff ff      	call -0x80a5
   48408: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48410: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48418: 85 10 00 00 58 7f ff ff      	call -0x80a8
   48420: 05 00 62 fd 00 00 00 00      	ja -0x29e <.text+0x46e18>
   48428: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48430: 79 a2 e8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x518]
   48438: 18 03 00 00 97 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd97
   48448: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   48450: 85 10 00 00 17 77 ff ff      	call -0x88e9
   48458: 7b 1a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r1
   48460: 55 00 0f 00 02 00 00 00      	jne r0, 0x2, +0xf <.text+0x483c0>
   48468: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   48470: 79 a8 d8 fa 00 00 00 00      	ldxdw r8, [r10 - 0x528]
   48478: 55 01 6d ff 00 00 00 00      	jne r1, 0x0, -0x93 <.text+0x47ec8>
   48480: 05 00 7b ff 00 00 00 00      	ja -0x85 <.text+0x47f40>
   48488: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   48490: 7b 32 10 00 00 00 00 00      	stxdw [r2 + 0x10], r3
   48498: 7b 12 08 00 00 00 00 00      	stxdw [r2 + 0x8], r1
   484a0: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   484a8: 05 00 51 fd 00 00 00 00      	ja -0x2af <.text+0x46e18>
   484b0: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   484b8: 79 a2 d0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x530]
   484c0: 05 00 6c ff 00 00 00 00      	ja -0x94 <.text+0x47f08>
   484c8: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   484d0: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   484d8: 05 00 69 ff 00 00 00 00      	ja -0x97 <.text+0x47f08>
   484e0: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   484e8: 79 a2 e8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x518]
   484f0: 05 00 66 ff 00 00 00 00      	ja -0x9a <.text+0x47f08>
   484f8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   48500: 85 10 00 00 1c a4 00 00      	call 0xa41c
   48508: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48510: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48518: 18 03 00 00 c4 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddc4
   48528: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   48530: 85 10 00 00 fb 76 ff ff      	call -0x8905
   48538: 05 00 86 fd 00 00 00 00      	ja -0x27a <.text+0x47050>
   48540: 79 a3 e0 fe 00 00 00 00      	ldxdw r3, [r10 - 0x120]
   48548: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48550: 07 01 00 00 b0 fc ff ff      	add64 r1, -0x350
   48558: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   48560: 85 10 00 00 ac ad 00 00      	call 0xadac
   48568: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   48570: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48578: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   48580: 85 10 00 00 2b 7f ff ff      	call -0x80d5
   48588: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48590: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48598: 85 10 00 00 28 7f ff ff      	call -0x80d8
   485a0: 15 08 2b 00 00 00 00 00      	jeq r8, 0x0, +0x2b <.text+0x485e0>
   485a8: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   485b8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   485c0: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   485c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   485d0: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   485d8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   485e0: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   485e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   485f0: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   485f8: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   48600: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   48608: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   48610: 07 08 00 00 c8 fc ff ff      	add64 r8, -0x338
   48618: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48620: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   48628: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   48630: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   48638: 85 10 00 00 e9 c3 00 00      	call 0xc3e9
   48640: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   48648: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48650: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48658: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48660: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   48668: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48670: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   48678: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48680: 7b 2a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r2
   48688: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48690: 7b 1a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r1
   48698: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   486a0: 07 02 00 00 f8 fc ff ff      	add64 r2, -0x308
   486a8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   486b0: 85 10 00 00 97 84 ff ff      	call -0x7b69
   486b8: 15 00 0a 00 00 00 00 00      	jeq r0, 0x0, +0xa <.text+0x485f0>
   486c0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   486c8: 85 10 00 00 e3 a3 00 00      	call 0xa3e3
   486d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   486d8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   486e0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   486f0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   486f8: 05 00 b0 00 00 00 00 00      	ja +0xb0 <.text+0x48b60>
   48700: b7 01 00 00 d5 07 00 00      	mov64 r1, 0x7d5
   48708: 05 00 be ff 00 00 00 00      	ja -0x42 <.text+0x483e0>
   48710: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   48718: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48720: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48728: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48730: 7b 2a 30 fd 00 00 00 00      	stxdw [r10 - 0x2d0], r2
   48738: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48740: 7b 2a 28 fd 00 00 00 00      	stxdw [r10 - 0x2d8], r2
   48748: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48750: 7b 2a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r2
   48758: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48760: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   48768: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48770: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48778: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48780: 07 02 00 00 18 fd ff ff      	add64 r2, -0x2e8
   48788: 85 10 00 00 7c 84 ff ff      	call -0x7b84
   48790: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x486b8>
   48798: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   487a0: 85 10 00 00 c8 a3 00 00      	call 0xa3c8
   487a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   487b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   487b8: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   487c8: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   487d0: 05 00 95 00 00 00 00 00      	ja +0x95 <.text+0x48b60>
   487d8: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   487e0: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   487e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   487f0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   487f8: 7b 2a 50 fd 00 00 00 00      	stxdw [r10 - 0x2b0], r2
   48800: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48808: 7b 2a 48 fd 00 00 00 00      	stxdw [r10 - 0x2b8], r2
   48810: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48818: 7b 2a 40 fd 00 00 00 00      	stxdw [r10 - 0x2c0], r2
   48820: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48828: 7b 1a 38 fd 00 00 00 00      	stxdw [r10 - 0x2c8], r1
   48830: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48838: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48840: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48848: 07 02 00 00 38 fd ff ff      	add64 r2, -0x2c8
   48850: 85 10 00 00 63 84 ff ff      	call -0x7b9d
   48858: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x48780>
   48860: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48868: 85 10 00 00 af a3 00 00      	call 0xa3af
   48870: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48878: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48880: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   48890: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   48898: 05 00 7c 00 00 00 00 00      	ja +0x7c <.text+0x48b60>
   488a0: 79 a1 b0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x550]
   488a8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   488b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   488b8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   488c0: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   488c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   488d0: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   488d8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   488e0: 7b 2a 60 fd 00 00 00 00      	stxdw [r10 - 0x2a0], r2
   488e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   488f0: 7b 1a 58 fd 00 00 00 00      	stxdw [r10 - 0x2a8], r1
   488f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48900: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48908: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48910: 07 02 00 00 58 fd ff ff      	add64 r2, -0x2a8
   48918: 85 10 00 00 4a 84 ff ff      	call -0x7bb6
   48920: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x48848>
   48928: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48930: 85 10 00 00 96 a3 00 00      	call 0xa396
   48938: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48940: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48948: 18 03 00 00 c4 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddc4
   48958: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   48960: 05 00 63 00 00 00 00 00      	ja +0x63 <.text+0x48b60>
   48968: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   48970: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48978: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48980: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48988: 7b 2a 90 fd 00 00 00 00      	stxdw [r10 - 0x270], r2
   48990: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48998: 7b 2a 88 fd 00 00 00 00      	stxdw [r10 - 0x278], r2
   489a0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   489a8: 7b 2a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r2
   489b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   489b8: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   489c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   489c8: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   489d0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   489d8: 07 02 00 00 78 fd ff ff      	add64 r2, -0x288
   489e0: 85 10 00 00 31 84 ff ff      	call -0x7bcf
   489e8: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x48910>
   489f0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   489f8: 85 10 00 00 7d a3 00 00      	call 0xa37d
   48a00: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48a08: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48a10: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   48a20: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   48a28: 05 00 4a 00 00 00 00 00      	ja +0x4a <.text+0x48b60>
   48a30: 79 a1 28 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d8]
   48a38: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   48a40: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48a48: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48a50: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   48a58: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48a60: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   48a68: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48a70: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   48a78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48a80: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   48a88: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48a90: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48a98: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48aa0: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   48aa8: 85 10 00 00 18 84 ff ff      	call -0x7be8
   48ab0: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x489d8>
   48ab8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48ac0: 85 10 00 00 64 a3 00 00      	call 0xa364
   48ac8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48ad0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48ad8: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   48ae8: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   48af0: 05 00 31 00 00 00 00 00      	ja +0x31 <.text+0x48b60>
   48af8: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   48b00: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   48b08: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48b10: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48b18: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   48b20: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48b28: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   48b30: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48b38: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   48b40: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48b48: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   48b50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48b58: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48b60: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48b68: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   48b70: 85 10 00 00 ff 83 ff ff      	call -0x7c01
   48b78: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x48aa0>
   48b80: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48b88: 85 10 00 00 4b a3 00 00      	call 0xa34b
   48b90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48b98: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48ba0: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   48bb0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   48bb8: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x48b60>
   48bc0: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   48bc8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   48bd0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48bd8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48be0: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   48be8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48bf0: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   48bf8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48c00: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   48c08: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48c10: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   48c18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48c20: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48c28: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48c30: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   48c38: 85 10 00 00 e6 83 ff ff      	call -0x7c1a
   48c40: 15 00 0d 00 00 00 00 00      	jeq r0, 0x0, +0xd <.text+0x48b90>
   48c48: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48c50: 85 10 00 00 32 a3 00 00      	call 0xa332
   48c58: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48c60: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48c68: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   48c78: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   48c80: 85 10 00 00 11 76 ff ff      	call -0x89ef
   48c88: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   48c90: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   48c98: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   48ca0: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   48ca8: 05 00 51 fc 00 00 00 00      	ja -0x3af <.text+0x46e18>
   48cb0: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   48cb8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   48cc0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48cc8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   48cd0: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   48cd8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   48ce0: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   48ce8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   48cf0: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   48cf8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48d00: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   48d08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48d10: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   48d18: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   48d20: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   48d28: 85 10 00 00 c8 83 ff ff      	call -0x7c38
   48d30: 15 00 09 00 00 00 00 00      	jeq r0, 0x0, +0x9 <.text+0x48c60>
   48d38: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   48d40: 85 10 00 00 14 a3 00 00      	call 0xa314
   48d48: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   48d50: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   48d58: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   48d68: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   48d70: 85 10 00 00 f3 75 ff ff      	call -0x8a0d
   48d78: 05 00 7e fc 00 00 00 00      	ja -0x382 <.text+0x47050>
   48d80: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   48d88: 15 01 70 02 00 00 00 00      	jeq r1, 0x0, +0x270 <.text+0x49ff0>
   48d90: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   48d98: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   48da0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   48da8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   48db0: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   48db8: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   48dc8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   48dd0: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   48dd8: 85 10 00 00 ff ff ff ff      	call -0x1
   48de0: 55 00 db 02 00 00 00 00      	jne r0, 0x0, +0x2db <.text+0x4a3a0>
   48de8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   48df0: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   48df8: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   48e00: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   48e08: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   48e10: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   48e18: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   48e20: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   48e28: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   48e30: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48e38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   48e40: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   48e48: 5d 73 61 02 00 00 00 00      	jne r3, r7, +0x261 <.text+0x4a038>
   48e50: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   48e58: 5d 93 5f 02 00 00 00 00      	jne r3, r9, +0x25f <.text+0x4a038>
   48e60: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   48e68: 5d 83 5d 02 00 00 00 00      	jne r3, r8, +0x25d <.text+0x4a038>
   48e70: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   48e78: 79 a3 a8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x558]
   48e80: 5d 32 5a 02 00 00 00 00      	jne r2, r3, +0x25a <.text+0x4a038>
   48e88: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   48e90: 15 01 76 02 00 00 00 00      	jeq r1, 0x0, +0x276 <.text+0x4a128>
   48e98: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   48ea0: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   48ea8: 7b 1a 98 fa 00 00 00 00      	stxdw [r10 - 0x568], r1
   48eb0: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   48eb8: 7b 1a a0 fa 00 00 00 00      	stxdw [r10 - 0x560], r1
   48ec0: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   48ec8: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   48ed0: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   48ed8: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   48ee0: 7b 3a 90 fa 00 00 00 00      	stxdw [r10 - 0x570], r3
   48ee8: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   48ef0: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   48ef8: 79 22 28 00 00 00 00 00      	ldxdw r2, [r2 + 0x28]
   48f00: 79 19 00 00 00 00 00 00      	ldxdw r9, [r1 + 0x0]
   48f08: 7b 2a 88 fa 00 00 00 00      	stxdw [r10 - 0x578], r2
   48f10: 5d 92 6f 02 00 00 00 00      	jne r2, r9, +0x26f <.text+0x4a170>
   48f18: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   48f20: 5d 81 6d 02 00 00 00 00      	jne r1, r8, +0x26d <.text+0x4a170>
   48f28: 79 a1 a0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x560]
   48f30: 5d 71 6b 02 00 00 00 00      	jne r1, r7, +0x26b <.text+0x4a170>
   48f38: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   48f40: 79 a2 90 fa 00 00 00 00      	ldxdw r2, [r10 - 0x570]
   48f48: 5d 21 68 02 00 00 00 00      	jne r1, r2, +0x268 <.text+0x4a170>
   48f50: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   48f58: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   48f60: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   48f68: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   48f70: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   48f78: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   48f80: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   48f88: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   48f98: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   48fa0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   48fa8: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   48fb0: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   48fb8: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   48fc0: 7b 4a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r4
   48fc8: 7b 3a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r3
   48fd0: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   48fd8: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   48fe0: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   48fe8: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   48ff0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   48ff8: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   49000: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49008: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49010: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   49018: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   49020: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   49028: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   49030: 85 10 00 00 ff ff ff ff      	call -0x1
   49038: 55 00 90 02 00 00 00 00      	jne r0, 0x0, +0x290 <.text+0x4a3a0>
   49040: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   49048: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   49050: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   49058: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   49060: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   49068: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   49070: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   49078: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   49080: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   49088: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49090: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49098: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   490a0: 5d 73 54 02 00 00 00 00      	jne r3, r7, +0x254 <.text+0x4a228>
   490a8: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   490b0: 5d 93 52 02 00 00 00 00      	jne r3, r9, +0x252 <.text+0x4a228>
   490b8: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   490c0: 5d 83 50 02 00 00 00 00      	jne r3, r8, +0x250 <.text+0x4a228>
   490c8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   490d0: 79 a3 a8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x558]
   490d8: 5d 32 4d 02 00 00 00 00      	jne r2, r3, +0x24d <.text+0x4a228>
   490e0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   490e8: 15 01 56 02 00 00 00 00      	jeq r1, 0x0, +0x256 <.text+0x4a280>
   490f0: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   490f8: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   49100: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   49108: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   49110: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   49118: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   49120: 85 10 00 00 8d 80 ff ff      	call -0x7f73
   49128: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   49130: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   49138: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   49140: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   49148: 5d 34 53 02 00 00 00 00      	jne r4, r3, +0x253 <.text+0x4a2c8>
   49150: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   49158: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   49160: 5d 34 50 02 00 00 00 00      	jne r4, r3, +0x250 <.text+0x4a2c8>
   49168: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   49170: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   49178: 5d 34 4d 02 00 00 00 00      	jne r4, r3, +0x24d <.text+0x4a2c8>
   49180: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49188: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   49190: 5d 12 4a 02 00 00 00 00      	jne r2, r1, +0x24a <.text+0x4a2c8>
   49198: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   491a0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   491a8: 85 10 00 00 a6 7d ff ff      	call -0x825a
   491b0: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   491b8: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   491c0: 7b 2a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r2
   491c8: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   491d0: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   491d8: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   491e0: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   491e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   491f0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   491f8: 7b 2a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r2
   49200: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49208: 7b 2a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r2
   49210: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49218: 7b 2a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r2
   49220: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49228: 7b 1a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r1
   49230: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   49238: 5d 17 3a 02 00 00 00 00      	jne r7, r1, +0x23a <.text+0x4a2f0>
   49240: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   49248: 5d 18 38 02 00 00 00 00      	jne r8, r1, +0x238 <.text+0x4a2f0>
   49250: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   49258: 5d 19 36 02 00 00 00 00      	jne r9, r1, +0x236 <.text+0x4a2f0>
   49260: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   49268: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   49270: 5d 12 33 02 00 00 00 00      	jne r2, r1, +0x233 <.text+0x4a2f0>
   49278: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   49280: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   49288: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   49290: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   49298: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   492a0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   492a8: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   492b0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   492b8: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   492c0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   492c8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   492d0: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   492d8: 07 08 00 00 00 ff ff ff      	add64 r8, -0x100
   492e0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   492e8: 85 10 00 00 54 80 ff ff      	call -0x7fac
   492f0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   492f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49300: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   49308: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49310: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   49318: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49320: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   49328: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49330: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   49338: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   49340: 07 01 00 00 38 fe ff ff      	add64 r1, -0x1c8
   49348: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   49350: 07 02 00 00 18 fe ff ff      	add64 r2, -0x1e8
   49358: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   49360: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   49368: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49370: 07 04 00 00 c8 fc ff ff      	add64 r4, -0x338
   49378: 85 10 00 00 20 99 00 00      	call 0x9920
   49380: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   49388: 85 10 00 00 6a 7d ff ff      	call -0x8296
   49390: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   49398: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   493a0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   493a8: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   493b0: 7b 3a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r3
   493b8: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   493c0: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   493c8: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   493d0: 79 a2 38 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1c8]
   493d8: 5d 27 28 02 00 00 00 00      	jne r7, r2, +0x228 <.text+0x4a400>
   493e0: 79 a2 40 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1c0]
   493e8: 5d 28 26 02 00 00 00 00      	jne r8, r2, +0x226 <.text+0x4a400>
   493f0: 79 a2 48 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1b8]
   493f8: 5d 29 24 02 00 00 00 00      	jne r9, r2, +0x224 <.text+0x4a400>
   49400: 79 a2 50 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1b0]
   49408: 79 a3 a8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x558]
   49410: 5d 23 21 02 00 00 00 00      	jne r3, r2, +0x221 <.text+0x4a400>
   49418: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49420: 15 01 36 02 00 00 00 00      	jeq r1, 0x0, +0x236 <.text+0x4a4b8>
   49428: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   49430: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49438: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49440: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   49448: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   49450: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   49460: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   49468: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   49470: 85 10 00 00 ff ff ff ff      	call -0x1
   49478: 55 00 08 02 00 00 00 00      	jne r0, 0x0, +0x208 <.text+0x4a3a0>
   49480: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   49488: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   49490: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   49498: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   494a0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   494a8: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   494b0: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   494b8: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   494c0: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   494c8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   494d0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   494d8: 5d 72 26 02 00 00 00 00      	jne r2, r7, +0x226 <.text+0x4a4f0>
   494e0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   494e8: 5d 82 24 02 00 00 00 00      	jne r2, r8, +0x224 <.text+0x4a4f0>
   494f0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   494f8: 5d 92 22 02 00 00 00 00      	jne r2, r9, +0x222 <.text+0x4a4f0>
   49500: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49508: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   49510: 5d 21 1f 02 00 00 00 00      	jne r1, r2, +0x21f <.text+0x4a4f0>
   49518: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   49520: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49528: 15 01 35 02 00 00 00 00      	jeq r1, 0x0, +0x235 <.text+0x4a5b8>
   49530: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   49538: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49540: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   49548: 7b 2a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r2
   49550: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   49558: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   49560: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   49568: 18 01 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r1, -0x6c5e9a281e0922fa
   49578: 5d 17 34 02 00 00 00 00      	jne r7, r1, +0x234 <.text+0x4a600>
   49580: 18 01 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r1, -0x53861431b91e3427
   49590: 5d 18 31 02 00 00 00 00      	jne r8, r1, +0x231 <.text+0x4a600>
   49598: 18 01 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r1, -0x6ec8a4a0127a4be4
   495a8: 5d 19 2e 02 00 00 00 00      	jne r9, r1, +0x22e <.text+0x4a600>
   495b0: 18 01 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r1, -0x56ff00817a0a73c6
   495c0: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   495c8: 5d 12 2a 02 00 00 00 00      	jne r2, r1, +0x22a <.text+0x4a600>
   495d0: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   495d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   495e0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   495e8: 15 01 40 02 00 00 00 00      	jeq r1, 0x0, +0x240 <.text+0x4a6d0>
   495f0: 79 a1 28 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d8]
   495f8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   49600: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49608: 15 01 45 02 00 00 00 00      	jeq r1, 0x0, +0x245 <.text+0x4a718>
   49610: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   49618: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   49620: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49628: 15 01 4a 02 00 00 00 00      	jeq r1, 0x0, +0x24a <.text+0x4a760>
   49630: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   49638: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49640: 15 01 50 02 00 00 00 00      	jeq r1, 0x0, +0x250 <.text+0x4a7a8>
   49648: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   49650: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   49658: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49660: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49668: 18 03 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r3, -0x6c5e9a281e0922fa
   49678: 5d 32 b0 01 00 00 00 00      	jne r2, r3, +0x1b0 <.text+0x4a2e0>
   49680: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49688: 18 03 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r3, -0x53861431b91e3427
   49698: 5d 32 ac 01 00 00 00 00      	jne r2, r3, +0x1ac <.text+0x4a2e0>
   496a0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   496a8: 18 03 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r3, -0x6ec8a4a0127a4be4
   496b8: 5d 32 a8 01 00 00 00 00      	jne r2, r3, +0x1a8 <.text+0x4a2e0>
   496c0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   496c8: 18 02 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r2, -0x56ff00817a0a73c6
   496d8: 5d 21 a4 01 00 00 00 00      	jne r1, r2, +0x1a4 <.text+0x4a2e0>
   496e0: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   496e8: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   496f0: 7b 2a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r2
   496f8: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   49700: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   49708: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   49710: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   49718: 79 14 00 00 00 00 00 00      	ldxdw r4, [r1 + 0x0]
   49720: 79 41 18 00 00 00 00 00      	ldxdw r1, [r4 + 0x18]
   49728: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   49730: 79 42 10 00 00 00 00 00      	ldxdw r2, [r4 + 0x10]
   49738: 7b 2a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r2
   49740: 79 43 08 00 00 00 00 00      	ldxdw r3, [r4 + 0x8]
   49748: 7b 3a 60 fe 00 00 00 00      	stxdw [r10 - 0x1a0], r3
   49750: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   49758: 7b 4a 58 fe 00 00 00 00      	stxdw [r10 - 0x1a8], r4
   49760: 5d 47 33 02 00 00 00 00      	jne r7, r4, +0x233 <.text+0x4a7e0>
   49768: 5d 38 32 02 00 00 00 00      	jne r8, r3, +0x232 <.text+0x4a7e0>
   49770: 5d 29 31 02 00 00 00 00      	jne r9, r2, +0x231 <.text+0x4a7e0>
   49778: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   49780: 5d 12 2f 02 00 00 00 00      	jne r2, r1, +0x22f <.text+0x4a7e0>
   49788: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   49790: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49798: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   497a0: 7b 2a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r2
   497a8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   497b0: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   497b8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   497c0: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   497c8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   497d0: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   497d8: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   497e0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   497e8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   497f0: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   497f8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49800: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   49808: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49810: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   49818: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49820: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   49828: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   49830: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   49838: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   49840: 07 02 00 00 58 fe ff ff      	add64 r2, -0x1a8
   49848: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   49850: 07 03 00 00 c8 fc ff ff      	add64 r3, -0x338
   49858: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49860: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49868: 85 10 00 00 82 98 00 00      	call 0x9882
   49870: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   49878: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   49880: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49888: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   49890: 7b 3a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r3
   49898: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   498a0: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   498a8: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   498b0: 79 a2 78 fe 00 00 00 00      	ldxdw r2, [r10 - 0x188]
   498b8: 5d 27 1e 02 00 00 00 00      	jne r7, r2, +0x21e <.text+0x4a890>
   498c0: 79 a2 80 fe 00 00 00 00      	ldxdw r2, [r10 - 0x180]
   498c8: 5d 28 1c 02 00 00 00 00      	jne r8, r2, +0x21c <.text+0x4a890>
   498d0: 79 a2 88 fe 00 00 00 00      	ldxdw r2, [r10 - 0x178]
   498d8: 5d 29 1a 02 00 00 00 00      	jne r9, r2, +0x21a <.text+0x4a890>
   498e0: 79 a2 90 fe 00 00 00 00      	ldxdw r2, [r10 - 0x170]
   498e8: 79 a3 a8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x558]
   498f0: 5d 23 17 02 00 00 00 00      	jne r3, r2, +0x217 <.text+0x4a890>
   498f8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49900: 15 01 2b 02 00 00 00 00      	jeq r1, 0x0, +0x22b <.text+0x4a940>
   49908: 79 a1 00 fb 00 00 00 00      	ldxdw r1, [r10 - 0x500]
   49910: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49918: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   49920: 7b 2a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r2
   49928: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   49930: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   49938: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   49940: 18 01 00 00 0c 14 de fc 00 00 00 00 82 5e c6 76      	lddw r1, 0x76c65e82fcde140c
   49950: 5d 17 2a 02 00 00 00 00      	jne r7, r1, +0x22a <.text+0x4a988>
   49958: 18 01 00 00 94 25 08 18 00 00 00 00 bb 65 40 65      	lddw r1, 0x654065bb18082594
   49968: 5d 18 27 02 00 00 00 00      	jne r8, r1, +0x227 <.text+0x4a988>
   49970: 18 01 00 00 f4 29 8d 31 00 00 00 00 56 d5 71 b4      	lddw r1, -0x4b8e2aa9ce72d60c
   49980: 5d 19 24 02 00 00 00 00      	jne r9, r1, +0x224 <.text+0x4a988>
   49988: 18 01 00 00 d4 f8 09 0c 00 00 00 00 18 e9 a8 63      	lddw r1, 0x63a8e9180c09f8d4
   49998: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   499a0: 5d 12 20 02 00 00 00 00      	jne r2, r1, +0x220 <.text+0x4a988>
   499a8: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   499b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   499b8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   499c0: 79 a2 c8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x538]
   499c8: 79 22 20 00 00 00 00 00      	ldxdw r2, [r2 + 0x20]
   499d0: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   499d8: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   499e0: 5d 34 43 01 00 00 00 00      	jne r4, r3, +0x143 <.text+0x4a2e0>
   499e8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   499f0: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   499f8: 5d 34 40 01 00 00 00 00      	jne r4, r3, +0x140 <.text+0x4a2e0>
   49a00: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   49a08: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   49a10: 5d 34 3d 01 00 00 00 00      	jne r4, r3, +0x13d <.text+0x4a2e0>
   49a18: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49a20: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   49a28: 5d 12 3a 01 00 00 00 00      	jne r2, r1, +0x13a <.text+0x4a2e0>
   49a30: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   49a38: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   49a40: 7b 2a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r2
   49a48: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   49a50: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   49a58: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   49a60: 79 a1 d8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x528]
   49a68: 79 14 00 00 00 00 00 00      	ldxdw r4, [r1 + 0x0]
   49a70: 79 41 18 00 00 00 00 00      	ldxdw r1, [r4 + 0x18]
   49a78: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
   49a80: 79 42 10 00 00 00 00 00      	ldxdw r2, [r4 + 0x10]
   49a88: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   49a90: 79 43 08 00 00 00 00 00      	ldxdw r3, [r4 + 0x8]
   49a98: 7b 3a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r3
   49aa0: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   49aa8: 7b 4a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r4
   49ab0: 5d 47 18 02 00 00 00 00      	jne r7, r4, +0x218 <.text+0x4aa58>
   49ab8: 5d 38 17 02 00 00 00 00      	jne r8, r3, +0x217 <.text+0x4aa58>
   49ac0: 5d 29 16 02 00 00 00 00      	jne r9, r2, +0x216 <.text+0x4aa58>
   49ac8: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   49ad0: 5d 12 14 02 00 00 00 00      	jne r2, r1, +0x214 <.text+0x4aa58>
   49ad8: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   49ae0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49ae8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   49af0: 7b 2a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r2
   49af8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49b00: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   49b08: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49b10: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   49b18: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49b20: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   49b28: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   49b30: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49b38: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   49b40: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   49b48: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49b50: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   49b58: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49b60: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   49b68: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49b70: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   49b78: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   49b80: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   49b88: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   49b90: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   49b98: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   49ba0: 07 03 00 00 c8 fc ff ff      	add64 r3, -0x338
   49ba8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49bb0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49bb8: 85 10 00 00 18 98 00 00      	call 0x9818
   49bc0: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   49bc8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   49bd0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49bd8: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   49be0: 7b 3a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r3
   49be8: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   49bf0: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   49bf8: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   49c00: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   49c08: 5d 27 03 02 00 00 00 00      	jne r7, r2, +0x203 <.text+0x4ab08>
   49c10: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   49c18: 5d 28 01 02 00 00 00 00      	jne r8, r2, +0x201 <.text+0x4ab08>
   49c20: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   49c28: 5d 29 ff 01 00 00 00 00      	jne r9, r2, +0x1ff <.text+0x4ab08>
   49c30: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   49c38: 79 a3 a8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x558]
   49c40: 5d 23 fc 01 00 00 00 00      	jne r3, r2, +0x1fc <.text+0x4ab08>
   49c48: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49c50: 15 01 10 02 00 00 00 00      	jeq r1, 0x0, +0x210 <.text+0x4abb8>
   49c58: 79 a1 a0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x460]
   49c60: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49c68: 15 01 0f 02 00 00 00 00      	jeq r1, 0x0, +0x20f <.text+0x4abc8>
   49c70: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   49c78: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49c80: 15 01 15 02 00 00 00 00      	jeq r1, 0x0, +0x215 <.text+0x4ac10>
   49c88: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   49c90: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49c98: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49ca0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   49ca8: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   49cb0: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   49cc0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   49cc8: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   49cd0: 85 10 00 00 ff ff ff ff      	call -0x1
   49cd8: 55 00 fc 00 00 00 00 00      	jne r0, 0x0, +0xfc <.text+0x4a3a0>
   49ce0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   49ce8: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   49cf0: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   49cf8: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   49d00: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   49d08: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   49d10: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   49d18: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   49d20: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   49d28: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49d30: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49d38: 5d 72 05 02 00 00 00 00      	jne r2, r7, +0x205 <.text+0x4ac48>
   49d40: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49d48: 5d 82 03 02 00 00 00 00      	jne r2, r8, +0x203 <.text+0x4ac48>
   49d50: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49d58: 5d 92 01 02 00 00 00 00      	jne r2, r9, +0x201 <.text+0x4ac48>
   49d60: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49d68: 79 a2 a8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x558]
   49d70: 5d 21 fe 01 00 00 00 00      	jne r1, r2, +0x1fe <.text+0x4ac48>
   49d78: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   49d80: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   49d88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49d90: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49d98: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   49da0: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   49da8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49db0: 18 05 00 00 d6 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xaddd6
   49dc0: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   49dc8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   49dd0: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   49dd8: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   49de0: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   49de8: 7b 4a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r4
   49df0: 7b 3a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r3
   49df8: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   49e00: 7a 0a e0 fe 07 00 00 00      	stdw [r10 - 0x120], 0x7
   49e08: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   49e10: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   49e18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   49e20: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   49e28: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   49e30: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   49e38: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   49e40: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   49e48: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   49e50: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   49e58: 85 10 00 00 ff ff ff ff      	call -0x1
   49e60: 55 00 cb 00 00 00 00 00      	jne r0, 0x0, +0xcb <.text+0x4a3a0>
   49e68: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   49e70: 7b 1a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r1
   49e78: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   49e80: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   49e88: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   49e90: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   49e98: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   49ea0: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   49ea8: 79 a1 e8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x518]
   49eb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   49eb8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   49ec0: 5d 72 df 01 00 00 00 00      	jne r2, r7, +0x1df <.text+0x4aca0>
   49ec8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   49ed0: 5d 82 dd 01 00 00 00 00      	jne r2, r8, +0x1dd <.text+0x4aca0>
   49ed8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   49ee0: 5d 92 db 01 00 00 00 00      	jne r2, r9, +0x1db <.text+0x4aca0>
   49ee8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   49ef0: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   49ef8: 5d 21 d8 01 00 00 00 00      	jne r1, r2, +0x1d8 <.text+0x4aca0>
   49f00: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   49f08: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   49f10: 15 01 ea 01 00 00 00 00      	jeq r1, 0x0, +0x1ea <.text+0x4ad48>
   49f18: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   49f20: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   49f28: 7b 21 f0 00 00 00 00 00      	stxdw [r1 + 0xf0], r2
   49f30: 79 a2 d0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x530]
   49f38: 7b 21 e8 00 00 00 00 00      	stxdw [r1 + 0xe8], r2
   49f40: 79 a2 e8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x518]
   49f48: 7b 21 e0 00 00 00 00 00      	stxdw [r1 + 0xe0], r2
   49f50: 79 a2 c0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x540]
   49f58: 7b 21 d8 00 00 00 00 00      	stxdw [r1 + 0xd8], r2
   49f60: 79 a2 e0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x520]
   49f68: 7b 21 d0 00 00 00 00 00      	stxdw [r1 + 0xd0], r2
   49f70: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   49f78: 7b 21 c8 00 00 00 00 00      	stxdw [r1 + 0xc8], r2
   49f80: 79 a2 f8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x508]
   49f88: 7b 21 c0 00 00 00 00 00      	stxdw [r1 + 0xc0], r2
   49f90: 79 a2 98 fb 00 00 00 00      	ldxdw r2, [r10 - 0x468]
   49f98: 7b 21 b8 00 00 00 00 00      	stxdw [r1 + 0xb8], r2
   49fa0: 79 a2 a0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x460]
   49fa8: 7b 21 b0 00 00 00 00 00      	stxdw [r1 + 0xb0], r2
   49fb0: 79 a2 d8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x528]
   49fb8: 7b 21 a8 00 00 00 00 00      	stxdw [r1 + 0xa8], r2
   49fc0: 79 a2 c8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x538]
   49fc8: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   49fd0: 79 a2 00 fb 00 00 00 00      	ldxdw r2, [r10 - 0x500]
   49fd8: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   49fe0: 79 a2 08 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f8]
   49fe8: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   49ff0: 79 a2 10 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f0]
   49ff8: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   4a000: 79 a2 18 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4e8]
   4a008: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   4a010: 79 a2 20 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4e0]
   4a018: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   4a020: 79 a2 28 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4d8]
   4a028: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   4a030: 79 a2 30 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4d0]
   4a038: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   4a040: 79 a2 38 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4c8]
   4a048: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   4a050: 79 a2 40 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4c0]
   4a058: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   4a060: 79 a2 48 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4b8]
   4a068: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   4a070: 79 a2 50 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4b0]
   4a078: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   4a080: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   4a088: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   4a090: 79 a2 60 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a0]
   4a098: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   4a0a0: 79 a2 68 fb 00 00 00 00      	ldxdw r2, [r10 - 0x498]
   4a0a8: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   4a0b0: 79 a2 b0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x550]
   4a0b8: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   4a0c0: 79 a2 70 fb 00 00 00 00      	ldxdw r2, [r10 - 0x490]
   4a0c8: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   4a0d0: 79 a2 78 fb 00 00 00 00      	ldxdw r2, [r10 - 0x488]
   4a0d8: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   4a0e0: 79 a2 80 fb 00 00 00 00      	ldxdw r2, [r10 - 0x480]
   4a0e8: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   4a0f0: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   4a0f8: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   4a100: 7b 61 00 00 00 00 00 00      	stxdw [r1 + 0x0], r6
   4a108: 05 00 c5 f9 00 00 00 00      	ja -0x63b <.text+0x46e18>
   4a110: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a118: 85 10 00 00 99 a0 00 00      	call 0xa099
   4a120: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a128: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a130: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   4a140: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   4a148: 85 10 00 00 78 73 ff ff      	call -0x8c88
   4a150: 05 00 03 fa 00 00 00 00      	ja -0x5fd <.text+0x47050>
   4a158: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   4a160: 85 10 00 00 90 a0 00 00      	call 0xa090
   4a168: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a170: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a178: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   4a188: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   4a190: 85 10 00 00 6f 73 ff ff      	call -0x8c91
   4a198: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a1a0: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   4a1a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4a1b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4a1b8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   4a1c0: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   4a1c8: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   4a1d0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4a1d8: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   4a1e0: 7b 9a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r9
   4a1e8: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   4a1f0: 79 a6 a8 fa 00 00 00 00      	ldxdw r6, [r10 - 0x558]
   4a1f8: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   4a200: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a208: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   4a210: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   4a218: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   4a220: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   4a228: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   4a230: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a238: 85 10 00 00 f7 9a 00 00      	call 0x9af7
   4a240: 05 00 e5 f9 00 00 00 00      	ja -0x61b <.text+0x47050>
   4a248: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a250: 85 10 00 00 72 a0 00 00      	call 0xa072
   4a258: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a260: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a268: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   4a278: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   4a280: 85 10 00 00 51 73 ff ff      	call -0x8caf
   4a288: 05 00 dc f9 00 00 00 00      	ja -0x624 <.text+0x47050>
   4a290: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   4a298: 85 10 00 00 69 a0 00 00      	call 0xa069
   4a2a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a2a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a2b0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   4a2c0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   4a2c8: 85 10 00 00 48 73 ff ff      	call -0x8cb8
   4a2d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a2d8: 79 a1 90 fa 00 00 00 00      	ldxdw r1, [r10 - 0x570]
   4a2e0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   4a2e8: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   4a2f0: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   4a2f8: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   4a300: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   4a308: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a310: 79 a1 a0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x560]
   4a318: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   4a320: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a328: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   4a330: 79 a1 88 fa 00 00 00 00      	ldxdw r1, [r10 - 0x578]
   4a338: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4a340: 05 00 db ff 00 00 00 00      	ja -0x25 <.text+0x4a100>
   4a348: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   4a350: 85 10 00 00 52 a0 00 00      	call 0xa052
   4a358: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a360: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a368: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   4a378: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   4a380: 85 10 00 00 31 73 ff ff      	call -0x8ccf
   4a388: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a390: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   4a398: 05 00 c1 ff 00 00 00 00      	ja -0x3f <.text+0x4a088>
   4a3a0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a3a8: 85 10 00 00 47 a0 00 00      	call 0xa047
   4a3b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a3b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a3c0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   4a3d0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   4a3d8: 85 10 00 00 26 73 ff ff      	call -0x8cda
   4a3e0: 05 00 b1 f9 00 00 00 00      	ja -0x64f <.text+0x47050>
   4a3e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4a3f0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4a3f8: 85 10 00 00 5c 7b ff ff      	call -0x84a4
   4a400: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   4a408: 05 00 ab f9 00 00 00 00      	ja -0x655 <.text+0x47048>
   4a410: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   4a418: 85 10 00 00 39 a0 00 00      	call 0xa039
   4a420: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a428: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a430: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   4a440: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4a448: 85 10 00 00 18 73 ff ff      	call -0x8ce8
   4a450: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a458: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a460: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a468: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4a470: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4a478: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4a480: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   4a488: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4a490: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   4a498: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4a4a0: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   4a4a8: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4a4b0: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   4a4b8: 05 00 21 00 00 00 00 00      	ja +0x21 <.text+0x4a4a8>
   4a4c0: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   4a4d0: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4a4d8: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   4a4e0: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   4a4e8: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   4a4f0: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   4a4f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4a500: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4a508: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   4a518: 85 10 00 00 6d b4 00 00      	call 0xb46d
   4a520: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   4a528: 85 10 00 00 17 a0 00 00      	call 0xa017
   4a530: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a538: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a540: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   4a550: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4a558: 85 10 00 00 f6 72 ff ff      	call -0x8d0a
   4a560: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a568: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a570: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a578: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4a580: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4a588: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4a590: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   4a598: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4a5a0: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   4a5a8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4a5b0: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   4a5b8: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4a5c0: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   4a5c8: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   4a5d0: 05 00 89 ff 00 00 00 00      	ja -0x77 <.text+0x4a100>
   4a5d8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a5e0: 85 10 00 00 00 a0 00 00      	call 0xa000
   4a5e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a5f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a5f8: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   4a608: 05 00 e3 fb 00 00 00 00      	ja -0x41d <.text+0x48408>
   4a610: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   4a618: 85 10 00 00 f9 9f 00 00      	call 0x9ff9
   4a620: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a628: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a630: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   4a640: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   4a648: 85 10 00 00 d8 72 ff ff      	call -0x8d28
   4a650: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a658: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   4a660: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4a668: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   4a670: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   4a678: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   4a680: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   4a688: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   4a690: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   4a698: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4a6a0: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4a6a8: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a6b0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   4a6b8: 7b 9a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r9
   4a6c0: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   4a6c8: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   4a6d0: 05 00 69 ff 00 00 00 00      	ja -0x97 <.text+0x4a100>
   4a6d8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a6e0: 85 10 00 00 e0 9f 00 00      	call 0x9fe0
   4a6e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a6f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a6f8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   4a708: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   4a710: 85 10 00 00 bf 72 ff ff      	call -0x8d41
   4a718: 05 00 4a f9 00 00 00 00      	ja -0x6b6 <.text+0x47050>
   4a720: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   4a728: 85 10 00 00 d7 9f 00 00      	call 0x9fd7
   4a730: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a738: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a740: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   4a750: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   4a758: 85 10 00 00 b6 72 ff ff      	call -0x8d4a
   4a760: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a768: 18 01 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r1, -0x6c5e9a281e0922fa
   4a778: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4a780: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a788: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a790: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4a798: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4a7a0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4a7a8: 18 01 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r1, -0x53861431b91e3427
   4a7b8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4a7c0: 18 01 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r1, -0x6ec8a4a0127a4be4
   4a7d0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4a7d8: 18 01 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r1, -0x56ff00817a0a73c6
   4a7e8: 05 00 bb ff 00 00 00 00      	ja -0x45 <.text+0x4a4a8>
   4a7f0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a7f8: 85 10 00 00 bd 9f 00 00      	call 0x9fbd
   4a800: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a808: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a810: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   4a820: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   4a828: 85 10 00 00 9c 72 ff ff      	call -0x8d64
   4a830: 05 00 27 f9 00 00 00 00      	ja -0x6d9 <.text+0x47050>
   4a838: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a840: 85 10 00 00 b4 9f 00 00      	call 0x9fb4
   4a848: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a850: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a858: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   4a868: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   4a870: 85 10 00 00 93 72 ff ff      	call -0x8d6d
   4a878: 05 00 1e f9 00 00 00 00      	ja -0x6e2 <.text+0x47050>
   4a880: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a888: 85 10 00 00 ab 9f 00 00      	call 0x9fab
   4a890: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a898: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a8a0: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   4a8b0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   4a8b8: 85 10 00 00 8a 72 ff ff      	call -0x8d76
   4a8c0: 05 00 15 f9 00 00 00 00      	ja -0x6eb <.text+0x47050>
   4a8c8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4a8d0: 85 10 00 00 a2 9f 00 00      	call 0x9fa2
   4a8d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a8e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a8e8: 18 03 00 00 bc dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcbc
   4a8f8: 05 00 8d fc 00 00 00 00      	ja -0x373 <.text+0x48c48>
   4a900: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   4a908: 85 10 00 00 9b 9f 00 00      	call 0x9f9b
   4a910: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a918: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a920: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   4a930: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   4a938: 85 10 00 00 7a 72 ff ff      	call -0x8d86
   4a940: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a948: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4a950: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4a958: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4a960: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4a968: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4a970: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   4a978: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4a980: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   4a988: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4a990: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   4a998: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4a9a0: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   4a9a8: 05 00 83 ff 00 00 00 00      	ja -0x7d <.text+0x4a4a8>
   4a9b0: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   4a9b8: 85 10 00 00 85 9f 00 00      	call 0x9f85
   4a9c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a9c8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4a9d0: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   4a9e0: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   4a9e8: 85 10 00 00 64 72 ff ff      	call -0x8d9c
   4a9f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4a9f8: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4aa00: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4aa08: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4aa10: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4aa18: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4aa20: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
   4aa28: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4aa30: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
   4aa38: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4aa40: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
   4aa48: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4aa50: 79 a1 90 fe 00 00 00 00      	ldxdw r1, [r10 - 0x170]
   4aa58: 05 00 6d ff 00 00 00 00      	ja -0x93 <.text+0x4a4a8>
   4aa60: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4aa68: 85 10 00 00 6f 9f 00 00      	call 0x9f6f
   4aa70: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4aa78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4aa80: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   4aa90: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   4aa98: 85 10 00 00 4e 72 ff ff      	call -0x8db2
   4aaa0: 05 00 d9 f8 00 00 00 00      	ja -0x727 <.text+0x47050>
   4aaa8: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   4aab0: 85 10 00 00 66 9f 00 00      	call 0x9f66
   4aab8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4aac0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4aac8: 18 03 00 00 0f dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd0f
   4aad8: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   4aae0: 85 10 00 00 45 72 ff ff      	call -0x8dbb
   4aae8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4aaf0: 18 01 00 00 0c 14 de fc 00 00 00 00 82 5e c6 76      	lddw r1, 0x76c65e82fcde140c
   4ab00: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4ab08: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4ab10: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4ab18: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4ab20: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4ab28: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4ab30: 18 01 00 00 94 25 08 18 00 00 00 00 bb 65 40 65      	lddw r1, 0x654065bb18082594
   4ab40: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4ab48: 18 01 00 00 f4 29 8d 31 00 00 00 00 56 d5 71 b4      	lddw r1, -0x4b8e2aa9ce72d60c
   4ab58: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4ab60: 18 01 00 00 d4 f8 09 0c 00 00 00 00 18 e9 a8 63      	lddw r1, 0x63a8e9180c09f8d4
   4ab70: 05 00 4a ff 00 00 00 00      	ja -0xb6 <.text+0x4a4a8>
   4ab78: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   4ab80: 85 10 00 00 4c 9f 00 00      	call 0x9f4c
   4ab88: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ab90: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ab98: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   4aba8: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   4abb0: 85 10 00 00 2b 72 ff ff      	call -0x8dd5
   4abb8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4abc0: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4abc8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4abd0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4abd8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4abe0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4abe8: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   4abf0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4abf8: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   4ac00: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4ac08: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   4ac10: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4ac18: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   4ac20: 05 00 34 ff 00 00 00 00      	ja -0xcc <.text+0x4a4a8>
   4ac28: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   4ac30: 85 10 00 00 36 9f 00 00      	call 0x9f36
   4ac38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ac40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ac48: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   4ac58: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   4ac60: 85 10 00 00 15 72 ff ff      	call -0x8deb
   4ac68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ac70: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4ac78: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4ac80: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   4ac88: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   4ac90: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   4ac98: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   4aca0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4aca8: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   4acb0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4acb8: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   4acc0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4acc8: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   4acd0: 05 00 1e ff 00 00 00 00      	ja -0xe2 <.text+0x4a4a8>
   4acd8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4ace0: 05 00 0b fc 00 00 00 00      	ja -0x3f5 <.text+0x48c20>
   4ace8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4acf0: 85 10 00 00 1e 9f 00 00      	call 0x9f1e
   4acf8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ad00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ad08: 18 03 00 00 52 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd52
   4ad18: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   4ad20: 85 10 00 00 fd 71 ff ff      	call -0x8e03
   4ad28: 05 00 88 f8 00 00 00 00      	ja -0x778 <.text+0x47050>
   4ad30: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4ad38: 85 10 00 00 15 9f 00 00      	call 0x9f15
   4ad40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ad48: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ad50: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   4ad60: 05 00 60 ff 00 00 00 00      	ja -0xa0 <.text+0x4a748>
   4ad68: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   4ad70: 85 10 00 00 0e 9f 00 00      	call 0x9f0e
   4ad78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ad80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ad88: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   4ad98: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   4ada0: 85 10 00 00 ed 71 ff ff      	call -0x8e13
   4ada8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4adb0: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   4adb8: 05 00 14 ff 00 00 00 00      	ja -0xec <.text+0x4a540>
   4adc0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   4adc8: 85 10 00 00 03 9f 00 00      	call 0x9f03
   4add0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4add8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ade0: 18 03 00 00 97 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd97
   4adf0: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   4adf8: 85 10 00 00 e2 71 ff ff      	call -0x8e1e
   4ae00: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ae08: 79 a1 e8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x518]
   4ae10: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ae18: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   4ae20: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   4ae28: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   4ae30: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   4ae38: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   4ae40: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   4ae48: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ae50: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4ae58: 79 a1 a8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x458]
   4ae60: 05 00 09 ff 00 00 00 00      	ja -0xf7 <.text+0x4a590>
   4ae68: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4ae70: 85 10 00 00 ee 9e 00 00      	call 0x9eee
   4ae78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ae80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ae88: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   4ae98: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   4aea0: 85 10 00 00 cd 71 ff ff      	call -0x8e33
   4aea8: 05 00 58 f8 00 00 00 00      	ja -0x7a8 <.text+0x47050>
   4cc98: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   4cca0: 7b 4a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r4
   4cca8: bf 39 00 00 00 00 00 00      	mov64 r9, r3
   4ccb0: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   4ccb8: 7b 1a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r1
   4ccc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ccc8: 07 01 00 00 c0 fb ff ff      	add64 r1, -0x440
   4ccd0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4ccd8: 85 10 00 00 6a 7a ff ff      	call -0x8596
   4cce0: 79 a6 c8 fb 00 00 00 00      	ldxdw r6, [r10 - 0x438]
   4cce8: 79 a8 c0 fb 00 00 00 00      	ldxdw r8, [r10 - 0x440]
   4ccf0: 55 08 2f 00 02 00 00 00      	jne r8, 0x2, +0x2f <.text+0x4cd50>
   4ccf8: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   4cd00: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   4cd08: 79 78 08 f0 00 00 00 00      	ldxdw r8, [r7 - 0xff8]
   4cd10: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   4cd18: 7b 6a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r6
   4cd20: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4cd28: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4cd30: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4cd38: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4cd40: 85 10 00 00 b1 7a ff ff      	call -0x854f
   4cd48: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   4cd50: 55 01 54 00 02 00 00 00      	jne r1, 0x2, +0x54 <.text+0x4ced8>
   4cd58: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   4cd60: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   4cd68: 85 10 00 00 10 6d 00 00      	call 0x6d10
   4cd70: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   4cd80: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4cd88: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4cd90: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   4cd98: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   4cda0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4cda8: 2d 21 60 00 00 00 00 00      	jgt r1, r2, +0x60 <.text+0x4cf90>
   4cdb0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4cdb8: 15 04 5f 00 00 00 00 00      	jeq r4, 0x0, +0x5f <.text+0x4cf98>
   4cdc0: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   4cdd0: 15 02 60 00 00 00 00 00      	jeq r2, 0x0, +0x60 <.text+0x4cfb8>
   4cdd8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   4cde0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4cdf0: 15 06 5f 00 01 00 00 00      	jeq r6, 0x1, +0x5f <.text+0x4cfd0>
   4cdf8: bd 21 5f 00 00 00 00 00      	jle r1, r2, +0x5f <.text+0x4cfd8>
   4ce00: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4ce10: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4ce18: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   4ce28: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   4ce30: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   4ce40: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   4ce48: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   4ce50: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   4ce58: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   4ce60: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   4ce68: 05 00 38 01 00 00 00 00      	ja +0x138 <.text+0x4d710>
   4ce70: 85 10 00 00 ef 6c 00 00      	call 0x6cef
   4ce78: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   4ce88: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4ce90: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4ce98: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   4cea0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   4cea8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4ceb0: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <.text+0x4ce18>
   4ceb8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4cec0: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <.text+0x4ce20>
   4cec8: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   4ced8: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x4ce40>
   4cee0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   4cee8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4cef0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   4cef8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4cf08: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <.text+0x4ce68>
   4cf10: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   4cf18: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   4cf20: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   4cf30: 85 10 00 00 22 ad 00 00      	call 0xad22
   4cf38: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <.text+0x4cda8>
   4cf40: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4cf48: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   4cf58: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x4cdc0>
   4cf60: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4cf68: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   4cf70: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4cf80: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <.text+0x4cdf0>
   4cf88: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4cf98: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4cfa0: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   4cfa8: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   4cfb0: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   4cfb8: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   4cfc0: 7a 06 18 00 06 00 00 00      	stdw [r6 + 0x18], 0x6
   4cfc8: 7a 06 08 00 06 00 00 00      	stdw [r6 + 0x8], 0x6
   4cfd0: 7a 06 00 00 01 00 00 00      	stdw [r6 + 0x0], 0x1
   4cfd8: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4cfe0: 7b 61 10 00 00 00 00 00      	stxdw [r1 + 0x10], r6
   4cfe8: 7b 81 08 00 00 00 00 00      	stxdw [r1 + 0x8], r8
   4cff0: 05 00 0b 01 00 00 00 00      	ja +0x10b <.text+0x4d730>
   4cff8: 85 10 00 00 be 6c 00 00      	call 0x6cbe
   4d000: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   4d010: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   4d018: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   4d020: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   4d028: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   4d030: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d038: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x4d000>
   4d040: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d048: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x4d008>
   4d050: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   4d060: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x4d028>
   4d068: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   4d070: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d078: 7b 8a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r8
   4d080: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d090: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x4d048>
   4d098: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   4d0a0: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   4d0a8: 85 10 00 00 f7 ac 00 00      	call 0xacf7
   4d0b0: 55 04 a1 ff 00 00 00 00      	jne r4, 0x0, -0x5f <.text+0x4cca0>
   4d0b8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4d0c0: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   4d0d0: 55 02 a0 ff 00 00 00 00      	jne r2, 0x0, -0x60 <.text+0x4ccb8>
   4d0d8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d0e8: 55 06 a1 ff 01 00 00 00      	jne r6, 0x1, -0x5f <.text+0x4ccd8>
   4d0f0: 2d 21 a1 ff 00 00 00 00      	jgt r1, r2, -0x5f <.text+0x4cce0>
   4d0f8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   4d100: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   4d108: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   4d118: 85 10 00 00 e5 ac 00 00      	call 0xace5
   4d120: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x4cf30>
   4d128: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   4d130: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   4d140: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x4cf48>
   4d148: 7b 8a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r8
   4d150: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d160: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x4cf78>
   4d168: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
   4d178: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   4d180: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4d188: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4d190: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   4d198: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   4d1a0: 85 10 00 00 7c ba 00 00      	call 0xba7c
   4d1a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4d1b0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4d1b8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4d1c0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4d1c8: 85 10 00 00 ed 79 ff ff      	call -0x8613
   4d1d0: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   4d1d8: 55 01 1f 00 02 00 00 00      	jne r1, 0x2, +0x1f <.text+0x4d1b8>
   4d1e0: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   4d1e8: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   4d1f0: 85 10 00 00 7f 6c 00 00      	call 0x6c7f
   4d1f8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   4d200: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d208: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   4d210: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   4d218: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d220: 2d 21 2a 00 00 00 00 00      	jgt r1, r2, +0x2a <.text+0x4d258>
   4d228: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d230: 15 04 29 00 00 00 00 00      	jeq r4, 0x0, +0x29 <.text+0x4d260>
   4d238: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   4d248: 15 02 2a 00 00 00 00 00      	jeq r2, 0x0, +0x2a <.text+0x4d280>
   4d250: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   4d258: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d268: 15 06 29 00 01 00 00 00      	jeq r6, 0x1, +0x29 <.text+0x4d298>
   4d270: bd 21 29 00 00 00 00 00      	jle r1, r2, +0x29 <.text+0x4d2a0>
   4d278: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4d288: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4d290: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   4d2a0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   4d2a8: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   4d2b0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   4d2b8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   4d2c0: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   4d2c8: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   4d2d0: 05 00 ab 00 00 00 00 00      	ja +0xab <.text+0x4d710>
   4d2d8: 85 10 00 00 62 6c 00 00      	call 0x6c62
   4d2e0: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   4d2e8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   4d2f0: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   4d2f8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   4d300: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d308: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x4d2c8>
   4d310: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d318: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x4d2d0>
   4d320: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   4d330: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x4d2f0>
   4d338: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   4d340: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d348: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d358: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x4d308>
   4d360: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   4d368: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   4d370: 85 10 00 00 9e ac 00 00      	call 0xac9e
   4d378: 55 04 d7 ff 00 00 00 00      	jne r4, 0x0, -0x29 <.text+0x4d118>
   4d380: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4d388: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   4d398: 55 02 d6 ff 00 00 00 00      	jne r2, 0x0, -0x2a <.text+0x4d130>
   4d3a0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d3b0: 55 06 d7 ff 01 00 00 00      	jne r6, 0x1, -0x29 <.text+0x4d150>
   4d3b8: 2d 21 d7 ff 00 00 00 00      	jgt r1, r2, -0x29 <.text+0x4d158>
   4d3c0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   4d3c8: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   4d3d0: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   4d3e0: 85 10 00 00 8c ac 00 00      	call 0xac8c
   4d3e8: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x4d200>
   4d3f0: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   4d3f8: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   4d408: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x4d218>
   4d410: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d420: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x4d240>
   4d428: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   4d430: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4d438: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4d440: 7b 1a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r1
   4d448: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   4d450: 85 10 00 00 26 ba 00 00      	call 0xba26
   4d458: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4d460: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4d468: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4d470: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4d478: 85 10 00 00 0e 6b ff ff      	call -0x94f2
   4d480: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   4d488: 55 01 1c 00 02 00 00 00      	jne r1, 0x2, +0x1c <.text+0x4d450>
   4d490: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   4d498: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   4d4a0: 85 10 00 00 29 6c 00 00      	call 0x6c29
   4d4a8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   4d4b0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d4b8: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   4d4c0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   4d4c8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d4d0: 2d 21 27 00 00 00 00 00      	jgt r1, r2, +0x27 <.text+0x4d4f0>
   4d4d8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d4e0: 15 04 26 00 00 00 00 00      	jeq r4, 0x0, +0x26 <.text+0x4d4f8>
   4d4e8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   4d4f8: 15 02 27 00 00 00 00 00      	jeq r2, 0x0, +0x27 <.text+0x4d518>
   4d500: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   4d508: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d518: 15 06 26 00 01 00 00 00      	jeq r6, 0x1, +0x26 <.text+0x4d530>
   4d520: bd 21 26 00 00 00 00 00      	jle r1, r2, +0x26 <.text+0x4d538>
   4d528: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4d538: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4d540: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   4d548: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   4d550: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   4d558: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   4d560: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   4d568: 05 00 58 00 00 00 00 00      	ja +0x58 <.text+0x4d710>
   4d570: 85 10 00 00 0f 6c 00 00      	call 0x6c0f
   4d578: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   4d580: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   4d588: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   4d590: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   4d598: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d5a0: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x4d560>
   4d5a8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d5b0: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x4d568>
   4d5b8: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   4d5c8: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x4d588>
   4d5d0: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   4d5d8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d5e0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d5f0: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x4d5a0>
   4d5f8: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   4d600: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   4d608: 85 10 00 00 4b ac 00 00      	call 0xac4b
   4d610: 55 04 da ff 00 00 00 00      	jne r4, 0x0, -0x26 <.text+0x4d3c8>
   4d618: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4d620: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   4d630: 55 02 d9 ff 00 00 00 00      	jne r2, 0x0, -0x27 <.text+0x4d3e0>
   4d638: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d648: 55 06 da ff 01 00 00 00      	jne r6, 0x1, -0x26 <.text+0x4d400>
   4d650: 2d 21 da ff 00 00 00 00      	jgt r1, r2, -0x26 <.text+0x4d408>
   4d658: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   4d660: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   4d668: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   4d678: 85 10 00 00 39 ac 00 00      	call 0xac39
   4d680: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x4d498>
   4d688: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   4d690: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   4d6a0: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x4d4b0>
   4d6a8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d6b8: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x4d4d8>
   4d6c0: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   4d6c8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4d6d0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4d6d8: 7b 1a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r1
   4d6e0: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   4d6e8: 85 10 00 00 d3 b9 00 00      	call 0xb9d3
   4d6f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4d6f8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4d700: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4d708: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4d710: 85 10 00 00 cc 6a ff ff      	call -0x9534
   4d718: 61 a1 b0 ff 00 00 00 00      	ldxw r1, [r10 - 0x50]
   4d720: 55 01 27 00 02 00 00 00      	jne r1, 0x2, +0x27 <.text+0x4d740>
   4d728: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   4d730: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   4d738: 85 10 00 00 d6 6b 00 00      	call 0x6bd6
   4d740: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   4d748: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d750: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   4d758: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   4d760: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d768: 2d 21 33 00 00 00 00 00      	jgt r1, r2, +0x33 <.text+0x4d7e8>
   4d770: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d778: 15 04 32 00 00 00 00 00      	jeq r4, 0x0, +0x32 <.text+0x4d7f0>
   4d780: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   4d790: 15 02 33 00 00 00 00 00      	jeq r2, 0x0, +0x33 <.text+0x4d810>
   4d798: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   4d7a0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d7b0: 15 06 32 00 01 00 00 00      	jeq r6, 0x1, +0x32 <.text+0x4d828>
   4d7b8: bd 21 32 00 00 00 00 00      	jle r1, r2, +0x32 <.text+0x4d830>
   4d7c0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4d7d0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4d7d8: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   4d7e8: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   4d7f0: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   4d800: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   4d808: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   4d810: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   4d818: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   4d820: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   4d828: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   4d830: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   4d838: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4d840: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   4d848: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   4d850: 7a 01 00 00 00 00 00 00      	stdw [r1 + 0x0], 0x0
   4d858: 95 00 00 00 00 00 00 00      	exit
   4d860: 85 10 00 00 b1 6b 00 00      	call 0x6bb1
   4d868: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   4d870: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   4d878: 07 03 00 00 28 ff ff ff      	add64 r3, -0xd8
   4d880: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   4d888: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   4d890: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x4d858>
   4d898: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   4d8a0: 79 a8 90 fb 00 00 00 00      	ldxdw r8, [r10 - 0x470]
   4d8a8: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x4d868>
   4d8b0: 18 01 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f28
   4d8c0: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x4d888>
   4d8c8: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   4d8d0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4d8d8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d8e8: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x4d8a0>
   4d8f0: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   4d8f8: b7 02 00 00 d8 00 00 00      	mov64 r2, 0xd8
   4d900: 85 10 00 00 ec ab 00 00      	call 0xabec
   4d908: 55 04 ce ff 00 00 00 00      	jne r4, 0x0, -0x32 <.text+0x4d660>
   4d910: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4d918: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   4d928: 55 02 cd ff 00 00 00 00      	jne r2, 0x0, -0x33 <.text+0x4d678>
   4d930: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d940: 55 06 ce ff 01 00 00 00      	jne r6, 0x1, -0x32 <.text+0x4d698>
   4d948: 2d 21 ce ff 00 00 00 00      	jgt r1, r2, -0x32 <.text+0x4d6a0>
   4d950: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   4d958: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   4d960: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   4d970: 85 10 00 00 da ab 00 00      	call 0xabda
   4d978: 79 a8 90 fb 00 00 00 00      	ldxdw r8, [r10 - 0x470]
   4d980: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x4d790>
   4d988: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   4d990: 18 01 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f28
   4d9a0: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x4d7a8>
   4d9a8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   4d9b8: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x4d7d0>
   4d9c0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   4d9d0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   4d9d8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4d9e0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4d9e8: 7b 1a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r1
   4d9f0: b7 03 00 00 d8 00 00 00      	mov64 r3, 0xd8
   4d9f8: 85 10 00 00 71 b9 00 00      	call 0xb971
   4da00: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4da08: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x4d960>
   4da10: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4da18: 7b 2a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r2
   4da20: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   4da28: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   4da30: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   4da38: bf 24 00 00 00 00 00 00      	mov64 r4, r2
   4da40: 07 04 00 00 30 00 00 00      	add64 r4, 0x30
   4da48: 7b 49 00 00 00 00 00 00      	stxdw [r9 + 0x0], r4
   4da50: 15 03 0c 00 00 00 00 00      	jeq r3, 0x0, +0xc <.text+0x4d998>
   4da58: 07 01 00 00 fe ff ff ff      	add64 r1, -0x2
   4da60: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4da68: 07 02 00 00 60 00 00 00      	add64 r2, 0x60
   4da70: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4da78: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x4d9f8>
   4da80: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4da88: 85 10 00 00 6b 99 00 00      	call 0x996b
   4da90: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   4da98: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   4daa0: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   4daa8: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   4dab0: 05 00 b4 ff 00 00 00 00      	ja -0x4c <.text+0x4d738>
   4dab8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4dac0: 85 10 00 00 64 99 00 00      	call 0x9964
   4dac8: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   4dad0: 15 00 08 00 02 00 00 00      	jeq r0, 0x2, +0x8 <.text+0x4d9f8>
   4dad8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4dae0: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   4dae8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   4daf8: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   4db00: 85 10 00 00 41 6c ff ff      	call -0x93bf
   4db08: bf 14 00 00 00 00 00 00      	mov64 r4, r1
   4db10: 55 00 76 00 02 00 00 00      	jne r0, 0x2, +0x76 <.text+0x4dda8>
   4db18: 7b 4a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r4
   4db20: 7b 4a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r4
   4db28: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4db30: 07 01 00 00 e8 fb ff ff      	add64 r1, -0x418
   4db38: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4db40: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4db48: 85 10 00 00 12 79 ff ff      	call -0x86ee
   4db50: 79 a2 f0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x410]
   4db58: 79 a1 e8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x418]
   4db60: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4da78>
   4db68: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   4db78: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   4db80: 85 10 00 00 31 6c ff ff      	call -0x93cf
   4db88: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4db90: 55 00 7b 01 02 00 00 00      	jne r0, 0x2, +0x17b <.text+0x4e650>
   4db98: 7b 2a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r2
   4dba0: 7b 2a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r2
   4dba8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4dbb0: 07 01 00 00 00 fc ff ff      	add64 r1, -0x400
   4dbb8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4dbc0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4dbc8: 85 10 00 00 aa 64 ff ff      	call -0x9b56
   4dbd0: 79 a2 08 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f8]
   4dbd8: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   4dbe0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4daf8>
   4dbe8: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   4dbf8: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   4dc00: 85 10 00 00 21 6c ff ff      	call -0x93df
   4dc08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4dc10: 55 00 6b 01 02 00 00 00      	jne r0, 0x2, +0x16b <.text+0x4e650>
   4dc18: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   4dc20: 7b 2a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r2
   4dc28: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4dc30: 07 01 00 00 10 fc ff ff      	add64 r1, -0x3f0
   4dc38: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4dc40: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4dc48: 85 10 00 00 64 79 ff ff      	call -0x869c
   4dc50: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   4dc58: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   4dc60: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x4db58>
   4dc68: 7b 2a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r2
   4dc70: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x4db88>
   4dc78: 18 03 00 00 6e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc6e
   4dc88: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4dc90: 85 10 00 00 0f 6c ff ff      	call -0x93f1
   4dc98: 55 00 be ff 02 00 00 00      	jne r0, 0x2, -0x42 <.text+0x4d970>
   4dca0: 7b 1a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r1
   4dca8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4dcb0: 07 01 00 00 28 fc ff ff      	add64 r1, -0x3d8
   4dcb8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4dcc0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4dcc8: 85 10 00 00 14 79 ff ff      	call -0x86ec
   4dcd0: 79 a2 30 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d0]
   4dcd8: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   4dce0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4dbf8>
   4dce8: 18 03 00 00 96 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb96
   4dcf8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   4dd00: 85 10 00 00 01 6c ff ff      	call -0x93ff
   4dd08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4dd10: 55 00 4b 01 02 00 00 00      	jne r0, 0x2, +0x14b <.text+0x4e650>
   4dd18: 7b 2a 48 fb 00 00 00 00      	stxdw [r10 - 0x4b8], r2
   4dd20: 7b 2a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r2
   4dd28: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4dd30: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4dd38: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4dd40: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4dd48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4dd50: 07 01 00 00 38 fc ff ff      	add64 r1, -0x3c8
   4dd58: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4dd60: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4dd68: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4dd70: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4dd78: 85 10 00 00 fc 6d ff ff      	call -0x9204
   4dd80: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   4dd88: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   4dd90: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x4dc88>
   4dd98: 7b 2a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r2
   4dda0: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x4dcb8>
   4dda8: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   4ddb8: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   4ddc0: 85 10 00 00 e9 6b ff ff      	call -0x9417
   4ddc8: 55 00 98 ff 02 00 00 00      	jne r0, 0x2, -0x68 <.text+0x4d970>
   4ddd0: 7b 1a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r1
   4ddd8: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4dde0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4dde8: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4ddf0: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4ddf8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4de00: 07 01 00 00 48 fc ff ff      	add64 r1, -0x3b8
   4de08: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4de10: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4de18: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4de20: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4de28: 85 10 00 00 7c 6d ff ff      	call -0x9284
   4de30: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   4de38: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   4de40: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4dd58>
   4de48: 18 03 00 00 80 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc80
   4de58: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   4de60: 85 10 00 00 d5 6b ff ff      	call -0x942b
   4de68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4de70: 55 00 1f 01 02 00 00 00      	jne r0, 0x2, +0x11f <.text+0x4e650>
   4de78: 7b 2a 38 fb 00 00 00 00      	stxdw [r10 - 0x4c8], r2
   4de80: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4de88: 15 01 0a 00 00 00 00 00      	jeq r1, 0x0, +0xa <.text+0x4ddc0>
   4de90: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4de98: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4dea0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4dea8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   4deb0: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   4deb8: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   4dec0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x4de18>
   4dec8: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4ded0: 7b 41 10 00 00 00 00 00      	stxdw [r1 + 0x10], r4
   4ded8: 05 00 14 01 00 00 00 00      	ja +0x114 <.text+0x4e660>
   4dee0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4dee8: 85 10 00 00 df 98 00 00      	call 0x98df
   4def0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4def8: 15 00 07 00 02 00 00 00      	jeq r0, 0x2, +0x7 <.text+0x4de18>
   4df00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4df08: 18 03 00 00 6c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb6c
   4df18: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   4df20: 85 10 00 00 bd 6b ff ff      	call -0x9443
   4df28: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4df30: 55 00 07 01 02 00 00 00      	jne r0, 0x2, +0x107 <.text+0x4e650>
   4df38: 7b 2a 30 fb 00 00 00 00      	stxdw [r10 - 0x4d0], r2
   4df40: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   4df48: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4df50: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4df58: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4df60: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4df68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4df70: 07 01 00 00 60 fc ff ff      	add64 r1, -0x3a0
   4df78: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4df80: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4df88: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4df90: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4df98: 85 10 00 00 22 6e ff ff      	call -0x91de
   4dfa0: 79 a2 68 fc 00 00 00 00      	ldxdw r2, [r10 - 0x398]
   4dfa8: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   4dfb0: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x4dea8>
   4dfb8: 7b 2a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r2
   4dfc0: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x4ded8>
   4dfc8: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   4dfd8: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   4dfe0: 85 10 00 00 a5 6b ff ff      	call -0x945b
   4dfe8: 55 00 54 ff 02 00 00 00      	jne r0, 0x2, -0xac <.text+0x4d970>
   4dff0: 7b 1a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r1
   4dff8: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4e000: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4e008: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4e010: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4e018: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e020: 07 01 00 00 70 fc ff ff      	add64 r1, -0x390
   4e028: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4e030: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4e038: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4e040: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4e048: 85 10 00 00 0c 6e ff ff      	call -0x91f4
   4e050: 79 a2 78 fc 00 00 00 00      	ldxdw r2, [r10 - 0x388]
   4e058: 79 a1 70 fc 00 00 00 00      	ldxdw r1, [r10 - 0x390]
   4e060: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4df78>
   4e068: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   4e078: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   4e080: 85 10 00 00 91 6b ff ff      	call -0x946f
   4e088: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e090: 55 00 db 00 02 00 00 00      	jne r0, 0x2, +0xdb <.text+0x4e650>
   4e098: 7b 2a 20 fb 00 00 00 00      	stxdw [r10 - 0x4e0], r2
   4e0a0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e0a8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x4dfc8>
   4e0b0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e0b8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e0c0: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   4e0c8: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   4e0d0: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   4e0d8: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   4e0e0: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x4e030>
   4e0e8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e0f0: 85 10 00 00 9e 98 00 00      	call 0x989e
   4e0f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e100: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x4dff8>
   4e108: 7b 2a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r2
   4e110: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x4e030>
   4e118: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e120: 18 03 00 00 bc dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcbc
   4e130: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   4e138: 85 10 00 00 7a 6b ff ff      	call -0x9486
   4e140: 55 00 29 ff 02 00 00 00      	jne r0, 0x2, -0xd7 <.text+0x4d970>
   4e148: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   4e150: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4e158: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4e160: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4e168: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4e170: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e178: 07 01 00 00 80 fc ff ff      	add64 r1, -0x380
   4e180: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4e188: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4e190: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4e198: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4e1a0: 85 10 00 00 e1 6d ff ff      	call -0x921f
   4e1a8: 79 a2 88 fc 00 00 00 00      	ldxdw r2, [r10 - 0x378]
   4e1b0: 79 a1 80 fc 00 00 00 00      	ldxdw r1, [r10 - 0x380]
   4e1b8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4e0d0>
   4e1c0: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   4e1d0: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   4e1d8: 85 10 00 00 66 6b ff ff      	call -0x949a
   4e1e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e1e8: 55 00 b0 00 02 00 00 00      	jne r0, 0x2, +0xb0 <.text+0x4e650>
   4e1f0: 7b 2a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r2
   4e1f8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e200: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x4e158>
   4e208: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4e210: 7b 2a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r2
   4e218: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e220: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e228: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e230: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e238: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x4e180>
   4e240: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e248: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e250: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   4e258: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   4e260: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   4e268: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   4e270: 05 00 12 00 00 00 00 00      	ja +0x12 <.text+0x4e1e8>
   4e278: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e280: 85 10 00 00 6c 98 00 00      	call 0x986c
   4e288: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e290: 55 00 3d 00 02 00 00 00      	jne r0, 0x2, +0x3d <.text+0x4e360>
   4e298: 7b 2a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r2
   4e2a0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e2a8: 85 10 00 00 67 98 00 00      	call 0x9867
   4e2b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e2b8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x4e1b0>
   4e2c0: 7b 2a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r2
   4e2c8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x4e1e8>
   4e2d0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e2d8: 18 03 00 00 0f dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd0f
   4e2e8: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   4e2f0: 85 10 00 00 43 6b ff ff      	call -0x94bd
   4e2f8: 55 00 f2 fe 02 00 00 00      	jne r0, 0x2, -0x10e <.text+0x4d970>
   4e300: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   4e308: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   4e310: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   4e318: 7b 8a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r8
   4e320: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   4e328: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e330: 07 01 00 00 90 fc ff ff      	add64 r1, -0x370
   4e338: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4e340: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   4e348: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4e350: 79 a4 a0 fb 00 00 00 00      	ldxdw r4, [r10 - 0x460]
   4e358: 85 10 00 00 aa 6d ff ff      	call -0x9256
   4e360: 79 a7 98 fc 00 00 00 00      	ldxdw r7, [r10 - 0x368]
   4e368: 79 a1 90 fc 00 00 00 00      	ldxdw r1, [r10 - 0x370]
   4e370: 15 01 07 00 02 00 00 00      	jeq r1, 0x2, +0x7 <.text+0x4e290>
   4e378: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   4e380: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   4e390: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   4e398: 85 10 00 00 2e 6b ff ff      	call -0x94d2
   4e3a0: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   4e3a8: 55 00 a2 00 02 00 00 00      	jne r0, 0x2, +0xa2 <.text+0x4e7a0>
   4e3b0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e3b8: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x4e310>
   4e3c0: 79 98 00 00 00 00 00 00      	ldxdw r8, [r9 + 0x0]
   4e3c8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4e3d0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e3d8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e3e0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e3e8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e3f0: 15 01 0b 00 00 00 00 00      	jeq r1, 0x0, +0xb <.text+0x4e330>
   4e3f8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4e400: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   4e408: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e410: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e418: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e420: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e428: 05 00 1c 00 00 00 00 00      	ja +0x1c <.text+0x4e3f0>
   4e430: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e438: 85 10 00 00 35 98 00 00      	call 0x9835
   4e440: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   4e448: 55 00 68 00 02 00 00 00      	jne r0, 0x2, +0x68 <.text+0x4e670>
   4e450: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e458: 85 10 00 00 31 98 00 00      	call 0x9831
   4e460: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e468: 55 00 0c 00 02 00 00 00      	jne r0, 0x2, +0xc <.text+0x4e3b0>
   4e470: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   4e478: 05 00 1a 00 00 00 00 00      	ja +0x1a <.text+0x4e430>
   4e480: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e488: 18 03 00 00 f6 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcf6
   4e498: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   4e4a0: 85 10 00 00 0d 6b ff ff      	call -0x94f3
   4e4a8: 55 00 bc fe 02 00 00 00      	jne r0, 0x2, -0x144 <.text+0x4d970>
   4e4b0: 7b 1a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r1
   4e4b8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e4c0: 55 01 af ff 00 00 00 00      	jne r1, 0x0, -0x51 <.text+0x4e120>
   4e4c8: 05 00 ba ff 00 00 00 00      	ja -0x46 <.text+0x4e180>
   4e4d0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e4d8: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   4e4e8: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   4e4f0: 85 10 00 00 03 6b ff ff      	call -0x94fd
   4e4f8: 55 00 b2 fe 02 00 00 00      	jne r0, 0x2, -0x14e <.text+0x4d970>
   4e500: 7b 1a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r1
   4e508: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e510: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x4e430>
   4e518: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4e520: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   4e528: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e530: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e538: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e540: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e548: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x4e4a0>
   4e550: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e558: 85 10 00 00 11 98 00 00      	call 0x9811
   4e560: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e568: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x4e460>
   4e570: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   4e578: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x4e4e0>
   4e580: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e588: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   4e598: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   4e5a0: 85 10 00 00 ed 6a ff ff      	call -0x9513
   4e5a8: 55 00 9c fe 02 00 00 00      	jne r0, 0x2, -0x164 <.text+0x4d970>
   4e5b0: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   4e5b8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e5c0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x4e4e0>
   4e5c8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e5d0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e5d8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   4e5e0: 7b 1a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r1
   4e5e8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   4e5f0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   4e5f8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x4e548>
   4e600: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e608: 85 10 00 00 fb 97 00 00      	call 0x97fb
   4e610: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e618: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x4e510>
   4e620: 7b 2a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r2
   4e628: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x4e548>
   4e630: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e638: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   4e648: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   4e650: 85 10 00 00 d7 6a ff ff      	call -0x9529
   4e658: 55 00 86 fe 02 00 00 00      	jne r0, 0x2, -0x17a <.text+0x4d970>
   4e660: 7b 1a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r1
   4e668: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e670: 07 01 00 00 a0 fc ff ff      	add64 r1, -0x360
   4e678: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4e680: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   4e688: 85 10 00 00 5c 78 ff ff      	call -0x87a4
   4e690: 79 a2 a8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x358]
   4e698: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   4e6a0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x4e5b8>
   4e6a8: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   4e6b8: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   4e6c0: 85 10 00 00 c9 6a ff ff      	call -0x9537
   4e6c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e6d0: 55 00 13 00 02 00 00 00      	jne r0, 0x2, +0x13 <.text+0x4e650>
   4e6d8: 7b 2a d8 fa 00 00 00 00      	stxdw [r10 - 0x528], r2
   4e6e0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e6e8: 7b 7a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r7
   4e6f0: 7b 8a f0 fa 00 00 00 00      	stxdw [r10 - 0x510], r8
   4e6f8: 15 01 1d 00 00 00 00 00      	jeq r1, 0x0, +0x1d <.text+0x4e6c8>
   4e700: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   4e708: 7b 2a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r2
   4e710: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e718: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e720: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e728: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e730: 15 01 1b 00 00 00 00 00      	jeq r1, 0x0, +0x1b <.text+0x4e6f0>
   4e738: 79 97 00 00 00 00 00 00      	ldxdw r7, [r9 + 0x0]
   4e740: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   4e748: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   4e750: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   4e758: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e760: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e768: 05 00 22 00 00 00 00 00      	ja +0x22 <.text+0x4e760>
   4e770: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4e778: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   4e780: 7b 01 08 00 00 00 00 00      	stxdw [r1 + 0x8], r0
   4e788: 05 00 18 fe 00 00 00 00      	ja -0x1e8 <.text+0x4d730>
   4e790: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e798: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4e7a0: 18 03 00 00 36 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd36
   4e7b0: b7 04 00 00 1c 00 00 00      	mov64 r4, 0x1c
   4e7b8: 85 10 00 00 aa 6a ff ff      	call -0x9556
   4e7c0: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   4e7c8: 55 00 82 00 02 00 00 00      	jne r0, 0x2, +0x82 <.text+0x4eac0>
   4e7d0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e7d8: 55 01 83 ff 00 00 00 00      	jne r1, 0x0, -0x7d <.text+0x4e2d8>
   4e7e0: 05 00 8d ff 00 00 00 00      	ja -0x73 <.text+0x4e330>
   4e7e8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e7f0: 85 10 00 00 be 97 00 00      	call 0x97be
   4e7f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4e800: 55 00 7e 00 02 00 00 00      	jne r0, 0x2, +0x7e <.text+0x4ead8>
   4e808: 7b 2a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r2
   4e810: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e818: 85 10 00 00 b9 97 00 00      	call 0x97b9
   4e820: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   4e828: 15 00 15 00 02 00 00 00      	jeq r0, 0x2, +0x15 <.text+0x4e7b8>
   4e830: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e838: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   4e840: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   4e850: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   4e858: 85 10 00 00 96 6a ff ff      	call -0x956a
   4e860: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   4e868: 55 00 0a 00 02 00 00 00      	jne r0, 0x2, +0xa <.text+0x4e7a0>
   4e870: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4e878: 79 a8 f0 fa 00 00 00 00      	ldxdw r8, [r10 - 0x510]
   4e880: 15 01 0a 00 00 00 00 00      	jeq r1, 0x0, +0xa <.text+0x4e7b8>
   4e888: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   4e890: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   4e898: 79 98 00 00 00 00 00 00      	ldxdw r8, [r9 + 0x0]
   4e8a0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4e8a8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   4e8b0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   4e8b8: 05 00 0f 00 00 00 00 00      	ja +0xf <.text+0x4e818>
   4e8c0: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4e8c8: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   4e8d0: 05 00 d5 ff 00 00 00 00      	ja -0x2b <.text+0x4e660>
   4e8d8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   4e8e0: 85 10 00 00 a0 97 00 00      	call 0x97a0
   4e8e8: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   4e8f0: 15 00 08 00 02 00 00 00      	jeq r0, 0x2, +0x8 <.text+0x4e818>
   4e8f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4e900: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4e908: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   4e918: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   4e920: 85 10 00 00 7d 6a ff ff      	call -0x9583
   4e928: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   4e930: 55 00 55 00 02 00 00 00      	jne r0, 0x2, +0x55 <.text+0x4eac0>
   4e938: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e940: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4e948: 85 10 00 00 ea a0 00 00      	call 0xa0ea
   4e950: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   4e958: 55 01 04 00 01 00 00 00      	jne r1, 0x1, +0x4 <.text+0x4e860>
   4e960: 61 a2 08 ff 00 00 00 00      	ldxw r2, [r10 - 0xf8]
   4e968: 61 a1 04 ff 00 00 00 00      	ldxw r1, [r10 - 0xfc]
   4e970: 85 10 00 00 f7 91 00 00      	call 0x91f7
   4e978: 05 00 22 fe 00 00 00 00      	ja -0x1de <.text+0x4d970>
   4e980: 7b 8a c8 fa 00 00 00 00      	stxdw [r10 - 0x538], r8
   4e988: 7b 7a d0 fa 00 00 00 00      	stxdw [r10 - 0x530], r7
   4e990: 79 a1 0c ff 00 00 00 00      	ldxdw r1, [r10 - 0xf4]
   4e998: 7b 1a b4 fc 00 00 00 00      	stxdw [r10 - 0x34c], r1
   4e9a0: 79 a1 14 ff 00 00 00 00      	ldxdw r1, [r10 - 0xec]
   4e9a8: 7b 1a bc fc 00 00 00 00      	stxdw [r10 - 0x344], r1
   4e9b0: 61 a1 1c ff 00 00 00 00      	ldxw r1, [r10 - 0xe4]
   4e9b8: 63 1a c4 fc 00 00 00 00      	stxw [r10 - 0x33c], r1
   4e9c0: 61 a1 08 ff 00 00 00 00      	ldxw r1, [r10 - 0xf8]
   4e9c8: 63 1a b0 fc 00 00 00 00      	stxw [r10 - 0x350], r1
   4e9d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e9d8: 07 01 00 00 f8 fb ff ff      	add64 r1, -0x408
   4e9e0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   4e9e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4e9f0: 07 01 00 00 e0 fb ff ff      	add64 r1, -0x420
   4e9f8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   4ea00: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea08: 07 01 00 00 58 fc ff ff      	add64 r1, -0x3a8
   4ea10: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   4ea18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea20: 07 01 00 00 d8 fb ff ff      	add64 r1, -0x428
   4ea28: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   4ea30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea38: 07 01 00 00 b8 fb ff ff      	add64 r1, -0x448
   4ea40: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   4ea48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea50: 07 01 00 00 20 fc ff ff      	add64 r1, -0x3e0
   4ea58: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   4ea60: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea68: 07 01 00 00 d0 fb ff ff      	add64 r1, -0x430
   4ea70: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4ea78: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ea80: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4ea88: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4ea90: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4ea98: 85 10 00 00 82 f8 ff ff      	call -0x77e
   4eaa0: 79 a3 d0 fc 00 00 00 00      	ldxdw r3, [r10 - 0x330]
   4eaa8: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   4eab0: 55 01 33 00 02 00 00 00      	jne r1, 0x2, +0x33 <.text+0x4eb30>
   4eab8: 7b 3a c0 fa 00 00 00 00      	stxdw [r10 - 0x540], r3
   4eac0: 79 32 20 00 00 00 00 00      	ldxdw r2, [r3 + 0x20]
   4eac8: 71 21 29 00 00 00 00 00      	ldxb r1, [r2 + 0x29]
   4ead0: 15 01 37 00 00 00 00 00      	jeq r1, 0x0, +0x37 <.text+0x4eb70>
   4ead8: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   4eae0: 07 08 00 00 c8 fc ff ff      	add64 r8, -0x338
   4eae8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4eaf0: 85 10 00 00 53 75 ff ff      	call -0x8aad
   4eaf8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4eb00: 85 10 00 00 1e a3 00 00      	call 0xa31e
   4eb08: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   4eb10: 79 a1 c0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x540]
   4eb18: 79 12 20 00 00 00 00 00      	ldxdw r2, [r1 + 0x20]
   4eb20: bf a9 00 00 00 00 00 00      	mov64 r9, r10
   4eb28: 07 09 00 00 00 ff ff ff      	add64 r9, -0x100
   4eb30: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   4eb38: 85 10 00 00 4a 75 ff ff      	call -0x8ab6
   4eb40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4eb48: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   4eb50: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   4eb58: 85 10 00 00 2c a3 00 00      	call 0xa32c
   4eb60: 61 a1 d8 fe 00 00 00 00      	ldxw r1, [r10 - 0x128]
   4eb68: 55 01 2d 00 01 00 00 00      	jne r1, 0x1, +0x2d <.text+0x4ebb8>
   4eb70: 61 a2 e0 fe 00 00 00 00      	ldxw r2, [r10 - 0x120]
   4eb78: 61 a1 dc fe 00 00 00 00      	ldxw r1, [r10 - 0x124]
   4eb80: 85 10 00 00 b5 91 00 00      	call 0x91b5
   4eb88: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   4eb90: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   4eb98: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   4eba0: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   4eba8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ebb0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4ebb8: 85 10 00 00 64 72 ff ff      	call -0x8d9c
   4ebc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ebc8: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4ebd0: 85 10 00 00 61 72 ff ff      	call -0x8d9f
   4ebd8: 05 00 8f fd 00 00 00 00      	ja -0x271 <.text+0x4d738>
   4ebe0: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4ebe8: 7b 81 10 00 00 00 00 00      	stxdw [r1 + 0x10], r8
   4ebf0: 05 00 71 ff 00 00 00 00      	ja -0x8f <.text+0x4e660>
   4ebf8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ec00: 18 03 00 00 97 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd97
   4ec10: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   4ec18: 85 10 00 00 1e 6a ff ff      	call -0x95e2
   4ec20: 7b 1a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r1
   4ec28: 55 00 09 00 02 00 00 00      	jne r0, 0x2, +0x9 <.text+0x4eb58>
   4ec30: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   4ec38: 79 a8 f0 fa 00 00 00 00      	ldxdw r8, [r10 - 0x510]
   4ec40: 55 01 5e ff 00 00 00 00      	jne r1, 0x0, -0xa2 <.text+0x4e618>
   4ec48: 05 00 78 ff 00 00 00 00      	ja -0x88 <.text+0x4e6f0>
   4ec50: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   4ec58: 7b 32 10 00 00 00 00 00      	stxdw [r2 + 0x10], r3
   4ec60: 7b 12 08 00 00 00 00 00      	stxdw [r2 + 0x8], r1
   4ec68: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   4ec70: 05 00 7c fd 00 00 00 00      	ja -0x284 <.text+0x4d738>
   4ec78: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   4ec80: 79 a2 e8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x518]
   4ec88: 05 00 5d ff 00 00 00 00      	ja -0xa3 <.text+0x4e658>
   4ec90: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   4ec98: 85 10 00 00 29 97 00 00      	call 0x9729
   4eca0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4eca8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ecb0: 18 03 00 00 c4 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddc4
   4ecc0: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4ecc8: 85 10 00 00 08 6a ff ff      	call -0x95f8
   4ecd0: 05 00 b7 fd 00 00 00 00      	ja -0x249 <.text+0x4d970>
   4ecd8: 79 a3 e0 fe 00 00 00 00      	ldxdw r3, [r10 - 0x120]
   4ece0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ece8: 07 01 00 00 b0 fc ff ff      	add64 r1, -0x350
   4ecf0: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   4ecf8: 85 10 00 00 b9 a0 00 00      	call 0xa0b9
   4ed00: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   4ed08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ed10: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4ed18: 85 10 00 00 38 72 ff ff      	call -0x8dc8
   4ed20: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ed28: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4ed30: 85 10 00 00 35 72 ff ff      	call -0x8dcb
   4ed38: 15 08 2b 00 00 00 00 00      	jeq r8, 0x0, +0x2b <.text+0x4ed78>
   4ed40: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   4ed50: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4ed58: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   4ed60: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4ed68: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   4ed70: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4ed78: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   4ed80: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ed88: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4ed90: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   4ed98: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   4eda0: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   4eda8: 07 08 00 00 c8 fc ff ff      	add64 r8, -0x338
   4edb0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4edb8: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   4edc0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4edc8: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   4edd0: 85 10 00 00 f6 b6 00 00      	call 0xb6f6
   4edd8: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   4ede0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ede8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4edf0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4edf8: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   4ee00: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4ee08: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   4ee10: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4ee18: 7b 2a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r2
   4ee20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ee28: 7b 1a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r1
   4ee30: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4ee38: 07 02 00 00 f8 fc ff ff      	add64 r2, -0x308
   4ee40: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4ee48: 85 10 00 00 a4 77 ff ff      	call -0x885c
   4ee50: 15 00 0a 00 00 00 00 00      	jeq r0, 0x0, +0xa <.text+0x4ed88>
   4ee58: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4ee60: 85 10 00 00 f0 96 00 00      	call 0x96f0
   4ee68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ee70: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ee78: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   4ee88: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   4ee90: 05 00 b0 00 00 00 00 00      	ja +0xb0 <.text+0x4f2f8>
   4ee98: b7 01 00 00 d5 07 00 00      	mov64 r1, 0x7d5
   4eea0: 05 00 be ff 00 00 00 00      	ja -0x42 <.text+0x4eb78>
   4eea8: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   4eeb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4eeb8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4eec0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4eec8: 7b 2a 30 fd 00 00 00 00      	stxdw [r10 - 0x2d0], r2
   4eed0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4eed8: 7b 2a 28 fd 00 00 00 00      	stxdw [r10 - 0x2d8], r2
   4eee0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4eee8: 7b 2a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r2
   4eef0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4eef8: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   4ef00: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ef08: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4ef10: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4ef18: 07 02 00 00 18 fd ff ff      	add64 r2, -0x2e8
   4ef20: 85 10 00 00 89 77 ff ff      	call -0x8877
   4ef28: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4ee50>
   4ef30: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4ef38: 85 10 00 00 d5 96 00 00      	call 0x96d5
   4ef40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4ef48: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4ef50: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   4ef60: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   4ef68: 05 00 95 00 00 00 00 00      	ja +0x95 <.text+0x4f2f8>
   4ef70: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   4ef78: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4ef80: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ef88: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4ef90: 7b 2a 50 fd 00 00 00 00      	stxdw [r10 - 0x2b0], r2
   4ef98: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4efa0: 7b 2a 48 fd 00 00 00 00      	stxdw [r10 - 0x2b8], r2
   4efa8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4efb0: 7b 2a 40 fd 00 00 00 00      	stxdw [r10 - 0x2c0], r2
   4efb8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4efc0: 7b 1a 38 fd 00 00 00 00      	stxdw [r10 - 0x2c8], r1
   4efc8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4efd0: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4efd8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4efe0: 07 02 00 00 38 fd ff ff      	add64 r2, -0x2c8
   4efe8: 85 10 00 00 70 77 ff ff      	call -0x8890
   4eff0: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4ef18>
   4eff8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f000: 85 10 00 00 bc 96 00 00      	call 0x96bc
   4f008: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f010: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f018: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   4f028: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4f030: 05 00 7c 00 00 00 00 00      	ja +0x7c <.text+0x4f2f8>
   4f038: 79 a1 c0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x540]
   4f040: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4f048: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f050: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f058: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   4f060: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f068: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   4f070: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f078: 7b 2a 60 fd 00 00 00 00      	stxdw [r10 - 0x2a0], r2
   4f080: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f088: 7b 1a 58 fd 00 00 00 00      	stxdw [r10 - 0x2a8], r1
   4f090: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f098: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f0a0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f0a8: 07 02 00 00 58 fd ff ff      	add64 r2, -0x2a8
   4f0b0: 85 10 00 00 57 77 ff ff      	call -0x88a9
   4f0b8: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4efe0>
   4f0c0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f0c8: 85 10 00 00 a3 96 00 00      	call 0x96a3
   4f0d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f0d8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f0e0: 18 03 00 00 c4 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddc4
   4f0f0: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   4f0f8: 05 00 63 00 00 00 00 00      	ja +0x63 <.text+0x4f2f8>
   4f100: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   4f108: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f110: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f118: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f120: 7b 2a 90 fd 00 00 00 00      	stxdw [r10 - 0x270], r2
   4f128: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f130: 7b 2a 88 fd 00 00 00 00      	stxdw [r10 - 0x278], r2
   4f138: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f140: 7b 2a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r2
   4f148: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f150: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   4f158: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f160: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f168: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f170: 07 02 00 00 78 fd ff ff      	add64 r2, -0x288
   4f178: 85 10 00 00 3e 77 ff ff      	call -0x88c2
   4f180: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4f0a8>
   4f188: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f190: 85 10 00 00 8a 96 00 00      	call 0x968a
   4f198: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f1a0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f1a8: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   4f1b8: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   4f1c0: 05 00 4a 00 00 00 00 00      	ja +0x4a <.text+0x4f2f8>
   4f1c8: 79 a1 28 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d8]
   4f1d0: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4f1d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f1e0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f1e8: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   4f1f0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f1f8: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   4f200: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f208: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   4f210: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f218: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   4f220: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f228: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f230: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f238: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   4f240: 85 10 00 00 25 77 ff ff      	call -0x88db
   4f248: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4f170>
   4f250: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f258: 85 10 00 00 71 96 00 00      	call 0x9671
   4f260: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f268: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f270: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   4f280: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   4f288: 05 00 31 00 00 00 00 00      	ja +0x31 <.text+0x4f2f8>
   4f290: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   4f298: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4f2a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f2a8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f2b0: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   4f2b8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f2c0: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   4f2c8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f2d0: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   4f2d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f2e0: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   4f2e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f2f0: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f2f8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f300: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   4f308: 85 10 00 00 0c 77 ff ff      	call -0x88f4
   4f310: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x4f238>
   4f318: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f320: 85 10 00 00 58 96 00 00      	call 0x9658
   4f328: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f330: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f338: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   4f348: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   4f350: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x4f2f8>
   4f358: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   4f360: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4f368: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f370: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f378: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   4f380: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f388: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   4f390: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f398: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   4f3a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f3a8: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   4f3b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f3b8: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f3c0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f3c8: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   4f3d0: 85 10 00 00 f3 76 ff ff      	call -0x890d
   4f3d8: 15 00 0d 00 00 00 00 00      	jeq r0, 0x0, +0xd <.text+0x4f328>
   4f3e0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f3e8: 85 10 00 00 3f 96 00 00      	call 0x963f
   4f3f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f3f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f400: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   4f410: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   4f418: 85 10 00 00 1e 69 ff ff      	call -0x96e2
   4f420: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   4f428: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   4f430: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   4f438: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   4f440: 05 00 82 fc 00 00 00 00      	ja -0x37e <.text+0x4d738>
   4f448: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   4f450: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4f458: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f460: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f468: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   4f470: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f478: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   4f480: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f488: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   4f490: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f498: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   4f4a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f4a8: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   4f4b0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4f4b8: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   4f4c0: 85 10 00 00 d5 76 ff ff      	call -0x892b
   4f4c8: 15 00 09 00 00 00 00 00      	jeq r0, 0x0, +0x9 <.text+0x4f3f8>
   4f4d0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   4f4d8: 85 10 00 00 21 96 00 00      	call 0x9621
   4f4e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   4f4e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   4f4f0: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   4f500: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   4f508: 85 10 00 00 00 69 ff ff      	call -0x9700
   4f510: 05 00 af fc 00 00 00 00      	ja -0x351 <.text+0x4d970>
   4f518: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   4f520: 15 01 66 02 00 00 00 00      	jeq r1, 0x0, +0x266 <.text+0x50738>
   4f528: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   4f530: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   4f538: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   4f540: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4f548: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   4f550: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   4f560: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   4f568: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   4f570: 85 10 00 00 ff ff ff ff      	call -0x1
   4f578: 55 00 d1 02 00 00 00 00      	jne r0, 0x0, +0x2d1 <.text+0x50ae8>
   4f580: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   4f588: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   4f590: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   4f598: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   4f5a0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   4f5a8: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   4f5b0: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   4f5b8: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   4f5c0: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   4f5c8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f5d0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4f5d8: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   4f5e0: 5d 73 57 02 00 00 00 00      	jne r3, r7, +0x257 <.text+0x50780>
   4f5e8: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   4f5f0: 5d 93 55 02 00 00 00 00      	jne r3, r9, +0x255 <.text+0x50780>
   4f5f8: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   4f600: 5d 83 53 02 00 00 00 00      	jne r3, r8, +0x253 <.text+0x50780>
   4f608: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   4f610: 79 a3 b8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x548]
   4f618: 5d 32 50 02 00 00 00 00      	jne r2, r3, +0x250 <.text+0x50780>
   4f620: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4f628: 15 01 6c 02 00 00 00 00      	jeq r1, 0x0, +0x26c <.text+0x50870>
   4f630: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   4f638: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   4f640: 7b 1a a8 fa 00 00 00 00      	stxdw [r10 - 0x558], r1
   4f648: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   4f650: 7b 1a b0 fa 00 00 00 00      	stxdw [r10 - 0x550], r1
   4f658: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   4f660: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   4f668: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   4f670: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   4f678: 7b 3a a0 fa 00 00 00 00      	stxdw [r10 - 0x560], r3
   4f680: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   4f688: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   4f690: 79 22 28 00 00 00 00 00      	ldxdw r2, [r2 + 0x28]
   4f698: 79 19 00 00 00 00 00 00      	ldxdw r9, [r1 + 0x0]
   4f6a0: 7b 2a 98 fa 00 00 00 00      	stxdw [r10 - 0x568], r2
   4f6a8: 5d 92 65 02 00 00 00 00      	jne r2, r9, +0x265 <.text+0x508b8>
   4f6b0: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   4f6b8: 5d 81 63 02 00 00 00 00      	jne r1, r8, +0x263 <.text+0x508b8>
   4f6c0: 79 a1 b0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x550]
   4f6c8: 5d 71 61 02 00 00 00 00      	jne r1, r7, +0x261 <.text+0x508b8>
   4f6d0: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   4f6d8: 79 a2 a0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x560]
   4f6e0: 5d 21 5e 02 00 00 00 00      	jne r1, r2, +0x25e <.text+0x508b8>
   4f6e8: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   4f6f0: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   4f6f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f700: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4f708: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   4f710: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   4f718: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4f720: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   4f730: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   4f738: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4f740: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   4f748: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   4f750: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   4f758: 7b 4a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r4
   4f760: 7b 3a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r3
   4f768: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   4f770: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   4f778: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   4f780: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   4f788: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f790: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   4f798: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   4f7a0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   4f7a8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4f7b0: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   4f7b8: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   4f7c0: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   4f7c8: 85 10 00 00 ff ff ff ff      	call -0x1
   4f7d0: 55 00 86 02 00 00 00 00      	jne r0, 0x0, +0x286 <.text+0x50ae8>
   4f7d8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   4f7e0: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   4f7e8: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   4f7f0: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   4f7f8: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   4f800: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   4f808: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   4f810: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   4f818: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   4f820: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f828: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4f830: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   4f838: 5d 73 4a 02 00 00 00 00      	jne r3, r7, +0x24a <.text+0x50970>
   4f840: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   4f848: 5d 93 48 02 00 00 00 00      	jne r3, r9, +0x248 <.text+0x50970>
   4f850: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   4f858: 5d 83 46 02 00 00 00 00      	jne r3, r8, +0x246 <.text+0x50970>
   4f860: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   4f868: 79 a3 b8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x548]
   4f870: 5d 32 43 02 00 00 00 00      	jne r2, r3, +0x243 <.text+0x50970>
   4f878: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4f880: 15 01 4c 02 00 00 00 00      	jeq r1, 0x0, +0x24c <.text+0x509c8>
   4f888: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   4f890: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   4f898: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   4f8a0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   4f8a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f8b0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4f8b8: 85 10 00 00 9a 73 ff ff      	call -0x8c66
   4f8c0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   4f8c8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   4f8d0: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   4f8d8: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   4f8e0: 5d 34 49 02 00 00 00 00      	jne r4, r3, +0x249 <.text+0x50a10>
   4f8e8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   4f8f0: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   4f8f8: 5d 34 46 02 00 00 00 00      	jne r4, r3, +0x246 <.text+0x50a10>
   4f900: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   4f908: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   4f910: 5d 34 43 02 00 00 00 00      	jne r4, r3, +0x243 <.text+0x50a10>
   4f918: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4f920: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   4f928: 5d 12 40 02 00 00 00 00      	jne r2, r1, +0x240 <.text+0x50a10>
   4f930: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4f938: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   4f940: 85 10 00 00 b3 70 ff ff      	call -0x8f4d
   4f948: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   4f950: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   4f958: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   4f960: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   4f968: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   4f970: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   4f978: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   4f980: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f988: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4f990: 7b 2a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r2
   4f998: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4f9a0: 7b 2a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r2
   4f9a8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4f9b0: 7b 2a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r2
   4f9b8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4f9c0: 7b 1a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r1
   4f9c8: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   4f9d0: 5d 17 30 02 00 00 00 00      	jne r7, r1, +0x230 <.text+0x50a38>
   4f9d8: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   4f9e0: 5d 18 2e 02 00 00 00 00      	jne r8, r1, +0x22e <.text+0x50a38>
   4f9e8: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   4f9f0: 5d 19 2c 02 00 00 00 00      	jne r9, r1, +0x22c <.text+0x50a38>
   4f9f8: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   4fa00: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   4fa08: 5d 12 29 02 00 00 00 00      	jne r2, r1, +0x229 <.text+0x50a38>
   4fa10: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   4fa18: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   4fa20: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   4fa28: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   4fa30: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   4fa38: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   4fa40: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   4fa48: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   4fa50: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   4fa58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4fa60: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   4fa68: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   4fa70: 07 08 00 00 00 ff ff ff      	add64 r8, -0x100
   4fa78: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4fa80: 85 10 00 00 61 73 ff ff      	call -0x8c9f
   4fa88: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   4fa90: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4fa98: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   4faa0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4faa8: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   4fab0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4fab8: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   4fac0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4fac8: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   4fad0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4fad8: 07 01 00 00 38 fe ff ff      	add64 r1, -0x1c8
   4fae0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4fae8: 07 02 00 00 18 fe ff ff      	add64 r2, -0x1e8
   4faf0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   4faf8: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   4fb00: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   4fb08: 07 04 00 00 c8 fc ff ff      	add64 r4, -0x338
   4fb10: 85 10 00 00 2d 8c 00 00      	call 0x8c2d
   4fb18: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   4fb20: 85 10 00 00 77 70 ff ff      	call -0x8f89
   4fb28: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   4fb30: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4fb38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4fb40: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   4fb48: 7b 3a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r3
   4fb50: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   4fb58: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   4fb60: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   4fb68: 79 a2 38 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1c8]
   4fb70: 5d 27 1e 02 00 00 00 00      	jne r7, r2, +0x21e <.text+0x50b48>
   4fb78: 79 a2 40 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1c0]
   4fb80: 5d 28 1c 02 00 00 00 00      	jne r8, r2, +0x21c <.text+0x50b48>
   4fb88: 79 a2 48 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1b8]
   4fb90: 5d 29 1a 02 00 00 00 00      	jne r9, r2, +0x21a <.text+0x50b48>
   4fb98: 79 a2 50 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1b0]
   4fba0: 79 a3 b8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x548]
   4fba8: 5d 23 17 02 00 00 00 00      	jne r3, r2, +0x217 <.text+0x50b48>
   4fbb0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fbb8: 15 01 2c 02 00 00 00 00      	jeq r1, 0x0, +0x22c <.text+0x50c00>
   4fbc0: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   4fbc8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   4fbd0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   4fbd8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   4fbe0: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   4fbe8: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   4fbf8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   4fc00: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   4fc08: 85 10 00 00 ff ff ff ff      	call -0x1
   4fc10: 55 00 fe 01 00 00 00 00      	jne r0, 0x0, +0x1fe <.text+0x50ae8>
   4fc18: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   4fc20: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   4fc28: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   4fc30: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   4fc38: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   4fc40: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   4fc48: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   4fc50: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   4fc58: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   4fc60: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4fc68: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4fc70: 5d 72 1c 02 00 00 00 00      	jne r2, r7, +0x21c <.text+0x50c38>
   4fc78: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4fc80: 5d 82 1a 02 00 00 00 00      	jne r2, r8, +0x21a <.text+0x50c38>
   4fc88: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4fc90: 5d 92 18 02 00 00 00 00      	jne r2, r9, +0x218 <.text+0x50c38>
   4fc98: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4fca0: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   4fca8: 5d 21 15 02 00 00 00 00      	jne r1, r2, +0x215 <.text+0x50c38>
   4fcb0: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   4fcb8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fcc0: 15 01 2b 02 00 00 00 00      	jeq r1, 0x0, +0x22b <.text+0x50d00>
   4fcc8: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   4fcd0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4fcd8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4fce0: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   4fce8: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   4fcf0: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   4fcf8: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   4fd00: 18 01 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r1, -0x6c5e9a281e0922fa
   4fd10: 5d 17 2a 02 00 00 00 00      	jne r7, r1, +0x22a <.text+0x50d48>
   4fd18: 18 01 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r1, -0x53861431b91e3427
   4fd28: 5d 18 27 02 00 00 00 00      	jne r8, r1, +0x227 <.text+0x50d48>
   4fd30: 18 01 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r1, -0x6ec8a4a0127a4be4
   4fd40: 5d 19 24 02 00 00 00 00      	jne r9, r1, +0x224 <.text+0x50d48>
   4fd48: 18 01 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r1, -0x56ff00817a0a73c6
   4fd58: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   4fd60: 5d 12 20 02 00 00 00 00      	jne r2, r1, +0x220 <.text+0x50d48>
   4fd68: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   4fd70: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4fd78: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fd80: 15 01 36 02 00 00 00 00      	jeq r1, 0x0, +0x236 <.text+0x50e18>
   4fd88: 79 a1 28 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d8]
   4fd90: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4fd98: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fda0: 15 01 3b 02 00 00 00 00      	jeq r1, 0x0, +0x23b <.text+0x50e60>
   4fda8: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   4fdb0: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4fdb8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fdc0: 15 01 40 02 00 00 00 00      	jeq r1, 0x0, +0x240 <.text+0x50ea8>
   4fdc8: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   4fdd0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   4fdd8: 15 01 46 02 00 00 00 00      	jeq r1, 0x0, +0x246 <.text+0x50ef0>
   4fde0: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   4fde8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   4fdf0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4fdf8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   4fe00: 18 03 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r3, -0x6c5e9a281e0922fa
   4fe10: 5d 32 a6 01 00 00 00 00      	jne r2, r3, +0x1a6 <.text+0x50a28>
   4fe18: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4fe20: 18 03 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r3, -0x53861431b91e3427
   4fe30: 5d 32 a2 01 00 00 00 00      	jne r2, r3, +0x1a2 <.text+0x50a28>
   4fe38: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4fe40: 18 03 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r3, -0x6ec8a4a0127a4be4
   4fe50: 5d 32 9e 01 00 00 00 00      	jne r2, r3, +0x19e <.text+0x50a28>
   4fe58: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   4fe60: 18 02 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r2, -0x56ff00817a0a73c6
   4fe70: 5d 21 9a 01 00 00 00 00      	jne r1, r2, +0x19a <.text+0x50a28>
   4fe78: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   4fe80: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   4fe88: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   4fe90: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   4fe98: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   4fea0: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   4fea8: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   4feb0: 79 14 00 00 00 00 00 00      	ldxdw r4, [r1 + 0x0]
   4feb8: 79 41 18 00 00 00 00 00      	ldxdw r1, [r4 + 0x18]
   4fec0: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   4fec8: 79 42 10 00 00 00 00 00      	ldxdw r2, [r4 + 0x10]
   4fed0: 7b 2a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r2
   4fed8: 79 43 08 00 00 00 00 00      	ldxdw r3, [r4 + 0x8]
   4fee0: 7b 3a 60 fe 00 00 00 00      	stxdw [r10 - 0x1a0], r3
   4fee8: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   4fef0: 7b 4a 58 fe 00 00 00 00      	stxdw [r10 - 0x1a8], r4
   4fef8: 5d 47 29 02 00 00 00 00      	jne r7, r4, +0x229 <.text+0x50f28>
   4ff00: 5d 38 28 02 00 00 00 00      	jne r8, r3, +0x228 <.text+0x50f28>
   4ff08: 5d 29 27 02 00 00 00 00      	jne r9, r2, +0x227 <.text+0x50f28>
   4ff10: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   4ff18: 5d 12 25 02 00 00 00 00      	jne r2, r1, +0x225 <.text+0x50f28>
   4ff20: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   4ff28: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ff30: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4ff38: 7b 2a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r2
   4ff40: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4ff48: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   4ff50: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4ff58: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   4ff60: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ff68: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   4ff70: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   4ff78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ff80: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   4ff88: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   4ff90: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   4ff98: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   4ffa0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   4ffa8: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   4ffb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   4ffb8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   4ffc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   4ffc8: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   4ffd0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   4ffd8: 07 02 00 00 58 fe ff ff      	add64 r2, -0x1a8
   4ffe0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   4ffe8: 07 03 00 00 c8 fc ff ff      	add64 r3, -0x338
   4fff0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   4fff8: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   50000: 85 10 00 00 8f 8b 00 00      	call 0x8b8f
   50008: 79 a1 10 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4f0]
   50010: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   50018: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   50020: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   50028: 7b 3a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r3
   50030: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   50038: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   50040: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   50048: 79 a2 78 fe 00 00 00 00      	ldxdw r2, [r10 - 0x188]
   50050: 5d 27 14 02 00 00 00 00      	jne r7, r2, +0x214 <.text+0x50fd8>
   50058: 79 a2 80 fe 00 00 00 00      	ldxdw r2, [r10 - 0x180]
   50060: 5d 28 12 02 00 00 00 00      	jne r8, r2, +0x212 <.text+0x50fd8>
   50068: 79 a2 88 fe 00 00 00 00      	ldxdw r2, [r10 - 0x178]
   50070: 5d 29 10 02 00 00 00 00      	jne r9, r2, +0x210 <.text+0x50fd8>
   50078: 79 a2 90 fe 00 00 00 00      	ldxdw r2, [r10 - 0x170]
   50080: 79 a3 b8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x548]
   50088: 5d 23 0d 02 00 00 00 00      	jne r3, r2, +0x20d <.text+0x50fd8>
   50090: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   50098: 15 01 21 02 00 00 00 00      	jeq r1, 0x0, +0x221 <.text+0x51088>
   500a0: 79 a1 00 fb 00 00 00 00      	ldxdw r1, [r10 - 0x500]
   500a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   500b0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   500b8: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   500c0: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   500c8: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   500d0: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   500d8: 18 01 00 00 0c 14 de fc 00 00 00 00 82 5e c6 76      	lddw r1, 0x76c65e82fcde140c
   500e8: 5d 17 20 02 00 00 00 00      	jne r7, r1, +0x220 <.text+0x510d0>
   500f0: 18 01 00 00 94 25 08 18 00 00 00 00 bb 65 40 65      	lddw r1, 0x654065bb18082594
   50100: 5d 18 1d 02 00 00 00 00      	jne r8, r1, +0x21d <.text+0x510d0>
   50108: 18 01 00 00 f4 29 8d 31 00 00 00 00 56 d5 71 b4      	lddw r1, -0x4b8e2aa9ce72d60c
   50118: 5d 19 1a 02 00 00 00 00      	jne r9, r1, +0x21a <.text+0x510d0>
   50120: 18 01 00 00 d4 f8 09 0c 00 00 00 00 18 e9 a8 63      	lddw r1, 0x63a8e9180c09f8d4
   50130: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   50138: 5d 12 16 02 00 00 00 00      	jne r2, r1, +0x216 <.text+0x510d0>
   50140: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   50148: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50150: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   50158: 79 a2 e0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x520]
   50160: 79 22 20 00 00 00 00 00      	ldxdw r2, [r2 + 0x20]
   50168: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   50170: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   50178: 5d 34 39 01 00 00 00 00      	jne r4, r3, +0x139 <.text+0x50a28>
   50180: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   50188: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   50190: 5d 34 36 01 00 00 00 00      	jne r4, r3, +0x136 <.text+0x50a28>
   50198: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   501a0: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   501a8: 5d 34 33 01 00 00 00 00      	jne r4, r3, +0x133 <.text+0x50a28>
   501b0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   501b8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   501c0: 5d 12 30 01 00 00 00 00      	jne r2, r1, +0x130 <.text+0x50a28>
   501c8: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   501d0: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   501d8: 7b 2a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r2
   501e0: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   501e8: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   501f0: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   501f8: 79 a1 f0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x510]
   50200: 79 14 00 00 00 00 00 00      	ldxdw r4, [r1 + 0x0]
   50208: 79 41 18 00 00 00 00 00      	ldxdw r1, [r4 + 0x18]
   50210: 7b 1a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r1
   50218: 79 42 10 00 00 00 00 00      	ldxdw r2, [r4 + 0x10]
   50220: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   50228: 79 43 08 00 00 00 00 00      	ldxdw r3, [r4 + 0x8]
   50230: 7b 3a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r3
   50238: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   50240: 7b 4a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r4
   50248: 5d 47 0e 02 00 00 00 00      	jne r7, r4, +0x20e <.text+0x511a0>
   50250: 5d 38 0d 02 00 00 00 00      	jne r8, r3, +0x20d <.text+0x511a0>
   50258: 5d 29 0c 02 00 00 00 00      	jne r9, r2, +0x20c <.text+0x511a0>
   50260: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   50268: 5d 12 0a 02 00 00 00 00      	jne r2, r1, +0x20a <.text+0x511a0>
   50270: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   50278: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50280: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   50288: 7b 2a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r2
   50290: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   50298: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   502a0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   502a8: 7b 2a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r2
   502b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   502b8: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   502c0: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   502c8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   502d0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   502d8: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   502e0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   502e8: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   502f0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   502f8: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   50300: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50308: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   50310: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   50318: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   50320: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   50328: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   50330: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   50338: 07 03 00 00 c8 fc ff ff      	add64 r3, -0x338
   50340: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   50348: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   50350: 85 10 00 00 25 8b 00 00      	call 0x8b25
   50358: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   50360: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   50368: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   50370: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   50378: 7b 3a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r3
   50380: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   50388: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   50390: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   50398: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   503a0: 5d 27 f9 01 00 00 00 00      	jne r7, r2, +0x1f9 <.text+0x51250>
   503a8: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   503b0: 5d 28 f7 01 00 00 00 00      	jne r8, r2, +0x1f7 <.text+0x51250>
   503b8: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   503c0: 5d 29 f5 01 00 00 00 00      	jne r9, r2, +0x1f5 <.text+0x51250>
   503c8: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   503d0: 79 a3 b8 fa 00 00 00 00      	ldxdw r3, [r10 - 0x548]
   503d8: 5d 23 f2 01 00 00 00 00      	jne r3, r2, +0x1f2 <.text+0x51250>
   503e0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   503e8: 15 01 06 02 00 00 00 00      	jeq r1, 0x0, +0x206 <.text+0x51300>
   503f0: 72 0a c8 fc ff 00 00 00      	stb [r10 - 0x338], 0xff
   503f8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   50400: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   50408: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   50410: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   50418: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   50428: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   50430: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   50438: 85 10 00 00 ff ff ff ff      	call -0x1
   50440: 55 00 f8 00 00 00 00 00      	jne r0, 0x0, +0xf8 <.text+0x50ae8>
   50448: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   50450: 7b 1a b8 fa 00 00 00 00      	stxdw [r10 - 0x548], r1
   50458: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   50460: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   50468: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   50470: 71 a1 c8 fc 00 00 00 00      	ldxb r1, [r10 - 0x338]
   50478: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   50480: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   50488: 79 a1 f8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x508]
   50490: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50498: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   504a0: 5d 72 f1 01 00 00 00 00      	jne r2, r7, +0x1f1 <.text+0x51310>
   504a8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   504b0: 5d 82 ef 01 00 00 00 00      	jne r2, r8, +0x1ef <.text+0x51310>
   504b8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   504c0: 5d 92 ed 01 00 00 00 00      	jne r2, r9, +0x1ed <.text+0x51310>
   504c8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   504d0: 79 a2 b8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x548]
   504d8: 5d 21 ea 01 00 00 00 00      	jne r1, r2, +0x1ea <.text+0x51310>
   504e0: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   504e8: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   504f0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   504f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   50500: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   50508: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   50510: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   50518: 18 05 00 00 d6 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xaddd6
   50528: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   50530: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   50538: 07 05 00 00 c8 fc ff ff      	add64 r5, -0x338
   50540: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   50548: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   50550: 7b 4a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r4
   50558: 7b 3a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r3
   50560: 7b 2a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r2
   50568: 7a 0a e0 fe 07 00 00 00      	stdw [r10 - 0x120], 0x7
   50570: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   50578: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   50580: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   50588: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   50590: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   50598: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   505a0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   505a8: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   505b0: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   505b8: 79 a3 a8 fb 00 00 00 00      	ldxdw r3, [r10 - 0x458]
   505c0: 85 10 00 00 ff ff ff ff      	call -0x1
   505c8: 55 00 c7 00 00 00 00 00      	jne r0, 0x0, +0xc7 <.text+0x50ae8>
   505d0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   505d8: 7b 1a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r1
   505e0: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   505e8: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   505f0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   505f8: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   50600: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   50608: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   50610: 79 a1 e8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x518]
   50618: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50620: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   50628: 5d 72 cb 01 00 00 00 00      	jne r2, r7, +0x1cb <.text+0x51368>
   50630: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   50638: 5d 82 c9 01 00 00 00 00      	jne r2, r8, +0x1c9 <.text+0x51368>
   50640: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   50648: 5d 92 c7 01 00 00 00 00      	jne r2, r9, +0x1c7 <.text+0x51368>
   50650: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   50658: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   50660: 5d 21 c4 01 00 00 00 00      	jne r1, r2, +0x1c4 <.text+0x51368>
   50668: 79 a1 c8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x538]
   50670: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   50678: 15 01 d6 01 00 00 00 00      	jeq r1, 0x0, +0x1d6 <.text+0x51410>
   50680: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   50688: 79 a2 c8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x538]
   50690: 7b 21 e0 00 00 00 00 00      	stxdw [r1 + 0xe0], r2
   50698: 79 a2 d0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x530]
   506a0: 7b 21 d8 00 00 00 00 00      	stxdw [r1 + 0xd8], r2
   506a8: 79 a2 e8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x518]
   506b0: 7b 21 d0 00 00 00 00 00      	stxdw [r1 + 0xd0], r2
   506b8: 79 a2 d8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x528]
   506c0: 7b 21 c8 00 00 00 00 00      	stxdw [r1 + 0xc8], r2
   506c8: 79 a2 f8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x508]
   506d0: 7b 21 c0 00 00 00 00 00      	stxdw [r1 + 0xc0], r2
   506d8: 79 a2 98 fb 00 00 00 00      	ldxdw r2, [r10 - 0x468]
   506e0: 7b 21 b8 00 00 00 00 00      	stxdw [r1 + 0xb8], r2
   506e8: 79 a2 a0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x460]
   506f0: 7b 21 b0 00 00 00 00 00      	stxdw [r1 + 0xb0], r2
   506f8: 79 a2 f0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x510]
   50700: 7b 21 a8 00 00 00 00 00      	stxdw [r1 + 0xa8], r2
   50708: 79 a2 e0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x520]
   50710: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   50718: 79 a2 00 fb 00 00 00 00      	ldxdw r2, [r10 - 0x500]
   50720: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   50728: 79 a2 08 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f8]
   50730: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   50738: 79 a2 10 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f0]
   50740: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   50748: 79 a2 18 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4e8]
   50750: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   50758: 79 a2 20 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4e0]
   50760: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   50768: 79 a2 28 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4d8]
   50770: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   50778: 79 a2 30 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4d0]
   50780: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   50788: 79 a2 38 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4c8]
   50790: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   50798: 79 a2 40 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4c0]
   507a0: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   507a8: 79 a2 48 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4b8]
   507b0: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   507b8: 79 a2 50 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4b0]
   507c0: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   507c8: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   507d0: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   507d8: 79 a2 60 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a0]
   507e0: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   507e8: 79 a2 68 fb 00 00 00 00      	ldxdw r2, [r10 - 0x498]
   507f0: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   507f8: 79 a2 c0 fa 00 00 00 00      	ldxdw r2, [r10 - 0x540]
   50800: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   50808: 79 a2 70 fb 00 00 00 00      	ldxdw r2, [r10 - 0x490]
   50810: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   50818: 79 a2 78 fb 00 00 00 00      	ldxdw r2, [r10 - 0x488]
   50820: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   50828: 79 a2 80 fb 00 00 00 00      	ldxdw r2, [r10 - 0x480]
   50830: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   50838: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   50840: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   50848: 7b 61 00 00 00 00 00 00      	stxdw [r1 + 0x0], r6
   50850: 05 00 00 fa 00 00 00 00      	ja -0x600 <.text+0x4d738>
   50858: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50860: 85 10 00 00 b0 93 00 00      	call 0x93b0
   50868: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50870: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50878: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   50888: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   50890: 85 10 00 00 8f 66 ff ff      	call -0x9971
   50898: 05 00 3e fa 00 00 00 00      	ja -0x5c2 <.text+0x4d970>
   508a0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   508a8: 85 10 00 00 a7 93 00 00      	call 0x93a7
   508b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   508b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   508c0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   508d0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   508d8: 85 10 00 00 86 66 ff ff      	call -0x997a
   508e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   508e8: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   508f0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   508f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50900: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   50908: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   50910: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   50918: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   50920: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   50928: 7b 9a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r9
   50930: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   50938: 79 a6 b8 fa 00 00 00 00      	ldxdw r6, [r10 - 0x548]
   50940: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   50948: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   50950: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   50958: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   50960: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   50968: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   50970: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   50978: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50980: 85 10 00 00 0e 8e 00 00      	call 0x8e0e
   50988: 05 00 20 fa 00 00 00 00      	ja -0x5e0 <.text+0x4d970>
   50990: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50998: 85 10 00 00 89 93 00 00      	call 0x9389
   509a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   509a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   509b0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   509c0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   509c8: 85 10 00 00 68 66 ff ff      	call -0x9998
   509d0: 05 00 17 fa 00 00 00 00      	ja -0x5e9 <.text+0x4d970>
   509d8: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   509e0: 85 10 00 00 80 93 00 00      	call 0x9380
   509e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   509f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   509f8: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   50a08: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   50a10: 85 10 00 00 5f 66 ff ff      	call -0x99a1
   50a18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50a20: 79 a1 a0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x560]
   50a28: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   50a30: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   50a38: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   50a40: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   50a48: 79 a1 a8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x558]
   50a50: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   50a58: 79 a1 b0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x550]
   50a60: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   50a68: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   50a70: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   50a78: 79 a1 98 fa 00 00 00 00      	ldxdw r1, [r10 - 0x568]
   50a80: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   50a88: 05 00 db ff 00 00 00 00      	ja -0x25 <.text+0x50848>
   50a90: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   50a98: 85 10 00 00 69 93 00 00      	call 0x9369
   50aa0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50aa8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50ab0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   50ac0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   50ac8: 85 10 00 00 48 66 ff ff      	call -0x99b8
   50ad0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50ad8: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   50ae0: 05 00 c1 ff 00 00 00 00      	ja -0x3f <.text+0x507d0>
   50ae8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50af0: 85 10 00 00 5e 93 00 00      	call 0x935e
   50af8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50b00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50b08: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   50b18: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   50b20: 85 10 00 00 3d 66 ff ff      	call -0x99c3
   50b28: 05 00 ec f9 00 00 00 00      	ja -0x614 <.text+0x4d970>
   50b30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   50b38: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   50b40: 85 10 00 00 73 6e ff ff      	call -0x918d
   50b48: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   50b50: 05 00 e6 f9 00 00 00 00      	ja -0x61a <.text+0x4d968>
   50b58: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   50b60: 85 10 00 00 50 93 00 00      	call 0x9350
   50b68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50b70: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50b78: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   50b88: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   50b90: 85 10 00 00 2f 66 ff ff      	call -0x99d1
   50b98: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50ba0: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   50ba8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   50bb0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   50bb8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   50bc0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   50bc8: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   50bd0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   50bd8: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   50be0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   50be8: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   50bf0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   50bf8: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   50c00: 05 00 21 00 00 00 00 00      	ja +0x21 <.text+0x50bf0>
   50c08: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   50c18: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   50c20: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   50c28: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   50c30: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   50c38: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   50c40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   50c48: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   50c50: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   50c60: 85 10 00 00 84 a7 00 00      	call 0xa784
   50c68: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   50c70: 85 10 00 00 2e 93 00 00      	call 0x932e
   50c78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50c80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50c88: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   50c98: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   50ca0: 85 10 00 00 0d 66 ff ff      	call -0x99f3
   50ca8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50cb0: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   50cb8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   50cc0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   50cc8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   50cd0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   50cd8: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   50ce0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   50ce8: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   50cf0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   50cf8: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   50d00: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   50d08: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   50d10: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   50d18: 05 00 89 ff 00 00 00 00      	ja -0x77 <.text+0x50848>
   50d20: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50d28: 85 10 00 00 17 93 00 00      	call 0x9317
   50d30: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50d38: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50d40: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   50d50: 05 00 ed fb 00 00 00 00      	ja -0x413 <.text+0x4eba0>
   50d58: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   50d60: 85 10 00 00 10 93 00 00      	call 0x9310
   50d68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50d70: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50d78: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   50d88: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   50d90: 85 10 00 00 ef 65 ff ff      	call -0x9a11
   50d98: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50da0: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   50da8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50db0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   50db8: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   50dc0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   50dc8: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   50dd0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   50dd8: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   50de0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   50de8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   50df0: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   50df8: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   50e00: 7b 9a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r9
   50e08: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   50e10: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   50e18: 05 00 69 ff 00 00 00 00      	ja -0x97 <.text+0x50848>
   50e20: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50e28: 85 10 00 00 f7 92 00 00      	call 0x92f7
   50e30: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50e38: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50e40: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   50e50: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   50e58: 85 10 00 00 d6 65 ff ff      	call -0x9a2a
   50e60: 05 00 85 f9 00 00 00 00      	ja -0x67b <.text+0x4d970>
   50e68: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   50e70: 85 10 00 00 ee 92 00 00      	call 0x92ee
   50e78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50e80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50e88: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   50e98: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   50ea0: 85 10 00 00 cd 65 ff ff      	call -0x9a33
   50ea8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50eb0: 18 01 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r1, -0x6c5e9a281e0922fa
   50ec0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   50ec8: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   50ed0: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   50ed8: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   50ee0: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   50ee8: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   50ef0: 18 01 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r1, -0x53861431b91e3427
   50f00: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   50f08: 18 01 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r1, -0x6ec8a4a0127a4be4
   50f18: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   50f20: 18 01 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r1, -0x56ff00817a0a73c6
   50f30: 05 00 bb ff 00 00 00 00      	ja -0x45 <.text+0x50bf0>
   50f38: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50f40: 85 10 00 00 d4 92 00 00      	call 0x92d4
   50f48: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50f50: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50f58: 18 03 00 00 6c d0 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad06c
   50f68: b7 04 00 00 04 00 00 00      	mov64 r4, 0x4
   50f70: 85 10 00 00 b3 65 ff ff      	call -0x9a4d
   50f78: 05 00 62 f9 00 00 00 00      	ja -0x69e <.text+0x4d970>
   50f80: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50f88: 85 10 00 00 cb 92 00 00      	call 0x92cb
   50f90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50f98: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50fa0: 18 03 00 00 8d dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc8d
   50fb0: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   50fb8: 85 10 00 00 aa 65 ff ff      	call -0x9a56
   50fc0: 05 00 59 f9 00 00 00 00      	ja -0x6a7 <.text+0x4d970>
   50fc8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   50fd0: 85 10 00 00 c2 92 00 00      	call 0x92c2
   50fd8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   50fe0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   50fe8: 18 03 00 00 a4 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadca4
   50ff8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   51000: 85 10 00 00 a1 65 ff ff      	call -0x9a5f
   51008: 05 00 50 f9 00 00 00 00      	ja -0x6b0 <.text+0x4d970>
   51010: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   51018: 85 10 00 00 b9 92 00 00      	call 0x92b9
   51020: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51028: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51030: 18 03 00 00 bc dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcbc
   51040: 05 00 97 fc 00 00 00 00      	ja -0x369 <.text+0x4f3e0>
   51048: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   51050: 85 10 00 00 b2 92 00 00      	call 0x92b2
   51058: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51060: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51068: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   51078: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   51080: 85 10 00 00 91 65 ff ff      	call -0x9a6f
   51088: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51090: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   51098: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   510a0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   510a8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   510b0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   510b8: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   510c0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   510c8: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   510d0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   510d8: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   510e0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   510e8: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   510f0: 05 00 83 ff 00 00 00 00      	ja -0x7d <.text+0x50bf0>
   510f8: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   51100: 85 10 00 00 9c 92 00 00      	call 0x929c
   51108: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51110: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51118: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   51128: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   51130: 85 10 00 00 7b 65 ff ff      	call -0x9a85
   51138: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51140: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   51148: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   51150: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   51158: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   51160: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   51168: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
   51170: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   51178: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
   51180: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   51188: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
   51190: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   51198: 79 a1 90 fe 00 00 00 00      	ldxdw r1, [r10 - 0x170]
   511a0: 05 00 6d ff 00 00 00 00      	ja -0x93 <.text+0x50bf0>
   511a8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   511b0: 85 10 00 00 86 92 00 00      	call 0x9286
   511b8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   511c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   511c8: 18 03 00 00 d2 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadcd2
   511d8: b7 04 00 00 24 00 00 00      	mov64 r4, 0x24
   511e0: 85 10 00 00 65 65 ff ff      	call -0x9a9b
   511e8: 05 00 14 f9 00 00 00 00      	ja -0x6ec <.text+0x4d970>
   511f0: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   511f8: 85 10 00 00 7d 92 00 00      	call 0x927d
   51200: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51208: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51210: 18 03 00 00 0f dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd0f
   51220: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   51228: 85 10 00 00 5c 65 ff ff      	call -0x9aa4
   51230: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51238: 18 01 00 00 0c 14 de fc 00 00 00 00 82 5e c6 76      	lddw r1, 0x76c65e82fcde140c
   51248: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   51250: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   51258: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   51260: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   51268: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   51270: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   51278: 18 01 00 00 94 25 08 18 00 00 00 00 bb 65 40 65      	lddw r1, 0x654065bb18082594
   51288: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   51290: 18 01 00 00 f4 29 8d 31 00 00 00 00 56 d5 71 b4      	lddw r1, -0x4b8e2aa9ce72d60c
   512a0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   512a8: 18 01 00 00 d4 f8 09 0c 00 00 00 00 18 e9 a8 63      	lddw r1, 0x63a8e9180c09f8d4
   512b8: 05 00 4a ff 00 00 00 00      	ja -0xb6 <.text+0x50bf0>
   512c0: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   512c8: 85 10 00 00 63 92 00 00      	call 0x9263
   512d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   512d8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   512e0: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   512f0: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   512f8: 85 10 00 00 42 65 ff ff      	call -0x9abe
   51300: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51308: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   51310: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   51318: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   51320: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   51328: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   51330: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   51338: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   51340: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   51348: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   51350: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   51358: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   51360: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   51368: 05 00 34 ff 00 00 00 00      	ja -0xcc <.text+0x50bf0>
   51370: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   51378: 85 10 00 00 4d 92 00 00      	call 0x924d
   51380: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51388: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51390: 18 03 00 00 20 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd20
   513a0: b7 04 00 00 16 00 00 00      	mov64 r4, 0x16
   513a8: 85 10 00 00 2c 65 ff ff      	call -0x9ad4
   513b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   513b8: 79 a1 b8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x548]
   513c0: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   513c8: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   513d0: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   513d8: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   513e0: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   513e8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   513f0: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   513f8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   51400: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   51408: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   51410: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   51418: 05 00 1e ff 00 00 00 00      	ja -0xe2 <.text+0x50bf0>
   51420: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   51428: 05 00 15 fc 00 00 00 00      	ja -0x3eb <.text+0x4f3b8>
   51430: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   51438: 85 10 00 00 35 92 00 00      	call 0x9235
   51440: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51448: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51450: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   51460: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   51468: 85 10 00 00 14 65 ff ff      	call -0x9aec
   51470: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51478: 79 a1 f8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x508]
   51480: 05 00 24 ff 00 00 00 00      	ja -0xdc <.text+0x50c88>
   51488: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   51490: 85 10 00 00 2a 92 00 00      	call 0x922a
   51498: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   514a0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   514a8: 18 03 00 00 97 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd97
   514b8: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   514c0: 85 10 00 00 09 65 ff ff      	call -0x9af7
   514c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   514d0: 79 a1 e8 fa 00 00 00 00      	ldxdw r1, [r10 - 0x518]
   514d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   514e0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   514e8: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   514f0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   514f8: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   51500: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   51508: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   51510: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   51518: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   51520: 79 a1 a8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x458]
   51528: 05 00 19 ff 00 00 00 00      	ja -0xe7 <.text+0x50cd8>
   51530: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   51538: 85 10 00 00 15 92 00 00      	call 0x9215
   51540: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   51548: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   51550: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   51560: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   51568: 85 10 00 00 f4 64 ff ff      	call -0x9b0c
   51570: 05 00 a3 f8 00 00 00 00      	ja -0x75d <.text+0x4d970>
   525f8: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   52600: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   52608: bf 39 00 00 00 00 00 00      	mov64 r9, r3
   52610: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   52618: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   52620: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   52628: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   52630: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   52638: 85 10 00 00 3e 6f ff ff      	call -0x90c2
   52640: 79 a1 10 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2f0]
   52648: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   52650: 79 a6 08 fd 00 00 00 00      	ldxdw r6, [r10 - 0x2f8]
   52658: 55 06 23 00 02 00 00 00      	jne r6, 0x2, +0x23 <.text+0x52658>
   52660: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   52668: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   52670: 79 76 08 f0 00 00 00 00      	ldxdw r6, [r7 - 0xff8]
   52678: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   52680: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   52688: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   52690: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   52698: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   526a0: 85 10 00 00 85 6f ff ff      	call -0x907b
   526a8: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   526b0: 55 01 38 00 02 00 00 00      	jne r1, 0x2, +0x38 <.text+0x52758>
   526b8: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   526c0: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   526c8: 85 10 00 00 e4 61 00 00      	call 0x61e4
   526d0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   526e0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   526e8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   526f0: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   526f8: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   52700: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   52708: bd 21 6c 00 00 00 00 00      	jle r1, r2, +0x6c <.text+0x52950>
   52710: 15 04 6d 00 00 00 00 00      	jeq r4, 0x0, +0x6d <.text+0x52960>
   52718: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   52728: 55 02 6e 00 00 00 00 00      	jne r2, 0x0, +0x6e <.text+0x52980>
   52730: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52740: 55 06 6f 00 01 00 00 00      	jne r6, 0x1, +0x6f <.text+0x529a0>
   52748: 2d 21 6f 00 00 00 00 00      	jgt r1, r2, +0x6f <.text+0x529a8>
   52750: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   52758: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   52760: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   52770: 85 10 00 00 1a a2 00 00      	call 0xa21a
   52778: 85 10 00 00 ce 61 00 00      	call 0x61ce
   52780: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   52790: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   52798: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   527a0: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   527a8: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   527b0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   527b8: bd 21 4f 00 00 00 00 00      	jle r1, r2, +0x4f <.text+0x52918>
   527c0: 15 04 50 00 00 00 00 00      	jeq r4, 0x0, +0x50 <.text+0x52928>
   527c8: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   527d8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x526c8>
   527e0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   527e8: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   527f0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   527f8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52808: 79 a3 00 fd 00 00 00 00      	ldxdw r3, [r10 - 0x300]
   52810: bd 21 13 06 00 00 00 00      	jle r1, r2, +0x613 <.text+0x55790>
   52818: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   52828: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   52830: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   52838: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   52840: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   52848: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   52850: 7a 03 18 00 06 00 00 00      	stdw [r3 + 0x18], 0x6
   52858: 7a 03 08 00 06 00 00 00      	stdw [r3 + 0x8], 0x6
   52860: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   52868: 7b 38 10 00 00 00 00 00      	stxdw [r8 + 0x10], r3
   52870: 05 00 59 00 00 00 00 00      	ja +0x59 <.text+0x52a20>
   52878: 85 10 00 00 ae 61 00 00      	call 0x61ae
   52880: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   52890: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   52898: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   528a0: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   528a8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   528b0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   528b8: bd 13 53 00 00 00 00 00      	jle r3, r1, +0x53 <.text+0x52a38>
   528c0: 7b 6a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r6
   528c8: 15 04 54 00 00 00 00 00      	jeq r4, 0x0, +0x54 <.text+0x52a50>
   528d0: 18 06 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r6, 0x300007f00
   528e0: 55 01 55 00 00 00 00 00      	jne r1, 0x0, +0x55 <.text+0x52a70>
   528e8: 7b 8a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r8
   528f0: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   52900: bd 16 57 00 00 00 00 00      	jle r6, r1, +0x57 <.text+0x52aa0>
   52908: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
   52918: 7b 68 00 00 00 00 00 00      	stxdw [r8 + 0x0], r6
   52920: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   52928: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   52930: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   52938: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   52940: 85 10 00 00 88 af 00 00      	call 0xaf88
   52948: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   52950: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   52958: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   52960: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   52968: 85 10 00 00 f9 6e ff ff      	call -0x9107
   52970: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   52978: 55 01 4b 00 02 00 00 00      	jne r1, 0x2, +0x4b <.text+0x52ab8>
   52980: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   52988: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   52990: 85 10 00 00 8b 61 00 00      	call 0x618b
   52998: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   529a0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   529a8: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   529b0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   529b8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   529c0: bd 21 74 00 00 00 00 00      	jle r1, r2, +0x74 <.text+0x52c48>
   529c8: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   529d0: 15 04 75 00 00 00 00 00      	jeq r4, 0x0, +0x75 <.text+0x52c60>
   529d8: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   529e8: 55 02 76 00 00 00 00 00      	jne r2, 0x0, +0x76 <.text+0x52c80>
   529f0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52a00: 55 06 77 00 01 00 00 00      	jne r6, 0x1, +0x77 <.text+0x52ca0>
   52a08: 2d 21 77 00 00 00 00 00      	jgt r1, r2, +0x77 <.text+0x52ca8>
   52a10: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   52a18: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   52a20: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   52a30: 85 10 00 00 c2 a1 00 00      	call 0xa1c2
   52a38: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   52a40: 55 04 b0 ff 00 00 00 00      	jne r4, 0x0, -0x50 <.text+0x526a8>
   52a48: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   52a50: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   52a60: 55 02 af ff 00 00 00 00      	jne r2, 0x0, -0x51 <.text+0x526c0>
   52a68: 05 00 af ff 00 00 00 00      	ja -0x51 <.text+0x526c8>
   52a70: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   52a78: 55 04 93 ff 00 00 00 00      	jne r4, 0x0, -0x6d <.text+0x525f8>
   52a80: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   52a88: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   52a98: 15 02 92 ff 00 00 00 00      	jeq r2, 0x0, -0x6e <.text+0x52610>
   52aa0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   52aa8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52ab8: 15 06 91 ff 01 00 00 00      	jeq r6, 0x1, -0x6f <.text+0x52628>
   52ac0: bd 21 91 ff 00 00 00 00      	jle r1, r2, -0x6f <.text+0x52630>
   52ac8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   52ad8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   52ae0: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   52af0: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   52af8: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   52b08: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   52b10: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   52b18: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   52b20: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   52b28: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   52b30: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   52b38: 7b 78 10 00 00 00 00 00      	stxdw [r8 + 0x10], r7
   52b40: 7b 68 08 00 00 00 00 00      	stxdw [r8 + 0x8], r6
   52b48: 7a 08 00 00 00 00 00 00      	stdw [r8 + 0x0], 0x0
   52b50: 05 00 fc 00 00 00 00 00      	ja +0xfc <.text+0x53218>
   52b58: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   52b60: 7b 6a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r6
   52b68: 55 04 ac ff 00 00 00 00      	jne r4, 0x0, -0x54 <.text+0x527b0>
   52b70: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   52b78: 18 06 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r6, 0x300007f00
   52b88: 15 01 ab ff 00 00 00 00      	jeq r1, 0x0, -0x55 <.text+0x527c8>
   52b90: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   52b98: bf 26 00 00 00 00 00 00      	mov64 r6, r2
   52ba0: 7b 8a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r8
   52ba8: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   52bb8: 2d 16 a9 ff 00 00 00 00      	jgt r6, r1, -0x57 <.text+0x527e8>
   52bc0: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   52bc8: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   52bd0: 85 10 00 00 92 a1 00 00      	call 0xa192
   52bd8: 85 10 00 00 42 61 00 00      	call 0x6142
   52be0: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   52be8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   52bf0: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   52bf8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   52c00: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   52c08: bd 53 43 00 00 00 00 00      	jle r3, r5, +0x43 <.text+0x52d08>
   52c10: 15 04 44 00 00 00 00 00      	jeq r4, 0x0, +0x44 <.text+0x52d18>
   52c18: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   52c28: 55 05 45 00 00 00 00 00      	jne r5, 0x0, +0x45 <.text+0x52d38>
   52c30: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52c40: bd 21 47 00 00 00 00 00      	jle r1, r2, +0x47 <.text+0x52d60>
   52c48: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   52c50: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   52c58: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   52c60: 7b 1a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r1
   52c68: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   52c70: 85 10 00 00 22 af 00 00      	call 0xaf22
   52c78: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   52c80: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   52c88: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   52c90: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   52c98: 85 10 00 00 0a 60 ff ff      	call -0x9ff6
   52ca0: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   52ca8: 55 01 3d 00 02 00 00 00      	jne r1, 0x2, +0x3d <.text+0x52d78>
   52cb0: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   52cb8: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   52cc0: 85 10 00 00 25 61 00 00      	call 0x6125
   52cc8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   52cd0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   52cd8: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   52ce0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   52ce8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   52cf0: bd 21 66 00 00 00 00 00      	jle r1, r2, +0x66 <.text+0x52f08>
   52cf8: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   52d00: 15 04 67 00 00 00 00 00      	jeq r4, 0x0, +0x67 <.text+0x52f20>
   52d08: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   52d18: 55 02 68 00 00 00 00 00      	jne r2, 0x0, +0x68 <.text+0x52f40>
   52d20: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52d30: 55 06 69 00 01 00 00 00      	jne r6, 0x1, +0x69 <.text+0x52f60>
   52d38: 2d 21 69 00 00 00 00 00      	jgt r1, r2, +0x69 <.text+0x52f68>
   52d40: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   52d48: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   52d50: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   52d60: 85 10 00 00 5c a1 00 00      	call 0xa15c
   52d68: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   52d70: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   52d78: 55 04 8b ff 00 00 00 00      	jne r4, 0x0, -0x75 <.text+0x528b8>
   52d80: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   52d88: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   52d98: 15 02 8a ff 00 00 00 00      	jeq r2, 0x0, -0x76 <.text+0x528d0>
   52da0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   52da8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52db8: 15 06 89 ff 01 00 00 00      	jeq r6, 0x1, -0x77 <.text+0x528e8>
   52dc0: bd 21 89 ff 00 00 00 00      	jle r1, r2, -0x77 <.text+0x528f0>
   52dc8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   52dd8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   52de0: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   52df0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   52df8: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   52e00: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   52e08: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   52e10: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   52e18: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   52e20: 05 00 9e 00 00 00 00 00      	ja +0x9e <.text+0x531f8>
   52e28: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   52e30: 55 04 bc ff 00 00 00 00      	jne r4, 0x0, -0x44 <.text+0x52af8>
   52e38: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   52e40: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   52e50: 15 05 bb ff 00 00 00 00      	jeq r5, 0x0, -0x45 <.text+0x52b10>
   52e58: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   52e60: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   52e68: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52e78: 2d 21 b9 ff 00 00 00 00      	jgt r1, r2, -0x47 <.text+0x52b28>
   52e80: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   52e88: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   52e90: 85 10 00 00 3a a1 00 00      	call 0xa13a
   52e98: 85 10 00 00 ea 60 00 00      	call 0x60ea
   52ea0: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   52ea8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   52eb0: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   52eb8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   52ec0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   52ec8: bd 53 40 00 00 00 00 00      	jle r3, r5, +0x40 <.text+0x52fb0>
   52ed0: 15 04 41 00 00 00 00 00      	jeq r4, 0x0, +0x41 <.text+0x52fc0>
   52ed8: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   52ee8: 55 05 42 00 00 00 00 00      	jne r5, 0x0, +0x42 <.text+0x52fe0>
   52ef0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52f00: bd 21 44 00 00 00 00 00      	jle r1, r2, +0x44 <.text+0x53008>
   52f08: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   52f10: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   52f18: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   52f20: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   52f28: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   52f30: 85 10 00 00 ca ae 00 00      	call 0xaeca
   52f38: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   52f40: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   52f48: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   52f50: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   52f58: 85 10 00 00 c3 5f ff ff      	call -0xa03d
   52f60: 61 a1 b0 ff 00 00 00 00      	ldxw r1, [r10 - 0x50]
   52f68: 55 01 3a 00 02 00 00 00      	jne r1, 0x2, +0x3a <.text+0x53020>
   52f70: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   52f78: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   52f80: 85 10 00 00 cd 60 00 00      	call 0x60cd
   52f88: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   52f90: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   52f98: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   52fa0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   52fa8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   52fb0: bd 21 52 00 00 00 00 00      	jle r1, r2, +0x52 <.text+0x53128>
   52fb8: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   52fc0: 15 04 53 00 00 00 00 00      	jeq r4, 0x0, +0x53 <.text+0x53140>
   52fc8: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   52fd8: 55 02 54 00 00 00 00 00      	jne r2, 0x0, +0x54 <.text+0x53160>
   52fe0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   52ff0: 55 06 55 00 01 00 00 00      	jne r6, 0x1, +0x55 <.text+0x53180>
   52ff8: 2d 21 55 00 00 00 00 00      	jgt r1, r2, +0x55 <.text+0x53188>
   53000: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   53008: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   53010: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   53020: 85 10 00 00 04 a1 00 00      	call 0xa104
   53028: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   53030: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   53038: 55 04 99 ff 00 00 00 00      	jne r4, 0x0, -0x67 <.text+0x52be8>
   53040: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   53048: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   53058: 15 02 98 ff 00 00 00 00      	jeq r2, 0x0, -0x68 <.text+0x52c00>
   53060: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   53068: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   53078: 15 06 97 ff 01 00 00 00      	jeq r6, 0x1, -0x69 <.text+0x52c18>
   53080: bd 21 97 ff 00 00 00 00      	jle r1, r2, -0x69 <.text+0x52c20>
   53088: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   53098: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   530a0: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   530a8: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   530b0: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   530b8: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   530c0: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   530c8: 05 00 49 00 00 00 00 00      	ja +0x49 <.text+0x531f8>
   530d0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   530d8: 55 04 bf ff 00 00 00 00      	jne r4, 0x0, -0x41 <.text+0x52db8>
   530e0: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   530e8: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   530f8: 15 05 be ff 00 00 00 00      	jeq r5, 0x0, -0x42 <.text+0x52dd0>
   53100: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   53108: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   53110: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   53120: 2d 21 bc ff 00 00 00 00      	jgt r1, r2, -0x44 <.text+0x52de8>
   53128: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   53130: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   53138: 85 10 00 00 e5 a0 00 00      	call 0xa0e5
   53140: 7b 6a c0 fc 00 00 00 00      	stxdw [r10 - 0x340], r6
   53148: 85 10 00 00 94 60 00 00      	call 0x6094
   53150: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   53158: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   53160: 07 03 00 00 28 ff ff ff      	add64 r3, -0xd8
   53168: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   53170: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   53178: bd 13 38 00 00 00 00 00      	jle r3, r1, +0x38 <.text+0x53220>
   53180: 79 a6 e0 fc 00 00 00 00      	ldxdw r6, [r10 - 0x320]
   53188: 15 04 39 00 00 00 00 00      	jeq r4, 0x0, +0x39 <.text+0x53238>
   53190: 18 08 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300007f28
   531a0: 55 01 3a 00 00 00 00 00      	jne r1, 0x0, +0x3a <.text+0x53258>
   531a8: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   531b8: bd 18 3c 00 00 00 00 00      	jle r8, r1, +0x3c <.text+0x53280>
   531c0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   531d0: 7b 81 00 00 00 00 00 00      	stxdw [r1 + 0x0], r8
   531d8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   531e0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   531e8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   531f0: b7 03 00 00 d8 00 00 00      	mov64 r3, 0xd8
   531f8: 85 10 00 00 71 ae 00 00      	call 0xae71
   53200: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53208: 15 01 35 00 00 00 00 00      	jeq r1, 0x0, +0x35 <.text+0x53298>
   53210: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53218: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53220: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   53228: 7b 1a b8 fc 00 00 00 00      	stxdw [r10 - 0x348], r1
   53230: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   53238: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   53240: 05 00 3b 00 00 00 00 00      	ja +0x3b <.text+0x53300>
   53248: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   53250: 79 a5 e0 fc 00 00 00 00      	ldxdw r5, [r10 - 0x320]
   53258: 55 04 ad ff 00 00 00 00      	jne r4, 0x0, -0x53 <.text+0x52ea8>
   53260: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   53268: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   53278: 15 02 ac ff 00 00 00 00      	jeq r2, 0x0, -0x54 <.text+0x52ec0>
   53280: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   53288: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   53298: 15 06 ab ff 01 00 00 00      	jeq r6, 0x1, -0x55 <.text+0x52ed8>
   532a0: bd 21 ab ff 00 00 00 00      	jle r1, r2, -0x55 <.text+0x52ee0>
   532a8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   532b8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   532c0: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   532d0: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   532d8: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   532e8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   532f0: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   532f8: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   53300: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   53308: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   53310: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   53318: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   53320: 7b 75 10 00 00 00 00 00      	stxdw [r5 + 0x10], r7
   53328: 7b 65 08 00 00 00 00 00      	stxdw [r5 + 0x8], r6
   53330: 7a 05 00 00 00 00 00 00      	stdw [r5 + 0x0], 0x0
   53338: 95 00 00 00 00 00 00 00      	exit
   53340: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   53348: 79 a6 e0 fc 00 00 00 00      	ldxdw r6, [r10 - 0x320]
   53350: 55 04 c7 ff 00 00 00 00      	jne r4, 0x0, -0x39 <.text+0x53070>
   53358: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   53360: 18 08 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300007f28
   53370: 15 01 c6 ff 00 00 00 00      	jeq r1, 0x0, -0x3a <.text+0x53088>
   53378: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   53380: bf 28 00 00 00 00 00 00      	mov64 r8, r2
   53388: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   53398: 2d 18 c4 ff 00 00 00 00      	jgt r8, r1, -0x3c <.text+0x530a0>
   533a0: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   533a8: b7 02 00 00 d8 00 00 00      	mov64 r2, 0xd8
   533b0: 85 10 00 00 96 a0 00 00      	call 0xa096
   533b8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   533c0: 85 10 00 00 44 8e 00 00      	call 0x8e44
   533c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   533d0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x532c8>
   533d8: 7b 2a b8 fc 00 00 00 00      	stxdw [r10 - 0x348], r2
   533e0: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x53300>
   533e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   533f0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   53400: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   53408: 85 10 00 00 20 61 ff ff      	call -0x9ee0
   53410: 55 00 01 02 02 00 00 00      	jne r0, 0x2, +0x201 <.text+0x54300>
   53418: 7b 1a b8 fc 00 00 00 00      	stxdw [r10 - 0x348], r1
   53420: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   53428: 07 01 00 00 18 fd ff ff      	add64 r1, -0x2e8
   53430: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   53438: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   53440: 85 10 00 00 f3 6d ff ff      	call -0x920d
   53448: 79 a2 20 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2e0]
   53450: 79 a1 18 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2e8]
   53458: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x53350>
   53460: 7b 2a b0 fc 00 00 00 00      	stxdw [r10 - 0x350], r2
   53468: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x53380>
   53470: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   53480: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   53488: 85 10 00 00 10 61 ff ff      	call -0x9ef0
   53490: 55 00 f1 01 02 00 00 00      	jne r0, 0x2, +0x1f1 <.text+0x54300>
   53498: 7b 1a b0 fc 00 00 00 00      	stxdw [r10 - 0x350], r1
   534a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   534a8: 07 01 00 00 28 fd ff ff      	add64 r1, -0x2d8
   534b0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   534b8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   534c0: 85 10 00 00 55 6e ff ff      	call -0x91ab
   534c8: 79 a2 30 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2d0]
   534d0: 79 a1 28 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2d8]
   534d8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x533f0>
   534e0: 18 03 00 00 89 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb89
   534f0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   534f8: 85 10 00 00 02 61 ff ff      	call -0x9efe
   53500: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53508: 55 00 2c 01 02 00 00 00      	jne r0, 0x2, +0x12c <.text+0x53d50>
   53510: 7b 2a a8 fc 00 00 00 00      	stxdw [r10 - 0x358], r2
   53518: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53520: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53440>
   53528: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53530: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53538: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   53540: 7b 1a a0 fc 00 00 00 00      	stxdw [r10 - 0x360], r1
   53548: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   53550: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   53558: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x534a8>
   53560: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53568: 85 10 00 00 0f 8e 00 00      	call 0x8e0f
   53570: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53578: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53470>
   53580: 7b 2a a0 fc 00 00 00 00      	stxdw [r10 - 0x360], r2
   53588: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x534a8>
   53590: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53598: 18 03 00 00 e8 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbe8
   535a8: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   535b0: 85 10 00 00 eb 60 ff ff      	call -0x9f15
   535b8: 55 00 cc 01 02 00 00 00      	jne r0, 0x2, +0x1cc <.text+0x54300>
   535c0: 7b 1a a0 fc 00 00 00 00      	stxdw [r10 - 0x360], r1
   535c8: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   535d0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   535d8: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   535e0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   535e8: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   535f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   535f8: 07 01 00 00 38 fd ff ff      	add64 r1, -0x2c8
   53600: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   53608: 79 a2 f8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x308]
   53610: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   53618: 79 a4 f0 fc 00 00 00 00      	ldxdw r4, [r10 - 0x310]
   53620: 85 10 00 00 86 63 ff ff      	call -0x9c7a
   53628: 79 a2 40 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2c0]
   53630: 79 a1 38 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2c8]
   53638: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x53550>
   53640: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   53650: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   53658: 85 10 00 00 d6 60 ff ff      	call -0x9f2a
   53660: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53668: 55 00 00 01 02 00 00 00      	jne r0, 0x2, +0x100 <.text+0x53d50>
   53670: 7b 2a 98 fc 00 00 00 00      	stxdw [r10 - 0x368], r2
   53678: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53680: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x535a0>
   53688: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53690: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53698: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   536a0: 7b 1a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r1
   536a8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   536b0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   536b8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x53608>
   536c0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   536c8: 85 10 00 00 e3 8d 00 00      	call 0x8de3
   536d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   536d8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x535d0>
   536e0: 7b 2a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r2
   536e8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x53608>
   536f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   536f8: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   53708: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   53710: 85 10 00 00 bf 60 ff ff      	call -0x9f41
   53718: 55 00 a0 01 02 00 00 00      	jne r0, 0x2, +0x1a0 <.text+0x54300>
   53720: 7b 1a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r1
   53728: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   53730: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   53738: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   53740: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   53748: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   53750: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   53758: 07 01 00 00 48 fd ff ff      	add64 r1, -0x2b8
   53760: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   53768: 79 a2 f8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x308]
   53770: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   53778: 79 a4 f0 fc 00 00 00 00      	ldxdw r4, [r10 - 0x310]
   53780: 85 10 00 00 86 62 ff ff      	call -0x9d7a
   53788: 79 a7 50 fd 00 00 00 00      	ldxdw r7, [r10 - 0x2b0]
   53790: 79 a1 48 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2b8]
   53798: 15 01 07 00 02 00 00 00      	jeq r1, 0x2, +0x7 <.text+0x536b8>
   537a0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   537a8: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   537b8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   537c0: 85 10 00 00 a9 60 ff ff      	call -0x9f57
   537c8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   537d0: 55 00 1b 00 02 00 00 00      	jne r0, 0x2, +0x1b <.text+0x53790>
   537d8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   537e0: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x53738>
   537e8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   537f0: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   537f8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53800: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53808: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53810: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53818: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x53760>
   53820: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53828: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   53830: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53838: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53840: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53848: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53850: 05 00 15 00 00 00 00 00      	ja +0x15 <.text+0x537e0>
   53858: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53860: 85 10 00 00 b0 8d 00 00      	call 0x8db0
   53868: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53870: 55 00 4b 00 02 00 00 00      	jne r0, 0x2, +0x4b <.text+0x539b0>
   53878: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   53880: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53888: 85 10 00 00 ab 8d 00 00      	call 0x8dab
   53890: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53898: 55 00 04 00 02 00 00 00      	jne r0, 0x2, +0x4 <.text+0x537a0>
   538a0: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   538a8: 05 00 12 00 00 00 00 00      	ja +0x12 <.text+0x53820>
   538b0: 7b 76 10 00 00 00 00 00      	stxdw [r6 + 0x10], r7
   538b8: 05 00 6d 01 00 00 00 00      	ja +0x16d <.text+0x54308>
   538c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   538c8: 18 03 00 00 fa db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbfa
   538d8: b7 04 00 00 14 00 00 00      	mov64 r4, 0x14
   538e0: 85 10 00 00 85 60 ff ff      	call -0x9f7b
   538e8: 55 00 66 01 02 00 00 00      	jne r0, 0x2, +0x166 <.text+0x54300>
   538f0: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   538f8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53900: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53820>
   53908: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53910: 7b 2a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r2
   53918: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53920: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53928: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53930: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53938: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x53890>
   53940: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53948: 85 10 00 00 93 8d 00 00      	call 0x8d93
   53950: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53958: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53850>
   53960: 7b 2a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r2
   53968: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x538d0>
   53970: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53978: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   53988: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   53990: 85 10 00 00 6f 60 ff ff      	call -0x9f91
   53998: 55 00 50 01 02 00 00 00      	jne r0, 0x2, +0x150 <.text+0x54300>
   539a0: 7b 1a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r1
   539a8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   539b0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x538d0>
   539b8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   539c0: 7b 2a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r2
   539c8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   539d0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   539d8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   539e0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   539e8: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x53940>
   539f0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   539f8: 85 10 00 00 7d 8d 00 00      	call 0x8d7d
   53a00: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53a08: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53900>
   53a10: 7b 2a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r2
   53a18: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x53980>
   53a20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53a28: 18 03 00 00 52 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd52
   53a38: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   53a40: 85 10 00 00 59 60 ff ff      	call -0x9fa7
   53a48: 55 00 3a 01 02 00 00 00      	jne r0, 0x2, +0x13a <.text+0x54300>
   53a50: 7b 1a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r1
   53a58: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53a60: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53980>
   53a68: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53a70: 7b 2a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r2
   53a78: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53a80: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53a88: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53a90: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53a98: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x53a40>
   53aa0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53aa8: 85 10 00 00 67 8d 00 00      	call 0x8d67
   53ab0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53ab8: 55 00 0c 00 02 00 00 00      	jne r0, 0x2, +0xc <.text+0x53a00>
   53ac0: 7b 2a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r2
   53ac8: 05 00 1a 00 00 00 00 00      	ja +0x1a <.text+0x53a80>
   53ad0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53ad8: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   53ae8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   53af0: 85 10 00 00 43 60 ff ff      	call -0x9fbd
   53af8: 55 00 24 01 02 00 00 00      	jne r0, 0x2, +0x124 <.text+0x54300>
   53b00: 7b 1a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r1
   53b08: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53b10: 55 01 a1 ff 00 00 00 00      	jne r1, 0x0, -0x5f <.text+0x53700>
   53b18: 05 00 ac ff 00 00 00 00      	ja -0x54 <.text+0x53760>
   53b20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53b28: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   53b38: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   53b40: 85 10 00 00 39 60 ff ff      	call -0x9fc7
   53b48: 55 00 1a 01 02 00 00 00      	jne r0, 0x2, +0x11a <.text+0x54300>
   53b50: 7b 1a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r1
   53b58: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53b60: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53a80>
   53b68: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53b70: 7b 2a 70 fc 00 00 00 00      	stxdw [r10 - 0x390], r2
   53b78: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53b80: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53b88: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53b90: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53b98: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x53af0>
   53ba0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53ba8: 85 10 00 00 47 8d 00 00      	call 0x8d47
   53bb0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53bb8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53ab0>
   53bc0: 7b 2a 70 fc 00 00 00 00      	stxdw [r10 - 0x390], r2
   53bc8: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x53b30>
   53bd0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53bd8: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   53be8: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   53bf0: 85 10 00 00 23 60 ff ff      	call -0x9fdd
   53bf8: 55 00 04 01 02 00 00 00      	jne r0, 0x2, +0x104 <.text+0x54300>
   53c00: 7b 1a 70 fc 00 00 00 00      	stxdw [r10 - 0x390], r1
   53c08: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53c10: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53b30>
   53c18: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53c20: 7b 2a 68 fc 00 00 00 00      	stxdw [r10 - 0x398], r2
   53c28: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53c30: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53c38: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53c40: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53c48: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x53ba0>
   53c50: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53c58: 85 10 00 00 31 8d 00 00      	call 0x8d31
   53c60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53c68: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53b60>
   53c70: 7b 2a 68 fc 00 00 00 00      	stxdw [r10 - 0x398], r2
   53c78: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x53be0>
   53c80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53c88: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   53c98: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   53ca0: 85 10 00 00 0d 60 ff ff      	call -0x9ff3
   53ca8: 55 00 ee 00 02 00 00 00      	jne r0, 0x2, +0xee <.text+0x54300>
   53cb0: 7b 1a 68 fc 00 00 00 00      	stxdw [r10 - 0x398], r1
   53cb8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53cc0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x53be0>
   53cc8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53cd0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53cd8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   53ce0: 7b 1a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r1
   53ce8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   53cf0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   53cf8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x53c48>
   53d00: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53d08: 85 10 00 00 1b 8d 00 00      	call 0x8d1b
   53d10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53d18: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53c10>
   53d20: 7b 2a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r2
   53d28: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x53c48>
   53d30: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53d38: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   53d48: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   53d50: 85 10 00 00 f7 5f ff ff      	call -0xa009
   53d58: 55 00 d8 00 02 00 00 00      	jne r0, 0x2, +0xd8 <.text+0x54300>
   53d60: 7b 1a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r1
   53d68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   53d70: 07 01 00 00 58 fd ff ff      	add64 r1, -0x2a8
   53d78: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   53d80: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   53d88: 85 10 00 00 7c 6d ff ff      	call -0x9284
   53d90: 79 a2 60 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2a0]
   53d98: 79 a1 58 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2a8]
   53da0: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x53cb8>
   53da8: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   53db8: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   53dc0: 85 10 00 00 e9 5f ff ff      	call -0xa017
   53dc8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53dd0: 55 00 13 00 02 00 00 00      	jne r0, 0x2, +0x13 <.text+0x53d50>
   53dd8: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   53de0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   53de8: 15 01 12 00 00 00 00 00      	jeq r1, 0x0, +0x12 <.text+0x53d60>
   53df0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   53df8: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   53e00: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   53e08: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   53e10: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53e18: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53e20: 15 01 10 00 00 00 00 00      	jeq r1, 0x0, +0x10 <.text+0x53d88>
   53e28: 7b 7a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r7
   53e30: bf 87 00 00 00 00 00 00      	mov64 r7, r8
   53e38: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   53e40: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   53e48: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   53e50: 7b 1a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r1
   53e58: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   53e60: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   53e68: 05 00 16 00 00 00 00 00      	ja +0x16 <.text+0x53e00>
   53e70: 7b 26 10 00 00 00 00 00      	stxdw [r6 + 0x10], r2
   53e78: 05 00 b5 00 00 00 00 00      	ja +0xb5 <.text+0x54308>
   53e80: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53e88: 85 10 00 00 eb 8c 00 00      	call 0x8ceb
   53e90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53e98: 55 00 6f 00 02 00 00 00      	jne r0, 0x2, +0x6f <.text+0x540f8>
   53ea0: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   53ea8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   53eb0: 85 10 00 00 e6 8c 00 00      	call 0x8ce6
   53eb8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   53ec0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x53db8>
   53ec8: 7b 2a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r2
   53ed0: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x53df0>
   53ed8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   53ee0: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   53ef0: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   53ef8: 85 10 00 00 c2 5f ff ff      	call -0xa03e
   53f00: 55 00 a3 00 02 00 00 00      	jne r0, 0x2, +0xa3 <.text+0x54300>
   53f08: 7b 1a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r1
   53f10: 7b 7a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r7
   53f18: bf 87 00 00 00 00 00 00      	mov64 r7, r8
   53f20: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   53f30: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   53f38: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   53f40: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   53f48: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   53f50: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   53f58: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   53f60: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   53f68: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   53f70: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   53f78: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   53f80: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   53f88: 07 08 00 00 68 fd ff ff      	add64 r8, -0x298
   53f90: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   53f98: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   53fa0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   53fa8: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   53fb0: 85 10 00 00 ba ac 00 00      	call 0xacba
   53fb8: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   53fc0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   53fc8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   53fd0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   53fd8: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   53fe0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   53fe8: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   53ff0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   53ff8: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   54000: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54008: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   54010: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   54018: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   54020: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   54028: 85 10 00 00 68 6d ff ff      	call -0x9298
   54030: 15 00 0a 00 00 00 00 00      	jeq r0, 0x0, +0xa <.text+0x53f68>
   54038: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   54040: 85 10 00 00 b4 8c 00 00      	call 0x8cb4
   54048: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   54050: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   54058: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   54068: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   54070: 85 10 00 00 93 5f ff ff      	call -0xa06d
   54078: 79 a6 e0 fc 00 00 00 00      	ldxdw r6, [r10 - 0x320]
   54080: 05 00 55 00 00 00 00 00      	ja +0x55 <.text+0x54210>
   54088: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   54090: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54098: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   540a0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   540a8: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   540b0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   540b8: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   540c0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   540c8: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   540d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   540d8: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   540e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   540e8: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   540f0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   540f8: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   54100: 85 10 00 00 4d 6d ff ff      	call -0x92b3
   54108: 79 a6 e0 fc 00 00 00 00      	ldxdw r6, [r10 - 0x320]
   54110: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x54038>
   54118: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   54120: 85 10 00 00 98 8c 00 00      	call 0x8c98
   54128: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   54130: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   54138: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   54148: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   54150: 05 00 3a 00 00 00 00 00      	ja +0x3a <.text+0x54208>
   54158: 79 71 20 00 00 00 00 00      	ldxdw r1, [r7 + 0x20]
   54160: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54168: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   54170: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   54178: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54180: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   54188: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   54190: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   54198: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   541a0: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   541a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   541b0: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   541b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   541c0: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   541c8: 85 10 00 00 34 6d ff ff      	call -0x92cc
   541d0: 15 00 12 00 00 00 00 00      	jeq r0, 0x0, +0x12 <.text+0x54148>
   541d8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   541e0: 85 10 00 00 80 8c 00 00      	call 0x8c80
   541e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   541f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   541f8: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   54208: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   54210: 05 00 22 00 00 00 00 00      	ja +0x22 <.text+0x54208>
   54218: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   54220: 18 03 00 00 98 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad798
   54230: b7 04 00 00 10 00 00 00      	mov64 r4, 0x10
   54238: 85 10 00 00 5a 5f ff ff      	call -0xa0a6
   54240: 55 00 3b 00 02 00 00 00      	jne r0, 0x2, +0x3b <.text+0x54300>
   54248: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   54250: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   54258: 55 01 79 ff 00 00 00 00      	jne r1, 0x0, -0x87 <.text+0x53d08>
   54260: 05 00 88 ff 00 00 00 00      	ja -0x78 <.text+0x53d88>
   54268: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   54270: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54278: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54280: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   54288: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   54290: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54298: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   542a0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   542a8: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   542b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   542b8: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   542c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   542c8: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   542d0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   542d8: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   542e0: 85 10 00 00 11 6d ff ff      	call -0x92ef
   542e8: 15 00 0c 00 00 00 00 00      	jeq r0, 0x0, +0xc <.text+0x54230>
   542f0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   542f8: 85 10 00 00 5d 8c 00 00      	call 0x8c5d
   54300: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   54308: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   54310: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   54320: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   54328: 85 10 00 00 3c 5f ff ff      	call -0xa0c4
   54330: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   54338: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   54340: 7a 06 00 00 00 00 00 00      	stdw [r6 + 0x0], 0x0
   54348: 05 00 fd fd 00 00 00 00      	ja -0x203 <.text+0x53218>
   54350: 7b 7a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r7
   54358: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   54360: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   54368: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54370: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   54378: 7b 2a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r2
   54380: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54388: 7b 2a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r2
   54390: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   54398: 7b 2a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r2
   543a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   543a8: 7b 1a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r1
   543b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   543b8: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   543c0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   543c8: 07 02 00 00 18 fe ff ff      	add64 r2, -0x1e8
   543d0: 85 10 00 00 f3 6c ff ff      	call -0x930d
   543d8: 15 00 0c 00 00 00 00 00      	jeq r0, 0x0, +0xc <.text+0x54320>
   543e0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   543e8: 85 10 00 00 3f 8c 00 00      	call 0x8c3f
   543f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   543f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   54400: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   54410: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   54418: 85 10 00 00 1e 5f ff ff      	call -0xa0e2
   54420: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   54428: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   54430: 7a 06 00 00 00 00 00 00      	stdw [r6 + 0x0], 0x0
   54438: 05 00 df fd 00 00 00 00      	ja -0x221 <.text+0x53218>
   54440: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   54448: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54450: 15 01 2a 02 00 00 00 00      	jeq r1, 0x0, +0x22a <.text+0x55488>
   54458: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   54460: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   54468: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   54470: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   54478: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   54480: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   54490: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   54498: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   544a0: 85 10 00 00 ff ff ff ff      	call -0x1
   544a8: 55 00 9a 02 00 00 00 00      	jne r0, 0x0, +0x29a <.text+0x55860>
   544b0: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   544b8: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   544c0: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   544c8: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   544d0: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   544d8: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   544e0: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   544e8: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   544f0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   544f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54500: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   54508: 5d 93 1c 02 00 00 00 00      	jne r3, r9, +0x21c <.text+0x554d0>
   54510: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   54518: 5d 83 1a 02 00 00 00 00      	jne r3, r8, +0x21a <.text+0x554d0>
   54520: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   54528: 5d 73 18 02 00 00 00 00      	jne r3, r7, +0x218 <.text+0x554d0>
   54530: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   54538: 5d 62 16 02 00 00 00 00      	jne r2, r6, +0x216 <.text+0x554d0>
   54540: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54548: 15 01 35 02 00 00 00 00      	jeq r1, 0x0, +0x235 <.text+0x555d8>
   54550: 79 a2 c0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x340]
   54558: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   54560: 7b 1a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r1
   54568: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   54570: 7b 1a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r1
   54578: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   54580: 7b 1a 30 fc 00 00 00 00      	stxdw [r10 - 0x3d0], r1
   54588: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   54590: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54598: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   545a0: 7b 3a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r3
   545a8: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   545b0: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   545b8: 79 29 28 00 00 00 00 00      	ldxdw r9, [r2 + 0x28]
   545c0: 79 16 00 00 00 00 00 00      	ldxdw r6, [r1 + 0x0]
   545c8: 5d 69 2d 02 00 00 00 00      	jne r9, r6, +0x22d <.text+0x55618>
   545d0: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   545d8: 5d 81 2b 02 00 00 00 00      	jne r1, r8, +0x22b <.text+0x55618>
   545e0: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   545e8: 5d 71 29 02 00 00 00 00      	jne r1, r7, +0x229 <.text+0x55618>
   545f0: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   545f8: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   54600: 5d 21 26 02 00 00 00 00      	jne r1, r2, +0x226 <.text+0x55618>
   54608: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   54610: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   54618: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54620: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54628: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54630: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   54638: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54640: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   54650: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   54658: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   54660: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   54668: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   54670: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   54678: 7b 4a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r4
   54680: 7b 3a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r3
   54688: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   54690: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   54698: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   546a0: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   546a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   546b0: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   546b8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   546c0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   546c8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   546d0: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   546d8: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   546e0: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   546e8: 85 10 00 00 ff ff ff ff      	call -0x1
   546f0: 55 00 51 02 00 00 00 00      	jne r0, 0x0, +0x251 <.text+0x55860>
   546f8: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   54700: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   54708: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   54710: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   54718: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   54720: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   54728: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   54730: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   54738: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54740: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54748: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   54750: 5d 93 12 02 00 00 00 00      	jne r3, r9, +0x212 <.text+0x556c8>
   54758: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   54760: 5d 83 10 02 00 00 00 00      	jne r3, r8, +0x210 <.text+0x556c8>
   54768: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   54770: 5d 73 0e 02 00 00 00 00      	jne r3, r7, +0x20e <.text+0x556c8>
   54778: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   54780: 5d 62 0c 02 00 00 00 00      	jne r2, r6, +0x20c <.text+0x556c8>
   54788: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54790: 15 01 15 02 00 00 00 00      	jeq r1, 0x0, +0x215 <.text+0x55720>
   54798: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   547a0: 79 16 20 00 00 00 00 00      	ldxdw r6, [r1 + 0x20]
   547a8: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   547b0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   547b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   547c0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   547c8: 85 10 00 00 b8 69 ff ff      	call -0x9648
   547d0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   547d8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   547e0: 79 62 18 00 00 00 00 00      	ldxdw r2, [r6 + 0x18]
   547e8: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   547f0: 5d 34 11 02 00 00 00 00      	jne r4, r3, +0x211 <.text+0x55760>
   547f8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54800: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   54808: 5d 34 0e 02 00 00 00 00      	jne r4, r3, +0x20e <.text+0x55760>
   54810: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   54818: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   54820: 5d 34 0b 02 00 00 00 00      	jne r4, r3, +0x20b <.text+0x55760>
   54828: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54830: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   54838: 5d 12 08 02 00 00 00 00      	jne r2, r1, +0x208 <.text+0x55760>
   54840: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   54848: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   54850: 85 10 00 00 d1 66 ff ff      	call -0x992f
   54858: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   54860: 79 19 60 00 00 00 00 00      	ldxdw r9, [r1 + 0x60]
   54868: 79 18 58 00 00 00 00 00      	ldxdw r8, [r1 + 0x58]
   54870: 79 17 50 00 00 00 00 00      	ldxdw r7, [r1 + 0x50]
   54878: 79 16 48 00 00 00 00 00      	ldxdw r6, [r1 + 0x48]
   54880: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   54888: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54890: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   54898: 7b 2a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r2
   548a0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   548a8: 7b 2a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r2
   548b0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   548b8: 7b 2a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r2
   548c0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   548c8: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   548d0: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   548d8: 5d 16 ff 01 00 00 00 00      	jne r6, r1, +0x1ff <.text+0x557b8>
   548e0: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   548e8: 5d 17 fd 01 00 00 00 00      	jne r7, r1, +0x1fd <.text+0x557b8>
   548f0: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   548f8: 5d 18 fb 01 00 00 00 00      	jne r8, r1, +0x1fb <.text+0x557b8>
   54900: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   54908: 5d 19 f9 01 00 00 00 00      	jne r9, r1, +0x1f9 <.text+0x557b8>
   54910: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   54918: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   54920: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   54928: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   54930: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   54938: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   54940: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   54948: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54950: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   54958: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54960: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   54968: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   54970: 07 08 00 00 00 ff ff ff      	add64 r8, -0x100
   54978: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   54980: 85 10 00 00 81 69 ff ff      	call -0x967f
   54988: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   54990: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54998: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   549a0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   549a8: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   549b0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   549b8: 7b 2a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r2
   549c0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   549c8: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   549d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   549d8: 07 01 00 00 58 fe ff ff      	add64 r1, -0x1a8
   549e0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   549e8: 07 02 00 00 38 fe ff ff      	add64 r2, -0x1c8
   549f0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   549f8: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   54a00: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   54a08: 07 04 00 00 68 fd ff ff      	add64 r4, -0x298
   54a10: 85 10 00 00 4d 82 00 00      	call 0x824d
   54a18: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   54a20: 85 10 00 00 97 66 ff ff      	call -0x9969
   54a28: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   54a30: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   54a38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54a40: 79 29 18 00 00 00 00 00      	ldxdw r9, [r2 + 0x18]
   54a48: 79 28 10 00 00 00 00 00      	ldxdw r8, [r2 + 0x10]
   54a50: 79 27 08 00 00 00 00 00      	ldxdw r7, [r2 + 0x8]
   54a58: 79 26 00 00 00 00 00 00      	ldxdw r6, [r2 + 0x0]
   54a60: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   54a68: 5d 26 ee 01 00 00 00 00      	jne r6, r2, +0x1ee <.text+0x558c0>
   54a70: 79 a2 60 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a0]
   54a78: 5d 27 ec 01 00 00 00 00      	jne r7, r2, +0x1ec <.text+0x558c0>
   54a80: 79 a2 68 fe 00 00 00 00      	ldxdw r2, [r10 - 0x198]
   54a88: 5d 28 ea 01 00 00 00 00      	jne r8, r2, +0x1ea <.text+0x558c0>
   54a90: 79 a2 70 fe 00 00 00 00      	ldxdw r2, [r10 - 0x190]
   54a98: 5d 29 e8 01 00 00 00 00      	jne r9, r2, +0x1e8 <.text+0x558c0>
   54aa0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54aa8: 15 01 fc 01 00 00 00 00      	jeq r1, 0x0, +0x1fc <.text+0x55970>
   54ab0: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   54ab8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   54ac0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   54ac8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   54ad0: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   54ad8: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   54ae8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   54af0: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   54af8: 85 10 00 00 ff ff ff ff      	call -0x1
   54b00: 55 00 cf 01 00 00 00 00      	jne r0, 0x0, +0x1cf <.text+0x55860>
   54b08: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   54b10: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   54b18: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   54b20: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   54b28: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   54b30: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   54b38: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   54b40: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   54b48: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54b50: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54b58: 5d 62 ee 01 00 00 00 00      	jne r2, r6, +0x1ee <.text+0x559b0>
   54b60: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   54b68: 5d 72 ec 01 00 00 00 00      	jne r2, r7, +0x1ec <.text+0x559b0>
   54b70: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54b78: 5d 82 ea 01 00 00 00 00      	jne r2, r8, +0x1ea <.text+0x559b0>
   54b80: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54b88: 5d 91 e8 01 00 00 00 00      	jne r1, r9, +0x1e8 <.text+0x559b0>
   54b90: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   54b98: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54ba0: 15 01 fd 01 00 00 00 00      	jeq r1, 0x0, +0x1fd <.text+0x55a70>
   54ba8: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   54bb0: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   54bb8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54bc0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54bc8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54bd0: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   54bd8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54be0: 18 05 00 00 1a dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc1a
   54bf0: 7b 5a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r5
   54bf8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   54c00: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   54c08: 7b 5a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r5
   54c10: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   54c18: 7b 4a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r4
   54c20: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   54c28: 7b 2a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r2
   54c30: 7a 0a 80 fe 0d 00 00 00      	stdw [r10 - 0x180], 0xd
   54c38: 7a 0a 90 fe 20 00 00 00      	stdw [r10 - 0x170], 0x20
   54c40: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   54c50: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   54c58: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   54c68: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   54c70: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   54c80: 7b 1a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r1
   54c88: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   54c98: 7b 1a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r1
   54ca0: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   54ca8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   54cb0: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   54cb8: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   54cc0: 07 03 00 00 68 fd ff ff      	add64 r3, -0x298
   54cc8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   54cd0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   54cd8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   54ce0: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   54ce8: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   54cf0: 85 10 00 00 ff ff ff ff      	call -0x1
   54cf8: 55 00 90 01 00 00 00 00      	jne r0, 0x0, +0x190 <.text+0x55860>
   54d00: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   54d08: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   54d10: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   54d18: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   54d20: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   54d28: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   54d30: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   54d38: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   54d40: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54d48: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54d50: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   54d58: 5d 93 ce 01 00 00 00 00      	jne r3, r9, +0x1ce <.text+0x55ab0>
   54d60: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   54d68: 5d 83 cc 01 00 00 00 00      	jne r3, r8, +0x1cc <.text+0x55ab0>
   54d70: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   54d78: 5d 73 ca 01 00 00 00 00      	jne r3, r7, +0x1ca <.text+0x55ab0>
   54d80: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   54d88: 5d 62 c8 01 00 00 00 00      	jne r2, r6, +0x1c8 <.text+0x55ab0>
   54d90: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54d98: 15 01 d1 01 00 00 00 00      	jeq r1, 0x0, +0x1d1 <.text+0x55b08>
   54da0: 79 a1 90 fc 00 00 00 00      	ldxdw r1, [r10 - 0x370]
   54da8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   54db0: 15 01 d5 01 00 00 00 00      	jeq r1, 0x0, +0x1d5 <.text+0x55b40>
   54db8: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   54dc0: 79 16 20 00 00 00 00 00      	ldxdw r6, [r1 + 0x20]
   54dc8: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   54dd0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   54dd8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   54de0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   54de8: 85 10 00 00 f4 68 ff ff      	call -0x970c
   54df0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   54df8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   54e00: 79 62 18 00 00 00 00 00      	ldxdw r2, [r6 + 0x18]
   54e08: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   54e10: 5d 34 4d 01 00 00 00 00      	jne r4, r3, +0x14d <.text+0x55760>
   54e18: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54e20: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   54e28: 5d 34 4a 01 00 00 00 00      	jne r4, r3, +0x14a <.text+0x55760>
   54e30: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   54e38: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   54e40: 5d 34 47 01 00 00 00 00      	jne r4, r3, +0x147 <.text+0x55760>
   54e48: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54e50: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   54e58: 5d 12 44 01 00 00 00 00      	jne r2, r1, +0x144 <.text+0x55760>
   54e60: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   54e68: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   54e70: 85 10 00 00 0d 66 ff ff      	call -0x99f3
   54e78: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   54e80: 79 19 60 00 00 00 00 00      	ldxdw r9, [r1 + 0x60]
   54e88: 79 18 58 00 00 00 00 00      	ldxdw r8, [r1 + 0x58]
   54e90: 79 17 50 00 00 00 00 00      	ldxdw r7, [r1 + 0x50]
   54e98: 7b 1a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r1
   54ea0: 79 16 48 00 00 00 00 00      	ldxdw r6, [r1 + 0x48]
   54ea8: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   54eb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54eb8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54ec0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   54ec8: 7b 2a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r2
   54ed0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54ed8: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   54ee0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   54ee8: 7b 2a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r2
   54ef0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54ef8: 7b 1a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r1
   54f00: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   54f08: 5d 16 b1 01 00 00 00 00      	jne r6, r1, +0x1b1 <.text+0x55b78>
   54f10: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   54f18: 5d 17 af 01 00 00 00 00      	jne r7, r1, +0x1af <.text+0x55b78>
   54f20: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   54f28: 5d 18 ad 01 00 00 00 00      	jne r8, r1, +0x1ad <.text+0x55b78>
   54f30: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   54f38: 5d 19 ab 01 00 00 00 00      	jne r9, r1, +0x1ab <.text+0x55b78>
   54f40: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   54f48: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   54f50: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   54f58: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   54f60: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   54f68: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   54f70: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   54f78: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   54f80: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   54f88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   54f90: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   54f98: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   54fa0: 07 08 00 00 00 ff ff ff      	add64 r8, -0x100
   54fa8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   54fb0: 85 10 00 00 bb 68 ff ff      	call -0x9745
   54fb8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   54fc0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   54fc8: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   54fd0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   54fd8: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   54fe0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   54fe8: 7b 2a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r2
   54ff0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   54ff8: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   55000: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   55008: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   55010: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   55018: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   55020: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   55028: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   55030: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   55038: 07 04 00 00 68 fd ff ff      	add64 r4, -0x298
   55040: 85 10 00 00 87 81 00 00      	call 0x8187
   55048: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   55050: 85 10 00 00 d1 65 ff ff      	call -0x9a2f
   55058: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   55060: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   55068: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   55070: 79 29 18 00 00 00 00 00      	ldxdw r9, [r2 + 0x18]
   55078: 79 28 10 00 00 00 00 00      	ldxdw r8, [r2 + 0x10]
   55080: 79 27 08 00 00 00 00 00      	ldxdw r7, [r2 + 0x8]
   55088: 79 26 00 00 00 00 00 00      	ldxdw r6, [r2 + 0x0]
   55090: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   55098: 5d 26 94 01 00 00 00 00      	jne r6, r2, +0x194 <.text+0x55c20>
   550a0: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   550a8: 5d 27 92 01 00 00 00 00      	jne r7, r2, +0x192 <.text+0x55c20>
   550b0: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   550b8: 5d 28 90 01 00 00 00 00      	jne r8, r2, +0x190 <.text+0x55c20>
   550c0: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   550c8: 5d 29 8e 01 00 00 00 00      	jne r9, r2, +0x18e <.text+0x55c20>
   550d0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   550d8: 15 01 a1 01 00 00 00 00      	jeq r1, 0x0, +0x1a1 <.text+0x55cc8>
   550e0: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   550e8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   550f0: 15 01 a6 01 00 00 00 00      	jeq r1, 0x0, +0x1a6 <.text+0x55d08>
   550f8: 79 a1 88 fc 00 00 00 00      	ldxdw r1, [r10 - 0x378]
   55100: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55108: 79 19 18 00 00 00 00 00      	ldxdw r9, [r1 + 0x18]
   55110: 79 18 10 00 00 00 00 00      	ldxdw r8, [r1 + 0x10]
   55118: 79 17 08 00 00 00 00 00      	ldxdw r7, [r1 + 0x8]
   55120: 79 16 00 00 00 00 00 00      	ldxdw r6, [r1 + 0x0]
   55128: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   55138: 5d 16 a4 01 00 00 00 00      	jne r6, r1, +0x1a4 <.text+0x55d40>
   55140: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   55150: 5d 17 a1 01 00 00 00 00      	jne r7, r1, +0x1a1 <.text+0x55d40>
   55158: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   55168: 5d 18 9e 01 00 00 00 00      	jne r8, r1, +0x19e <.text+0x55d40>
   55170: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   55180: 5d 19 9b 01 00 00 00 00      	jne r9, r1, +0x19b <.text+0x55d40>
   55188: 79 a1 80 fc 00 00 00 00      	ldxdw r1, [r10 - 0x380]
   55190: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   55198: 15 01 b1 01 00 00 00 00      	jeq r1, 0x0, +0x1b1 <.text+0x55e08>
   551a0: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   551a8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   551b0: 15 01 b6 01 00 00 00 00      	jeq r1, 0x0, +0x1b6 <.text+0x55e48>
   551b8: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   551c0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   551c8: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   551d0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   551d8: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   551e0: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   551f0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   551f8: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   55200: 85 10 00 00 ff ff ff ff      	call -0x1
   55208: 55 00 ee 00 00 00 00 00      	jne r0, 0x0, +0xee <.text+0x55860>
   55210: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   55218: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   55220: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   55228: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   55230: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   55238: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   55240: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   55248: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   55250: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55258: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   55260: 5d 62 a8 01 00 00 00 00      	jne r2, r6, +0x1a8 <.text+0x55e88>
   55268: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   55270: 5d 72 a6 01 00 00 00 00      	jne r2, r7, +0x1a6 <.text+0x55e88>
   55278: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   55280: 5d 82 a4 01 00 00 00 00      	jne r2, r8, +0x1a4 <.text+0x55e88>
   55288: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   55290: 5d 91 a2 01 00 00 00 00      	jne r1, r9, +0x1a2 <.text+0x55e88>
   55298: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   552a0: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   552a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   552b0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   552b8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   552c0: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   552c8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   552d0: 18 05 00 00 68 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xad768
   552e0: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   552e8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   552f0: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   552f8: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   55300: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   55308: 7b 4a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r4
   55310: 7b 3a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r3
   55318: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   55320: 7a 0a e0 fe 10 00 00 00      	stdw [r10 - 0x120], 0x10
   55328: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   55330: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   55338: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   55340: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   55348: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   55350: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   55358: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   55360: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   55368: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   55370: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   55378: 85 10 00 00 ff ff ff ff      	call -0x1
   55380: 55 00 bf 00 00 00 00 00      	jne r0, 0x0, +0xbf <.text+0x55860>
   55388: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   55390: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   55398: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   553a0: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   553a8: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   553b0: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   553b8: 73 12 05 00 00 00 00 00      	stxb [r2 + 0x5], r1
   553c0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   553c8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   553d0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   553d8: 5d 62 84 01 00 00 00 00      	jne r2, r6, +0x184 <.text+0x55ee0>
   553e0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   553e8: 5d 72 82 01 00 00 00 00      	jne r2, r7, +0x182 <.text+0x55ee0>
   553f0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   553f8: 5d 82 80 01 00 00 00 00      	jne r2, r8, +0x180 <.text+0x55ee0>
   55400: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   55408: 5d 91 7e 01 00 00 00 00      	jne r1, r9, +0x17e <.text+0x55ee0>
   55410: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   55418: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   55420: 15 01 86 01 00 00 00 00      	jeq r1, 0x0, +0x186 <.text+0x55f38>
   55428: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   55430: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   55438: 7b 21 b0 00 00 00 00 00      	stxdw [r1 + 0xb0], r2
   55440: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   55448: 7b 21 a8 00 00 00 00 00      	stxdw [r1 + 0xa8], r2
   55450: 79 a2 58 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a8]
   55458: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   55460: 79 a2 60 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a0]
   55468: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   55470: 79 a2 68 fc 00 00 00 00      	ldxdw r2, [r10 - 0x398]
   55478: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   55480: 79 a2 70 fc 00 00 00 00      	ldxdw r2, [r10 - 0x390]
   55488: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   55490: 79 a2 78 fc 00 00 00 00      	ldxdw r2, [r10 - 0x388]
   55498: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   554a0: 79 a2 80 fc 00 00 00 00      	ldxdw r2, [r10 - 0x380]
   554a8: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   554b0: 79 a2 88 fc 00 00 00 00      	ldxdw r2, [r10 - 0x378]
   554b8: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   554c0: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   554c8: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   554d0: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   554d8: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   554e0: 79 a2 48 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b8]
   554e8: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   554f0: 79 a2 90 fc 00 00 00 00      	ldxdw r2, [r10 - 0x370]
   554f8: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   55500: 79 a2 98 fc 00 00 00 00      	ldxdw r2, [r10 - 0x368]
   55508: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   55510: 79 a2 a0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x360]
   55518: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   55520: 79 a2 a8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x358]
   55528: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   55530: 79 a2 b0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x350]
   55538: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   55540: 79 a2 b8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x348]
   55548: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   55550: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   55558: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   55560: 79 a2 c8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x338]
   55568: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   55570: 79 a2 d0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x330]
   55578: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   55580: 79 a2 c0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x340]
   55588: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   55590: 79 a2 00 fd 00 00 00 00      	ldxdw r2, [r10 - 0x300]
   55598: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   555a0: 05 00 b2 fb 00 00 00 00      	ja -0x44e <.text+0x53218>
   555a8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   555b0: 85 10 00 00 06 8a 00 00      	call 0x8a06
   555b8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   555c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   555c8: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   555d8: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   555e0: 85 10 00 00 e5 5c ff ff      	call -0xa31b
   555e8: 05 00 1c 00 00 00 00 00      	ja +0x1c <.text+0x555b0>
   555f0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   555f8: 85 10 00 00 fd 89 00 00      	call 0x89fd
   55600: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55608: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55610: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   55620: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   55628: 85 10 00 00 dc 5c ff ff      	call -0xa324
   55630: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55638: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   55640: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55648: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55650: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   55658: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   55660: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   55668: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   55670: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   55678: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   55680: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   55688: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   55690: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   55698: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   556a0: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   556a8: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   556b0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   556b8: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   556c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   556c8: 85 10 00 00 65 84 00 00      	call 0x8465
   556d0: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   556d8: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   556e0: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   556e8: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   556f0: 05 00 88 fb 00 00 00 00      	ja -0x478 <.text+0x53218>
   556f8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55700: 85 10 00 00 dc 89 00 00      	call 0x89dc
   55708: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55710: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55718: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   55728: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   55730: 05 00 d5 ff 00 00 00 00      	ja -0x2b <.text+0x554c0>
   55738: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   55740: 85 10 00 00 d4 89 00 00      	call 0x89d4
   55748: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55750: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55758: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   55768: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   55770: 85 10 00 00 b3 5c ff ff      	call -0xa34d
   55778: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55780: 79 a1 18 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e8]
   55788: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   55790: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   55798: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   557a0: 7b 6a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r6
   557a8: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   557b0: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   557b8: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   557c0: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   557c8: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   557d0: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   557d8: 7b 9a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r9
   557e0: 05 00 d9 ff 00 00 00 00      	ja -0x27 <.text+0x55590>
   557e8: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   557f0: 85 10 00 00 be 89 00 00      	call 0x89be
   557f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55800: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55808: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   55818: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   55820: 85 10 00 00 9d 5c ff ff      	call -0xa363
   55828: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55830: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   55838: 05 00 c0 ff 00 00 00 00      	ja -0x40 <.text+0x55520>
   55840: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55848: 85 10 00 00 b3 89 00 00      	call 0x89b3
   55850: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55858: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55860: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   55870: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   55878: 05 00 ac ff 00 00 00 00      	ja -0x54 <.text+0x554c0>
   55880: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   55888: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   55890: 85 10 00 00 c9 64 ff ff      	call -0x9b37
   55898: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   558a0: 85 10 00 00 a8 89 00 00      	call 0x89a8
   558a8: 05 00 c4 ff 00 00 00 00      	ja -0x3c <.text+0x555b0>
   558b0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   558b8: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   558c0: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   558d0: 85 10 00 00 ee 9b 00 00      	call 0x9bee
   558d8: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   558e0: 85 10 00 00 a0 89 00 00      	call 0x89a0
   558e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   558f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   558f8: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   55908: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   55910: 85 10 00 00 7f 5c ff ff      	call -0xa381
   55918: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55920: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   55928: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   55930: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   55938: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   55940: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   55948: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   55950: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   55958: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   55960: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   55968: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   55970: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   55978: 05 00 20 00 00 00 00 00      	ja +0x20 <.text+0x55960>
   55980: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   55990: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   55998: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   559a0: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   559a8: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   559b0: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   559b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   559c0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   559c8: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   559d8: 85 10 00 00 d5 9d 00 00      	call 0x9dd5
   559e0: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   559e8: 85 10 00 00 7f 89 00 00      	call 0x897f
   559f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   559f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55a00: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   55a10: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   55a18: 85 10 00 00 5e 5c ff ff      	call -0xa3a2
   55a20: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55a28: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   55a30: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   55a38: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   55a40: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   55a48: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   55a50: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   55a58: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   55a60: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   55a68: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   55a70: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   55a78: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   55a80: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   55a88: 05 00 84 ff 00 00 00 00      	ja -0x7c <.text+0x55590>
   55a90: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55a98: 85 10 00 00 69 89 00 00      	call 0x8969
   55aa0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55aa8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55ab0: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   55ac0: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   55ac8: 05 00 62 ff 00 00 00 00      	ja -0x9e <.text+0x554c0>
   55ad0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   55ad8: 85 10 00 00 61 89 00 00      	call 0x8961
   55ae0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55ae8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55af0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   55b00: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   55b08: 85 10 00 00 40 5c ff ff      	call -0xa3c0
   55b10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55b18: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   55b20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55b28: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   55b30: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   55b38: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   55b40: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   55b48: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   55b50: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   55b58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   55b60: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   55b68: 7b 9a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r9
   55b70: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   55b78: 7b 7a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r7
   55b80: 7b 6a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r6
   55b88: 05 00 64 ff 00 00 00 00      	ja -0x9c <.text+0x55590>
   55b90: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55b98: 85 10 00 00 49 89 00 00      	call 0x8949
   55ba0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55ba8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55bb0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   55bc0: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   55bc8: 05 00 42 ff 00 00 00 00      	ja -0xbe <.text+0x554c0>
   55bd0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   55bd8: 85 10 00 00 41 89 00 00      	call 0x8941
   55be0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55be8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55bf0: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   55c00: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   55c08: 85 10 00 00 20 5c ff ff      	call -0xa3e0
   55c10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55c18: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   55c20: 05 00 43 ff 00 00 00 00      	ja -0xbd <.text+0x55520>
   55c28: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55c30: 85 10 00 00 36 89 00 00      	call 0x8936
   55c38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55c40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55c48: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   55c58: 05 00 59 ff 00 00 00 00      	ja -0xa7 <.text+0x55608>
   55c60: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55c68: 85 10 00 00 2f 89 00 00      	call 0x892f
   55c70: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55c78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55c80: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   55c90: 05 00 52 ff 00 00 00 00      	ja -0xae <.text+0x55608>
   55c98: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   55ca0: 85 10 00 00 28 89 00 00      	call 0x8928
   55ca8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55cb0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55cb8: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   55cc8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   55cd0: 85 10 00 00 07 5c ff ff      	call -0xa3f9
   55cd8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55ce0: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   55ce8: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   55cf0: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   55cf8: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   55d00: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   55d08: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   55d10: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   55d18: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   55d20: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   55d28: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   55d30: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   55d38: 05 00 a8 ff 00 00 00 00      	ja -0x58 <.text+0x55960>
   55d40: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   55d48: 85 10 00 00 13 89 00 00      	call 0x8913
   55d50: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55d58: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55d60: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   55d70: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   55d78: 85 10 00 00 f2 5b ff ff      	call -0xa40e
   55d80: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55d88: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   55d90: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   55d98: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   55da0: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   55da8: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   55db0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   55db8: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   55dc0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   55dc8: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   55dd0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   55dd8: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   55de0: 05 00 93 ff 00 00 00 00      	ja -0x6d <.text+0x55960>
   55de8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55df0: 85 10 00 00 fe 88 00 00      	call 0x88fe
   55df8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55e00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55e08: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   55e18: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   55e20: 05 00 f7 fe 00 00 00 00      	ja -0x109 <.text+0x554c0>
   55e28: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55e30: 85 10 00 00 f6 88 00 00      	call 0x88f6
   55e38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55e40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55e48: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   55e58: 05 00 19 ff 00 00 00 00      	ja -0xe7 <.text+0x55608>
   55e60: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   55e68: 85 10 00 00 ef 88 00 00      	call 0x88ef
   55e70: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55e78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55e80: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   55e90: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   55e98: 85 10 00 00 ce 5b ff ff      	call -0xa432
   55ea0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55ea8: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   55eb8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   55ec0: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   55ec8: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   55ed0: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   55ed8: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   55ee0: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   55ef0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   55ef8: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   55f08: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   55f10: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   55f20: 05 00 6b ff 00 00 00 00      	ja -0x95 <.text+0x55960>
   55f28: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55f30: 85 10 00 00 d6 88 00 00      	call 0x88d6
   55f38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55f40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55f48: 18 03 00 00 52 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd52
   55f58: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   55f60: 05 00 cf fe 00 00 00 00      	ja -0x131 <.text+0x554c0>
   55f68: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   55f70: 85 10 00 00 ce 88 00 00      	call 0x88ce
   55f78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55f80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55f88: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   55f98: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   55fa0: 05 00 c7 fe 00 00 00 00      	ja -0x139 <.text+0x554c0>
   55fa8: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   55fb0: 85 10 00 00 c6 88 00 00      	call 0x88c6
   55fb8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55fc0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   55fc8: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   55fd8: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   55fe0: 85 10 00 00 a5 5b ff ff      	call -0xa45b
   55fe8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   55ff0: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   55ff8: 05 00 64 ff 00 00 00 00      	ja -0x9c <.text+0x55a00>
   56000: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   56008: 85 10 00 00 bb 88 00 00      	call 0x88bb
   56010: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   56018: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   56020: 18 03 00 00 98 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad798
   56030: b7 04 00 00 10 00 00 00      	mov64 r4, 0x10
   56038: 85 10 00 00 9a 5b ff ff      	call -0xa466
   56040: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   56048: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   56050: 05 00 59 ff 00 00 00 00      	ja -0xa7 <.text+0x55a00>
   56058: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   56060: 85 10 00 00 b0 88 00 00      	call 0x88b0
   56068: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   56070: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   56078: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   56088: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   56090: 05 00 a9 fe 00 00 00 00      	ja -0x157 <.text+0x554c0>
   56f08: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   56f10: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   56f18: bf 38 00 00 00 00 00 00      	mov64 r8, r3
   56f20: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   56f28: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   56f30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   56f38: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   56f40: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   56f48: 85 10 00 00 1c 66 ff ff      	call -0x99e4
   56f50: 79 a6 10 fd 00 00 00 00      	ldxdw r6, [r10 - 0x2f0]
   56f58: 79 a9 08 fd 00 00 00 00      	ldxdw r9, [r10 - 0x2f8]
   56f60: 55 09 2e 00 02 00 00 00      	jne r9, 0x2, +0x2e <.text+0x56fb8>
   56f68: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   56f70: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   56f78: 79 79 08 f0 00 00 00 00      	ldxdw r9, [r7 - 0xff8]
   56f80: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   56f88: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   56f90: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   56f98: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   56fa0: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   56fa8: 85 10 00 00 64 66 ff ff      	call -0x999c
   56fb0: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   56fb8: 55 01 54 00 02 00 00 00      	jne r1, 0x2, +0x54 <.text+0x57140>
   56fc0: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   56fc8: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   56fd0: 85 10 00 00 c3 58 00 00      	call 0x58c3
   56fd8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   56fe8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   56ff0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   56ff8: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   57000: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   57008: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57010: 2d 21 61 00 00 00 00 00      	jgt r1, r2, +0x61 <.text+0x57200>
   57018: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   57020: 15 04 60 00 00 00 00 00      	jeq r4, 0x0, +0x60 <.text+0x57208>
   57028: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   57038: 15 02 61 00 00 00 00 00      	jeq r2, 0x0, +0x61 <.text+0x57228>
   57040: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   57048: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57058: 15 06 60 00 01 00 00 00      	jeq r6, 0x1, +0x60 <.text+0x57240>
   57060: bd 21 60 00 00 00 00 00      	jle r1, r2, +0x60 <.text+0x57248>
   57068: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   57078: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   57080: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   57090: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   57098: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   570a8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   570b0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   570b8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   570c0: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   570c8: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   570d0: 05 00 f2 00 00 00 00 00      	ja +0xf2 <.text+0x57748>
   570d8: 85 10 00 00 a2 58 00 00      	call 0x58a2
   570e0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   570f0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   570f8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   57100: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   57108: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   57110: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57118: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <.text+0x57080>
   57120: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   57128: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <.text+0x57088>
   57130: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   57140: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x570a8>
   57148: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   57150: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   57158: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   57160: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57170: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <.text+0x570d0>
   57178: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   57180: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   57188: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   57198: 85 10 00 00 d5 98 00 00      	call 0x98d5
   571a0: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <.text+0x57010>
   571a8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   571b0: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   571c0: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x57028>
   571c8: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   571d0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   571d8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   571e8: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <.text+0x57058>
   571f0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   57200: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   57208: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   57210: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   57218: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   57220: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   57228: 7a 06 18 00 06 00 00 00      	stdw [r6 + 0x18], 0x6
   57230: 7a 06 08 00 06 00 00 00      	stdw [r6 + 0x8], 0x6
   57238: 7a 06 00 00 01 00 00 00      	stdw [r6 + 0x0], 0x1
   57240: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   57248: 7b 61 10 00 00 00 00 00      	stxdw [r1 + 0x10], r6
   57250: 7b 91 08 00 00 00 00 00      	stxdw [r1 + 0x8], r9
   57258: 05 00 c5 00 00 00 00 00      	ja +0xc5 <.text+0x57768>
   57260: 85 10 00 00 71 58 00 00      	call 0x5871
   57268: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   57278: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   57280: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57288: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   57290: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   57298: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   572a0: 2d 13 1d 00 00 00 00 00      	jgt r3, r1, +0x1d <.text+0x57270>
   572a8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   572b0: 7b 7a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r7
   572b8: 15 04 1c 00 00 00 00 00      	jeq r4, 0x0, +0x1c <.text+0x57280>
   572c0: 18 07 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f00
   572d0: 15 01 1d 00 00 00 00 00      	jeq r1, 0x0, +0x1d <.text+0x572a0>
   572d8: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   572e0: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   572e8: 7b 9a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r9
   572f0: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   57300: 2d 17 1b 00 00 00 00 00      	jgt r7, r1, +0x1b <.text+0x572c0>
   57308: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   57310: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   57318: 85 10 00 00 a9 98 00 00      	call 0x98a9
   57320: 55 04 a0 ff 00 00 00 00      	jne r4, 0x0, -0x60 <.text+0x56f08>
   57328: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57330: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   57340: 55 02 9f ff 00 00 00 00      	jne r2, 0x0, -0x61 <.text+0x56f20>
   57348: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57358: 55 06 a0 ff 01 00 00 00      	jne r6, 0x1, -0x60 <.text+0x56f40>
   57360: 2d 21 a0 ff 00 00 00 00      	jgt r1, r2, -0x60 <.text+0x56f48>
   57368: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   57370: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   57378: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   57388: 85 10 00 00 97 98 00 00      	call 0x9897
   57390: 7b 7a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r7
   57398: 55 04 e4 ff 00 00 00 00      	jne r4, 0x0, -0x1c <.text+0x571a0>
   573a0: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   573a8: 18 07 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f00
   573b8: 55 01 e3 ff 00 00 00 00      	jne r1, 0x0, -0x1d <.text+0x571b8>
   573c0: 7b 9a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r9
   573c8: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   573d8: bd 17 e5 ff 00 00 00 00      	jle r7, r1, -0x1b <.text+0x571e8>
   573e0: 18 09 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r9, 0x300000000
   573f0: 7b 79 00 00 00 00 00 00      	stxdw [r9 + 0x0], r7
   573f8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   57400: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   57408: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   57410: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   57418: 85 10 00 00 2d a6 00 00      	call 0xa62d
   57420: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57428: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   57430: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57438: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57440: 85 10 00 00 9e 65 ff ff      	call -0x9a62
   57448: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   57450: 55 01 1f 00 02 00 00 00      	jne r1, 0x2, +0x1f <.text+0x57430>
   57458: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   57460: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   57468: 85 10 00 00 30 58 00 00      	call 0x5830
   57470: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   57478: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   57480: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   57488: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   57490: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57498: 2d 21 2a 00 00 00 00 00      	jgt r1, r2, +0x2a <.text+0x574d0>
   574a0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   574a8: 15 04 29 00 00 00 00 00      	jeq r4, 0x0, +0x29 <.text+0x574d8>
   574b0: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   574c0: 15 02 2a 00 00 00 00 00      	jeq r2, 0x0, +0x2a <.text+0x574f8>
   574c8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   574d0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   574e0: 15 06 29 00 01 00 00 00      	jeq r6, 0x1, +0x29 <.text+0x57510>
   574e8: bd 21 29 00 00 00 00 00      	jle r1, r2, +0x29 <.text+0x57518>
   574f0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   57500: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   57508: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   57518: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   57520: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   57528: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   57530: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   57538: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   57540: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   57548: 05 00 63 00 00 00 00 00      	ja +0x63 <.text+0x57748>
   57550: 85 10 00 00 13 58 00 00      	call 0x5813
   57558: 79 95 00 00 00 00 00 00      	ldxdw r5, [r9 + 0x0]
   57560: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   57568: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   57570: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   57578: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57580: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x57540>
   57588: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   57590: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x57548>
   57598: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   575a8: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x57568>
   575b0: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   575b8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   575c0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   575d0: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x57580>
   575d8: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   575e0: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   575e8: 85 10 00 00 4f 98 00 00      	call 0x984f
   575f0: 55 04 d7 ff 00 00 00 00      	jne r4, 0x0, -0x29 <.text+0x57390>
   575f8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57600: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   57610: 55 02 d6 ff 00 00 00 00      	jne r2, 0x0, -0x2a <.text+0x573a8>
   57618: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57628: 55 06 d7 ff 01 00 00 00      	jne r6, 0x1, -0x29 <.text+0x573c8>
   57630: 2d 21 d7 ff 00 00 00 00      	jgt r1, r2, -0x29 <.text+0x573d0>
   57638: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   57640: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   57648: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   57658: 85 10 00 00 3d 98 00 00      	call 0x983d
   57660: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x57478>
   57668: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   57670: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   57680: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x57490>
   57688: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57698: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x574b8>
   576a0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   576b0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   576b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   576c0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   576c8: 7b 1a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r1
   576d0: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   576d8: 85 10 00 00 d5 a5 00 00      	call 0xa5d5
   576e0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   576e8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x57608>
   576f0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   576f8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   57700: 79 89 00 00 00 00 00 00      	ldxdw r9, [r8 + 0x0]
   57708: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   57710: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   57718: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   57720: 05 00 04 00 00 00 00 00      	ja +0x4 <.text+0x57628>
   57728: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   57730: 85 10 00 00 d6 85 00 00      	call 0x85d6
   57738: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   57740: 55 00 a0 00 02 00 00 00      	jne r0, 0x2, +0xa0 <.text+0x57b28>
   57748: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57750: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   57758: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57760: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57768: 85 10 00 00 b0 56 ff ff      	call -0xa950
   57770: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   57778: 55 01 23 00 02 00 00 00      	jne r1, 0x2, +0x23 <.text+0x57778>
   57780: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   57788: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   57790: 85 10 00 00 cb 57 00 00      	call 0x57cb
   57798: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   577a8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   577b0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   577b8: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   577c0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   577c8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   577d0: 2d 21 2f 00 00 00 00 00      	jgt r1, r2, +0x2f <.text+0x57830>
   577d8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   577e0: 15 04 2e 00 00 00 00 00      	jeq r4, 0x0, +0x2e <.text+0x57838>
   577e8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   577f8: 15 02 2f 00 00 00 00 00      	jeq r2, 0x0, +0x2f <.text+0x57858>
   57800: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   57808: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57818: 15 06 2e 00 01 00 00 00      	jeq r6, 0x1, +0x2e <.text+0x57870>
   57820: bd 21 2e 00 00 00 00 00      	jle r1, r2, +0x2e <.text+0x57878>
   57828: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   57838: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   57840: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   57848: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   57850: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   57858: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   57860: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   57868: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   57870: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   57878: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   57880: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   57888: 7a 01 00 00 00 00 00 00      	stdw [r1 + 0x0], 0x0
   57890: 95 00 00 00 00 00 00 00      	exit
   57898: 85 10 00 00 aa 57 00 00      	call 0x57aa
   578a0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   578b0: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   578b8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   578c0: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   578c8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   578d0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   578d8: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x578a0>
   578e0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   578e8: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x578a8>
   578f0: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   57900: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x578c8>
   57908: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   57910: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   57918: 7b 7a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r7
   57920: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57930: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x578e8>
   57938: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   57940: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   57948: 85 10 00 00 e3 97 00 00      	call 0x97e3
   57950: 55 04 d2 ff 00 00 00 00      	jne r4, 0x0, -0x2e <.text+0x576c8>
   57958: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57960: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   57970: 55 02 d1 ff 00 00 00 00      	jne r2, 0x0, -0x2f <.text+0x576e0>
   57978: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57988: 55 06 d2 ff 01 00 00 00      	jne r6, 0x1, -0x2e <.text+0x57700>
   57990: 2d 21 d2 ff 00 00 00 00      	jgt r1, r2, -0x2e <.text+0x57708>
   57998: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   579a0: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   579a8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   579b8: 85 10 00 00 d1 97 00 00      	call 0x97d1
   579c0: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x577d0>
   579c8: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   579d0: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   579e0: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x577e8>
   579e8: 7b 7a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r7
   579f0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57a00: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x57818>
   57a08: 18 07 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300000000
   57a18: 7b 17 00 00 00 00 00 00      	stxdw [r7 + 0x0], r1
   57a20: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   57a28: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   57a30: 7b 1a c0 fc 00 00 00 00      	stxdw [r10 - 0x340], r1
   57a38: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   57a40: 85 10 00 00 68 a5 00 00      	call 0xa568
   57a48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57a50: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   57a58: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57a60: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57a68: 85 10 00 00 61 56 ff ff      	call -0xa99f
   57a70: 61 a1 b0 ff 00 00 00 00      	ldxw r1, [r10 - 0x50]
   57a78: 55 01 0b 00 02 00 00 00      	jne r1, 0x2, +0xb <.text+0x579b8>
   57a80: 79 a2 08 ff 00 00 00 00      	ldxdw r2, [r10 - 0xf8]
   57a88: 79 a1 00 ff 00 00 00 00      	ldxdw r1, [r10 - 0x100]
   57a90: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   57aa0: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   57aa8: 85 10 00 00 4c 58 ff ff      	call -0xa7b4
   57ab0: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   57ab8: 15 00 27 00 02 00 00 00      	jeq r0, 0x2, +0x27 <.text+0x57ad8>
   57ac0: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   57ac8: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   57ad0: 05 00 79 01 00 00 00 00      	ja +0x179 <.text+0x58580>
   57ad8: 85 10 00 00 62 57 00 00      	call 0x5762
   57ae0: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   57ae8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57af0: 07 03 00 00 28 ff ff ff      	add64 r3, -0xd8
   57af8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   57b00: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57b08: 2d 13 0d 00 00 00 00 00      	jgt r3, r1, +0xd <.text+0x57a58>
   57b10: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   57b18: 15 04 0c 00 00 00 00 00      	jeq r4, 0x0, +0xc <.text+0x57a60>
   57b20: 18 07 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f28
   57b30: 15 01 0d 00 00 00 00 00      	jeq r1, 0x0, +0xd <.text+0x57a80>
   57b38: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   57b40: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   57b48: 18 01 00 00 08 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000008
   57b58: 3d 17 0b 00 00 00 00 00      	jge r7, r1, +0xb <.text+0x57a98>
   57b60: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   57b68: b7 02 00 00 d8 00 00 00      	mov64 r2, 0xd8
   57b70: 85 10 00 00 9e 97 00 00      	call 0x979e
   57b78: 55 04 f4 ff 00 00 00 00      	jne r4, 0x0, -0xc <.text+0x57a00>
   57b80: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   57b88: 18 07 00 00 28 7f 00 00 00 00 00 00 03 00 00 00      	lddw r7, 0x300007f28
   57b98: 55 01 f3 ff 00 00 00 00      	jne r1, 0x0, -0xd <.text+0x57a18>
   57ba0: 18 01 00 00 08 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000008
   57bb0: ad 17 f5 ff 00 00 00 00      	jlt r7, r1, -0xb <.text+0x57a40>
   57bb8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   57bc8: 7b 71 00 00 00 00 00 00      	stxdw [r1 + 0x0], r7
   57bd0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   57bd8: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   57be0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   57be8: b7 03 00 00 d8 00 00 00      	mov64 r3, 0xd8
   57bf0: 85 10 00 00 32 a5 00 00      	call 0xa532
   57bf8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57c00: 07 01 00 00 18 fd ff ff      	add64 r1, -0x2e8
   57c08: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57c10: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57c18: 85 10 00 00 6a 65 ff ff      	call -0x9a96
   57c20: 79 a2 20 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2e0]
   57c28: 79 a1 18 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2e8]
   57c30: 55 01 38 00 02 00 00 00      	jne r1, 0x2, +0x38 <.text+0x57cd8>
   57c38: 7b 2a b8 fc 00 00 00 00      	stxdw [r10 - 0x348], r2
   57c40: 05 00 3c 00 00 00 00 00      	ja +0x3c <.text+0x57d08>
   57c48: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   57c50: 85 10 00 00 33 57 00 00      	call 0x5733
   57c58: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   57c68: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   57c70: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   57c78: 07 01 00 00 f7 ff ff ff      	add64 r1, -0x9
   57c80: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   57c88: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   57c90: 2d 21 11 00 00 00 00 00      	jgt r1, r2, +0x11 <.text+0x57c00>
   57c98: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   57ca0: 15 04 10 00 00 00 00 00      	jeq r4, 0x0, +0x10 <.text+0x57c08>
   57ca8: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   57cb8: bf 64 00 00 00 00 00 00      	mov64 r4, r6
   57cc0: 15 02 11 00 00 00 00 00      	jeq r2, 0x0, +0x11 <.text+0x57c30>
   57cc8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   57cd0: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   57cd8: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   57ce0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57cf0: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <.text+0x57c58>
   57cf8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   57d00: b7 02 00 00 09 00 00 00      	mov64 r2, 0x9
   57d08: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   57d18: 85 10 00 00 65 97 00 00      	call 0x9765
   57d20: 55 04 f0 ff 00 00 00 00      	jne r4, 0x0, -0x10 <.text+0x57b88>
   57d28: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   57d30: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   57d40: bf 64 00 00 00 00 00 00      	mov64 r4, r6
   57d48: 55 02 ef ff 00 00 00 00      	jne r2, 0x0, -0x11 <.text+0x57ba8>
   57d50: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   57d58: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   57d60: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   57d70: bd 21 f0 ff 00 00 00 00      	jle r1, r2, -0x10 <.text+0x57bd8>
   57d78: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   57d88: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   57d90: 18 02 00 00 73 6f 6c 5f 00 00 00 00 76 61 75 6c      	lddw r2, 0x6c7561765f6c6f73
   57da0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   57da8: 72 01 08 00 74 00 00 00      	stb [r1 + 0x8], 0x74
   57db0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   57db8: 7b 19 10 00 00 00 00 00      	stxdw [r9 + 0x10], r1
   57dc0: 7a 09 18 00 09 00 00 00      	stdw [r9 + 0x18], 0x9
   57dc8: 7a 09 08 00 09 00 00 00      	stdw [r9 + 0x8], 0x9
   57dd0: 7a 09 00 00 01 00 00 00      	stdw [r9 + 0x0], 0x1
   57dd8: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   57de0: 7b 91 10 00 00 00 00 00      	stxdw [r1 + 0x10], r9
   57de8: 7b 41 08 00 00 00 00 00      	stxdw [r1 + 0x8], r4
   57df0: 05 00 52 ff 00 00 00 00      	ja -0xae <.text+0x57768>
   57df8: 18 03 00 00 89 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb89
   57e08: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   57e10: 85 10 00 00 df 57 ff ff      	call -0xa821
   57e18: 55 00 01 04 02 00 00 00      	jne r0, 0x2, +0x401 <.text+0x59d08>
   57e20: 7b 1a b8 fc 00 00 00 00      	stxdw [r10 - 0x348], r1
   57e28: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57e30: 07 01 00 00 28 fd ff ff      	add64 r1, -0x2d8
   57e38: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57e40: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57e48: 85 10 00 00 b2 64 ff ff      	call -0x9b4e
   57e50: 79 a2 30 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2d0]
   57e58: 79 a1 28 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2d8]
   57e60: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x57d78>
   57e68: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   57e78: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   57e80: 85 10 00 00 d1 57 ff ff      	call -0xa82f
   57e88: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   57e90: 55 00 ff 00 02 00 00 00      	jne r0, 0x2, +0xff <.text+0x58570>
   57e98: 7b 2a b0 fc 00 00 00 00      	stxdw [r10 - 0x350], r2
   57ea0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   57ea8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x57dc8>
   57eb0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   57eb8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   57ec0: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   57ec8: 7b 1a a8 fc 00 00 00 00      	stxdw [r10 - 0x358], r1
   57ed0: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   57ed8: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   57ee0: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x57e30>
   57ee8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   57ef0: 85 10 00 00 de 84 00 00      	call 0x84de
   57ef8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   57f00: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x57df8>
   57f08: 7b 2a a8 fc 00 00 00 00      	stxdw [r10 - 0x358], r2
   57f10: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x57e30>
   57f18: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   57f20: 18 03 00 00 e8 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbe8
   57f30: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   57f38: 85 10 00 00 ba 57 ff ff      	call -0xa846
   57f40: 55 00 dc 03 02 00 00 00      	jne r0, 0x2, +0x3dc <.text+0x59d08>
   57f48: 7b 1a a8 fc 00 00 00 00      	stxdw [r10 - 0x358], r1
   57f50: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   57f58: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   57f60: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   57f68: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   57f70: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   57f78: 7b 1a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r1
   57f80: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   57f88: 07 01 00 00 38 fd ff ff      	add64 r1, -0x2c8
   57f90: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   57f98: 79 a2 f8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x308]
   57fa0: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   57fa8: 79 a4 f0 fc 00 00 00 00      	ldxdw r4, [r10 - 0x310]
   57fb0: 85 10 00 00 54 5a ff ff      	call -0xa5ac
   57fb8: 79 a2 40 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2c0]
   57fc0: 79 a1 38 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2c8]
   57fc8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x57ee0>
   57fd0: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   57fe0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   57fe8: 85 10 00 00 a4 57 ff ff      	call -0xa85c
   57ff0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   57ff8: 55 00 d2 00 02 00 00 00      	jne r0, 0x2, +0xd2 <.text+0x58570>
   58000: 7b 2a a0 fc 00 00 00 00      	stxdw [r10 - 0x360], r2
   58008: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58010: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x57f30>
   58018: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   58020: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58028: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   58030: 7b 1a 98 fc 00 00 00 00      	stxdw [r10 - 0x368], r1
   58038: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   58040: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   58048: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x57f98>
   58050: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   58058: 85 10 00 00 b1 84 00 00      	call 0x84b1
   58060: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58068: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x57f60>
   58070: 7b 2a 98 fc 00 00 00 00      	stxdw [r10 - 0x368], r2
   58078: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x57f98>
   58080: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58088: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   58098: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   580a0: 85 10 00 00 8d 57 ff ff      	call -0xa873
   580a8: 55 00 af 03 02 00 00 00      	jne r0, 0x2, +0x3af <.text+0x59d08>
   580b0: 7b 1a 98 fc 00 00 00 00      	stxdw [r10 - 0x368], r1
   580b8: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   580c0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   580c8: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   580d0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   580d8: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   580e0: 7b 1a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r1
   580e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   580f0: 07 01 00 00 48 fd ff ff      	add64 r1, -0x2b8
   580f8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   58100: 79 a2 f8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x308]
   58108: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   58110: 79 a4 f0 fc 00 00 00 00      	ldxdw r4, [r10 - 0x310]
   58118: 85 10 00 00 53 59 ff ff      	call -0xa6ad
   58120: 79 a2 50 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2b0]
   58128: 79 a1 48 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2b8]
   58130: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x58048>
   58138: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   58148: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   58150: 85 10 00 00 77 57 ff ff      	call -0xa889
   58158: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58160: 55 00 a5 00 02 00 00 00      	jne r0, 0x2, +0xa5 <.text+0x58570>
   58168: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   58170: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58178: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x580d0>
   58180: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   58188: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   58190: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   58198: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   581a0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   581a8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   581b0: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x580f8>
   581b8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   581c0: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   581c8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   581d0: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   581d8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   581e0: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   581e8: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x58168>
   581f0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   581f8: 85 10 00 00 7d 84 00 00      	call 0x847d
   58200: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58208: 55 00 49 00 02 00 00 00      	jne r0, 0x2, +0x49 <.text+0x58338>
   58210: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   58218: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   58220: 85 10 00 00 78 84 00 00      	call 0x8478
   58228: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58230: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x58128>
   58238: 7b 2a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r2
   58240: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x581a8>
   58248: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58250: 18 03 00 00 fa db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbfa
   58260: b7 04 00 00 14 00 00 00      	mov64 r4, 0x14
   58268: 85 10 00 00 54 57 ff ff      	call -0xa8ac
   58270: 55 00 76 03 02 00 00 00      	jne r0, 0x2, +0x376 <.text+0x59d08>
   58278: 7b 1a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r1
   58280: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58288: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x581a8>
   58290: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   58298: 7b 2a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r2
   582a0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   582a8: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   582b0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   582b8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   582c0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x58218>
   582c8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   582d0: 85 10 00 00 62 84 00 00      	call 0x8462
   582d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   582e0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x581d8>
   582e8: 7b 2a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r2
   582f0: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x58258>
   582f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58300: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   58310: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   58318: 85 10 00 00 3e 57 ff ff      	call -0xa8c2
   58320: 55 00 60 03 02 00 00 00      	jne r0, 0x2, +0x360 <.text+0x59d08>
   58328: 7b 1a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r1
   58330: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58338: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x58258>
   58340: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   58348: 7b 2a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r2
   58350: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   58358: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   58360: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   58368: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58370: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x582c8>
   58378: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   58380: 85 10 00 00 4c 84 00 00      	call 0x844c
   58388: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58390: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x58288>
   58398: 7b 2a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r2
   583a0: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x58308>
   583a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   583b0: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   583c0: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   583c8: 85 10 00 00 28 57 ff ff      	call -0xa8d8
   583d0: 55 00 4a 03 02 00 00 00      	jne r0, 0x2, +0x34a <.text+0x59d08>
   583d8: 7b 1a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r1
   583e0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   583e8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x58308>
   583f0: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   583f8: 7b 2a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r2
   58400: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   58408: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   58410: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   58418: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58420: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x583c8>
   58428: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   58430: 85 10 00 00 36 84 00 00      	call 0x8436
   58438: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58440: 55 00 0c 00 02 00 00 00      	jne r0, 0x2, +0xc <.text+0x58388>
   58448: 7b 2a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r2
   58450: 05 00 1a 00 00 00 00 00      	ja +0x1a <.text+0x58408>
   58458: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58460: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   58470: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   58478: 85 10 00 00 12 57 ff ff      	call -0xa8ee
   58480: 55 00 34 03 02 00 00 00      	jne r0, 0x2, +0x334 <.text+0x59d08>
   58488: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   58490: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58498: 55 01 a3 ff 00 00 00 00      	jne r1, 0x0, -0x5d <.text+0x58098>
   584a0: 05 00 ae ff 00 00 00 00      	ja -0x52 <.text+0x580f8>
   584a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   584b0: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   584c0: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   584c8: 85 10 00 00 08 57 ff ff      	call -0xa8f8
   584d0: 55 00 2a 03 02 00 00 00      	jne r0, 0x2, +0x32a <.text+0x59d08>
   584d8: 7b 1a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r1
   584e0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   584e8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x58408>
   584f0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   584f8: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58500: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   58508: 7b 1a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r1
   58510: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   58518: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   58520: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x58470>
   58528: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   58530: 85 10 00 00 16 84 00 00      	call 0x8416
   58538: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58540: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x58438>
   58548: 7b 2a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r2
   58550: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x58470>
   58558: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58560: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   58570: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   58578: 85 10 00 00 f2 56 ff ff      	call -0xa90e
   58580: 55 00 14 03 02 00 00 00      	jne r0, 0x2, +0x314 <.text+0x59d08>
   58588: 7b 1a 78 fc 00 00 00 00      	stxdw [r10 - 0x388], r1
   58590: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   58598: 07 01 00 00 58 fd ff ff      	add64 r1, -0x2a8
   585a0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   585a8: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   585b0: 85 10 00 00 77 64 ff ff      	call -0x9b89
   585b8: 79 a2 60 fd 00 00 00 00      	ldxdw r2, [r10 - 0x2a0]
   585c0: 79 a1 58 fd 00 00 00 00      	ldxdw r1, [r10 - 0x2a8]
   585c8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x584e0>
   585d0: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   585e0: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   585e8: 85 10 00 00 e4 56 ff ff      	call -0xa91c
   585f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   585f8: 55 00 12 00 02 00 00 00      	jne r0, 0x2, +0x12 <.text+0x58570>
   58600: 7b 2a 70 fc 00 00 00 00      	stxdw [r10 - 0x390], r2
   58608: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58610: 15 01 13 00 00 00 00 00      	jeq r1, 0x0, +0x13 <.text+0x58590>
   58618: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   58620: 7b 2a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r2
   58628: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   58630: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   58638: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   58640: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58648: 15 01 11 00 00 00 00 00      	jeq r1, 0x0, +0x11 <.text+0x585b8>
   58650: 7b 7a 68 fc 00 00 00 00      	stxdw [r10 - 0x398], r7
   58658: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   58660: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   58668: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   58670: 7b 1a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r1
   58678: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   58680: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   58688: 05 00 17 00 00 00 00 00      	ja +0x17 <.text+0x58628>
   58690: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   58698: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   586a0: 7b 01 08 00 00 00 00 00      	stxdw [r1 + 0x8], r0
   586a8: 05 00 3b fe 00 00 00 00      	ja -0x1c5 <.text+0x57768>
   586b0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   586b8: 85 10 00 00 e5 83 00 00      	call 0x83e5
   586c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   586c8: 55 00 71 00 02 00 00 00      	jne r0, 0x2, +0x71 <.text+0x58938>
   586d0: 7b 2a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r2
   586d8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   586e0: 85 10 00 00 e0 83 00 00      	call 0x83e0
   586e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   586f0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x585e8>
   586f8: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   58700: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x58620>
   58708: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58710: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   58720: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   58728: 85 10 00 00 bc 56 ff ff      	call -0xa944
   58730: 55 00 de 02 02 00 00 00      	jne r0, 0x2, +0x2de <.text+0x59d08>
   58738: 7b 1a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r1
   58740: 7b 7a 68 fc 00 00 00 00      	stxdw [r10 - 0x398], r7
   58748: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   58758: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   58760: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   58768: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   58770: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   58778: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   58780: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   58788: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58790: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   58798: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   587a0: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   587a8: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   587b0: 07 07 00 00 68 fd ff ff      	add64 r7, -0x298
   587b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   587c0: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   587c8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   587d0: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   587d8: 85 10 00 00 b5 a3 00 00      	call 0xa3b5
   587e0: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   587e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   587f0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   587f8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   58800: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   58808: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   58810: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   58818: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   58820: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   58828: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58830: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   58838: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   58840: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   58848: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   58850: 85 10 00 00 63 64 ff ff      	call -0x9b9d
   58858: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x58780>
   58860: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   58868: 85 10 00 00 af 83 00 00      	call 0x83af
   58870: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58878: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58880: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   58890: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   58898: 05 00 31 00 00 00 00 00      	ja +0x31 <.text+0x58908>
   588a0: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   588a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   588b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   588b8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   588c0: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   588c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   588d0: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   588d8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   588e0: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   588e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   588f0: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   588f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   58900: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   58908: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   58910: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   58918: 85 10 00 00 4a 64 ff ff      	call -0x9bb6
   58920: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x58848>
   58928: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   58930: 85 10 00 00 96 83 00 00      	call 0x8396
   58938: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58940: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58948: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   58958: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   58960: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x58908>
   58968: 79 a1 68 fc 00 00 00 00      	ldxdw r1, [r10 - 0x398]
   58970: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   58978: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58980: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   58988: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   58990: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   58998: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   589a0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   589a8: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   589b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   589b8: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   589c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   589c8: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   589d0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   589d8: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   589e0: 85 10 00 00 31 64 ff ff      	call -0x9bcf
   589e8: 15 00 17 00 00 00 00 00      	jeq r0, 0x0, +0x17 <.text+0x58988>
   589f0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   589f8: 85 10 00 00 7d 83 00 00      	call 0x837d
   58a00: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58a08: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58a10: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   58a20: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   58a28: 85 10 00 00 5c 56 ff ff      	call -0xa9a4
   58a30: 79 a2 00 fd 00 00 00 00      	ldxdw r2, [r10 - 0x300]
   58a38: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   58a40: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   58a48: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   58a50: 05 00 c7 fd 00 00 00 00      	ja -0x239 <.text+0x57770>
   58a58: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58a60: 18 03 00 00 98 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad798
   58a70: b7 04 00 00 10 00 00 00      	mov64 r4, 0x10
   58a78: 85 10 00 00 52 56 ff ff      	call -0xa9ae
   58a80: 55 00 74 02 02 00 00 00      	jne r0, 0x2, +0x274 <.text+0x59d08>
   58a88: 7b 1a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r1
   58a90: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   58a98: 55 01 76 ff 00 00 00 00      	jne r1, 0x0, -0x8a <.text+0x58530>
   58aa0: 05 00 86 ff 00 00 00 00      	ja -0x7a <.text+0x585b8>
   58aa8: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   58ab0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58ab8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58ac0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   58ac8: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   58ad0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   58ad8: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   58ae0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   58ae8: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   58af0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58af8: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   58b00: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   58b08: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   58b10: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   58b18: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   58b20: 85 10 00 00 09 64 ff ff      	call -0x9bf7
   58b28: 15 00 07 00 00 00 00 00      	jeq r0, 0x0, +0x7 <.text+0x58a48>
   58b30: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   58b38: 85 10 00 00 55 83 00 00      	call 0x8355
   58b40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58b48: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58b50: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   58b60: 05 00 a5 ff 00 00 00 00      	ja -0x5b <.text+0x58770>
   58b68: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   58b70: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   58b78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58b80: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   58b88: 7b 2a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r2
   58b90: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   58b98: 7b 2a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r2
   58ba0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   58ba8: 7b 2a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r2
   58bb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58bb8: 7b 1a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r1
   58bc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   58bc8: 07 01 00 00 68 fd ff ff      	add64 r1, -0x298
   58bd0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   58bd8: 07 02 00 00 18 fe ff ff      	add64 r2, -0x1e8
   58be0: 85 10 00 00 f1 63 ff ff      	call -0x9c0f
   58be8: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x58b10>
   58bf0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   58bf8: 85 10 00 00 3d 83 00 00      	call 0x833d
   58c00: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   58c08: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   58c10: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   58c20: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   58c28: 05 00 3e 02 00 00 00 00      	ja +0x23e <.text+0x59d00>
   58c30: 7b 9a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r9
   58c38: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   58c40: 15 01 34 02 00 00 00 00      	jeq r1, 0x0, +0x234 <.text+0x59cc8>
   58c48: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   58c50: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   58c58: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   58c60: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   58c68: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   58c70: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   58c80: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   58c88: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   58c90: 85 10 00 00 ff ff ff ff      	call -0x1
   58c98: 55 00 ad 02 00 00 00 00      	jne r0, 0x0, +0x2ad <.text+0x5a0e8>
   58ca0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   58ca8: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   58cb0: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   58cb8: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   58cc0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   58cc8: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   58cd0: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   58cd8: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   58ce0: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   58ce8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58cf0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   58cf8: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   58d00: 5d 73 29 02 00 00 00 00      	jne r3, r7, +0x229 <.text+0x59d30>
   58d08: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   58d10: 5d 93 27 02 00 00 00 00      	jne r3, r9, +0x227 <.text+0x59d30>
   58d18: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   58d20: 5d 83 25 02 00 00 00 00      	jne r3, r8, +0x225 <.text+0x59d30>
   58d28: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   58d30: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   58d38: 5d 32 22 02 00 00 00 00      	jne r2, r3, +0x222 <.text+0x59d30>
   58d40: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   58d48: 15 01 3e 02 00 00 00 00      	jeq r1, 0x0, +0x23e <.text+0x59e20>
   58d50: 79 a2 c8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x338]
   58d58: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   58d60: 7b 1a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r1
   58d68: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   58d70: 7b 1a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r1
   58d78: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   58d80: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   58d88: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   58d90: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   58d98: 7b 3a 30 fc 00 00 00 00      	stxdw [r10 - 0x3d0], r3
   58da0: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   58da8: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   58db0: 79 22 28 00 00 00 00 00      	ldxdw r2, [r2 + 0x28]
   58db8: 79 19 00 00 00 00 00 00      	ldxdw r9, [r1 + 0x0]
   58dc0: 7b 2a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r2
   58dc8: 5d 92 36 02 00 00 00 00      	jne r2, r9, +0x236 <.text+0x59e60>
   58dd0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   58dd8: 5d 81 34 02 00 00 00 00      	jne r1, r8, +0x234 <.text+0x59e60>
   58de0: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   58de8: 5d 71 32 02 00 00 00 00      	jne r1, r7, +0x232 <.text+0x59e60>
   58df0: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   58df8: 79 a2 30 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d0]
   58e00: 5d 21 2f 02 00 00 00 00      	jne r1, r2, +0x22f <.text+0x59e60>
   58e08: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   58e10: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   58e18: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58e20: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   58e28: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   58e30: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   58e38: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   58e40: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   58e50: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   58e58: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   58e60: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   58e68: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   58e70: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   58e78: 7b 4a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r4
   58e80: 7b 3a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r3
   58e88: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   58e90: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   58e98: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   58ea0: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   58ea8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   58eb0: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   58eb8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   58ec0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   58ec8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   58ed0: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   58ed8: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   58ee0: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   58ee8: 85 10 00 00 ff ff ff ff      	call -0x1
   58ef0: 55 00 62 02 00 00 00 00      	jne r0, 0x0, +0x262 <.text+0x5a0e8>
   58ef8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   58f00: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   58f08: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   58f10: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   58f18: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   58f20: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   58f28: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   58f30: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   58f38: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   58f40: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   58f48: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   58f50: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   58f58: 5d 73 1b 02 00 00 00 00      	jne r3, r7, +0x21b <.text+0x59f18>
   58f60: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   58f68: 5d 93 19 02 00 00 00 00      	jne r3, r9, +0x219 <.text+0x59f18>
   58f70: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   58f78: 5d 83 17 02 00 00 00 00      	jne r3, r8, +0x217 <.text+0x59f18>
   58f80: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   58f88: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   58f90: 5d 32 14 02 00 00 00 00      	jne r2, r3, +0x214 <.text+0x59f18>
   58f98: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   58fa0: 15 01 1d 02 00 00 00 00      	jeq r1, 0x0, +0x21d <.text+0x59f70>
   58fa8: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   58fb0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   58fb8: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   58fc0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   58fc8: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   58fd0: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   58fe0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   58fe8: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   58ff0: 85 10 00 00 ff ff ff ff      	call -0x1
   58ff8: 55 00 41 02 00 00 00 00      	jne r0, 0x0, +0x241 <.text+0x5a0e8>
   59000: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59008: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   59010: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   59018: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   59020: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   59028: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   59030: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   59038: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   59040: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   59048: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59050: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59058: 5d 72 0e 02 00 00 00 00      	jne r2, r7, +0x20e <.text+0x59fb0>
   59060: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   59068: 5d 82 0c 02 00 00 00 00      	jne r2, r8, +0x20c <.text+0x59fb0>
   59070: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   59078: 5d 92 0a 02 00 00 00 00      	jne r2, r9, +0x20a <.text+0x59fb0>
   59080: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59088: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   59090: 5d 21 07 02 00 00 00 00      	jne r1, r2, +0x207 <.text+0x59fb0>
   59098: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   590a0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   590a8: 15 01 1d 02 00 00 00 00      	jeq r1, 0x0, +0x21d <.text+0x5a078>
   590b0: 79 a1 68 fc 00 00 00 00      	ldxdw r1, [r10 - 0x398]
   590b8: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   590c0: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   590c8: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   590d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   590d8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   590e0: 85 10 00 00 95 60 ff ff      	call -0x9f6b
   590e8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   590f0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   590f8: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   59100: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   59108: 5d 34 19 02 00 00 00 00      	jne r4, r3, +0x219 <.text+0x5a0b8>
   59110: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   59118: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   59120: 5d 34 16 02 00 00 00 00      	jne r4, r3, +0x216 <.text+0x5a0b8>
   59128: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   59130: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   59138: 5d 34 13 02 00 00 00 00      	jne r4, r3, +0x213 <.text+0x5a0b8>
   59140: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59148: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   59150: 5d 12 10 02 00 00 00 00      	jne r2, r1, +0x210 <.text+0x5a0b8>
   59158: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   59160: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   59168: 85 10 00 00 ae 5d ff ff      	call -0xa252
   59170: 79 a1 68 fc 00 00 00 00      	ldxdw r1, [r10 - 0x398]
   59178: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   59180: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   59188: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   59190: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   59198: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   591a0: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   591a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   591b0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   591b8: 7b 2a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r2
   591c0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   591c8: 7b 2a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r2
   591d0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   591d8: 7b 2a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r2
   591e0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   591e8: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   591f0: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   591f8: 5d 17 0d 02 00 00 00 00      	jne r7, r1, +0x20d <.text+0x5a148>
   59200: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   59208: 5d 18 0b 02 00 00 00 00      	jne r8, r1, +0x20b <.text+0x5a148>
   59210: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   59218: 5d 19 09 02 00 00 00 00      	jne r9, r1, +0x209 <.text+0x5a148>
   59220: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   59228: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   59230: 5d 12 06 02 00 00 00 00      	jne r2, r1, +0x206 <.text+0x5a148>
   59238: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   59240: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   59248: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   59250: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   59258: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   59260: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   59268: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   59270: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   59278: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   59280: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59288: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   59290: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   59298: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   592a0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   592a8: 85 10 00 00 5c 60 ff ff      	call -0x9fa4
   592b0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   592b8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   592c0: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   592c8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   592d0: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   592d8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   592e0: 7b 2a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r2
   592e8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   592f0: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   592f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   59300: 07 01 00 00 58 fe ff ff      	add64 r1, -0x1a8
   59308: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   59310: 07 02 00 00 38 fe ff ff      	add64 r2, -0x1c8
   59318: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   59320: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   59328: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   59330: 07 04 00 00 68 fd ff ff      	add64 r4, -0x298
   59338: 85 10 00 00 28 79 00 00      	call 0x7928
   59340: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   59348: 85 10 00 00 72 5d ff ff      	call -0xa28e
   59350: 79 a1 68 fc 00 00 00 00      	ldxdw r1, [r10 - 0x398]
   59358: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   59360: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59368: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   59370: 7b 3a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r3
   59378: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   59380: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   59388: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   59390: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   59398: 5d 27 ef 01 00 00 00 00      	jne r7, r2, +0x1ef <.text+0x5a1f8>
   593a0: 79 a2 60 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a0]
   593a8: 5d 28 ed 01 00 00 00 00      	jne r8, r2, +0x1ed <.text+0x5a1f8>
   593b0: 79 a2 68 fe 00 00 00 00      	ldxdw r2, [r10 - 0x198]
   593b8: 5d 29 eb 01 00 00 00 00      	jne r9, r2, +0x1eb <.text+0x5a1f8>
   593c0: 79 a2 70 fe 00 00 00 00      	ldxdw r2, [r10 - 0x190]
   593c8: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   593d0: 5d 23 e8 01 00 00 00 00      	jne r3, r2, +0x1e8 <.text+0x5a1f8>
   593d8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   593e0: 15 01 fd 01 00 00 00 00      	jeq r1, 0x0, +0x1fd <.text+0x5a2b0>
   593e8: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   593f0: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   593f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59400: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59408: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   59410: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   59418: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59420: 18 05 00 00 1a dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc1a
   59430: 7b 5a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r5
   59438: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   59440: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   59448: 7b 5a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r5
   59450: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   59458: 7b 4a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r4
   59460: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   59468: 7b 2a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r2
   59470: 7a 0a 80 fe 0d 00 00 00      	stdw [r10 - 0x180], 0xd
   59478: 7a 0a 90 fe 20 00 00 00      	stdw [r10 - 0x170], 0x20
   59480: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   59490: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   59498: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   594a8: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   594b0: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   594c0: 7b 1a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r1
   594c8: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   594d8: 7b 1a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r1
   594e0: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   594e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   594f0: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   594f8: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   59500: 07 03 00 00 68 fd ff ff      	add64 r3, -0x298
   59508: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   59510: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   59518: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   59520: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   59528: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   59530: 85 10 00 00 ff ff ff ff      	call -0x1
   59538: 55 00 99 01 00 00 00 00      	jne r0, 0x0, +0x199 <.text+0x5a0e8>
   59540: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59548: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   59550: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   59558: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   59560: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   59568: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   59570: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   59578: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   59580: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   59588: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59590: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59598: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   595a0: 5d 73 cd 01 00 00 00 00      	jne r3, r7, +0x1cd <.text+0x5a2f0>
   595a8: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   595b0: 5d 93 cb 01 00 00 00 00      	jne r3, r9, +0x1cb <.text+0x5a2f0>
   595b8: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   595c0: 5d 83 c9 01 00 00 00 00      	jne r3, r8, +0x1c9 <.text+0x5a2f0>
   595c8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   595d0: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   595d8: 5d 32 c6 01 00 00 00 00      	jne r2, r3, +0x1c6 <.text+0x5a2f0>
   595e0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   595e8: 15 01 cf 01 00 00 00 00      	jeq r1, 0x0, +0x1cf <.text+0x5a348>
   595f0: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   595f8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   59600: 15 01 d3 01 00 00 00 00      	jeq r1, 0x0, +0x1d3 <.text+0x5a380>
   59608: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   59610: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   59618: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   59620: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   59628: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   59630: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   59638: 85 10 00 00 ea 5f ff ff      	call -0xa016
   59640: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59648: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   59650: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   59658: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   59660: 5d 34 6e 01 00 00 00 00      	jne r4, r3, +0x16e <.text+0x5a0b8>
   59668: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   59670: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   59678: 5d 34 6b 01 00 00 00 00      	jne r4, r3, +0x16b <.text+0x5a0b8>
   59680: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   59688: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   59690: 5d 34 68 01 00 00 00 00      	jne r4, r3, +0x168 <.text+0x5a0b8>
   59698: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   596a0: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   596a8: 5d 12 65 01 00 00 00 00      	jne r2, r1, +0x165 <.text+0x5a0b8>
   596b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   596b8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   596c0: 85 10 00 00 03 5d ff ff      	call -0xa2fd
   596c8: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   596d0: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   596d8: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   596e0: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   596e8: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   596f0: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   596f8: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   59700: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59708: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59710: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   59718: 7b 2a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r2
   59720: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   59728: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   59730: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   59738: 7b 2a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r2
   59740: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59748: 7b 1a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r1
   59750: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   59758: 5d 17 af 01 00 00 00 00      	jne r7, r1, +0x1af <.text+0x5a3b8>
   59760: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   59768: 5d 18 ad 01 00 00 00 00      	jne r8, r1, +0x1ad <.text+0x5a3b8>
   59770: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   59778: 5d 19 ab 01 00 00 00 00      	jne r9, r1, +0x1ab <.text+0x5a3b8>
   59780: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   59788: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   59790: 5d 12 a8 01 00 00 00 00      	jne r2, r1, +0x1a8 <.text+0x5a3b8>
   59798: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   597a0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   597a8: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   597b0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   597b8: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   597c0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   597c8: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   597d0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   597d8: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   597e0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   597e8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   597f0: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   597f8: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   59800: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   59808: 85 10 00 00 b0 5f ff ff      	call -0xa050
   59810: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59818: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59820: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   59828: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   59830: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   59838: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   59840: 7b 2a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r2
   59848: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59850: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   59858: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   59860: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   59868: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   59870: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   59878: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   59880: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   59888: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   59890: 07 04 00 00 68 fd ff ff      	add64 r4, -0x298
   59898: 85 10 00 00 7c 78 00 00      	call 0x787c
   598a0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   598a8: 85 10 00 00 c6 5c ff ff      	call -0xa33a
   598b0: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   598b8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   598c0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   598c8: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   598d0: 7b 3a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r3
   598d8: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   598e0: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   598e8: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   598f0: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   598f8: 5d 27 91 01 00 00 00 00      	jne r7, r2, +0x191 <.text+0x5a468>
   59900: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   59908: 5d 28 8f 01 00 00 00 00      	jne r8, r2, +0x18f <.text+0x5a468>
   59910: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   59918: 5d 29 8d 01 00 00 00 00      	jne r9, r2, +0x18d <.text+0x5a468>
   59920: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   59928: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   59930: 5d 23 8a 01 00 00 00 00      	jne r3, r2, +0x18a <.text+0x5a468>
   59938: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   59940: 15 01 9e 01 00 00 00 00      	jeq r1, 0x0, +0x19e <.text+0x5a518>
   59948: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   59950: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   59958: 15 01 9d 01 00 00 00 00      	jeq r1, 0x0, +0x19d <.text+0x5a528>
   59960: 79 a1 90 fc 00 00 00 00      	ldxdw r1, [r10 - 0x370]
   59968: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59970: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   59978: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   59980: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   59988: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   59990: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   59998: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   599a8: 5d 17 9a 01 00 00 00 00      	jne r7, r1, +0x19a <.text+0x5a560>
   599b0: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   599c0: 5d 18 97 01 00 00 00 00      	jne r8, r1, +0x197 <.text+0x5a560>
   599c8: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   599d8: 5d 19 94 01 00 00 00 00      	jne r9, r1, +0x194 <.text+0x5a560>
   599e0: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   599f0: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   599f8: 5d 12 90 01 00 00 00 00      	jne r2, r1, +0x190 <.text+0x5a560>
   59a00: 72 0a 68 fd ff 00 00 00      	stb [r10 - 0x298], 0xff
   59a08: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   59a10: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   59a18: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   59a20: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   59a28: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   59a38: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   59a40: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   59a48: 85 10 00 00 ff ff ff ff      	call -0x1
   59a50: 55 00 f6 00 00 00 00 00      	jne r0, 0x0, +0xf6 <.text+0x5a0e8>
   59a58: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59a60: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   59a68: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   59a70: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   59a78: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   59a80: 71 a1 68 fd 00 00 00 00      	ldxb r1, [r10 - 0x298]
   59a88: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   59a90: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   59a98: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   59aa0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59aa8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59ab0: 5d 72 93 01 00 00 00 00      	jne r2, r7, +0x193 <.text+0x5a630>
   59ab8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   59ac0: 5d 82 91 01 00 00 00 00      	jne r2, r8, +0x191 <.text+0x5a630>
   59ac8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   59ad0: 5d 92 8f 01 00 00 00 00      	jne r2, r9, +0x18f <.text+0x5a630>
   59ad8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59ae0: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   59ae8: 5d 21 8c 01 00 00 00 00      	jne r1, r2, +0x18c <.text+0x5a630>
   59af0: 79 a1 c0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x340]
   59af8: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   59b00: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59b08: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59b10: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   59b18: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   59b20: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59b28: 18 05 00 00 68 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xad768
   59b38: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   59b40: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   59b48: 07 05 00 00 68 fd ff ff      	add64 r5, -0x298
   59b50: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   59b58: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   59b60: 7b 4a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r4
   59b68: 7b 3a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r3
   59b70: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   59b78: 7a 0a e0 fe 10 00 00 00      	stdw [r10 - 0x120], 0x10
   59b80: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   59b88: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   59b90: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   59b98: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   59ba0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   59ba8: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   59bb0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   59bb8: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   59bc0: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   59bc8: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   59bd0: 85 10 00 00 ff ff ff ff      	call -0x1
   59bd8: 55 00 c5 00 00 00 00 00      	jne r0, 0x0, +0xc5 <.text+0x5a0e8>
   59be0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   59be8: 7b 1a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r1
   59bf0: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   59bf8: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   59c00: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   59c08: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   59c10: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   59c18: 73 12 05 00 00 00 00 00      	stxb [r2 + 0x5], r1
   59c20: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   59c28: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59c30: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   59c38: 5d 72 6d 01 00 00 00 00      	jne r2, r7, +0x16d <.text+0x5a688>
   59c40: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   59c48: 5d 82 6b 01 00 00 00 00      	jne r2, r8, +0x16b <.text+0x5a688>
   59c50: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   59c58: 5d 92 69 01 00 00 00 00      	jne r2, r9, +0x169 <.text+0x5a688>
   59c60: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59c68: 79 a2 f8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x308]
   59c70: 5d 21 66 01 00 00 00 00      	jne r1, r2, +0x166 <.text+0x5a688>
   59c78: 79 a1 58 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a8]
   59c80: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   59c88: 15 01 78 01 00 00 00 00      	jeq r1, 0x0, +0x178 <.text+0x5a730>
   59c90: 79 a1 00 fd 00 00 00 00      	ldxdw r1, [r10 - 0x300]
   59c98: 79 a2 58 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a8]
   59ca0: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   59ca8: 79 a2 60 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a0]
   59cb0: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   59cb8: 79 a2 70 fc 00 00 00 00      	ldxdw r2, [r10 - 0x390]
   59cc0: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   59cc8: 79 a2 78 fc 00 00 00 00      	ldxdw r2, [r10 - 0x388]
   59cd0: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   59cd8: 79 a2 80 fc 00 00 00 00      	ldxdw r2, [r10 - 0x380]
   59ce0: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   59ce8: 79 a2 88 fc 00 00 00 00      	ldxdw r2, [r10 - 0x378]
   59cf0: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   59cf8: 79 a2 90 fc 00 00 00 00      	ldxdw r2, [r10 - 0x370]
   59d00: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   59d08: 79 a2 d8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x328]
   59d10: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   59d18: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   59d20: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   59d28: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   59d30: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   59d38: 79 a2 98 fc 00 00 00 00      	ldxdw r2, [r10 - 0x368]
   59d40: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   59d48: 79 a2 a0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x360]
   59d50: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   59d58: 79 a2 a8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x358]
   59d60: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   59d68: 79 a2 b0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x350]
   59d70: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   59d78: 79 a2 b8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x348]
   59d80: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   59d88: 79 a2 68 fc 00 00 00 00      	ldxdw r2, [r10 - 0x398]
   59d90: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   59d98: 79 a2 c0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x340]
   59da0: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   59da8: 79 a2 48 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b8]
   59db0: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   59db8: 79 a2 d0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x330]
   59dc0: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   59dc8: 79 a2 c8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x338]
   59dd0: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   59dd8: 7b 61 00 00 00 00 00 00      	stxdw [r1 + 0x0], r6
   59de0: 05 00 55 fb 00 00 00 00      	ja -0x4ab <.text+0x57770>
   59de8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   59df0: 85 10 00 00 fe 80 00 00      	call 0x80fe
   59df8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59e00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   59e08: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   59e18: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   59e20: 85 10 00 00 dd 53 ff ff      	call -0xac23
   59e28: 79 a2 00 fd 00 00 00 00      	ldxdw r2, [r10 - 0x300]
   59e30: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   59e38: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   59e40: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   59e48: 05 00 48 fb 00 00 00 00      	ja -0x4b8 <.text+0x57770>
   59e50: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   59e58: 85 10 00 00 f1 80 00 00      	call 0x80f1
   59e60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59e68: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   59e70: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   59e80: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   59e88: 85 10 00 00 d0 53 ff ff      	call -0xac30
   59e90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59e98: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   59ea0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59ea8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   59eb0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   59eb8: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   59ec0: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   59ec8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   59ed0: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   59ed8: 7b 9a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r9
   59ee0: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   59ee8: 79 a6 50 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3b0]
   59ef0: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   59ef8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   59f00: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   59f08: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   59f10: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   59f18: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   59f20: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   59f28: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   59f30: 85 10 00 00 58 7b 00 00      	call 0x7b58
   59f38: 05 00 dd ff 00 00 00 00      	ja -0x23 <.text+0x59d08>
   59f40: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   59f48: 85 10 00 00 d3 80 00 00      	call 0x80d3
   59f50: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59f58: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   59f60: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   59f70: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   59f78: 05 00 d4 ff 00 00 00 00      	ja -0x2c <.text+0x59d00>
   59f80: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   59f88: 85 10 00 00 cb 80 00 00      	call 0x80cb
   59f90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59f98: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   59fa0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   59fb0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   59fb8: 85 10 00 00 aa 53 ff ff      	call -0xac56
   59fc0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   59fc8: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   59fd0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   59fd8: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   59fe0: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   59fe8: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   59ff0: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   59ff8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a000: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   5a008: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   5a010: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a018: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   5a020: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   5a028: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   5a030: 05 00 dc ff 00 00 00 00      	ja -0x24 <.text+0x59df8>
   5a038: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5a040: 85 10 00 00 b4 80 00 00      	call 0x80b4
   5a048: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a050: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a058: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   5a068: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   5a070: 85 10 00 00 93 53 ff ff      	call -0xac6d
   5a078: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a080: 79 a1 d0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x330]
   5a088: 05 00 c2 ff 00 00 00 00      	ja -0x3e <.text+0x59d80>
   5a090: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a098: 85 10 00 00 a9 80 00 00      	call 0x80a9
   5a0a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a0a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a0b0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   5a0c0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   5a0c8: 05 00 aa ff 00 00 00 00      	ja -0x56 <.text+0x59d00>
   5a0d0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5a0d8: 85 10 00 00 a1 80 00 00      	call 0x80a1
   5a0e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a0e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a0f0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   5a100: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   5a108: 85 10 00 00 80 53 ff ff      	call -0xac80
   5a110: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a118: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   5a120: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5a128: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5a130: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   5a138: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5a140: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   5a148: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5a150: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   5a158: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5a160: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   5a168: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a170: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   5a178: 7b 9a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r9
   5a180: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   5a188: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   5a190: 05 00 b0 ff 00 00 00 00      	ja -0x50 <.text+0x59df8>
   5a198: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a1a0: 85 10 00 00 88 80 00 00      	call 0x8088
   5a1a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a1b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a1b8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   5a1c8: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   5a1d0: 05 00 89 ff 00 00 00 00      	ja -0x77 <.text+0x59d00>
   5a1d8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5a1e0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5a1e8: 85 10 00 00 9e 5b ff ff      	call -0xa462
   5a1f0: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   5a1f8: 85 10 00 00 7d 80 00 00      	call 0x807d
   5a200: 05 00 84 ff 00 00 00 00      	ja -0x7c <.text+0x59d08>
   5a208: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   5a218: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   5a220: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   5a228: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   5a230: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   5a238: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   5a240: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5a248: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5a250: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   5a260: 85 10 00 00 c4 94 00 00      	call 0x94c4
   5a268: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   5a270: 85 10 00 00 6e 80 00 00      	call 0x806e
   5a278: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a280: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a288: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   5a298: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   5a2a0: 85 10 00 00 4d 53 ff ff      	call -0xacb3
   5a2a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a2b0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a2b8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a2c0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   5a2c8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   5a2d0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   5a2d8: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   5a2e0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   5a2e8: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   5a2f0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   5a2f8: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   5a300: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   5a308: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   5a310: 05 00 15 00 00 00 00 00      	ja +0x15 <.text+0x5a2a0>
   5a318: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   5a320: 85 10 00 00 58 80 00 00      	call 0x8058
   5a328: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a330: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a338: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   5a348: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   5a350: 85 10 00 00 37 53 ff ff      	call -0xacc9
   5a358: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a360: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a368: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a370: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   5a378: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   5a380: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   5a388: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   5a390: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   5a398: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   5a3a0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   5a3a8: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   5a3b0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   5a3b8: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   5a3c0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   5a3c8: 05 00 69 ff 00 00 00 00      	ja -0x97 <.text+0x59df8>
   5a3d0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a3d8: 85 10 00 00 41 80 00 00      	call 0x8041
   5a3e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a3e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a3f0: 18 03 00 00 c9 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbc9
   5a400: b7 04 00 00 12 00 00 00      	mov64 r4, 0x12
   5a408: 05 00 42 ff 00 00 00 00      	ja -0xbe <.text+0x59d00>
   5a410: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5a418: 85 10 00 00 39 80 00 00      	call 0x8039
   5a420: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a428: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a430: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   5a440: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5a448: 85 10 00 00 18 53 ff ff      	call -0xace8
   5a450: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a458: 79 a1 a0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x360]
   5a460: 05 00 47 ff 00 00 00 00      	ja -0xb9 <.text+0x59d80>
   5a468: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a470: 85 10 00 00 2e 80 00 00      	call 0x802e
   5a478: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a480: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a488: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   5a498: 05 00 5a ff 00 00 00 00      	ja -0xa6 <.text+0x59e50>
   5a4a0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a4a8: 85 10 00 00 27 80 00 00      	call 0x8027
   5a4b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a4b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a4c0: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   5a4d0: 05 00 53 ff 00 00 00 00      	ja -0xad <.text+0x59e50>
   5a4d8: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   5a4e0: 85 10 00 00 20 80 00 00      	call 0x8020
   5a4e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a4f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a4f8: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   5a508: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5a510: 85 10 00 00 ff 52 ff ff      	call -0xad01
   5a518: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a520: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a528: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a530: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   5a538: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   5a540: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   5a548: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   5a550: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   5a558: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   5a560: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   5a568: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   5a570: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   5a578: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   5a580: 05 00 c7 ff 00 00 00 00      	ja -0x39 <.text+0x5a2a0>
   5a588: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   5a590: 85 10 00 00 0a 80 00 00      	call 0x800a
   5a598: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a5a0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a5a8: 18 03 00 00 dd dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadddd
   5a5b8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5a5c0: 85 10 00 00 e9 52 ff ff      	call -0xad17
   5a5c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a5d0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a5d8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a5e0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   5a5e8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   5a5f0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   5a5f8: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   5a600: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   5a608: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   5a610: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   5a618: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   5a620: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   5a628: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   5a630: 05 00 b1 ff 00 00 00 00      	ja -0x4f <.text+0x5a2a0>
   5a638: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a640: 05 00 b6 fc 00 00 00 00      	ja -0x34a <.text+0x58ad8>
   5a648: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a650: 85 10 00 00 f2 7f 00 00      	call 0x7ff2
   5a658: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a660: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a668: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   5a678: 05 00 1e ff 00 00 00 00      	ja -0xe2 <.text+0x59e50>
   5a680: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   5a688: 85 10 00 00 eb 7f 00 00      	call 0x7feb
   5a690: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a698: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a6a0: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   5a6b0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   5a6b8: 85 10 00 00 ca 52 ff ff      	call -0xad36
   5a6c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a6c8: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   5a6d8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   5a6e0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   5a6e8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5a6f0: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   5a6f8: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   5a700: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   5a708: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   5a718: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   5a720: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   5a730: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   5a738: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   5a748: 05 00 8e ff 00 00 00 00      	ja -0x72 <.text+0x5a2a0>
   5a750: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5a758: 85 10 00 00 d1 7f 00 00      	call 0x7fd1
   5a760: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a768: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a770: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   5a780: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   5a788: 85 10 00 00 b0 52 ff ff      	call -0xad50
   5a790: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a798: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   5a7a0: 05 00 2f ff 00 00 00 00      	ja -0xd1 <.text+0x5a000>
   5a7a8: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5a7b0: 85 10 00 00 c6 7f 00 00      	call 0x7fc6
   5a7b8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a7c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a7c8: 18 03 00 00 98 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xad798
   5a7d8: b7 04 00 00 10 00 00 00      	mov64 r4, 0x10
   5a7e0: 85 10 00 00 a5 52 ff ff      	call -0xad5b
   5a7e8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a7f0: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   5a7f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5a800: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5a808: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   5a810: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5a818: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   5a820: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5a828: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   5a830: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5a838: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   5a840: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   5a848: 05 00 24 ff 00 00 00 00      	ja -0xdc <.text+0x5a050>
   5a850: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5a858: 85 10 00 00 b1 7f 00 00      	call 0x7fb1
   5a860: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5a868: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5a870: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   5a880: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   5a888: 05 00 b2 fe 00 00 00 00      	ja -0x14e <.text+0x59d00>
   5c6d8: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   5c6e0: 7b 4a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r4
   5c6e8: bf 39 00 00 00 00 00 00      	mov64 r9, r3
   5c6f0: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   5c6f8: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   5c700: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5c708: 07 01 00 00 68 fc ff ff      	add64 r1, -0x398
   5c710: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5c718: 85 10 00 00 22 5b ff ff      	call -0xa4de
   5c720: 79 a1 70 fc 00 00 00 00      	ldxdw r1, [r10 - 0x390]
   5c728: 7b 1a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r1
   5c730: 79 a6 68 fc 00 00 00 00      	ldxdw r6, [r10 - 0x398]
   5c738: 55 06 23 00 02 00 00 00      	jne r6, 0x2, +0x23 <.text+0x5c738>
   5c740: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   5c748: 7b 1a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r1
   5c750: 79 76 08 f0 00 00 00 00      	ldxdw r6, [r7 - 0xff8]
   5c758: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   5c760: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5c768: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5c770: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5c778: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5c780: 85 10 00 00 69 5b ff ff      	call -0xa497
   5c788: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   5c790: 55 01 38 00 02 00 00 00      	jne r1, 0x2, +0x38 <.text+0x5c838>
   5c798: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   5c7a0: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   5c7a8: 85 10 00 00 c8 4d 00 00      	call 0x4dc8
   5c7b0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   5c7c0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5c7c8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5c7d0: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   5c7d8: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   5c7e0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5c7e8: bd 21 6c 00 00 00 00 00      	jle r1, r2, +0x6c <.text+0x5ca30>
   5c7f0: 15 04 6d 00 00 00 00 00      	jeq r4, 0x0, +0x6d <.text+0x5ca40>
   5c7f8: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   5c808: 55 02 6e 00 00 00 00 00      	jne r2, 0x0, +0x6e <.text+0x5ca60>
   5c810: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5c820: 55 06 6f 00 01 00 00 00      	jne r6, 0x1, +0x6f <.text+0x5ca80>
   5c828: 2d 21 6f 00 00 00 00 00      	jgt r1, r2, +0x6f <.text+0x5ca88>
   5c830: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   5c838: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   5c840: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   5c850: 85 10 00 00 fe 8d 00 00      	call 0x8dfe
   5c858: 85 10 00 00 b2 4d 00 00      	call 0x4db2
   5c860: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   5c870: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5c878: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5c880: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   5c888: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   5c890: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5c898: bd 21 4f 00 00 00 00 00      	jle r1, r2, +0x4f <.text+0x5c9f8>
   5c8a0: 15 04 50 00 00 00 00 00      	jeq r4, 0x0, +0x50 <.text+0x5ca08>
   5c8a8: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   5c8b8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x5c7a8>
   5c8c0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   5c8c8: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   5c8d0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   5c8d8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5c8e8: 79 a3 60 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3a0]
   5c8f0: bd 21 ea 06 00 00 00 00      	jle r1, r2, +0x6ea <.text+0x5ff28>
   5c8f8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5c908: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5c910: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   5c918: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   5c920: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   5c928: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   5c930: 7a 03 18 00 06 00 00 00      	stdw [r3 + 0x18], 0x6
   5c938: 7a 03 08 00 06 00 00 00      	stdw [r3 + 0x8], 0x6
   5c940: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   5c948: 7b 38 10 00 00 00 00 00      	stxdw [r8 + 0x10], r3
   5c950: 05 00 59 00 00 00 00 00      	ja +0x59 <.text+0x5cb00>
   5c958: 85 10 00 00 92 4d 00 00      	call 0x4d92
   5c960: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   5c970: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5c978: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5c980: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   5c988: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   5c990: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5c998: bd 13 53 00 00 00 00 00      	jle r3, r1, +0x53 <.text+0x5cb18>
   5c9a0: 7b 6a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r6
   5c9a8: 15 04 54 00 00 00 00 00      	jeq r4, 0x0, +0x54 <.text+0x5cb30>
   5c9b0: 18 06 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r6, 0x300007f00
   5c9c0: 55 01 55 00 00 00 00 00      	jne r1, 0x0, +0x55 <.text+0x5cb50>
   5c9c8: 7b 8a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r8
   5c9d0: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   5c9e0: bd 16 57 00 00 00 00 00      	jle r6, r1, +0x57 <.text+0x5cb80>
   5c9e8: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
   5c9f8: 7b 68 00 00 00 00 00 00      	stxdw [r8 + 0x0], r6
   5ca00: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5ca08: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   5ca10: bf 61 00 00 00 00 00 00      	mov64 r1, r6
   5ca18: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   5ca20: 85 10 00 00 6c 9b 00 00      	call 0x9b6c
   5ca28: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5ca30: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5ca38: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5ca40: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5ca48: 85 10 00 00 dd 5a ff ff      	call -0xa523
   5ca50: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   5ca58: 55 01 4b 00 02 00 00 00      	jne r1, 0x2, +0x4b <.text+0x5cb98>
   5ca60: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   5ca68: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   5ca70: 85 10 00 00 6f 4d 00 00      	call 0x4d6f
   5ca78: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   5ca80: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5ca88: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   5ca90: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   5ca98: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5caa0: bd 21 74 00 00 00 00 00      	jle r1, r2, +0x74 <.text+0x5cd28>
   5caa8: 79 a5 40 fc 00 00 00 00      	ldxdw r5, [r10 - 0x3c0]
   5cab0: 15 04 75 00 00 00 00 00      	jeq r4, 0x0, +0x75 <.text+0x5cd40>
   5cab8: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   5cac8: 55 02 76 00 00 00 00 00      	jne r2, 0x0, +0x76 <.text+0x5cd60>
   5cad0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5cae0: 55 06 77 00 01 00 00 00      	jne r6, 0x1, +0x77 <.text+0x5cd80>
   5cae8: 2d 21 77 00 00 00 00 00      	jgt r1, r2, +0x77 <.text+0x5cd88>
   5caf0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   5caf8: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   5cb00: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   5cb10: 85 10 00 00 a6 8d 00 00      	call 0x8da6
   5cb18: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5cb20: 55 04 b0 ff 00 00 00 00      	jne r4, 0x0, -0x50 <.text+0x5c788>
   5cb28: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5cb30: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   5cb40: 55 02 af ff 00 00 00 00      	jne r2, 0x0, -0x51 <.text+0x5c7a0>
   5cb48: 05 00 af ff 00 00 00 00      	ja -0x51 <.text+0x5c7a8>
   5cb50: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5cb58: 55 04 93 ff 00 00 00 00      	jne r4, 0x0, -0x6d <.text+0x5c6d8>
   5cb60: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5cb68: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   5cb78: 15 02 92 ff 00 00 00 00      	jeq r2, 0x0, -0x6e <.text+0x5c6f0>
   5cb80: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   5cb88: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5cb98: 15 06 91 ff 01 00 00 00      	jeq r6, 0x1, -0x6f <.text+0x5c708>
   5cba0: bd 21 91 ff 00 00 00 00      	jle r1, r2, -0x6f <.text+0x5c710>
   5cba8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5cbb8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5cbc0: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   5cbd0: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   5cbd8: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   5cbe8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   5cbf0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   5cbf8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   5cc00: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   5cc08: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   5cc10: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   5cc18: 7b 78 10 00 00 00 00 00      	stxdw [r8 + 0x10], r7
   5cc20: 7b 68 08 00 00 00 00 00      	stxdw [r8 + 0x8], r6
   5cc28: 7a 08 00 00 00 00 00 00      	stdw [r8 + 0x0], 0x0
   5cc30: 95 00 00 00 00 00 00 00      	exit
   5cc38: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5cc40: 7b 6a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r6
   5cc48: 55 04 ac ff 00 00 00 00      	jne r4, 0x0, -0x54 <.text+0x5c890>
   5cc50: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   5cc58: 18 06 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r6, 0x300007f00
   5cc68: 15 01 ab ff 00 00 00 00      	jeq r1, 0x0, -0x55 <.text+0x5c8a8>
   5cc70: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   5cc78: bf 26 00 00 00 00 00 00      	mov64 r6, r2
   5cc80: 7b 8a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r8
   5cc88: 18 01 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000007
   5cc98: 2d 16 a9 ff 00 00 00 00      	jgt r6, r1, -0x57 <.text+0x5c8c8>
   5cca0: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   5cca8: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   5ccb0: 85 10 00 00 76 8d 00 00      	call 0x8d76
   5ccb8: 85 10 00 00 26 4d 00 00      	call 0x4d26
   5ccc0: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   5ccc8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   5ccd0: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   5ccd8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   5cce0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5cce8: bd 53 43 00 00 00 00 00      	jle r3, r5, +0x43 <.text+0x5cde8>
   5ccf0: 15 04 44 00 00 00 00 00      	jeq r4, 0x0, +0x44 <.text+0x5cdf8>
   5ccf8: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   5cd08: 55 05 45 00 00 00 00 00      	jne r5, 0x0, +0x45 <.text+0x5ce18>
   5cd10: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5cd20: bd 21 47 00 00 00 00 00      	jle r1, r2, +0x47 <.text+0x5ce40>
   5cd28: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   5cd30: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5cd38: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   5cd40: 7b 1a 30 fc 00 00 00 00      	stxdw [r10 - 0x3d0], r1
   5cd48: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   5cd50: 85 10 00 00 06 9b 00 00      	call 0x9b06
   5cd58: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5cd60: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5cd68: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5cd70: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5cd78: 85 10 00 00 ee 4b ff ff      	call -0xb412
   5cd80: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   5cd88: 55 01 3d 00 02 00 00 00      	jne r1, 0x2, +0x3d <.text+0x5ce58>
   5cd90: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   5cd98: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   5cda0: 85 10 00 00 09 4d 00 00      	call 0x4d09
   5cda8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   5cdb0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5cdb8: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   5cdc0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   5cdc8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5cdd0: bd 21 56 00 00 00 00 00      	jle r1, r2, +0x56 <.text+0x5cf68>
   5cdd8: 79 a5 40 fc 00 00 00 00      	ldxdw r5, [r10 - 0x3c0]
   5cde0: 15 04 57 00 00 00 00 00      	jeq r4, 0x0, +0x57 <.text+0x5cf80>
   5cde8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   5cdf8: 55 02 58 00 00 00 00 00      	jne r2, 0x0, +0x58 <.text+0x5cfa0>
   5ce00: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5ce10: 55 06 59 00 01 00 00 00      	jne r6, 0x1, +0x59 <.text+0x5cfc0>
   5ce18: 2d 21 59 00 00 00 00 00      	jgt r1, r2, +0x59 <.text+0x5cfc8>
   5ce20: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   5ce28: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   5ce30: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   5ce40: 85 10 00 00 40 8d 00 00      	call 0x8d40
   5ce48: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5ce50: 79 a5 40 fc 00 00 00 00      	ldxdw r5, [r10 - 0x3c0]
   5ce58: 55 04 8b ff 00 00 00 00      	jne r4, 0x0, -0x75 <.text+0x5c998>
   5ce60: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5ce68: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   5ce78: 15 02 8a ff 00 00 00 00      	jeq r2, 0x0, -0x76 <.text+0x5c9b0>
   5ce80: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   5ce88: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5ce98: 15 06 89 ff 01 00 00 00      	jeq r6, 0x1, -0x77 <.text+0x5c9c8>
   5cea0: bd 21 89 ff 00 00 00 00      	jle r1, r2, -0x77 <.text+0x5c9d0>
   5cea8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5ceb8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5cec0: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   5ced0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   5ced8: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   5cee0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   5cee8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   5cef0: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   5cef8: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   5cf00: 05 00 44 00 00 00 00 00      	ja +0x44 <.text+0x5d008>
   5cf08: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5cf10: 55 04 bc ff 00 00 00 00      	jne r4, 0x0, -0x44 <.text+0x5cbd8>
   5cf18: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   5cf20: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   5cf30: 15 05 bb ff 00 00 00 00      	jeq r5, 0x0, -0x45 <.text+0x5cbf0>
   5cf38: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   5cf40: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5cf48: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5cf58: 2d 21 b9 ff 00 00 00 00      	jgt r1, r2, -0x47 <.text+0x5cc08>
   5cf60: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   5cf68: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   5cf70: 85 10 00 00 1e 8d 00 00      	call 0x8d1e
   5cf78: 7b 6a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r6
   5cf80: 85 10 00 00 cd 4c 00 00      	call 0x4ccd
   5cf88: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   5cf90: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   5cf98: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   5cfa0: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   5cfa8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5cfb0: bd 53 33 00 00 00 00 00      	jle r3, r5, +0x33 <.text+0x5d030>
   5cfb8: 79 a6 40 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3c0]
   5cfc0: 79 a8 50 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3b0]
   5cfc8: 15 04 34 00 00 00 00 00      	jeq r4, 0x0, +0x34 <.text+0x5d050>
   5cfd0: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   5cfe0: 55 05 35 00 00 00 00 00      	jne r5, 0x0, +0x35 <.text+0x5d070>
   5cfe8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5cff8: bd 21 37 00 00 00 00 00      	jle r1, r2, +0x37 <.text+0x5d098>
   5d000: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5d010: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5d018: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5d020: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   5d028: 7b 1a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r1
   5d030: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   5d038: 85 10 00 00 a9 9a 00 00      	call 0x9aa9
   5d040: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5d048: 15 01 30 00 00 00 00 00      	jeq r1, 0x0, +0x30 <.text+0x5d0b0>
   5d050: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5d058: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5d060: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5d068: 7b 1a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r1
   5d070: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5d078: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5d080: 05 00 2d 00 00 00 00 00      	ja +0x2d <.text+0x5d0d0>
   5d088: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5d090: 79 a5 40 fc 00 00 00 00      	ldxdw r5, [r10 - 0x3c0]
   5d098: 55 04 a9 ff 00 00 00 00      	jne r4, 0x0, -0x57 <.text+0x5ccc8>
   5d0a0: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5d0a8: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   5d0b8: 15 02 a8 ff 00 00 00 00      	jeq r2, 0x0, -0x58 <.text+0x5cce0>
   5d0c0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   5d0c8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5d0d8: 15 06 a7 ff 01 00 00 00      	jeq r6, 0x1, -0x59 <.text+0x5ccf8>
   5d0e0: bd 21 a7 ff 00 00 00 00      	jle r1, r2, -0x59 <.text+0x5cd00>
   5d0e8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5d0f8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5d100: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   5d108: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   5d110: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   5d118: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   5d120: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   5d128: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   5d130: 7b 75 10 00 00 00 00 00      	stxdw [r5 + 0x10], r7
   5d138: 7b 65 08 00 00 00 00 00      	stxdw [r5 + 0x8], r6
   5d140: 7a 05 00 00 00 00 00 00      	stdw [r5 + 0x0], 0x0
   5d148: 05 00 5c ff 00 00 00 00      	ja -0xa4 <.text+0x5cb10>
   5d150: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5d158: 79 a6 40 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3c0]
   5d160: 79 a8 50 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3b0]
   5d168: 55 04 cc ff 00 00 00 00      	jne r4, 0x0, -0x34 <.text+0x5ceb0>
   5d170: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   5d178: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   5d188: 15 05 cb ff 00 00 00 00      	jeq r5, 0x0, -0x35 <.text+0x5cec8>
   5d190: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   5d198: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5d1a0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5d1b0: 2d 21 c9 ff 00 00 00 00      	jgt r1, r2, -0x37 <.text+0x5cee0>
   5d1b8: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   5d1c0: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   5d1c8: 85 10 00 00 d3 8c 00 00      	call 0x8cd3
   5d1d0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5d1d8: 85 10 00 00 81 7a 00 00      	call 0x7a81
   5d1e0: 55 00 47 00 02 00 00 00      	jne r0, 0x2, +0x47 <.text+0x5d300>
   5d1e8: 7b 1a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r1
   5d1f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d1f8: 07 01 00 00 78 fc ff ff      	add64 r1, -0x388
   5d200: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d208: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d210: 85 10 00 00 6b 5a ff ff      	call -0xa595
   5d218: 79 a2 80 fc 00 00 00 00      	ldxdw r2, [r10 - 0x380]
   5d220: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   5d228: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x5d120>
   5d230: 7b 2a 10 fc 00 00 00 00      	stxdw [r10 - 0x3f0], r2
   5d238: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x5d150>
   5d240: 18 03 00 00 96 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb96
   5d250: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5d258: 85 10 00 00 56 4d ff ff      	call -0xb2aa
   5d260: 55 00 ba 02 02 00 00 00      	jne r0, 0x2, +0x2ba <.text+0x5e718>
   5d268: 7b 1a 10 fc 00 00 00 00      	stxdw [r10 - 0x3f0], r1
   5d270: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   5d278: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   5d280: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   5d288: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   5d290: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   5d298: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d2a0: 07 01 00 00 88 fc ff ff      	add64 r1, -0x378
   5d2a8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d2b0: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   5d2b8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d2c0: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   5d2c8: 85 10 00 00 bc 4f ff ff      	call -0xb044
   5d2d0: 79 a2 90 fc 00 00 00 00      	ldxdw r2, [r10 - 0x370]
   5d2d8: 79 a1 88 fc 00 00 00 00      	ldxdw r1, [r10 - 0x378]
   5d2e0: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x5d1d8>
   5d2e8: 7b 2a 08 fc 00 00 00 00      	stxdw [r10 - 0x3f8], r2
   5d2f0: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x5d208>
   5d2f8: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   5d308: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   5d310: 85 10 00 00 3f 4d ff ff      	call -0xb2c1
   5d318: 55 00 a3 02 02 00 00 00      	jne r0, 0x2, +0x2a3 <.text+0x5e718>
   5d320: 7b 1a 08 fc 00 00 00 00      	stxdw [r10 - 0x3f8], r1
   5d328: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   5d330: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   5d338: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   5d340: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   5d348: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   5d350: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d358: 07 01 00 00 98 fc ff ff      	add64 r1, -0x368
   5d360: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d368: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   5d370: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d378: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   5d380: 85 10 00 00 a5 4f ff ff      	call -0xb05b
   5d388: 79 a2 a0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x360]
   5d390: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   5d398: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x5d2b0>
   5d3a0: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   5d3b0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5d3b8: 85 10 00 00 2a 4d ff ff      	call -0xb2d6
   5d3c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d3c8: 55 00 10 02 02 00 00 00      	jne r0, 0x2, +0x210 <.text+0x5e330>
   5d3d0: 7b 2a 00 fc 00 00 00 00      	stxdw [r10 - 0x400], r2
   5d3d8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5d3e0: 15 01 2e 00 00 00 00 00      	jeq r1, 0x0, +0x2e <.text+0x5d438>
   5d3e8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5d3f0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5d3f8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5d400: 7b 1a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r1
   5d408: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5d410: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5d418: 05 00 3c 00 00 00 00 00      	ja +0x3c <.text+0x5d4e0>
   5d420: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   5d428: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   5d430: 85 10 00 00 37 4c 00 00      	call 0x4c37
   5d438: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   5d448: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5d450: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   5d458: 07 01 00 00 f6 ff ff ff      	add64 r1, -0xa
   5d460: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   5d468: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   5d470: bd 21 22 00 00 00 00 00      	jle r1, r2, +0x22 <.text+0x5d468>
   5d478: 15 04 23 00 00 00 00 00      	jeq r4, 0x0, +0x23 <.text+0x5d478>
   5d480: 18 01 00 00 f6 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff6
   5d490: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   5d498: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x5d388>
   5d4a0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   5d4a8: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   5d4b0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   5d4b8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   5d4c8: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   5d4d0: bd 21 a2 05 00 00 00 00      	jle r1, r2, +0x5a2 <.text+0x600c8>
   5d4d8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   5d4e8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   5d4f0: 18 02 00 00 71 75 6f 74 00 00 00 00 65 5f 6d 69      	lddw r2, 0x696d5f65746f7571
   5d500: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   5d508: 6a 01 08 00 6e 74 00 00      	sth [r1 + 0x8], 0x746e
   5d510: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   5d518: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   5d520: 7a 03 18 00 0a 00 00 00      	stdw [r3 + 0x18], 0xa
   5d528: 7a 03 08 00 0a 00 00 00      	stdw [r3 + 0x8], 0xa
   5d530: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   5d538: 7b 36 10 00 00 00 00 00      	stxdw [r6 + 0x10], r3
   5d540: 7b 46 08 00 00 00 00 00      	stxdw [r6 + 0x8], r4
   5d548: 7a 06 00 00 00 00 00 00      	stdw [r6 + 0x0], 0x0
   5d550: 05 00 db fe 00 00 00 00      	ja -0x125 <.text+0x5cb10>
   5d558: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5d560: 85 10 00 00 10 7a 00 00      	call 0x7a10
   5d568: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d570: 55 00 0a 00 02 00 00 00      	jne r0, 0x2, +0xa <.text+0x5d4a8>
   5d578: 7b 2a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r2
   5d580: 05 00 0f 00 00 00 00 00      	ja +0xf <.text+0x5d4e0>
   5d588: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   5d590: 55 04 dd ff 00 00 00 00      	jne r4, 0x0, -0x23 <.text+0x5d360>
   5d598: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   5d5a0: 18 01 00 00 f6 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff6
   5d5b0: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   5d5b8: 55 02 dc ff 00 00 00 00      	jne r2, 0x0, -0x24 <.text+0x5d380>
   5d5c0: 05 00 dc ff 00 00 00 00      	ja -0x24 <.text+0x5d388>
   5d5c8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5d5d0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   5d5e0: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   5d5e8: 85 10 00 00 e4 4c ff ff      	call -0xb31c
   5d5f0: 55 00 48 02 02 00 00 00      	jne r0, 0x2, +0x248 <.text+0x5e718>
   5d5f8: 7b 1a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r1
   5d600: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d608: 07 01 00 00 a8 fc ff ff      	add64 r1, -0x358
   5d610: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d618: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d620: 85 10 00 00 b7 59 ff ff      	call -0xa649
   5d628: 79 a2 b0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x350]
   5d630: 79 a1 a8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x358]
   5d638: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x5d530>
   5d640: 7b 2a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r2
   5d648: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x5d560>
   5d650: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   5d660: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   5d668: 85 10 00 00 d4 4c ff ff      	call -0xb32c
   5d670: 55 00 38 02 02 00 00 00      	jne r0, 0x2, +0x238 <.text+0x5e718>
   5d678: 7b 1a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r1
   5d680: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d688: 07 01 00 00 b8 fc ff ff      	add64 r1, -0x348
   5d690: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d698: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d6a0: 85 10 00 00 19 5a ff ff      	call -0xa5e7
   5d6a8: 79 a2 c0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x340]
   5d6b0: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   5d6b8: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x5d5b0>
   5d6c0: 7b 2a e8 fb 00 00 00 00      	stxdw [r10 - 0x418], r2
   5d6c8: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x5d5e0>
   5d6d0: 18 03 00 00 89 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb89
   5d6e0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5d6e8: 85 10 00 00 c4 4c ff ff      	call -0xb33c
   5d6f0: 55 00 28 02 02 00 00 00      	jne r0, 0x2, +0x228 <.text+0x5e718>
   5d6f8: 7b 1a e8 fb 00 00 00 00      	stxdw [r10 - 0x418], r1
   5d700: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d708: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   5d710: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d718: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d720: 85 10 00 00 3f 45 ff ff      	call -0xbac1
   5d728: 79 a2 d0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x330]
   5d730: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   5d738: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x5d650>
   5d740: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   5d750: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   5d758: 85 10 00 00 b6 4c ff ff      	call -0xb34a
   5d760: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d768: 55 00 9c 01 02 00 00 00      	jne r0, 0x2, +0x19c <.text+0x5e330>
   5d770: 7b 2a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r2
   5d778: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5d780: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5d6a0>
   5d788: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5d790: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5d798: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5d7a0: 7b 1a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r1
   5d7a8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5d7b0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5d7b8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x5d708>
   5d7c0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5d7c8: 85 10 00 00 c3 79 00 00      	call 0x79c3
   5d7d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d7d8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5d6d0>
   5d7e0: 7b 2a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r2
   5d7e8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x5d708>
   5d7f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5d7f8: 18 03 00 00 e8 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbe8
   5d808: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   5d810: 85 10 00 00 9f 4c ff ff      	call -0xb361
   5d818: 55 00 03 02 02 00 00 00      	jne r0, 0x2, +0x203 <.text+0x5e718>
   5d820: 7b 1a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r1
   5d828: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   5d830: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   5d838: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   5d840: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   5d848: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   5d850: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5d858: 07 01 00 00 d8 fc ff ff      	add64 r1, -0x328
   5d860: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5d868: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   5d870: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5d878: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   5d880: 85 10 00 00 d0 4e ff ff      	call -0xb130
   5d888: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   5d890: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   5d898: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x5d7b0>
   5d8a0: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   5d8b0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5d8b8: 85 10 00 00 8a 4c ff ff      	call -0xb376
   5d8c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d8c8: 55 00 70 01 02 00 00 00      	jne r0, 0x2, +0x170 <.text+0x5e330>
   5d8d0: 7b 2a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r2
   5d8d8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5d8e0: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x5d838>
   5d8e8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5d8f0: 7b 2a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r2
   5d8f8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5d900: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5d908: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5d910: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5d918: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x5d860>
   5d920: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5d928: 7b 2a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r2
   5d930: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5d938: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5d940: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5d948: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5d950: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x5d8d0>
   5d958: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5d960: 85 10 00 00 90 79 00 00      	call 0x7990
   5d968: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d970: 55 00 54 00 02 00 00 00      	jne r0, 0x2, +0x54 <.text+0x5daf8>
   5d978: 7b 2a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r2
   5d980: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5d988: 85 10 00 00 8b 79 00 00      	call 0x798b
   5d990: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5d998: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5d890>
   5d9a0: 7b 2a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r2
   5d9a8: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5d910>
   5d9b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5d9b8: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   5d9c8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5d9d0: 85 10 00 00 67 4c ff ff      	call -0xb399
   5d9d8: 55 00 cb 01 02 00 00 00      	jne r0, 0x2, +0x1cb <.text+0x5e718>
   5d9e0: 7b 1a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r1
   5d9e8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5d9f0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5d910>
   5d9f8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5da00: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5da08: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5da10: 7b 1a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r1
   5da18: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5da20: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5da28: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x5d978>
   5da30: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5da38: 85 10 00 00 75 79 00 00      	call 0x7975
   5da40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5da48: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5d940>
   5da50: 7b 2a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r2
   5da58: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x5d978>
   5da60: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5da68: 18 03 00 00 44 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc44
   5da78: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   5da80: 85 10 00 00 51 4c ff ff      	call -0xb3af
   5da88: 55 00 b5 01 02 00 00 00      	jne r0, 0x2, +0x1b5 <.text+0x5e718>
   5da90: 7b 1a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r1
   5da98: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   5daa0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   5daa8: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   5dab0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   5dab8: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   5dac0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5dac8: 07 01 00 00 e8 fc ff ff      	add64 r1, -0x318
   5dad0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5dad8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   5dae0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5dae8: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   5daf0: 85 10 00 00 b7 4e ff ff      	call -0xb149
   5daf8: 79 a8 f0 fc 00 00 00 00      	ldxdw r8, [r10 - 0x310]
   5db00: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   5db08: 15 01 07 00 02 00 00 00      	jeq r1, 0x2, +0x7 <.text+0x5da28>
   5db10: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   5db18: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   5db28: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   5db30: 85 10 00 00 3b 4c ff ff      	call -0xb3c5
   5db38: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   5db40: 55 00 24 00 02 00 00 00      	jne r0, 0x2, +0x24 <.text+0x5db48>
   5db48: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5db50: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x5daa8>
   5db58: 79 97 00 00 00 00 00 00      	ldxdw r7, [r9 + 0x0]
   5db60: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   5db68: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5db70: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5db78: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5db80: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5db88: 15 01 0b 00 00 00 00 00      	jeq r1, 0x0, +0xb <.text+0x5dac8>
   5db90: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5db98: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   5dba0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5dba8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5dbb0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5dbb8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5dbc0: 05 00 1e 00 00 00 00 00      	ja +0x1e <.text+0x5db98>
   5dbc8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5dbd0: 85 10 00 00 42 79 00 00      	call 0x7942
   5dbd8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   5dbe0: 55 00 54 00 02 00 00 00      	jne r0, 0x2, +0x54 <.text+0x5dd68>
   5dbe8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5dbf0: 85 10 00 00 3e 79 00 00      	call 0x793e
   5dbf8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5dc00: 55 00 0e 00 02 00 00 00      	jne r0, 0x2, +0xe <.text+0x5db58>
   5dc08: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   5dc10: 05 00 1c 00 00 00 00 00      	ja +0x1c <.text+0x5dbd8>
   5dc18: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5dc20: 18 03 00 00 31 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade31
   5dc30: b7 04 00 00 1e 00 00 00      	mov64 r4, 0x1e
   5dc38: 85 10 00 00 1a 4c ff ff      	call -0xb3e6
   5dc40: 55 00 7e 01 02 00 00 00      	jne r0, 0x2, +0x17e <.text+0x5e718>
   5dc48: 7b 1a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r1
   5dc50: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5dc58: 55 01 98 ff 00 00 00 00      	jne r1, 0x0, -0x68 <.text+0x5d800>
   5dc60: 05 00 a3 ff 00 00 00 00      	ja -0x5d <.text+0x5d860>
   5dc68: 7b 86 10 00 00 00 00 00      	stxdw [r6 + 0x10], r8
   5dc70: 05 00 79 01 00 00 00 00      	ja +0x179 <.text+0x5e720>
   5dc78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5dc80: 18 03 00 00 6c de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade6c
   5dc90: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5dc98: 85 10 00 00 0e 4c ff ff      	call -0xb3f2
   5dca0: 55 00 72 01 02 00 00 00      	jne r0, 0x2, +0x172 <.text+0x5e718>
   5dca8: 7b 1a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r1
   5dcb0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5dcb8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5dbd8>
   5dcc0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5dcc8: 7b 2a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r2
   5dcd0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5dcd8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5dce0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5dce8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5dcf0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5dc48>
   5dcf8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5dd00: 85 10 00 00 1c 79 00 00      	call 0x791c
   5dd08: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5dd10: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5dc08>
   5dd18: 7b 2a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r2
   5dd20: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5dc88>
   5dd28: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5dd30: 18 03 00 00 84 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade84
   5dd40: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   5dd48: 85 10 00 00 f8 4b ff ff      	call -0xb408
   5dd50: 55 00 5c 01 02 00 00 00      	jne r0, 0x2, +0x15c <.text+0x5e718>
   5dd58: 7b 1a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r1
   5dd60: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5dd68: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5dc88>
   5dd70: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5dd78: 7b 2a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r2
   5dd80: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5dd88: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5dd90: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5dd98: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5dda0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5dcf8>
   5dda8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5ddb0: 85 10 00 00 06 79 00 00      	call 0x7906
   5ddb8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5ddc0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5dcb8>
   5ddc8: 7b 2a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r2
   5ddd0: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5dd38>
   5ddd8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5dde0: 18 03 00 00 fa db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbfa
   5ddf0: b7 04 00 00 14 00 00 00      	mov64 r4, 0x14
   5ddf8: 85 10 00 00 e2 4b ff ff      	call -0xb41e
   5de00: 55 00 46 01 02 00 00 00      	jne r0, 0x2, +0x146 <.text+0x5e718>
   5de08: 7b 1a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r1
   5de10: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5de18: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5dd38>
   5de20: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5de28: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   5de30: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5de38: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5de40: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5de48: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5de50: 05 00 19 00 00 00 00 00      	ja +0x19 <.text+0x5de00>
   5de58: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5de60: 85 10 00 00 f0 78 00 00      	call 0x78f0
   5de68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5de70: 55 00 0d 00 02 00 00 00      	jne r0, 0x2, +0xd <.text+0x5ddc0>
   5de78: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   5de80: 05 00 1b 00 00 00 00 00      	ja +0x1b <.text+0x5de40>
   5de88: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5de90: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   5de98: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   5dea8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5deb0: 85 10 00 00 cb 4b ff ff      	call -0xb435
   5deb8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   5dec0: 55 00 5b 00 02 00 00 00      	jne r0, 0x2, +0x5b <.text+0x5e080>
   5dec8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5ded0: 55 01 97 ff 00 00 00 00      	jne r1, 0x0, -0x69 <.text+0x5da70>
   5ded8: 05 00 a1 ff 00 00 00 00      	ja -0x5f <.text+0x5dac8>
   5dee0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5dee8: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   5def8: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   5df00: 85 10 00 00 c1 4b ff ff      	call -0xb43f
   5df08: 55 00 25 01 02 00 00 00      	jne r0, 0x2, +0x125 <.text+0x5e718>
   5df10: 7b 1a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r1
   5df18: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5df20: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5de40>
   5df28: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5df30: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   5df38: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5df40: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5df48: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5df50: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5df58: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5deb0>
   5df60: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5df68: 85 10 00 00 cf 78 00 00      	call 0x78cf
   5df70: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5df78: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5de70>
   5df80: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   5df88: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5def0>
   5df90: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5df98: 18 03 00 00 52 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd52
   5dfa8: b7 04 00 00 19 00 00 00      	mov64 r4, 0x19
   5dfb0: 85 10 00 00 ab 4b ff ff      	call -0xb455
   5dfb8: 55 00 0f 01 02 00 00 00      	jne r0, 0x2, +0x10f <.text+0x5e718>
   5dfc0: 7b 1a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r1
   5dfc8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5dfd0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5def0>
   5dfd8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5dfe0: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   5dfe8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5dff0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5dff8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5e000: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5e008: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5df60>
   5e010: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e018: 85 10 00 00 b9 78 00 00      	call 0x78b9
   5e020: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e028: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5df20>
   5e030: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   5e038: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5dfa0>
   5e040: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e048: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   5e058: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   5e060: 85 10 00 00 95 4b ff ff      	call -0xb46b
   5e068: 55 00 f9 00 02 00 00 00      	jne r0, 0x2, +0xf9 <.text+0x5e718>
   5e070: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   5e078: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5e080: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5dfa0>
   5e088: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5e090: 7b 2a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r2
   5e098: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5e0a0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5e0a8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5e0b0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5e0b8: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5e010>
   5e0c0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e0c8: 85 10 00 00 a3 78 00 00      	call 0x78a3
   5e0d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e0d8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5dfd0>
   5e0e0: 7b 2a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r2
   5e0e8: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5e050>
   5e0f0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e0f8: 18 03 00 00 92 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade92
   5e108: b7 04 00 00 22 00 00 00      	mov64 r4, 0x22
   5e110: 85 10 00 00 7f 4b ff ff      	call -0xb481
   5e118: 55 00 e3 00 02 00 00 00      	jne r0, 0x2, +0xe3 <.text+0x5e718>
   5e120: 7b 1a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r1
   5e128: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5e130: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5e050>
   5e138: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5e140: 7b 2a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r2
   5e148: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5e150: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5e158: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5e160: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5e168: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5e0d0>
   5e170: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e178: 85 10 00 00 8d 78 00 00      	call 0x788d
   5e180: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e188: 55 00 04 00 02 00 00 00      	jne r0, 0x2, +0x4 <.text+0x5e090>
   5e190: 7b 2a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r2
   5e198: 05 00 12 00 00 00 00 00      	ja +0x12 <.text+0x5e110>
   5e1a0: 7b 76 10 00 00 00 00 00      	stxdw [r6 + 0x10], r7
   5e1a8: 05 00 d2 00 00 00 00 00      	ja +0xd2 <.text+0x5e720>
   5e1b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e1b8: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   5e1c8: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   5e1d0: 85 10 00 00 67 4b ff ff      	call -0xb499
   5e1d8: 55 00 cb 00 02 00 00 00      	jne r0, 0x2, +0xcb <.text+0x5e718>
   5e1e0: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   5e1e8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5e1f0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5e110>
   5e1f8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   5e200: 7b 2a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r2
   5e208: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5e210: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5e218: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5e220: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5e228: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x5e180>
   5e230: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e238: 85 10 00 00 75 78 00 00      	call 0x7875
   5e240: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e248: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5e140>
   5e250: 7b 2a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r2
   5e258: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x5e1c0>
   5e260: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e268: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   5e278: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   5e280: 85 10 00 00 51 4b ff ff      	call -0xb4af
   5e288: 55 00 b5 00 02 00 00 00      	jne r0, 0x2, +0xb5 <.text+0x5e718>
   5e290: 7b 1a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r1
   5e298: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   5e2a0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x5e1c0>
   5e2a8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   5e2b0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   5e2b8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5e2c0: 7b 1a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r1
   5e2c8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5e2d0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5e2d8: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x5e228>
   5e2e0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e2e8: 85 10 00 00 5f 78 00 00      	call 0x785f
   5e2f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e2f8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5e1f0>
   5e300: 7b 2a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r2
   5e308: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x5e228>
   5e310: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e318: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   5e328: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   5e330: 85 10 00 00 3b 4b ff ff      	call -0xb4c5
   5e338: 55 00 9f 00 02 00 00 00      	jne r0, 0x2, +0x9f <.text+0x5e718>
   5e340: 7b 1a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r1
   5e348: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5e350: 07 01 00 00 f8 fc ff ff      	add64 r1, -0x308
   5e358: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5e360: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   5e368: 85 10 00 00 c0 58 ff ff      	call -0xa740
   5e370: 79 a2 00 fd 00 00 00 00      	ldxdw r2, [r10 - 0x300]
   5e378: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   5e380: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x5e298>
   5e388: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   5e398: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   5e3a0: 85 10 00 00 2d 4b ff ff      	call -0xb4d3
   5e3a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e3b0: 55 00 13 00 02 00 00 00      	jne r0, 0x2, +0x13 <.text+0x5e330>
   5e3b8: 7b 2a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r2
   5e3c0: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   5e3c8: 7b 7a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r7
   5e3d0: 15 03 11 00 00 00 00 00      	jeq r3, 0x0, +0x11 <.text+0x5e340>
   5e3d8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5e3e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e3e8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   5e3f0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   5e3f8: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   5e400: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   5e408: 7b 1a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r1
   5e410: 15 03 0e 00 00 00 00 00      	jeq r3, 0x0, +0xe <.text+0x5e368>
   5e418: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   5e420: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   5e428: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   5e430: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   5e438: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   5e440: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   5e448: 05 00 14 00 00 00 00 00      	ja +0x14 <.text+0x5e3d0>
   5e450: 7b 26 10 00 00 00 00 00      	stxdw [r6 + 0x10], r2
   5e458: 05 00 7c 00 00 00 00 00      	ja +0x7c <.text+0x5e720>
   5e460: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e468: 85 10 00 00 2f 78 00 00      	call 0x782f
   5e470: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e478: 55 00 6d 00 02 00 00 00      	jne r0, 0x2, +0x6d <.text+0x5e6c8>
   5e480: 7b 2a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r2
   5e488: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   5e490: 85 10 00 00 2a 78 00 00      	call 0x782a
   5e498: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e4a0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x5e398>
   5e4a8: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   5e4b0: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x5e3d0>
   5e4b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e4c0: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   5e4d0: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   5e4d8: 85 10 00 00 06 4b ff ff      	call -0xb4fa
   5e4e0: 55 00 6a 00 02 00 00 00      	jne r0, 0x2, +0x6a <.text+0x5e718>
   5e4e8: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   5e4f0: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   5e500: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e508: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   5e510: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e518: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   5e520: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e528: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   5e530: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e538: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   5e540: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   5e548: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   5e550: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   5e558: 07 07 00 00 08 fd ff ff      	add64 r7, -0x2f8
   5e560: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e568: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   5e570: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5e578: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   5e580: 85 10 00 00 00 98 00 00      	call 0x9800
   5e588: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   5e590: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e598: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e5a0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e5a8: 7b 2a 50 fd 00 00 00 00      	stxdw [r10 - 0x2b0], r2
   5e5b0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e5b8: 7b 2a 48 fd 00 00 00 00      	stxdw [r10 - 0x2b8], r2
   5e5c0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e5c8: 7b 2a 40 fd 00 00 00 00      	stxdw [r10 - 0x2c0], r2
   5e5d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e5d8: 7b 1a 38 fd 00 00 00 00      	stxdw [r10 - 0x2c8], r1
   5e5e0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e5e8: 07 02 00 00 38 fd ff ff      	add64 r2, -0x2c8
   5e5f0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5e5f8: 85 10 00 00 ae 58 ff ff      	call -0xa752
   5e600: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x5e528>
   5e608: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5e610: 85 10 00 00 fa 77 00 00      	call 0x77fa
   5e618: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e620: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e628: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   5e638: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5e640: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x5e5e8>
   5e648: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   5e650: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e658: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e660: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e668: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   5e670: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e678: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   5e680: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e688: 7b 2a 60 fd 00 00 00 00      	stxdw [r10 - 0x2a0], r2
   5e690: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e698: 7b 1a 58 fd 00 00 00 00      	stxdw [r10 - 0x2a8], r1
   5e6a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5e6a8: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   5e6b0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e6b8: 07 02 00 00 58 fd ff ff      	add64 r2, -0x2a8
   5e6c0: 85 10 00 00 95 58 ff ff      	call -0xa76b
   5e6c8: 15 00 09 00 00 00 00 00      	jeq r0, 0x0, +0x9 <.text+0x5e5f8>
   5e6d0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5e6d8: 85 10 00 00 e1 77 00 00      	call 0x77e1
   5e6e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e6e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e6f0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   5e700: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   5e708: 85 10 00 00 c0 4a ff ff      	call -0xb540
   5e710: 05 00 5b 00 00 00 00 00      	ja +0x5b <.text+0x5e8d0>
   5e718: 7b 8a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r8
   5e720: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   5e728: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5e730: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e738: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e740: 7b 2a 90 fd 00 00 00 00      	stxdw [r10 - 0x270], r2
   5e748: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e750: 7b 2a 88 fd 00 00 00 00      	stxdw [r10 - 0x278], r2
   5e758: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e760: 7b 2a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r2
   5e768: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e770: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   5e778: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5e780: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   5e788: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e790: 07 02 00 00 78 fd ff ff      	add64 r2, -0x288
   5e798: 85 10 00 00 7a 58 ff ff      	call -0xa786
   5e7a0: 15 00 16 00 00 00 00 00      	jeq r0, 0x0, +0x16 <.text+0x5e738>
   5e7a8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5e7b0: 85 10 00 00 c6 77 00 00      	call 0x77c6
   5e7b8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e7c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e7c8: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   5e7d8: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   5e7e0: 05 00 3f 00 00 00 00 00      	ja +0x3f <.text+0x5e8c0>
   5e7e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e7f0: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   5e800: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   5e808: 85 10 00 00 a0 4a ff ff      	call -0xb560
   5e810: 55 00 04 00 02 00 00 00      	jne r0, 0x2, +0x4 <.text+0x5e718>
   5e818: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   5e820: 7b 1a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r1
   5e828: 55 03 7d ff 00 00 00 00      	jne r3, 0x0, -0x83 <.text+0x5e2f8>
   5e830: 05 00 8a ff 00 00 00 00      	ja -0x76 <.text+0x5e368>
   5e838: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   5e840: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   5e848: 7a 06 00 00 00 00 00 00      	stdw [r6 + 0x0], 0x0
   5e850: 05 00 7b fc 00 00 00 00      	ja -0x385 <.text+0x5cb10>
   5e858: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   5e860: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5e868: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e870: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e878: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   5e880: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e888: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   5e890: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e898: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   5e8a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e8a8: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   5e8b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5e8b8: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   5e8c0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e8c8: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   5e8d0: 85 10 00 00 53 58 ff ff      	call -0xa7ad
   5e8d8: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x5e800>
   5e8e0: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5e8e8: 85 10 00 00 9f 77 00 00      	call 0x779f
   5e8f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e8f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e900: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   5e910: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   5e918: 05 00 18 00 00 00 00 00      	ja +0x18 <.text+0x5e8c0>
   5e920: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   5e928: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e930: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e938: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5e940: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   5e948: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5e950: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   5e958: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5e960: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   5e968: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5e970: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   5e978: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5e980: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   5e988: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5e990: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   5e998: 85 10 00 00 3a 58 ff ff      	call -0xa7c6
   5e9a0: 15 00 0d 00 00 00 00 00      	jeq r0, 0x0, +0xd <.text+0x5e8f0>
   5e9a8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5e9b0: 85 10 00 00 86 77 00 00      	call 0x7786
   5e9b8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5e9c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5e9c8: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   5e9d8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5e9e0: 85 10 00 00 65 4a ff ff      	call -0xb59b
   5e9e8: 79 a6 40 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3c0]
   5e9f0: 7b 06 08 00 00 00 00 00      	stxdw [r6 + 0x8], r0
   5e9f8: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   5ea00: 7a 06 00 00 00 00 00 00      	stdw [r6 + 0x0], 0x0
   5ea08: 05 00 44 fc 00 00 00 00      	ja -0x3bc <.text+0x5cb10>
   5ea10: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   5ea18: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5ea20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ea28: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5ea30: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   5ea38: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5ea40: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   5ea48: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5ea50: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   5ea58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ea60: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   5ea68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5ea70: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   5ea78: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5ea80: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   5ea88: 85 10 00 00 1c 58 ff ff      	call -0xa7e4
   5ea90: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x5e9b8>
   5ea98: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   5eaa0: 85 10 00 00 68 77 00 00      	call 0x7768
   5eaa8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5eab0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5eab8: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   5eac8: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   5ead0: 05 00 83 02 00 00 00 00      	ja +0x283 <.text+0x5fdd0>
   5ead8: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   5eae0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5eae8: 15 01 79 02 00 00 00 00      	jeq r1, 0x0, +0x279 <.text+0x5fd98>
   5eaf0: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   5eaf8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5eb00: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   5eb08: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5eb10: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   5eb18: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   5eb28: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   5eb30: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   5eb38: 85 10 00 00 ff ff ff ff      	call -0x1
   5eb40: 55 00 ee 02 00 00 00 00      	jne r0, 0x0, +0x2ee <.text+0x60198>
   5eb48: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   5eb50: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   5eb58: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   5eb60: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   5eb68: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   5eb70: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   5eb78: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   5eb80: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   5eb88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5eb90: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5eb98: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   5eba0: 5d 93 6f 02 00 00 00 00      	jne r3, r9, +0x26f <.text+0x5fe00>
   5eba8: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   5ebb0: 5d 83 6d 02 00 00 00 00      	jne r3, r8, +0x26d <.text+0x5fe00>
   5ebb8: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   5ebc0: 5d 73 6b 02 00 00 00 00      	jne r3, r7, +0x26b <.text+0x5fe00>
   5ebc8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5ebd0: 5d 62 69 02 00 00 00 00      	jne r2, r6, +0x269 <.text+0x5fe00>
   5ebd8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5ebe0: 15 01 84 02 00 00 00 00      	jeq r1, 0x0, +0x284 <.text+0x5fee8>
   5ebe8: 79 a2 28 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d8]
   5ebf0: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   5ebf8: 7b 1a 38 fb 00 00 00 00      	stxdw [r10 - 0x4c8], r1
   5ec00: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   5ec08: 7b 1a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r1
   5ec10: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   5ec18: 7b 1a 48 fb 00 00 00 00      	stxdw [r10 - 0x4b8], r1
   5ec20: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   5ec28: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ec30: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5ec38: 7b 3a 30 fb 00 00 00 00      	stxdw [r10 - 0x4d0], r3
   5ec40: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   5ec48: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   5ec50: 79 29 28 00 00 00 00 00      	ldxdw r9, [r2 + 0x28]
   5ec58: 79 16 00 00 00 00 00 00      	ldxdw r6, [r1 + 0x0]
   5ec60: 5d 69 81 02 00 00 00 00      	jne r9, r6, +0x281 <.text+0x5ff50>
   5ec68: 79 a1 48 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b8]
   5ec70: 5d 81 7f 02 00 00 00 00      	jne r1, r8, +0x27f <.text+0x5ff50>
   5ec78: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   5ec80: 5d 71 7d 02 00 00 00 00      	jne r1, r7, +0x27d <.text+0x5ff50>
   5ec88: 79 a1 38 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c8]
   5ec90: 79 a2 30 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4d0]
   5ec98: 5d 21 7a 02 00 00 00 00      	jne r1, r2, +0x27a <.text+0x5ff50>
   5eca0: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5eca8: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   5ecb0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ecb8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5ecc0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5ecc8: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   5ecd0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5ecd8: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   5ece8: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   5ecf0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5ecf8: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   5ed00: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   5ed08: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   5ed10: 7b 4a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r4
   5ed18: 7b 3a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r3
   5ed20: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   5ed28: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   5ed30: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   5ed38: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   5ed40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5ed48: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   5ed50: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5ed58: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   5ed60: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5ed68: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   5ed70: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   5ed78: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   5ed80: 85 10 00 00 ff ff ff ff      	call -0x1
   5ed88: 55 00 a5 02 00 00 00 00      	jne r0, 0x0, +0x2a5 <.text+0x60198>
   5ed90: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   5ed98: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   5eda0: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   5eda8: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   5edb0: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   5edb8: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   5edc0: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   5edc8: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   5edd0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5edd8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5ede0: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   5ede8: 5d 93 66 02 00 00 00 00      	jne r3, r9, +0x266 <.text+0x60000>
   5edf0: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   5edf8: 5d 83 64 02 00 00 00 00      	jne r3, r8, +0x264 <.text+0x60000>
   5ee00: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   5ee08: 5d 73 62 02 00 00 00 00      	jne r3, r7, +0x262 <.text+0x60000>
   5ee10: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5ee18: 5d 62 60 02 00 00 00 00      	jne r2, r6, +0x260 <.text+0x60000>
   5ee20: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5ee28: 15 01 69 02 00 00 00 00      	jeq r1, 0x0, +0x269 <.text+0x60058>
   5ee30: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   5ee38: 79 16 20 00 00 00 00 00      	ldxdw r6, [r1 + 0x20]
   5ee40: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5ee48: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   5ee50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5ee58: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5ee60: 85 10 00 00 e5 54 ff ff      	call -0xab1b
   5ee68: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5ee70: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   5ee78: 79 62 18 00 00 00 00 00      	ldxdw r2, [r6 + 0x18]
   5ee80: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   5ee88: 5d 34 65 02 00 00 00 00      	jne r4, r3, +0x265 <.text+0x60098>
   5ee90: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5ee98: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   5eea0: 5d 34 62 02 00 00 00 00      	jne r4, r3, +0x262 <.text+0x60098>
   5eea8: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5eeb0: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   5eeb8: 5d 34 5f 02 00 00 00 00      	jne r4, r3, +0x25f <.text+0x60098>
   5eec0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5eec8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5eed0: 5d 12 5c 02 00 00 00 00      	jne r2, r1, +0x25c <.text+0x60098>
   5eed8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5eee0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5eee8: 85 10 00 00 fe 51 ff ff      	call -0xae02
   5eef0: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   5eef8: 79 19 60 00 00 00 00 00      	ldxdw r9, [r1 + 0x60]
   5ef00: 79 18 58 00 00 00 00 00      	ldxdw r8, [r1 + 0x58]
   5ef08: 79 17 50 00 00 00 00 00      	ldxdw r7, [r1 + 0x50]
   5ef10: 79 16 48 00 00 00 00 00      	ldxdw r6, [r1 + 0x48]
   5ef18: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   5ef20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ef28: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5ef30: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   5ef38: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5ef40: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   5ef48: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5ef50: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   5ef58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ef60: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   5ef68: 79 a1 f8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x208]
   5ef70: 5d 16 53 02 00 00 00 00      	jne r6, r1, +0x253 <.text+0x600f0>
   5ef78: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   5ef80: 5d 17 51 02 00 00 00 00      	jne r7, r1, +0x251 <.text+0x600f0>
   5ef88: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   5ef90: 5d 18 4f 02 00 00 00 00      	jne r8, r1, +0x24f <.text+0x600f0>
   5ef98: 79 a1 10 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f0]
   5efa0: 5d 19 4d 02 00 00 00 00      	jne r9, r1, +0x24d <.text+0x600f0>
   5efa8: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5efb0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   5efb8: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   5efc0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5efc8: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   5efd0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5efd8: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   5efe0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5efe8: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   5eff0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5eff8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   5f000: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   5f008: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   5f010: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5f018: 85 10 00 00 ae 54 ff ff      	call -0xab52
   5f020: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5f028: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f030: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   5f038: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f040: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   5f048: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f050: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   5f058: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f060: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   5f068: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f070: 07 01 00 00 18 fe ff ff      	add64 r1, -0x1e8
   5f078: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5f080: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   5f088: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   5f090: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   5f098: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5f0a0: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   5f0a8: 85 10 00 00 7a 6d 00 00      	call 0x6d7a
   5f0b0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5f0b8: 85 10 00 00 c4 51 ff ff      	call -0xae3c
   5f0c0: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   5f0c8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5f0d0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f0d8: 79 29 18 00 00 00 00 00      	ldxdw r9, [r2 + 0x18]
   5f0e0: 79 28 10 00 00 00 00 00      	ldxdw r8, [r2 + 0x10]
   5f0e8: 79 27 08 00 00 00 00 00      	ldxdw r7, [r2 + 0x8]
   5f0f0: 79 26 00 00 00 00 00 00      	ldxdw r6, [r2 + 0x0]
   5f0f8: 79 a2 18 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1e8]
   5f100: 5d 26 42 02 00 00 00 00      	jne r6, r2, +0x242 <.text+0x601f8>
   5f108: 79 a2 20 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1e0]
   5f110: 5d 27 40 02 00 00 00 00      	jne r7, r2, +0x240 <.text+0x601f8>
   5f118: 79 a2 28 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1d8]
   5f120: 5d 28 3e 02 00 00 00 00      	jne r8, r2, +0x23e <.text+0x601f8>
   5f128: 79 a2 30 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1d0]
   5f130: 5d 29 3c 02 00 00 00 00      	jne r9, r2, +0x23c <.text+0x601f8>
   5f138: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f140: 15 01 50 02 00 00 00 00      	jeq r1, 0x0, +0x250 <.text+0x602a8>
   5f148: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   5f150: 79 16 20 00 00 00 00 00      	ldxdw r6, [r1 + 0x20]
   5f158: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f160: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5f168: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   5f170: 85 10 00 00 83 54 ff ff      	call -0xab7d
   5f178: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5f180: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   5f188: 79 62 18 00 00 00 00 00      	ldxdw r2, [r6 + 0x18]
   5f190: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   5f198: 5d 34 03 02 00 00 00 00      	jne r4, r3, +0x203 <.text+0x60098>
   5f1a0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5f1a8: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   5f1b0: 5d 34 00 02 00 00 00 00      	jne r4, r3, +0x200 <.text+0x60098>
   5f1b8: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5f1c0: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   5f1c8: 5d 34 fd 01 00 00 00 00      	jne r4, r3, +0x1fd <.text+0x60098>
   5f1d0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f1d8: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5f1e0: 5d 12 fa 01 00 00 00 00      	jne r2, r1, +0x1fa <.text+0x60098>
   5f1e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f1f0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5f1f8: 85 10 00 00 9c 51 ff ff      	call -0xae64
   5f200: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   5f208: 79 19 60 00 00 00 00 00      	ldxdw r9, [r1 + 0x60]
   5f210: 79 18 58 00 00 00 00 00      	ldxdw r8, [r1 + 0x58]
   5f218: 79 17 50 00 00 00 00 00      	ldxdw r7, [r1 + 0x50]
   5f220: 79 16 48 00 00 00 00 00      	ldxdw r6, [r1 + 0x48]
   5f228: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   5f230: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f238: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5f240: 7b 2a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r2
   5f248: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f250: 7b 2a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r2
   5f258: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f260: 7b 2a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r2
   5f268: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f270: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   5f278: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   5f280: 5d 16 30 02 00 00 00 00      	jne r6, r1, +0x230 <.text+0x602e8>
   5f288: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   5f290: 5d 17 2e 02 00 00 00 00      	jne r7, r1, +0x22e <.text+0x602e8>
   5f298: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   5f2a0: 5d 18 2c 02 00 00 00 00      	jne r8, r1, +0x22c <.text+0x602e8>
   5f2a8: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   5f2b0: 5d 19 2a 02 00 00 00 00      	jne r9, r1, +0x22a <.text+0x602e8>
   5f2b8: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   5f2c0: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   5f2c8: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5f2d0: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   5f2d8: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5f2e0: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   5f2e8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5f2f0: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   5f2f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f300: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   5f308: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   5f310: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   5f318: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5f320: 85 10 00 00 4d 54 ff ff      	call -0xabb3
   5f328: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5f330: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f338: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   5f340: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f348: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   5f350: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f358: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   5f360: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f368: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   5f370: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f378: 07 01 00 00 58 fe ff ff      	add64 r1, -0x1a8
   5f380: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5f388: 07 02 00 00 38 fe ff ff      	add64 r2, -0x1c8
   5f390: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   5f398: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   5f3a0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5f3a8: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   5f3b0: 85 10 00 00 19 6d 00 00      	call 0x6d19
   5f3b8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5f3c0: 85 10 00 00 63 51 ff ff      	call -0xae9d
   5f3c8: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   5f3d0: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5f3d8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f3e0: 79 29 18 00 00 00 00 00      	ldxdw r9, [r2 + 0x18]
   5f3e8: 79 28 10 00 00 00 00 00      	ldxdw r8, [r2 + 0x10]
   5f3f0: 79 27 08 00 00 00 00 00      	ldxdw r7, [r2 + 0x8]
   5f3f8: 79 26 00 00 00 00 00 00      	ldxdw r6, [r2 + 0x0]
   5f400: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   5f408: 5d 26 14 02 00 00 00 00      	jne r6, r2, +0x214 <.text+0x60390>
   5f410: 79 a2 60 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a0]
   5f418: 5d 27 12 02 00 00 00 00      	jne r7, r2, +0x212 <.text+0x60390>
   5f420: 79 a2 68 fe 00 00 00 00      	ldxdw r2, [r10 - 0x198]
   5f428: 5d 28 10 02 00 00 00 00      	jne r8, r2, +0x210 <.text+0x60390>
   5f430: 79 a2 70 fe 00 00 00 00      	ldxdw r2, [r10 - 0x190]
   5f438: 5d 29 0e 02 00 00 00 00      	jne r9, r2, +0x20e <.text+0x60390>
   5f440: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f448: 15 01 21 02 00 00 00 00      	jeq r1, 0x0, +0x221 <.text+0x60438>
   5f450: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   5f458: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5f460: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   5f468: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5f470: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   5f478: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   5f488: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   5f490: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   5f498: 85 10 00 00 ff ff ff ff      	call -0x1
   5f4a0: 55 00 c2 01 00 00 00 00      	jne r0, 0x0, +0x1c2 <.text+0x60198>
   5f4a8: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   5f4b0: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   5f4b8: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   5f4c0: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   5f4c8: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   5f4d0: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   5f4d8: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   5f4e0: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   5f4e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f4f0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f4f8: 5d 62 13 02 00 00 00 00      	jne r2, r6, +0x213 <.text+0x60478>
   5f500: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f508: 5d 72 11 02 00 00 00 00      	jne r2, r7, +0x211 <.text+0x60478>
   5f510: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f518: 5d 82 0f 02 00 00 00 00      	jne r2, r8, +0x20f <.text+0x60478>
   5f520: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f528: 5d 91 0d 02 00 00 00 00      	jne r1, r9, +0x20d <.text+0x60478>
   5f530: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   5f538: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f540: 15 01 22 02 00 00 00 00      	jeq r1, 0x0, +0x222 <.text+0x60538>
   5f548: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5f550: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   5f558: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f560: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f568: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5f570: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   5f578: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f580: 18 05 00 00 1a dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc1a
   5f590: 7b 5a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r5
   5f598: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5f5a0: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   5f5a8: 7b 5a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r5
   5f5b0: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   5f5b8: 7b 4a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r4
   5f5c0: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   5f5c8: 7b 2a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r2
   5f5d0: 7a 0a 80 fe 0d 00 00 00      	stdw [r10 - 0x180], 0xd
   5f5d8: 7a 0a 90 fe 20 00 00 00      	stdw [r10 - 0x170], 0x20
   5f5e0: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   5f5f0: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   5f5f8: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   5f608: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   5f610: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   5f620: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   5f628: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   5f638: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   5f640: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   5f648: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f650: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   5f658: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   5f660: 07 03 00 00 08 fd ff ff      	add64 r3, -0x2f8
   5f668: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5f670: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   5f678: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5f680: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   5f688: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   5f690: 85 10 00 00 ff ff ff ff      	call -0x1
   5f698: 55 00 83 01 00 00 00 00      	jne r0, 0x0, +0x183 <.text+0x60198>
   5f6a0: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   5f6a8: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   5f6b0: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   5f6b8: 79 a9 00 ff 00 00 00 00      	ldxdw r9, [r10 - 0x100]
   5f6c0: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   5f6c8: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   5f6d0: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   5f6d8: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   5f6e0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f6e8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f6f0: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   5f6f8: 5d 93 f3 01 00 00 00 00      	jne r3, r9, +0x1f3 <.text+0x60578>
   5f700: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   5f708: 5d 83 f1 01 00 00 00 00      	jne r3, r8, +0x1f1 <.text+0x60578>
   5f710: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   5f718: 5d 73 ef 01 00 00 00 00      	jne r3, r7, +0x1ef <.text+0x60578>
   5f720: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5f728: 5d 62 ed 01 00 00 00 00      	jne r2, r6, +0x1ed <.text+0x60578>
   5f730: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f738: 15 01 f6 01 00 00 00 00      	jeq r1, 0x0, +0x1f6 <.text+0x605d0>
   5f740: 79 a1 c8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x438]
   5f748: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f750: 15 01 fa 01 00 00 00 00      	jeq r1, 0x0, +0x1fa <.text+0x60608>
   5f758: 79 a1 c0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x440]
   5f760: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f768: 15 01 ff 01 00 00 00 00      	jeq r1, 0x0, +0x1ff <.text+0x60648>
   5f770: 79 a1 b8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x448]
   5f778: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5f780: 15 01 03 02 00 00 00 00      	jeq r1, 0x0, +0x203 <.text+0x60680>
   5f788: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   5f790: 79 16 20 00 00 00 00 00      	ldxdw r6, [r1 + 0x20]
   5f798: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5f7a0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   5f7a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f7b0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5f7b8: 85 10 00 00 ba 53 ff ff      	call -0xac46
   5f7c0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5f7c8: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   5f7d0: 79 62 18 00 00 00 00 00      	ldxdw r2, [r6 + 0x18]
   5f7d8: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   5f7e0: 5d 34 3a 01 00 00 00 00      	jne r4, r3, +0x13a <.text+0x60098>
   5f7e8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5f7f0: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   5f7f8: 5d 34 37 01 00 00 00 00      	jne r4, r3, +0x137 <.text+0x60098>
   5f800: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5f808: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   5f810: 5d 34 34 01 00 00 00 00      	jne r4, r3, +0x134 <.text+0x60098>
   5f818: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f820: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   5f828: 5d 12 31 01 00 00 00 00      	jne r2, r1, +0x131 <.text+0x60098>
   5f830: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f838: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   5f840: 85 10 00 00 d3 50 ff ff      	call -0xaf2d
   5f848: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   5f850: 79 19 60 00 00 00 00 00      	ldxdw r9, [r1 + 0x60]
   5f858: 79 18 58 00 00 00 00 00      	ldxdw r8, [r1 + 0x58]
   5f860: 79 17 50 00 00 00 00 00      	ldxdw r7, [r1 + 0x50]
   5f868: 79 16 48 00 00 00 00 00      	ldxdw r6, [r1 + 0x48]
   5f870: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   5f878: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f880: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f888: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   5f890: 7b 2a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r2
   5f898: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f8a0: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   5f8a8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f8b0: 7b 2a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r2
   5f8b8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f8c0: 7b 1a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r1
   5f8c8: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   5f8d0: 5d 16 e1 01 00 00 00 00      	jne r6, r1, +0x1e1 <.text+0x606c0>
   5f8d8: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   5f8e0: 5d 17 df 01 00 00 00 00      	jne r7, r1, +0x1df <.text+0x606c0>
   5f8e8: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   5f8f0: 5d 18 dd 01 00 00 00 00      	jne r8, r1, +0x1dd <.text+0x606c0>
   5f8f8: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   5f900: 5d 19 db 01 00 00 00 00      	jne r9, r1, +0x1db <.text+0x606c0>
   5f908: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   5f910: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   5f918: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   5f920: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   5f928: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   5f930: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   5f938: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   5f940: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   5f948: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   5f950: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5f958: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   5f960: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   5f968: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   5f970: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5f978: 85 10 00 00 82 53 ff ff      	call -0xac7e
   5f980: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   5f988: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5f990: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   5f998: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5f9a0: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   5f9a8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5f9b0: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   5f9b8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5f9c0: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   5f9c8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   5f9d0: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   5f9d8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   5f9e0: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   5f9e8: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   5f9f0: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   5f9f8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5fa00: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   5fa08: 85 10 00 00 4e 6c 00 00      	call 0x6c4e
   5fa10: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   5fa18: 85 10 00 00 98 50 ff ff      	call -0xaf68
   5fa20: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   5fa28: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   5fa30: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5fa38: 79 29 18 00 00 00 00 00      	ldxdw r9, [r2 + 0x18]
   5fa40: 79 28 10 00 00 00 00 00      	ldxdw r8, [r2 + 0x10]
   5fa48: 79 27 08 00 00 00 00 00      	ldxdw r7, [r2 + 0x8]
   5fa50: 79 26 00 00 00 00 00 00      	ldxdw r6, [r2 + 0x0]
   5fa58: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   5fa60: 5d 26 c4 01 00 00 00 00      	jne r6, r2, +0x1c4 <.text+0x60768>
   5fa68: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   5fa70: 5d 27 c2 01 00 00 00 00      	jne r7, r2, +0x1c2 <.text+0x60768>
   5fa78: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   5fa80: 5d 28 c0 01 00 00 00 00      	jne r8, r2, +0x1c0 <.text+0x60768>
   5fa88: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   5fa90: 5d 29 be 01 00 00 00 00      	jne r9, r2, +0x1be <.text+0x60768>
   5fa98: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5faa0: 15 01 d1 01 00 00 00 00      	jeq r1, 0x0, +0x1d1 <.text+0x60810>
   5faa8: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   5fab0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fab8: 15 01 d0 01 00 00 00 00      	jeq r1, 0x0, +0x1d0 <.text+0x60820>
   5fac0: 79 a1 58 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a8]
   5fac8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fad0: 15 01 d4 01 00 00 00 00      	jeq r1, 0x0, +0x1d4 <.text+0x60858>
   5fad8: 79 a1 a8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x458]
   5fae0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5fae8: 79 19 18 00 00 00 00 00      	ldxdw r9, [r1 + 0x18]
   5faf0: 79 18 10 00 00 00 00 00      	ldxdw r8, [r1 + 0x10]
   5faf8: 79 17 08 00 00 00 00 00      	ldxdw r7, [r1 + 0x8]
   5fb00: 79 16 00 00 00 00 00 00      	ldxdw r6, [r1 + 0x0]
   5fb08: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   5fb18: 5d 16 d3 01 00 00 00 00      	jne r6, r1, +0x1d3 <.text+0x60898>
   5fb20: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   5fb30: 5d 17 d0 01 00 00 00 00      	jne r7, r1, +0x1d0 <.text+0x60898>
   5fb38: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   5fb48: 5d 18 cd 01 00 00 00 00      	jne r8, r1, +0x1cd <.text+0x60898>
   5fb50: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   5fb60: 5d 19 ca 01 00 00 00 00      	jne r9, r1, +0x1ca <.text+0x60898>
   5fb68: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   5fb70: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fb78: 15 01 e0 01 00 00 00 00      	jeq r1, 0x0, +0x1e0 <.text+0x60960>
   5fb80: 79 a1 90 fb 00 00 00 00      	ldxdw r1, [r10 - 0x470]
   5fb88: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fb90: 15 01 e5 01 00 00 00 00      	jeq r1, 0x0, +0x1e5 <.text+0x609a0>
   5fb98: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   5fba0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   5fba8: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   5fbb0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   5fbb8: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   5fbc0: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   5fbd0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   5fbd8: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   5fbe0: 85 10 00 00 ff ff ff ff      	call -0x1
   5fbe8: 55 00 d9 00 00 00 00 00      	jne r0, 0x0, +0xd9 <.text+0x60198>
   5fbf0: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   5fbf8: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   5fc00: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   5fc08: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   5fc10: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   5fc18: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   5fc20: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   5fc28: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   5fc30: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5fc38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   5fc40: 5d 62 d7 01 00 00 00 00      	jne r2, r6, +0x1d7 <.text+0x609e0>
   5fc48: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   5fc50: 5d 72 d5 01 00 00 00 00      	jne r2, r7, +0x1d5 <.text+0x609e0>
   5fc58: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   5fc60: 5d 82 d3 01 00 00 00 00      	jne r2, r8, +0x1d3 <.text+0x609e0>
   5fc68: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5fc70: 5d 91 d1 01 00 00 00 00      	jne r1, r9, +0x1d1 <.text+0x609e0>
   5fc78: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   5fc80: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fc88: 15 01 d9 01 00 00 00 00      	jeq r1, 0x0, +0x1d9 <.text+0x60a38>
   5fc90: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   5fc98: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   5fca0: 15 01 de 01 00 00 00 00      	jeq r1, 0x0, +0x1de <.text+0x60a78>
   5fca8: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   5fcb0: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   5fcb8: 7b 21 f8 00 00 00 00 00      	stxdw [r1 + 0xf8], r2
   5fcc0: 79 a2 60 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a0]
   5fcc8: 7b 21 f0 00 00 00 00 00      	stxdw [r1 + 0xf0], r2
   5fcd0: 79 a2 68 fb 00 00 00 00      	ldxdw r2, [r10 - 0x498]
   5fcd8: 7b 21 e8 00 00 00 00 00      	stxdw [r1 + 0xe8], r2
   5fce0: 79 a2 78 fb 00 00 00 00      	ldxdw r2, [r10 - 0x488]
   5fce8: 7b 21 e0 00 00 00 00 00      	stxdw [r1 + 0xe0], r2
   5fcf0: 79 a2 80 fb 00 00 00 00      	ldxdw r2, [r10 - 0x480]
   5fcf8: 7b 21 d8 00 00 00 00 00      	stxdw [r1 + 0xd8], r2
   5fd00: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   5fd08: 7b 21 d0 00 00 00 00 00      	stxdw [r1 + 0xd0], r2
   5fd10: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   5fd18: 7b 21 c8 00 00 00 00 00      	stxdw [r1 + 0xc8], r2
   5fd20: 79 a2 98 fb 00 00 00 00      	ldxdw r2, [r10 - 0x468]
   5fd28: 7b 21 c0 00 00 00 00 00      	stxdw [r1 + 0xc0], r2
   5fd30: 79 a2 a0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x460]
   5fd38: 7b 21 b8 00 00 00 00 00      	stxdw [r1 + 0xb8], r2
   5fd40: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   5fd48: 7b 21 b0 00 00 00 00 00      	stxdw [r1 + 0xb0], r2
   5fd50: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   5fd58: 7b 21 a8 00 00 00 00 00      	stxdw [r1 + 0xa8], r2
   5fd60: 79 a2 48 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b8]
   5fd68: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   5fd70: 79 a2 58 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a8]
   5fd78: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   5fd80: 79 a2 70 fb 00 00 00 00      	ldxdw r2, [r10 - 0x490]
   5fd88: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   5fd90: 79 a2 50 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4b0]
   5fd98: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   5fda0: 79 a2 b8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x448]
   5fda8: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   5fdb0: 79 a2 c0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x440]
   5fdb8: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   5fdc0: 79 a2 c8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x438]
   5fdc8: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   5fdd0: 79 a2 d0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x430]
   5fdd8: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   5fde0: 79 a2 d8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x428]
   5fde8: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   5fdf0: 79 a2 e0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x420]
   5fdf8: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   5fe00: 79 a2 e8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x418]
   5fe08: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   5fe10: 79 a2 f0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x410]
   5fe18: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   5fe20: 79 a2 f8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x408]
   5fe28: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   5fe30: 79 a2 00 fc 00 00 00 00      	ldxdw r2, [r10 - 0x400]
   5fe38: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   5fe40: 79 a2 08 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f8]
   5fe48: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   5fe50: 79 a2 10 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f0]
   5fe58: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   5fe60: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   5fe68: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   5fe70: 79 a2 20 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e0]
   5fe78: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   5fe80: 79 a2 30 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d0]
   5fe88: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   5fe90: 79 a2 28 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d8]
   5fe98: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   5fea0: 79 a2 60 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a0]
   5fea8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   5feb0: 05 00 af f9 00 00 00 00      	ja -0x651 <.text+0x5cb10>
   5feb8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   5fec0: 85 10 00 00 e4 74 00 00      	call 0x74e4
   5fec8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5fed0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5fed8: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   5fee8: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   5fef0: 85 10 00 00 c3 47 ff ff      	call -0xb83d
   5fef8: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   5ff00: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   5ff08: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   5ff10: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   5ff18: 05 00 a2 f9 00 00 00 00      	ja -0x65e <.text+0x5cb10>
   5ff20: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   5ff28: 85 10 00 00 d7 74 00 00      	call 0x74d7
   5ff30: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5ff38: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5ff40: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   5ff50: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   5ff58: 85 10 00 00 b6 47 ff ff      	call -0xb84a
   5ff60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   5ff68: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   5ff70: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ff78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   5ff80: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   5ff88: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   5ff90: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   5ff98: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   5ffa0: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   5ffa8: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   5ffb0: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   5ffb8: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   5ffc0: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   5ffc8: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   5ffd0: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   5ffd8: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   5ffe0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   5ffe8: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   5fff0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   5fff8: 85 10 00 00 3f 6f 00 00      	call 0x6f3f
   60000: 05 00 de ff 00 00 00 00      	ja -0x22 <.text+0x5fdd8>
   60008: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60010: 85 10 00 00 ba 74 00 00      	call 0x74ba
   60018: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60020: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60028: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   60038: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   60040: 05 00 d5 ff 00 00 00 00      	ja -0x2b <.text+0x5fdd0>
   60048: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   60050: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   60058: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   60068: 85 10 00 00 fb 86 00 00      	call 0x86fb
   60070: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   60078: 85 10 00 00 ad 74 00 00      	call 0x74ad
   60080: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60088: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60090: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   600a0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   600a8: 85 10 00 00 8c 47 ff ff      	call -0xb874
   600b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   600b8: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   600c0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   600c8: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   600d0: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   600d8: 7b 6a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r6
   600e0: 79 a1 38 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c8]
   600e8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   600f0: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   600f8: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   60100: 79 a1 48 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b8]
   60108: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   60110: 7b 9a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r9
   60118: 05 00 d8 ff 00 00 00 00      	ja -0x28 <.text+0x5fec0>
   60120: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   60128: 85 10 00 00 97 74 00 00      	call 0x7497
   60130: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60138: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60140: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   60150: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   60158: 85 10 00 00 76 47 ff ff      	call -0xb88a
   60160: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60168: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   60170: 05 00 bf ff 00 00 00 00      	ja -0x41 <.text+0x5fe50>
   60178: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60180: 85 10 00 00 8c 74 00 00      	call 0x748c
   60188: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60190: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60198: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   601a8: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   601b0: 05 00 a7 ff 00 00 00 00      	ja -0x59 <.text+0x5fdd0>
   601b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   601c0: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   601c8: 85 10 00 00 a2 4f ff ff      	call -0xb05e
   601d0: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   601d8: 85 10 00 00 81 74 00 00      	call 0x7481
   601e0: 05 00 a2 ff 00 00 00 00      	ja -0x5e <.text+0x5fdd8>
   601e8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   601f0: b7 02 00 00 0a 00 00 00      	mov64 r2, 0xa
   601f8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   60208: 85 10 00 00 c7 86 00 00      	call 0x86c7
   60210: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   60218: 85 10 00 00 79 74 00 00      	call 0x7479
   60220: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60228: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60230: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   60240: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   60248: 85 10 00 00 58 47 ff ff      	call -0xb8a8
   60250: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60258: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60260: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60268: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60270: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60278: 79 a1 f8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x208]
   60280: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60288: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   60290: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60298: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   602a0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   602a8: 79 a1 10 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f0]
   602b0: 05 00 20 00 00 00 00 00      	ja +0x20 <.text+0x60298>
   602b8: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   602c8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   602d0: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   602d8: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   602e0: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   602e8: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   602f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   602f8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   60300: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   60310: 85 10 00 00 ae 88 00 00      	call 0x88ae
   60318: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   60320: 85 10 00 00 58 74 00 00      	call 0x7458
   60328: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60330: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60338: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   60348: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   60350: 85 10 00 00 37 47 ff ff      	call -0xb8c9
   60358: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60360: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60368: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60370: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60378: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60380: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   60388: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60390: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   60398: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   603a0: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   603a8: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   603b0: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   603b8: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   603c0: 05 00 83 ff 00 00 00 00      	ja -0x7d <.text+0x5fec0>
   603c8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   603d0: 85 10 00 00 42 74 00 00      	call 0x7442
   603d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   603e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   603e8: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   603f8: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   60400: 05 00 5d ff 00 00 00 00      	ja -0xa3 <.text+0x5fdd0>
   60408: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   60410: 85 10 00 00 3a 74 00 00      	call 0x743a
   60418: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60420: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60428: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   60438: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   60440: 85 10 00 00 19 47 ff ff      	call -0xb8e7
   60448: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60450: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60458: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60460: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60468: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60470: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   60478: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60480: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   60488: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60490: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   60498: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   604a0: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   604a8: 05 00 e1 ff 00 00 00 00      	ja -0x1f <.text+0x60298>
   604b0: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   604b8: 85 10 00 00 25 74 00 00      	call 0x7425
   604c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   604c8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   604d0: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   604e0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   604e8: 85 10 00 00 04 47 ff ff      	call -0xb8fc
   604f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   604f8: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60500: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60508: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60510: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60518: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   60520: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60528: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   60530: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60538: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   60540: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   60548: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   60550: 05 00 cc ff 00 00 00 00      	ja -0x34 <.text+0x60298>
   60558: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60560: 85 10 00 00 10 74 00 00      	call 0x7410
   60568: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60570: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60578: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   60588: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   60590: 05 00 2b ff 00 00 00 00      	ja -0xd5 <.text+0x5fdd0>
   60598: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   605a0: 85 10 00 00 08 74 00 00      	call 0x7408
   605a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   605b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   605b8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   605c8: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   605d0: 85 10 00 00 e7 46 ff ff      	call -0xb919
   605d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   605e0: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   605e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   605f0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   605f8: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   60600: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   60608: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   60610: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   60618: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   60620: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   60628: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   60630: 7b 9a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r9
   60638: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   60640: 7b 7a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r7
   60648: 7b 6a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r6
   60650: 05 00 31 ff 00 00 00 00      	ja -0xcf <.text+0x5fec0>
   60658: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60660: 85 10 00 00 f0 73 00 00      	call 0x73f0
   60668: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60670: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60678: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   60688: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   60690: 05 00 0b ff 00 00 00 00      	ja -0xf5 <.text+0x5fdd0>
   60698: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   606a0: 85 10 00 00 e8 73 00 00      	call 0x73e8
   606a8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   606b0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   606b8: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   606c8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   606d0: 85 10 00 00 c7 46 ff ff      	call -0xb939
   606d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   606e0: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   606e8: 05 00 10 ff 00 00 00 00      	ja -0xf0 <.text+0x5fe50>
   606f0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   606f8: 85 10 00 00 dd 73 00 00      	call 0x73dd
   60700: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60708: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60710: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   60720: 05 00 22 ff 00 00 00 00      	ja -0xde <.text+0x5ff18>
   60728: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60730: 85 10 00 00 d6 73 00 00      	call 0x73d6
   60738: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60740: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60748: 18 03 00 00 31 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade31
   60758: b7 04 00 00 1e 00 00 00      	mov64 r4, 0x1e
   60760: 05 00 f1 fe 00 00 00 00      	ja -0x10f <.text+0x5fdd0>
   60768: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60770: 85 10 00 00 ce 73 00 00      	call 0x73ce
   60778: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60780: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60788: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   60798: 05 00 13 ff 00 00 00 00      	ja -0xed <.text+0x5ff18>
   607a0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   607a8: 85 10 00 00 c7 73 00 00      	call 0x73c7
   607b0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   607b8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   607c0: 18 03 00 00 44 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc44
   607d0: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   607d8: 05 00 e2 fe 00 00 00 00      	ja -0x11e <.text+0x5fdd0>
   607e0: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   607e8: 85 10 00 00 bf 73 00 00      	call 0x73bf
   607f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   607f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60800: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   60810: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   60818: 85 10 00 00 9e 46 ff ff      	call -0xb962
   60820: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60828: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60830: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60838: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60840: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60848: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   60850: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60858: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   60860: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60868: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   60870: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   60878: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   60880: 05 00 66 ff 00 00 00 00      	ja -0x9a <.text+0x60298>
   60888: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   60890: 85 10 00 00 aa 73 00 00      	call 0x73aa
   60898: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   608a0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   608a8: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   608b8: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   608c0: 85 10 00 00 89 46 ff ff      	call -0xb977
   608c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   608d0: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   608d8: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   608e0: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   608e8: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   608f0: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   608f8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60900: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   60908: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60910: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   60918: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   60920: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   60928: 05 00 51 ff 00 00 00 00      	ja -0xaf <.text+0x60298>
   60930: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60938: 05 00 2c fc 00 00 00 00      	ja -0x3d4 <.text+0x5e980>
   60940: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60948: 85 10 00 00 93 73 00 00      	call 0x7393
   60950: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60958: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60960: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   60970: 05 00 d8 fe 00 00 00 00      	ja -0x128 <.text+0x5ff18>
   60978: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60980: 85 10 00 00 8c 73 00 00      	call 0x738c
   60988: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60990: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60998: 18 03 00 00 6c de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade6c
   609a8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   609b0: 05 00 a7 fe 00 00 00 00      	ja -0x159 <.text+0x5fdd0>
   609b8: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   609c0: 85 10 00 00 84 73 00 00      	call 0x7384
   609c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   609d0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   609d8: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   609e8: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   609f0: 85 10 00 00 63 46 ff ff      	call -0xb99d
   609f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60a00: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   60a10: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   60a18: 7b 9a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r9
   60a20: 7b 8a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r8
   60a28: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   60a30: 7b 6a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r6
   60a38: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   60a48: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   60a50: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   60a60: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   60a68: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   60a78: 05 00 27 ff 00 00 00 00      	ja -0xd9 <.text+0x60298>
   60a80: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60a88: 85 10 00 00 6b 73 00 00      	call 0x736b
   60a90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60a98: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60aa0: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   60ab0: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   60ab8: 05 00 86 fe 00 00 00 00      	ja -0x17a <.text+0x5fdd0>
   60ac0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60ac8: 85 10 00 00 63 73 00 00      	call 0x7363
   60ad0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60ad8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60ae0: 18 03 00 00 92 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade92
   60af0: b7 04 00 00 22 00 00 00      	mov64 r4, 0x22
   60af8: 05 00 7e fe 00 00 00 00      	ja -0x182 <.text+0x5fdd0>
   60b00: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   60b08: 85 10 00 00 5b 73 00 00      	call 0x735b
   60b10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60b18: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60b20: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   60b30: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   60b38: 85 10 00 00 3a 46 ff ff      	call -0xb9c6
   60b40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60b48: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   60b50: 05 00 52 ff 00 00 00 00      	ja -0xae <.text+0x604c8>
   60b58: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60b60: 85 10 00 00 50 73 00 00      	call 0x7350
   60b68: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60b70: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60b78: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   60b88: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   60b90: 05 00 6b fe 00 00 00 00      	ja -0x195 <.text+0x5fdd0>
   60b98: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   60ba0: 85 10 00 00 48 73 00 00      	call 0x7348
   60ba8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   60bb0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   60bb8: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   60bc8: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   60bd0: 05 00 63 fe 00 00 00 00      	ja -0x19d <.text+0x5fdd0>
   61b40: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   61b48: 7b 4a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r4
   61b50: bf 39 00 00 00 00 00 00      	mov64 r9, r3
   61b58: 7b 2a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r2
   61b60: 7b 1a 60 fc 00 00 00 00      	stxdw [r10 - 0x3a0], r1
   61b68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   61b70: 07 01 00 00 68 fc ff ff      	add64 r1, -0x398
   61b78: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   61b80: 85 10 00 00 95 50 ff ff      	call -0xaf6b
   61b88: 79 a6 70 fc 00 00 00 00      	ldxdw r6, [r10 - 0x390]
   61b90: 79 a8 68 fc 00 00 00 00      	ldxdw r8, [r10 - 0x398]
   61b98: 55 08 2e 00 02 00 00 00      	jne r8, 0x2, +0x2e <.text+0x61bf0>
   61ba0: 79 71 10 f0 00 00 00 00      	ldxdw r1, [r7 - 0xff0]
   61ba8: 7b 1a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r1
   61bb0: 79 78 08 f0 00 00 00 00      	ldxdw r8, [r7 - 0xff8]
   61bb8: 79 77 00 f0 00 00 00 00      	ldxdw r7, [r7 - 0x1000]
   61bc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   61bc8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   61bd0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   61bd8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   61be0: 85 10 00 00 dd 50 ff ff      	call -0xaf23
   61be8: 71 a1 fd ff 00 00 00 00      	ldxb r1, [r10 - 0x3]
   61bf0: 55 01 54 00 02 00 00 00      	jne r1, 0x2, +0x54 <.text+0x61d78>
   61bf8: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   61c00: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   61c08: 85 10 00 00 3c 43 00 00      	call 0x433c
   61c10: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   61c20: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   61c28: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   61c30: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   61c38: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   61c40: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   61c48: 2d 21 60 00 00 00 00 00      	jgt r1, r2, +0x60 <.text+0x61e30>
   61c50: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   61c58: 15 04 5f 00 00 00 00 00      	jeq r4, 0x0, +0x5f <.text+0x61e38>
   61c60: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   61c70: 15 02 60 00 00 00 00 00      	jeq r2, 0x0, +0x60 <.text+0x61e58>
   61c78: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   61c80: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   61c90: 15 06 5f 00 01 00 00 00      	jeq r6, 0x1, +0x5f <.text+0x61e70>
   61c98: bd 21 5f 00 00 00 00 00      	jle r1, r2, +0x5f <.text+0x61e78>
   61ca0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   61cb0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   61cb8: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   61cc8: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   61cd0: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   61ce0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   61ce8: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   61cf0: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   61cf8: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   61d00: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   61d08: 05 00 df 00 00 00 00 00      	ja +0xdf <.text+0x622e8>
   61d10: 85 10 00 00 1b 43 00 00      	call 0x431b
   61d18: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   61d28: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   61d30: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   61d38: 07 01 00 00 fa ff ff ff      	add64 r1, -0x6
   61d40: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   61d48: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   61d50: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <.text+0x61cb8>
   61d58: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   61d60: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <.text+0x61cc0>
   61d68: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   61d78: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <.text+0x61ce0>
   61d80: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   61d88: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   61d90: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   61d98: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   61da8: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <.text+0x61d08>
   61db0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   61db8: b7 02 00 00 06 00 00 00      	mov64 r2, 0x6
   61dc0: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   61dd0: 85 10 00 00 4e 83 00 00      	call 0x834e
   61dd8: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <.text+0x61c48>
   61de0: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   61de8: 18 01 00 00 fa 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffa
   61df8: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <.text+0x61c60>
   61e00: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   61e08: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   61e10: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   61e20: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <.text+0x61c90>
   61e28: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   61e38: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   61e40: 6a 01 04 00 65 72 00 00      	sth [r1 + 0x4], 0x7265
   61e48: 62 01 00 00 74 72 61 64      	stw [r1 + 0x0], 0x64617274
   61e50: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   61e58: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   61e60: 7a 06 18 00 06 00 00 00      	stdw [r6 + 0x18], 0x6
   61e68: 7a 06 08 00 06 00 00 00      	stdw [r6 + 0x8], 0x6
   61e70: 7a 06 00 00 01 00 00 00      	stdw [r6 + 0x0], 0x1
   61e78: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   61e80: 7b 61 10 00 00 00 00 00      	stxdw [r1 + 0x10], r6
   61e88: 7b 81 08 00 00 00 00 00      	stxdw [r1 + 0x8], r8
   61e90: 05 00 b2 00 00 00 00 00      	ja +0xb2 <.text+0x62308>
   61e98: 85 10 00 00 ea 42 00 00      	call 0x42ea
   61ea0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   61eb0: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   61eb8: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   61ec0: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   61ec8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   61ed0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   61ed8: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x61ea0>
   61ee0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   61ee8: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x61ea8>
   61ef0: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   61f00: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x61ec8>
   61f08: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   61f10: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   61f18: 7b 8a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r8
   61f20: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   61f30: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x61ee8>
   61f38: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   61f40: b7 02 00 00 00 01 00 00      	mov64 r2, 0x100
   61f48: 85 10 00 00 23 83 00 00      	call 0x8323
   61f50: 55 04 a1 ff 00 00 00 00      	jne r4, 0x0, -0x5f <.text+0x61b40>
   61f58: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   61f60: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   61f70: 55 02 a0 ff 00 00 00 00      	jne r2, 0x0, -0x60 <.text+0x61b58>
   61f78: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   61f88: 55 06 a1 ff 01 00 00 00      	jne r6, 0x1, -0x5f <.text+0x61b78>
   61f90: 2d 21 a1 ff 00 00 00 00      	jgt r1, r2, -0x5f <.text+0x61b80>
   61f98: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   61fa0: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   61fa8: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   61fb8: 85 10 00 00 11 83 00 00      	call 0x8311
   61fc0: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x61dd0>
   61fc8: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   61fd0: 18 01 00 00 00 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f00
   61fe0: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x61de8>
   61fe8: 7b 8a 40 fc 00 00 00 00      	stxdw [r10 - 0x3c0], r8
   61ff0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62000: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x61e18>
   62008: 18 08 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r8, 0x300000000
   62018: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   62020: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   62028: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   62030: 7b 1a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r1
   62038: b7 03 00 00 00 01 00 00      	mov64 r3, 0x100
   62040: 85 10 00 00 a8 90 00 00      	call 0x90a8
   62048: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62050: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   62058: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62060: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62068: 85 10 00 00 19 50 ff ff      	call -0xafe7
   62070: 71 a1 69 ff 00 00 00 00      	ldxb r1, [r10 - 0x97]
   62078: 55 01 1f 00 02 00 00 00      	jne r1, 0x2, +0x1f <.text+0x62058>
   62080: 79 a7 08 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf8]
   62088: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   62090: 85 10 00 00 ab 42 00 00      	call 0x42ab
   62098: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   620a0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   620a8: 07 01 00 00 f4 ff ff ff      	add64 r1, -0xc
   620b0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   620b8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   620c0: 2d 21 2a 00 00 00 00 00      	jgt r1, r2, +0x2a <.text+0x620f8>
   620c8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   620d0: 15 04 29 00 00 00 00 00      	jeq r4, 0x0, +0x29 <.text+0x62100>
   620d8: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   620e8: 15 02 2a 00 00 00 00 00      	jeq r2, 0x0, +0x2a <.text+0x62120>
   620f0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   620f8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62108: 15 06 29 00 01 00 00 00      	jeq r6, 0x1, +0x29 <.text+0x62138>
   62110: bd 21 29 00 00 00 00 00      	jle r1, r2, +0x29 <.text+0x62140>
   62118: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   62128: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   62130: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 73      	lddw r2, 0x735f6d656879616d
   62140: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   62148: 62 01 08 00 74 61 74 65      	stw [r1 + 0x8], 0x65746174
   62150: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   62158: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   62160: 7a 07 18 00 0c 00 00 00      	stdw [r7 + 0x18], 0xc
   62168: 7a 07 08 00 0c 00 00 00      	stdw [r7 + 0x8], 0xc
   62170: 05 00 52 00 00 00 00 00      	ja +0x52 <.text+0x622e8>
   62178: 85 10 00 00 8e 42 00 00      	call 0x428e
   62180: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   62188: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   62190: 07 03 00 00 90 ff ff ff      	add64 r3, -0x70
   62198: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   621a0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   621a8: 2d 53 1b 00 00 00 00 00      	jgt r3, r5, +0x1b <.text+0x62168>
   621b0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   621b8: 15 04 1a 00 00 00 00 00      	jeq r4, 0x0, +0x1a <.text+0x62170>
   621c0: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   621d0: 15 05 1b 00 00 00 00 00      	jeq r5, 0x0, +0x1b <.text+0x62190>
   621d8: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   621e0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   621e8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   621f8: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <.text+0x621a8>
   62200: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   62208: b7 02 00 00 70 00 00 00      	mov64 r2, 0x70
   62210: 85 10 00 00 ca 82 00 00      	call 0x82ca
   62218: 55 04 d7 ff 00 00 00 00      	jne r4, 0x0, -0x29 <.text+0x61fb8>
   62220: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   62228: 18 01 00 00 f4 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff4
   62238: 55 02 d6 ff 00 00 00 00      	jne r2, 0x0, -0x2a <.text+0x61fd0>
   62240: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62250: 55 06 d7 ff 01 00 00 00      	jne r6, 0x1, -0x29 <.text+0x61ff0>
   62258: 2d 21 d7 ff 00 00 00 00      	jgt r1, r2, -0x29 <.text+0x61ff8>
   62260: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   62268: b7 02 00 00 0c 00 00 00      	mov64 r2, 0xc
   62270: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   62280: 85 10 00 00 b8 82 00 00      	call 0x82b8
   62288: 55 04 e6 ff 00 00 00 00      	jne r4, 0x0, -0x1a <.text+0x620a0>
   62290: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   62298: 18 01 00 00 90 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f90
   622a8: 55 05 e5 ff 00 00 00 00      	jne r5, 0x0, -0x1b <.text+0x620b8>
   622b0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   622c0: bd 21 e7 ff 00 00 00 00      	jle r1, r2, -0x19 <.text+0x620e0>
   622c8: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   622d0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   622d8: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   622e0: 7b 1a 30 fc 00 00 00 00      	stxdw [r10 - 0x3d0], r1
   622e8: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   622f0: 85 10 00 00 52 90 00 00      	call 0x9052
   622f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62300: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   62308: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62310: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62318: 85 10 00 00 3a 41 ff ff      	call -0xbec6
   62320: 61 a1 00 ff 00 00 00 00      	ldxw r1, [r10 - 0x100]
   62328: 55 01 21 00 02 00 00 00      	jne r1, 0x2, +0x21 <.text+0x62318>
   62330: 79 a7 10 ff 00 00 00 00      	ldxdw r7, [r10 - 0xf0]
   62338: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   62340: 85 10 00 00 55 42 00 00      	call 0x4255
   62348: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   62350: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   62358: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   62360: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   62368: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   62370: 2d 21 2d 00 00 00 00 00      	jgt r1, r2, +0x2d <.text+0x623c0>
   62378: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   62380: 15 04 2c 00 00 00 00 00      	jeq r4, 0x0, +0x2c <.text+0x623c8>
   62388: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   62398: 15 02 2d 00 00 00 00 00      	jeq r2, 0x0, +0x2d <.text+0x623e8>
   623a0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   623a8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   623b8: 15 06 2c 00 01 00 00 00      	jeq r6, 0x1, +0x2c <.text+0x62400>
   623c0: bd 21 2c 00 00 00 00 00      	jle r1, r2, +0x2c <.text+0x62408>
   623c8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   623d8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   623e0: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   623e8: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   623f0: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   623f8: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   62400: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   62408: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   62410: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   62418: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   62420: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   62428: 7a 01 00 00 00 00 00 00      	stdw [r1 + 0x0], 0x0
   62430: 95 00 00 00 00 00 00 00      	exit
   62438: 85 10 00 00 36 42 00 00      	call 0x4236
   62440: 79 85 00 00 00 00 00 00      	ldxdw r5, [r8 + 0x0]
   62448: bf 53 00 00 00 00 00 00      	mov64 r3, r5
   62450: 07 03 00 00 80 ff ff ff      	add64 r3, -0x80
   62458: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   62460: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   62468: 2d 53 1c 00 00 00 00 00      	jgt r3, r5, +0x1c <.text+0x62430>
   62470: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   62478: 79 a8 50 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3b0]
   62480: 15 04 1b 00 00 00 00 00      	jeq r4, 0x0, +0x1b <.text+0x62440>
   62488: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   62498: 15 05 1c 00 00 00 00 00      	jeq r5, 0x0, +0x1c <.text+0x62460>
   624a0: 57 02 00 00 f8 ff ff ff      	and64 r2, -0x8
   624a8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   624b0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   624c0: 2d 21 1a 00 00 00 00 00      	jgt r1, r2, +0x1a <.text+0x62478>
   624c8: b7 01 00 00 08 00 00 00      	mov64 r1, 0x8
   624d0: b7 02 00 00 80 00 00 00      	mov64 r2, 0x80
   624d8: 85 10 00 00 71 82 00 00      	call 0x8271
   624e0: 55 04 d4 ff 00 00 00 00      	jne r4, 0x0, -0x2c <.text+0x62268>
   624e8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   624f0: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   62500: 55 02 d3 ff 00 00 00 00      	jne r2, 0x0, -0x2d <.text+0x62280>
   62508: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62518: 55 06 d4 ff 01 00 00 00      	jne r6, 0x1, -0x2c <.text+0x622a0>
   62520: 2d 21 d4 ff 00 00 00 00      	jgt r1, r2, -0x2c <.text+0x622a8>
   62528: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   62530: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   62538: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   62548: 85 10 00 00 5f 82 00 00      	call 0x825f
   62550: 79 a8 50 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3b0]
   62558: 55 04 e5 ff 00 00 00 00      	jne r4, 0x0, -0x1b <.text+0x62368>
   62560: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   62568: 18 01 00 00 80 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007f80
   62578: 55 05 e4 ff 00 00 00 00      	jne r5, 0x0, -0x1c <.text+0x62380>
   62580: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62590: bd 21 e6 ff 00 00 00 00      	jle r1, r2, -0x1a <.text+0x623a8>
   62598: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   625a8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   625b0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   625b8: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   625c0: 7b 1a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r1
   625c8: b7 03 00 00 80 00 00 00      	mov64 r3, 0x80
   625d0: 85 10 00 00 f6 8f 00 00      	call 0x8ff6
   625d8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   625e0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x62500>
   625e8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   625f0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   625f8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   62600: 7b 1a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r1
   62608: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   62610: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   62618: 05 00 04 00 00 00 00 00      	ja +0x4 <.text+0x62520>
   62620: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   62628: 85 10 00 00 f7 6f 00 00      	call 0x6ff7
   62630: 55 00 47 00 02 00 00 00      	jne r0, 0x2, +0x47 <.text+0x62750>
   62638: 7b 1a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r1
   62640: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62648: 07 01 00 00 78 fc ff ff      	add64 r1, -0x388
   62650: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62658: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62660: 85 10 00 00 e1 4f ff ff      	call -0xb01f
   62668: 79 a2 80 fc 00 00 00 00      	ldxdw r2, [r10 - 0x380]
   62670: 79 a1 78 fc 00 00 00 00      	ldxdw r1, [r10 - 0x388]
   62678: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x62570>
   62680: 7b 2a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r2
   62688: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x625a0>
   62690: 18 03 00 00 96 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb96
   626a0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   626a8: 85 10 00 00 cc 42 ff ff      	call -0xbd34
   626b0: 55 00 8e 05 02 00 00 00      	jne r0, 0x2, +0x58e <.text+0x65208>
   626b8: 7b 1a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r1
   626c0: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   626c8: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   626d0: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   626d8: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   626e0: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   626e8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   626f0: 07 01 00 00 88 fc ff ff      	add64 r1, -0x378
   626f8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62700: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   62708: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62710: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   62718: 85 10 00 00 32 45 ff ff      	call -0xbace
   62720: 79 a2 90 fc 00 00 00 00      	ldxdw r2, [r10 - 0x370]
   62728: 79 a1 88 fc 00 00 00 00      	ldxdw r1, [r10 - 0x378]
   62730: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x62628>
   62738: 7b 2a 10 fc 00 00 00 00      	stxdw [r10 - 0x3f0], r2
   62740: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x62658>
   62748: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   62758: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   62760: 85 10 00 00 b5 42 ff ff      	call -0xbd4b
   62768: 55 00 77 05 02 00 00 00      	jne r0, 0x2, +0x577 <.text+0x65208>
   62770: 7b 1a 10 fc 00 00 00 00      	stxdw [r10 - 0x3f0], r1
   62778: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   62780: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   62788: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   62790: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   62798: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   627a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   627a8: 07 01 00 00 98 fc ff ff      	add64 r1, -0x368
   627b0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   627b8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   627c0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   627c8: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   627d0: 85 10 00 00 1b 45 ff ff      	call -0xbae5
   627d8: 79 a2 a0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x360]
   627e0: 79 a1 98 fc 00 00 00 00      	ldxdw r1, [r10 - 0x368]
   627e8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x62700>
   627f0: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   62800: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   62808: 85 10 00 00 a0 42 ff ff      	call -0xbd60
   62810: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62818: 55 00 fc 01 02 00 00 00      	jne r0, 0x2, +0x1fc <.text+0x636e0>
   62820: 7b 2a 08 fc 00 00 00 00      	stxdw [r10 - 0x3f8], r2
   62828: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   62830: 15 01 36 00 00 00 00 00      	jeq r1, 0x0, +0x36 <.text+0x628c8>
   62838: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62840: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62848: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   62850: 7b 1a 00 fc 00 00 00 00      	stxdw [r10 - 0x400], r1
   62858: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   62860: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   62868: 05 00 3c 00 00 00 00 00      	ja +0x3c <.text+0x62930>
   62870: bf 07 00 00 00 00 00 00      	mov64 r7, r0
   62878: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   62880: 85 10 00 00 ad 41 00 00      	call 0x41ad
   62888: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   62898: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   628a0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   628a8: 07 01 00 00 f6 ff ff ff      	add64 r1, -0xa
   628b0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   628b8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   628c0: 2d 21 1d 00 00 00 00 00      	jgt r1, r2, +0x1d <.text+0x62890>
   628c8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   628d0: 15 04 1c 00 00 00 00 00      	jeq r4, 0x0, +0x1c <.text+0x62898>
   628d8: 18 01 00 00 f6 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff6
   628e8: bf 74 00 00 00 00 00 00      	mov64 r4, r7
   628f0: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x627e0>
   628f8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   62900: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   62908: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   62910: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62920: bf 63 00 00 00 00 00 00      	mov64 r3, r6
   62928: bd 21 9a 05 00 00 00 00      	jle r1, r2, +0x59a <.text+0x654e0>
   62930: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   62940: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   62948: 18 02 00 00 71 75 6f 74 00 00 00 00 65 5f 6d 69      	lddw r2, 0x696d5f65746f7571
   62958: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   62960: 6a 01 08 00 6e 74 00 00      	sth [r1 + 0x8], 0x746e
   62968: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   62970: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   62978: 7a 03 18 00 0a 00 00 00      	stdw [r3 + 0x18], 0xa
   62980: 7a 03 08 00 0a 00 00 00      	stdw [r3 + 0x8], 0xa
   62988: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   62990: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   62998: 7b 31 10 00 00 00 00 00      	stxdw [r1 + 0x10], r3
   629a0: 7b 41 08 00 00 00 00 00      	stxdw [r1 + 0x8], r4
   629a8: 05 00 4f ff 00 00 00 00      	ja -0xb1 <.text+0x62308>
   629b0: 55 04 e4 ff 00 00 00 00      	jne r4, 0x0, -0x1c <.text+0x627b8>
   629b8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   629c0: 18 01 00 00 f6 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff6
   629d0: bf 74 00 00 00 00 00 00      	mov64 r4, r7
   629d8: 55 02 e3 ff 00 00 00 00      	jne r2, 0x0, -0x1d <.text+0x627d8>
   629e0: 05 00 e3 ff 00 00 00 00      	ja -0x1d <.text+0x627e0>
   629e8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   629f0: 85 10 00 00 7e 6f 00 00      	call 0x6f7e
   629f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62a00: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x628f8>
   62a08: 7b 2a 00 fc 00 00 00 00      	stxdw [r10 - 0x400], r2
   62a10: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x62930>
   62a18: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   62a20: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   62a30: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   62a38: 85 10 00 00 5a 42 ff ff      	call -0xbda6
   62a40: 55 00 1c 05 02 00 00 00      	jne r0, 0x2, +0x51c <.text+0x65208>
   62a48: 7b 1a 00 fc 00 00 00 00      	stxdw [r10 - 0x400], r1
   62a50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62a58: 07 01 00 00 a8 fc ff ff      	add64 r1, -0x358
   62a60: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62a68: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62a70: 85 10 00 00 2d 4f ff ff      	call -0xb0d3
   62a78: 79 a2 b0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x350]
   62a80: 79 a1 a8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x358]
   62a88: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x62980>
   62a90: 7b 2a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r2
   62a98: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x629b0>
   62aa0: 18 03 00 00 f4 da 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadaf4
   62ab0: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   62ab8: 85 10 00 00 4a 42 ff ff      	call -0xbdb6
   62ac0: 55 00 0c 05 02 00 00 00      	jne r0, 0x2, +0x50c <.text+0x65208>
   62ac8: 7b 1a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r1
   62ad0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62ad8: 07 01 00 00 b8 fc ff ff      	add64 r1, -0x348
   62ae0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62ae8: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62af0: 85 10 00 00 8f 4f ff ff      	call -0xb071
   62af8: 79 a2 c0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x340]
   62b00: 79 a1 b8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x348]
   62b08: 55 01 02 00 02 00 00 00      	jne r1, 0x2, +0x2 <.text+0x62a00>
   62b10: 7b 2a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r2
   62b18: 05 00 06 00 00 00 00 00      	ja +0x6 <.text+0x62a30>
   62b20: 18 03 00 00 89 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb89
   62b30: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   62b38: 85 10 00 00 3a 42 ff ff      	call -0xbdc6
   62b40: 55 00 fc 04 02 00 00 00      	jne r0, 0x2, +0x4fc <.text+0x65208>
   62b48: 7b 1a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r1
   62b50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62b58: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   62b60: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62b68: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62b70: 85 10 00 00 b5 3a ff ff      	call -0xc54b
   62b78: 79 a2 d0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x330]
   62b80: 79 a1 c8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x338]
   62b88: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x62aa0>
   62b90: 18 03 00 00 5b dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc5b
   62ba0: b7 04 00 00 13 00 00 00      	mov64 r4, 0x13
   62ba8: 85 10 00 00 2c 42 ff ff      	call -0xbdd4
   62bb0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62bb8: 55 00 88 01 02 00 00 00      	jne r0, 0x2, +0x188 <.text+0x636e0>
   62bc0: 7b 2a e8 fb 00 00 00 00      	stxdw [r10 - 0x418], r2
   62bc8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   62bd0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x62af0>
   62bd8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62be0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62be8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   62bf0: 7b 1a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r1
   62bf8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   62c00: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   62c08: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x62b58>
   62c10: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   62c18: 85 10 00 00 39 6f 00 00      	call 0x6f39
   62c20: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62c28: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x62b20>
   62c30: 7b 2a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r2
   62c38: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x62b58>
   62c40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   62c48: 18 03 00 00 e8 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbe8
   62c58: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   62c60: 85 10 00 00 15 42 ff ff      	call -0xbdeb
   62c68: 55 00 d7 04 02 00 00 00      	jne r0, 0x2, +0x4d7 <.text+0x65208>
   62c70: 7b 1a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r1
   62c78: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   62c80: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   62c88: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   62c90: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   62c98: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   62ca0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62ca8: 07 01 00 00 d8 fc ff ff      	add64 r1, -0x328
   62cb0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62cb8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   62cc0: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62cc8: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   62cd0: 85 10 00 00 46 44 ff ff      	call -0xbbba
   62cd8: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   62ce0: 79 a1 d8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x328]
   62ce8: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x62c00>
   62cf0: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   62d00: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   62d08: 85 10 00 00 00 42 ff ff      	call -0xbe00
   62d10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62d18: 55 00 5c 01 02 00 00 00      	jne r0, 0x2, +0x15c <.text+0x636e0>
   62d20: 7b 2a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r2
   62d28: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   62d30: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x62c88>
   62d38: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   62d40: 7b 2a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r2
   62d48: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   62d50: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   62d58: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62d60: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62d68: 15 01 0c 00 00 00 00 00      	jeq r1, 0x0, +0xc <.text+0x62cb0>
   62d70: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   62d78: 7b 2a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r2
   62d80: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   62d88: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   62d90: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62d98: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62da0: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x62d20>
   62da8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   62db0: 85 10 00 00 06 6f 00 00      	call 0x6f06
   62db8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62dc0: 55 00 54 00 02 00 00 00      	jne r0, 0x2, +0x54 <.text+0x62f48>
   62dc8: 7b 2a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r2
   62dd0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   62dd8: 85 10 00 00 01 6f 00 00      	call 0x6f01
   62de0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62de8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x62ce0>
   62df0: 7b 2a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r2
   62df8: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x62d60>
   62e00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   62e08: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   62e18: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   62e20: 85 10 00 00 dd 41 ff ff      	call -0xbe23
   62e28: 55 00 9f 04 02 00 00 00      	jne r0, 0x2, +0x49f <.text+0x65208>
   62e30: 7b 1a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r1
   62e38: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   62e40: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x62d60>
   62e48: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62e50: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62e58: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   62e60: 7b 1a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r1
   62e68: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   62e70: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   62e78: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x62dc8>
   62e80: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   62e88: 85 10 00 00 eb 6e 00 00      	call 0x6eeb
   62e90: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62e98: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x62d90>
   62ea0: 7b 2a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r2
   62ea8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x62dc8>
   62eb0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   62eb8: 18 03 00 00 44 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc44
   62ec8: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   62ed0: 85 10 00 00 c7 41 ff ff      	call -0xbe39
   62ed8: 55 00 89 04 02 00 00 00      	jne r0, 0x2, +0x489 <.text+0x65208>
   62ee0: 7b 1a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r1
   62ee8: 79 a1 48 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b8]
   62ef0: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   62ef8: 79 a1 40 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c0]
   62f00: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   62f08: 7b 7a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r7
   62f10: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62f18: 07 01 00 00 e8 fc ff ff      	add64 r1, -0x318
   62f20: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62f28: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   62f30: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   62f38: 79 a4 58 fc 00 00 00 00      	ldxdw r4, [r10 - 0x3a8]
   62f40: 85 10 00 00 2d 44 ff ff      	call -0xbbd3
   62f48: 79 a8 f0 fc 00 00 00 00      	ldxdw r8, [r10 - 0x310]
   62f50: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   62f58: 15 01 07 00 02 00 00 00      	jeq r1, 0x2, +0x7 <.text+0x62e78>
   62f60: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   62f68: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   62f78: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   62f80: 85 10 00 00 b1 41 ff ff      	call -0xbe4f
   62f88: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   62f90: 55 00 24 00 02 00 00 00      	jne r0, 0x2, +0x24 <.text+0x62f98>
   62f98: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   62fa0: 15 01 0e 00 00 00 00 00      	jeq r1, 0x0, +0xe <.text+0x62ef8>
   62fa8: 79 97 00 00 00 00 00 00      	ldxdw r7, [r9 + 0x0]
   62fb0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   62fb8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   62fc0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   62fc8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   62fd0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   62fd8: 15 01 0b 00 00 00 00 00      	jeq r1, 0x0, +0xb <.text+0x62f18>
   62fe0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   62fe8: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   62ff0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   62ff8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   63000: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   63008: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   63010: 05 00 1f 00 00 00 00 00      	ja +0x1f <.text+0x62ff0>
   63018: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63020: 85 10 00 00 b8 6e 00 00      	call 0x6eb8
   63028: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   63030: 55 00 55 00 02 00 00 00      	jne r0, 0x2, +0x55 <.text+0x631c0>
   63038: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63040: 85 10 00 00 b4 6e 00 00      	call 0x6eb4
   63048: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63050: 55 00 0f 00 02 00 00 00      	jne r0, 0x2, +0xf <.text+0x62fb0>
   63058: 7b 2a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r2
   63060: 05 00 1d 00 00 00 00 00      	ja +0x1d <.text+0x63030>
   63068: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63070: 18 03 00 00 31 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade31
   63080: b7 04 00 00 1e 00 00 00      	mov64 r4, 0x1e
   63088: 85 10 00 00 90 41 ff ff      	call -0xbe70
   63090: 55 00 52 04 02 00 00 00      	jne r0, 0x2, +0x452 <.text+0x65208>
   63098: 7b 1a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r1
   630a0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   630a8: 55 01 98 ff 00 00 00 00      	jne r1, 0x0, -0x68 <.text+0x62c50>
   630b0: 05 00 a3 ff 00 00 00 00      	ja -0x5d <.text+0x62cb0>
   630b8: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   630c0: 7b 81 10 00 00 00 00 00      	stxdw [r1 + 0x10], r8
   630c8: 05 00 e8 00 00 00 00 00      	ja +0xe8 <.text+0x636f0>
   630d0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   630d8: 18 03 00 00 6c de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade6c
   630e8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   630f0: 85 10 00 00 83 41 ff ff      	call -0xbe7d
   630f8: 55 00 45 04 02 00 00 00      	jne r0, 0x2, +0x445 <.text+0x65208>
   63100: 7b 1a 58 fc 00 00 00 00      	stxdw [r10 - 0x3a8], r1
   63108: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63110: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x63030>
   63118: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   63120: 7b 2a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r2
   63128: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   63130: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   63138: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   63140: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   63148: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x630a0>
   63150: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63158: 85 10 00 00 91 6e 00 00      	call 0x6e91
   63160: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63168: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x63060>
   63170: 7b 2a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r2
   63178: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x630e0>
   63180: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63188: 18 03 00 00 84 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade84
   63198: b7 04 00 00 0e 00 00 00      	mov64 r4, 0xe
   631a0: 85 10 00 00 6d 41 ff ff      	call -0xbe93
   631a8: 55 00 2f 04 02 00 00 00      	jne r0, 0x2, +0x42f <.text+0x65208>
   631b0: 7b 1a 48 fc 00 00 00 00      	stxdw [r10 - 0x3b8], r1
   631b8: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   631c0: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x630e0>
   631c8: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   631d0: 7b 2a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r2
   631d8: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   631e0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   631e8: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   631f0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   631f8: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x63150>
   63200: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63208: 85 10 00 00 7b 6e 00 00      	call 0x6e7b
   63210: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63218: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x63110>
   63220: 7b 2a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r2
   63228: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x63190>
   63230: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63238: 18 03 00 00 fa db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbfa
   63248: b7 04 00 00 14 00 00 00      	mov64 r4, 0x14
   63250: 85 10 00 00 57 41 ff ff      	call -0xbea9
   63258: 55 00 19 04 02 00 00 00      	jne r0, 0x2, +0x419 <.text+0x65208>
   63260: 7b 1a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r1
   63268: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63270: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x63190>
   63278: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   63280: 7b 2a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r2
   63288: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   63290: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   63298: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   632a0: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   632a8: 05 00 19 00 00 00 00 00      	ja +0x19 <.text+0x63258>
   632b0: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   632b8: 85 10 00 00 65 6e 00 00      	call 0x6e65
   632c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   632c8: 55 00 0d 00 02 00 00 00      	jne r0, 0x2, +0xd <.text+0x63218>
   632d0: 7b 2a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r2
   632d8: 05 00 1b 00 00 00 00 00      	ja +0x1b <.text+0x63298>
   632e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   632e8: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   632f0: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   63300: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   63308: 85 10 00 00 40 41 ff ff      	call -0xbec0
   63310: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   63318: 55 00 5b 00 02 00 00 00      	jne r0, 0x2, +0x5b <.text+0x634d8>
   63320: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63328: 55 01 96 ff 00 00 00 00      	jne r1, 0x0, -0x6a <.text+0x62ec0>
   63330: 05 00 a0 ff 00 00 00 00      	ja -0x60 <.text+0x62f18>
   63338: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63340: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   63350: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   63358: 85 10 00 00 36 41 ff ff      	call -0xbeca
   63360: 55 00 f8 03 02 00 00 00      	jne r0, 0x2, +0x3f8 <.text+0x65208>
   63368: 7b 1a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r1
   63370: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63378: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x63298>
   63380: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   63388: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   63390: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   63398: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   633a0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   633a8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   633b0: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x63308>
   633b8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   633c0: 85 10 00 00 44 6e 00 00      	call 0x6e44
   633c8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   633d0: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x632c8>
   633d8: 7b 2a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r2
   633e0: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x63348>
   633e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   633f0: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   63400: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   63408: 85 10 00 00 20 41 ff ff      	call -0xbee0
   63410: 55 00 e2 03 02 00 00 00      	jne r0, 0x2, +0x3e2 <.text+0x65208>
   63418: 7b 1a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r1
   63420: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63428: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x63348>
   63430: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   63438: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   63440: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   63448: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   63450: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   63458: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   63460: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x633b8>
   63468: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63470: 85 10 00 00 2e 6e 00 00      	call 0x6e2e
   63478: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63480: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x63378>
   63488: 7b 2a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r2
   63490: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x633f8>
   63498: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   634a0: 18 03 00 00 92 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade92
   634b0: b7 04 00 00 22 00 00 00      	mov64 r4, 0x22
   634b8: 85 10 00 00 0a 41 ff ff      	call -0xbef6
   634c0: 55 00 cc 03 02 00 00 00      	jne r0, 0x2, +0x3cc <.text+0x65208>
   634c8: 7b 1a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r1
   634d0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   634d8: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x633f8>
   634e0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   634e8: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   634f0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   634f8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   63500: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   63508: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   63510: 05 00 0e 00 00 00 00 00      	ja +0xe <.text+0x63468>
   63518: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63520: 85 10 00 00 18 6e 00 00      	call 0x6e18
   63528: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63530: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x63428>
   63538: 7b 2a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r2
   63540: 05 00 10 00 00 00 00 00      	ja +0x10 <.text+0x634a8>
   63548: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63550: 18 03 00 00 82 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd82
   63560: b7 04 00 00 0a 00 00 00      	mov64 r4, 0xa
   63568: 85 10 00 00 f4 40 ff ff      	call -0xbf0c
   63570: 55 00 b6 03 02 00 00 00      	jne r0, 0x2, +0x3b6 <.text+0x65208>
   63578: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   63580: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63588: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x634a8>
   63590: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   63598: 7b 2a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r2
   635a0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   635a8: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   635b0: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   635b8: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   635c0: 05 00 11 00 00 00 00 00      	ja +0x11 <.text+0x63530>
   635c8: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   635d0: 85 10 00 00 02 6e 00 00      	call 0x6e02
   635d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   635e0: 55 00 05 00 02 00 00 00      	jne r0, 0x2, +0x5 <.text+0x634f0>
   635e8: 7b 2a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r2
   635f0: 05 00 13 00 00 00 00 00      	ja +0x13 <.text+0x63570>
   635f8: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   63600: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   63608: 05 00 40 00 00 00 00 00      	ja +0x40 <.text+0x636f0>
   63610: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63618: 18 03 00 00 8c dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd8c
   63628: b7 04 00 00 0b 00 00 00      	mov64 r4, 0xb
   63630: 85 10 00 00 db 40 ff ff      	call -0xbf25
   63638: 55 00 9d 03 02 00 00 00      	jne r0, 0x2, +0x39d <.text+0x65208>
   63640: 7b 1a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r1
   63648: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   63650: 15 01 07 00 00 00 00 00      	jeq r1, 0x0, +0x7 <.text+0x63570>
   63658: 07 01 00 00 ff ff ff ff      	add64 r1, -0x1
   63660: 7b 19 08 00 00 00 00 00      	stxdw [r9 + 0x8], r1
   63668: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   63670: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   63678: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   63680: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   63688: 05 00 0d 00 00 00 00 00      	ja +0xd <.text+0x635d8>
   63690: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63698: 85 10 00 00 e9 6d 00 00      	call 0x6de9
   636a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   636a8: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x635a0>
   636b0: 7b 2a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r2
   636b8: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x635d8>
   636c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   636c8: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   636d8: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   636e0: 85 10 00 00 c5 40 ff ff      	call -0xbf3b
   636e8: 55 00 87 03 02 00 00 00      	jne r0, 0x2, +0x387 <.text+0x65208>
   636f0: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   636f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63700: 07 01 00 00 f8 fc ff ff      	add64 r1, -0x308
   63708: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63710: bf 93 00 00 00 00 00 00      	mov64 r3, r9
   63718: 85 10 00 00 4a 4e ff ff      	call -0xb1b6
   63720: 79 a2 00 fd 00 00 00 00      	ldxdw r2, [r10 - 0x300]
   63728: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   63730: 15 01 06 00 02 00 00 00      	jeq r1, 0x2, +0x6 <.text+0x63648>
   63738: 18 03 00 00 5c db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb5c
   63748: b7 04 00 00 07 00 00 00      	mov64 r4, 0x7
   63750: 85 10 00 00 b7 40 ff ff      	call -0xbf49
   63758: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63760: 55 00 13 00 02 00 00 00      	jne r0, 0x2, +0x13 <.text+0x636e0>
   63768: 7b 2a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r2
   63770: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   63778: 7b 7a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r7
   63780: 15 03 13 00 00 00 00 00      	jeq r3, 0x0, +0x13 <.text+0x63700>
   63788: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   63790: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63798: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   637a0: 7b 29 00 00 00 00 00 00      	stxdw [r9 + 0x0], r2
   637a8: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   637b0: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   637b8: 7b 1a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r1
   637c0: 15 03 10 00 00 00 00 00      	jeq r3, 0x0, +0x10 <.text+0x63728>
   637c8: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   637d0: 7b 39 08 00 00 00 00 00      	stxdw [r9 + 0x8], r3
   637d8: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   637e0: 7b 1a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r1
   637e8: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   637f0: 7b 19 00 00 00 00 00 00      	stxdw [r9 + 0x0], r1
   637f8: 05 00 16 00 00 00 00 00      	ja +0x16 <.text+0x63790>
   63800: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   63808: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   63810: 7b 01 08 00 00 00 00 00      	stxdw [r1 + 0x8], r0
   63818: 05 00 81 fd 00 00 00 00      	ja -0x27f <.text+0x62308>
   63820: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63828: 85 10 00 00 b7 6d 00 00      	call 0x6db7
   63830: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63838: 55 00 6c 00 02 00 00 00      	jne r0, 0x2, +0x6c <.text+0x63a80>
   63840: 7b 2a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r2
   63848: b7 01 00 00 bd 0b 00 00      	mov64 r1, 0xbbd
   63850: 85 10 00 00 b2 6d 00 00      	call 0x6db2
   63858: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63860: 55 00 02 00 02 00 00 00      	jne r0, 0x2, +0x2 <.text+0x63758>
   63868: 7b 2a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r2
   63870: 05 00 07 00 00 00 00 00      	ja +0x7 <.text+0x63790>
   63878: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63880: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   63890: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   63898: 85 10 00 00 8e 40 ff ff      	call -0xbf72
   638a0: 55 00 50 03 02 00 00 00      	jne r0, 0x2, +0x350 <.text+0x65208>
   638a8: 7b 1a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r1
   638b0: 18 01 00 00 40 13 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1340
   638c0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   638c8: 7b 2a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r2
   638d0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   638d8: 7b 2a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r2
   638e0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   638e8: 7b 2a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r2
   638f0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   638f8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   63900: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   63908: 7a 0a 28 ff 00 00 00 00      	stdw [r10 - 0xd8], 0x0
   63910: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   63918: 07 07 00 00 08 fd ff ff      	add64 r7, -0x2f8
   63920: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63928: 07 02 00 00 00 ff ff ff      	add64 r2, -0x100
   63930: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   63938: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   63940: 85 10 00 00 88 8d 00 00      	call 0x8d88
   63948: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   63950: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63958: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63960: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63968: 7b 2a 50 fd 00 00 00 00      	stxdw [r10 - 0x2b0], r2
   63970: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63978: 7b 2a 48 fd 00 00 00 00      	stxdw [r10 - 0x2b8], r2
   63980: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63988: 7b 2a 40 fd 00 00 00 00      	stxdw [r10 - 0x2c0], r2
   63990: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63998: 7b 1a 38 fd 00 00 00 00      	stxdw [r10 - 0x2c8], r1
   639a0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   639a8: 07 02 00 00 38 fd ff ff      	add64 r2, -0x2c8
   639b0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   639b8: 85 10 00 00 36 4e ff ff      	call -0xb1ca
   639c0: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x638e8>
   639c8: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   639d0: 85 10 00 00 82 6d 00 00      	call 0x6d82
   639d8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   639e0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   639e8: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   639f8: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   63a00: 05 00 55 00 00 00 00 00      	ja +0x55 <.text+0x63b90>
   63a08: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   63a10: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63a18: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63a20: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63a28: 7b 2a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r2
   63a30: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63a38: 7b 2a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r2
   63a40: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63a48: 7b 2a 60 fd 00 00 00 00      	stxdw [r10 - 0x2a0], r2
   63a50: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63a58: 7b 1a 58 fd 00 00 00 00      	stxdw [r10 - 0x2a8], r1
   63a60: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63a68: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   63a70: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63a78: 07 02 00 00 58 fd ff ff      	add64 r2, -0x2a8
   63a80: 85 10 00 00 1d 4e ff ff      	call -0xb1e3
   63a88: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x639b0>
   63a90: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   63a98: 85 10 00 00 69 6d 00 00      	call 0x6d69
   63aa0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63aa8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63ab0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   63ac0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   63ac8: 05 00 3c 00 00 00 00 00      	ja +0x3c <.text+0x63b90>
   63ad0: 7b 8a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r8
   63ad8: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   63ae0: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   63ae8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63af0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63af8: 7b 2a 90 fd 00 00 00 00      	stxdw [r10 - 0x270], r2
   63b00: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63b08: 7b 2a 88 fd 00 00 00 00      	stxdw [r10 - 0x278], r2
   63b10: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63b18: 7b 2a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r2
   63b20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63b28: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   63b30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63b38: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   63b40: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63b48: 07 02 00 00 78 fd ff ff      	add64 r2, -0x288
   63b50: 85 10 00 00 03 4e ff ff      	call -0xb1fd
   63b58: 15 00 12 00 00 00 00 00      	jeq r0, 0x0, +0x12 <.text+0x63ad0>
   63b60: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   63b68: 85 10 00 00 4f 6d 00 00      	call 0x6d4f
   63b70: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63b78: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63b80: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   63b90: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   63b98: 05 00 22 00 00 00 00 00      	ja +0x22 <.text+0x63b90>
   63ba0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63ba8: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   63bb8: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   63bc0: 85 10 00 00 29 40 ff ff      	call -0xbfd7
   63bc8: 55 00 eb 02 02 00 00 00      	jne r0, 0x2, +0x2eb <.text+0x65208>
   63bd0: 79 93 08 00 00 00 00 00      	ldxdw r3, [r9 + 0x8]
   63bd8: 7b 1a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r1
   63be0: 55 03 7c ff 00 00 00 00      	jne r3, 0x0, -0x84 <.text+0x636a8>
   63be8: 05 00 8b ff 00 00 00 00      	ja -0x75 <.text+0x63728>
   63bf0: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   63bf8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   63c00: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63c08: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63c10: 7b 2a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r2
   63c18: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63c20: 7b 2a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r2
   63c28: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63c30: 7b 2a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r2
   63c38: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63c40: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   63c48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63c50: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   63c58: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63c60: 07 02 00 00 98 fd ff ff      	add64 r2, -0x268
   63c68: 85 10 00 00 e0 4d ff ff      	call -0xb220
   63c70: 15 00 0d 00 00 00 00 00      	jeq r0, 0x0, +0xd <.text+0x63bc0>
   63c78: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   63c80: 85 10 00 00 2c 6d 00 00      	call 0x6d2c
   63c88: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63c90: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63c98: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   63ca8: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   63cb0: 85 10 00 00 0b 40 ff ff      	call -0xbff5
   63cb8: 79 a2 60 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a0]
   63cc0: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   63cc8: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   63cd0: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   63cd8: 05 00 ea fc 00 00 00 00      	ja -0x316 <.text+0x62310>
   63ce0: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   63ce8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63cf0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63cf8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63d00: 7b 2a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r2
   63d08: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63d10: 7b 2a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r2
   63d18: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63d20: 7b 2a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r2
   63d28: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63d30: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   63d38: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63d40: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   63d48: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63d50: 07 02 00 00 b8 fd ff ff      	add64 r2, -0x248
   63d58: 85 10 00 00 c2 4d ff ff      	call -0xb23e
   63d60: 15 00 07 00 00 00 00 00      	jeq r0, 0x0, +0x7 <.text+0x63c80>
   63d68: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   63d70: 85 10 00 00 0e 6d 00 00      	call 0x6d0e
   63d78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63d80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63d88: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   63d98: 05 00 8b ff 00 00 00 00      	ja -0x75 <.text+0x638d8>
   63da0: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   63da8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   63db0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63db8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63dc0: 7b 2a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r2
   63dc8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63dd0: 7b 2a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r2
   63dd8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63de0: 7b 2a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r2
   63de8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63df0: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   63df8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63e00: 07 01 00 00 08 fd ff ff      	add64 r1, -0x2f8
   63e08: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63e10: 07 02 00 00 d8 fd ff ff      	add64 r2, -0x228
   63e18: 85 10 00 00 aa 4d ff ff      	call -0xb256
   63e20: 15 00 08 00 00 00 00 00      	jeq r0, 0x0, +0x8 <.text+0x63d48>
   63e28: b7 01 00 00 f8 07 00 00      	mov64 r1, 0x7f8
   63e30: 85 10 00 00 f6 6c 00 00      	call 0x6cf6
   63e38: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   63e40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   63e48: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   63e58: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   63e60: 05 00 97 02 00 00 00 00      	ja +0x297 <.text+0x65200>
   63e68: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   63e70: 15 01 8e 02 00 00 00 00      	jeq r1, 0x0, +0x28e <.text+0x651c8>
   63e78: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   63e80: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   63e88: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   63e90: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63e98: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   63ea0: 18 01 00 00 50 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1950
   63eb0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   63eb8: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   63ec0: 85 10 00 00 ff ff ff ff      	call -0x1
   63ec8: 55 00 01 03 00 00 00 00      	jne r0, 0x0, +0x301 <.text+0x655b8>
   63ed0: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   63ed8: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   63ee0: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   63ee8: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   63ef0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   63ef8: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   63f00: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   63f08: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   63f10: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   63f18: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63f20: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   63f28: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   63f30: 5d 73 83 02 00 00 00 00      	jne r3, r7, +0x283 <.text+0x65230>
   63f38: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   63f40: 5d 93 81 02 00 00 00 00      	jne r3, r9, +0x281 <.text+0x65230>
   63f48: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   63f50: 5d 83 7f 02 00 00 00 00      	jne r3, r8, +0x27f <.text+0x65230>
   63f58: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   63f60: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   63f68: 5d 32 7c 02 00 00 00 00      	jne r2, r3, +0x27c <.text+0x65230>
   63f70: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   63f78: 15 01 98 02 00 00 00 00      	jeq r1, 0x0, +0x298 <.text+0x65320>
   63f80: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   63f88: 79 21 40 00 00 00 00 00      	ldxdw r1, [r2 + 0x40]
   63f90: 7b 1a 48 fb 00 00 00 00      	stxdw [r10 - 0x4b8], r1
   63f98: 79 21 38 00 00 00 00 00      	ldxdw r1, [r2 + 0x38]
   63fa0: 7b 1a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r1
   63fa8: 79 21 30 00 00 00 00 00      	ldxdw r1, [r2 + 0x30]
   63fb0: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   63fb8: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   63fc0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   63fc8: 7b 3a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r3
   63fd0: 79 17 10 00 00 00 00 00      	ldxdw r7, [r1 + 0x10]
   63fd8: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   63fe0: 79 22 28 00 00 00 00 00      	ldxdw r2, [r2 + 0x28]
   63fe8: 79 19 00 00 00 00 00 00      	ldxdw r9, [r1 + 0x0]
   63ff0: 7b 2a 38 fb 00 00 00 00      	stxdw [r10 - 0x4c8], r2
   63ff8: 5d 92 90 02 00 00 00 00      	jne r2, r9, +0x290 <.text+0x65360>
   64000: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   64008: 5d 81 8e 02 00 00 00 00      	jne r1, r8, +0x28e <.text+0x65360>
   64010: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   64018: 5d 71 8c 02 00 00 00 00      	jne r1, r7, +0x28c <.text+0x65360>
   64020: 79 a1 48 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b8]
   64028: 79 a2 40 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4c0]
   64030: 5d 21 89 02 00 00 00 00      	jne r1, r2, +0x289 <.text+0x65360>
   64038: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   64040: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   64048: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64050: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64058: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64060: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   64068: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64070: 18 05 00 00 0e dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc0e
   64080: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   64088: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64090: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   64098: 7b 5a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r5
   640a0: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   640a8: 7b 4a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r4
   640b0: 7b 3a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r3
   640b8: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   640c0: 7a 0a e0 fe 0c 00 00 00      	stdw [r10 - 0x120], 0xc
   640c8: 7a 0a f0 fe 20 00 00 00      	stdw [r10 - 0x110], 0x20
   640d0: 72 0a 78 fe ff 00 00 00      	stb [r10 - 0x188], 0xff
   640d8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   640e0: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   640e8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   640f0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   640f8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64100: 07 05 00 00 78 fe ff ff      	add64 r5, -0x188
   64108: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   64110: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   64118: 85 10 00 00 ff ff ff ff      	call -0x1
   64120: 55 00 b6 02 00 00 00 00      	jne r0, 0x0, +0x2b6 <.text+0x655b8>
   64128: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64130: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   64138: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   64140: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   64148: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   64150: 71 a1 78 fe 00 00 00 00      	ldxb r1, [r10 - 0x188]
   64158: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   64160: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   64168: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   64170: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64178: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64180: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   64188: 5d 73 75 02 00 00 00 00      	jne r3, r7, +0x275 <.text+0x65418>
   64190: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   64198: 5d 93 73 02 00 00 00 00      	jne r3, r9, +0x273 <.text+0x65418>
   641a0: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   641a8: 5d 83 71 02 00 00 00 00      	jne r3, r8, +0x271 <.text+0x65418>
   641b0: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   641b8: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   641c0: 5d 32 6e 02 00 00 00 00      	jne r2, r3, +0x26e <.text+0x65418>
   641c8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   641d0: 15 01 77 02 00 00 00 00      	jeq r1, 0x0, +0x277 <.text+0x65470>
   641d8: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   641e0: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   641e8: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   641f0: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   641f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64200: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   64208: 85 10 00 00 70 4a ff ff      	call -0xb590
   64210: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64218: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   64220: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   64228: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   64230: 5d 34 73 02 00 00 00 00      	jne r4, r3, +0x273 <.text+0x654b0>
   64238: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64240: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   64248: 5d 34 70 02 00 00 00 00      	jne r4, r3, +0x270 <.text+0x654b0>
   64250: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   64258: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   64260: 5d 34 6d 02 00 00 00 00      	jne r4, r3, +0x26d <.text+0x654b0>
   64268: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64270: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   64278: 5d 12 6a 02 00 00 00 00      	jne r2, r1, +0x26a <.text+0x654b0>
   64280: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64288: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   64290: 85 10 00 00 89 47 ff ff      	call -0xb877
   64298: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   642a0: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   642a8: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   642b0: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   642b8: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   642c0: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   642c8: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   642d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   642d8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   642e0: 7b 2a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r2
   642e8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   642f0: 7b 2a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r2
   642f8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64300: 7b 2a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r2
   64308: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64310: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   64318: 79 a1 f8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x208]
   64320: 5d 17 60 02 00 00 00 00      	jne r7, r1, +0x260 <.text+0x65508>
   64328: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   64330: 5d 18 5e 02 00 00 00 00      	jne r8, r1, +0x25e <.text+0x65508>
   64338: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   64340: 5d 19 5c 02 00 00 00 00      	jne r9, r1, +0x25c <.text+0x65508>
   64348: 79 a1 10 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f0]
   64350: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   64358: 5d 12 59 02 00 00 00 00      	jne r2, r1, +0x259 <.text+0x65508>
   64360: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   64368: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   64370: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   64378: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   64380: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   64388: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   64390: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   64398: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   643a0: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   643a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   643b0: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   643b8: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   643c0: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   643c8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   643d0: 85 10 00 00 37 4a ff ff      	call -0xb5c9
   643d8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   643e0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   643e8: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   643f0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   643f8: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   64400: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64408: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   64410: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64418: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   64420: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64428: 07 01 00 00 18 fe ff ff      	add64 r1, -0x1e8
   64430: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   64438: 07 02 00 00 f8 fd ff ff      	add64 r2, -0x208
   64440: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   64448: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   64450: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64458: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   64460: 85 10 00 00 03 63 00 00      	call 0x6303
   64468: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   64470: 85 10 00 00 4d 47 ff ff      	call -0xb8b3
   64478: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   64480: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   64488: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64490: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   64498: 7b 3a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r3
   644a0: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   644a8: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   644b0: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   644b8: 79 a2 18 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1e8]
   644c0: 5d 27 4e 02 00 00 00 00      	jne r7, r2, +0x24e <.text+0x65618>
   644c8: 79 a2 20 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1e0]
   644d0: 5d 28 4c 02 00 00 00 00      	jne r8, r2, +0x24c <.text+0x65618>
   644d8: 79 a2 28 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1d8]
   644e0: 5d 29 4a 02 00 00 00 00      	jne r9, r2, +0x24a <.text+0x65618>
   644e8: 79 a2 30 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1d0]
   644f0: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   644f8: 5d 23 47 02 00 00 00 00      	jne r3, r2, +0x247 <.text+0x65618>
   64500: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64508: 15 01 5c 02 00 00 00 00      	jeq r1, 0x0, +0x25c <.text+0x656d0>
   64510: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   64518: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   64520: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64528: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   64530: 79 a2 20 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e0]
   64538: 85 10 00 00 0a 4a ff ff      	call -0xb5f6
   64540: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64548: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   64550: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   64558: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   64560: 5d 34 0d 02 00 00 00 00      	jne r4, r3, +0x20d <.text+0x654b0>
   64568: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64570: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   64578: 5d 34 0a 02 00 00 00 00      	jne r4, r3, +0x20a <.text+0x654b0>
   64580: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   64588: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   64590: 5d 34 07 02 00 00 00 00      	jne r4, r3, +0x207 <.text+0x654b0>
   64598: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   645a0: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   645a8: 5d 12 04 02 00 00 00 00      	jne r2, r1, +0x204 <.text+0x654b0>
   645b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   645b8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   645c0: 85 10 00 00 23 47 ff ff      	call -0xb8dd
   645c8: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   645d0: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   645d8: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   645e0: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   645e8: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   645f0: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   645f8: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   64600: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64608: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64610: 7b 2a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r2
   64618: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64620: 7b 2a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r2
   64628: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64630: 7b 2a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r2
   64638: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64640: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   64648: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   64650: 5d 17 3b 02 00 00 00 00      	jne r7, r1, +0x23b <.text+0x65710>
   64658: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   64660: 5d 18 39 02 00 00 00 00      	jne r8, r1, +0x239 <.text+0x65710>
   64668: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   64670: 5d 19 37 02 00 00 00 00      	jne r9, r1, +0x237 <.text+0x65710>
   64678: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   64680: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   64688: 5d 12 34 02 00 00 00 00      	jne r2, r1, +0x234 <.text+0x65710>
   64690: 79 a2 20 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e0]
   64698: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   646a0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   646a8: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   646b0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   646b8: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   646c0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   646c8: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   646d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   646d8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   646e0: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   646e8: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   646f0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   646f8: 85 10 00 00 d2 49 ff ff      	call -0xb62e
   64700: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64708: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64710: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   64718: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64720: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   64728: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64730: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   64738: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64740: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   64748: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64750: 07 01 00 00 58 fe ff ff      	add64 r1, -0x1a8
   64758: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   64760: 07 02 00 00 38 fe ff ff      	add64 r2, -0x1c8
   64768: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   64770: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   64778: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64780: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   64788: 85 10 00 00 9e 62 00 00      	call 0x629e
   64790: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   64798: 85 10 00 00 e8 46 ff ff      	call -0xb918
   647a0: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   647a8: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   647b0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   647b8: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   647c0: 7b 3a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r3
   647c8: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   647d0: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   647d8: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   647e0: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   647e8: 5d 27 1e 02 00 00 00 00      	jne r7, r2, +0x21e <.text+0x657c0>
   647f0: 79 a2 60 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a0]
   647f8: 5d 28 1c 02 00 00 00 00      	jne r8, r2, +0x21c <.text+0x657c0>
   64800: 79 a2 68 fe 00 00 00 00      	ldxdw r2, [r10 - 0x198]
   64808: 5d 29 1a 02 00 00 00 00      	jne r9, r2, +0x21a <.text+0x657c0>
   64810: 79 a2 70 fe 00 00 00 00      	ldxdw r2, [r10 - 0x190]
   64818: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   64820: 5d 23 17 02 00 00 00 00      	jne r3, r2, +0x217 <.text+0x657c0>
   64828: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64830: 15 01 2b 02 00 00 00 00      	jeq r1, 0x0, +0x22b <.text+0x65870>
   64838: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   64840: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64848: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   64850: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64858: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   64860: 18 01 00 00 88 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1988
   64870: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   64878: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   64880: 85 10 00 00 ff ff ff ff      	call -0x1
   64888: 55 00 c9 01 00 00 00 00      	jne r0, 0x0, +0x1c9 <.text+0x655b8>
   64890: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64898: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   648a0: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   648a8: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   648b0: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   648b8: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   648c0: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   648c8: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   648d0: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   648d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   648e0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   648e8: 5d 72 1c 02 00 00 00 00      	jne r2, r7, +0x21c <.text+0x658b0>
   648f0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   648f8: 5d 82 1a 02 00 00 00 00      	jne r2, r8, +0x21a <.text+0x658b0>
   64900: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64908: 5d 92 18 02 00 00 00 00      	jne r2, r9, +0x218 <.text+0x658b0>
   64910: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64918: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   64920: 5d 21 15 02 00 00 00 00      	jne r1, r2, +0x215 <.text+0x658b0>
   64928: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   64930: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64938: 15 01 2b 02 00 00 00 00      	jeq r1, 0x0, +0x22b <.text+0x65978>
   64940: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   64948: 79 11 58 00 00 00 00 00      	ldxdw r1, [r1 + 0x58]
   64950: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64958: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64960: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64968: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   64970: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64978: 18 05 00 00 1a dc 0a 00 00 00 00 00 00 00 00 00      	lddw r5, 0xadc1a
   64988: 7b 5a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r5
   64990: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64998: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   649a0: 7b 5a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r5
   649a8: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   649b0: 7b 4a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r4
   649b8: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   649c0: 7b 2a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r2
   649c8: 7a 0a 80 fe 0d 00 00 00      	stdw [r10 - 0x180], 0xd
   649d0: 7a 0a 90 fe 20 00 00 00      	stdw [r10 - 0x170], 0x20
   649d8: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   649e8: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   649f0: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   64a00: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   64a08: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   64a18: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   64a20: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   64a30: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   64a38: 72 0a ff fe ff 00 00 00      	stb [r10 - 0x101], 0xff
   64a40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64a48: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   64a50: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   64a58: 07 03 00 00 08 fd ff ff      	add64 r3, -0x2f8
   64a60: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64a68: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   64a70: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64a78: 07 05 00 00 ff fe ff ff      	add64 r5, -0x101
   64a80: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   64a88: 85 10 00 00 ff ff ff ff      	call -0x1
   64a90: 55 00 88 01 00 00 00 00      	jne r0, 0x0, +0x188 <.text+0x655b8>
   64a98: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64aa0: 7b 1a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r1
   64aa8: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   64ab0: 79 a9 08 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf8]
   64ab8: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   64ac0: 71 a1 ff fe 00 00 00 00      	ldxb r1, [r10 - 0x101]
   64ac8: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   64ad0: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   64ad8: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   64ae0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64ae8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64af0: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   64af8: 5d 73 fb 01 00 00 00 00      	jne r3, r7, +0x1fb <.text+0x659b8>
   64b00: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   64b08: 5d 93 f9 01 00 00 00 00      	jne r3, r9, +0x1f9 <.text+0x659b8>
   64b10: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   64b18: 5d 83 f7 01 00 00 00 00      	jne r3, r8, +0x1f7 <.text+0x659b8>
   64b20: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   64b28: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   64b30: 5d 32 f4 01 00 00 00 00      	jne r2, r3, +0x1f4 <.text+0x659b8>
   64b38: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64b40: 15 01 fd 01 00 00 00 00      	jeq r1, 0x0, +0x1fd <.text+0x65a10>
   64b48: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   64b50: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64b58: 15 01 01 02 00 00 00 00      	jeq r1, 0x0, +0x201 <.text+0x65a48>
   64b60: 79 a1 c8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x438]
   64b68: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64b70: 15 01 06 02 00 00 00 00      	jeq r1, 0x0, +0x206 <.text+0x65a88>
   64b78: 79 a1 c0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x440]
   64b80: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64b88: 15 01 0a 02 00 00 00 00      	jeq r1, 0x0, +0x20a <.text+0x65ac0>
   64b90: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   64b98: 79 17 20 00 00 00 00 00      	ldxdw r7, [r1 + 0x20]
   64ba0: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   64ba8: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   64bb0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64bb8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   64bc0: 85 10 00 00 39 49 ff ff      	call -0xb6c7
   64bc8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64bd0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   64bd8: 79 72 18 00 00 00 00 00      	ldxdw r2, [r7 + 0x18]
   64be0: 79 24 00 00 00 00 00 00      	ldxdw r4, [r2 + 0x0]
   64be8: 5d 34 3c 01 00 00 00 00      	jne r4, r3, +0x13c <.text+0x654b0>
   64bf0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64bf8: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   64c00: 5d 34 39 01 00 00 00 00      	jne r4, r3, +0x139 <.text+0x654b0>
   64c08: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   64c10: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   64c18: 5d 34 36 01 00 00 00 00      	jne r4, r3, +0x136 <.text+0x654b0>
   64c20: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64c28: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   64c30: 5d 12 33 01 00 00 00 00      	jne r2, r1, +0x133 <.text+0x654b0>
   64c38: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64c40: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   64c48: 85 10 00 00 52 46 ff ff      	call -0xb9ae
   64c50: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   64c58: 79 12 60 00 00 00 00 00      	ldxdw r2, [r1 + 0x60]
   64c60: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   64c68: 79 19 58 00 00 00 00 00      	ldxdw r9, [r1 + 0x58]
   64c70: 79 18 50 00 00 00 00 00      	ldxdw r8, [r1 + 0x50]
   64c78: 79 17 48 00 00 00 00 00      	ldxdw r7, [r1 + 0x48]
   64c80: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   64c88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64c90: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64c98: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64ca0: 7b 2a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r2
   64ca8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64cb0: 7b 2a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r2
   64cb8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64cc0: 7b 2a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r2
   64cc8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64cd0: 7b 1a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r1
   64cd8: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   64ce0: 5d 17 e7 01 00 00 00 00      	jne r7, r1, +0x1e7 <.text+0x65b00>
   64ce8: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   64cf0: 5d 18 e5 01 00 00 00 00      	jne r8, r1, +0x1e5 <.text+0x65b00>
   64cf8: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   64d00: 5d 19 e3 01 00 00 00 00      	jne r9, r1, +0x1e3 <.text+0x65b00>
   64d08: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   64d10: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   64d18: 5d 12 e0 01 00 00 00 00      	jne r2, r1, +0x1e0 <.text+0x65b00>
   64d20: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   64d28: 79 12 58 00 00 00 00 00      	ldxdw r2, [r1 + 0x58]
   64d30: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   64d38: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   64d40: 7b 3a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r3
   64d48: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   64d50: 7b 3a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r3
   64d58: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   64d60: 7b 3a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r3
   64d68: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64d70: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   64d78: bf a7 00 00 00 00 00 00      	mov64 r7, r10
   64d80: 07 07 00 00 00 ff ff ff      	add64 r7, -0x100
   64d88: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   64d90: 85 10 00 00 ff 48 ff ff      	call -0xb701
   64d98: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   64da0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64da8: 7b 2a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r2
   64db0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64db8: 7b 2a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r2
   64dc0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64dc8: 7b 2a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r2
   64dd0: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   64dd8: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   64de0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64de8: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   64df0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   64df8: 07 02 00 00 98 fe ff ff      	add64 r2, -0x168
   64e00: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   64e08: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   64e10: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64e18: 07 04 00 00 08 fd ff ff      	add64 r4, -0x2f8
   64e20: 85 10 00 00 cb 61 00 00      	call 0x61cb
   64e28: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   64e30: 85 10 00 00 15 46 ff ff      	call -0xb9eb
   64e38: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   64e40: 79 11 20 00 00 00 00 00      	ldxdw r1, [r1 + 0x20]
   64e48: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   64e50: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   64e58: 7b 3a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r3
   64e60: 79 29 10 00 00 00 00 00      	ldxdw r9, [r2 + 0x10]
   64e68: 79 28 08 00 00 00 00 00      	ldxdw r8, [r2 + 0x8]
   64e70: 79 27 00 00 00 00 00 00      	ldxdw r7, [r2 + 0x0]
   64e78: 79 a2 b8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x148]
   64e80: 5d 27 c9 01 00 00 00 00      	jne r7, r2, +0x1c9 <.text+0x65bb0>
   64e88: 79 a2 c0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x140]
   64e90: 5d 28 c7 01 00 00 00 00      	jne r8, r2, +0x1c7 <.text+0x65bb0>
   64e98: 79 a2 c8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x138]
   64ea0: 5d 29 c5 01 00 00 00 00      	jne r9, r2, +0x1c5 <.text+0x65bb0>
   64ea8: 79 a2 d0 fe 00 00 00 00      	ldxdw r2, [r10 - 0x130]
   64eb0: 79 a3 58 fb 00 00 00 00      	ldxdw r3, [r10 - 0x4a8]
   64eb8: 5d 23 c2 01 00 00 00 00      	jne r3, r2, +0x1c2 <.text+0x65bb0>
   64ec0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64ec8: 15 01 d6 01 00 00 00 00      	jeq r1, 0x0, +0x1d6 <.text+0x65c60>
   64ed0: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   64ed8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64ee0: 15 01 d5 01 00 00 00 00      	jeq r1, 0x0, +0x1d5 <.text+0x65c70>
   64ee8: 79 a1 58 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a8]
   64ef0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64ef8: 15 01 d9 01 00 00 00 00      	jeq r1, 0x0, +0x1d9 <.text+0x65ca8>
   64f00: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   64f08: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64f10: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64f18: 7b 2a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r2
   64f20: 79 19 10 00 00 00 00 00      	ldxdw r9, [r1 + 0x10]
   64f28: 79 18 08 00 00 00 00 00      	ldxdw r8, [r1 + 0x8]
   64f30: 79 17 00 00 00 00 00 00      	ldxdw r7, [r1 + 0x0]
   64f38: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   64f48: 5d 17 d6 01 00 00 00 00      	jne r7, r1, +0x1d6 <.text+0x65ce0>
   64f50: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   64f60: 5d 18 d3 01 00 00 00 00      	jne r8, r1, +0x1d3 <.text+0x65ce0>
   64f68: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   64f78: 5d 19 d0 01 00 00 00 00      	jne r9, r1, +0x1d0 <.text+0x65ce0>
   64f80: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   64f90: 79 a2 58 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a8]
   64f98: 5d 12 cc 01 00 00 00 00      	jne r2, r1, +0x1cc <.text+0x65ce0>
   64fa0: 79 a1 a8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x458]
   64fa8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64fb0: 15 01 e3 01 00 00 00 00      	jeq r1, 0x0, +0x1e3 <.text+0x65db0>
   64fb8: 79 a1 a0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x460]
   64fc0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   64fc8: 15 01 e7 01 00 00 00 00      	jeq r1, 0x0, +0x1e7 <.text+0x65de8>
   64fd0: 72 0a 08 fd ff 00 00 00      	stb [r10 - 0x2f8], 0xff
   64fd8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64fe0: 07 04 00 00 00 ff ff ff      	add64 r4, -0x100
   64fe8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64ff0: 07 05 00 00 08 fd ff ff      	add64 r5, -0x2f8
   64ff8: 18 01 00 00 78 19 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1978
   65008: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   65010: 79 a3 50 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b0]
   65018: 85 10 00 00 ff ff ff ff      	call -0x1
   65020: 55 00 d6 00 00 00 00 00      	jne r0, 0x0, +0xd6 <.text+0x655b8>
   65028: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   65030: 7b 1a 50 fc 00 00 00 00      	stxdw [r10 - 0x3b0], r1
   65038: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   65040: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   65048: 79 a7 00 ff 00 00 00 00      	ldxdw r7, [r10 - 0x100]
   65050: 71 a1 08 fd 00 00 00 00      	ldxb r1, [r10 - 0x2f8]
   65058: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   65060: 73 12 04 00 00 00 00 00      	stxb [r2 + 0x4], r1
   65068: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   65070: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   65078: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   65080: 5d 72 d8 01 00 00 00 00      	jne r2, r7, +0x1d8 <.text+0x65e28>
   65088: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   65090: 5d 82 d6 01 00 00 00 00      	jne r2, r8, +0x1d6 <.text+0x65e28>
   65098: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   650a0: 5d 92 d4 01 00 00 00 00      	jne r2, r9, +0x1d4 <.text+0x65e28>
   650a8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   650b0: 79 a2 50 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b0]
   650b8: 5d 21 d1 01 00 00 00 00      	jne r1, r2, +0x1d1 <.text+0x65e28>
   650c0: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   650c8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   650d0: 15 01 e3 01 00 00 00 00      	jeq r1, 0x0, +0x1e3 <.text+0x65ed0>
   650d8: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   650e0: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   650e8: 15 01 e7 01 00 00 00 00      	jeq r1, 0x0, +0x1e7 <.text+0x65f08>
   650f0: 79 a1 60 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3a0]
   650f8: 79 a2 68 fb 00 00 00 00      	ldxdw r2, [r10 - 0x498]
   65100: 7b 21 f0 00 00 00 00 00      	stxdw [r1 + 0xf0], r2
   65108: 79 a2 70 fb 00 00 00 00      	ldxdw r2, [r10 - 0x490]
   65110: 7b 21 e8 00 00 00 00 00      	stxdw [r1 + 0xe8], r2
   65118: 79 a2 78 fb 00 00 00 00      	ldxdw r2, [r10 - 0x488]
   65120: 7b 21 e0 00 00 00 00 00      	stxdw [r1 + 0xe0], r2
   65128: 79 a2 88 fb 00 00 00 00      	ldxdw r2, [r10 - 0x478]
   65130: 7b 21 d8 00 00 00 00 00      	stxdw [r1 + 0xd8], r2
   65138: 79 a2 90 fb 00 00 00 00      	ldxdw r2, [r10 - 0x470]
   65140: 7b 21 d0 00 00 00 00 00      	stxdw [r1 + 0xd0], r2
   65148: 79 a2 98 fb 00 00 00 00      	ldxdw r2, [r10 - 0x468]
   65150: 7b 21 c8 00 00 00 00 00      	stxdw [r1 + 0xc8], r2
   65158: 79 a2 a0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x460]
   65160: 7b 21 c0 00 00 00 00 00      	stxdw [r1 + 0xc0], r2
   65168: 79 a2 a8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x458]
   65170: 7b 21 b8 00 00 00 00 00      	stxdw [r1 + 0xb8], r2
   65178: 79 a2 b0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x450]
   65180: 7b 21 b0 00 00 00 00 00      	stxdw [r1 + 0xb0], r2
   65188: 79 a2 b8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x448]
   65190: 7b 21 a8 00 00 00 00 00      	stxdw [r1 + 0xa8], r2
   65198: 79 a2 48 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3b8]
   651a0: 7b 21 a0 00 00 00 00 00      	stxdw [r1 + 0xa0], r2
   651a8: 79 a2 58 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a8]
   651b0: 7b 21 98 00 00 00 00 00      	stxdw [r1 + 0x98], r2
   651b8: 79 a2 80 fb 00 00 00 00      	ldxdw r2, [r10 - 0x480]
   651c0: 7b 21 90 00 00 00 00 00      	stxdw [r1 + 0x90], r2
   651c8: 79 a2 60 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4a0]
   651d0: 7b 21 88 00 00 00 00 00      	stxdw [r1 + 0x88], r2
   651d8: 79 a2 c0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x440]
   651e0: 7b 21 80 00 00 00 00 00      	stxdw [r1 + 0x80], r2
   651e8: 79 a2 c8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x438]
   651f0: 7b 21 78 00 00 00 00 00      	stxdw [r1 + 0x78], r2
   651f8: 79 a2 d0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x430]
   65200: 7b 21 70 00 00 00 00 00      	stxdw [r1 + 0x70], r2
   65208: 79 a2 d8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x428]
   65210: 7b 21 68 00 00 00 00 00      	stxdw [r1 + 0x68], r2
   65218: 79 a2 e0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x420]
   65220: 7b 21 60 00 00 00 00 00      	stxdw [r1 + 0x60], r2
   65228: 79 a2 e8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x418]
   65230: 7b 21 58 00 00 00 00 00      	stxdw [r1 + 0x58], r2
   65238: 79 a2 f0 fb 00 00 00 00      	ldxdw r2, [r10 - 0x410]
   65240: 7b 21 50 00 00 00 00 00      	stxdw [r1 + 0x50], r2
   65248: 79 a2 f8 fb 00 00 00 00      	ldxdw r2, [r10 - 0x408]
   65250: 7b 21 48 00 00 00 00 00      	stxdw [r1 + 0x48], r2
   65258: 79 a2 00 fc 00 00 00 00      	ldxdw r2, [r10 - 0x400]
   65260: 7b 21 40 00 00 00 00 00      	stxdw [r1 + 0x40], r2
   65268: 79 a2 08 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f8]
   65270: 7b 21 38 00 00 00 00 00      	stxdw [r1 + 0x38], r2
   65278: 79 a2 10 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3f0]
   65280: 7b 21 30 00 00 00 00 00      	stxdw [r1 + 0x30], r2
   65288: 79 a2 18 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e8]
   65290: 7b 21 28 00 00 00 00 00      	stxdw [r1 + 0x28], r2
   65298: 79 a2 20 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e0]
   652a0: 7b 21 20 00 00 00 00 00      	stxdw [r1 + 0x20], r2
   652a8: 79 a2 28 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d8]
   652b0: 7b 21 18 00 00 00 00 00      	stxdw [r1 + 0x18], r2
   652b8: 79 a2 30 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3d0]
   652c0: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   652c8: 79 a2 38 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c8]
   652d0: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   652d8: 7b 61 00 00 00 00 00 00      	stxdw [r1 + 0x0], r6
   652e0: 05 00 29 fa 00 00 00 00      	ja -0x5d7 <.text+0x62310>
   652e8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   652f0: 85 10 00 00 5e 6a 00 00      	call 0x6a5e
   652f8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65300: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65308: 18 03 00 00 55 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc55
   65318: b7 04 00 00 06 00 00 00      	mov64 r4, 0x6
   65320: 85 10 00 00 3d 3d ff ff      	call -0xc2c3
   65328: 79 a2 60 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3a0]
   65330: 7b 12 10 00 00 00 00 00      	stxdw [r2 + 0x10], r1
   65338: 7b 02 08 00 00 00 00 00      	stxdw [r2 + 0x8], r0
   65340: 7a 02 00 00 00 00 00 00      	stdw [r2 + 0x0], 0x0
   65348: 05 00 1c fa 00 00 00 00      	ja -0x5e4 <.text+0x62310>
   65350: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   65358: 85 10 00 00 51 6a 00 00      	call 0x6a51
   65360: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65368: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65370: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   65380: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   65388: 85 10 00 00 30 3d ff ff      	call -0xc2d0
   65390: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65398: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   653a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   653a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   653b0: 79 13 00 00 00 00 00 00      	ldxdw r3, [r1 + 0x0]
   653b8: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   653c0: 79 15 10 00 00 00 00 00      	ldxdw r5, [r1 + 0x10]
   653c8: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   653d0: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   653d8: 7b 9a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r9
   653e0: 7b 8a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r8
   653e8: 79 a6 58 fb 00 00 00 00      	ldxdw r6, [r10 - 0x4a8]
   653f0: 7b 6a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r6
   653f8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65400: 7b 5a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r5
   65408: 7b 4a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r4
   65410: 7b 3a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r3
   65418: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   65420: 07 03 00 00 00 ff ff ff      	add64 r3, -0x100
   65428: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65430: 85 10 00 00 b8 64 00 00      	call 0x64b8
   65438: 05 00 dd ff 00 00 00 00      	ja -0x23 <.text+0x65208>
   65440: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65448: 85 10 00 00 33 6a 00 00      	call 0x6a33
   65450: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65458: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65460: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   65470: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   65478: 05 00 d4 ff 00 00 00 00      	ja -0x2c <.text+0x65200>
   65480: b7 01 00 00 d1 07 00 00      	mov64 r1, 0x7d1
   65488: 85 10 00 00 2b 6a 00 00      	call 0x6a2b
   65490: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65498: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   654a0: 18 03 00 00 0f db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb0f
   654b0: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   654b8: 85 10 00 00 0a 3d ff ff      	call -0xc2f6
   654c0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   654c8: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   654d0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   654d8: 7b 7a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r7
   654e0: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   654e8: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   654f0: 79 a1 48 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b8]
   654f8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65500: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   65508: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   65510: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65518: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   65520: 79 a1 38 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c8]
   65528: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   65530: 05 00 dc ff 00 00 00 00      	ja -0x24 <.text+0x652f8>
   65538: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   65540: 85 10 00 00 14 6a 00 00      	call 0x6a14
   65548: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65550: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65558: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   65568: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   65570: 85 10 00 00 f3 3c ff ff      	call -0xc30d
   65578: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65580: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   65588: 05 00 c2 ff 00 00 00 00      	ja -0x3e <.text+0x65280>
   65590: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65598: 85 10 00 00 09 6a 00 00      	call 0x6a09
   655a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   655a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   655b0: 18 03 00 00 bd db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbbd
   655c0: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   655c8: 05 00 aa ff 00 00 00 00      	ja -0x56 <.text+0x65200>
   655d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   655d8: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   655e0: 85 10 00 00 1f 45 ff ff      	call -0xbae1
   655e8: b7 01 00 00 e7 07 00 00      	mov64 r1, 0x7e7
   655f0: 85 10 00 00 fe 69 00 00      	call 0x69fe
   655f8: 05 00 a5 ff 00 00 00 00      	ja -0x5b <.text+0x65208>
   65600: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   65608: b7 02 00 00 0a 00 00 00      	mov64 r2, 0xa
   65610: 18 03 00 00 60 13 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1360
   65620: 85 10 00 00 44 7c 00 00      	call 0x7c44
   65628: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   65630: 85 10 00 00 f6 69 00 00      	call 0x69f6
   65638: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65640: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65648: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   65658: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   65660: 85 10 00 00 d5 3c ff ff      	call -0xc32b
   65668: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65670: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65678: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65680: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65688: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65690: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   65698: 79 a1 f8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x208]
   656a0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   656a8: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   656b0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   656b8: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   656c0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   656c8: 79 a1 10 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f0]
   656d0: 05 00 21 00 00 00 00 00      	ja +0x21 <.text+0x656c0>
   656d8: 18 01 00 00 f8 11 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb11f8
   656e8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   656f0: 7a 0a 20 ff 00 00 00 00      	stdw [r10 - 0xe0], 0x0
   656f8: 7a 0a 08 ff 01 00 00 00      	stdw [r10 - 0xf8], 0x1
   65700: 7a 0a 18 ff 00 00 00 00      	stdw [r10 - 0xe8], 0x0
   65708: 7a 0a 10 ff 08 00 00 00      	stdw [r10 - 0xf0], 0x8
   65710: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   65718: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   65720: 18 02 00 00 08 12 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1208
   65730: 85 10 00 00 2a 7e 00 00      	call 0x7e2a
   65738: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   65740: 85 10 00 00 d4 69 00 00      	call 0x69d4
   65748: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65750: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65758: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   65768: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   65770: 85 10 00 00 b3 3c ff ff      	call -0xc34d
   65778: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65780: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65788: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65790: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65798: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   657a0: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   657a8: 79 a1 18 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e8]
   657b0: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   657b8: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   657c0: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   657c8: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   657d0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   657d8: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   657e0: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   657e8: 05 00 85 ff 00 00 00 00      	ja -0x7b <.text+0x652f8>
   657f0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   657f8: 85 10 00 00 bd 69 00 00      	call 0x69bd
   65800: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65808: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65810: 18 03 00 00 02 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade02
   65820: b7 04 00 00 17 00 00 00      	mov64 r4, 0x17
   65828: 05 00 5e ff 00 00 00 00      	ja -0xa2 <.text+0x65200>
   65830: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   65838: 85 10 00 00 b5 69 00 00      	call 0x69b5
   65840: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65848: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65850: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   65860: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   65868: 85 10 00 00 94 3c ff ff      	call -0xc36c
   65870: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65878: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65880: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65888: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65890: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65898: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   658a0: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   658a8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   658b0: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   658b8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   658c0: 79 a1 48 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b8]
   658c8: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   658d0: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   658d8: 05 00 e0 ff 00 00 00 00      	ja -0x20 <.text+0x656c0>
   658e0: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   658e8: 85 10 00 00 9f 69 00 00      	call 0x699f
   658f0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   658f8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65900: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   65910: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   65918: 85 10 00 00 7e 3c ff ff      	call -0xc382
   65920: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65928: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65930: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65938: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65940: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65948: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   65950: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   65958: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   65960: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   65968: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   65970: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   65978: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   65980: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   65988: 05 00 ca ff 00 00 00 00      	ja -0x36 <.text+0x656c0>
   65990: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65998: 85 10 00 00 89 69 00 00      	call 0x6989
   659a0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   659a8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   659b0: 18 03 00 00 19 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade19
   659c0: b7 04 00 00 18 00 00 00      	mov64 r4, 0x18
   659c8: 05 00 2a ff 00 00 00 00      	ja -0xd6 <.text+0x65200>
   659d0: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   659d8: 85 10 00 00 81 69 00 00      	call 0x6981
   659e0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   659e8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   659f0: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   65a00: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   65a08: 85 10 00 00 60 3c ff ff      	call -0xc3a0
   65a10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65a18: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   65a20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   65a28: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   65a30: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   65a38: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   65a40: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   65a48: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   65a50: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   65a58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   65a60: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   65a68: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65a70: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   65a78: 7b 9a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r9
   65a80: 7b 8a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r8
   65a88: 7b 7a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r7
   65a90: 05 00 30 ff 00 00 00 00      	ja -0xd0 <.text+0x652f8>
   65a98: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65aa0: 85 10 00 00 68 69 00 00      	call 0x6968
   65aa8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65ab0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65ab8: 18 03 00 00 63 db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb63
   65ac8: b7 04 00 00 09 00 00 00      	mov64 r4, 0x9
   65ad0: 05 00 09 ff 00 00 00 00      	ja -0xf7 <.text+0x65200>
   65ad8: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   65ae0: 85 10 00 00 60 69 00 00      	call 0x6960
   65ae8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65af0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65af8: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   65b08: b7 04 00 00 0d 00 00 00      	mov64 r4, 0xd
   65b10: 85 10 00 00 3f 3c ff ff      	call -0xc3c1
   65b18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65b20: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   65b28: 05 00 0e ff 00 00 00 00      	ja -0xf2 <.text+0x65280>
   65b30: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65b38: 85 10 00 00 55 69 00 00      	call 0x6955
   65b40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65b48: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65b50: 18 03 00 00 db db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbdb
   65b60: 05 00 21 ff 00 00 00 00      	ja -0xdf <.text+0x65350>
   65b68: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65b70: 85 10 00 00 4e 69 00 00      	call 0x694e
   65b78: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65b80: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65b88: 18 03 00 00 31 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade31
   65b98: b7 04 00 00 1e 00 00 00      	mov64 r4, 0x1e
   65ba0: 05 00 ef fe 00 00 00 00      	ja -0x111 <.text+0x65200>
   65ba8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65bb0: 85 10 00 00 46 69 00 00      	call 0x6946
   65bb8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65bc0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65bc8: 18 03 00 00 37 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc37
   65bd8: 05 00 12 ff 00 00 00 00      	ja -0xee <.text+0x65350>
   65be0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65be8: 85 10 00 00 3f 69 00 00      	call 0x693f
   65bf0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65bf8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65c00: 18 03 00 00 44 dc 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadc44
   65c10: b7 04 00 00 11 00 00 00      	mov64 r4, 0x11
   65c18: 05 00 e0 fe 00 00 00 00      	ja -0x120 <.text+0x65200>
   65c20: b7 01 00 00 df 07 00 00      	mov64 r1, 0x7df
   65c28: 85 10 00 00 37 69 00 00      	call 0x6937
   65c30: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65c38: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65c40: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   65c50: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   65c58: 85 10 00 00 16 3c ff ff      	call -0xc3ea
   65c60: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65c68: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65c70: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65c78: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65c80: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65c88: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   65c90: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   65c98: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   65ca0: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   65ca8: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   65cb0: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   65cb8: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   65cc0: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   65cc8: 05 00 62 ff 00 00 00 00      	ja -0x9e <.text+0x656c0>
   65cd0: b7 01 00 00 d9 07 00 00      	mov64 r1, 0x7d9
   65cd8: 85 10 00 00 21 69 00 00      	call 0x6921
   65ce0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65ce8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65cf0: 18 03 00 00 4f de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade4f
   65d00: b7 04 00 00 1d 00 00 00      	mov64 r4, 0x1d
   65d08: 85 10 00 00 00 3c ff ff      	call -0xc400
   65d10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65d18: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65d20: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65d28: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65d30: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65d38: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   65d40: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   65d48: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   65d50: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   65d58: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   65d60: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   65d68: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   65d70: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   65d78: 05 00 4c ff 00 00 00 00      	ja -0xb4 <.text+0x656c0>
   65d80: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65d88: 05 00 14 fc 00 00 00 00      	ja -0x3ec <.text+0x63d10>
   65d90: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65d98: 85 10 00 00 09 69 00 00      	call 0x6909
   65da0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65da8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65db0: 18 03 00 00 f5 dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddf5
   65dc0: 05 00 d5 fe 00 00 00 00      	ja -0x12b <.text+0x65350>
   65dc8: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65dd0: 85 10 00 00 02 69 00 00      	call 0x6902
   65dd8: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65de0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65de8: 18 03 00 00 6c de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade6c
   65df8: 05 00 78 ff 00 00 00 00      	ja -0x88 <.text+0x658a0>
   65e00: b7 01 00 00 dc 07 00 00      	mov64 r1, 0x7dc
   65e08: 85 10 00 00 fb 68 00 00      	call 0x68fb
   65e10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65e18: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65e20: 18 03 00 00 ee db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadbee
   65e30: b7 04 00 00 0c 00 00 00      	mov64 r4, 0xc
   65e38: 85 10 00 00 da 3b ff ff      	call -0xc426
   65e40: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65e48: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   65e58: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   65e60: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65e68: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   65e70: 7b 9a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r9
   65e78: 7b 8a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r8
   65e80: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   65e88: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   65e98: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   65ea0: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   65eb0: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   65eb8: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   65ec8: 05 00 22 ff 00 00 00 00      	ja -0xde <.text+0x656c0>
   65ed0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65ed8: 85 10 00 00 e1 68 00 00      	call 0x68e1
   65ee0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65ee8: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65ef0: 18 03 00 00 6b dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd6b
   65f00: 05 00 23 ff 00 00 00 00      	ja -0xdd <.text+0x65700>
   65f08: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65f10: 85 10 00 00 da 68 00 00      	call 0x68da
   65f18: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65f20: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65f28: 18 03 00 00 92 de 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xade92
   65f38: b7 04 00 00 22 00 00 00      	mov64 r4, 0x22
   65f40: 05 00 7b fe 00 00 00 00      	ja -0x185 <.text+0x65200>
   65f48: b7 01 00 00 d6 07 00 00      	mov64 r1, 0x7d6
   65f50: 85 10 00 00 d2 68 00 00      	call 0x68d2
   65f58: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65f60: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   65f68: 18 03 00 00 4d db 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadb4d
   65f78: b7 04 00 00 0f 00 00 00      	mov64 r4, 0xf
   65f80: 85 10 00 00 b1 3b ff ff      	call -0xc44f
   65f88: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   65f90: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   65f98: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   65fa0: 79 13 18 00 00 00 00 00      	ldxdw r3, [r1 + 0x18]
   65fa8: 7b 3a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r3
   65fb0: 79 13 10 00 00 00 00 00      	ldxdw r3, [r1 + 0x10]
   65fb8: 7b 3a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r3
   65fc0: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   65fc8: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   65fd0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   65fd8: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   65fe0: 79 a1 50 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3b0]
   65fe8: 05 00 50 ff 00 00 00 00      	ja -0xb0 <.text+0x65950>
   65ff0: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   65ff8: 85 10 00 00 bd 68 00 00      	call 0x68bd
   66000: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   66008: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   66010: 18 03 00 00 9e dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xadd9e
   66020: 05 00 7d ff 00 00 00 00      	ja -0x83 <.text+0x65af0>
   66028: b7 01 00 00 d0 07 00 00      	mov64 r1, 0x7d0
   66030: 85 10 00 00 b6 68 00 00      	call 0x68b6
   66038: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   66040: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   66048: 18 03 00 00 af dd 0a 00 00 00 00 00 00 00 00 00      	lddw r3, 0xaddaf
   66058: b7 04 00 00 15 00 00 00      	mov64 r4, 0x15
   66060: 05 00 57 fe 00 00 00 00      	ja -0x1a9 <.text+0x65200>
   7ff08: bf 37 00 00 00 00 00 00      	mov64 r7, r3
   7ff10: bf 28 00 00 00 00 00 00      	mov64 r8, r2
   7ff18: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   7ff20: 18 01 00 00 bb e0 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae0bb
   7ff30: b7 02 00 00 17 00 00 00      	mov64 r2, 0x17
   7ff38: 85 10 00 00 ff ff ff ff      	call -0x1
   7ff40: 62 0a cc fb ff ff ff ff      	stw [r10 - 0x434], -0x1
   7ff48: 7b 7a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r7
   7ff50: 7b 8a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r8
   7ff58: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   7ff60: 07 01 00 00 cc fb ff ff      	add64 r1, -0x434
   7ff68: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   7ff70: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   7ff78: 07 01 00 00 f0 fd ff ff      	add64 r1, -0x210
   7ff80: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   7ff88: 07 03 00 00 d0 fb ff ff      	add64 r3, -0x430
   7ff90: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   7ff98: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   7ffa0: 85 10 00 00 d9 70 ff ff      	call -0x8f27
   7ffa8: 61 a7 f0 fd 00 00 00 00      	ldxw r7, [r10 - 0x210]
   7ffb0: 55 07 03 00 02 00 00 00      	jne r7, 0x2, +0x3 <.text+0x7feb0>
   7ffb8: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   7ffc0: 79 a0 f8 fd 00 00 00 00      	ldxdw r0, [r10 - 0x208]
   7ffc8: 05 00 21 00 00 00 00 00      	ja +0x21 <.text+0x7ffb8>
   7ffd0: 61 a1 f4 fd 00 00 00 00      	ldxw r1, [r10 - 0x20c]
   7ffd8: 7b 1a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r1
   7ffe0: 79 a9 f8 fd 00 00 00 00      	ldxdw r9, [r10 - 0x208]
   7ffe8: 79 a8 00 fe 00 00 00 00      	ldxdw r8, [r10 - 0x200]
   7fff0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   7fff8: 07 01 00 00 f8 fb ff ff      	add64 r1, -0x408
   80000: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   80008: 07 02 00 00 08 fe ff ff      	add64 r2, -0x1f8
   80010: b7 03 00 00 f8 01 00 00      	mov64 r3, 0x1f8
   80018: 85 10 00 00 ad 54 00 00      	call 0x54ad
   80020: 7b 8a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r8
   80028: 7b 9a e8 fb 00 00 00 00      	stxdw [r10 - 0x418], r9
   80030: 79 a1 c0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x440]
   80038: 63 1a e4 fb 00 00 00 00      	stxw [r10 - 0x41c], r1
   80040: 63 7a e0 fb 00 00 00 00      	stxw [r10 - 0x420], r7
   80048: 61 a1 cc fb 00 00 00 00      	ldxw r1, [r10 - 0x434]
   80050: 63 1a 10 fe 00 00 00 00      	stxw [r10 - 0x1f0], r1
   80058: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   80060: 7b 1a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r1
   80068: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   80070: 7b 1a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r1
   80078: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   80080: 07 01 00 00 e0 fb ff ff      	add64 r1, -0x420
   80088: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   80090: 7b 6a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r6
   80098: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   800a0: 07 01 00 00 f0 fd ff ff      	add64 r1, -0x210
   800a8: 85 10 00 00 fd 1a ff ff      	call -0xe503
   800b0: 55 00 04 00 02 00 00 00      	jne r0, 0x2, +0x4 <.text+0x7ffb8>
   800b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   800c0: 07 01 00 00 e0 fb ff ff      	add64 r1, -0x420
   800c8: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   800d0: 85 10 00 00 dc 75 ff ff      	call -0x8a24
   800d8: 95 00 00 00 00 00 00 00      	exit
   810b8: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   810c0: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   810c8: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   810d0: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   810d8: 7b 1a 78 fe 00 00 00 00      	stxdw [r10 - 0x188], r1
   810e0: 18 01 00 00 2d e1 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae12d
   810f0: b7 02 00 00 11 00 00 00      	mov64 r2, 0x11
   810f8: 85 10 00 00 ff ff ff ff      	call -0x1
   81100: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x81008>
   81108: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81110: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   81118: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x81008>
   81120: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x810b0>
   81128: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   81138: 85 10 00 00 fe 42 00 00      	call 0x42fe
   81140: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   81148: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   81150: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   81158: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   81160: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x81078>
   81168: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x81078>
   81170: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   81178: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   81180: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x81078>
   81188: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   81190: 8d 00 00 00 02 00 00 00      	callx r2
   81198: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   811a0: 85 10 00 00 88 32 00 00      	call 0x3288
   811a8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   811b0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   811b8: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   811c0: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   811c8: 95 00 00 00 00 00 00 00      	exit
   811d0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   811d8: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   811e0: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   811e8: 7b 1a 58 fe 00 00 00 00      	stxdw [r10 - 0x1a8], r1
   811f0: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   811f8: 7b 1a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r1
   81200: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   81208: 7b 1a 60 fe 00 00 00 00      	stxdw [r10 - 0x1a0], r1
   81210: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   81218: 6b 1a 84 fe 00 00 00 00      	stxh [r10 - 0x17c], r1
   81220: 63 1a 80 fe 00 00 00 00      	stxw [r10 - 0x180], r1
   81228: 7b 6a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r6
   81230: 7b 7a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r7
   81238: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81240: 07 01 00 00 88 fe ff ff      	add64 r1, -0x178
   81248: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   81250: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81258: 07 01 00 00 80 fe ff ff      	add64 r1, -0x180
   81260: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   81268: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   81270: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81278: 07 01 00 00 58 ff ff ff      	add64 r1, -0xa8
   81280: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   81288: 07 03 00 00 a0 fe ff ff      	add64 r3, -0x160
   81290: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   81298: 79 a7 78 fe 00 00 00 00      	ldxdw r7, [r10 - 0x188]
   812a0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   812a8: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   812b0: 85 10 00 00 8a ab ff ff      	call -0x5476
   812b8: 79 a9 68 ff 00 00 00 00      	ldxdw r9, [r10 - 0x98]
   812c0: 79 a8 60 ff 00 00 00 00      	ldxdw r8, [r10 - 0xa0]
   812c8: 79 a6 58 ff 00 00 00 00      	ldxdw r6, [r10 - 0xa8]
   812d0: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x81098>
   812d8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   812e0: 07 01 00 00 c8 fe ff ff      	add64 r1, -0x138
   812e8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   812f0: 07 02 00 00 70 ff ff ff      	add64 r2, -0x90
   812f8: b7 03 00 00 90 00 00 00      	mov64 r3, 0x90
   81300: 85 10 00 00 50 52 00 00      	call 0x5250
   81308: 7b 9a c0 fe 00 00 00 00      	stxdw [r10 - 0x140], r9
   81310: 7b 8a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r8
   81318: 7b 6a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r6
   81320: 61 a1 80 fe 00 00 00 00      	ldxw r1, [r10 - 0x180]
   81328: 63 1a 78 ff 00 00 00 00      	stxw [r10 - 0x88], r1
   81330: 69 a1 84 fe 00 00 00 00      	ldxh r1, [r10 - 0x17c]
   81338: 6b 1a 7c ff 00 00 00 00      	stxh [r10 - 0x84], r1
   81340: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   81348: 7b 1a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r1
   81350: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   81358: 7b 1a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r1
   81360: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81368: 07 01 00 00 b0 fe ff ff      	add64 r1, -0x150
   81370: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   81378: 7b 7a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r7
   81380: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81388: 07 01 00 00 58 ff ff ff      	add64 r1, -0xa8
   81390: 79 a2 58 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1a8]
   81398: 79 a3 70 fe 00 00 00 00      	ldxdw r3, [r10 - 0x190]
   813a0: 79 a4 68 fe 00 00 00 00      	ldxdw r4, [r10 - 0x198]
   813a8: 79 a5 60 fe 00 00 00 00      	ldxdw r5, [r10 - 0x1a0]
   813b0: 85 10 00 00 cd 3b ff ff      	call -0xc433
   813b8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   813c0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   813c8: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x81098>
   813d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   813d8: 07 01 00 00 b0 fe ff ff      	add64 r1, -0x150
   813e0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   813e8: 85 10 00 00 94 b2 ff ff      	call -0x4d6c
   813f0: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x81088>
   813f8: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   81400: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   81408: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   81410: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   81418: 7b 1a 58 fe 00 00 00 00      	stxdw [r10 - 0x1a8], r1
   81420: 18 01 00 00 a8 d7 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xad7a8
   81430: b7 02 00 00 10 00 00 00      	mov64 r2, 0x10
   81438: 85 10 00 00 ff ff ff ff      	call -0x1
   81440: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x81348>
   81448: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81450: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   81458: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x81348>
   81460: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x813f0>
   81468: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   81478: 85 10 00 00 96 42 00 00      	call 0x4296
   81480: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   81488: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   81490: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   81498: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   814a0: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x813b8>
   814a8: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x813b8>
   814b0: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   814b8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   814c0: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x813b8>
   814c8: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   814d0: 8d 00 00 00 02 00 00 00      	callx r2
   814d8: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   814e0: 85 10 00 00 20 32 00 00      	call 0x3220
   814e8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   814f0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   814f8: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   81500: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81508: 95 00 00 00 00 00 00 00      	exit
   81510: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   81518: 7b 1a 50 fe 00 00 00 00      	stxdw [r10 - 0x1b0], r1
   81520: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   81528: 7b 1a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r1
   81530: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   81538: 7b 1a 48 fe 00 00 00 00      	stxdw [r10 - 0x1b8], r1
   81540: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   81548: 7b 1a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r1
   81550: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   81558: 6b 1a 64 fe 00 00 00 00      	stxh [r10 - 0x19c], r1
   81560: 63 1a 60 fe 00 00 00 00      	stxw [r10 - 0x1a0], r1
   81568: 7b 6a 88 fe 00 00 00 00      	stxdw [r10 - 0x178], r6
   81570: 7b 7a 80 fe 00 00 00 00      	stxdw [r10 - 0x180], r7
   81578: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81580: 07 01 00 00 68 fe ff ff      	add64 r1, -0x198
   81588: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   81590: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81598: 07 01 00 00 60 fe ff ff      	add64 r1, -0x1a0
   815a0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   815a8: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   815b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   815b8: 07 01 00 00 48 ff ff ff      	add64 r1, -0xb8
   815c0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   815c8: 07 03 00 00 80 fe ff ff      	add64 r3, -0x180
   815d0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   815d8: 79 a7 58 fe 00 00 00 00      	ldxdw r7, [r10 - 0x1a8]
   815e0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   815e8: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   815f0: 85 10 00 00 00 a2 ff ff      	call -0x5e00
   815f8: 79 a9 58 ff 00 00 00 00      	ldxdw r9, [r10 - 0xa8]
   81600: 79 a8 50 ff 00 00 00 00      	ldxdw r8, [r10 - 0xb0]
   81608: 79 a6 48 ff 00 00 00 00      	ldxdw r6, [r10 - 0xb8]
   81610: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x813d8>
   81618: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81620: 07 01 00 00 a8 fe ff ff      	add64 r1, -0x158
   81628: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   81630: 07 02 00 00 60 ff ff ff      	add64 r2, -0xa0
   81638: b7 03 00 00 a0 00 00 00      	mov64 r3, 0xa0
   81640: 85 10 00 00 e8 51 00 00      	call 0x51e8
   81648: 7b 9a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r9
   81650: 7b 8a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r8
   81658: 7b 6a 90 fe 00 00 00 00      	stxdw [r10 - 0x170], r6
   81660: 61 a1 60 fe 00 00 00 00      	ldxw r1, [r10 - 0x1a0]
   81668: 63 1a 68 ff 00 00 00 00      	stxw [r10 - 0x98], r1
   81670: 69 a1 64 fe 00 00 00 00      	ldxh r1, [r10 - 0x19c]
   81678: 6b 1a 6c ff 00 00 00 00      	stxh [r10 - 0x94], r1
   81680: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
   81688: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   81690: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
   81698: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   816a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   816a8: 07 01 00 00 90 fe ff ff      	add64 r1, -0x170
   816b0: 7b 1a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r1
   816b8: 7b 7a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r7
   816c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   816c8: 07 01 00 00 48 ff ff ff      	add64 r1, -0xb8
   816d0: 79 a2 38 fe 00 00 00 00      	ldxdw r2, [r10 - 0x1c8]
   816d8: 79 a3 50 fe 00 00 00 00      	ldxdw r3, [r10 - 0x1b0]
   816e0: 79 a4 48 fe 00 00 00 00      	ldxdw r4, [r10 - 0x1b8]
   816e8: 79 a5 40 fe 00 00 00 00      	ldxdw r5, [r10 - 0x1c0]
   816f0: 85 10 00 00 a2 34 ff ff      	call -0xcb5e
   816f8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81700: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81708: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x813d8>
   81710: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81718: 07 01 00 00 90 fe ff ff      	add64 r1, -0x170
   81720: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81728: 85 10 00 00 2d a9 ff ff      	call -0x56d3
   81730: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x813c8>
   81738: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   81740: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   81748: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   81750: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   81758: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   81760: 18 01 00 00 3e e1 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae13e
   81770: b7 02 00 00 13 00 00 00      	mov64 r2, 0x13
   81778: 85 10 00 00 ff ff ff ff      	call -0x1
   81780: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x81688>
   81788: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81790: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   81798: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x81688>
   817a0: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x81730>
   817a8: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   817b8: 85 10 00 00 2e 42 00 00      	call 0x422e
   817c0: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   817c8: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   817d0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   817d8: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   817e0: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x816f8>
   817e8: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x816f8>
   817f0: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   817f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   81800: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x816f8>
   81808: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   81810: 8d 00 00 00 02 00 00 00      	callx r2
   81818: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   81820: 85 10 00 00 b8 31 00 00      	call 0x31b8
   81828: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81830: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81838: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   81840: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81848: 95 00 00 00 00 00 00 00      	exit
   81850: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   81858: 7b 1a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r1
   81860: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   81868: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   81870: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   81878: 7b 1a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r1
   81880: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   81888: 7b 1a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r1
   81890: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   81898: 73 1a e4 fd 00 00 00 00      	stxb [r10 - 0x21c], r1
   818a0: 63 1a e0 fd 00 00 00 00      	stxw [r10 - 0x220], r1
   818a8: 7b 6a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r6
   818b0: 7b 7a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r7
   818b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   818c0: 07 01 00 00 e8 fd ff ff      	add64 r1, -0x218
   818c8: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   818d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   818d8: 07 01 00 00 e0 fd ff ff      	add64 r1, -0x220
   818e0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   818e8: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   818f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   818f8: 07 01 00 00 08 ff ff ff      	add64 r1, -0xf8
   81900: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   81908: 07 03 00 00 00 fe ff ff      	add64 r3, -0x200
   81910: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   81918: 79 a7 d8 fd 00 00 00 00      	ldxdw r7, [r10 - 0x228]
   81920: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81928: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   81930: 85 10 00 00 41 c0 ff ff      	call -0x3fbf
   81938: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   81940: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   81948: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   81950: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x81718>
   81958: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81960: 07 01 00 00 28 fe ff ff      	add64 r1, -0x1d8
   81968: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   81970: 07 02 00 00 20 ff ff ff      	add64 r2, -0xe0
   81978: b7 03 00 00 e0 00 00 00      	mov64 r3, 0xe0
   81980: 85 10 00 00 80 51 00 00      	call 0x5180
   81988: 7b 9a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r9
   81990: 7b 8a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r8
   81998: 7b 6a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r6
   819a0: 61 a1 e0 fd 00 00 00 00      	ldxw r1, [r10 - 0x220]
   819a8: 63 1a 28 ff 00 00 00 00      	stxw [r10 - 0xd8], r1
   819b0: 71 a1 e4 fd 00 00 00 00      	ldxb r1, [r10 - 0x21c]
   819b8: 73 1a 2c ff 00 00 00 00      	stxb [r10 - 0xd4], r1
   819c0: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   819c8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   819d0: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   819d8: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   819e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   819e8: 07 01 00 00 10 fe ff ff      	add64 r1, -0x1f0
   819f0: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   819f8: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   81a00: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81a08: 07 01 00 00 08 ff ff ff      	add64 r1, -0xf8
   81a10: 79 a2 b8 fd 00 00 00 00      	ldxdw r2, [r10 - 0x248]
   81a18: 79 a3 d0 fd 00 00 00 00      	ldxdw r3, [r10 - 0x230]
   81a20: 79 a4 c8 fd 00 00 00 00      	ldxdw r4, [r10 - 0x238]
   81a28: 79 a5 c0 fd 00 00 00 00      	ldxdw r5, [r10 - 0x240]
   81a30: 85 10 00 00 70 4a ff ff      	call -0xb590
   81a38: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81a40: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81a48: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x81718>
   81a50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81a58: 07 01 00 00 10 fe ff ff      	add64 r1, -0x1f0
   81a60: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81a68: 85 10 00 00 bf c8 ff ff      	call -0x3741
   81a70: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x81708>
   81a78: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   81a80: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   81a88: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   81a90: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   81a98: 7b 1a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r1
   81aa0: 18 01 00 00 51 e1 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae151
   81ab0: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   81ab8: 85 10 00 00 ff ff ff ff      	call -0x1
   81ac0: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x819c8>
   81ac8: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81ad0: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   81ad8: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x819c8>
   81ae0: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x81a70>
   81ae8: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   81af8: 85 10 00 00 c6 41 00 00      	call 0x41c6
   81b00: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   81b08: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   81b10: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   81b18: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   81b20: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x81a38>
   81b28: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x81a38>
   81b30: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   81b38: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   81b40: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x81a38>
   81b48: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   81b50: 8d 00 00 00 02 00 00 00      	callx r2
   81b58: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   81b60: 85 10 00 00 50 31 00 00      	call 0x3150
   81b68: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81b70: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81b78: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   81b80: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81b88: 95 00 00 00 00 00 00 00      	exit
   81b90: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   81b98: 7b 1a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r1
   81ba0: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   81ba8: 7b 1a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r1
   81bb0: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   81bb8: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   81bc0: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   81bc8: 7b 1a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r1
   81bd0: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   81bd8: 73 1a d4 fd 00 00 00 00      	stxb [r10 - 0x22c], r1
   81be0: 63 1a d0 fd 00 00 00 00      	stxw [r10 - 0x230], r1
   81be8: 7b 6a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r6
   81bf0: 7b 7a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r7
   81bf8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81c00: 07 01 00 00 d8 fd ff ff      	add64 r1, -0x228
   81c08: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   81c10: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81c18: 07 01 00 00 d0 fd ff ff      	add64 r1, -0x230
   81c20: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   81c28: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   81c30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81c38: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   81c40: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   81c48: 07 03 00 00 f0 fd ff ff      	add64 r3, -0x210
   81c50: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   81c58: 79 a7 c8 fd 00 00 00 00      	ldxdw r7, [r10 - 0x238]
   81c60: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81c68: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   81c70: 85 10 00 00 4c b5 ff ff      	call -0x4ab4
   81c78: 79 a9 10 ff 00 00 00 00      	ldxdw r9, [r10 - 0xf0]
   81c80: 79 a8 08 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf8]
   81c88: 79 a6 00 ff 00 00 00 00      	ldxdw r6, [r10 - 0x100]
   81c90: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x81a58>
   81c98: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81ca0: 07 01 00 00 18 fe ff ff      	add64 r1, -0x1e8
   81ca8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   81cb0: 07 02 00 00 18 ff ff ff      	add64 r2, -0xe8
   81cb8: b7 03 00 00 e8 00 00 00      	mov64 r3, 0xe8
   81cc0: 85 10 00 00 18 51 00 00      	call 0x5118
   81cc8: 7b 9a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r9
   81cd0: 7b 8a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r8
   81cd8: 7b 6a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r6
   81ce0: 61 a1 d0 fd 00 00 00 00      	ldxw r1, [r10 - 0x230]
   81ce8: 63 1a 20 ff 00 00 00 00      	stxw [r10 - 0xe0], r1
   81cf0: 71 a1 d4 fd 00 00 00 00      	ldxb r1, [r10 - 0x22c]
   81cf8: 73 1a 24 ff 00 00 00 00      	stxb [r10 - 0xdc], r1
   81d00: 79 a1 f8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x208]
   81d08: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   81d10: 79 a1 f0 fd 00 00 00 00      	ldxdw r1, [r10 - 0x210]
   81d18: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   81d20: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81d28: 07 01 00 00 00 fe ff ff      	add64 r1, -0x200
   81d30: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   81d38: 7b 7a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r7
   81d40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81d48: 07 01 00 00 00 ff ff ff      	add64 r1, -0x100
   81d50: 79 a2 a8 fd 00 00 00 00      	ldxdw r2, [r10 - 0x258]
   81d58: 79 a3 c0 fd 00 00 00 00      	ldxdw r3, [r10 - 0x240]
   81d60: 79 a4 b8 fd 00 00 00 00      	ldxdw r4, [r10 - 0x248]
   81d68: 79 a5 b0 fd 00 00 00 00      	ldxdw r5, [r10 - 0x250]
   81d70: 85 10 00 00 ed 40 ff ff      	call -0xbf13
   81d78: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81d80: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81d88: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x81a58>
   81d90: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81d98: 07 01 00 00 00 fe ff ff      	add64 r1, -0x200
   81da0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81da8: 85 10 00 00 c5 bd ff ff      	call -0x423b
   81db0: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x81a48>
   81db8: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   81dc0: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   81dc8: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   81dd0: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   81dd8: 7b 1a f8 fd 00 00 00 00      	stxdw [r10 - 0x208], r1
   81de0: 18 01 00 00 63 e1 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae163
   81df0: b7 02 00 00 19 00 00 00      	mov64 r2, 0x19
   81df8: 85 10 00 00 ff ff ff ff      	call -0x1
   81e00: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x81d08>
   81e08: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81e10: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   81e18: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x81d08>
   81e20: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x81db0>
   81e28: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   81e38: 85 10 00 00 5e 41 00 00      	call 0x415e
   81e40: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   81e48: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   81e50: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   81e58: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   81e60: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x81d78>
   81e68: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x81d78>
   81e70: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   81e78: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   81e80: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x81d78>
   81e88: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   81e90: 8d 00 00 00 02 00 00 00      	callx r2
   81e98: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   81ea0: 85 10 00 00 e8 30 00 00      	call 0x30e8
   81ea8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   81eb0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   81eb8: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   81ec0: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   81ec8: 95 00 00 00 00 00 00 00      	exit
   81ed0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   81ed8: 7b 1a f0 fd 00 00 00 00      	stxdw [r10 - 0x210], r1
   81ee0: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   81ee8: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   81ef0: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   81ef8: 7b 1a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r1
   81f00: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   81f08: 7b 1a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r1
   81f10: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   81f18: 73 1a 04 fe 00 00 00 00      	stxb [r10 - 0x1fc], r1
   81f20: 63 1a 00 fe 00 00 00 00      	stxw [r10 - 0x200], r1
   81f28: 7b 6a 28 fe 00 00 00 00      	stxdw [r10 - 0x1d8], r6
   81f30: 7b 7a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r7
   81f38: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81f40: 07 01 00 00 08 fe ff ff      	add64 r1, -0x1f8
   81f48: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   81f50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81f58: 07 01 00 00 00 fe ff ff      	add64 r1, -0x200
   81f60: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   81f68: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   81f70: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81f78: 07 01 00 00 18 ff ff ff      	add64 r1, -0xe8
   81f80: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   81f88: 07 03 00 00 20 fe ff ff      	add64 r3, -0x1e0
   81f90: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   81f98: 79 a7 f8 fd 00 00 00 00      	ldxdw r7, [r10 - 0x208]
   81fa0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   81fa8: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   81fb0: 85 10 00 00 9c 95 ff ff      	call -0x6a64
   81fb8: 79 a9 28 ff 00 00 00 00      	ldxdw r9, [r10 - 0xd8]
   81fc0: 79 a8 20 ff 00 00 00 00      	ldxdw r8, [r10 - 0xe0]
   81fc8: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   81fd0: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x81d98>
   81fd8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   81fe0: 07 01 00 00 48 fe ff ff      	add64 r1, -0x1b8
   81fe8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   81ff0: 07 02 00 00 30 ff ff ff      	add64 r2, -0xd0
   81ff8: b7 03 00 00 d0 00 00 00      	mov64 r3, 0xd0
   82000: 85 10 00 00 b0 50 00 00      	call 0x50b0
   82008: 7b 9a 40 fe 00 00 00 00      	stxdw [r10 - 0x1c0], r9
   82010: 7b 8a 38 fe 00 00 00 00      	stxdw [r10 - 0x1c8], r8
   82018: 7b 6a 30 fe 00 00 00 00      	stxdw [r10 - 0x1d0], r6
   82020: 61 a1 00 fe 00 00 00 00      	ldxw r1, [r10 - 0x200]
   82028: 63 1a 38 ff 00 00 00 00      	stxw [r10 - 0xc8], r1
   82030: 71 a1 04 fe 00 00 00 00      	ldxb r1, [r10 - 0x1fc]
   82038: 73 1a 3c ff 00 00 00 00      	stxb [r10 - 0xc4], r1
   82040: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   82048: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   82050: 79 a1 20 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1e0]
   82058: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   82060: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82068: 07 01 00 00 30 fe ff ff      	add64 r1, -0x1d0
   82070: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   82078: 7b 7a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r7
   82080: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82088: 07 01 00 00 18 ff ff ff      	add64 r1, -0xe8
   82090: 79 a2 d8 fd 00 00 00 00      	ldxdw r2, [r10 - 0x228]
   82098: 79 a3 f0 fd 00 00 00 00      	ldxdw r3, [r10 - 0x210]
   820a0: 79 a4 e8 fd 00 00 00 00      	ldxdw r4, [r10 - 0x218]
   820a8: 79 a5 e0 fd 00 00 00 00      	ldxdw r5, [r10 - 0x220]
   820b0: 85 10 00 00 b6 2a ff ff      	call -0xd54a
   820b8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   820c0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   820c8: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x81d98>
   820d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   820d8: 07 01 00 00 30 fe ff ff      	add64 r1, -0x1d0
   820e0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   820e8: 85 10 00 00 91 9e ff ff      	call -0x616f
   820f0: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x81d88>
   820f8: bf 59 00 00 00 00 00 00      	mov64 r9, r5
   82100: bf 48 00 00 00 00 00 00      	mov64 r8, r4
   82108: bf 36 00 00 00 00 00 00      	mov64 r6, r3
   82110: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   82118: 7b 1a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r1
   82120: 18 01 00 00 7c e1 0a 00 00 00 00 00 00 00 00 00      	lddw r1, 0xae17c
   82130: b7 02 00 00 18 00 00 00      	mov64 r2, 0x18
   82138: 85 10 00 00 ff ff ff ff      	call -0x1
   82140: a5 09 04 00 10 00 00 00      	jlt r9, 0x10, +0x4 <.text+0x82048>
   82148: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   82150: 57 01 00 00 fe ff ff ff      	and64 r1, -0x2
   82158: 15 01 01 00 10 00 00 00      	jeq r1, 0x10, +0x1 <.text+0x82048>
   82160: 55 01 15 00 12 00 00 00      	jne r1, 0x12, +0x15 <.text+0x820f0>
   82168: 18 01 00 00 20 12 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1220
   82178: 85 10 00 00 f6 40 00 00      	call 0x40f6
   82180: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   82188: 57 01 00 00 03 00 00 00      	and64 r1, 0x3
   82190: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   82198: 07 02 00 00 fe ff ff ff      	add64 r2, -0x2
   821a0: a5 02 06 00 02 00 00 00      	jlt r2, 0x2, +0x6 <.text+0x820b8>
   821a8: 15 01 05 00 00 00 00 00      	jeq r1, 0x0, +0x5 <.text+0x820b8>
   821b0: 79 01 07 00 00 00 00 00      	ldxdw r1, [r0 + 0x7]
   821b8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   821c0: 15 02 02 00 00 00 00 00      	jeq r2, 0x0, +0x2 <.text+0x820b8>
   821c8: 79 01 ff ff 00 00 00 00      	ldxdw r1, [r0 - 0x1]
   821d0: 8d 00 00 00 02 00 00 00      	callx r2
   821d8: b7 01 00 00 66 00 00 00      	mov64 r1, 0x66
   821e0: 85 10 00 00 80 30 00 00      	call 0x3080
   821e8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   821f0: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   821f8: bf 80 00 00 00 00 00 00      	mov64 r0, r8
   82200: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   82208: 95 00 00 00 00 00 00 00      	exit
   82210: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   82218: 7b 1a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r1
   82220: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   82228: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   82230: 69 81 10 00 00 00 00 00      	ldxh r1, [r8 + 0x10]
   82238: 7b 1a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r1
   82240: 69 81 12 00 00 00 00 00      	ldxh r1, [r8 + 0x12]
   82248: 7b 1a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r1
   82250: b7 01 00 00 ff ff ff ff      	mov64 r1, -0x1
   82258: 73 1a e4 fd 00 00 00 00      	stxb [r10 - 0x21c], r1
   82260: 63 1a e0 fd 00 00 00 00      	stxw [r10 - 0x220], r1
   82268: 7b 6a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r6
   82270: 7b 7a 00 fe 00 00 00 00      	stxdw [r10 - 0x200], r7
   82278: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82280: 07 01 00 00 e8 fd ff ff      	add64 r1, -0x218
   82288: 7b 1a 10 f0 00 00 00 00      	stxdw [r10 - 0xff0], r1
   82290: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82298: 07 01 00 00 e0 fd ff ff      	add64 r1, -0x220
   822a0: 7b 1a 08 f0 00 00 00 00      	stxdw [r10 - 0xff8], r1
   822a8: 7b 9a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r9
   822b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   822b8: 07 01 00 00 08 ff ff ff      	add64 r1, -0xf8
   822c0: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   822c8: 07 03 00 00 00 fe ff ff      	add64 r3, -0x200
   822d0: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   822d8: 79 a7 d8 fd 00 00 00 00      	ldxdw r7, [r10 - 0x228]
   822e0: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   822e8: bf 84 00 00 00 00 00 00      	mov64 r4, r8
   822f0: 85 10 00 00 10 88 ff ff      	call -0x77f0
   822f8: 79 a9 18 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe8]
   82300: 79 a8 10 ff 00 00 00 00      	ldxdw r8, [r10 - 0xf0]
   82308: 79 a6 08 ff 00 00 00 00      	ldxdw r6, [r10 - 0xf8]
   82310: 15 06 dc ff 00 00 00 00      	jeq r6, 0x0, -0x24 <.text+0x820d8>
   82318: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82320: 07 01 00 00 28 fe ff ff      	add64 r1, -0x1d8
   82328: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   82330: 07 02 00 00 20 ff ff ff      	add64 r2, -0xe0
   82338: b7 03 00 00 e0 00 00 00      	mov64 r3, 0xe0
   82340: 85 10 00 00 48 50 00 00      	call 0x5048
   82348: 7b 9a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r9
   82350: 7b 8a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r8
   82358: 7b 6a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r6
   82360: 61 a1 e0 fd 00 00 00 00      	ldxw r1, [r10 - 0x220]
   82368: 63 1a 28 ff 00 00 00 00      	stxw [r10 - 0xd8], r1
   82370: 71 a1 e4 fd 00 00 00 00      	ldxb r1, [r10 - 0x21c]
   82378: 73 1a 2c ff 00 00 00 00      	stxb [r10 - 0xd4], r1
   82380: 79 a1 08 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1f8]
   82388: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   82390: 79 a1 00 fe 00 00 00 00      	ldxdw r1, [r10 - 0x200]
   82398: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   823a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   823a8: 07 01 00 00 10 fe ff ff      	add64 r1, -0x1f0
   823b0: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   823b8: 7b 7a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r7
   823c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   823c8: 07 01 00 00 08 ff ff ff      	add64 r1, -0xf8
   823d0: 79 a2 b8 fd 00 00 00 00      	ldxdw r2, [r10 - 0x248]
   823d8: 79 a3 d0 fd 00 00 00 00      	ldxdw r3, [r10 - 0x230]
   823e0: 79 a4 c8 fd 00 00 00 00      	ldxdw r4, [r10 - 0x238]
   823e8: 79 a5 c0 fd 00 00 00 00      	ldxdw r5, [r10 - 0x240]
   823f0: 85 10 00 00 4d 25 ff ff      	call -0xdab3
   823f8: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   82400: bf 19 00 00 00 00 00 00      	mov64 r9, r1
   82408: 55 08 bd ff 02 00 00 00      	jne r8, 0x2, -0x43 <.text+0x820d8>
   82410: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   82418: 07 01 00 00 10 fe ff ff      	add64 r1, -0x1f0
   82420: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   82428: 85 10 00 00 fd 92 ff ff      	call -0x6d03
   82430: 05 00 b6 ff 00 00 00 00      	ja -0x4a <.text+0x820c8>
   90bc0: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   90bc8: 79 74 18 00 00 00 00 00      	ldxdw r4, [r7 + 0x18]
   90bd0: 79 73 48 00 00 00 00 00      	ldxdw r3, [r7 + 0x48]
   90bd8: 79 71 78 00 00 00 00 00      	ldxdw r1, [r7 + 0x78]
   90be0: 7b 2a 18 f0 00 00 00 00      	stxdw [r10 - 0xfe8], r2
   90be8: 7b 1a 00 f0 00 00 00 00      	stxdw [r10 - 0x1000], r1
   90bf0: 7a 0a 10 f0 00 00 00 00      	stdw [r10 - 0xff0], 0x0
   90bf8: 7a 0a 08 f0 08 00 00 00      	stdw [r10 - 0xff8], 0x8
   90c00: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   90c08: 07 02 00 00 b8 00 00 00      	add64 r2, 0xb8
   90c10: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   90c18: 07 01 00 00 70 ff ff ff      	add64 r1, -0x90
   90c20: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   90c28: 85 10 00 00 1c 05 00 00      	call 0x51c
   90c30: 61 a3 7c ff 00 00 00 00      	ldxw r3, [r10 - 0x84]
   90c38: 61 a8 78 ff 00 00 00 00      	ldxw r8, [r10 - 0x88]
   90c40: 79 a9 70 ff 00 00 00 00      	ldxdw r9, [r10 - 0x90]
   90c48: 18 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80      	lddw r1, -0x8000000000000000
   90c58: 7b 7a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r7
   90c60: 5d 19 4e 00 00 00 00 00      	jne r9, r1, +0x4e <custom_panic+0xd9b8>
   90c68: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   90c70: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   90c78: 85 10 00 00 96 0d 00 00      	call 0xd96
   90c80: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   90c88: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   90c90: 79 71 20 00 00 00 00 00      	ldxdw r1, [r7 + 0x20]
   90c98: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90ca0: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90ca8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90cb0: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd7b0>
   90cb8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90cc0: 07 01 00 00 20 00 00 00      	add64 r1, 0x20
   90cc8: 85 10 00 00 db 1e 00 00      	call 0x1edb
   90cd0: 79 71 28 00 00 00 00 00      	ldxdw r1, [r7 + 0x28]
   90cd8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90ce0: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90ce8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90cf0: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd7f0>
   90cf8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90d00: 07 01 00 00 28 00 00 00      	add64 r1, 0x28
   90d08: 85 10 00 00 c9 1e 00 00      	call 0x1ec9
   90d10: 79 71 50 00 00 00 00 00      	ldxdw r1, [r7 + 0x50]
   90d18: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90d20: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90d28: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90d30: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd830>
   90d38: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90d40: 07 01 00 00 50 00 00 00      	add64 r1, 0x50
   90d48: 85 10 00 00 cb 1e 00 00      	call 0x1ecb
   90d50: 79 71 58 00 00 00 00 00      	ldxdw r1, [r7 + 0x58]
   90d58: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90d60: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90d68: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90d70: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd870>
   90d78: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90d80: 07 01 00 00 58 00 00 00      	add64 r1, 0x58
   90d88: 85 10 00 00 b9 1e 00 00      	call 0x1eb9
   90d90: 79 71 80 00 00 00 00 00      	ldxdw r1, [r7 + 0x80]
   90d98: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90da0: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90da8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90db0: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd8b0>
   90db8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90dc0: 07 01 00 00 80 00 00 00      	add64 r1, 0x80
   90dc8: 85 10 00 00 bb 1e 00 00      	call 0x1ebb
   90dd0: 79 71 88 00 00 00 00 00      	ldxdw r1, [r7 + 0x88]
   90dd8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90de0: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90de8: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90df0: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd8f0>
   90df8: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   90e00: 07 01 00 00 88 00 00 00      	add64 r1, 0x88
   90e08: 85 10 00 00 a9 1e 00 00      	call 0x1ea9
   90e10: 79 78 08 00 00 00 00 00      	ldxdw r8, [r7 + 0x8]
   90e18: 79 77 10 00 00 00 00 00      	ldxdw r7, [r7 + 0x10]
   90e20: 15 07 47 00 00 00 00 00      	jeq r7, 0x0, +0x47 <custom_panic+0xdb40>
   90e28: bf 89 00 00 00 00 00 00      	mov64 r9, r8
   90e30: 07 09 00 00 10 00 00 00      	add64 r9, 0x10
   90e38: 05 00 03 00 00 00 00 00      	ja +0x3 <custom_panic+0xd938>
   90e40: 07 09 00 00 30 00 00 00      	add64 r9, 0x30
   90e48: 07 07 00 00 ff ff ff ff      	add64 r7, -0x1
   90e50: 15 07 41 00 00 00 00 00      	jeq r7, 0x0, +0x41 <custom_panic+0xdb40>
   90e58: 79 91 f8 ff 00 00 00 00      	ldxdw r1, [r9 - 0x8]
   90e60: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90e68: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90e70: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90e78: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xd978>
   90e80: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   90e88: 07 01 00 00 f8 ff ff ff      	add64 r1, -0x8
   90e90: 85 10 00 00 a2 1e 00 00      	call 0x1ea2
   90e98: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   90ea0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   90ea8: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   90eb0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   90eb8: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <custom_panic+0xd920>
   90ec0: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   90ec8: 85 10 00 00 91 1e 00 00      	call 0x1e91
   90ed0: 05 00 ed ff 00 00 00 00      	ja -0x13 <custom_panic+0xd920>
   90ed8: 07 07 00 00 78 00 00 00      	add64 r7, 0x78
   90ee0: 7b 7a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r7
   90ee8: 79 a7 18 ff 00 00 00 00      	ldxdw r7, [r10 - 0xe8]
   90ef0: 07 07 00 00 48 00 00 00      	add64 r7, 0x48
   90ef8: 79 a6 18 ff 00 00 00 00      	ldxdw r6, [r10 - 0xe8]
   90f00: 07 06 00 00 18 00 00 00      	add64 r6, 0x18
   90f08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   90f10: 07 01 00 00 30 ff ff ff      	add64 r1, -0xd0
   90f18: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   90f20: 07 02 00 00 80 ff ff ff      	add64 r2, -0x80
   90f28: 7b 3a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r3
   90f30: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   90f38: 85 10 00 00 c9 32 00 00      	call 0x32c9
   90f40: 79 a1 08 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf8]
   90f48: 63 1a 2c ff 00 00 00 00      	stxw [r10 - 0xd4], r1
   90f50: 63 8a 28 ff 00 00 00 00      	stxw [r10 - 0xd8], r8
   90f58: 7b 9a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r9
   90f60: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   90f68: 07 08 00 00 70 ff ff ff      	add64 r8, -0x90
   90f70: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   90f78: bf 72 00 00 00 00 00 00      	mov64 r2, r7
   90f80: 79 a7 18 ff 00 00 00 00      	ldxdw r7, [r10 - 0xe8]
   90f88: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   90f90: 85 10 00 00 be 32 00 00      	call 0x32be
   90f98: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   90fa0: 07 01 00 00 a0 ff ff ff      	add64 r1, -0x60
   90fa8: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   90fb0: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   90fb8: 85 10 00 00 b9 32 00 00      	call 0x32b9
   90fc0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   90fc8: 07 01 00 00 d0 ff ff ff      	add64 r1, -0x30
   90fd0: 79 a2 10 ff 00 00 00 00      	ldxdw r2, [r10 - 0xf0]
   90fd8: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   90fe0: 85 10 00 00 b4 32 00 00      	call 0x32b4
   90fe8: 79 74 a8 00 00 00 00 00      	ldxdw r4, [r7 + 0xa8]
   90ff0: 79 75 b0 00 00 00 00 00      	ldxdw r5, [r7 + 0xb0]
   90ff8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   91000: 07 01 00 00 20 ff ff ff      	add64 r1, -0xe0
   91008: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   91010: b7 03 00 00 03 00 00 00      	mov64 r3, 0x3
   91018: 85 10 00 00 9f 14 00 00      	call 0x149f
   91020: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   91028: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   91030: 67 01 00 00 20 00 00 00      	lsh64 r1, 0x20
   91038: 77 01 00 00 20 00 00 00      	rsh64 r1, 0x20
   91040: 55 01 09 00 1a 00 00 00      	jne r1, 0x1a, +0x9 <custom_panic+0xdb70>
   91048: b7 06 00 00 02 00 00 00      	mov64 r6, 0x2
   91050: 55 09 0e 00 00 00 00 00      	jne r9, 0x0, +0xe <custom_panic+0xdba8>
   91058: 05 00 12 00 00 00 00 00      	ja +0x12 <custom_panic+0xdbd0>
   91060: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   91068: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   91070: 15 02 37 00 00 00 00 00      	jeq r2, 0x0, +0x37 <custom_panic+0xdd10>
   91078: 27 02 00 00 30 00 00 00      	mul64 r2, 0x30
   91080: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   91088: 05 00 32 00 00 00 00 00      	ja +0x32 <custom_panic+0xdd00>
   91090: bf 01 00 00 00 00 00 00      	mov64 r1, r0
   91098: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   910a0: 85 10 00 00 11 0d 00 00      	call 0xd11
   910a8: bf 06 00 00 00 00 00 00      	mov64 r6, r0
   910b0: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   910b8: 79 a9 20 ff 00 00 00 00      	ldxdw r9, [r10 - 0xe0]
   910c0: 15 09 05 00 00 00 00 00      	jeq r9, 0x0, +0x5 <custom_panic+0xdbd0>
   910c8: 27 09 00 00 22 00 00 00      	mul64 r9, 0x22
   910d0: 79 a1 28 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd8]
   910d8: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   910e0: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   910e8: 85 10 00 00 36 e4 ff ff      	call -0x1bca
   910f0: 79 a2 38 ff 00 00 00 00      	ldxdw r2, [r10 - 0xc8]
   910f8: 15 02 03 00 00 00 00 00      	jeq r2, 0x0, +0x3 <custom_panic+0xdbf8>
   91100: 79 a1 40 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc0]
   91108: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   91110: 85 10 00 00 31 e4 ff ff      	call -0x1bcf
   91118: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   91120: 07 01 00 00 70 ff ff ff      	add64 r1, -0x90
   91128: 85 10 00 00 7c fd ff ff      	call -0x284
   91130: 79 79 08 00 00 00 00 00      	ldxdw r9, [r7 + 0x8]
   91138: 79 77 10 00 00 00 00 00      	ldxdw r7, [r7 + 0x10]
   91140: 15 07 16 00 00 00 00 00      	jeq r7, 0x0, +0x16 <custom_panic+0xdcd8>
   91148: bf 98 00 00 00 00 00 00      	mov64 r8, r9
   91150: 07 08 00 00 10 00 00 00      	add64 r8, 0x10
   91158: 05 00 03 00 00 00 00 00      	ja +0x3 <custom_panic+0xdc58>
   91160: 07 08 00 00 30 00 00 00      	add64 r8, 0x30
   91168: 07 07 00 00 ff ff ff ff      	add64 r7, -0x1
   91170: 15 07 10 00 00 00 00 00      	jeq r7, 0x0, +0x10 <custom_panic+0xdcd8>
   91178: 79 81 f8 ff 00 00 00 00      	ldxdw r1, [r8 - 0x8]
   91180: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   91188: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   91190: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   91198: 55 02 03 00 00 00 00 00      	jne r2, 0x0, +0x3 <custom_panic+0xdc98>
   911a0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   911a8: 07 01 00 00 f8 ff ff ff      	add64 r1, -0x8
   911b0: 85 10 00 00 3e 1e 00 00      	call 0x1e3e
   911b8: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   911c0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   911c8: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   911d0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   911d8: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <custom_panic+0xdc40>
   911e0: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   911e8: 85 10 00 00 2d 1e 00 00      	call 0x1e2d
   911f0: 05 00 ed ff 00 00 00 00      	ja -0x13 <custom_panic+0xdc40>
   911f8: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   91200: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   91208: 15 02 04 00 00 00 00 00      	jeq r2, 0x0, +0x4 <custom_panic+0xdd10>
   91210: 27 02 00 00 30 00 00 00      	mul64 r2, 0x30
   91218: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   91220: b7 03 00 00 08 00 00 00      	mov64 r3, 0x8
   91228: 85 10 00 00 0e e4 ff ff      	call -0x1bf2
   91230: bf 60 00 00 00 00 00 00      	mov64 r0, r6
   91238: 79 a1 10 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf0]
   91240: 95 00 00 00 00 00 00 00      	exit
   93510: 7b 4a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r4
   93518: 7b 3a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r3
   93520: bf 29 00 00 00 00 00 00      	mov64 r9, r2
   93528: 79 97 18 00 00 00 00 00      	ldxdw r7, [r9 + 0x18]
   93530: 79 93 10 00 00 00 00 00      	ldxdw r3, [r9 + 0x10]
   93538: 79 94 08 00 00 00 00 00      	ldxdw r4, [r9 + 0x8]
   93540: 79 52 18 f0 00 00 00 00      	ldxdw r2, [r5 - 0xfe8]
   93548: 79 56 10 f0 00 00 00 00      	ldxdw r6, [r5 - 0xff0]
   93550: 79 58 08 f0 00 00 00 00      	ldxdw r8, [r5 - 0xff8]
   93558: 79 55 00 f0 00 00 00 00      	ldxdw r5, [r5 - 0x1000]
   93560: 7b 5a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r5
   93568: 79 95 00 00 00 00 00 00      	ldxdw r5, [r9 + 0x0]
   93570: 18 00 00 00 06 dd f6 e1 00 00 00 00 ee 75 8f de      	lddw r0, -0x21708a111e0922fa
   93580: 5d 05 09 00 00 00 00 00      	jne r5, r0, +0x9 <custom_panic+0x100b0>
   93588: 18 00 00 00 18 42 5d bc 00 00 00 00 e4 6c cd da      	lddw r0, -0x2532931b43a2bde8
   93598: 5d 04 06 00 00 00 00 00      	jne r4, r0, +0x6 <custom_panic+0x100b0>
   935a0: 18 00 00 00 b6 1a fc 4d 00 00 00 00 83 b9 0d 27      	lddw r0, 0x270db9834dfc1ab6
   935b0: 5d 03 03 00 00 00 00 00      	jne r3, r0, +0x3 <custom_panic+0x100b0>
   935b8: 18 00 00 00 fe bd f9 28 00 00 00 00 d8 a1 8b fc      	lddw r0, -0x3745e27d7064202
   935c8: 1d 07 0c 00 00 00 00 00      	jeq r7, r0, +0xc <custom_panic+0x10110>
   935d0: 18 00 00 00 06 dd f6 e1 00 00 00 00 d7 65 a1 93      	lddw r0, -0x6c5e9a281e0922fa
   935e0: 5d 05 2c 00 00 00 00 00      	jne r5, r0, +0x2c <custom_panic+0x10228>
   935e8: 18 05 00 00 d9 cb e1 46 00 00 00 00 ce eb 79 ac      	lddw r5, -0x53861431b91e3427
   935f8: 5d 54 29 00 00 00 00 00      	jne r4, r5, +0x29 <custom_panic+0x10228>
   93600: 18 04 00 00 1c b4 85 ed 00 00 00 00 5f 5b 37 91      	lddw r4, -0x6ec8a4a0127a4be4
   93610: 5d 43 26 00 00 00 00 00      	jne r3, r4, +0x26 <custom_panic+0x10228>
   93618: 18 03 00 00 3a 8c f5 85 00 00 00 00 7e ff 00 a9      	lddw r3, -0x56ff00817a0a73c6
   93628: 5d 37 23 00 00 00 00 00      	jne r7, r3, +0x23 <custom_panic+0x10228>
   93630: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   93638: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
   93640: 62 0a b0 ff 08 00 00 00      	stw [r10 - 0x50], 0x8
   93648: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   93650: 07 01 00 00 80 ff ff ff      	add64 r1, -0x80
   93658: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   93660: 07 02 00 00 b0 ff ff ff      	add64 r2, -0x50
   93668: 85 10 00 00 71 fe ff ff      	call -0x18f
   93670: bf 67 00 00 00 00 00 00      	mov64 r7, r6
   93678: 07 07 00 00 03 00 00 00      	add64 r7, 0x3
   93680: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   93688: ad 67 01 00 00 00 00 00      	jlt r7, r6, +0x1 <custom_panic+0x10178>
   93690: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   93698: 7b 9a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r9
   936a0: 57 01 00 00 01 00 00 00      	and64 r1, 0x1
   936a8: 55 01 8e 00 00 00 00 00      	jne r1, 0x0, +0x8e <custom_panic+0x10600>
   936b0: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   936b8: 7b 1a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r1
   936c0: bf 71 00 00 00 00 00 00      	mov64 r1, r7
   936c8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   936d0: b7 03 00 00 22 00 00 00      	mov64 r3, 0x22
   936d8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   936e0: 85 10 00 00 13 32 00 00      	call 0x3213
   936e8: bf 09 00 00 00 00 00 00      	mov64 r9, r0
   936f0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   936f8: 55 01 01 00 00 00 00 00      	jne r1, 0x0, +0x1 <custom_panic+0x101e8>
   93700: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   93708: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   93710: 55 02 01 00 00 00 00 00      	jne r2, 0x0, +0x1 <custom_panic+0x10200>
   93718: 75 09 0a 00 00 00 00 00      	jsge r9, 0x0, +0xa <custom_panic+0x10250>
   93720: 79 a1 78 ff 00 00 00 00      	ldxdw r1, [r10 - 0x88]
   93728: bf 92 00 00 00 00 00 00      	mov64 r2, r9
   93730: 18 03 00 00 10 1d 0b 00 00 00 00 00 00 00 00 00      	lddw r3, 0xb1d10
   93740: 85 10 00 00 20 20 00 00      	call 0x2020
   93748: 18 02 00 00 00 00 00 00 00 00 00 00 00 00 00 80      	lddw r2, -0x8000000000000000
   93758: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   93760: 62 01 08 00 06 00 00 00      	stw [r1 + 0x8], 0x6
   93768: 05 00 75 00 00 00 00 00      	ja +0x75 <custom_panic+0x105f8>
   93770: 85 10 00 00 cf df ff ff      	call -0x2031
   93778: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   93780: 7b 1a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r1
   93788: bf 91 00 00 00 00 00 00      	mov64 r1, r9
   93790: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   93798: 85 10 00 00 3e df ff ff      	call -0x20c2
   937a0: 15 00 ef ff 00 00 00 00      	jeq r0, 0x0, -0x11 <custom_panic+0x10200>
   937a8: b7 09 00 00 01 00 00 00      	mov64 r9, 0x1
   937b0: 15 06 01 00 00 00 00 00      	jeq r6, 0x0, +0x1 <custom_panic+0x102a0>
   937b8: b7 09 00 00 00 00 00 00      	mov64 r9, 0x0
   937c0: 7b 0a a0 ff 00 00 00 00      	stxdw [r10 - 0x60], r0
   937c8: 7b 7a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r7
   937d0: 79 a2 60 ff 00 00 00 00      	ldxdw r2, [r10 - 0xa0]
   937d8: 79 21 18 00 00 00 00 00      	ldxdw r1, [r2 + 0x18]
   937e0: 7b 10 18 00 00 00 00 00      	stxdw [r0 + 0x18], r1
   937e8: 79 21 10 00 00 00 00 00      	ldxdw r1, [r2 + 0x10]
   937f0: 7b 10 10 00 00 00 00 00      	stxdw [r0 + 0x10], r1
   937f8: 79 21 08 00 00 00 00 00      	ldxdw r1, [r2 + 0x8]
   93800: 7b 10 08 00 00 00 00 00      	stxdw [r0 + 0x8], r1
   93808: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   93810: 7b 10 00 00 00 00 00 00      	stxdw [r0 + 0x0], r1
   93818: 6a 00 20 00 00 01 00 00      	sth [r0 + 0x20], 0x100
   93820: 79 a2 68 ff 00 00 00 00      	ldxdw r2, [r10 - 0x98]
   93828: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   93830: 7b 10 22 00 00 00 00 00      	stxdw [r0 + 0x22], r1
   93838: 79 21 08 00 00 00 00 00      	ldxdw r1, [r2 + 0x8]
   93840: 7b 10 2a 00 00 00 00 00      	stxdw [r0 + 0x2a], r1
   93848: 79 21 10 00 00 00 00 00      	ldxdw r1, [r2 + 0x10]
   93850: 7b 10 32 00 00 00 00 00      	stxdw [r0 + 0x32], r1
   93858: 79 21 18 00 00 00 00 00      	ldxdw r1, [r2 + 0x18]
   93860: 7b 10 3a 00 00 00 00 00      	stxdw [r0 + 0x3a], r1
   93868: 6a 00 42 00 00 01 00 00      	sth [r0 + 0x42], 0x100
   93870: 7a 0a a8 ff 02 00 00 00      	stdw [r10 - 0x58], 0x2
   93878: 55 07 06 00 02 00 00 00      	jne r7, 0x2, +0x6 <custom_panic+0x10390>
   93880: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   93888: 07 01 00 00 98 ff ff ff      	add64 r1, -0x68
   93890: 18 02 00 00 28 1d 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1d28
   938a0: 85 10 00 00 57 0f 00 00      	call 0xf57
   938a8: 79 a0 a0 ff 00 00 00 00      	ldxdw r0, [r10 - 0x60]
   938b0: 79 a2 70 ff 00 00 00 00      	ldxdw r2, [r10 - 0x90]
   938b8: 79 21 18 00 00 00 00 00      	ldxdw r1, [r2 + 0x18]
   938c0: 7b 10 5c 00 00 00 00 00      	stxdw [r0 + 0x5c], r1
   938c8: 79 21 10 00 00 00 00 00      	ldxdw r1, [r2 + 0x10]
   938d0: 7b 10 54 00 00 00 00 00      	stxdw [r0 + 0x54], r1
   938d8: 79 21 08 00 00 00 00 00      	ldxdw r1, [r2 + 0x8]
   938e0: 7b 10 4c 00 00 00 00 00      	stxdw [r0 + 0x4c], r1
   938e8: 79 21 00 00 00 00 00 00      	ldxdw r1, [r2 + 0x0]
   938f0: 7b 10 44 00 00 00 00 00      	stxdw [r0 + 0x44], r1
   938f8: 73 90 64 00 00 00 00 00      	stxb [r0 + 0x64], r9
   93900: 72 00 65 00 00 00 00 00      	stb [r0 + 0x65], 0x0
   93908: 7a 0a a8 ff 03 00 00 00      	stdw [r10 - 0x58], 0x3
   93910: 15 06 26 00 00 00 00 00      	jeq r6, 0x0, +0x26 <custom_panic+0x10528>
   93918: b7 07 00 00 03 00 00 00      	mov64 r7, 0x3
   93920: b7 09 00 00 00 00 00 00      	mov64 r9, 0x0
   93928: 67 06 00 00 03 00 00 00      	lsh64 r6, 0x3
   93930: 05 00 11 00 00 00 00 00      	ja +0x11 <custom_panic+0x104a0>
   93938: 07 08 00 00 08 00 00 00      	add64 r8, 0x8
   93940: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
   93948: 0f 91 00 00 00 00 00 00      	add64 r1, r9
   93950: 79 a2 c8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x38]
   93958: 7b 21 7e 00 00 00 00 00      	stxdw [r1 + 0x7e], r2
   93960: 79 a2 c0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x40]
   93968: 7b 21 76 00 00 00 00 00      	stxdw [r1 + 0x76], r2
   93970: 79 a2 b8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x48]
   93978: 7b 21 6e 00 00 00 00 00      	stxdw [r1 + 0x6e], r2
   93980: 79 a2 b0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x50]
   93988: 7b 21 66 00 00 00 00 00      	stxdw [r1 + 0x66], r2
   93990: 6a 01 86 00 01 00 00 00      	sth [r1 + 0x86], 0x1
   93998: 07 09 00 00 22 00 00 00      	add64 r9, 0x22
   939a0: 07 07 00 00 01 00 00 00      	add64 r7, 0x1
   939a8: 7b 7a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r7
   939b0: 07 06 00 00 f8 ff ff ff      	add64 r6, -0x8
   939b8: 15 06 11 00 00 00 00 00      	jeq r6, 0x0, +0x11 <custom_panic+0x10528>
   939c0: 79 81 00 00 00 00 00 00      	ldxdw r1, [r8 + 0x0]
   939c8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   939d0: 7b 2a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r2
   939d8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   939e0: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
   939e8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   939f0: 7b 2a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r2
   939f8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   93a00: 7b 1a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r1
   93a08: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
   93a10: 5d 17 e4 ff 00 00 00 00      	jne r7, r1, -0x1c <custom_panic+0x10418>
   93a18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   93a20: 07 01 00 00 98 ff ff ff      	add64 r1, -0x68
   93a28: 18 02 00 00 40 1d 0b 00 00 00 00 00 00 00 00 00      	lddw r2, 0xb1d40
   93a38: 85 10 00 00 24 0f 00 00      	call 0xf24
   93a40: 05 00 de ff 00 00 00 00      	ja -0x22 <custom_panic+0x10418>
   93a48: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
   93a50: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   93a58: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
   93a60: 7b 1a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r1
   93a68: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
   93a70: 7b 1a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r1
   93a78: 79 a4 50 ff 00 00 00 00      	ldxdw r4, [r10 - 0xb0]
   93a80: 79 41 18 00 00 00 00 00      	ldxdw r1, [r4 + 0x18]
   93a88: 79 42 10 00 00 00 00 00      	ldxdw r2, [r4 + 0x10]
   93a90: 79 43 08 00 00 00 00 00      	ldxdw r3, [r4 + 0x8]
   93a98: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   93aa0: 79 a5 80 ff 00 00 00 00      	ldxdw r5, [r10 - 0x80]
   93aa8: 7b 5a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r5
   93ab0: 79 a5 88 ff 00 00 00 00      	ldxdw r5, [r10 - 0x78]
   93ab8: 7b 5a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r5
   93ac0: 79 a5 90 ff 00 00 00 00      	ldxdw r5, [r10 - 0x70]
   93ac8: 7b 5a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r5
   93ad0: 7b 4a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r4
   93ad8: 7b 3a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r3
   93ae0: 7b 2a f0 ff 00 00 00 00      	stxdw [r10 - 0x10], r2
   93ae8: 7b 1a f8 ff 00 00 00 00      	stxdw [r10 - 0x8], r1
   93af0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   93af8: 07 02 00 00 b0 ff ff ff      	add64 r2, -0x50
   93b00: 79 a1 58 ff 00 00 00 00      	ldxdw r1, [r10 - 0xa8]
   93b08: b7 03 00 00 50 00 00 00      	mov64 r3, 0x50
   93b10: 85 10 00 00 4e 2d 00 00      	call 0x2d4e
   93b18: 95 00 00 00 00 00 00 00      	exit
   93b20: 18 01 00 00 f8 1c 0b 00 00 00 00 00 00 00 00 00      	lddw r1, 0xb1cf8
   93b30: 85 10 00 00 ed 29 00 00      	call 0x29ed
   976d8: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   976e0: b7 01 00 00 02 00 00 00      	mov64 r1, 0x2
   976e8: 71 23 28 00 00 00 00 00      	ldxb r3, [r2 + 0x28]
   976f0: 55 03 04 00 00 00 00 00      	jne r3, 0x0, +0x4 <custom_panic+0x141f8>
   976f8: b7 01 00 00 c2 0b 00 00      	mov64 r1, 0xbc2
   97700: 85 10 00 00 dc 05 00 00      	call 0x5dc
   97708: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   97710: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   97718: 7b 16 00 00 00 00 00 00      	stxdw [r6 + 0x0], r1
   97720: 7b 26 08 00 00 00 00 00      	stxdw [r6 + 0x8], r2
   97728: 95 00 00 00 00 00 00 00      	exit
   9efd0: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   9efd8: 7a 0a f8 ff 00 00 00 00      	stdw [r10 - 0x8], 0x0
   9efe0: 7a 0a f0 ff 00 00 00 00      	stdw [r10 - 0x10], 0x0
   9efe8: 7a 0a e8 ff 00 00 00 00      	stdw [r10 - 0x18], 0x0
   9eff0: 7a 0a e0 ff 00 00 00 00      	stdw [r10 - 0x20], 0x0
   9eff8: 7a 0a d8 ff 00 00 00 00      	stdw [r10 - 0x28], 0x0
   9f000: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   9f008: 07 01 00 00 d8 ff ff ff      	add64 r1, -0x28
   9f010: 85 10 00 00 ff ff ff ff      	call -0x1
   9f018: 15 00 03 00 00 00 00 00      	jeq r0, 0x0, +0x3 <custom_panic+0x1bb18>
   9f020: 62 06 04 00 10 00 00 00      	stw [r6 + 0x4], 0x10
   9f028: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   9f030: 05 00 0b 00 00 00 00 00      	ja +0xb <custom_panic+0x1bb70>
   9f038: 79 a1 f8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x8]
   9f040: 7b 16 28 00 00 00 00 00      	stxdw [r6 + 0x28], r1
   9f048: 79 a1 f0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x10]
   9f050: 7b 16 20 00 00 00 00 00      	stxdw [r6 + 0x20], r1
   9f058: 79 a1 e8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x18]
   9f060: 7b 16 18 00 00 00 00 00      	stxdw [r6 + 0x18], r1
   9f068: 79 a1 e0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x20]
   9f070: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   9f078: 79 a1 d8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x28]
   9f080: 7b 16 08 00 00 00 00 00      	stxdw [r6 + 0x8], r1
   9f088: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   9f090: 63 16 00 00 00 00 00 00      	stxw [r6 + 0x0], r1
   9f098: 95 00 00 00 00 00 00 00      	exit
