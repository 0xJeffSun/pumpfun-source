# Mayhem next pass: BuyPumpSwap zero-divisor error construction

## Actionable proposal

`proposal.patch` makes one isolated source correction across two files:

1. Add `PumpSwapCpiMathOverflow = 11` with original message `Math Overflow in Pump Swap CPI call` to the existing `PumpSwapError` enum.
2. At the BuyPumpSwap sizing division, convert `checked_div`'s None into that typed enum error before the existing terminal unwrap:

```rust
// Before
let input=u64::try_from((output as u128*vt).checked_div(vs+output as u128).unwrap()).unwrap();
// After
let input=u64::try_from((output as u128*vt).checked_div(vs+output as u128).ok_or(PumpSwapError::PumpSwapCpiMathOverflow).unwrap()).unwrap();
```

This changes the zero-divisor panic construction from **Option::unwrap(None)** to **Result::unwrap(Err(PumpSwapCpiMathOverflow))**, as the original does. It does not return a recoverable Anchor error6011. The product, denominator addition, checked division, successful quotient, and outer u64 conversion are unchanged. Only `buy_pump_swap` calls the added variant. Other trades, initializers, account admission, signatures, CPIs and error paths are unchanged by the proposed source diff.

The explicit value11 is not chosen for compiler shape: the original writes exactly11 into the error value passed to its Debug implementation. The existing split reconstructed `PumpSwapError` already uses original value10 for `PumpSwapCpiFailed`; adding the adjacent original variant to this type is the smallest source factoring hypothesis. There is no new private error type or boxed Anchor Error conversion.

## Exact original evidence

Original ELF SHA256: `a87fa9f866272514e6acb852b668c4a08aeb173d56c883039991d114d1199bdb`.
Current retained candidate SHA256: `9e4e19dfb3b3fefbec13ecfc0d43ffd2ff0bea7b74ac7b2fe14126d23c79c05b`.

The complete original BuyPumpSwap handler [85600,95336), its full sizing helper [185296,186552), full Debug [196888,197000), full Display [196056,196888), and full Result unwrap helper [674280,674512) are retained under `evidence/`. Original function boundaries are inherited next-known-entry boundaries, not historical debug symbols. Handler identity is the permitted non-initializer attribution retained in the pass01 ledger (O0077, with candidate C0103); unknown mixed dispatch and initializer bodies were not used.

The handler calls the sizing helper at87736 ->185296. In the helper, the final denominator is added at185952 (or the equivalent min-selection arm186144) with an explicit carry. At186176–186192, the low denominator OR carry determines whether to divide. Nonzero branches to186000 and calls697904 at186072. Zero falls through to186200, which writes u32 value11 at frame-8. The error path then passes:

- r1 =709876 and r2 =43: literal `called Result::unwrap() on an Err value` (with the backticks present in the actual bytes);
- r3 =pointer to the value11;
- r4 =727032: a Debug vtable with size4 and alignment4;
- r5 =727184: original source-location descriptor, retained as evidence only.

The call at186280 targets674280. The inherited original-to-candidate mapping identifies674280 as `core::result::unwrap_failed`; its entire body and the caller setup are retained. The proposal uses normal Rust `unwrap()` and does not forge the original source path/line.

The vtable formatter slot727056 contains a type8 relocation to196888. Its full body loads the u32 discriminant, multiplies by8, looks up the pointer table727696 and length table713112, and calls682144 at196984. For index11:

- pointer slot727784 ->710761;
- length slot713200 ->23;
- exact bytes: `PumpSwapCpiMathOverflow`.

The full Display body selects11 through196096 ->196168,196176 ->196376,196376 ->196784. It loads711138 and length35, then reaches its indirect formatting call at196872. The exact message bytes are `Math Overflow in Pump Swap CPI call`. This establishes both name and message; neither is guessed from the current source or a log substring.

## Existing observed mismatch

`observed-diagnostic.json` retains the existing pass01 diagnostic for `buy_pump_swap` case `virtual_-122946690720`, from `repro/mayhem/twentyfour/buy-pump-swap-native-differential.json.gz` case73. Both versions ended with ProgramFailedToComplete. The candidate additionally logged `called Option::unwrap() on a None value` at the current sizing line; the original reported its panic at the original state.rs location. This is motivation, not a runtime test of this proposal.

The source correction follows the original static typed-Result failure construction. It does **not** promise matching final logs: formatting-engine behavior, source diagnostics, compiler lowering, panic strategy and source paths still differ and are not corrected by this patch. Replacing checked division with bare `/`, manually emitting the desired log, returning6011 instead of panicking, or using abort solely to suppress text would not be supported by this evidence.

## Source factoring and limits

Current allowed source was inspected: `MayhemError` has `MathOverflow` (different Debug name), `BuyError` has no relevant math variant, `SellError` has no relevant math variant, and `PumpSwapError` currently has only `PumpSwapCpiFailed=10`. No retained Rust source containing `PumpSwapCpiMathOverflow` was found in the scoped public Mayhem packages. The original single-enum name is unavailable. Reusing/expanding the already present PumpSwap error type is therefore a concrete minimal reconstruction, not recovered historical text.

The original sizing helper also has other narrowing/error branches. This proposal addresses only the final division's None arm and leaves the outer `u64::try_from(...).unwrap()` intact. It does not assert complete sizing-helper equivalence, all error enum/constructor equality, or full original/candidate identity. No additional GlobalParams roles are inferred. The excluded initializer was not analyzed or changed.

No compile, runtime invocation, new fixture, transaction, compiler/layout search, target modification, or manufactured source coordinates occurred. A future acceptance pass must check compilation and replay existing permitted receipts before any integration claim; no new runtime case is required or supplied here.

## Reproduce the static evidence

Run `PYTHONDONTWRITEBYTECODE=1 python3 inspect_evidence.py` from any directory. This uses only the copied pinned ELFs and local standard-library decoding helpers. It regenerates full assembly windows and asserts the critical original instructions, calls, branches, relocations and literal bytes. It never executes the ELF. `input-bindings.json` and `manifest.json` bind original source/evidence inputs and this package's outputs.
