"""Read-only ELF evidence extraction; does not execute any SBF code."""
from pathlib import Path
import sys,struct,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'method'))
import disasm
H=lambda b:hashlib.sha256(b).hexdigest()
O=disasm.a.Elf((P/'inputs/original.so').read_bytes())
C=disasm.a.Elf((P/'inputs/candidate.so').read_bytes())
assert H(O.b)=='a87fa9f866272514e6acb852b668c4a08aeb173d56c883039991d114d1199bdb'
assert H(C.b)=='9e4e19dfb3b3fefbec13ecfc0d43ffd2ff0bea7b74ac7b2fe14126d23c79c05b'
windows=[('original-buy-handler',O,85600,95336),('original-buy-sizing',O,185296,186552),('original-error-display',O,196056,196888),('original-error-debug',O,196888,197000),('original-result-unwrap',O,674280,674512),('candidate-buy-handler',C,121656,138512)]
for name,e,a,b in windows:
 (P/'evidence'/f'{name}.asm').write_text(disasm.render(e,a,b))
def instruction(e,pc):return struct.unpack('<BBhi',e.at(pc,8))
def call(pc,target):
 o,r,f,i=instruction(O,pc);assert o==0x85 and pc+8+i*8==target
 return {'pc':pc,'bytes':O.at(pc,8).hex(),'target':target}
def branch(pc,target):
 o,r,f,i=instruction(O,pc);assert o&7 in (5,6) and pc+8+f*8==target
 return {'pc':pc,'bytes':O.at(pc,8).hex(),'target':target}
assert instruction(O,186200)==(0x62,0x0a,-8,11)
assert O.at(709876,43)==b'called `Result::unwrap()` on an `Err` value'
# In this ELF, dynamic relocation type8 encodes its address in upper u32.
assert O.relocations[727056]['type']==8
fmt=struct.unpack('<II',O.at(727056,8))[1];assert fmt==196888
assert struct.unpack('<Q',O.at(727040,8))[0]==4
assert struct.unpack('<Q',O.at(727048,8))[0]==4
name_slot=727696+11*8;len_slot=713112+11*8
assert O.relocations[name_slot]['type']==8
name=struct.unpack('<II',O.at(name_slot,8))[1];n=struct.unpack('<Q',O.at(len_slot,8))[0]
assert (name,n)==(710761,23)
assert O.at(name,n)==b'PumpSwapCpiMathOverflow'
assert O.at(711138,35)==b'Math Overflow in Pump Swap CPI call'
records={
 'original_sha256':H(O.b),'candidate_sha256':H(C.b),
 'full_windows':[{'name':name,'start':a,'end':b,'sha256':H(e.at(a,b-a)),'boundary':'retained next-entry boundary; original symbols unavailable'} for name,e,a,b in windows],
 'calls':[call(87736,185296),call(186072,697904),call(186280,674280),call(196984,682144)],
 'zero_divisor_branch':branch(186192,186000),
 'zero_divisor_fallthrough':{'from':186192,'to':186200,'meaning':'r7 | carry equals zero'},
 'error_variant_store':{'pc':186200,'bytes':O.at(186200,8).hex(),'value':11},
 'unwrap_literal':{'address':709876,'length':43,'utf8':O.at(709876,43).decode()},
 'debug_vtable':{'address':727032,'size':4,'align':4,'formatter_pointer_slot':727056,'formatter':fmt,'raw_hex':O.at(727032,32).hex()},
 'debug_name':{'index':11,'pointer_slot':name_slot,'length_slot':len_slot,'address':name,'length':n,'utf8':O.at(name,n).decode()},
 'display_selector_branches':[branch(196096,196168),branch(196176,196376),branch(196376,196784),branch(196808,196872)],
 'display_message':{'address':711138,'length':35,'utf8':O.at(711138,35).decode()},
 'limits':['static branch/call/data evidence only','no full-handler semantic equivalence','no post-proposal build/runtime result','original function names absent; role attribution from retained non-initializer ledger','formatter engine and indirect call behavior not recursively proved'],
}
(P/'evidence/result.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'full_windows':len(windows),'error_name':records['debug_name']['utf8'],'message':records['display_message']['utf8']}))
