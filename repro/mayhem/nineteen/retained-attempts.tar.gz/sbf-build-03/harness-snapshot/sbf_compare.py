#!/usr/bin/env python3
"""Unmodified original/candidate SBF comparison with ordinary signatures and synthetic accounts."""
from pathlib import Path
import json,hashlib,base64,argparse,re
import sbf_probe as p
from solders.transaction import Transaction
D=Path(__file__).resolve().parent
NAMES=['trader','global_params','mayhem_state','sol_vault','mint','mayhem_token_vault','token_program','system_program','global','bonding_curve','fee_recipient','associated_bonding_curve','creator_vault','pump_event_authority','pump_program','fee_config','fee_program','event_authority','program','bonding_curve_v2','buyback_recipient']
def cases():
 rows=[r['case'] for r in json.loads((D/'model-original-validation.json').read_text())['cases']]
 rows += [{'name':'unsigned_trader','unsigned_trader':True},{'name':'extra_account','extra_account':True},{'name':'trailing','trailing':'abcd00ff'}]
 for i in range(21):rows.append({'name':f'account_count_{i}','account_count':i})
 for n in range(20):rows.append({'name':f'payload_{n}','payload_length':n})
 for i in [0,1,2,3,5,9,10,11,12,20]:rows.append({'name':'readonly_'+NAMES[i],'readonly':[i]})
 for i in range(1,21):rows.append({'name':'wrong_key_'+NAMES[i],'wrong_keys':[i]})
 for i in [1,2,4,5,9,11]:
  for label,change in [('owner',{'system_owner':True}),('empty',{'length':0}),('disc',{'bytes':[[0,0]]})]:rows.append({'name':f'{NAMES[i]}_{label}','mutations':{i:change}})
 for label,i,offset in [('trader_mismatch',1,81),('vault_mint',5,0),('vault_owner',5,32),('curve_ata_mint',11,0),('curve_ata_owner',11,32)]:rows.append({'name':label,'mutations':{i:{'pubkey':[[offset,str(p.TRADER.pubkey())]]}}})
 for i,off in [(1,48),(2,88),(2,97),(9,48),(9,81)]:rows.append({'name':f'invalid_flag_{i}_{off}','mutations':{i:{'bytes':[[off,4]]}}})
 for i,sizes in [(1,[7,8,48,49,80,112,253,254,318]),(2,[7,8,88,89,97,98,105,106,170]),(4,[81,82]),(5,[164,165]),(9,[7,8,48,49,80,81,82,166]),(11,[164,165])]:
  for n in sizes:rows.append({'name':f'length_{NAMES[i]}_{n}','mutations':{i:{'length':n}}})
 for v in [0,1]:
  for i in [5,11]:rows.append({'name':f'token_initialized_{i}_{v}','mutations':{i:{'bytes':[[108,v]]}}})
 # Matched fixture configurations add independent arithmetic/rounding and ordinary rejection paths.
 for retained in [0,1,2500,5000,9998,9999,10000]:
  for cap in [0,1,1000]:rows.append({'name':f'reserve_{retained}_cap_{cap}','retained':retained,'cap':cap})
 # The original external curve wrapper pads up to the full 141-byte schema.
 # Every truncation checks that partial fields, not only field boundaries, agree.
 for n in range(142):rows.append({'name':f'curve_prefix_{n}','mutations':{9:{'length':n}}})
 for off in [48,81,82,123,124]:
  for value in [0,1,2,255]:rows.append({'name':f'curve_bool_{off}_{value}','curve_bytes':[[off,value]]})
 for off in [115,125,133]:rows.append({'name':f'curve_tail_u64_{off}','curve_u64':[[off,(1<<64)-1]]})
 rows.append({'name':'curve_quote_mint','mutations':{9:{'pubkey':[[83,str(p.TRADER.pubkey())]]}}})
 for now in [-1,0,99,100,101]:rows.append({'name':f'clock_{now}','now':now})
 for vt,vs,tokens in [(1,1,1),(1,(1<<64)-1,1),((1<<64)-1,1,(1<<64)-1),((1<<64)-1,(1<<64)-1,(1<<64)-1),(1,0,1),(1,1,0),(1000,1000,1000)]:
  rows.append({'name':f'quote_extreme_{vt}_{vs}_{tokens}','tokens':tokens,'curve_u64':[[8,vt],[16,vs]]})
 spl='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'
 for key in [spl,str(p.PUMP),str(p.MAY),str(p.f.Pubkey.default())]:rows.append({'name':'token_program_replace_'+key,'replace_keys':{6:key}})
 for i in [4,5,11]:rows.append({'name':'legacy_token_owner_'+NAMES[i],'mutations':{i:{'owner':spl}}})
 return rows

def normlogs(logs):
 out=[]
 for l in logs:
  if re.search(r' consumed \d+ of \d+ compute units',l):continue
  l=re.sub(r'AnchorError thrown in .+?:\d+\.', 'AnchorError thrown in <source>.',l)
  if 'panicked at' in l:continue
  out.append(l)
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--limit',type=int);a=ap.parse_args();rows=[];mismatches=[]
 for c in cases()[:a.limit]:
  original=p.run(c);candidate=p.run(c,a.candidate);diff=[]
  for r in [original,candidate]:
   tx=Transaction.from_bytes(base64.b64decode(r['transaction_base64']));assert all(tx.verify_with_results())
  if original['transaction_base64']!=candidate['transaction_base64']:diff.append('signed_transaction')
  for phase in ['before','after']:
   x={k:v for k,v in original[phase].items() if k!=str(p.MAY)};y={k:v for k,v in candidate[phase].items() if k!=str(p.MAY)}
   if x!=y:diff.append(phase)
  if original['error']!=candidate['error']:diff.append('error')
  for field in ['inner_instructions','return_data']:
   if original['metadata'][field]!=candidate['metadata'][field]:diff.append(field)
  ev=lambda r:[l for l in r['metadata']['logs'] if l.startswith('Program data: ')]
  if ev(original)!=ev(candidate):diff.append('events')
  logdiff=normlogs(original['metadata']['logs'])!=normlogs(candidate['metadata']['logs'])
  row={'case':c,'original':original,'candidate':candidate,'different_fields':diff,'normalized_log_difference':logdiff};rows.append(row)
  if diff:mismatches.append({'case':c['name'],'fields':diff,'original_error':original['error'],'candidate_error':candidate['error']})
  print(c['name'],original['error'],diff,flush=True)
 report={'scope':__doc__,'candidate_sha256':p.sha(a.candidate.read_bytes()),'candidate_bytes':a.candidate.stat().st_size,'original_sha256':p.sha((p.ROOT/'evidence/original/mayhem/deployed.so').read_bytes()),'case_count':len(rows),'successful_original_cases':sum(r['original']['error'] is None for r in rows),'signed_transactions':2*len(rows),'mismatches':mismatches,'normalized_log_differences':[r['case']['name'] for r in rows if r['normalized_log_difference']],'harness_sha256':{str(x.relative_to(p.ROOT)):p.sha(x.read_bytes()) for x in [Path(__file__).resolve(),D/'sbf_probe.py',p.ROOT/'scripts/pump_trade_fixture.py']},'cases':rows}
 a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['case_count','successful_original_cases','mismatches']}));raise SystemExit(bool(mismatches))
if __name__=='__main__':main()
