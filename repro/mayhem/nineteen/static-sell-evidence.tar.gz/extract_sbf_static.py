#!/usr/bin/env python3
"""Extract original-ELF-checked sell evidence with actual relative branch targets."""
from pathlib import Path
import re,struct,json,hashlib
D=Path(__file__).resolve().parent;ROOT=D.parents[1];out=D/'sbf-static';out.mkdir(exist_ok=True)
elf=ROOT/'evidence/original/mayhem/deployed.so';asm=ROOT/'work/disassembly/mayhem.asm'
b=elf.read_bytes();lines=asm.read_text().splitlines();rows=[]
ranges=[('curve-padding',0xac0,0x1860),('curve-account-and-reload',0x5fb0,0x6a18),('curve-decoder',0x84108,0x84c80),('token2022-program-parser',0xa770,0xa970),('sell-accounts',0x56f08,0x5a8b0),('sell-handler',0x1f220,0x224e0),('sell-state-update',0x2cf88,0x2d3d0),('sell-guards',0x2dd18,0x2e640),('sell-event-serialize',0x5b700,0x5c6d8)]
for name,start,end in ranges:
 result=[]
 for line in lines:
  m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2} )+)\s+(.*)',line)
  if not m:continue
  at=int(m[1],16)
  if not start<=at<end:continue
  raw=bytes.fromhex(m[2]);assert b[at:at+len(raw)]==raw
  text=m[3];op=raw[0]
  if op==0x85 and raw[1]==0x10:text+=' ; true_call '+hex(at+8+8*struct.unpack_from('<i',raw,4)[0])
  elif op&7==5 and op not in (0x85,0x95,0x8d):text+=' ; true_branch '+hex(at+8+8*struct.unpack_from('<h',raw,2)[0])
  result.append(f'{at:06x}: {raw.hex()}  {text}')
 p=out/(name+'.asm');p.write_text('\n'.join(result)+'\n');rows.append({'path':str(p.relative_to(D)),'start':start,'end_exclusive':end,'verified_instructions':len(result),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'provenance.json').write_text(json.dumps({'original_sha256':hashlib.sha256(b).hexdigest(),'disassembly_sha256':hashlib.sha256(asm.read_bytes()).hexdigest(),'note':'Address ranges are bounded excerpts, not claimed source function boundaries. Actual relative call and branch targets are recomputed from instruction bytes because the old disassembler labels were offset.','excerpts':rows},indent=2)+'\n')
