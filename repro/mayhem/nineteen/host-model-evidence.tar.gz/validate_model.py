#!/usr/bin/env python3
"""Compare the static Rust model to unmodified original ELF over normally signed synthetic fixtures."""
from pathlib import Path
import json,base64,struct,subprocess,re,hashlib
import probe_sell as p
from solders.transaction import Transaction
D=Path(__file__).resolve().parent
cases=[{'name':'base'},{'name':'wrong_v2_program','wrong_v2_program':True}]
for name,changes in [
 ('paused',{'paused':1}),('paused_precedes_deadline',{'paused':1,'deadline':100}),
 ('interval_before_deadline',{'last':99,'interval':2,'deadline':100}),
 ('interval_equal',{'last':99,'interval':1}),('interval_zero',{'last':99,'interval':0}),
 ('last_zero',{'last':0,'interval':1000}),('interval_negative',{'last':101,'interval':-2}),
 ('interval_overflow',{'last':2**63-1,'interval':1}),('deadline_equal',{'deadline':100}),('deadline_before',{'deadline':99}),
 ('threshold_below',{'status':0,'threshold':27959}),('threshold_equal',{'status':0,'threshold':27960}),
 ('threshold_above',{'status':0,'threshold':27961}),('active_skips_threshold',{'status':1,'threshold':2**64-1}),
 ('status2_unexpired',{'status':2,'threshold':0}),('zero_virtual_tokens',{'curve_u64':[(8,0)]}),
 ('reference_zero',{'reference':0}),('reference_max',{'reference':2**128-1}),
 ('tolerance0',{'tolerance':0}),('tolerance10000',{'tolerance':10000}),('tolerance10001',{'tolerance':10001}),
 ('tolerance65535',{'tolerance':65535}),('retained0',{'retained':0}),('retained9999',{'retained':9999}),
 ('retained10000',{'retained':10000}),('retained10001',{'retained':10001}),('retained65535',{'retained':65535}),
 ('positive_counters',{'global_sol':123456789,'state_sol':23456789,'state_tokens':3456789}),
 ('negative_counters',{'global_sol':-123456789,'state_sol':-23456789,'state_tokens':-3456789}),
 ('global_underflow',{'global_sol':-(2**127)}),('state_underflow',{'state_sol':-(2**127)}),('token_overflow',{'state_tokens':2**127-1})]:cases.append({'name':name,**changes})
for tokens in [0,1,10,100,10000,10**6,10**12]:cases.append({'name':f'tokens_{tokens}','tokens':tokens})
for cap in [1,2,100,2795,2796,2797,100000,2**64-1]:cases.append({'name':f'cap_{cap}','cap':cap})
# Exact reference-price band boundaries with zero tolerance exercise inclusive comparisons.
baseprice=30000027960*10**15//1072999000000000
for delta in [-1,0,1]:cases.append({'name':f'zero_tolerance_price_{delta}','reference':baseprice+delta,'tolerance':0})
rows=[];mismatches=[]
def number(data,off,size,signed=False):return int.from_bytes(data[off:off+size],'little',signed=signed)
def bytesof(snap):return base64.b64decode(snap['data_base64'])
for case in cases:
 r=p.run(case);vt,vs,rt,rs=r['inputs']['curve'];reference=r['inputs']['reference']
 args=[case.get('paused',0),case.get('last',0),case.get('interval',0),case.get('deadline',10000),case.get('status',1),case.get('threshold',0),vt,vs,rs,case.get('tokens',10**9),case.get('cap',0),reference,case.get('tolerance',2400),case.get('retained',9000)]
 model=json.loads(subprocess.check_output([str(D/'crate/target/debug/mayhem-sell-static-draft'),*map(str,args)],text=True))
 tx=Transaction.from_bytes(base64.b64decode(r['transaction_base64']));assert tx.verify_with_results()==[True]
 direct=[i for group in r['metadata']['inner_instructions'] for i in group if i['stackHeight']==2 and tx.message.account_keys[i['instruction']['programIdIndex']]==p.PUMP]
 failures=[];checks={}
 if case.get('wrong_v2_program'):
  checks['parser_rejected_pump_derived_v2']=r['error'] is not None and 'Custom(2006)' in r['error']
 elif 'error' in model:
  checks['guard_or_quote_error']=r['error'] is not None and f'Custom({model["error"]})' in r['error']
 elif 'panic' in model:
  checks['panic']=r['error'] is not None and 'ProgramFailedToComplete' in r['error']
 else:
  expected=bytes.fromhex('33e685a4017f83ad')+struct.pack('<QQ',model['token_input'],model['minimum_sol_output'])
  actual=bytes(direct[0]['instruction']['data'][1:]) if direct else b''
  checks['pump_cpi_arguments']=actual==expected
  if r['error'] is None:
   keys=list(r['before']);globalkey,statekey,solkey,mintkey,vaultkey=[keys[i] for i in [1,2,3,4,5]]
   g=bytesof(r['after'][globalkey]);s=bytesof(r['after'][statekey]);v=bytesof(r['after'][vaultkey]);cb=bytesof(r['after'][str(p.CURVE)])
   sol=r['after'][solkey]['lamports']-r['before'][solkey]['lamports'];tokens=number(bytesof(r['before'][vaultkey]),64,8)-number(v,64,8)
   checks['post_cpi_state']=number(g,113,16,True)==case.get('global_sol',0)-sol and number(s,56,16,True)==case.get('state_sol',0)-sol and number(s,72,16,True)==case.get('state_tokens',0)+tokens and number(s,89,8,True)==100 and s[97]==model['status']
   vtp,vsp,rtp,rsp=struct.unpack_from('<QQQQ',cb,8)
   event=bytes.fromhex('31487b2d6e40b085')+b'\1'+bytes(p.SOL)+bytes(p.f.Pubkey.from_string(mintkey))
   event+=struct.pack('<QQQQ',sol,tokens,r['after'][solkey]['lamports'],number(v,64,8))
   event+=s[56:88]+struct.pack('<QQ',vsp,vtp)+g[113:129]+struct.pack('<qqQQIH',100,case.get('deadline',10000),rsp,rtp,number(g,162,4),case.get('retained',9000))
   event+=struct.pack('<QQ',sol,r['after'][solkey]['lamports'])+s[56:72]+struct.pack('<Q',vsp)+g[113:129]+struct.pack('<Q',rsp)+bytes(32)
   logs=[base64.b64decode(line[14:]) for line in r['metadata']['logs'] if line.startswith('Program data: ')]
   checks['complete_303_byte_event']=len(event)==303 and event in logs
   selfcalls=[i for group in r['metadata']['inner_instructions'] for i in group if i['stackHeight']==2 and tx.message.account_keys[i['instruction']['programIdIndex']]==p.MAY]
   checks['matching_event_cpi']=bool(selfcalls) and bytes(selfcalls[-1]['instruction']['data'][1:])==bytes.fromhex('e445a52e51cb9a1d')+event
  elif case['name'] in ['global_underflow','state_underflow','token_overflow']:
   checks['post_cpi_checked_overflow']='Custom(6002)' in r['error']
 if r['error']:
  checks['failed_transaction_business_state_rollback']=all(r['before'][key]==r['after'][key] for key in r['before'] if key!=str(p.TRADER.pubkey()))
 failures=[name for name,ok in checks.items() if not ok]
 r.update(model=model,checks=checks,failures=failures);rows.append(r)
 if failures:mismatches.append({'case':case['name'],'failures':failures})
 print(case['name'],r['error'],failures)
report={'scope':__doc__,'runtime':'LiteSVM with signature verification and blockhash checks enabled; original Mayhem and dependencies; no modified ELF or signer bypass','count':len(rows),'success_count':sum(r['error'] is None for r in rows),'mismatches':mismatches,'original_sha256':p.sha((p.ROOT/'evidence/original/mayhem/deployed.so').read_bytes()),'inputs_sha256':{str(path.relative_to(p.ROOT)):p.sha(path.read_bytes()) for path in [Path(__file__).resolve(),D/'probe_sell.py',D/'crate/src/lib.rs',D/'crate/src/main.rs',p.ROOT/'scripts/pump_trade_fixture.py']},'cases':rows}
(D/'model-original-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['count','success_count','mismatches']}))
raise SystemExit(bool(mismatches))
