#!/usr/bin/env python3
"""Original ELF only, ordinary signed synthetic accounts, local LiteSVM; never RPC.
No authorization is weakened: the owned trader signs, GlobalParams.trader matches it,
and Mayhem itself signs for the real sol-vault PDA during its CPI.
"""
from pathlib import Path
import sys,json,base64,hashlib,struct
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import pump_trade_fixture as f
from solders.clock import Clock
from solders.compute_budget import set_compute_unit_limit
MAY=f.Pubkey.from_string('MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e')
TRADER=f.Keypair.from_seed(hashlib.sha256(b'mayhem-sell-static-followup-owned-trader-v1').digest())
assert TRADER.pubkey().is_on_curve()
GLOBAL=f.Pubkey.find_program_address([b'global-params'],MAY)[0]
SOL=f.Pubkey.find_program_address([b'sol-vault'],MAY)[0]
EVENT=f.Pubkey.find_program_address([b'__event_authority'],MAY)[0]
PUMP=f.Pubkey.from_string(f.x['program']);ATA=f.Pubkey.from_string('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL')
CURVE=f.Pubkey.from_string(f.x['accounts']['curve']);PGLOBAL=f.Pubkey.from_string(f.x['accounts']['global'])
INITIAL={k:f.vm.get_account(k) for k in f.msg.account_keys}
sha=lambda b:hashlib.sha256(b).hexdigest()
def snap(a):
 return None if a is None else {'lamports':a.lamports,'owner':str(a.owner),'executable':a.executable,'rent_epoch':a.rent_epoch,'data_base64':base64.b64encode(a.data).decode() if not a.executable else None,'data_sha256':sha(a.data)}
def run(c):
 vm=f.LiteSVM().with_sigverify(True).with_blockhash_check(True).with_log_bytes_limit(None)
 for name,key in [('mayhem',MAY),('pump',PUMP),('pump_fees',f.Pubkey.from_string('pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ'))]:
  vm.add_program_from_file(key,ROOT/f'evidence/original/{name}/deployed.so')
 for name in ['spl_token','spl_token_2022','associated_token']:
  capture=json.loads((ROOT/f'evidence/dependencies/{name}/capture.json').read_text());vm.add_program_from_file(f.Pubkey.from_string(capture['program']),ROOT/f'evidence/dependencies/{name}/deployed.so')
 for key,a in INITIAL.items():
  if a is not None and not a.executable:vm.set_account(key,a)
 vm.set_clock(Clock(100,0,0,0,c.get('now',100)))
 vm.set_account(TRADER.pubkey(),f.Account(10**10,b'',f.Pubkey.default()))
 vm.set_account(SOL,f.Account(10**10,b'',f.Pubkey.default()))
 v3=f.ixs[-1].accounts;mint=v3[1].pubkey;token=v3[3].pubkey
 statekey=f.Pubkey.find_program_address([b'mayhem-state',bytes(mint)],MAY)[0]
 vault=f.Pubkey.find_program_address([bytes(SOL),bytes(token),bytes(mint)],ATA)[0]
 td=bytearray(INITIAL[v3[9].pubkey].data);td[32:64]=bytes(SOL);struct.pack_into('<Q',td,64,c.get('tokens',10**9));vm.set_account(vault,f.Account(10**8,bytes(td),token))
 gd=bytearray(hashlib.sha256(b'account:GlobalParams').digest()[:8]+bytes(310));gd[49:81]=bytes(TRADER.pubkey());gd[81:113]=bytes(TRADER.pubkey());gd[48]=c.get('paused',0)
 for off,val in [(16,c.get('cap',0)),(129,c.get('threshold',0)),(146,c.get('interval',0))]:struct.pack_into('<Q',gd,off,val%(1<<64))
 gd[113:129]=c.get('global_sol',0).to_bytes(16,'little',signed=True)
 vm.set_account(GLOBAL,f.Account(10**8,bytes(gd),MAY))
 sd=bytearray(hashlib.sha256(b'account:MayhemState').digest()[:8]+bytes(162));sd[24:56]=bytes(mint);struct.pack_into('<q',sd,16,c.get('deadline',10000));struct.pack_into('<Q',sd,89,c.get('last',0)%(1<<64));sd[97]=c.get('status',1)
 sd[56:72]=c.get('state_sol',0).to_bytes(16,'little',signed=True);sd[72:88]=c.get('state_tokens',0).to_bytes(16,'little',signed=True)
 vm.set_account(statekey,f.Account(10**8,bytes(sd),MAY))
 curve=bytearray(INITIAL[CURVE].data);curve[81]=1
 for off,val in c.get('curve_u64',[]):struct.pack_into('<Q',curve,off,val)
 for off,val in c.get('curve_bytes',[]):curve[off]=val
 vm.set_account(CURVE,f.Account(INITIAL[CURVE].lamports,bytes(curve),PUMP))
 creator=f.Pubkey(curve[49:81]);creatorvault=f.Pubkey.find_program_address([b'creator-vault',bytes(creator)],PUMP)[0]
 fee=f.Pubkey(INITIAL[PGLOBAL].data[483:515]);pump_event=f.Pubkey.find_program_address([b'__event_authority'],PUMP)[0]
 v2=f.Pubkey.find_program_address([b'bonding-curve-v2',bytes(mint)],PUMP if c.get('wrong_v2_program') else MAY)[0]
 vm.set_account(v2,f.Account(10**7,bytes(curve),PUMP))
 for key in [creatorvault,fee]:
  if vm.get_account(key) is None:vm.set_account(key,f.Account(10**7,b'',f.Pubkey.default()))
 keys=[TRADER.pubkey(),GLOBAL,statekey,SOL,mint,vault,token,f.Pubkey.default(),PGLOBAL,CURVE,fee,v3[6].pubkey,creatorvault,pump_event,PUMP,f.Pubkey.from_string(f.x['accounts']['fee_config']),f.Pubkey.from_string('pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ'),EVENT,MAY,v2,v3[13].pubkey]
 writable={0,1,2,3,5,9,10,11,12,20};metas=[f.AccountMeta(k,i==0,i in writable) for i,k in enumerate(keys)]
 vt,vs,rt,rs=struct.unpack_from('<QQQQ',curve,8)
 reference=c.get('reference',vs*10**15//vt if vt else 0)
 payload=hashlib.sha256(b'global:sell').digest()[:8]+reference.to_bytes(16,'little')+struct.pack('<HH',c.get('tolerance',2400),c.get('retained',9000))
 tx=f.Transaction.new_signed_with_payer([set_compute_unit_limit(1400000),f.Instruction(MAY,payload,metas)],TRADER.pubkey(),[TRADER],vm.latest_blockhash())
 assert tx.verify_with_results()==[True]
 before={str(k):snap(vm.get_account(k)) for k in keys}
 result=vm.send_transaction(tx);failed=isinstance(result,f.FailedTransactionMetadata);meta=result.meta() if failed else result
 assert tx.verify_with_results()==[True]
 after={str(k):snap(vm.get_account(k)) for k in keys}
 return {'case':c,'error':str(result.err()) if failed else None,'signature':str(tx.signatures[0]),'signature_verified':True,'transaction_base64':base64.b64encode(bytes(tx)).decode(),'synthetic_trader':str(TRADER.pubkey()),'inputs':{'curve':[vt,vs,rt,rs],'reference':reference},'before':before,'after':after,'metadata':json.loads(meta.to_json())}
if __name__=='__main__':
 cases=[{'name':'base'}]
 rows=[run(c) for c in cases]
 out=Path(__file__).with_name('original-synthetic-probes.json');out.write_text(json.dumps({'scope':__doc__,'original_sha256':sha((ROOT/'evidence/original/mayhem/deployed.so').read_bytes()),'cases':rows},indent=2)+'\n')
 for r in rows:
  print(r['case']['name'],r['error']);print('\n'.join(r['metadata']['logs']))
