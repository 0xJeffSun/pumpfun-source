#!/usr/bin/env python3
"""Independently compare the Rust draft's event/post functions to saved original executions."""
from pathlib import Path
import json,base64,struct,subprocess,hashlib
D=Path(__file__).resolve().parent;B=D/'crate/target/debug/mayhem-sell-static-draft'
def event_fields(raw):
 assert len(raw)==303 and raw[:9].hex()=='31487b2d6e40b08501'
 args=[raw[9:41].hex(),raw[41:73].hex()];off=73
 for width,signed in [(8,False)]*4+[(16,True)]*2+[(8,False)]*2+[(16,True)]+[(8,True)]*2+[(8,False)]*2+[(4,False),(2,False)]:
  args.append(str(int.from_bytes(raw[off:off+width],'little',signed=signed)));off+=width
 return args
checks=[]
source=D/'model-original-validation.json';r=json.loads(source.read_text())
for row in r['cases']:
 if row['error'] is not None:continue
 raw=next(base64.b64decode(l[14:]) for l in row['metadata']['logs'] if l.startswith('Program data: ') and base64.b64decode(l[14:])[:8].hex()=='31487b2d6e40b085')
 args=event_fields(raw);actual=bytes.fromhex(subprocess.check_output([str(B),'event',*args],text=True).strip());assert actual==raw
 case=row['case'];sol=int(args[2]);tokens=int(args[3]);post=subprocess.check_output([str(B),'post',str(case.get('global_sol',0)),str(case.get('state_sol',0)),str(case.get('state_tokens',0)),'0',str(sol),str(tokens),'0'],text=True).strip()
 expected=f'{case.get("global_sol",0)-sol} {case.get("state_sol",0)-sol} {case.get("state_tokens",0)+tokens}';assert post==expected
 checks.append({'source_case':case['name'],'signature':row['signature'],'event_sha256':hashlib.sha256(raw).hexdigest(),'complete_rust_encoding_matches':True,'rust_post_values_match_original':True})
historical=[]
for row in json.loads((D/'historical-trade-inventory.json').read_text())['transactions']:
 if row['instruction']!='sell':continue
 event=next(bytes.fromhex(i['data_hex'])[8:] for i in row['inner'] if i['program']=='MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e')
 actual=bytes.fromhex(subprocess.check_output([str(B),'event',*event_fields(event)],text=True).strip());assert actual==event
 historical.append({'signature':row['signature'],'event_sha256':hashlib.sha256(event).hexdigest(),'complete_rust_encoding_matches':True})
report={'scope':__doc__,'original_synthetic_receipt_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'synthetic_successes':checks,'historical_sell_events':historical,'mismatches':[]}
(D/'event-post-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'synthetic_successes':len(checks),'historical_sell_events':len(historical),'mismatches':[]}))
