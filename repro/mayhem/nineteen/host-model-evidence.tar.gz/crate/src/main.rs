use mayhem_sell_static_draft::*;
fn main() {
 let a:Vec<String>=std::env::args().skip(1).collect();
 if a.first().map(String::as_str)==Some("event") {
  assert_eq!(a.len(),18);
  let key=|i:usize|-> [u8;32] { let v:Vec<u8>=(0..a[i].len()).step_by(2).map(|n|u8::from_str_radix(&a[i][n..n+2],16).unwrap()).collect();v.try_into().unwrap() };
  let n=|i:usize|a[i].parse::<u64>().unwrap();
  let e=SellEvent{sol_vault:key(1),mint:key(2),sol_amount:n(3),token_amount:n(4),sol_vault_balance:n(5),token_vault_balance:n(6),state_sol_deployed:a[7].parse().unwrap(),state_token_net:a[8].parse().unwrap(),virtual_sol:n(9),virtual_tokens:n(10),global_sol_deployed:a[11].parse().unwrap(),timestamp:a[12].parse().unwrap(),end_timestamp:a[13].parse().unwrap(),real_sol:n(14),real_tokens:n(15),version:n(16) as u32,retained_reserve_bps:n(17) as u16};
  for byte in e.encode(){print!("{byte:02x}");}println!();return;
 }
 if a.first().map(String::as_str)==Some("post") {
  assert_eq!(a.len(),8);
  let mut g=Global{paused:false,trade_interval:0,initial_sol_threshold:0,sol_output_cap:0,sol_deployed:a[1].parse().unwrap()};
  let mut s=State{last_trade_timestamp:0,end_timestamp:0,status:0,sol_deployed:a[2].parse().unwrap(),token_net:a[3].parse().unwrap()};
  let result=post_cpi(&mut g,&mut s,a[4].parse().unwrap(),a[5].parse().unwrap(),a[6].parse().unwrap(),a[7].parse().unwrap());
  match result {Ok(_)=>println!("{} {} {}",g.sol_deployed,s.sol_deployed,s.token_net),Err(Failure::Custom(c))=>println!("error {c}"),Err(Failure::Panic(p))=>println!("panic {p}")};return;
 }
 assert_eq!(a.len(),14);
 let n=|i:usize|a[i].parse::<u64>().unwrap();
 let g=Global{paused:n(0)!=0,trade_interval:a[2].parse().unwrap(),initial_sol_threshold:n(5),sol_output_cap:n(10),sol_deployed:0};
 let mut s=State{last_trade_timestamp:a[1].parse().unwrap(),end_timestamp:a[3].parse().unwrap(),status:n(4) as u8,sol_deployed:0,token_net:0};
 let c=Curve{virtual_tokens:n(6),virtual_sol:n(7),real_sol:n(8)};
 let out=guards(&g,&mut s,c.real_sol,100).and_then(|_|quote(a[11].parse().unwrap(),n(12) as u16,n(13) as u16,c,n(9),g.sol_output_cap));
 match out {
  Ok(q)=>println!("{{\"token_input\":{},\"minimum_sol_output\":{},\"target_sol_output\":{},\"last\":{},\"status\":{}}}",q.token_input,q.minimum_sol_output,q.target_sol_output,s.last_trade_timestamp,s.status),
  Err(Failure::Custom(code))=>println!("{{\"error\":{code}}}"),
  Err(Failure::Panic(reason))=>println!("{{\"panic\":{reason:?}}}")
 }
}
