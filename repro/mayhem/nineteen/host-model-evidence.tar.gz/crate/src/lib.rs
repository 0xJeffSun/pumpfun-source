//! Partial host-side model recovered from the original ELF. No Solana entrypoint.
//! Account parsing and CPI execution are deliberately outside this draft.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Failure { Custom(u32), Panic(&'static str) }
type Result<T> = core::result::Result<T, Failure>;
const MATH: Failure = Failure::Custom(6002);
#[derive(Debug, Clone, Copy)]
pub struct Global {
    pub paused: bool,                 // Borsh 48; original memory 0xf5
    pub trade_interval: i64,          // Borsh 146; original memory 0x90
    pub initial_sol_threshold: u64,   // Borsh 129; original memory 0x80
    pub sol_output_cap: u64,          // Borsh 16; original memory 0x60
    pub sol_deployed: i128,           // Borsh 113; original memory 0x40
}
#[derive(Debug, Clone, Copy)]
pub struct State {
    pub end_timestamp: i64,           // Borsh 16; original memory 0x48
    pub last_trade_timestamp: i64,    // Borsh 89; original memory 0x50
    pub status: u8,                   // Borsh 97; original memory 0x60
    pub sol_deployed: i128,           // Borsh 56; original memory 0x20
    pub token_net: i128,              // Borsh 72; original memory 0x30
}
#[derive(Debug, Clone, Copy)]
pub struct Curve { pub virtual_tokens: u64, pub virtual_sol: u64, pub real_sol: u64 }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote { pub token_input: u64, pub minimum_sol_output: u64, pub target_sol_output: u64 }
/// 0x2dd18 and 0x2e1c0, legacy native-SOL branch. Caller rollback is required on error.
pub fn guards(global: &Global, state: &mut State, real_sol: u64, now: i64) -> Result<()> {
    if global.paused { return Err(Failure::Custom(6000)); }
    if state.last_trade_timestamp != 0 && global.trade_interval != 0 {
        let next = state.last_trade_timestamp.checked_add(global.trade_interval)
            .ok_or(Failure::Panic("signed interval addition overflow"))?;
        if now < next { return Err(Failure::Custom(6015)); }
    }
    state.last_trade_timestamp = now;
    if now >= state.end_timestamp { return Err(Failure::Custom(6004)); }
    if state.status != 1 {
        if real_sol < global.initial_sol_threshold { return Err(Failure::Custom(6003)); }
        state.status = 1;
    }
    Ok(())
}
/// 0x1f300..0x1fc18. Field names describe arithmetic, not recovered historical API names.
pub fn quote(reference: u128, tolerance_bps: u16, retained_reserve_bps: u16,
             c: Curve, vault_tokens: u64, global_cap: u64) -> Result<Quote> {
    if c.virtual_tokens == 0 { return Err(MATH); }
    let scaled = reference.checked_mul(tolerance_bps as u128).ok_or(MATH)?;
    let price = c.virtual_sol as u128 * 1_000_000_000_000_000u128 / c.virtual_tokens as u128;
    let tolerance = scaled / 10_000;
    let lower = reference.checked_sub(tolerance).ok_or(MATH)?;
    let upper = reference.checked_add(tolerance).ok_or(MATH)?;
    if price < lower || price > upper { return Err(Failure::Custom(6012)); }
    let retained = 10_000u16.checked_sub(retained_reserve_bps)
        .ok_or(Failure::Panic("u16 reserve subtraction overflow"))?;
    let available = c.virtual_sol as u128 * vault_tokens as u128 /
        (c.virtual_tokens as u128 + vault_tokens as u128);
    let mut output = u64::try_from(available).map_err(|_| Failure::Panic("u128 conversion"))?;
    if global_cap != 0 { output = output.min(global_cap); }
    output = output.min((c.real_sol as u128 * retained as u128 / 10_000) as u64);
    let denominator = c.virtual_sol.checked_sub(output)
        .filter(|n| *n != 0).ok_or(Failure::Panic("inverse quote denominator"))?;
    let input = output as u128 * c.virtual_tokens as u128 / denominator as u128;
    Ok(Quote { token_input: u64::try_from(input).map_err(|_| Failure::Panic("u128 conversion"))?,
        minimum_sol_output: output.saturating_sub(1), target_sol_output: output })
}
/// 0x21a50..0x21b08 and 0x2cf88. Deltas come from post-CPI reloads, not quoted output.
/// The caller must use transactional rollback for any error, including earlier successful writes.
pub fn post_cpi(global: &mut Global, state: &mut State, sol_before: u64, sol_after: u64,
                tokens_before: u64, tokens_after: u64) -> Result<(u64,u64)> {
    let sol = sol_after.checked_sub(sol_before).ok_or(Failure::Panic("lamport delta underflow"))?;
    let tokens = tokens_before.checked_sub(tokens_after).ok_or(Failure::Panic("token delta underflow"))?;
    global.sol_deployed = global.sol_deployed.checked_sub(sol as i128).ok_or(MATH)?;
    state.sol_deployed = state.sol_deployed.checked_sub(sol as i128).ok_or(MATH)?;
    state.token_net = state.token_net.checked_add(tokens as i128).ok_or(MATH)?;
    Ok((sol,tokens))
}
/// Legacy sell's CPI data. Account order is recorded separately; signer seeds must be
/// the real Mayhem [b"sol-vault", bump], never an outer signer flag.
pub fn pump_sell_data(q: Quote) -> [u8;24] {
    let mut data=[0u8;24];data[..8].copy_from_slice(&[0x33,0xe6,0x85,0xa4,0x01,0x7f,0x83,0xad]);
    data[8..16].copy_from_slice(&q.token_input.to_le_bytes());
    data[16..24].copy_from_slice(&q.minimum_sol_output.to_le_bytes());data
}

/// Complete legacy-sell event layout at 0x5b700. Historical Rust field names are
/// unavailable. The repeated quote values are present in the original event.
#[derive(Debug, Clone)]
pub struct SellEvent {
    pub sol_vault: [u8;32], pub mint: [u8;32],
    pub sol_amount: u64, pub token_amount: u64,
    pub sol_vault_balance: u64, pub token_vault_balance: u64,
    pub state_sol_deployed: i128, pub state_token_net: i128,
    pub virtual_sol: u64, pub virtual_tokens: u64, pub global_sol_deployed: i128,
    pub timestamp: i64, pub end_timestamp: i64, pub real_sol: u64, pub real_tokens: u64,
    pub version: u32, pub retained_reserve_bps: u16,
}
impl SellEvent {
    pub fn encode(&self) -> Vec<u8> {
        let mut out=Vec::with_capacity(303);
        macro_rules! put {($v:expr)=>{out.extend_from_slice(&$v.to_le_bytes())}}
        out.extend_from_slice(&[0x31,0x48,0x7b,0x2d,0x6e,0x40,0xb0,0x85]);
        out.push(1);out.extend_from_slice(&self.sol_vault);out.extend_from_slice(&self.mint);
        put!(self.sol_amount);put!(self.token_amount);put!(self.sol_vault_balance);put!(self.token_vault_balance);
        put!(self.state_sol_deployed);put!(self.state_token_net);put!(self.virtual_sol);put!(self.virtual_tokens);
        put!(self.global_sol_deployed);put!(self.timestamp);put!(self.end_timestamp);put!(self.real_sol);put!(self.real_tokens);
        put!(self.version);put!(self.retained_reserve_bps);
        put!(self.sol_amount);put!(self.sol_vault_balance);put!(self.state_sol_deployed);
        put!(self.virtual_sol);put!(self.global_sol_deployed);put!(self.real_sol);
        out.extend_from_slice(&[0u8;32]);out
    }
}
