# Legacy Mayhem sell: executable host model and original-runtime evidence

The isolated crate now recovers legacy sell's guard logic, price tolerance and
amount calculation, post-CPI signed accounting, Pump sell payload, and complete
303-byte event encoding. It is a host-side model without a Solana entrypoint.
No nineteenth Mayhem handler or candidate-byte equivalence is claimed.

The original program completed 26 successful sells across 52 normally signed
synthetic local transactions. All 52 cases matched the model's scoped checks:
35 exact Pump CPI payload comparisons, 26 state and event comparisons, 13 guard
or quote errors, three expected panics, three post-CPI arithmetic overflows, and
one account-seed failure. Every failed transaction rolled back business state.
The Rust event encoder also reproduces all eight captured historical sell events.

## Authorization and fixture scope

`probe_sell.py` uses an ordinary deterministic **test-only** trader Keypair. Its
pubkey is the synthetic GlobalParams.trader. LiteSVM verifies signatures and
blockhashes; every stored transaction independently verifies. Mayhem derives the
real `sol-vault` PDA signature for its Pump CPI. The unmodified captured Mayhem,
Pump, Pump Fees, Token, Token2022 and ATA ELFs are loaded normally. There is no
RPC, live key, live account mutation, signer bypass, initializer experiment, or
patched executable.

The account bytes combine an existing accepted Pump synthetic fixture with new
explicit synthetic Mayhem configuration, state and vault balances. They are not
historical pre-state or evidence of control over any live configured trader.
`validation-inputs.json` preserves dependency, fixture and tool hashes. All work
is isolated here; published Mayhem18 and central source/status remain unchanged.

## Recovered guards and codec mapping

`codec-offsets.json` maps the original serializers to existing account codecs.
The common native-SOL path performs these operations in order:

1. `GlobalParams.paused` (serialized 48) returns 6000 if true.
2. If prior trade time (MayhemState 89) and interval (GlobalParams 146) are
   nonzero, signed checked addition determines the next time. Earlier execution
   returns 6015; signed addition overflow panics. On success it stores Clock time.
3. At or after MayhemState's end timestamp (16), return 6004.
4. Status 1 skips the initial reserve gate. Other decoded statuses compare real
   SOL reserves against GlobalParams 129; insufficient reserves return 6003,
   otherwise status becomes 1. Synthetic status 2 with an unexpired deadline
   follows this same branch; no live reachability claim is made.

The observed `bonding-curve-v2` account is derived with
`[b"bonding-curve-v2", mint]` under **Mayhem's program ID**. Supplying the Pump-derived
PDA returns ConstraintSeeds/2006. This rule comes from 0x59af0..0x59bd0 and is
confirmed by the retained negative/positive fixture pair. Other parser constraints
still require a complete independent reconstruction before an executable candidate
can be treated as equivalent.

## Recovered quote calculation

The 20-byte payload is `reference: u128`, `tolerance_bps: u16`,
`retained_reserve_bps: u16`, using descriptive names rather than claiming original
API names. The same earlier evidence preserves the outer discriminators and CPI
account order.

- Compute `price = virtual_sol * 10^15 / virtual_tokens` with floor division.
- Compute `delta = checked(reference * tolerance_bps) / 10000`; require the price
  to fall inclusively within checked `[reference - delta, reference + delta]`.
  Arithmetic failure returns 6002; an out-of-band price returns 6012.
- Compute the maximum SOL output from all vault tokens with integer constant
  product arithmetic. A nonzero GlobalParams cap at serialized 16 limits it.
- Limit output again to `real_sol * (10000 - retained_reserve_bps) / 10000`.
  A reserve value above 10000 panics on subtraction.
- Invert that output to `token_input = output * virtual_tokens /
  (virtual_sol - output)`, rounded down. Pump receives that input and
  `minimum_sol_output = output.saturating_sub(1)`.

All 35 reached Pump CPI payloads matched exactly, including output cap and rounding
boundaries. Zero-token results reach Pump, which returns its own zero-amount error;
this is not a Mayhem preflight rejection.

## Recovered post-CPI accounting and event

Mayhem reloads the token vault and bonding curve, then obtains actual deltas from
SOL vault lamports and token vault balance. It subtracts received SOL from both
GlobalParams.sol_deployed (113) and MayhemState.field_56 (56), and adds tokens sold
to MayhemState.field_72 (72), using checked signed i128 arithmetic. Overflow returns
6002. The counters can be negative; names other than the existing known
GlobalParams field are descriptive.

The full event discriminator is `31487b2d6e40b085`. Its 295-byte body contains the
sell tag, vault and mint, actual amounts, post balances, signed counters, post
curve reserves, time/deadline, version, reserve parameter, repeated native-quote
fields, and a zero quote mint. Both the log event and signed event CPI contain the
same bytes. The Rust encoder matches all 26 successful synthetic executions and
all eight preserved historical sell events, including negative signed counters.

## Verification and next implementation boundary

Run from the repository root:

```sh
cargo build --offline --manifest-path work/mayhem-trade-followup/crate/Cargo.toml
python3 work/mayhem-trade-followup/validate_model.py
python3 work/mayhem-trade-followup/validate_event_and_post.py
python3 work/mayhem-trade-followup/extract_static.py
```

`model-original-validation.json` contains each original signed transaction,
complete before/after account snapshots, inner CPI, logs and model checks.
`event-post-validation.json` checks the Rust event and post-accounting routines
against those saved executions. The static excerpt generator verifies every
instruction byte against the original ELF and calculates true relative branch
and call targets; old disassembler label text has a 0x120 displacement error.

The remaining candidate work is a faithful full account parser, real Pump CPI
construction/seeds and account exit serialization, then fresh SBF compilation and
original/candidate comparisons. The host model does not test those missing pieces.
Its results should be integrated as research evidence, without increasing the
published implemented-handler count.
