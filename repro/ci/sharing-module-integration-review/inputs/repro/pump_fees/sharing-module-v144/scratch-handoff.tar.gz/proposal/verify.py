#!/usr/bin/env python3
"""Portable source-only and saved-byte proof; never builds or runs program transactions."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,sys,tarfile,tempfile
W=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((W/n).read_text())
assert not any(p.is_symlink()for p in W.rglob('*'))
assert {str(p.relative_to(W)):H(p.read_bytes())for p in W.rglob('*')if p.is_file()and p!=W/'manifest-sha256.json'}==read('manifest-sha256.json')
base=read('before-source-sha256.json');output=read('after-source-sha256.json');assert len(base)==23 and len(output)==26
before={n:(W/'before'/n).read_bytes()for n in base};after={n:(W/'after'/n).read_bytes()for n in output}
assert {n:H(b)for n,b in before.items()}==base and {n:H(b)for n,b in after.items()}==output
move=read('move.json');old=move['from'];new=move['to'];a,z=move['before_bytes'];block=before[old][a:z]
assert H(block)==move['declaration_sha256']and len(block)==move['declaration_bytes']
assert re.fullmatch(rb'#\[account\]\npub struct SharingConfig \{[^}]+\}\n',block)
expected=before.copy();expected[old]=(before[old][:a]+b'pub use crate::instructions::fee_sharing::create_fee_sharing_config::SharingConfig;\n'+before[old][z:]).replace(b'use crate::types::{FeeProgramGlobal, Shareholder};',b'use crate::types::FeeProgramGlobal;')
expected[new]=b'use anchor_lang::prelude::*;\nuse crate::donation::ConfigStatus;\nuse crate::types::Shareholder;\n\n'+block
expected['programs/pump-fees/src/instructions/mod.rs']=b'pub mod fee_sharing;\n'
expected['programs/pump-fees/src/instructions/fee_sharing/mod.rs']=b'pub mod create_fee_sharing_config;\n'
lib='programs/pump-fees/src/lib.rs';assert before[lib].count(b'mod state;\n')==1;expected[lib]=before[lib].replace(b'mod state;\n',b'mod state;\nmod instructions;\n')
assert after==expected and len([n for n in after if before.get(n)!=after[n]])==5
assert not move['explicit_impl_blocks']
for n,b in before.items():
 if n.endswith('.rs'):assert not re.search(rb'\bimpl\b[^{};]*\bSharingConfig\b[^{};]*\{',b)
patch=''.join(''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),after[n].decode().splitlines(True),fromfile='a/'+n if n in before else'/dev/null',tofile='b/'+n))for n in sorted(after));assert patch==(W/'source.patch').read_text()
assert before['Cargo.lock']==after['Cargo.lock']and before['programs/pump-fees/src/contexts.rs']==after['programs/pump-fees/src/contexts.rs']and before['programs/pump-fees/src/state.rs']==after['programs/pump-fees/src/state.rs']
for f in read('framework-provenance.json'):
 archive=W/'framework'/(f['package']+'.crate');assert H(archive.read_bytes())==f['crate_sha256']and f['crate_sha256']in before['Cargo.lock'].decode()
 with tarfile.open(archive)as t:raw=t.extractfile(f['package']+'/'+f['selected_member']).read()
 assert raw==(W/'framework'/f['package']/f['selected_member']).read_bytes()and H(raw)==f['selected_member_sha256']
prov=read('provenance.json');current=read('inputs/current-package-manifest.json')
assert H((W/'inputs/current-package-manifest.json').read_bytes())==prov['baseline_package_manifest_sha256']
for local,original in [('candidate.so','pump_fees_candidate.so'),('symbols.so','symbols.so'),('current-codecs.json','candidate-codecs.json')]:assert H((W/'inputs'/local).read_bytes())==current[original]
assert H((W/'inputs/candidate.so').read_bytes())==prov['baseline_candidate_sha256']and H((W/'inputs/original.so').read_bytes())==prov['original_sha256']
assert prov['build_attempts']==prov['runtime_executions']==0 and not prov['main_source_modified']
with tempfile.TemporaryDirectory()as temp:
 out=Path(temp)/'proof.json';r=subprocess.run([sys.executable,'-B',str(W/'analyze_evidence.py'),'--output',str(out)],cwd=temp,capture_output=True,text=True);assert r.returncode==0,(r.stdout,r.stderr);assert json.loads(out.read_text())==read('proof.json')
print(json.dumps({'verified':True,'before_inputs':23,'after_proposed_inputs':26,'changed_paths':5,'byte_preserved_account_declarations':1,'complete_baseline_static_windows':3,'immediate_call_sites_checked':23,'proposed_source_compiled':False,'proposed_source_runtime_tested':False},indent=2))
