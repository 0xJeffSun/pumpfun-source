from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];P=R/'work/fees-sharing-module-proposal';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(P/'manifest-sha256.json')=='d1e3d9e2a7d3d4bc89af923a0eaa537ef880838df7d89681094cf071254c31c3'
assert not (W/'proposal').exists()and not(W/'source').exists()
shutil.copytree(P,W/'proposal');r=subprocess.run([sys.executable,'-B',str(W/'proposal/verify.py')],cwd=W,capture_output=True,text=True)
(W/'proposal-verification.json').write_text(json.dumps({'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seal_sha256':H(P/'manifest-sha256.json')},indent=2)+'\n');assert r.returncode==0
before=json.loads((P/'before-source-sha256.json').read_text());after=json.loads((P/'after-source-sha256.json').read_text());assert len(before)==23 and len(after)==26
assert all(H(R/n)==h for n,h in before.items())
shutil.copytree(P/'after',W/'source');shutil.copyfile(P/'before-source-sha256.json',W/'baseline-source-sha256.json');shutil.copyfile(P/'after-source-sha256.json',W/'source-sha256.json');shutil.copyfile(P/'source.patch',W/'source.patch')
for name,root,files in [('baseline-source-snapshot.tar.gz',P/'before',before),('source-snapshot.tar.gz',W/'source',after)]:
 with tarfile.open(W/name,'w:gz')as t:
  for n,h in files.items():assert H(root/n)==h;t.add(root/n,arcname=n,recursive=False)
print('PREPARED exact 26-input proposal; current main 23 inputs unchanged')
