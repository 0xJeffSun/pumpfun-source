# SharingConfig placement: one fixed scratch build

This candidate moves the complete unchanged SharingConfig account declaration from donation.rs to the original recorded filename, `programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs`. The public donation reexport preserves every existing consumer. ConfigStatus, Shareholder, handlers and contexts remain unchanged. The five-path patch and 23-before/26-after input maps exactly reproduce the approved sealed proposal retained under `proposal/`.

No main source is changed. Candidate SHA-256 is `8cce74a5191b286eaa10af59c02c9ee16d3853be214c5e9b1132e50bba15ef87`, 768,104 bytes. The baseline is the accepted 768,024-byte state-module candidate `d5b8f885…`. There was one isolated source build, using the established v1.44 compiler and unchanged SDK's v1.52 stripping phase. The 26 actual source inputs, four build helpers, 53 SDK sources, isolated build target/SDK/rustup locations, before/after tool hashes and logs are retained. All shared allocated ELF payloads, including `.text`, are unchanged by stripping. This is file/phase provenance, not a complete process invocation-hash trace or unique historical pipeline proof.

The prebuild seal is `8c1357c624ffd64d09862638d8be0bda94b770d58f3f67af6b64843ef1367e8c`. The source patch, snapshots, proposal and launch metadata were fixed before compilation. No padding, line alignment, compiler/flag/dependency variants or new fixtures were used. The immutable proposal seal remains `d1e3d9e2a7d3d4bc89af923a0eaa537ef880838df7d89681094cf071254c31c3`. Its retained scripting correction is historical; this build required no source or compilation retry.

## Static result and remaining deltas

All five complete checked codecs now point to their exact original filenames and account-name literals. Their normalized bodies differ only at historical line immediate +528. SharingConfig uses natural attribute line 5 versus original 37; the other four retain natural lines 3, 6, 9 and 12 versus original 50, 113, 135 and 154. All 35 immediate calls resolve through signed operands to complete normalized/relocation-matching target bodies. This is a bounded body and literal result, not raw-code or unrestricted descendant/data equivalence.

The fresh SharingConfig closure separately checks its full 744-byte checked decoder, 1,472-byte unchecked decoder and 1,024-byte Account::try_from wrapper. The latter two full bodies match normalized original windows. Their 23 immediate call sites retain complete target matches except the checked codec's known line difference. These 23 sites overlap the wider 35-site codec check and are not additional unique functions. Every relocated pointer is inventoried; only the filename/account-name literal extents are established. Other pointer objects and arbitrary descendants remain unresolved.

The larger donation caller remains unproven: its current named body is 10,576 bytes, while the second original incoming caller window is 13,800 bytes. No offset-based whole-body pairing is claimed. Stripped original extents are inferred from entry references, not recovered original debug symbols.

The accepted inline initializer handler/parser/wrapper, social exit and six Pubkey helper windows remain supported: ten complete bodies, 26 direct calls and five known literal extents. The four state.rs account codec filename bindings are retained. The original complete ELF still differs: 948,944 versus 768,104 bytes, 419,928 differing shared positions, first difference at byte 24 and length difference −180,840. Difference counts are layout-sensitive and are not semantic coverage percentages.

## Fresh unchanged runtime results

All 17,441 existing comparison receipts passed, plus the separate ten-step donation sequence. The 18-suite aggregate contributes 17,331 comparisons; 69 focused comparisons repeat existing inputs. No new unique cases or handlers are claimed. Each saved receipt binds this candidate, the actual scratch source/build hashes, and the unchanged 46 harness-origin files and 18 runtime inputs. Only orchestration paths, source count and completion bookkeeping were adapted; the harness/fixture bytes are unchanged.

The unchanged saved-evidence verifier rechecks exact external-codec AnchorError logs and 8,644 encoded transaction fields with 17,204 signatures. These counts are distinct from total executions and unique transactions. Two genuine historical FeeConfig initializer messages retain original signed bytes and signatures, runtime signature verification and a stale-blockhash rejection control; they are not historical FeeProgramGlobal initializer messages. There is no signer bypass, network transaction submission or transfer of old runtime receipts to a different binary.

## Portable checks

Copy this full directory anywhere and run `python3 -B verify.py --runtime`. This verifies the seal, exact approved source move, prebuild/source/helper/harness/SDK archives, actual raw comparisons, fresh complete static windows, all receipt/build bindings and saved signatures. Python with `solders` is required for `--runtime`; the default checks do not require it. Neither command compiles code or replays program transactions.

`inspect_sharing_closure.py.portability.patch` records the only change to the executed closure inspector: input locations now reference the adjacent candidate and symbols. The original executed inspector is retained. Recorded work paths are provenance only. The 44 canonical published harness copies are mapped separately for future integration; this portable package carries all actual 46 origins itself.

This is a reviewable scratch result. Main promotion, a clean main identity build, and central status/CI integration require the parent's next decision. Bounded checks do not establish exhaustive behavior, complete security coverage, deployment readiness or original historical source identity.
