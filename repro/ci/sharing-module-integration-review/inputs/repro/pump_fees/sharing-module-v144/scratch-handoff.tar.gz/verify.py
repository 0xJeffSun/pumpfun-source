#!/usr/bin/env python3
"""Portable saved-byte verifier; --runtime verifies saved signatures, never replays programs."""
from pathlib import Path
import argparse,gzip,hashlib,json,subprocess,sys,tarfile,tempfile
P=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((P/n).read_text())
a=argparse.ArgumentParser();a.add_argument('--runtime',action='store_true');args=a.parse_args()
assert not any(p.is_symlink()for p in P.rglob('*'))
manifest=read('manifest-sha256.json');assert {str(p.relative_to(P)):H(p.read_bytes())for p in P.rglob('*')if p.is_file()and p!=P/'manifest-sha256.json'}==manifest

def archive(n,expected):
 with tarfile.open(P/n)as t:
  members=t.getmembers();assert all(m.isfile()and not Path(m.name).is_absolute()and'..'not in Path(m.name).parts for m in members)
  data={m.name:t.extractfile(m).read()for m in members};assert len(data)==len(members)
 assert {n:H(b)for n,b in data.items()}==expected,n
 return data
source=read('source-sha256.json');base=read('baseline-source-sha256.json');assert len(source)==26 and len(base)==23
before=archive('baseline-source-snapshot.tar.gz',base);after=archive('source-snapshot.tar.gz',source)
assert base==read('proposal/before-source-sha256.json')and source==read('proposal/after-source-sha256.json')
for n,b in before.items():assert b==(P/'proposal/before'/n).read_bytes()
for n,b in after.items():assert b==(P/'proposal/after'/n).read_bytes()
assert (P/'source.patch').read_bytes()==(P/'proposal/source.patch').read_bytes()
pre=archive('prebuild-snapshot.tar.gz',read('prebuild-manifest-sha256.json'));assert pre['source-snapshot.tar.gz']==(P/'source-snapshot.tar.gz').read_bytes()and pre['source.patch']==(P/'source.patch').read_bytes()
archive('build-helper-snapshot.tar.gz',read('build-helper-sha256.json'));assert len(read('build-helper-sha256.json'))==4
archive('harness-snapshot.tar.gz',read('harness-source-sha256.json'));assert len(read('harness-source-sha256.json'))==46
runtime=read('runtime-inputs.json');assert len(runtime)==18
for n,h in runtime.items():assert H((P/'runtime'/n).read_bytes())==h
build=read('build-comparison.json');attempt=read('build-attempt.json');prefix='work/fees-sharing-module-recovery/source/'
assert len(build['source_sha256'])==26 and {n.removeprefix(prefix):h for n,h in build['source_sha256'].items()}==source
assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256']
assert H(gzip.decompress((P/'build.log.gz').read_bytes()))==build['build_log_sha256']==attempt['build_log_sha256']
C=(P/'pump_fees_candidate.so').read_bytes();O=(P/'proposal/inputs/original.so').read_bytes();prov=read('provenance.json')
assert H(C)==prov['candidate_sha256']=='8cce74a5191b286eaa10af59c02c9ee16d3853be214c5e9b1132e50bba15ef87'and len(C)==prov['candidate_bytes']==768104 and H(O)==prov['original_sha256']
comparison={'original_bytes':len(O),'candidate_bytes':len(C),'original_sha256':H(O),'candidate_sha256':H(C),'full_byte_equality':O==C,'first_difference':next((i for i,(a,b)in enumerate(zip(O,C))if a!=b),None),'different_positions_in_shared_length':sum(a!=b for a,b in zip(O,C)),'length_difference':len(C)-len(O)}
assert comparison==build['comparison']and prov['source_build_attempts']==1 and not prov['main_source_modified']
assert H((P/'proposal/manifest-sha256.json').read_bytes())==prov['sealed_prebuild_proposal_sha256']=='d1e3d9e2a7d3d4bc89af923a0eaa537ef880838df7d89681094cf071254c31c3'
sdk=archive('sbf-sdk-snapshot.tar.gz',build['sdk_source_sha256']);assert len(sdk)==53
phase=read('tool-phase-provenance.json');assert phase['compile']['requested_tools_version']=='v1.44'and phase['compile']['tool_hashes_before']==phase['compile']['tool_hashes_after']=={n:v['sha256']for n,v in phase['compile']['tool_files'].items()}
assert phase['compile']['unstripped_sha256']==H((P/'symbols.so').read_bytes())and phase['strip']['candidate_sha256']==H(C)
assert phase['strip']['sdk_marker']=='platform-tools-v1.52.md'and phase['strip']['file_sha256_before']==phase['strip']['file_sha256_after']=='12415dc01e08e4f606a1a4eac8c197d560c7883161d266312c821bf5db7bf8be'
for n,h in phase['phase_source_sha256'].items():assert H(sdk[n])==h
from elf_reader import Elf
c=Elf(P/'pump_fees_candidate.so');s=Elf(P/'symbols.so')
for n in set(c.secs)&set(s.secs):
 x,y=c.secs[n],s.secs[n]
 if x[2]&2:assert c.b[x[4]:x[4]+x[5]]==s.b[y[4]:y[4]+y[5]],n
with tempfile.TemporaryDirectory()as temp:
 temp=Path(temp)
 def run(script,argv):
  r=subprocess.run([sys.executable,'-B',str(P/script),*map(str,argv)],cwd=temp,capture_output=True,text=True);assert r.returncode==0,(script,r.stdout,r.stderr);return r
 run('proposal/verify.py',[])
 output=temp/'codecs.json';run('inspect_codecs.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--output',output]);assert json.loads(output.read_text())==read('candidate-codecs.json')
 output=temp/'retained.json';run('verify_retained_static.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--baseline-symbols',P/'accepted-inline-symbols.so','--gate',P/'accepted-inline-static-gate.json','--output',output]);assert json.loads(output.read_text())==read('retained-static-gate.json')
 output=temp/'closure.json';run('inspect_sharing_closure.py',['--output',output]);assert json.loads(output.read_text())==read('sharing-closure-proof.json')
 if args.runtime:assert json.loads(run('verify_saved_runtime.py',[]).stdout)==read('runtime-verification-result.json')
rows=read('candidate-codecs.json')['full_codecs'];assert len(rows)==5
for r in rows:
 assert r['original_entry_bounded']and r['relocation_pattern_equal']and r['different_slots']==[528]and all(x['equal']for x in r['literal_spans'])
 assert all(x['original_entry_bounded']and x['normalized_equal']and x['relocation_pattern_equal']for x in r['calls'])
inputs=read('frozen-runner-inputs.json');assert inputs['source_sha256']==source and inputs['harness_sha256']==read('harness-source-sha256.json')and inputs['runtime_sha256']==runtime and inputs['runner_sha256']==H((P/'run_regressions.py').read_bytes())
bindings=read('receipt-build-bindings.json');assert len(bindings)==10
for row in bindings:
 encoded=(P/row['saved_report']).read_bytes();raw=gzip.decompress(encoded);d=json.loads(raw)
 assert H(encoded)==row['saved_report_sha256']and H(raw)==row['raw_report_sha256']==row['report_sha256']
 assert d['candidate_sha256']==H(C)and d['original_sha256']==H(O)and not d['mismatches']
 assert row['executed_candidate_sha256']==H(C)and row['actual_source_sha256']==source and row['build_report_sha256']==H((P/'build-comparison.json').read_bytes())and row['returncode']==0 and row['passed']
summary=read('runtime-summary.json');assert summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and summary['source_inputs']==26 and not summary['mismatches']and not summary['orchestration_failures']
print(json.dumps({'verified':True,'sealed_files':len(manifest),'source_inputs':26,'source_filename_matches':5,'whole_original_elf_equal':False,'comparison_receipts':17441,'donation_steps':10,'saved_signature_verifier_rerun':args.runtime,'main_source_changed':False},indent=2))
