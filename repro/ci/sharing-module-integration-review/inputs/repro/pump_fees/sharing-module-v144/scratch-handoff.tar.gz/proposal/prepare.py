from pathlib import Path
import hashlib,json,re,shutil,subprocess,difflib,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];P=R/'repro/pump_fees/state-module-v144';H=lambda b:hashlib.sha256(b).hexdigest()
def save(n,v):(W/n).parent.mkdir(parents=True,exist_ok=True);(W/n).write_text(json.dumps(v,indent=2)+'\n')
assert not (W/'before').exists()and not(W/'after').exists()
source=json.loads((P/'source-sha256.json').read_text());assert len(source)==23
before={n:(R/n).read_bytes()for n in source};assert {n:H(b)for n,b in before.items()}==source
for n,h in json.loads((P/'manifest-sha256.json').read_text()).items():assert H((P/n).read_bytes())==h
old='programs/pump-fees/src/donation.rs';new='programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs'
m=re.search(rb'#\[account\]\npub struct SharingConfig \{[^}]+\}\n',before[old]);assert m
block=m.group();assert block.count(b'\n')==2
# No handwritten inherent/trait implementations for this concrete type exist in the frozen Rust closure.
impls=[]
for n,b in before.items():
 if n.endswith('.rs'):
  impls.extend({'file':n,'text':x.group().decode()}for x in re.finditer(rb'\bimpl\b[^{};]*\bSharingConfig\b[^{};]*\{',b))
assert not impls
reexport=b'pub use crate::instructions::fee_sharing::create_fee_sharing_config::SharingConfig;\n'
after=before.copy();after[old]=before[old][:m.start()]+reexport+before[old][m.end():]
assert after[old].count(b'use crate::types::{FeeProgramGlobal, Shareholder};')==1
after[old]=after[old].replace(b'use crate::types::{FeeProgramGlobal, Shareholder};',b'use crate::types::FeeProgramGlobal;')
after[new]=b'use anchor_lang::prelude::*;\nuse crate::donation::ConfigStatus;\nuse crate::types::Shareholder;\n\n'+block
after['programs/pump-fees/src/instructions/mod.rs']=b'pub mod fee_sharing;\n'
after['programs/pump-fees/src/instructions/fee_sharing/mod.rs']=b'pub mod create_fee_sharing_config;\n'
lib='programs/pump-fees/src/lib.rs';assert before[lib].count(b'mod state;\n')==1;after[lib]=before[lib].replace(b'mod state;\n',b'mod state;\nmod instructions;\n')
patch=''
for n in sorted(after):patch+=''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),after[n].decode().splitlines(True),fromfile='a/'+n if n in before else'/dev/null',tofile='b/'+n))
(W/'source.patch').write_text(patch)
for name,data in [('before',before),('after',after)]:
 for n,b in data.items():p=W/name/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 save(name+'-source-sha256.json',{n:H(b)for n,b in data.items()})
save('move.json',{'type':'SharingConfig','from':old,'to':new,'before_bytes':[m.start(),m.end()],'before_lines':[before[old][:m.start()].count(b'\n')+1,before[old][:m.end()].count(b'\n')],'after_attribute_line':5,'declaration_bytes':len(block),'declaration_sha256':H(block),'explicit_impl_blocks':impls,'natural_line_alignment':False,'changed_paths':[n for n in after if before.get(n)!=after[n]],'unchanged_helper_types':['crate::donation::ConfigStatus','crate::types::Shareholder']})
inputs=W/'inputs';inputs.mkdir()
for src,n in [(P/'pump_fees_candidate.so','candidate.so'),(P/'symbols.so','symbols.so'),(R/'evidence/original/pump_fees/deployed.so','original.so'),(P/'candidate-codecs.json','current-codecs.json'),(P/'manifest-sha256.json','current-package-manifest.json'),(R/'evidence/upstream/pump_fees.json','pump_fees.json')]:shutil.copyfile(src,inputs/n)
shutil.copyfile(R/'work/fees-state-module-recovery/elf_reader.py',W/'elf_reader.py')
registry=R/'work/fees-family-221-trial/cargo-home/registry';framework=[]
for package,checksum,member in [('anchor-attribute-account-0.31.2','b9a9d17a623263f338511b4a849c4accd99be03b84a8f7b9f64d0988a29771c9','src/lib.rs'),('anchor-syn-0.31.2','99f085a93ab107b9ab2ec70be125b17d2c64c05eebf4da52281a16613a588613','src/codegen/program/common.rs')]:
 archive=registry/'cache/index.crates.io-1949cf8c6b5b557f'/(package+'.crate');assert H(archive.read_bytes())==checksum and checksum in before['Cargo.lock'].decode()
 dst=W/'framework'/(package+'.crate');dst.parent.mkdir(exist_ok=True);shutil.copyfile(archive,dst)
 with tarfile.open(archive)as t:raw=t.extractfile(package+'/'+member).read()
 installed=registry/'src/index.crates.io-1949cf8c6b5b557f'/package/member;assert raw==installed.read_bytes();target=W/'framework'/package/member;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 framework.append({'package':package,'crate_sha256':checksum,'selected_member':member,'selected_member_sha256':H(raw),'registry_source':'registry+https://github.com/rust-lang/crates.io-index','checksum_matches_unchanged_Cargo_lock':True,'installed_member_equals_checksum_bound_archive':True})
save('framework-provenance.json',framework)
save('provenance.json',{'scope':'Prebuild-only source-placement proposal; no compilation or runtime execution.','observed_head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip(),'baseline_package':'repro/pump_fees/state-module-v144','baseline_package_manifest_sha256':H((P/'manifest-sha256.json').read_bytes()),'baseline_candidate_sha256':H((inputs/'candidate.so').read_bytes()),'original_sha256':H((inputs/'original.so').read_bytes()),'before_inputs':len(before),'after_proposed_inputs':len(after),'main_source_modified':False,'build_attempts':0,'runtime_executions':0,'baseline_is_published_input_map_not_claim_that_observed_HEAD_contains_current_uncommitted_inputs':True})
print('PREPARED 23 to 26 inputs; five changed/added paths; one byte-preserved declaration')
