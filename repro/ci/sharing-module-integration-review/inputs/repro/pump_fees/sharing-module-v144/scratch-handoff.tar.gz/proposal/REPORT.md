# SharingConfig: prebuild source-placement proposal

A minimal account-declaration move is supported by the original codec's exact filename literal: `programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs`. The proposal is source-only. No compiler, program runtime, new fixture or main-source edit was performed.

The baseline is the accepted state-module package, candidate SHA-256 `d5b8f885942ee0d54519e4330941b5e034cfcdcf271eb286d0b4cc81165bee13`. All 23 actual source/workspace/IDL/documentation inputs match that package. The observed Git HEAD is recorded separately; the input map is the baseline and does not imply that an observed HEAD already contains concurrently promoted files.

## Exact proposed change

The complete `#[account]` SharingConfig declaration is preserved byte-for-byte, including all seven fields, their order, visibility, names and types. It moves from donation.rs into the evidenced file. `move.json` records its exact bytes, line ranges and SHA-256.

The new file imports the unchanged `ConfigStatus` from donation.rs and `Shareholder` from types.rs plus Anchor's prelude. donation.rs publicly reexports the relocated SharingConfig, preserving the existing donation, sharing, sharing_admin and sharing_update access paths and the root donation glob import. Its now-unused Shareholder import is removed. ConfigStatus and Shareholder do not move or change. All handlers, account contexts, constraints and explicit handler calls stay byte-identical.

No handwritten inherent or trait implementation for SharingConfig exists in the frozen Rust inputs. The locked account macro generates serialization, deserialization, discriminator, owner and Clone implementations from the preserved declaration. This proposal neither drops nor manually rewrites any such implementation. The context types' generated exit implementations continue to refer to the same concrete type through the reexport; post-move macro expansion and output remain unverified until compilation.

Five paths change or are added:

- `programs/pump-fees/src/donation.rs`: declaration replaced by a public reexport and unused import removed.
- `programs/pump-fees/src/lib.rs`: adds only `mod instructions;` after `mod state;`.
- `programs/pump-fees/src/instructions/mod.rs`: declares `pub mod fee_sharing;`.
- `programs/pump-fees/src/instructions/fee_sharing/mod.rs`: declares `pub mod create_fee_sharing_config;`.
- `programs/pump-fees/src/instructions/fee_sharing/create_fee_sharing_config.rs`: three necessary imports and the unchanged account declaration.

The proposed source closure has 26 files, up from 23. Cargo.lock, manifests/profile, IDLs, the accepted inline Pump Global context and all four already-moved state.rs accounts remain unchanged. Natural new account-attribute line 5 intentionally differs from original line 37. No source padding, line spoofing, remapping or formatting search is used. The new root module and removed declaration naturally shift some other source coordinates; these effects must remain visible in any later fixed build/regression run.

The file path supports this natural nested module organization. It does not uniquely establish historical module nesting, the historical source prefix, other contents of that file or original compiler configuration. In particular, the create-sharing handler/context stay in sharing.rs because moving them is unnecessary for the evidenced account declaration and is outside this proposal.

## Original bytes, callers and data

All ranges below are ELF file offsets, with exclusive end. `proof.json` rechecks complete raw/normalized windows, relocation patterns, signed call operands and explicit literal spans from the retained binaries.

| Window | Current candidate | Captured original | Result |
|---|---|---|---|
| SharingConfig checked decoder | [152496,153240), 744 bytes | [442944,443688), 744 bytes | Normalized differences only +528 line and +536 filename length; relocation pattern matches. |
| SharingConfig unchecked decoder | [153240,154712), 1,472 bytes | [443688,445160), 1,472 bytes | Complete normalized body and relocation pattern match. |
| Account::try_from caller | [25376,26400), 1,024 bytes | [27096,28120), 1,024 bytes | Complete normalized body and relocation pattern match. |

The checked decoder's +488 relocation reaches original filename bytes [803673,803749), SHA-256 `5c5fe100cbe2ec4a2c051fee697f64c8a66839b59168bedfa7d88df345c8deea`. Current bytes [698576,698610) contain `programs/pump-fees/src/donation.rs`. The +624 account-name literal is `SharingConfig` in both. The line immediate is original 37 versus current 107.

The checked decoder's seven immediate targets all have complete matching normalized bodies and matching inferred extents. Its unchecked target has six immediate calls; those six complete target bodies also match. The Account::try_from wrapper has ten immediate calls: nine complete targets match, and the tenth is the checked SharingConfig decoder with the two source-location differences above. These are 23 call-site checks, not 23 unique functions or a transitive equivalence proof.

There are two direct incoming calls to the checked decoder in each ELF. One is the matched Account::try_from wrapper. The other current call is at 431496 inside the 10,576-byte named create_donation_fee_pda body [425016,435592). The other original call is at 173320 inside inferred entry window [163920,177720), 13,800 bytes. This larger original caller is not asserted equivalent or paired by relative-offset arithmetic. Original entry-window bounds come from direct-call/relocation entries, not original debug symbols.

Every immediate relocated pointer in the three main windows is inventoried with its actual target and containing section. Only the filename/account-name extents are proved here; other rodata, data-relocation objects, indirect function pointers and arbitrary descendant closure remain unresolved. The current normalized matches do not make those objects equivalent.

## Locked macro contract

The actual lock selects anchor-lang 0.31.1 and anchor-attribute-account/anchor-syn 0.31.2. `framework/` retains the checksum-bound official registry archives and selected source members, which were compared with the installed cache bytes. This is existing dependency evidence, not a graph change.

The account macro uses the declared account name to generate the default `account` discriminator and uses `crate::ID` for Owner. Its ordinary account branch derives AnchorSerialize, AnchorDeserialize and Clone and emits AccountSerialize/AccountDeserialize/Discriminator implementations. The selected common discriminator helper hashes `namespace:name`. The unchanged `account:SharingConfig` preimage gives `d84a0900388c5d4b`, matching the public IDL bytes. Moving the Rust module does not change these inputs. Field order/type preservation supports a source-level expectation of unchanged encoding, but compilation and unchanged runtime regression checks are still required before accepting a new executable. Canonical Rust symbol/type paths and generated diagnostics may change.

## Reproduce and next gate

Copy the whole proposal directory anywhere and run `python3 -B verify.py`. It verifies the complete file seal, 23 before/26 after maps, exactly the five-path patch, preserved declaration/dependency/context bytes, checksum-bound macro members and the entire static proof. It does not compile or execute program transactions. A scripting filename initially shadowed Python's standard inspect module; the failed script and correction are preserved under analysis-history with no source/build consequence.

The concrete next prerequisite is parent review of source.patch. Only then would one isolated fixed-recipe build be justified, followed by the original full codec/call/literal comparisons and unchanged existing Fees corpus. No post-move binary or runtime equivalence is claimed by this prebuild package.
