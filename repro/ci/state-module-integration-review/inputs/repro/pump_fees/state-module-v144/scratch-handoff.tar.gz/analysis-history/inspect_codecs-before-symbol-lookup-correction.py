from pathlib import Path
import argparse,hashlib,json,re,struct,sys
sys.dont_write_bytecode=True
from elf_reader import Elf
W=Path(__file__).resolve().parent;R=W.parents[1]
a=argparse.ArgumentParser();a.add_argument('--candidate',type=Path,required=True);a.add_argument('--symbols',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--moved',action='store_true');args=a.parse_args()
C=Elf(args.candidate);S=Elf(args.symbols);O=Elf(W/'lead/evidence/original.so');H=lambda b:hashlib.sha256(b).hexdigest();canonical=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]and C.pattern(C.lo,C.hi-C.lo)==S.pattern(S.lo,S.hi-S.lo)
ranges={v:(O.entries[i+1]if i+1<len(O.entries)else O.hi)-v for i,v in enumerate(O.entries)}
proof=json.loads((W/'lead/evidence/prior-fees-functions/focused-proof.json').read_text());types=['BuybackVault','SocialFeePda','DonationFeePda','FeeProgramGlobal','SharingConfig'];output=[]
def compare(c,o,n):return {'candidate_start':c,'original_start':o,'bytes':n,'raw_equal':C.b[c:c+n]==O.b[o:o+n],'normalized_equal':C.normalized[c:c+n]==O.normalized[o:o+n],'relocation_pattern_equal':C.pattern(c,n)==O.pattern(o,n),'candidate_raw_sha256':H(C.b[c:c+n]),'original_raw_sha256':H(O.b[o:o+n]),'original_entry_bounded':ranges.get(o)==n,'different_slots':[i for i in range(0,n,8)if C.normalized[c+i:c+i+8]!=O.normalized[o+i:o+i+8]]}
for prior in proof['focused']:
 typ=next((x['original'].get('utf8')for x in prior['relocated_data']if x['original'].get('utf8')in types),None)
 if typ is None:continue
 names={canonical(n)for n in prior['names']}
 if args.moved and typ!='SharingConfig':
  names={n.replace('..buyback..','..state..').replace('..social..','..state..').replace('..donation..','..state..').replace('..types..','..state..')for n in names}
 found={(f['start'],f['size'])for f in S.funcs if canonical(f['name'])in names};assert len(found)==1,(typ,found,names)
 c,n=next(iter(found));o=prior['original']['start'];row=compare(c,o,n);row['type']=typ;row['candidate_symbol_size']=n;row['original_prior_size']=prior['original']['bytes']
 calls=[]
 for call in C.callsites(c,n):
  off=call['offset'];target=call['target'];other=O.calls.get(o+off);sizes={f['size']for f in S.funcs if f['start']==target}
  if other is None or len(sizes)!=1: calls.append({'call_offset':off,'candidate_target':target,'original_target':other,'unresolved':True});continue
  x=compare(target,other,next(iter(sizes)));x['call_offset']=off;calls.append(x)
 row['calls']=calls;row['literal_spans']=[]
 for literal in prior['relocated_data']:
  off=literal['original']['instruction_offset'];at=c+off;ptr=struct.unpack_from('<I',C.b,at+4)[0]|struct.unpack_from('<I',C.b,at+12)[0]<<32
  if off==488:
   assert C.b[c+536]==0x7a and O.b[o+536]==0x7a
   length=struct.unpack_from('<i',C.b,c+536+4)[0]
   assert 1<=length<=256
  else:length=literal['original']['bytes']
  raw=C.b[ptr:ptr+length];wanted=bytes.fromhex(literal['original']['hex'])
  row['literal_spans'].append({'instruction_offset':off,'candidate_start':ptr,'candidate_bytes':length,'candidate_hex':raw.hex(),'candidate_utf8':raw.decode(errors='replace'),'original_bytes':len(wanted),'original_hex':wanted.hex(),'original_utf8':literal['original']['utf8'],'equal':raw==wanted})
 row['candidate_diagnostic_line']=struct.unpack_from('<i',C.b,c+528+4)[0];row['original_diagnostic_line']=struct.unpack_from('<i',O.b,o+528+4)[0];output.append(row)
assert {r['type']for r in output}==set(types)
result={'candidate_sha256':H(C.b),'symbols_sha256':H(S.b),'original_sha256':H(O.b),'moved_types':args.moved,'full_codecs':output,'limits':'Complete checked codec windows and direct callee/literal extents inspected. Natural diagnostic-line differences remain; no transitive equivalence or historical layout claim.'}
args.output.write_text(json.dumps(result,indent=2)+'\n')
for r in output:print(r['type'],r['bytes'],r['different_slots'],[(x['instruction_offset'],x['equal'])for x in r['literal_spans']],r['candidate_diagnostic_line'],r['original_diagnostic_line'])
