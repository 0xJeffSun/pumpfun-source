#!/usr/bin/env python3
"""Read-only retained accepted window checks; no transitive equivalence claim."""
from pathlib import Path
import hashlib,json,re,struct,argparse
from elf_reader import Elf
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--symbols',type=Path,required=True);p.add_argument('--baseline-symbols',type=Path,required=True);p.add_argument('--gate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
C=Elf(a.candidate);S=Elf(a.symbols);B=Elf(a.baseline_symbols);O=Elf(W/'lead/evidence/original.so');prior=json.loads(a.gate.read_text());H=lambda b:hashlib.sha256(b).hexdigest();canon=lambda n:re.sub(r'17h[0-9a-f]{16}E$','E',n)
assert C.b[C.lo:C.hi]==S.b[S.lo:S.hi]
ranges={x:(O.entries[i+1]if i+1<len(O.entries)else O.hi)-x for i,x in enumerate(O.entries)}
def compare(c,o,n):
 return {'candidate_start':c,'original_start':o,'bytes':n,'candidate_raw_sha256':H(C.b[c:c+n]),'original_raw_sha256':H(O.b[o:o+n]),'raw_equal':C.b[c:c+n]==O.b[o:o+n],'normalized_equal':C.normalized[c:c+n]==O.normalized[o:o+n],'relocation_pattern_equal':C.pattern(c,n)==O.pattern(o,n),'original_entry_bounded':ranges.get(o)==n}
def require(x):assert x['normalized_equal']and x['relocation_pattern_equal']and x['original_entry_bounded'],x
rows={}
for name,old in list(prior['initializer_bodies'].items())+[(r['name'],r)for r in prior['retained_prior_bodies']]:
 names={canon(f['name'])for f in B.funcs if f['start']==old['candidate_start']}
 found={(f['start'],f['size'])for f in S.funcs if canon(f['name'])in names};assert len(found)==1,(name,found)
 c,n=next(iter(found));assert n==old['bytes'];r=compare(c,old['original_start'],n);require(r);rows[name]=r
calls={}
for name,key in [('handler','initializer_direct_calls'),('social_exit','retained_social_calls'),('pubkey_write_as_base58','retained_formatter_calls')]:
 parent=rows[name];current=[]
 for old in prior[key]:
  off=old['call_offset'];at=parent['candidate_start']+off;ct=C.calls[at];ot=O.calls[parent['original_start']+off];assert ot==old['original_start']
  sizes={f['size']for f in S.funcs if f['start']==ct};assert sizes=={old['bytes']}
  r=compare(ct,ot,old['bytes']);r.update(call_offset=off,candidate_signed_operand=struct.unpack_from('<i',C.b,at+4)[0],original_signed_operand=struct.unpack_from('<i',O.b,parent['original_start']+off+4)[0]);require(r);current.append(r)
 calls[name]=current
literals={}
for name,key in [('handler','initializer_literals'),('social_exit','retained_social_literals')]:
 current=[]
 for old in prior[key]:
  off=old['instruction_offset'];at=rows[name]['candidate_start']+off;ptr=struct.unpack_from('<I',C.b,at+4)[0]|struct.unpack_from('<I',C.b,at+12)[0]<<32;data=C.b[ptr:ptr+old['bytes']];assert data.hex()==old['hex']
  current.append({'offset':off,'candidate_target':ptr,'bytes':len(data),'sha256':H(data),'original_target':old['original_target'],'equal':True})
 literals[name]=current
result={'candidate_sha256':H(C.b),'baseline_symbols_sha256':H(B.b),'original_sha256':H(O.b),'all_retained_gates_passed':True,'bodies':rows,'direct_calls':calls,'literals':literals,'limits':'Retained complete normalized windows, signed immediate targets and known literal extents. No unrestricted descendant or data closure claim.'}
a.output.write_text(json.dumps(result,indent=2)+'\n');print('RETAINED STATIC PASS',len(rows),'bodies',sum(map(len,calls.values())),'direct calls',sum(map(len,literals.values())),'literals')
