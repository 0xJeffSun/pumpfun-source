#!/usr/bin/env python3
"""Portable saved-evidence verifier. --runtime rechecks signatures, never executes transactions."""
from pathlib import Path
import argparse,difflib,gzip,hashlib,json,subprocess,sys,tarfile,tempfile
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((P/n).read_text())
a=argparse.ArgumentParser();a.add_argument('--runtime',action='store_true');args=a.parse_args()
manifest=read('manifest-sha256.json');actual={str(p.relative_to(P)):H(p.read_bytes())for p in P.rglob('*')if p.is_file()and p.name!='manifest-sha256.json'}
# Nested original manifests are evidence and remain sealed by the outer manifest.
for p in P.rglob('manifest-sha256.json'):
 if p!=P/'manifest-sha256.json':actual[str(p.relative_to(P))]=H(p.read_bytes())
assert actual==manifest,'file inventory or digest mismatch'
def archive(n,expected):
 with tarfile.open(P/n)as t:
  members=t.getmembers();assert len(members)==len(expected)
  assert all(m.isfile()and not Path(m.name).is_absolute()and'..'not in Path(m.name).parts for m in members)
  contents={m.name:t.extractfile(m).read()for m in members};assert len(contents)==len(members)
 assert {n:H(v)for n,v in contents.items()}==expected,n
 return contents
base=read('baseline-source-sha256.json');source=read('source-sha256.json');assert len(base)==22 and len(source)==23
before=archive('baseline-source-snapshot.tar.gz',base);after=archive('source-snapshot.tar.gz',source)
blocks=[];expected=before.copy()
for m in read('lead/moves.json'):
 n=m['from'];a,z=m['before_bytes'];block=before[n][a:z];assert H(block)==m['declaration_sha256'];blocks.append(block);expected[n]=before[n][:a]+('pub use crate::state::'+m['type']+';\n').encode()+before[n][z:]
expected['programs/pump-fees/src/state.rs']=b'use anchor_lang::prelude::*;\n\n'+b'\n'.join(blocks)
n='programs/pump-fees/src/lib.rs';assert before[n].count(b'mod types;\n')==1;expected[n]=before[n].replace(b'mod types;\n',b'mod types;\nmod state;\n')
assert after==expected
patch=''.join(''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),after[n].decode().splitlines(True),fromfile='a/'+n if n in before else'/dev/null',tofile='b/'+n))for n in sorted(after))
assert patch==(P/'source.patch').read_text()==(P/'lead/source.patch').read_text()
assert after['Cargo.lock']==before['Cargo.lock']and after['programs/pump-fees/src/contexts.rs']==before['programs/pump-fees/src/contexts.rs']
prebuild=archive('prebuild-snapshot.tar.gz',read('prebuild-manifest-sha256.json'));assert prebuild['source.patch']==patch.encode()
assert H(prebuild['source-snapshot.tar.gz'])==H((P/'source-snapshot.tar.gz').read_bytes())
archive('build-helper-snapshot.tar.gz',read('build-helper-sha256.json'));harness=archive('harness-snapshot.tar.gz',read('harness-source-sha256.json'));assert len(harness)==46
sdk=archive('sbf-sdk-snapshot.tar.gz',read('build-comparison.json')['sdk_source_sha256']);assert len(sdk)==53
runtime=read('runtime-inputs.json');assert len(runtime)==18
for n,h in runtime.items():assert H((P/'runtime'/n).read_bytes())==h
prov=read('provenance.json');candidate=(P/'pump_fees_candidate.so').read_bytes();original=(P/'lead/evidence/original.so').read_bytes();symbols=(P/'symbols.so').read_bytes()
assert H(candidate)==prov['candidate_sha256']and len(candidate)==prov['candidate_bytes']and H(original)==prov['original_sha256']
assert prov['source_build_attempts']==1 and not prov['main_source_modified']
comparison={'original_bytes':len(original),'candidate_bytes':len(candidate),'original_sha256':H(original),'candidate_sha256':H(candidate),'full_byte_equality':original==candidate,'first_difference':next((i for i,(a,b)in enumerate(zip(original,candidate))if a!=b),min(len(original),len(candidate))if len(original)!=len(candidate)else None),'different_positions_in_shared_length':sum(a!=b for a,b in zip(original,candidate)),'length_difference':len(candidate)-len(original)}
assert comparison==read('build-comparison.json')['comparison']
build=read('build-comparison.json');prefix='work/fees-state-module-recovery/source/';assert len(build['source_sha256'])==23 and {n.removeprefix(prefix):h for n,h in build['source_sha256'].items()}==source
attempt=read('build-attempt.json');assert attempt['returncode']==0 and attempt['source_unchanged']and attempt['source_sha256']==attempt['source_after_sha256']==build['source_sha256']
assert H(gzip.decompress((P/'build.log.gz').read_bytes()))==build['build_log_sha256']==attempt['build_log_sha256']
phase=read('tool-phase-provenance.json');assert phase['compile']['requested_tools_version']=='v1.44'and phase['compile']['tool_hashes_before']==phase['compile']['tool_hashes_after']
assert phase['strip']['sdk_marker']=='platform-tools-v1.52.md'and phase['strip']['file_sha256_before']==phase['strip']['file_sha256_after']
assert phase['compile']['unstripped_sha256']==H(symbols)and phase['strip']['candidate_sha256']==H(candidate)
for n,h in phase['phase_source_sha256'].items():assert H(sdk[n])==h
from elf_reader import Elf
C=Elf(P/'pump_fees_candidate.so');S=Elf(P/'symbols.so')
for name in set(C.secs)&set(S.secs):
 c,s=C.secs[name],S.secs[name]
 if c[2]&2:assert C.b[c[4]:c[4]+c[5]]==S.b[s[4]:s[4]+s[5]],name
with tempfile.TemporaryDirectory()as temp:
 temp=Path(temp)
 def run(script,argv):
  r=subprocess.run([sys.executable,'-B',str(P/script),*map(str,argv)],capture_output=True,text=True,cwd=temp);assert r.returncode==0,(script,r.stdout,r.stderr)
 run('lead/verify.py',[])
 for stem,moved,candidate_path,symbol_path in [('candidate',True,P/'pump_fees_candidate.so',P/'symbols.so'),('baseline',False,P/'baseline/pump_fees_candidate.so',P/'baseline/symbols.so')]:
  output=temp/(stem+'.json');run('inspect_codecs.py',['--candidate',candidate_path,'--symbols',symbol_path,'--output',output]+(['--moved']if moved else[]));assert json.loads(output.read_text())==read(stem+'-codecs.json'if moved else'baseline-codecs-complete.json')
 output=temp/'retained.json';run('verify_retained_static.py',['--candidate',P/'pump_fees_candidate.so','--symbols',P/'symbols.so','--baseline-symbols',P/'baseline/symbols.so','--gate',P/'accepted-inline-static-gate.json','--output',output]);assert json.loads(output.read_text())==read('retained-static-gate.json')
rows=read('candidate-codecs.json')['full_codecs'];assert len(rows)==5
for row in rows:
 assert row['relocation_pattern_equal']and row['original_entry_bounded']and row['literal_spans'][1]['equal']
 if row['type']!='SharingConfig':assert row['literal_spans'][0]['equal']and row['different_slots']==[528]
 assert all(x['normalized_equal']and x['original_entry_bounded']and x['relocation_pattern_equal']for x in row['calls'])
inputs=read('frozen-runner-inputs.json');assert inputs['source_sha256']==source and inputs['harness_sha256']==read('harness-source-sha256.json')and inputs['runtime_sha256']==runtime
assert inputs['runner_sha256']==H((P/'run_regressions.py').read_bytes())
bindings=read('receipt-build-bindings.json');assert len(bindings)==10
for row in bindings:
 raw=gzip.decompress((P/row['saved_report']).read_bytes());d=json.loads(raw);assert H(raw)==row['raw_report_sha256']==row['report_sha256']and H((P/row['saved_report']).read_bytes())==row['saved_report_sha256']
 assert d['candidate_sha256']==H(candidate)and d['original_sha256']==H(original)and not d['mismatches']
 assert row['actual_source_sha256']==source and row['build_report_sha256']==H((P/'build-comparison.json').read_bytes())and row['executed_candidate_sha256']==H(candidate)and row['returncode']==0 and row['passed']
summary=read('runtime-summary.json');assert summary['comparison_receipts']==17441 and summary['donation_sequence_steps']==10 and summary['source_inputs']==23 and not summary['mismatches']and not summary['orchestration_failures']
if args.runtime:
 r=subprocess.run([sys.executable,'-B',str(P/'verify_saved_runtime.py')],capture_output=True,text=True,cwd=P);assert r.returncode==0,(r.stdout,r.stderr);assert json.loads(r.stdout)==read('runtime-verification-result.json')
print(json.dumps({'verified':True,'sealed_files':len(manifest),'source_inputs':23,'source_placement_matches':4,'checked_codec_windows':5,'immediate_call_sites':35,'retained_accepted_windows':10,'comparison_receipts':17441,'donation_steps':10,'saved_signature_verifier_rerun':args.runtime,'whole_original_elf_equal':False},indent=2))
