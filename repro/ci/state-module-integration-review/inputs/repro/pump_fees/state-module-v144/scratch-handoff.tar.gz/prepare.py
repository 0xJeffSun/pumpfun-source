from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tarfile,difflib,re
W=Path(__file__).resolve().parent;R=W.parents[1];P=R/'repro/pump_fees/initializer-inline-v144';S=W/'source';L=W/'lead'
H=lambda b:hashlib.sha256(b).hexdigest()
def save(n,v):(W/n).write_text(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()=='517d77db988d8c63b6cf476f0be138c5a4f3128a'
assert not S.exists()and not L.exists();shutil.copytree(R/'repro/parallel-work/2026-10-24/wave2-results/fees_state_module',L)
r=subprocess.run([sys.executable,'-B',str(L/'verify.py')],cwd=W,capture_output=True,text=True);save('lead-verification.json',{'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'manifest_sha256':H((L/'manifest-sha256.json').read_bytes())});assert r.returncode==0
base=json.loads((P/'source-sha256.json').read_text());assert len(base)==22
before={n:(R/n).read_bytes()for n in base};assert {n:H(v)for n,v in before.items()}==base
assert all(v==subprocess.check_output(['git','-C',str(R),'show','517d77db988d8c63b6cf476f0be138c5a4f3128a:'+n])for n,v in before.items())
after=before.copy();blocks=[]
for move in json.loads((L/'moves.json').read_text()):
 n=move['from'];a,z=move['before_bytes'];block=before[n][a:z];assert H(block)==move['declaration_sha256'];assert re.fullmatch(rb'#\[account\]\npub struct '+move['type'].encode()+rb'\s*\{[^}]*\}\n',block)
 after[n]=before[n][:a]+('pub use crate::state::'+move['type']+';\n').encode()+before[n][z:];blocks.append(block)
after['programs/pump-fees/src/state.rs']=b'use anchor_lang::prelude::*;\n\n'+b'\n'.join(blocks)
name='programs/pump-fees/src/lib.rs';assert before[name].count(b'mod types;\n')==1;after[name]=before[name].replace(b'mod types;\n',b'mod types;\nmod state;\n')
patch=''
for n in sorted(after):patch+=''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),after[n].decode().splitlines(True),fromfile='a/'+n if n in before else'/dev/null',tofile='b/'+n))
assert patch==(L/'source.patch').read_text();(W/'source.patch').write_text(patch)
assert after['programs/pump-fees/src/contexts.rs']==before['programs/pump-fees/src/contexts.rs']and b'pub pump_global: Account<'in after['programs/pump-fees/src/contexts.rs']
for n,v in after.items():p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v)
save('baseline-source-sha256.json',base);save('source-sha256.json',{n:H(v)for n,v in after.items()})
for name,files in [('baseline-source-snapshot.tar.gz',before),('source-snapshot.tar.gz',after)]:
 with tarfile.open(W/name,'w:gz')as t:
  import io
  for n,v in files.items():info=tarfile.TarInfo(n);info.size=len(v);info.mode=0o644;t.addfile(info,io.BytesIO(v))
save('prebuild-source-review.json',{'baseline_commit':'517d77db988d8c63b6cf476f0be138c5a4f3128a','baseline_candidate_sha256':'01fedce5878ec14618233c4683bcb4149e471775acb48ffb69614d9df570bb95','before_inputs':22,'after_inputs':23,'changed_paths':[n for n in after if after[n]!=before.get(n)],'inline_context_preserved':True,'dependencies_unchanged':after['Cargo.lock']==before['Cargo.lock'],'exact_published_patch_reproduced':True,'declaration_blocks_byte_preserved':4,'source_padded_or_line_aligned':False,'known_limits':'Natural module declaration insertion shifts following lib.rs source coordinates; diagnostics will be compared without compensating source changes.','compiler_attempts_at_snapshot':0})
print('PREPARED exact six-path proposal, current inline context and lock retained')
