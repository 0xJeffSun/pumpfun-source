   8e128: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   8e130: 7b 9a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r9
   8e138: 7b 5a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r5
   8e140: 7b 30 00 00 00 00 00 00      	stxdw [r0 + 0x0], r3
   8e148: 55 02 01 00 01 00 00 00      	jne r2, 0x1, +0x1 <.text+0x8e038>
   8e150: 05 00 d4 ff 00 00 00 00      	ja -0x2c <.text+0x8ded8>
   8e158: 7b 0a c0 fe 00 00 00 00      	stxdw [r10 - 0x140], r0
   8e160: 7b 7a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r7
   8e168: 79 49 00 00 00 00 00 00      	ldxdw r9, [r4 + 0x0]
   8e170: 79 94 08 00 00 00 00 00      	ldxdw r4, [r9 + 0x8]
   8e178: 79 43 00 00 00 00 00 00      	ldxdw r3, [r4 + 0x0]
   8e180: 07 03 00 00 01 00 00 00      	add64 r3, 0x1
   8e188: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   8e190: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <.text+0x8e080>
   8e198: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   8e1a0: 7b 6a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r6
   8e1a8: 71 85 2a 00 00 00 00 00      	ldxb r5, [r8 + 0x2a]
   8e1b0: 7b 5a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r5
   8e1b8: 71 85 29 00 00 00 00 00      	ldxb r5, [r8 + 0x29]
   8e1c0: 7b 5a d0 fe 00 00 00 00      	stxdw [r10 - 0x130], r5
   8e1c8: 71 85 28 00 00 00 00 00      	ldxb r5, [r8 + 0x28]
   8e1d0: 7b 5a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r5
   8e1d8: 79 85 20 00 00 00 00 00      	ldxdw r5, [r8 + 0x20]
   8e1e0: 79 87 18 00 00 00 00 00      	ldxdw r7, [r8 + 0x18]
   8e1e8: 79 90 00 00 00 00 00 00      	ldxdw r0, [r9 + 0x0]
   8e1f0: 7b 34 00 00 00 00 00 00      	stxdw [r4 + 0x0], r3
   8e1f8: 55 02 01 00 01 00 00 00      	jne r2, 0x1, +0x1 <.text+0x8e0e8>
   8e200: 05 00 be ff 00 00 00 00      	ja -0x42 <.text+0x8ded8>
   8e208: 7b 5a b0 fe 00 00 00 00      	stxdw [r10 - 0x150], r5
   8e210: 79 93 10 00 00 00 00 00      	ldxdw r3, [r9 + 0x10]
   8e218: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   8e220: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   8e228: b7 06 00 00 01 00 00 00      	mov64 r6, 0x1
   8e230: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <.text+0x8e120>
   8e238: b7 06 00 00 00 00 00 00      	mov64 r6, 0x0
   8e240: 79 a5 30 ff 00 00 00 00      	ldxdw r5, [r10 - 0xd0]
   8e248: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
   8e250: 7b 23 00 00 00 00 00 00      	stxdw [r3 + 0x0], r2
   8e258: 55 06 01 00 01 00 00 00      	jne r6, 0x1, +0x1 <.text+0x8e148>
   8e260: 05 00 b2 ff 00 00 00 00      	ja -0x4e <.text+0x8ded8>
   8e268: 79 92 18 00 00 00 00 00      	ldxdw r2, [r9 + 0x18]
   8e270: 79 95 20 00 00 00 00 00      	ldxdw r5, [r9 + 0x20]
   8e278: 71 96 28 00 00 00 00 00      	ldxb r6, [r9 + 0x28]
   8e280: 71 98 29 00 00 00 00 00      	ldxb r8, [r9 + 0x29]
   8e288: 71 99 2a 00 00 00 00 00      	ldxb r9, [r9 + 0x2a]
   8e290: 73 9a ea ff 00 00 00 00      	stxb [r10 - 0x16], r9
   8e298: 73 8a e9 ff 00 00 00 00      	stxb [r10 - 0x17], r8
   8e2a0: 73 6a e8 ff 00 00 00 00      	stxb [r10 - 0x18], r6
   8e2a8: 7b 5a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r5
   8e2b0: 7b 2a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r2
   8e2b8: 7b 3a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r3
   8e2c0: 7b 4a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r4
   8e2c8: 7b 0a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r0
   8e2d0: 79 a1 c8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x138]
   8e2d8: 73 1a ba ff 00 00 00 00      	stxb [r10 - 0x46], r1
   8e2e0: 79 a1 d0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x130]
   8e2e8: 73 1a b9 ff 00 00 00 00      	stxb [r10 - 0x47], r1
   8e2f0: 79 a1 d8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x128]
   8e2f8: 73 1a b8 ff 00 00 00 00      	stxb [r10 - 0x48], r1
   8e300: 79 a1 b0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x150]
   8e308: 7b 1a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r1
   8e310: 7b 7a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r7
   8e318: 79 a1 c0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x140]
   8e320: 7b 1a a0 ff 00 00 00 00      	stxdw [r10 - 0x60], r1
   8e328: 79 a1 e0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x120]
   8e330: 7b 1a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r1
   8e338: 79 a1 f0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x110]
   8e340: 7b 1a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r1
   8e348: 79 a1 00 ff 00 00 00 00      	ldxdw r1, [r10 - 0x100]
   8e350: 73 1a 8a ff 00 00 00 00      	stxb [r10 - 0x76], r1
   8e358: 79 a1 08 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf8]
   8e360: 73 1a 89 ff 00 00 00 00      	stxb [r10 - 0x77], r1
   8e368: 79 a1 10 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf0]
   8e370: 73 1a 88 ff 00 00 00 00      	stxb [r10 - 0x78], r1
   8e378: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   8e380: 7b 1a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r1
   8e388: 79 a1 20 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe0]
   8e390: 7b 1a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r1
   8e398: 79 a1 28 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd8]
   8e3a0: 7b 1a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r1
   8e3a8: 79 a1 e8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x118]
   8e3b0: 7b 1a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r1
   8e3b8: 79 a1 f8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x108]
   8e3c0: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   8e3c8: 7a 0a f8 ff 00 00 00 00      	stdw [r10 - 0x8], 0x0
   8e3d0: 7a 0a f0 ff 08 00 00 00      	stdw [r10 - 0x10], 0x8
   8e3d8: 7a 0a 58 ff 00 00 00 00      	stdw [r10 - 0xa8], 0x0
   8e3e0: 7a 0a 50 ff 08 00 00 00      	stdw [r10 - 0xb0], 0x8
   8e3e8: 7a 0a 48 ff 00 00 00 00      	stdw [r10 - 0xb8], 0x0
   8e3f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   8e3f8: 07 01 00 00 38 ff ff ff      	add64 r1, -0xc8
   8e400: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   8e408: 07 02 00 00 48 ff ff ff      	add64 r2, -0xb8
   8e410: 79 a3 30 ff 00 00 00 00      	ldxdw r3, [r10 - 0xd0]
   8e418: 85 10 00 00 8e 1f 02 00      	call 0x21f8e
   8e420: 79 a6 40 ff 00 00 00 00      	ldxdw r6, [r10 - 0xc0]
   8e428: 79 a0 38 ff 00 00 00 00      	ldxdw r0, [r10 - 0xc8]
   8e430: 79 a1 b8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x148]
   8e438: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   8e440: 7b 01 00 00 00 00 00 00      	stxdw [r1 + 0x0], r0
