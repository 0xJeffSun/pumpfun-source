from probe import *
from probe_routes import route2
from probe_curve import curve_route
from probe_validation import account_change,mutate_at
from probe_mixed import curve_then_amm,amm_then_curve
from probe_two_curves import two_curves
import hashlib
candidate=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
cases=[]
for sell in [False,True]:
 for tail in [False,True]:
  for amount,limit in [(0,0),(0,1),(1,0),(1,1),(10**9,1)]:cases.append((f'one-{sell}-{tail}-{amount}-{limit}',dict(amount=amount,limit=limit,sell=sell,tail=tail)))
 for amount in [1,10**6,10**9,10**12]:
  cases.append((f'two-{sell}-{amount}',dict(amount=amount,sell=sell,overrides=route2(sell))))
  cases.append((f'curve-{sell}-{amount}',dict(amount=amount,sell=sell,overrides=curve_route(sell))))
for kind,setup in [('curve-amm',curve_then_amm),('amm-curve',amm_then_curve),('two-curves',two_curves)]:
 for sell in [False,True]:
  for amount in [10**6,10**9]:cases.append((f'{kind}-{sell}-{amount}',dict(amount=amount,sell=sell,overrides=setup(sell))))
for i in list(range(1,5))+[6]+list(range(12,21)):
 for typ,val in [('owner',Pubkey.default()),('data',b''),('readonly',None)]:cases.append((f'validation-{i}-{typ}',dict(overrides=account_change(i,typ,val))))
for i in [1,2,19,20]:
 for off,d in [(0,bytes(32)),(32,bytes(32)),(108,bytes([0])),(108,bytes([2]))]:cases.append((f'token-{i}-{off}-{d[0]}',dict(overrides=mutate_at(i,off,d))))
for off,d in [(8,bytes([0])),(11,bytes(32)),(43,bytes(32)),(75,bytes(32)),(139,bytes(32)),(171,bytes(32)),(243,b'\x01'),(244,b'\x01')]:cases.append((f'pool-{off}',dict(overrides=mutate_at(18,off,d))))
rows=[]
for name,params in cases:
 original=run(**params);recovered=run(candidate=candidate,**params);diff=[k for k in ['error','events','inner','after','return_data']if original[k]!=recovered[k]];rows.append({'case':name,'mismatches':diff,'original':original,'candidate':recovered});print(name,diff,original['error'],recovered['error'],flush=True)
(out/'report.json').write_text(json.dumps({'candidate':str(candidate),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'case_count':len(rows),'passed':sum(not r['mismatches']for r in rows),'rows':rows},indent=2))
