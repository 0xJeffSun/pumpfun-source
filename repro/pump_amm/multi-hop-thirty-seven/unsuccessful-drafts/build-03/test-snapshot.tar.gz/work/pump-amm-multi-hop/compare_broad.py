"""Bounded original-vs-candidate multi-hop differential; all outer signatures verified."""
from probe import *
from probe_routes import route2,BASE2,USER2
from probe_curve import curve_route,CM,CURVE,CB,CQ,CU
from probe_mixed import curve_then_amm,amm_then_curve
from probe_two_curves import two_curves
from probe_validation import account_change,mutate_at
from pump_amm_trade_v2_differential import custom_fee_table
import hashlib

def tf(key,bps,maximum):
 def ov(h,m):
  a=h.vm.get_account(key);d=bytearray(a.data[:82])+bytes(83)+bytes([1]);conf=bytes(72)+struct.pack('<QQH',0,maximum,bps)*2;d+=struct.pack('<HH',1,len(conf))+conf;h.vm.set_account(key,Account(10**9,bytes(d),TOKEN22))
  for k in ([vaultbase,userbase]if key==base else[vaultquote,userquote]):
   a=h.vm.get_account(k);d=a.data[:165]+bytes([2])+struct.pack('<HHQ',2,8,0);h.vm.set_account(k,Account(max(a.lamports,10**9),d,TOKEN22))
  if key==quote:
   a=h.vm.get_account(buyback);owner=Pubkey.from_bytes(a.data[32:64]);k=Pubkey.find_program_address([bytes(owner),bytes(TOKEN22),bytes(quote)],ATA)[0];d=a.data[:165]+bytes([2])+struct.pack('<HHQ',2,8,0);h.vm.set_account(k,Account(10**9,d,TOKEN22));m[6]=AccountMeta(k,False,True)
 return ov

def volume_state(length=137,offset=None,value=b''):
 def ov(h,m):
  d=bytearray(bytes(next(x for x in IDL['accounts']if x['name']=='UserVolumeAccumulator')['discriminator'])+bytes(PAYER.pubkey())+bytes(97));d=d[:length].ljust(length,b'\0')
  if offset is not None:d[offset:offset+len(value)]=value
  h.vm.set_account(volume,Account(10**9,bytes(d),PROGRAM))
 return ov

def remaining_shape(n):
 def ov(h,m):
  if n<5:m[16:]=m[16:16+n]
  else:m.extend([m[16]]*(n-5))
 return ov

def mixed_direction(h,m):
 route2(False)(h,m);second=m[21:];m[21]=second[1];m[22]=second[0];d=bytearray(h.vm.get_account(USER2).data);d[:32]=bytes(BASE2);h.vm.set_account(USER2,Account(10**9,bytes(d),TOKEN))

if __name__=='__main__':
 candidate=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False);rows=[]
 def test(label,**params):
  original=run(**params);recovered=run(candidate=candidate,**params);diff=[k for k in original if k!='logs'and original[k]!=recovered[k]];rows.append({'case':label,'mismatches':diff,'original':original,'candidate':recovered});print(label,diff,original['error'],recovered['error'],flush=True)
 for sell in [False,True]:
  for amount in [0,1,2,3,4,5,10,100,1000,10**6,10**9,10**12,10**15,2**64-1]:
   for limit in [0,1,2**64-1]:test(f'amount-limit-{sell}-{amount}-{limit}',sell=sell,amount=amount,limit=limit)
  test(f'unsigned-{sell}',sell=sell,unsigned=True);test(f'separate-payer-{sell}',sell=sell,separate_payer=True);test(f'readonly-user-{sell}',sell=sell,separate_payer=True,overrides=meta_mutation(0,'readonly'))
  for n in range(24):test(f'payload-{sell}-{n}',sell=sell,payload_length=n)
  test(f'extra-data-{sell}',sell=sell,extra_data=b'abc')
  for idx in range(1,21):test(f'substitute-{sell}-{idx}',sell=sell,overrides=meta_mutation(idx,'substitute'))
  for idx in [1,2,3,4,5,6,18,19,20]:test(f'readonly-{sell}-{idx}',sell=sell,overrides=meta_mutation(idx,'readonly'))
  for key in [pool,CONFIG_KEY,base,quote,userbase,userquote,vaultbase,vaultquote,feeconfig,buyback]:test(f'owner-{sell}-{key}',sell=sell,overrides=mutate(key,0,b'',owner=Pubkey.default()))
  for key in [userbase,userquote,vaultbase,vaultquote,buyback]:
   for off,d in [(0,bytes(32)),(32,bytes(32)),(108,b'\0'),(108,b'\2')]:test(f'token-{sell}-{key}-{off}-{d.hex()}',sell=sell,overrides=mutate(key,off,d))
   for n in [0,1,2**64-1]:test(f'balance-{sell}-{key}-{n}',sell=sell,overrides=mutate(key,64,struct.pack('<Q',n)))
  for off,d in [(8,b'\0'),(11,bytes(32)),(43,bytes(32)),(75,bytes(32)),(139,bytes(32)),(171,bytes(32)),(211,bytes(32)),(243,b'\1'),(244,b'\1'),(270,b'\1')]:test(f'pool-field-{sell}-{off}',sell=sell,overrides=mutate(pool,off,d))
  for v in [-2**127,-10**13,-125882,-125881,0,1,10**9,2**64,2**127-1]:test(f'virtual-{sell}-{v}',sell=sell,overrides=mutate(pool,245,v.to_bytes(16,'little',signed=True)))
  for off in [261,271,279]:
   for v in [0,1,10**9,2**64-1]:test(f'pool-fees-{sell}-{off}-{v}',sell=sell,overrides=mutate(pool,off,struct.pack('<Q',v)))
  for v in [0,1,9999,10000,10001,2**64-1]:test(f'buyback-bps-{sell}-{v}',sell=sell,overrides=mutate(CONFIG_KEY,899,struct.pack('<Q',v)))
  for flags in [0,1,2,4,8,16,31,255]:test(f'disabled-{sell}-{flags}',sell=sell,overrides=mutate(CONFIG_KEY,56,bytes([flags])))
  for length in [0,7,8,210,211,243,244,245,261,270,271,286,287,300]:test(f'pool-length-{sell}-{length}',sell=sell,overrides=mutate(pool,0,b'',length))
  for length in [0,7,8,40,73,89,90,136,137,138]:test(f'volume-length-{sell}-{length}',sell=sell,overrides=volume_state(length))
  for off,d in [(8,bytes(32)),(8,bytes(OUTSIDER.pubkey())),(40,b'\1'),(41,struct.pack('<Q',123)),(49,struct.pack('<Q',456)),(57,struct.pack('<Q',789)),(65,struct.pack('<Q',1234))]:test(f'volume-field-{sell}-{off}-{d.hex()}',sell=sell,overrides=volume_state(offset=off,value=d))
  for length in [0,7,8,40,65,69,1068,1069,2511,2512,3000,4072,4073,4096,4097]:test(f'fee-length-{sell}-{length}',sell=sell,overrides=mutate(feeconfig,0,b'',length))
  for tiers in [[],[(0,(0,0,0))],[(0,(10,20,30))],[(2**120,(10,20,30)),(0,(40,50,60))],[(0,(10,20,30)),(0,(40,50,60))],[(0,(10000,10000,10000))],[(0,(2**64-1,0,0))]]:test(f'fee-table-{sell}-{tiers}',sell=sell,overrides=custom_fee_table(tiers))
  for key in [base,quote]:
   for bps in [0,1,100,9999,10000]:
    for maximum in [0,1,123,2**64-1]:test(f'transfer-fee-{sell}-{key}-{bps}-{maximum}',sell=sell,overrides=tf(key,bps,maximum))
  for count in [0,1,2,3,4,5,6,9,10,11]:test(f'remaining-{sell}-{count}',sell=sell,overrides=remaining_shape(count))
  for kind,setup in [('two-amm',route2),('curve',curve_route),('curve-amm',curve_then_amm),('amm-curve',amm_then_curve),('two-curves',two_curves)]:
   for amount in [1,10**6,10**9,10**12]:
    for limit in [1,2**64-1]:test(f'route-{kind}-{sell}-{amount}-{limit}',sell=sell,amount=amount,limit=limit,overrides=setup(sell))
  for length in [0,7,8,56,642,907,939,940,948,949,1000]:test(f'global-length-{sell}-{length}',sell=sell,overrides=mutate(CONFIG_KEY,0,b'',length))
 test('mixed-direction',overrides=mixed_direction)
 failures=[i for i,r in enumerate(rows)if r['mismatches']];sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();(out/'report.json').write_text(json.dumps({'scope':'Bounded original-vs-candidate offline MultiHopSwap with normal verified test-owned signatures and captured dependencies. Synthetic fixture mutations.','candidate':str(candidate),'candidate_sha256':sha(candidate),'original_sha256':sha(ROOT/'evidence/original/pump_amm/deployed.so'),'case_count':len(rows),'passed':len(rows)-len(failures),'mismatches':failures,'cases':rows},separators=(',',':'))+'\n');print(len(rows),len(failures));raise SystemExit(bool(failures))
