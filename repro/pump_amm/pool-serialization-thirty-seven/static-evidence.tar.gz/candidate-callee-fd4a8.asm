000fd4a8: bf 26 00 00 00 00 00 00  mov64 r6, r2
000fd4b0: 79 11 00 00 00 00 00 00  ldxdw r1, [r1 + 0x0]
000fd4b8: bf 12 00 00 00 00 00 00  mov64 r2, r1
000fd4c0: 57 02 00 00 03 00 00 00  and64 r2, 0x3
000fd4c8: 65 02 08 00 01 00 00 00  jsgt r2, 0x1, +0x8 <custom_panic+0x35998> ; branch 0xfd510
000fd4d0: 15 02 27 00 00 00 00 00  jeq r2, 0x0, +0x27 <custom_panic+0x35a98> ; branch 0xfd610
000fd4d8: 79 12 ff ff 00 00 00 00  ldxdw r2, [r1 - 0x1]
000fd4e0: 79 11 07 00 00 00 00 00  ldxdw r1, [r1 + 0x7]
000fd4e8: 79 13 20 00 00 00 00 00  ldxdw r3, [r1 + 0x20]
000fd4f0: bf 21 00 00 00 00 00 00  mov64 r1, r2
000fd4f8: bf 62 00 00 00 00 00 00  mov64 r2, r6
000fd500: 8d 00 00 00 03 00 00 00  callx r3
000fd508: 05 00 59 00 00 00 00 00  ja +0x59 <custom_panic+0x35c60> ; branch 0xfd7d8
000fd510: 15 02 24 00 02 00 00 00  jeq r2, 0x2, +0x24 <custom_panic+0x35ac0> ; branch 0xfd638
000fd518: 77 01 00 00 20 00 00 00  rsh64 r1, 0x20
000fd520: 85 10 00 00 e6 fd ff ff  call -0x21a ; call 0xfc458 _ZN3std2io5error14repr_bitpacked14kind_from_prim17h204160dd4d1a484eE
000fd528: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd530: 07 01 00 00 80 ff ff ff  add64 r1, -0x80
000fd538: bf 02 00 00 00 00 00 00  mov64 r2, r0
000fd540: 85 10 00 00 81 fe ff ff  call -0x17f ; call 0xfc950 _ZN3std2io5error9ErrorKind6as_str17h33a927e14da26158E
000fd548: 18 01 00 00 30 c3 0f 00 00 00 00 00 00 00 00 00  lddw r1, 0xfc330 ; data 0xfc330 b'\xbf#\x00\x00\x00\x00\x00\x00y\x12\x08\x00\x00\x00\x00\x00y\x11\x00\x00\x00\x00\x00\x00\x85\x10\x00\x00\x9f\x0c\x00\x00\x95\x00\x00\x00\x00\x00\x00\x00a#4\x00\x00\x00\x00\x00\xbf4\x00\x00\x00\x00\x00\x00W\x04\x00\x00\x10\x00\x00\x00U\x04\x05\x00\x00\x00\x00\x00W\x03\x00\x00 \x00\x00\x00'
000fd558: 7b 1a a0 ff 00 00 00 00  stxdw [r10 - 0x60], r1
000fd560: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd568: 07 01 00 00 b0 ff ff ff  add64 r1, -0x50
000fd570: 7b 1a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r1
000fd578: 18 01 00 00 90 91 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x109190 ; data 0x109190 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00AccountNotSignerPermissionDeniedno storage spaceAvailable fees ('
000fd588: 7b 1a d0 ff 00 00 00 00  stxdw [r10 - 0x30], r1
000fd590: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd598: 07 01 00 00 98 ff ff ff  add64 r1, -0x68
000fd5a0: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000fd5a8: 79 a1 88 ff 00 00 00 00  ldxdw r1, [r10 - 0x78]
000fd5b0: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000fd5b8: 79 a1 80 ff 00 00 00 00  ldxdw r1, [r10 - 0x80]
000fd5c0: 7b 1a b0 ff 00 00 00 00  stxdw [r10 - 0x50], r1
000fd5c8: 7a 0a f0 ff 00 00 00 00  stdw [r10 - 0x10], 0x0
000fd5d0: 7a 0a d8 ff 01 00 00 00  stdw [r10 - 0x28], 0x1
000fd5d8: 7a 0a e8 ff 01 00 00 00  stdw [r10 - 0x18], 0x1
000fd5e0: 79 62 28 00 00 00 00 00  ldxdw r2, [r6 + 0x28]
000fd5e8: 79 61 20 00 00 00 00 00  ldxdw r1, [r6 + 0x20]
000fd5f0: bf a3 00 00 00 00 00 00  mov64 r3, r10
000fd5f8: 07 03 00 00 d0 ff ff ff  add64 r3, -0x30
000fd600: 85 10 00 00 cb 06 00 00  call 0x6cb ; call 0x100c60 _ZN4core3fmt5write17hc096270015428e07E
000fd608: 05 00 39 00 00 00 00 00  ja +0x39 <custom_panic+0x35c60> ; branch 0xfd7d8
000fd610: 79 12 08 00 00 00 00 00  ldxdw r2, [r1 + 0x8]
000fd618: 79 11 00 00 00 00 00 00  ldxdw r1, [r1 + 0x0]
000fd620: bf 63 00 00 00 00 00 00  mov64 r3, r6
000fd628: 85 10 00 00 43 0a 00 00  call 0xa43 ; call 0x102848 _ZN42_$LT$str$u20$as$u20$core..fmt..Display$GT$3fmt17h630bd9b8573b2806E
000fd630: 05 00 34 00 00 00 00 00  ja +0x34 <custom_panic+0x35c60> ; branch 0xfd7d8
000fd638: 77 01 00 00 20 00 00 00  rsh64 r1, 0x20
000fd640: 63 1a 94 ff 00 00 00 00  stxw [r10 - 0x6c], r1
000fd648: b7 01 00 00 14 00 00 00  mov64 r1, 0x14
000fd650: b7 02 00 00 01 00 00 00  mov64 r2, 0x1
000fd658: 85 10 00 00 49 94 ff ff  call -0x6bb7 ; call 0xc78a8 __rust_alloc
000fd660: 55 00 03 00 00 00 00 00  jne r0, 0x0, +0x3 <custom_panic+0x35b08> ; branch 0xfd680
000fd668: b7 01 00 00 01 00 00 00  mov64 r1, 0x1
000fd670: b7 02 00 00 14 00 00 00  mov64 r2, 0x14
000fd678: 85 10 00 00 9f 01 00 00  call 0x19f ; call 0xfe378 _ZN5alloc7raw_vec12handle_error17ha65af3db0df92ee4E
000fd680: 18 01 00 00 6e 20 73 75 00 00 00 00 63 63 65 73  lddw r1, 0x736563637573206e
000fd690: 7b 10 08 00 00 00 00 00  stxdw [r0 + 0x8], r1
000fd698: 18 01 00 00 6f 70 65 72 00 00 00 00 61 74 69 6f  lddw r1, 0x6f6974617265706f
000fd6a8: 7b 10 00 00 00 00 00 00  stxdw [r0 + 0x0], r1
000fd6b0: 62 00 10 00 73 66 75 6c  stw [r0 + 0x10], 0x6c756673
000fd6b8: 7b 0a a0 ff 00 00 00 00  stxdw [r10 - 0x60], r0
000fd6c0: 7a 0a a8 ff 14 00 00 00  stdw [r10 - 0x58], 0x14
000fd6c8: 7a 0a 98 ff 14 00 00 00  stdw [r10 - 0x68], 0x14
000fd6d0: 18 01 00 00 30 01 11 00 00 00 00 00 00 00 00 00  lddw r1, 0x110130 ; data 0x110130 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00:\xd3\x10\x00\x0b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00E\xd3\x10\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xe0\xde\x0f\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf8\xe9\x0f\x00'
000fd6e0: 7b 1a d0 ff 00 00 00 00  stxdw [r10 - 0x30], r1
000fd6e8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd6f0: 07 01 00 00 b0 ff ff ff  add64 r1, -0x50
000fd6f8: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000fd700: 18 01 00 00 d0 57 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x1057d0 ; data 0x1057d0 b'\xbf#\x00\x00\x00\x00\x00\x00a\x14\x00\x00\x00\x00\x00\x00g\x04\x00\x00 \x00\x00\x00\xc7\x04\x00\x00 \x00\x00\x00e\x04\x03\x00\xff\xff\xff\xff\xbfA\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00\x00\x00\x00\x00\x05\x00\x01\x00\x00\x00\x00\x00\xbfA\x00\x00\x00\x00\x00\x00\xb7\x02\x00\x00\x01\x00\x00\x00'
000fd710: 7b 1a c8 ff 00 00 00 00  stxdw [r10 - 0x38], r1
000fd718: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd720: 07 01 00 00 94 ff ff ff  add64 r1, -0x6c
000fd728: 7b 1a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r1
000fd730: 18 01 00 00 30 c4 0f 00 00 00 00 00 00 00 00 00  lddw r1, 0xfc430 ; data 0xfc430 b'\xbf#\x00\x00\x00\x00\x00\x00y\x12\x10\x00\x00\x00\x00\x00y\x11\x08\x00\x00\x00\x00\x00\x85\x10\x00\x00\x7f\x0c\x00\x00\x95\x00\x00\x00\x00\x00\x00\x00g\x01\x00\x00 \x00\x00\x00w\x01\x00\x00 \x00\x00\x00e\x01\t\x00\x13\x00\x00\x00e\x01\x17\x00\t\x00\x00\x00e\x01*\x00\x04\x00\x00\x00'
000fd740: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000fd748: bf a1 00 00 00 00 00 00  mov64 r1, r10
000fd750: 07 01 00 00 98 ff ff ff  add64 r1, -0x68
000fd758: 7b 1a b0 ff 00 00 00 00  stxdw [r10 - 0x50], r1
000fd760: 7a 0a f0 ff 00 00 00 00  stdw [r10 - 0x10], 0x0
000fd768: 7a 0a d8 ff 03 00 00 00  stdw [r10 - 0x28], 0x3
000fd770: 7a 0a e8 ff 02 00 00 00  stdw [r10 - 0x18], 0x2
000fd778: 79 62 28 00 00 00 00 00  ldxdw r2, [r6 + 0x28]
000fd780: 79 61 20 00 00 00 00 00  ldxdw r1, [r6 + 0x20]
000fd788: bf a3 00 00 00 00 00 00  mov64 r3, r10
000fd790: 07 03 00 00 d0 ff ff ff  add64 r3, -0x30
000fd798: 85 10 00 00 98 06 00 00  call 0x698 ; call 0x100c60 _ZN4core3fmt5write17hc096270015428e07E
000fd7a0: 79 a2 98 ff 00 00 00 00  ldxdw r2, [r10 - 0x68]
000fd7a8: 15 02 05 00 00 00 00 00  jeq r2, 0x0, +0x5 <custom_panic+0x35c60> ; branch 0xfd7d8
000fd7b0: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
000fd7b8: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000fd7c0: bf 06 00 00 00 00 00 00  mov64 r6, r0
000fd7c8: 85 10 00 00 35 94 ff ff  call -0x6bcb ; call 0xc7978 __rust_dealloc
000fd7d0: bf 60 00 00 00 00 00 00  mov64 r0, r6
000fd7d8: 95 00 00 00 00 00 00 00  exit
