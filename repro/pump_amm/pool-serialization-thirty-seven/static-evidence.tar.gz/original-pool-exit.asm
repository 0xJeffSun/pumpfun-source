00004210: bf 27 00 00 00 00 00 00  mov64 r7, r2
00004218: bf 16 00 00 00 00 00 00  mov64 r6, r1
00004220: bf 31 00 00 00 00 00 00  mov64 r1, r3
00004228: bf 42 00 00 00 00 00 00  mov64 r2, r4
00004230: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00004238: 85 10 00 00 d4 2a 02 00  call 0x22ad4 ; call 0x1198e0 memcmp
00004240: b7 09 00 00 02 00 00 00  mov64 r9, 0x2
00004248: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00004250: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
00004258: 55 00 c8 00 00 00 00 00  jne r0, 0x0, +0xc8 <.text+0x4780> ; branch 0x48a0
00004260: 79 78 00 00 00 00 00 00  ldxdw r8, [r7 + 0x0]
00004268: bf 81 00 00 00 00 00 00  mov64 r1, r8
00004270: 85 10 00 00 9a fd 01 00  call 0x1fd9a ; call 0x102f48 _ZN11anchor_lang6common9is_closed17h44e46358caf480deE
00004278: 55 00 c4 00 00 00 00 00  jne r0, 0x0, +0xc4 <.text+0x4780> ; branch 0x48a0
00004280: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004288: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004290: bf 82 00 00 00 00 00 00  mov64 r2, r8
00004298: 85 10 00 00 ef 09 02 00  call 0x209ef ; call 0x109218 _ZN19solana_account_info11AccountInfo19try_borrow_mut_data17h2fe7bf8bc6a14d92E
000042a0: 79 a8 e8 ff 00 00 00 00  ldxdw r8, [r10 - 0x18]
000042a8: 79 a1 e0 ff 00 00 00 00  ldxdw r1, [r10 - 0x20]
000042b0: 79 a2 d8 ff 00 00 00 00  ldxdw r2, [r10 - 0x28]
000042b8: 18 03 00 00 1a 00 00 00 00 00 00 00 00 00 00 80  lddw r3, -0x7fffffffffffffe6
000042c8: 5d 32 a4 00 00 00 00 00  jne r2, r3, +0xa4 <.text+0x46d0> ; branch 0x47f0
000042d0: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
000042d8: 79 11 08 00 00 00 00 00  ldxdw r1, [r1 + 0x8]
000042e0: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000042e8: 7b 2a d8 ff 00 00 00 00  stxdw [r10 - 0x28], r2
000042f0: 7a 0a e8 ff 00 00 00 00  stdw [r10 - 0x18], 0x0
000042f8: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004300: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004308: 18 02 00 00 0e c6 11 00 00 00 00 00 00 00 00 00  lddw r2, 0x11c60e ; data 0x11c60e b'\xf1\x9am\x04\x11\xb1m\xbc\xca*\xf6+\x8e\xbe\x1e\xffDeadlockdeadlock\x95\x08\x9c\xca\xa0\xfc\xb0\xd9lamportsend_time__event_authorityGlobalV'
00004318: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00004320: 85 10 00 00 d5 fc 01 00  call 0x1fcd5 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004328: 55 00 a3 00 00 00 00 00  jne r0, 0x0, +0xa3 <.text+0x4728> ; branch 0x4848
00004330: bf 72 00 00 00 00 00 00  mov64 r2, r7
00004338: 07 02 00 00 1a 01 00 00  add64 r2, 0x11a
00004340: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004348: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004350: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004358: 85 10 00 00 ce fc 01 00  call 0x1fcce ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004360: 55 00 9c 00 00 00 00 00  jne r0, 0x0, +0x9c <.text+0x4728> ; branch 0x4848
00004368: 69 71 18 01 00 00 00 00  ldxh r1, [r7 + 0x118]
00004370: 6b 1a f0 ff 00 00 00 00  stxh [r10 - 0x10], r1
00004378: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004380: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004388: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004390: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004398: b7 03 00 00 02 00 00 00  mov64 r3, 0x2
000043a0: 85 10 00 00 c5 fc 01 00  call 0x1fcc5 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000043a8: 55 00 93 00 00 00 00 00  jne r0, 0x0, +0x93 <.text+0x4728> ; branch 0x4848
000043b0: bf 72 00 00 00 00 00 00  mov64 r2, r7
000043b8: 07 02 00 00 08 00 00 00  add64 r2, 0x8
000043c0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000043c8: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000043d0: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000043d8: 85 10 00 00 be fc 01 00  call 0x1fcbe ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000043e0: 55 00 8c 00 00 00 00 00  jne r0, 0x0, +0x8c <.text+0x4728> ; branch 0x4848
000043e8: bf 72 00 00 00 00 00 00  mov64 r2, r7
000043f0: 07 02 00 00 28 00 00 00  add64 r2, 0x28
000043f8: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004400: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004408: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00004410: 85 10 00 00 b7 fc 01 00  call 0x1fcb7 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004418: 55 00 85 00 00 00 00 00  jne r0, 0x0, +0x85 <.text+0x4728> ; branch 0x4848
00004420: bf 72 00 00 00 00 00 00  mov64 r2, r7
00004428: 07 02 00 00 48 00 00 00  add64 r2, 0x48
00004430: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004438: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004440: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00004448: 85 10 00 00 b0 fc 01 00  call 0x1fcb0 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004450: 55 00 7e 00 00 00 00 00  jne r0, 0x0, +0x7e <.text+0x4728> ; branch 0x4848
00004458: bf 72 00 00 00 00 00 00  mov64 r2, r7
00004460: 07 02 00 00 68 00 00 00  add64 r2, 0x68
00004468: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004470: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004478: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00004480: 85 10 00 00 a9 fc 01 00  call 0x1fca9 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004488: 55 00 77 00 00 00 00 00  jne r0, 0x0, +0x77 <.text+0x4728> ; branch 0x4848
00004490: bf 72 00 00 00 00 00 00  mov64 r2, r7
00004498: 07 02 00 00 88 00 00 00  add64 r2, 0x88
000044a0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000044a8: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000044b0: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000044b8: 85 10 00 00 a2 fc 01 00  call 0x1fca2 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000044c0: 55 00 70 00 00 00 00 00  jne r0, 0x0, +0x70 <.text+0x4728> ; branch 0x4848
000044c8: bf 72 00 00 00 00 00 00  mov64 r2, r7
000044d0: 07 02 00 00 a8 00 00 00  add64 r2, 0xa8
000044d8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000044e0: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000044e8: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000044f0: 85 10 00 00 9b fc 01 00  call 0x1fc9b ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000044f8: 55 00 69 00 00 00 00 00  jne r0, 0x0, +0x69 <.text+0x4728> ; branch 0x4848
00004500: 79 71 f8 00 00 00 00 00  ldxdw r1, [r7 + 0xf8]
00004508: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
00004510: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004518: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004520: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004528: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004530: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00004538: 85 10 00 00 92 fc 01 00  call 0x1fc92 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004540: 55 00 60 00 00 00 00 00  jne r0, 0x0, +0x60 <.text+0x4728> ; branch 0x4848
00004548: bf 72 00 00 00 00 00 00  mov64 r2, r7
00004550: 07 02 00 00 c8 00 00 00  add64 r2, 0xc8
00004558: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004560: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004568: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00004570: 85 10 00 00 8b fc 01 00  call 0x1fc8b ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004578: 55 00 59 00 00 00 00 00  jne r0, 0x0, +0x59 <.text+0x4728> ; branch 0x4848
00004580: 71 71 1b 01 00 00 00 00  ldxb r1, [r7 + 0x11b]
00004588: 73 1a f0 ff 00 00 00 00  stxb [r10 - 0x10], r1
00004590: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004598: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000045a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000045a8: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
000045b0: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000045b8: 85 10 00 00 82 fc 01 00  call 0x1fc82 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000045c0: 55 00 50 00 00 00 00 00  jne r0, 0x0, +0x50 <.text+0x4728> ; branch 0x4848
000045c8: 71 71 1c 01 00 00 00 00  ldxb r1, [r7 + 0x11c]
000045d0: 73 1a f0 ff 00 00 00 00  stxb [r10 - 0x10], r1
000045d8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000045e0: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000045e8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000045f0: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
000045f8: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004600: 85 10 00 00 79 fc 01 00  call 0x1fc79 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004608: 55 00 47 00 00 00 00 00  jne r0, 0x0, +0x47 <.text+0x4728> ; branch 0x4848
00004610: 79 71 e8 00 00 00 00 00  ldxdw r1, [r7 + 0xe8]
00004618: 79 72 f0 00 00 00 00 00  ldxdw r2, [r7 + 0xf0]
00004620: 7b 2a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r2
00004628: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
00004630: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004638: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004640: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004648: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004650: b7 03 00 00 10 00 00 00  mov64 r3, 0x10
00004658: 85 10 00 00 6e fc 01 00  call 0x1fc6e ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004660: 55 00 3c 00 00 00 00 00  jne r0, 0x0, +0x3c <.text+0x4728> ; branch 0x4848
00004668: 79 71 00 01 00 00 00 00  ldxdw r1, [r7 + 0x100]
00004670: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
00004678: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004680: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004688: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004690: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004698: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
000046a0: 85 10 00 00 65 fc 01 00  call 0x1fc65 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000046a8: 55 00 33 00 00 00 00 00  jne r0, 0x0, +0x33 <.text+0x4728> ; branch 0x4848
000046b0: 71 71 1d 01 00 00 00 00  ldxb r1, [r7 + 0x11d]
000046b8: 73 1a f0 ff 00 00 00 00  stxb [r10 - 0x10], r1
000046c0: bf a1 00 00 00 00 00 00  mov64 r1, r10
000046c8: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000046d0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000046d8: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
000046e0: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
000046e8: 85 10 00 00 5c fc 01 00  call 0x1fc5c ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000046f0: 55 00 2a 00 00 00 00 00  jne r0, 0x0, +0x2a <.text+0x4728> ; branch 0x4848
000046f8: 71 71 1e 01 00 00 00 00  ldxb r1, [r7 + 0x11e]
00004700: 73 1a f0 ff 00 00 00 00  stxb [r10 - 0x10], r1
00004708: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004710: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004718: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004720: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004728: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004730: 85 10 00 00 53 fc 01 00  call 0x1fc53 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004738: 55 00 21 00 00 00 00 00  jne r0, 0x0, +0x21 <.text+0x4728> ; branch 0x4848
00004740: 79 71 08 01 00 00 00 00  ldxdw r1, [r7 + 0x108]
00004748: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
00004750: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004758: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
00004760: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004768: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
00004770: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00004778: 85 10 00 00 4a fc 01 00  call 0x1fc4a ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004780: 55 00 18 00 00 00 00 00  jne r0, 0x0, +0x18 <.text+0x4728> ; branch 0x4848
00004788: 79 71 10 01 00 00 00 00  ldxdw r1, [r7 + 0x110]
00004790: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
00004798: bf a1 00 00 00 00 00 00  mov64 r1, r10
000047a0: 07 01 00 00 d8 ff ff ff  add64 r1, -0x28
000047a8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000047b0: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
000047b8: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
000047c0: 85 10 00 00 41 fc 01 00  call 0x1fc41 ; call 0x1029d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000047c8: 55 00 0f 00 00 00 00 00  jne r0, 0x0, +0xf <.text+0x4728> ; branch 0x4848
000047d0: 79 81 00 00 00 00 00 00  ldxdw r1, [r8 + 0x0]
000047d8: 07 01 00 00 01 00 00 00  add64 r1, 0x1
000047e0: 7b 18 00 00 00 00 00 00  stxdw [r8 + 0x0], r1
000047e8: 05 00 16 00 00 00 00 00  ja +0x16 <.text+0x4780> ; branch 0x48a0
000047f0: 7b 8a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r8
000047f8: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
00004800: 7b 2a d8 ff 00 00 00 00  stxdw [r10 - 0x28], r2
00004808: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004810: 07 01 00 00 c8 ff ff ff  add64 r1, -0x38
00004818: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004820: 07 02 00 00 d8 ff ff ff  add64 r2, -0x28
00004828: 85 10 00 00 02 fd 01 00  call 0x1fd02 ; call 0x103040 _ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he510612a1c8a4b27E
00004830: 79 a1 d0 ff 00 00 00 00  ldxdw r1, [r10 - 0x30]
00004838: 79 a9 c8 ff 00 00 00 00  ldxdw r9, [r10 - 0x38]
00004840: 05 00 0b 00 00 00 00 00  ja +0xb <.text+0x4780> ; branch 0x48a0
00004848: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004850: 07 01 00 00 b8 ff ff ff  add64 r1, -0x48
00004858: bf 02 00 00 00 00 00 00  mov64 r2, r0
00004860: 85 10 00 00 0f fd 01 00  call 0x1fd0f ; call 0x1030e0 _ZN94_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$std..io..error..Error$GT$$GT$4from17h0b723e6bf3ace3d2E
00004868: 79 a1 c0 ff 00 00 00 00  ldxdw r1, [r10 - 0x40]
00004870: 79 a2 b8 ff 00 00 00 00  ldxdw r2, [r10 - 0x48]
00004878: 79 83 00 00 00 00 00 00  ldxdw r3, [r8 + 0x0]
00004880: 07 03 00 00 01 00 00 00  add64 r3, 0x1
00004888: 7b 38 00 00 00 00 00 00  stxdw [r8 + 0x0], r3
00004890: 15 02 01 00 02 00 00 00  jeq r2, 0x2, +0x1 <.text+0x4780> ; branch 0x48a0
00004898: bf 29 00 00 00 00 00 00  mov64 r9, r2
000048a0: 7b 16 08 00 00 00 00 00  stxdw [r6 + 0x8], r1
000048a8: 7b 96 00 00 00 00 00 00  stxdw [r6 + 0x0], r9
000048b0: 95 00 00 00 00 00 00 00  exit
