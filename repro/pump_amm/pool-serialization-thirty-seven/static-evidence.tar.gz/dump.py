#!/usr/bin/env python3
"""Disassemble and byte-verify selected frozen windows; no executable changes."""
from pathlib import Path
import bisect, gzip, hashlib, json, re, struct, subprocess, sys
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'))
from elf_reader import Elf
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((W/'inputs.json').read_bytes())
rows=json.loads(gzip.decompress((W/'function-catalog.json.gz').read_bytes()))
by={r['start']:r for r in rows}
elfs={label:Elf(ROOT/inputs[label]['path'])for label in ['original','candidate']}
tool=ROOT/'work/pump-amm-serializer-only/build/sdk/dependencies/platform-tools/llvm/bin/llvm-objdump'
toolinfo={'path':str(tool.resolve()),'sha256':sha(tool.read_bytes()),'version':subprocess.check_output([str(tool),'--version'],text=True),'scope':'Disassembly only; this is not a new source build or a historical compiler claim'}
(W/'disassembler.json').write_text(json.dumps(toolinfo,indent=2)+'\n')
starts={'original':{'pool-exit':0x4210},'candidate':{'pool-exit':0x3c38}}
for label,e in elfs.items():
    start=starts[label]['pool-exit'];end=e.entries[bisect.bisect_right(e.entries,start)]
    for call in e.callsites(start,end-start):
        target=call['target']
        starts[label][f'callee-{target:x}']=target
# Include candidate's known From<io::Error> body for comparison with the original's
# authentic direct callee, although the current Pool exit does not call it.
starts['candidate']['io-error-conversion-reference']=0xee9e0
starts['original']['program-io-conversion']=0x10a410
starts['candidate']['program-io-conversion']=0xf5650
manifest=[]
for label,selected in starts.items():
    e=elfs[label]
    for name,start in selected.items():
        end=e.entries[bisect.bisect_right(e.entries,start)]
        if label=='candidate':
            symbol=by[start];assert symbol['bytes']==end-start,(name,symbol,end-start)
        else:symbol=None
        proc=subprocess.run([str(tool),'-d',f'--start-address={start}',f'--stop-address={end}',str(e.path)],capture_output=True,text=True)
        assert proc.returncode==0,proc.stderr
        (W/f'{label}-{name}.raw-objdump.txt').write_text(proc.stdout)
        records=[]
        for line in proc.stdout.splitlines():
            m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2} )+[0-9a-f]{2})\s+(.+)',line)
            if not m:continue
            at=int(m[1],16);raw=bytes.fromhex(m[2]);assert start<=at<end
            assert e.b[at:at+len(raw)]==raw
            r={'at':hex(at),'offset':at-start,'raw_hex':raw.hex(),'instruction':m[3]};extra=[]
            if at in e.calls:
                target=e.calls[at];r['call_target']=hex(target)
                target_rows=[x for x in rows if target in x['matches']]if label=='original'else[by.get(target,{})]
                r['candidate_names']=[n for x in target_rows for n in x.get('names',[])]
                extra.append('call '+hex(target)+' '+','.join(r['candidate_names']))
            if at in e.relocations:
                reloc=e.relocations[at];r['relocation']=reloc
                if reloc['type']==10:extra.append('external '+reloc['symbol'])
                elif raw[0]==0x18:
                    pointer=struct.unpack_from('<I',raw,4)[0]|struct.unpack_from('<I',raw,12)[0]<<32
                    r['pointer']=hex(pointer);r['data80_hex']=e.b[pointer:pointer+80].hex();extra.append('data '+hex(pointer)+' '+repr(e.b[pointer:pointer+80]))
            if raw[0]&7==5 and raw[0]not in[0x85,0x8d,0x95]:
                displacement=struct.unpack_from('<h',raw,2)[0];target=at+8+8*displacement
                r['branch_displacement']=displacement;r['branch_target']=hex(target);extra.append('branch '+hex(target))
            r['annotated']=f'{at:08x}: {m[2]}  {m[3]}'+(' ; '+' ; '.join(extra)if extra else'')
            records.append(r)
        assert sum(len(bytes.fromhex(r['raw_hex']))for r in records)==end-start,(label,name,start,end)
        (W/f'{label}-{name}.json').write_text(json.dumps(records,indent=2)+'\n')
        (W/f'{label}-{name}.asm').write_text('\n'.join(r['annotated']for r in records)+'\n')
        manifest.append({'label':label,'name':name,'start':hex(start),'end':hex(end),'bytes':end-start,'raw_sha256':sha(e.b[start:end]),'normalized_sha256':sha(e.normalized[start:end]),'relocations':e.pattern(start,end-start),'candidate_symbol':symbol,'dump_bytes_verified':True})
(W/'windows.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps([{'label':r['label'],'name':r['name'],'start':r['start'],'bytes':r['bytes']}for r in manifest],indent=2))
