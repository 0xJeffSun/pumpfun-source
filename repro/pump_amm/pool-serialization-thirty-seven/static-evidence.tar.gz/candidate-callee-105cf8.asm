00105cf8: 62 0a fc ff 00 00 00 00  stw [r10 - 0x4], 0x0
00105d00: bf a4 00 00 00 00 00 00  mov64 r4, r10
00105d08: 07 04 00 00 fc ff ff ff  add64 r4, -0x4
00105d10: 85 10 00 00 ff ff ff ff  call -0x1 ; external sol_memcmp_
00105d18: 61 a0 fc ff 00 00 00 00  ldxw r0, [r10 - 0x4]
00105d20: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00105d28: c7 00 00 00 20 00 00 00  arsh64 r0, 0x20
00105d30: 95 00 00 00 00 00 00 00  exit
