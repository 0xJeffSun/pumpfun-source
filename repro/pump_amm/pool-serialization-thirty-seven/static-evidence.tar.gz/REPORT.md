# AMM Pool exit: independently supported error-conversion correction

The captured original Pool exit sends the discriminator write and every field
write failure through Anchor's `From<io::Error>` implementation. Current AMM37
instead expands two `e.to_string()` conversions into the exit body and then calls
`From<ProgramError>`. The bounded correction is the three-line body in
`suggested-pool-serializer.patch`: `writer.write_all(Self::DISCRIMINATOR)?;`,
`self.serialize(writer)?;`, `Ok(())`. This static package does not apply or build
that patch and makes no new behavioral-equivalence claim.

## Frozen inputs and scope

- Candidate: `repro/pump_amm/serialization-thirty-seven/pump_amm_recovered.so`,
  1,176,640 bytes, SHA-256
  `b656628b9f43c1b18edecbe58f8275be3829c52604a1926f540dcdb64eb8f257`.
- Original: `evidence/original/pump_amm/deployed.so`, 10,485,715 bytes, SHA-256
  `6a7ad34596d83b4c435b32f458a56e718e9f82eb4ad38e4316616d15d24d8ff7`.
- All 18 source/Cargo inputs match the published build manifest, its source
  archive, and current AMM main paths. Copies are under `source-snapshot/`.
- The pre-existing unstripped symbol ELF has SHA-256
  `82529a569bccdcb055015e1d9152633c56c3b622c69adb5bbe401e033ecb4236`;
  its complete text bytes equal the published candidate's text. It supplies
  candidate symbol names, not invented original symbols.
- `inputs.json`, `windows.json` and the manifest bind the inputs and all selected
  instruction windows. The disassembler is recorded separately and was used
  only to print existing bytes; it is not a new build or historical compiler claim.
- No source mutation, runtime fixture/probe, compiler/flag/layout search,
  executable patch, or `create_config` initializer analysis occurred. The
  suggested patch remains uncompiled in this frozen static record. New handlers
  and runtime receipts are zero; whole-file equality remains false.

## Pair identification and exact boundaries

| Window | Byte addresses | Bytes | Raw SHA-256 |
|---|---|---:|---|
| Original Pool exit | `0x4210..0x48b8` | 1,704 | `10dfb5d9f97ed2db83af235c91c7cd4994ded334b22c748cf833c13b0b030235` |
| Current candidate Pool exit | `0x3c38..0x4628` | 2,544 | `cba9070343aded067ddc0567c2bc9109c12c7d2c60ca95bc0ba8aca04ddb39df` |

The candidate symbol is
`Account<T>::exit_with_expected_owner` ending in hash `2c31418f4bfed1b7`.
Its symbol size and inferred next-entry boundary agree. Original boundaries are
entry/call-target based, not recovered debug symbols. The original and candidate
each have exactly one relocated text reference to the eight-byte Pool
discriminator `f19a6d0411b16dbc`: original `0x4308 → 0x11c60e`, candidate
`0x3d38 → 0x108e8b`. Both write that exact eight-byte value and then the same
18 Pool fields, with the captured IDL's widths/order, totaling 287 bytes.

`field-write-correspondence.json` records every call, field source offset, width,
serialized offset and error branch. The observed Account-wrapper memory offsets
are identical on both sides (the register holding the wrapper differs):
`0x11a, 0x118, 0x8, 0x28, 0x48, 0x68, 0x88, 0xa8, 0xf8, 0xc8,
0x11b, 0x11c, 0xe8, 0x100, 0x11d, 0x11e, 0x108, 0x110`.
These are Rust-memory offsets, not serialized account offsets. This comparison
does not suggest changing Pool's field declarations or its legacy decoder.

## Error dataflow

Original `0x4320` writes the discriminator. Its failure branch at `0x4328`
has raw displacement `+163`, hence target `0x4328 + 8 + 163*8 = 0x4848`.
All 18 following field-write failures reach that same block. At `0x4858` the
unmodified I/O error in `r0` is moved into argument register `r2`; the call at
`0x4860` targets `0x1030e0`, the complete 176-byte Anchor I/O-error conversion.
The borrowed-account counter is then restored and the resulting error returned.
The separate borrow-data failure goes to `From<ProgramError>` at
`0x4828 → 0x103040`; this path is already appropriate and should not change.

Candidate discriminator failure branches at `0x3d68` (`+185`) to `0x4338`.
Each later field failure reaches `0x4290`; for example `0x3da0` (`+157`) reaches
that block. These two paths call I/O-error `Display::fmt` at `0x43c8` and `0x4320`
respectively, target `0xfd4a8`. They have separate string/error cleanup paths and
eventually call `From<ProgramError>` at `0x44f8` and `0x45b0`. The inlined
formatting includes a possible `unwrap_failed` call at `0x4420`, with the literal
`a Display implementation returned an error unexpectedly`. Those extra blocks
and references account for the observed different conversion shape; merely
rewriting registers or branches would not repair the source-level distinction.

The candidate already contains a 176-byte `From<io::Error>` helper at `0xee9e0`.
Its complete body and relocation pattern match original `0x1030e0` after only
declared call/relocation-immediate normalization in memory. Original call
`0x1030f8 → 0x10a410` corresponds to candidate `0xee9f8 → 0xf5650`:
the complete `ProgramError::from(io::Error)` bodies also match. This is independent
evidence for the intended conversion, not an inference from GlobalConfig alone.

The frozen Cargo.lock pins Anchor 0.31.1 and solana-program-error 2.2.2. Their
locally cached `.crate` hashes match the lockfile and published cache manifest;
the exact relevant files are retained under `framework-source/`. Anchor's
`error.rs:305–308` routes `BorshIoError` to `ProgramError::from(error)`, and
solana-program-error's `lib.rs:376–380` constructs `BorshIoError(format!("{error}"))`.
This explains the current direct `.to_string()` expansion versus the authentic
out-of-line conversion. It does not establish unique historical source spelling
or the original dependency versions.

## Direct callees and relocations

All six unique original direct targets have complete normalized candidate
counterparts with matching relocation patterns:

| Role | Original | Candidate | Bytes | Called by current candidate Pool? |
|---|---|---|---:|---|
| `memcmp` | `0x1198e0` | `0x105cf8` | 64 | Yes |
| `is_closed` | `0x102f48` | `0xee848` | 112 | Yes |
| `try_borrow_mut_data` | `0x109218` | `0xf4458` | 120 | Yes |
| `BpfWriter::write_all` | `0x1029d0` | `0xee2d0` | 288 | Yes |
| `Error::from(ProgramError)` | `0x103040` | `0xee940` | 160 | Yes |
| `Error::from(io::Error)` | `0x1030e0` | `0xee9e0` | 176 | No |

The original exit has one relocation: the Pool discriminator at offset 248.
The candidate has six: offsets 256, 1656, 1824, 1968, 1992 and 2008. The additional
five reference formatting vtables, the formatting-failure string, and panic/source
data. Every referenced address and its next 80 raw bytes are retained in the
annotated JSON. Only the consumed discriminator's eight bytes are claimed equal;
adjacent rodata is not silently normalized. Candidate-only direct callees include
`Display::fmt` and `unwrap_failed`. Their actual windows are preserved too.

## Proposed next validation, not performed here

Apply only the frozen patch in a fresh isolated source copy, build once with the
existing pinned v1.44 recipe, compare its complete Pool exit and direct targets,
then run the existing 25 AMM suites/17,462 cases on the resulting artifact if
separately authorized. No new fixture is needed to justify this source lead.
The patch's exact SHA-256 is
`8aaeb99665e7b0ae2f93c9e427fa8888a48dcc3b82ca8b848f7d37c7dd5bee34`.
