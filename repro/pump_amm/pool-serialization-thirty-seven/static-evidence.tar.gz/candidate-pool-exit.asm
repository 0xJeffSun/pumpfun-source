00003c38: bf 29 00 00 00 00 00 00  mov64 r9, r2
00003c40: bf 16 00 00 00 00 00 00  mov64 r6, r1
00003c48: bf 31 00 00 00 00 00 00  mov64 r1, r3
00003c50: bf 42 00 00 00 00 00 00  mov64 r2, r4
00003c58: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003c60: 85 10 00 00 12 04 02 00  call 0x20412 ; call 0x105cf8 memcmp
00003c68: b7 01 00 00 02 00 00 00  mov64 r1, 0x2
00003c70: 67 00 00 00 20 00 00 00  lsh64 r0, 0x20
00003c78: 77 00 00 00 20 00 00 00  rsh64 r0, 0x20
00003c80: 55 00 18 01 00 00 00 00  jne r0, 0x0, +0x118 <.text+0x4428> ; branch 0x4548
00003c88: 79 98 00 00 00 00 00 00  ldxdw r8, [r9 + 0x0]
00003c90: bf 81 00 00 00 00 00 00  mov64 r1, r8
00003c98: 85 10 00 00 75 d5 01 00  call 0x1d575 ; call 0xee848 _ZN11anchor_lang6common9is_closed17h44e46358caf480deE
00003ca0: b7 01 00 00 02 00 00 00  mov64 r1, 0x2
00003ca8: 55 00 13 01 00 00 00 00  jne r0, 0x0, +0x113 <.text+0x4428> ; branch 0x4548
00003cb0: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003cb8: 07 01 00 00 b8 ff ff ff  add64 r1, -0x48
00003cc0: bf 82 00 00 00 00 00 00  mov64 r2, r8
00003cc8: 85 10 00 00 f1 e0 01 00  call 0x1e0f1 ; call 0xf4458 _ZN19solana_account_info11AccountInfo19try_borrow_mut_data17h2fe7bf8bc6a14d92E
00003cd0: 79 a7 c8 ff 00 00 00 00  ldxdw r7, [r10 - 0x38]
00003cd8: 79 a1 c0 ff 00 00 00 00  ldxdw r1, [r10 - 0x40]
00003ce0: 79 a2 b8 ff 00 00 00 00  ldxdw r2, [r10 - 0x48]
00003ce8: 18 03 00 00 1a 00 00 00 00 00 00 00 00 00 00 80  lddw r3, -0x7fffffffffffffe6
00003cf8: 5d 32 a7 00 00 00 00 00  jne r2, r3, +0xa7 <.text+0x4118> ; branch 0x4238
00003d00: 79 12 00 00 00 00 00 00  ldxdw r2, [r1 + 0x0]
00003d08: 79 11 08 00 00 00 00 00  ldxdw r1, [r1 + 0x8]
00003d10: 7b 1a 70 ff 00 00 00 00  stxdw [r10 - 0x90], r1
00003d18: 7b 2a 68 ff 00 00 00 00  stxdw [r10 - 0x98], r2
00003d20: 7a 0a 78 ff 00 00 00 00  stdw [r10 - 0x88], 0x0
00003d28: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003d30: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003d38: 18 02 00 00 8b 8e 10 00 00 00 00 00 00 00 00 00  lddw r2, 0x108e8b ; data 0x108e8b b'\xf1\x9am\x04\x11\xb1m\xbc\xe4E\xa5.Q\xcb\x9a\x1d\xca*\xf6+\x8e\xbe\x1e\xffDeadlockdeadlock\x95\x08\x9c\xca\xa0\xfc\xb0\xd9src/legacy_buy.rspool-authorityb'
00003d48: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00003d50: 85 10 00 00 af d4 01 00  call 0x1d4af ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003d58: bf 08 00 00 00 00 00 00  mov64 r8, r0
00003d60: 7b 7a 30 ff 00 00 00 00  stxdw [r10 - 0xd0], r7
00003d68: 55 08 b9 00 00 00 00 00  jne r8, 0x0, +0xb9 <.text+0x4218> ; branch 0x4338
00003d70: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003d78: 07 02 00 00 1a 01 00 00  add64 r2, 0x11a
00003d80: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003d88: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003d90: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00003d98: 85 10 00 00 a6 d4 01 00  call 0x1d4a6 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003da0: 55 00 9d 00 00 00 00 00  jne r0, 0x0, +0x9d <.text+0x4170> ; branch 0x4290
00003da8: 69 91 18 01 00 00 00 00  ldxh r1, [r9 + 0x118]
00003db0: 6b 1a b8 ff 00 00 00 00  stxh [r10 - 0x48], r1
00003db8: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003dc0: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003dc8: bf a2 00 00 00 00 00 00  mov64 r2, r10
00003dd0: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00003dd8: b7 03 00 00 02 00 00 00  mov64 r3, 0x2
00003de0: 85 10 00 00 9d d4 01 00  call 0x1d49d ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003de8: 55 00 94 00 00 00 00 00  jne r0, 0x0, +0x94 <.text+0x4170> ; branch 0x4290
00003df0: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003df8: 07 02 00 00 08 00 00 00  add64 r2, 0x8
00003e00: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003e08: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003e10: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003e18: 85 10 00 00 96 d4 01 00  call 0x1d496 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003e20: 55 00 8d 00 00 00 00 00  jne r0, 0x0, +0x8d <.text+0x4170> ; branch 0x4290
00003e28: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003e30: 07 02 00 00 28 00 00 00  add64 r2, 0x28
00003e38: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003e40: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003e48: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003e50: 85 10 00 00 8f d4 01 00  call 0x1d48f ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003e58: 55 00 86 00 00 00 00 00  jne r0, 0x0, +0x86 <.text+0x4170> ; branch 0x4290
00003e60: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003e68: 07 02 00 00 48 00 00 00  add64 r2, 0x48
00003e70: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003e78: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003e80: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003e88: 85 10 00 00 88 d4 01 00  call 0x1d488 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003e90: 55 00 7f 00 00 00 00 00  jne r0, 0x0, +0x7f <.text+0x4170> ; branch 0x4290
00003e98: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003ea0: 07 02 00 00 68 00 00 00  add64 r2, 0x68
00003ea8: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003eb0: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003eb8: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003ec0: 85 10 00 00 81 d4 01 00  call 0x1d481 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003ec8: 55 00 78 00 00 00 00 00  jne r0, 0x0, +0x78 <.text+0x4170> ; branch 0x4290
00003ed0: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003ed8: 07 02 00 00 88 00 00 00  add64 r2, 0x88
00003ee0: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003ee8: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003ef0: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003ef8: 85 10 00 00 7a d4 01 00  call 0x1d47a ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003f00: 55 00 71 00 00 00 00 00  jne r0, 0x0, +0x71 <.text+0x4170> ; branch 0x4290
00003f08: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003f10: 07 02 00 00 a8 00 00 00  add64 r2, 0xa8
00003f18: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003f20: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003f28: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003f30: 85 10 00 00 73 d4 01 00  call 0x1d473 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003f38: 55 00 6a 00 00 00 00 00  jne r0, 0x0, +0x6a <.text+0x4170> ; branch 0x4290
00003f40: 79 91 f8 00 00 00 00 00  ldxdw r1, [r9 + 0xf8]
00003f48: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
00003f50: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003f58: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003f60: bf a2 00 00 00 00 00 00  mov64 r2, r10
00003f68: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00003f70: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00003f78: 85 10 00 00 6a d4 01 00  call 0x1d46a ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003f80: 55 00 61 00 00 00 00 00  jne r0, 0x0, +0x61 <.text+0x4170> ; branch 0x4290
00003f88: bf 92 00 00 00 00 00 00  mov64 r2, r9
00003f90: 07 02 00 00 c8 00 00 00  add64 r2, 0xc8
00003f98: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003fa0: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003fa8: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
00003fb0: 85 10 00 00 63 d4 01 00  call 0x1d463 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00003fb8: 55 00 5a 00 00 00 00 00  jne r0, 0x0, +0x5a <.text+0x4170> ; branch 0x4290
00003fc0: 71 91 1b 01 00 00 00 00  ldxb r1, [r9 + 0x11b]
00003fc8: 73 1a b8 ff 00 00 00 00  stxb [r10 - 0x48], r1
00003fd0: bf a1 00 00 00 00 00 00  mov64 r1, r10
00003fd8: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00003fe0: bf a2 00 00 00 00 00 00  mov64 r2, r10
00003fe8: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00003ff0: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00003ff8: 85 10 00 00 5a d4 01 00  call 0x1d45a ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004000: 55 00 51 00 00 00 00 00  jne r0, 0x0, +0x51 <.text+0x4170> ; branch 0x4290
00004008: 71 91 1c 01 00 00 00 00  ldxb r1, [r9 + 0x11c]
00004010: 73 1a b8 ff 00 00 00 00  stxb [r10 - 0x48], r1
00004018: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004020: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00004028: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004030: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004038: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004040: 85 10 00 00 51 d4 01 00  call 0x1d451 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004048: 55 00 48 00 00 00 00 00  jne r0, 0x0, +0x48 <.text+0x4170> ; branch 0x4290
00004050: 79 91 e8 00 00 00 00 00  ldxdw r1, [r9 + 0xe8]
00004058: 79 92 f0 00 00 00 00 00  ldxdw r2, [r9 + 0xf0]
00004060: 7b 2a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r2
00004068: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
00004070: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004078: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00004080: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004088: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004090: b7 03 00 00 10 00 00 00  mov64 r3, 0x10
00004098: 85 10 00 00 46 d4 01 00  call 0x1d446 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000040a0: 55 00 3d 00 00 00 00 00  jne r0, 0x0, +0x3d <.text+0x4170> ; branch 0x4290
000040a8: 79 91 00 01 00 00 00 00  ldxdw r1, [r9 + 0x100]
000040b0: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000040b8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000040c0: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
000040c8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000040d0: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000040d8: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
000040e0: 85 10 00 00 3d d4 01 00  call 0x1d43d ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000040e8: 55 00 34 00 00 00 00 00  jne r0, 0x0, +0x34 <.text+0x4170> ; branch 0x4290
000040f0: 71 91 1d 01 00 00 00 00  ldxb r1, [r9 + 0x11d]
000040f8: 73 1a b8 ff 00 00 00 00  stxb [r10 - 0x48], r1
00004100: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004108: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00004110: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004118: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004120: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004128: 85 10 00 00 34 d4 01 00  call 0x1d434 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004130: 55 00 2b 00 00 00 00 00  jne r0, 0x0, +0x2b <.text+0x4170> ; branch 0x4290
00004138: 71 91 1e 01 00 00 00 00  ldxb r1, [r9 + 0x11e]
00004140: 73 1a b8 ff 00 00 00 00  stxb [r10 - 0x48], r1
00004148: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004150: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
00004158: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004160: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004168: b7 03 00 00 01 00 00 00  mov64 r3, 0x1
00004170: 85 10 00 00 2b d4 01 00  call 0x1d42b ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004178: 55 00 22 00 00 00 00 00  jne r0, 0x0, +0x22 <.text+0x4170> ; branch 0x4290
00004180: 79 91 08 01 00 00 00 00  ldxdw r1, [r9 + 0x108]
00004188: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
00004190: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004198: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
000041a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000041a8: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000041b0: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
000041b8: 85 10 00 00 22 d4 01 00  call 0x1d422 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
000041c0: 55 00 19 00 00 00 00 00  jne r0, 0x0, +0x19 <.text+0x4170> ; branch 0x4290
000041c8: 79 91 10 01 00 00 00 00  ldxdw r1, [r9 + 0x110]
000041d0: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000041d8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000041e0: 07 01 00 00 68 ff ff ff  add64 r1, -0x98
000041e8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000041f0: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000041f8: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
00004200: 85 10 00 00 19 d4 01 00  call 0x1d419 ; call 0xee2d0 _ZN101_$LT$anchor_lang..bpf_writer..BpfWriter$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$u20$as$u20$std..io..Write$GT$9write_all17hf6a55be3d3dd5670E
00004208: 55 00 10 00 00 00 00 00  jne r0, 0x0, +0x10 <.text+0x4170> ; branch 0x4290
00004210: 79 71 00 00 00 00 00 00  ldxdw r1, [r7 + 0x0]
00004218: 07 01 00 00 01 00 00 00  add64 r1, 0x1
00004220: 7b 17 00 00 00 00 00 00  stxdw [r7 + 0x0], r1
00004228: b7 01 00 00 02 00 00 00  mov64 r1, 0x2
00004230: 05 00 62 00 00 00 00 00  ja +0x62 <.text+0x4428> ; branch 0x4548
00004238: 7b 7a c8 ff 00 00 00 00  stxdw [r10 - 0x38], r7
00004240: 7b 1a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r1
00004248: 7b 2a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r2
00004250: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004258: 07 01 00 00 58 ff ff ff  add64 r1, -0xa8
00004260: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004268: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004270: 85 10 00 00 d9 d4 01 00  call 0x1d4d9 ; call 0xee940 _ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he510612a1c8a4b27E
00004278: 79 a7 60 ff 00 00 00 00  ldxdw r7, [r10 - 0xa0]
00004280: 79 a1 58 ff 00 00 00 00  ldxdw r1, [r10 - 0xa8]
00004288: 05 00 57 00 00 00 00 00  ja +0x57 <.text+0x4428> ; branch 0x4548
00004290: 7b 0a 80 ff 00 00 00 00  stxdw [r10 - 0x80], r0
00004298: 7a 0a b0 ff 00 00 00 00  stdw [r10 - 0x50], 0x0
000042a0: 7a 0a a8 ff 01 00 00 00  stdw [r10 - 0x58], 0x1
000042a8: 7a 0a a0 ff 00 00 00 00  stdw [r10 - 0x60], 0x0
000042b0: 18 01 00 00 98 e4 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x10e498 ; data 0x10e498 b'\x00\x00\x00\x00\xc0\x8b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\x99\x00\x00\x00\x00\x00\x00\x90\x96\x00\x00\x00\x00\x00\x00\x08\x89\x00\x00\x00\x00\x00\x00\xb8\x8b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00`\x96\x00\x00'
000042c0: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000042c8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000042d0: 07 01 00 00 a0 ff ff ff  add64 r1, -0x60
000042d8: 7b 1a d8 ff 00 00 00 00  stxdw [r10 - 0x28], r1
000042e0: 72 0a f0 ff 03 00 00 00  stb [r10 - 0x10], 0x3
000042e8: 7a 0a e8 ff 20 00 00 00  stdw [r10 - 0x18], 0x20
000042f0: 7a 0a c8 ff 00 00 00 00  stdw [r10 - 0x38], 0x0
000042f8: 7a 0a b8 ff 00 00 00 00  stdw [r10 - 0x48], 0x0
00004300: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004308: 07 01 00 00 80 ff ff ff  add64 r1, -0x80
00004310: bf a2 00 00 00 00 00 00  mov64 r2, r10
00004318: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
00004320: 85 10 00 00 30 f2 01 00  call 0x1f230 ; call 0xfd4a8 _ZN60_$LT$std..io..error..Error$u20$as$u20$core..fmt..Display$GT$3fmt17h2070b5e55d34502fE
00004328: 15 00 46 00 00 00 00 00  jeq r0, 0x0, +0x46 <.text+0x4440> ; branch 0x4560
00004330: 05 00 14 00 00 00 00 00  ja +0x14 <.text+0x42b8> ; branch 0x43d8
00004338: 7b 8a 80 ff 00 00 00 00  stxdw [r10 - 0x80], r8
00004340: 7a 0a b0 ff 00 00 00 00  stdw [r10 - 0x50], 0x0
00004348: 7a 0a a8 ff 01 00 00 00  stdw [r10 - 0x58], 0x1
00004350: 7a 0a a0 ff 00 00 00 00  stdw [r10 - 0x60], 0x0
00004358: 18 01 00 00 98 e4 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x10e498 ; data 0x10e498 b'\x00\x00\x00\x00\xc0\x8b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\x99\x00\x00\x00\x00\x00\x00\x90\x96\x00\x00\x00\x00\x00\x00\x08\x89\x00\x00\x00\x00\x00\x00\xb8\x8b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00`\x96\x00\x00'
00004368: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
00004370: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004378: 07 01 00 00 a0 ff ff ff  add64 r1, -0x60
00004380: 7b 1a d8 ff 00 00 00 00  stxdw [r10 - 0x28], r1
00004388: 72 0a f0 ff 03 00 00 00  stb [r10 - 0x10], 0x3
00004390: 7a 0a e8 ff 20 00 00 00  stdw [r10 - 0x18], 0x20
00004398: 7a 0a c8 ff 00 00 00 00  stdw [r10 - 0x38], 0x0
000043a0: 7a 0a b8 ff 00 00 00 00  stdw [r10 - 0x48], 0x0
000043a8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000043b0: 07 01 00 00 80 ff ff ff  add64 r1, -0x80
000043b8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000043c0: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000043c8: 85 10 00 00 1b f2 01 00  call 0x1f21b ; call 0xfd4a8 _ZN60_$LT$std..io..error..Error$u20$as$u20$core..fmt..Display$GT$3fmt17h2070b5e55d34502fE
000043d0: 15 00 0a 00 00 00 00 00  jeq r0, 0x0, +0xa <.text+0x4308> ; branch 0x4428
000043d8: bf a3 00 00 00 00 00 00  mov64 r3, r10
000043e0: 07 03 00 00 ff ff ff ff  add64 r3, -0x1
000043e8: 18 01 00 00 76 88 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x108876 ; data 0x108876 b'a Display implementation returned an error unexpectedly/Users/runner/work/platfo'
000043f8: b7 02 00 00 37 00 00 00  mov64 r2, 0x37
00004400: 18 04 00 00 c8 e4 10 00 00 00 00 00 00 00 00 00  lddw r4, 0x10e4c8 ; data 0x10e4c8 b'\x00\x00\x00\x00\xb8\x8b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00`\x96\x00\x00\x00\x00\x00\x00\xad\x88\x10\x00U\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00L\x88\x10\x00\r\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x006\x00\x00\x00'
00004410: 18 05 00 00 e8 e4 10 00 00 00 00 00 00 00 00 00  lddw r5, 0x10e4e8 ; data 0x10e4e8 b'\x00\x00\x00\x00\xad\x88\x10\x00U\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00L\x88\x10\x00\r\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00\x006\x00\x00\x00\x00\x00\x00\x00L\x88\x10\x00\r\x00\x00\x00\x00\x00\x00\x00\xa9\x00\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00\x92\x8a\x10\x00'
00004420: 85 10 00 00 03 f7 01 00  call 0x1f703 ; call 0xffc40 _ZN4core6result13unwrap_failed17hd1eff923a9bd6719E
00004428: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
00004430: 7b 1a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r1
00004438: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
00004440: 7b 1a 90 ff 00 00 00 00  stxdw [r10 - 0x70], r1
00004448: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
00004450: 7b 1a 88 ff 00 00 00 00  stxdw [r10 - 0x78], r1
00004458: bf 81 00 00 00 00 00 00  mov64 r1, r8
00004460: 57 01 00 00 03 00 00 00  and64 r1, 0x3
00004468: bf 12 00 00 00 00 00 00  mov64 r2, r1
00004470: 07 02 00 00 fe ff ff ff  add64 r2, -0x2
00004478: a5 02 05 00 02 00 00 00  jlt r2, 0x2, +0x5 <.text+0x4388> ; branch 0x44a8
00004480: 15 01 04 00 00 00 00 00  jeq r1, 0x0, +0x4 <.text+0x4388> ; branch 0x44a8
00004488: 79 81 ff ff 00 00 00 00  ldxdw r1, [r8 - 0x1]
00004490: 79 82 07 00 00 00 00 00  ldxdw r2, [r8 + 0x7]
00004498: 79 22 00 00 00 00 00 00  ldxdw r2, [r2 + 0x0]
000044a0: 8d 00 00 00 02 00 00 00  callx r2
000044a8: 79 a1 98 ff 00 00 00 00  ldxdw r1, [r10 - 0x68]
000044b0: 7b 1a c8 ff 00 00 00 00  stxdw [r10 - 0x38], r1
000044b8: 79 a1 90 ff 00 00 00 00  ldxdw r1, [r10 - 0x70]
000044c0: 7b 1a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r1
000044c8: 79 a1 88 ff 00 00 00 00  ldxdw r1, [r10 - 0x78]
000044d0: 7b 1a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r1
000044d8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000044e0: 07 01 00 00 48 ff ff ff  add64 r1, -0xb8
000044e8: bf a2 00 00 00 00 00 00  mov64 r2, r10
000044f0: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000044f8: 85 10 00 00 88 d4 01 00  call 0x1d488 ; call 0xee940 _ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he510612a1c8a4b27E
00004500: 79 a7 50 ff 00 00 00 00  ldxdw r7, [r10 - 0xb0]
00004508: 79 a8 48 ff 00 00 00 00  ldxdw r8, [r10 - 0xb8]
00004510: 79 a2 30 ff 00 00 00 00  ldxdw r2, [r10 - 0xd0]
00004518: 79 21 00 00 00 00 00 00  ldxdw r1, [r2 + 0x0]
00004520: 07 01 00 00 01 00 00 00  add64 r1, 0x1
00004528: 7b 12 00 00 00 00 00 00  stxdw [r2 + 0x0], r1
00004530: b7 01 00 00 02 00 00 00  mov64 r1, 0x2
00004538: 15 08 01 00 02 00 00 00  jeq r8, 0x2, +0x1 <.text+0x4428> ; branch 0x4548
00004540: bf 81 00 00 00 00 00 00  mov64 r1, r8
00004548: 7b 76 08 00 00 00 00 00  stxdw [r6 + 0x8], r7
00004550: 7b 16 00 00 00 00 00 00  stxdw [r6 + 0x0], r1
00004558: 95 00 00 00 00 00 00 00  exit
00004560: 79 a1 b0 ff 00 00 00 00  ldxdw r1, [r10 - 0x50]
00004568: 7b 1a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r1
00004570: 79 a1 a8 ff 00 00 00 00  ldxdw r1, [r10 - 0x58]
00004578: 7b 1a 90 ff 00 00 00 00  stxdw [r10 - 0x70], r1
00004580: 79 a1 a0 ff 00 00 00 00  ldxdw r1, [r10 - 0x60]
00004588: 7b 1a 88 ff 00 00 00 00  stxdw [r10 - 0x78], r1
00004590: bf a1 00 00 00 00 00 00  mov64 r1, r10
00004598: 07 01 00 00 38 ff ff ff  add64 r1, -0xc8
000045a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000045a8: 07 02 00 00 88 ff ff ff  add64 r2, -0x78
000045b0: 85 10 00 00 71 d4 01 00  call 0x1d471 ; call 0xee940 _ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17he510612a1c8a4b27E
000045b8: 79 a7 40 ff 00 00 00 00  ldxdw r7, [r10 - 0xc0]
000045c0: 79 a8 38 ff 00 00 00 00  ldxdw r8, [r10 - 0xc8]
000045c8: 79 a2 80 ff 00 00 00 00  ldxdw r2, [r10 - 0x80]
000045d0: bf 21 00 00 00 00 00 00  mov64 r1, r2
000045d8: 57 01 00 00 03 00 00 00  and64 r1, 0x3
000045e0: bf 13 00 00 00 00 00 00  mov64 r3, r1
000045e8: 07 03 00 00 fe ff ff ff  add64 r3, -0x2
000045f0: a5 03 e3 ff 02 00 00 00  jlt r3, 0x2, -0x1d <.text+0x43f0> ; branch 0x4510
000045f8: 15 01 e2 ff 00 00 00 00  jeq r1, 0x0, -0x1e <.text+0x43f0> ; branch 0x4510
00004600: 79 21 ff ff 00 00 00 00  ldxdw r1, [r2 - 0x1]
00004608: 79 22 07 00 00 00 00 00  ldxdw r2, [r2 + 0x7]
00004610: 79 22 00 00 00 00 00 00  ldxdw r2, [r2 + 0x0]
00004618: 8d 00 00 00 02 00 00 00  callx r2
00004620: 05 00 dd ff 00 00 00 00  ja -0x23 <.text+0x43f0> ; branch 0x4510
