#!/usr/bin/env python3
"""Read-only AMM Pool exit indexing. No build, execution, or executable mutation."""
from pathlib import Path
import bisect, datetime, gzip, hashlib, json, struct, sys, tarfile

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sys.path.insert(0, str(ROOT / 'repro/pump_fees/framework-matching'))
from elf_reader import Elf
sha = lambda b: hashlib.sha256(b).hexdigest()
package = ROOT / 'repro/pump_amm/serialization-thirty-seven'
original = Elf(ROOT / 'evidence/original/pump_amm/deployed.so')
candidate = Elf(package / 'pump_amm_recovered.so')
symbols = Elf(ROOT / 'work/pump-amm-serializer-only/build/target/sbf-solana-solana/release/pump_amm_recovered.so')
assert sha(candidate.b) == 'b656628b9f43c1b18edecbe58f8275be3829c52604a1926f540dcdb64eb8f257'
assert sha(original.b) == '6a7ad34596d83b4c435b32f458a56e718e9f82eb4ad38e4316616d15d24d8ff7'
assert sha(symbols.b) == '82529a569bccdcb055015e1d9152633c56c3b622c69adb5bbe401e033ecb4236'
assert candidate.b[candidate.lo:candidate.hi] == symbols.b[symbols.lo:symbols.hi]
build = json.loads((package / 'build-comparison.json').read_bytes())
assert len(build['source_sha256']) == 18
source = []
with tarfile.open(package / 'source-snapshot.tar.gz', 'r:gz') as stream:
    saved = {m.name: stream.extractfile(m).read() for m in stream.getmembers() if m.isfile()}
for name, digest in build['source_sha256'].items():
    data = (ROOT / name).read_bytes()
    assert sha(data) == digest, name
    match = [(n, b) for n, b in saved.items() if n.endswith(name)]
    assert len(match) == 1 and match[0][1] == data, name
    path = W / 'source-snapshot' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    source.append({'path': name, 'sha256': digest, 'bytes': len(data)})
refs = ['evidence/upstream/pump_amm.json',
        'repro/pump_amm/serialization-thirty-seven/build-comparison.json',
        'repro/pump_amm/serialization-thirty-seven/function-match.json',
        'repro/pump_amm/serialization-thirty-seven/source-snapshot.tar.gz',
        'repro/pump_fees/framework-matching/elf_reader.py',
        'research/imported-lab/analysis/pump_fun/pump_amm.asm']
inputs = {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Static Pool serializer only; no build, probes, source edits, or initializer analysis',
    'original': original.identity(), 'candidate': candidate.identity(), 'symbols': symbols.identity(),
    'sources': source, 'source_count': len(source),
    'references': [{'path': p, 'sha256': sha((ROOT / p).read_bytes())} for p in refs],
    'full_byte_equality': False, 'builds': 0, 'runtime_receipts': 0}
(W / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
(W / 'elf_reader.snapshot.py').write_bytes((ROOT / refs[-2]).read_bytes())
original_ranges = {}
for i, start in enumerate(original.entries):
    end = original.entries[i+1] if i+1 < len(original.entries) else original.hi
    original_ranges.setdefault((end-start, sha(original.normalized[start:end])), []).append(start)
functions = {}
for fn in symbols.funcs:
    functions.setdefault((fn['start'], fn['size']), []).append(fn['name'])
rows = []
for (start, length), names in sorted(functions.items()):
    normalized_hash = sha(candidate.normalized[start:start+length])
    hits = [at for at in original_ranges.get((length, normalized_hash), [])
            if original.pattern(at, length) == candidate.pattern(start, length)]
    rows.append({'names': names, 'start': start, 'bytes': length,
                 'normalized_sha256': normalized_hash,
                 'raw_sha256': sha(candidate.b[start:start+length]),
                 'relocations': candidate.pattern(start, length), 'matches': hits})
(W / 'function-catalog.json.gz').write_bytes(gzip.compress((json.dumps(rows, indent=2)+'\n').encode(), mtime=0))
disc = bytes([241,154,109,4,17,177,109,188])
report = {}
for label, elf in [('original', original), ('candidate', candidate)]:
    found = []
    for at, relocation in elf.relocations.items():
        if not (elf.lo <= at < elf.hi and elf.b[at] == 0x18 and relocation['type'] == 8):
            continue
        pointer = struct.unpack_from('<I', elf.b, at+4)[0] | struct.unpack_from('<I', elf.b, at+12)[0] << 32
        if elf.b[pointer:pointer+8] != disc:
            continue
        index = bisect.bisect_right(elf.entries, at)-1
        entry = elf.entries[index]
        end = elf.entries[index+1] if index+1 < len(elf.entries) else elf.hi
        named = [r for r in rows if r['start'] <= at < r['start']+r['bytes']] if label == 'candidate' else []
        found.append({'at': hex(at), 'pointer': hex(pointer), 'discriminator_hex': disc.hex(),
                      'entry': hex(entry), 'end': hex(end), 'bytes': end-entry, 'candidate_functions': named})
    report[label] = found
(W / 'pool-discriminator-references.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'sources': len(source), 'functions': len(rows), 'references': report}, indent=2))
