000f5650: 7b 2a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r2
000f5658: 18 02 00 00 90 91 10 00 00 00 00 00 00 00 00 00  lddw r2, 0x109190 ; data 0x109190 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00AccountNotSignerPermissionDeniedno storage spaceAvailable fees ('
000f5668: 7b 2a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r2
000f5670: bf a2 00 00 00 00 00 00  mov64 r2, r10
000f5678: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
000f5680: 7b 2a d0 ff 00 00 00 00  stxdw [r10 - 0x30], r2
000f5688: 18 02 00 00 a8 d4 0f 00 00 00 00 00 00 00 00 00  lddw r2, 0xfd4a8 ; data 0xfd4a8 b"\xbf&\x00\x00\x00\x00\x00\x00y\x11\x00\x00\x00\x00\x00\x00\xbf\x12\x00\x00\x00\x00\x00\x00W\x02\x00\x00\x03\x00\x00\x00e\x02\x08\x00\x01\x00\x00\x00\x15\x02'\x00\x00\x00\x00\x00y\x12\xff\xff\x00\x00\x00\x00y\x11\x07\x00\x00\x00\x00\x00y\x13 \x00\x00\x00\x00\x00\xbf!\x00\x00\x00\x00\x00\x00"
000f5698: 7b 2a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r2
000f56a0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000f56a8: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
000f56b0: 7b 2a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r2
000f56b8: 7a 0a e0 ff 00 00 00 00  stdw [r10 - 0x20], 0x0
000f56c0: 7a 0a c8 ff 01 00 00 00  stdw [r10 - 0x38], 0x1
000f56c8: 7a 0a d8 ff 01 00 00 00  stdw [r10 - 0x28], 0x1
000f56d0: bf a2 00 00 00 00 00 00  mov64 r2, r10
000f56d8: 07 02 00 00 c0 ff ff ff  add64 r2, -0x40
000f56e0: 85 10 00 00 a8 11 00 00  call 0x11a8 ; call 0xfe428 _ZN5alloc3fmt6format12format_inner17h18e09540b0977914E
000f56e8: 79 a6 b8 ff 00 00 00 00  ldxdw r6, [r10 - 0x48]
000f56f0: bf 61 00 00 00 00 00 00  mov64 r1, r6
000f56f8: 57 01 00 00 03 00 00 00  and64 r1, 0x3
000f5700: bf 12 00 00 00 00 00 00  mov64 r2, r1
000f5708: 07 02 00 00 fe ff ff ff  add64 r2, -0x2
000f5710: a5 02 10 00 02 00 00 00  jlt r2, 0x2, +0x10 <custom_panic+0x2dc20> ; branch 0xf5798
000f5718: 15 01 0f 00 00 00 00 00  jeq r1, 0x0, +0xf <custom_panic+0x2dc20> ; branch 0xf5798
000f5720: 79 67 ff ff 00 00 00 00  ldxdw r7, [r6 - 0x1]
000f5728: 79 68 07 00 00 00 00 00  ldxdw r8, [r6 + 0x7]
000f5730: 79 82 00 00 00 00 00 00  ldxdw r2, [r8 + 0x0]
000f5738: bf 71 00 00 00 00 00 00  mov64 r1, r7
000f5740: 8d 00 00 00 02 00 00 00  callx r2
000f5748: 07 06 00 00 ff ff ff ff  add64 r6, -0x1
000f5750: 79 82 08 00 00 00 00 00  ldxdw r2, [r8 + 0x8]
000f5758: 15 02 03 00 00 00 00 00  jeq r2, 0x0, +0x3 <custom_panic+0x2dc00> ; branch 0xf5778
000f5760: 79 83 10 00 00 00 00 00  ldxdw r3, [r8 + 0x10]
000f5768: bf 71 00 00 00 00 00 00  mov64 r1, r7
000f5770: 85 10 00 00 40 a4 ff ff  call -0x5bc0 ; call 0xc7978 __rust_dealloc
000f5778: bf 61 00 00 00 00 00 00  mov64 r1, r6
000f5780: b7 02 00 00 18 00 00 00  mov64 r2, 0x18
000f5788: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
000f5790: 85 10 00 00 3c a4 ff ff  call -0x5bc4 ; call 0xc7978 __rust_dealloc
000f5798: 95 00 00 00 00 00 00 00  exit
