000ee2d0: bf 17 00 00 00 00 00 00  mov64 r7, r1
000ee2d8: b7 00 00 00 00 00 00 00  mov64 r0, 0x0
000ee2e0: 79 75 08 00 00 00 00 00  ldxdw r5, [r7 + 0x8]
000ee2e8: 79 79 10 00 00 00 00 00  ldxdw r9, [r7 + 0x10]
000ee2f0: b7 08 00 00 00 00 00 00  mov64 r8, 0x0
000ee2f8: 3d 59 18 00 00 00 00 00  jge r9, r5, +0x18 <custom_panic+0x26848> ; branch 0xee3c0
000ee300: bf 51 00 00 00 00 00 00  mov64 r1, r5
000ee308: 1f 91 00 00 00 00 00 00  sub64 r1, r9
000ee310: b7 06 00 00 01 00 00 00  mov64 r6, 0x1
000ee318: b7 04 00 00 01 00 00 00  mov64 r4, 0x1
000ee320: 2d 51 01 00 00 00 00 00  jgt r1, r5, +0x1 <custom_panic+0x267b8> ; branch 0xee330
000ee328: b7 04 00 00 00 00 00 00  mov64 r4, 0x0
000ee330: 55 04 01 00 00 00 00 00  jne r4, 0x0, +0x1 <custom_panic+0x267c8> ; branch 0xee340
000ee338: bf 18 00 00 00 00 00 00  mov64 r8, r1
000ee340: ad 38 01 00 00 00 00 00  jlt r8, r3, +0x1 <custom_panic+0x267d8> ; branch 0xee350
000ee348: bf 38 00 00 00 00 00 00  mov64 r8, r3
000ee350: 7b 3a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r3
000ee358: 79 71 00 00 00 00 00 00  ldxdw r1, [r7 + 0x0]
000ee360: 0f 91 00 00 00 00 00 00  add64 r1, r9
000ee368: bf 83 00 00 00 00 00 00  mov64 r3, r8
000ee370: 85 10 00 00 ff ff ff ff  call -0x1 ; external sol_memcpy_
000ee378: bf 91 00 00 00 00 00 00  mov64 r1, r9
000ee380: 0f 81 00 00 00 00 00 00  add64 r1, r8
000ee388: ad 91 01 00 00 00 00 00  jlt r1, r9, +0x1 <custom_panic+0x26820> ; branch 0xee398
000ee390: b7 06 00 00 00 00 00 00  mov64 r6, 0x0
000ee398: 57 06 00 00 01 00 00 00  and64 r6, 0x1
000ee3a0: b7 00 00 00 00 00 00 00  mov64 r0, 0x0
000ee3a8: 55 06 05 00 00 00 00 00  jne r6, 0x0, +0x5 <custom_panic+0x26860> ; branch 0xee3d8
000ee3b0: 7b 17 10 00 00 00 00 00  stxdw [r7 + 0x10], r1
000ee3b8: 79 a3 f8 ff 00 00 00 00  ldxdw r3, [r10 - 0x8]
000ee3c0: 1d 38 01 00 00 00 00 00  jeq r8, r3, +0x1 <custom_panic+0x26858> ; branch 0xee3d0
000ee3c8: 85 10 00 00 ea fc ff ff  call -0x316 ; call 0xecb20 _ZN3std2io5error5Error3new17h4bab95b6bf323abbE
000ee3d0: 95 00 00 00 00 00 00 00  exit
000ee3d8: 18 01 00 00 78 f3 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x10f378 ; data 0x10f378 b'\x00\x00\x00\x00y\xb1\x10\x00\x11\x00\x00\x00\x00\x00\x00\x00\x1c\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x8a\xb1\x10\x00\r\x00\x00\x00\x00\x00\x00\x00\x0b\x00\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00\x8a\xb1\x10\x00\r\x00\x00\x00\x00\x00\x00\x00\t\x00\x00\x00 \x00\x00\x00\x00\x00\x00\x00\x8a\xb1\x10\x00'
000ee3e8: 85 10 00 00 94 2c 00 00  call 0x2c94 ; call 0x104890 _ZN4core9panicking11panic_const24panic_const_add_overflow17h490567cbdd03e99bE
