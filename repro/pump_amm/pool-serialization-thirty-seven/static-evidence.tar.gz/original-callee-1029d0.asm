001029d0: bf 17 00 00 00 00 00 00  mov64 r7, r1
001029d8: b7 00 00 00 00 00 00 00  mov64 r0, 0x0
001029e0: 79 75 08 00 00 00 00 00  ldxdw r5, [r7 + 0x8]
001029e8: 79 79 10 00 00 00 00 00  ldxdw r9, [r7 + 0x10]
001029f0: b7 08 00 00 00 00 00 00  mov64 r8, 0x0
001029f8: 3d 59 18 00 00 00 00 00  jge r9, r5, +0x18 <custom_panic+0x14610> ; branch 0x102ac0
00102a00: bf 51 00 00 00 00 00 00  mov64 r1, r5
00102a08: 1f 91 00 00 00 00 00 00  sub64 r1, r9
00102a10: b7 06 00 00 01 00 00 00  mov64 r6, 0x1
00102a18: b7 04 00 00 01 00 00 00  mov64 r4, 0x1
00102a20: 2d 51 01 00 00 00 00 00  jgt r1, r5, +0x1 <custom_panic+0x14580> ; branch 0x102a30
00102a28: b7 04 00 00 00 00 00 00  mov64 r4, 0x0
00102a30: 55 04 01 00 00 00 00 00  jne r4, 0x0, +0x1 <custom_panic+0x14590> ; branch 0x102a40
00102a38: bf 18 00 00 00 00 00 00  mov64 r8, r1
00102a40: ad 38 01 00 00 00 00 00  jlt r8, r3, +0x1 <custom_panic+0x145a0> ; branch 0x102a50
00102a48: bf 38 00 00 00 00 00 00  mov64 r8, r3
00102a50: 7b 3a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r3
00102a58: 79 71 00 00 00 00 00 00  ldxdw r1, [r7 + 0x0]
00102a60: 0f 91 00 00 00 00 00 00  add64 r1, r9
00102a68: bf 83 00 00 00 00 00 00  mov64 r3, r8
00102a70: 85 10 00 00 ff ff ff ff  call -0x1 ; external sol_memcpy_
00102a78: bf 91 00 00 00 00 00 00  mov64 r1, r9
00102a80: 0f 81 00 00 00 00 00 00  add64 r1, r8
00102a88: ad 91 01 00 00 00 00 00  jlt r1, r9, +0x1 <custom_panic+0x145e8> ; branch 0x102a98
00102a90: b7 06 00 00 00 00 00 00  mov64 r6, 0x0
00102a98: 57 06 00 00 01 00 00 00  and64 r6, 0x1
00102aa0: b7 00 00 00 00 00 00 00  mov64 r0, 0x0
00102aa8: 55 06 05 00 00 00 00 00  jne r6, 0x0, +0x5 <custom_panic+0x14628> ; branch 0x102ad8
00102ab0: 7b 17 10 00 00 00 00 00  stxdw [r7 + 0x10], r1
00102ab8: 79 a3 f8 ff 00 00 00 00  ldxdw r3, [r10 - 0x8]
00102ac0: 1d 38 01 00 00 00 00 00  jeq r8, r3, +0x1 <custom_panic+0x14620> ; branch 0x102ad0
00102ac8: 85 10 00 00 bd fc ff ff  call -0x343 ; call 0x1010b8 _ZN3std2io5error5Error3new17h4bab95b6bf323abbE
00102ad0: 95 00 00 00 00 00 00 00  exit
00102ad8: 18 01 00 00 38 2f 12 00 00 00 00 00 00 00 00 00  lddw r1, 0x122f38 ; data 0x122f38 b'\x00\x00\x00\x00@\xf0\x11\x00\x11\x00\x00\x00\x00\x00\x00\x00\x1c\x00\x00\x00\t\x00\x00\x00\x00\x00\x00\x00Q\xf0\x11\x00\r\x00\x00\x00\x00\x00\x00\x00\x0b\x00\x00\x00\x15\x00\x00\x00\x00\x00\x00\x00Q\xf0\x11\x00\r\x00\x00\x00\x00\x00\x00\x00\t\x00\x00\x00 \x00\x00\x00\x00\x00\x00\x00Q\xf0\x11\x00'
00102ae8: 85 10 00 00 23 2b 00 00  call 0x2b23 ; call 0x118408 _ZN4core9panicking11panic_const24panic_const_add_overflow17h490567cbdd03e99bE,_ZN4core9panicking11panic_const24panic_const_sub_overflow17h4a633ef3d3c6c1e2E,_ZN4core9panicking11panic_const24panic_const_mul_overflow17h630bce620d304031E,_ZN4core9panicking11panic_const24panic_const_div_overflow17h1de8056b783cf79aE,_ZN4core9panicking11panic_const23panic_const_div_by_zero17h2bd12e3a9c459cc2E
