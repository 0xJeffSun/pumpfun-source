000ee848: bf 16 00 00 00 00 00 00  mov64 r6, r1
000ee850: 79 61 18 00 00 00 00 00  ldxdw r1, [r6 + 0x18]
000ee858: 18 02 00 00 d8 86 10 00 00 00 00 00 00 00 00 00  lddw r2, 0x1086d8 ; data 0x1086d8 b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0bpe\xb1\xe3\xd1|E8\x9dR\x7fk\x04\xc3\xcdX\xb8ls\x1a\xa0\xfd\xb5I\xb6\xd1\xbc\x03\xf8)F\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15h\xbf\x17[\xaa'
000ee868: b7 03 00 00 20 00 00 00  mov64 r3, 0x20
000ee870: 85 10 00 00 90 2e 00 00  call 0x2e90 ; call 0x105cf8 memcmp
000ee878: bf 01 00 00 00 00 00 00  mov64 r1, r0
000ee880: b7 00 00 00 00 00 00 00  mov64 r0, 0x0
000ee888: 67 01 00 00 20 00 00 00  lsh64 r1, 0x20
000ee890: 77 01 00 00 20 00 00 00  rsh64 r1, 0x20
000ee898: 55 01 02 00 00 00 00 00  jne r1, 0x0, +0x2 <custom_panic+0x26d38> ; branch 0xee8b0
000ee8a0: bf 61 00 00 00 00 00 00  mov64 r1, r6
000ee8a8: 85 10 00 00 35 0b 00 00  call 0xb35 ; call 0xf4258 _ZN19solana_account_info11AccountInfo13data_is_empty17hfe4a05f82a6681e6E
000ee8b0: 95 00 00 00 00 00 00 00  exit
