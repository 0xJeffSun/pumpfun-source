000ee9e0: bf 16 00 00 00 00 00 00  mov64 r6, r1
000ee9e8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ee9f0: 07 01 00 00 e8 ff ff ff  add64 r1, -0x18
000ee9f8: 85 10 00 00 8a 0d 00 00  call 0xd8a ; call 0xf5650 _ZN103_$LT$solana_program_error..ProgramError$u20$as$u20$core..convert..From$LT$std..io..error..Error$GT$$GT$4from17hb31d13733a9f9951E
000eea00: b7 01 00 00 80 00 00 00  mov64 r1, 0x80
000eea08: b7 02 00 00 08 00 00 00  mov64 r2, 0x8
000eea10: 85 10 00 00 d2 b1 ff ff  call -0x4e2e ; call 0xc78a8 __rust_alloc
000eea18: 55 00 03 00 00 00 00 00  jne r0, 0x0, +0x3 <custom_panic+0x26ec0> ; branch 0xeea38
000eea20: b7 01 00 00 08 00 00 00  mov64 r1, 0x8
000eea28: b7 02 00 00 80 00 00 00  mov64 r2, 0x80
000eea30: 85 10 00 00 2b 1f 00 00  call 0x1f2b ; call 0xfe390 _ZN5alloc5alloc18handle_alloc_error17hfd63d3615830768dE
000eea38: 7a 00 00 00 02 00 00 00  stdw [r0 + 0x0], 0x2
000eea40: 79 a1 e8 ff 00 00 00 00  ldxdw r1, [r10 - 0x18]
000eea48: 7b 10 20 00 00 00 00 00  stxdw [r0 + 0x20], r1
000eea50: 79 a1 f0 ff 00 00 00 00  ldxdw r1, [r10 - 0x10]
000eea58: 7b 10 28 00 00 00 00 00  stxdw [r0 + 0x28], r1
000eea60: 79 a1 f8 ff 00 00 00 00  ldxdw r1, [r10 - 0x8]
000eea68: 7b 10 30 00 00 00 00 00  stxdw [r0 + 0x30], r1
000eea70: 72 00 38 00 02 00 00 00  stb [r0 + 0x38], 0x2
000eea78: 7b 06 08 00 00 00 00 00  stxdw [r6 + 0x8], r0
000eea80: 7a 06 00 00 01 00 00 00  stdw [r6 + 0x0], 0x1
000eea88: 95 00 00 00 00 00 00 00  exit
