0010a410: 7b 2a b8 ff 00 00 00 00  stxdw [r10 - 0x48], r2
0010a418: 18 02 00 00 88 ca 11 00 00 00 00 00 00 00 00 00  lddw r2, 0x11ca88 ; data 0x11ca88 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00AccountNotSignerPermissionDeniedno storage spaceAvailable fees ('
0010a428: 7b 2a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r2
0010a430: bf a2 00 00 00 00 00 00  mov64 r2, r10
0010a438: 07 02 00 00 f0 ff ff ff  add64 r2, -0x10
0010a440: 7b 2a d0 ff 00 00 00 00  stxdw [r10 - 0x30], r2
0010a448: 18 02 00 00 78 04 11 00 00 00 00 00 00 00 00 00  lddw r2, 0x110478 ; data 0x110478 b"\xbf&\x00\x00\x00\x00\x00\x00y\x11\x00\x00\x00\x00\x00\x00\xbf\x12\x00\x00\x00\x00\x00\x00W\x02\x00\x00\x03\x00\x00\x00e\x02\x08\x00\x01\x00\x00\x00\x15\x02'\x00\x00\x00\x00\x00y\x12\xff\xff\x00\x00\x00\x00y\x11\x07\x00\x00\x00\x00\x00y\x13 \x00\x00\x00\x00\x00\xbf!\x00\x00\x00\x00\x00\x00"
0010a458: 7b 2a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r2
0010a460: bf a2 00 00 00 00 00 00  mov64 r2, r10
0010a468: 07 02 00 00 b8 ff ff ff  add64 r2, -0x48
0010a470: 7b 2a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r2
0010a478: 7a 0a e0 ff 00 00 00 00  stdw [r10 - 0x20], 0x0
0010a480: 7a 0a c8 ff 01 00 00 00  stdw [r10 - 0x38], 0x1
0010a488: 7a 0a d8 ff 01 00 00 00  stdw [r10 - 0x28], 0x1
0010a490: bf a2 00 00 00 00 00 00  mov64 r2, r10
0010a498: 07 02 00 00 c0 ff ff ff  add64 r2, -0x40
0010a4a0: 85 10 00 00 ea 0d 00 00  call 0xdea ; call 0x1113f8 _ZN5alloc3fmt6format12format_inner17h18e09540b0977914E
0010a4a8: 79 a6 b8 ff 00 00 00 00  ldxdw r6, [r10 - 0x48]
0010a4b0: bf 61 00 00 00 00 00 00  mov64 r1, r6
0010a4b8: 57 01 00 00 03 00 00 00  and64 r1, 0x3
0010a4c0: bf 12 00 00 00 00 00 00  mov64 r2, r1
0010a4c8: 07 02 00 00 fe ff ff ff  add64 r2, -0x2
0010a4d0: a5 02 10 00 02 00 00 00  jlt r2, 0x2, +0x10 <custom_panic+0x1c0a8> ; branch 0x10a558
0010a4d8: 15 01 0f 00 00 00 00 00  jeq r1, 0x0, +0xf <custom_panic+0x1c0a8> ; branch 0x10a558
0010a4e0: 79 67 ff ff 00 00 00 00  ldxdw r7, [r6 - 0x1]
0010a4e8: 79 68 07 00 00 00 00 00  ldxdw r8, [r6 + 0x7]
0010a4f0: 79 82 00 00 00 00 00 00  ldxdw r2, [r8 + 0x0]
0010a4f8: bf 71 00 00 00 00 00 00  mov64 r1, r7
0010a500: 8d 00 00 00 02 00 00 00  callx r2
0010a508: 07 06 00 00 ff ff ff ff  add64 r6, -0x1
0010a510: 79 82 08 00 00 00 00 00  ldxdw r2, [r8 + 0x8]
0010a518: 15 02 03 00 00 00 00 00  jeq r2, 0x0, +0x3 <custom_panic+0x1c088> ; branch 0x10a538
0010a520: 79 83 10 00 00 00 00 00  ldxdw r3, [r8 + 0x10]
0010a528: bf 71 00 00 00 00 00 00  mov64 r1, r7
0010a530: 85 10 00 00 af c7 ff ff  call -0x3851 ; call 0xee2b0 _ZN4core3ptr205drop_in_place$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$GT$17h6600291b02639810E,_ZN4core3ptr28drop_in_place$LT$$RF$u32$GT$17hb20a71161c32297fE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17hba88d9c2d6538ddfE,_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h1ee8bdf06693370cE,_ZN4core3ptr47drop_in_place$LT$solana_pubkey..PubkeyError$GT$17h955ae1c902d5e044E,_ZN4core3ptr55drop_in_place$LT$solana_program_error..ProgramError$GT$17h5a0e5c8065583a5cE,_ZN4core5error5Error7provide17hbe8cec213cc04632E,__rust_dealloc,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h83eabe94e5379cd5E,_ZN4core5error5Error7provide17h5d113fa38e1f424dE,_ZN4core3ptr28drop_in_place$LT$$RF$str$GT$17h99648ae50359f950E,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h331d3cf2a8a69436E,_ZN4core5error5Error7provide17hd83011d26c62e5acE,_ZN4core3ptr26drop_in_place$LT$usize$GT$17h61e976054266c6c6E,_ZN4core5error5Error7provide17h0f3cdf537cf38f73E,_ZN4core3ptr122drop_in_place$LT$$RF$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$GT$17h5ec3b656566bd4d5E,_ZN4core3ptr24drop_in_place$LT$i32$GT$17h70dc905d0354dec6E,_ZN4core3ptr25drop_in_place$LT$bool$GT$17h38c0aa384008eb1eE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h33cc8fe931e63de8E,_ZN4core3ptr26drop_in_place$LT$usize$GT$17ha57d6f37d611032cE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h49f6f3e10b17e18aE
0010a538: bf 61 00 00 00 00 00 00  mov64 r1, r6
0010a540: b7 02 00 00 18 00 00 00  mov64 r2, 0x18
0010a548: b7 03 00 00 08 00 00 00  mov64 r3, 0x8
0010a550: 85 10 00 00 ab c7 ff ff  call -0x3855 ; call 0xee2b0 _ZN4core3ptr205drop_in_place$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$GT$17h6600291b02639810E,_ZN4core3ptr28drop_in_place$LT$$RF$u32$GT$17hb20a71161c32297fE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17hba88d9c2d6538ddfE,_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h1ee8bdf06693370cE,_ZN4core3ptr47drop_in_place$LT$solana_pubkey..PubkeyError$GT$17h955ae1c902d5e044E,_ZN4core3ptr55drop_in_place$LT$solana_program_error..ProgramError$GT$17h5a0e5c8065583a5cE,_ZN4core5error5Error7provide17hbe8cec213cc04632E,__rust_dealloc,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h83eabe94e5379cd5E,_ZN4core5error5Error7provide17h5d113fa38e1f424dE,_ZN4core3ptr28drop_in_place$LT$$RF$str$GT$17h99648ae50359f950E,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h331d3cf2a8a69436E,_ZN4core5error5Error7provide17hd83011d26c62e5acE,_ZN4core3ptr26drop_in_place$LT$usize$GT$17h61e976054266c6c6E,_ZN4core5error5Error7provide17h0f3cdf537cf38f73E,_ZN4core3ptr122drop_in_place$LT$$RF$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$GT$17h5ec3b656566bd4d5E,_ZN4core3ptr24drop_in_place$LT$i32$GT$17h70dc905d0354dec6E,_ZN4core3ptr25drop_in_place$LT$bool$GT$17h38c0aa384008eb1eE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h33cc8fe931e63de8E,_ZN4core3ptr26drop_in_place$LT$usize$GT$17ha57d6f37d611032cE,_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17h49f6f3e10b17e18aE
0010a558: 95 00 00 00 00 00 00 00  exit
