#!/usr/bin/env python3
"""Verify sealed static evidence only. No build or recovered-code execution."""
from pathlib import Path
import hashlib,json,struct
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((W/'manifest.json').read_bytes())
for r in manifest['files']:
    b=(W/r['path']).read_bytes();assert len(b)==r['bytes']and sha(b)==r['sha256'],r['path']
inputs=json.loads((W/'inputs.json').read_bytes())
for r in inputs['sources']:
    assert sha((W/'source-snapshot'/r['path']).read_bytes())==r['sha256']
    assert sha((ROOT/r['path']).read_bytes())==r['sha256'],r['path']
for r in inputs['references']:
    assert sha((ROOT/r['path']).read_bytes())==r['sha256'],r['path']
elfs={label:(ROOT/inputs[label]['path']).read_bytes()for label in ['original','candidate','symbols']}
for label,b in elfs.items():assert sha(b)==inputs[label]['sha256']
instructions=branches=calls=0
windows=json.loads((W/'windows.json').read_bytes())
for window in windows:
    label,name=window['label'],window['name'];b=elfs[label]
    start,end=int(window['start'],16),int(window['end'],16)
    assert sha(b[start:end])==window['raw_sha256']
    rows=json.loads((W/f'{label}-{name}.json').read_bytes());cursor=start
    for r in rows:
        at=int(r['at'],16);raw=bytes.fromhex(r['raw_hex']);assert at==cursor and b[at:at+len(raw)]==raw
        cursor+=len(raw);instructions+=1
        if 'call_target'in r:
            assert at+8+8*struct.unpack_from('<i',raw,4)[0]==int(r['call_target'],16);calls+=1
        if 'branch_target'in r:
            d=struct.unpack_from('<h',raw,2)[0];assert d==r['branch_displacement']and at+8+8*d==int(r['branch_target'],16);branches+=1
        if 'pointer'in r:
            p=int(r['pointer'],16);assert b[p:p+80].hex()==r['data80_hex']
    assert cursor==end
    assert (W/f'{label}-{name}.asm').read_text()=='\n'.join(r['annotated']for r in rows)+'\n'
analysis=json.loads((W/'analysis.json').read_bytes())
assert sha((W/'suggested-pool-serializer.patch').read_bytes())==analysis['source_patch_sha256']
assert analysis['field_writes']==19 and analysis['serialized_bytes']==287
print(json.dumps({'result':'pass','sealed_files':len(manifest['files']),'source_inputs':18,'windows':len(windows),'instructions':instructions,'branches':branches,'direct_calls':calls,'candidate_sha256':inputs['candidate']['sha256'],'original_sha256':inputs['original']['sha256'],'manifest_sha256':sha((W/'manifest.json').read_bytes()),'builds':0,'runtime_receipts':0,'full_byte_equality':False},indent=2))
