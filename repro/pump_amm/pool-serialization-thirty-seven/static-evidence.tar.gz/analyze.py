#!/usr/bin/env python3
"""Static instruction/dataflow summaries only; does not execute program logic."""
from pathlib import Path
import difflib, gzip, hashlib, json, re, struct, sys, tarfile, tomllib
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
sys.path.insert(0,str(ROOT/'repro/pump_fees/framework-matching'))
from elf_reader import Elf
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((W/'inputs.json').read_bytes())
original=Elf(ROOT/inputs['original']['path']);candidate=Elf(ROOT/inputs['candidate']['path'])
catalog=json.loads(gzip.decompress((W/'function-catalog.json.gz').read_bytes()));by={r['start']:r for r in catalog}
idl=json.loads((ROOT/'evidence/upstream/pump_amm.json').read_bytes())
pool=next(t for t in idl['types']if t['name']=='Pool')
fields=[{'name':'discriminator','type':'bytes8'}]+pool['type']['fields']
expected_widths=[8,1,2,32,32,32,32,32,32,8,32,1,1,16,8,1,1,8,8]
expected_offsets=[None,0x11a,0x118,8,0x28,0x48,0x68,0x88,0xa8,0xf8,0xc8,0x11b,0x11c,0xe8,0x100,0x11d,0x11e,0x108,0x110]
assert len(fields)==len(expected_widths)
write_summaries={}
for label, writer, account_register in [('original',0x1029d0,7),('candidate',0xee2d0,9)]:
    rows=json.loads((W/f'{label}-pool-exit.json').read_bytes())
    calls=[i for i,r in enumerate(rows)if r.get('call_target')==hex(writer)]
    assert len(calls)==19
    summaries=[];previous=-1;serialized_offset=0
    for index,(at_i,field,width,offset)in enumerate(zip(calls,fields,expected_widths,expected_offsets)):
        segment=rows[previous+1:at_i];call=rows[at_i]
        sizes=[r for r in segment if re.fullmatch(r'mov64 r3, 0x[0-9a-f]+',r['instruction'])]
        assert sizes and int(sizes[-1]['instruction'].split('0x')[1],16)==width
        if index==0:
            evidence=[r for r in segment if r.get('pointer')]
            assert len(evidence)==1 and bytes.fromhex(evidence[0]['data80_hex'])[:8]==bytes([241,154,109,4,17,177,109,188])
        else:
            evidence=[r for r in segment if f'[r{account_register} + {offset:#x}]'in r['instruction']]
            if not evidence:
                moves=[i for i,r in enumerate(segment)if r['instruction']==f'mov64 r2, r{account_register}']
                assert moves,index
                evidence=[r for r in segment[moves[-1]+1:]if r['instruction']==f'add64 r2, {offset:#x}']
            assert evidence,index
        after=rows[at_i+1:at_i+5]
        error_branch=next(r for r in after if 'branch_target'in r)
        summaries.append({'field':field,'serialized_offset':serialized_offset,'width':width,
            'account_wrapper_offset':None if offset is None else hex(offset),'write_call':call,
            'source_evidence':evidence,'error_branch':error_branch})
        serialized_offset+=width;previous=at_i
    assert serialized_offset==287
    write_summaries[label]=summaries
(W/'field-write-correspondence.json').write_text(json.dumps(write_summaries,indent=2)+'\n')
original_targets=sorted(set(c['target']for c in original.callsites(0x4210,1704)))
candidate_targets=sorted(set(c['target']for c in candidate.callsites(0x3c38,2544)))
direct=[]
for target in original_targets:
    matching=[r for r in catalog if target in r['matches']]
    assert len(matching)==1,(target,matching)
    row=matching[0]
    direct.append({'original_target':hex(target),'candidate_target':hex(row['start']),
        'called_by_current_candidate_pool':row['start']in candidate_targets,
        'names':row['names'],'bytes':row['bytes'],'normalized_sha256':row['normalized_sha256'],
        'relocations':row['relocations'],'raw_bytes_equal':original.b[target:target+row['bytes']]==candidate.b[row['start']:row['start']+row['bytes']],
        'full_entry_bounded_normalized_match':True})
extra=[{'candidate_target':hex(t),'function':by[t]}for t in candidate_targets if not any(int(r['candidate_target'],16)==t for r in direct)]
source=(W/'source-snapshot/programs/pump-amm/src/state.rs').read_text()
old='''        writer.write_all(Self::DISCRIMINATOR).map_err(|e| anchor_lang::solana_program::program_error::ProgramError::BorshIoError(e.to_string()))?;
        self.serialize(writer).map_err(|e| anchor_lang::solana_program::program_error::ProgramError::BorshIoError(e.to_string()).into())'''
new='''        writer.write_all(Self::DISCRIMINATOR)?;
        self.serialize(writer)?;
        Ok(())'''
assert source.count(old)==1
patch=''.join(difflib.unified_diff(source.splitlines(True),source.replace(old,new).splitlines(True),fromfile='a/programs/pump-amm/src/state.rs',tofile='b/programs/pump-amm/src/state.rs'))
(W/'suggested-pool-serializer.patch').write_text(patch)
lock=tomllib.loads((ROOT/'programs/pump-amm/Cargo.lock').read_text())
framework=[]
for name,version,files in [('anchor-lang','0.31.1',['src/error.rs','src/accounts/account.rs']),('solana-program-error','2.2.2',['src/lib.rs'])]:
    pkg=next(p for p in lock['package']if p['name']==name and p['version']==version)
    archives=list((ROOT/'work/pump-amm-v144/cargo-home/registry/cache').glob(f'*/{name}-{version}.crate'))
    assert archives
    archive=archives[0];assert sha(archive.read_bytes())==pkg['checksum']
    with tarfile.open(archive,'r:gz')as stream:
        for file in files:
            member=f'{name}-{version}/{file}';data=stream.extractfile(member).read()
            output=W/'framework-source'/member;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(data)
            framework.append({'package':name,'version':version,'archive_sha256':pkg['checksum'],'path':str(output.relative_to(W)),'sha256':sha(data)})
summary={'scope':'Static-only comparison; suggested patch is not applied or built in this package',
    'original_pool_exit':{'start':'0x4210','end':'0x48b8','bytes':1704,'raw_sha256':sha(original.b[0x4210:0x48b8])},
    'candidate_pool_exit':{'start':'0x3c38','end':'0x4628','bytes':2544,'raw_sha256':sha(candidate.b[0x3c38:0x4628])},
    'field_writes':19,'payload_field_count':18,'serialized_bytes':287,
    'original_error_targets':sorted(set(r['error_branch']['branch_target']for r in write_summaries['original'])),
    'candidate_error_targets':sorted(set(r['error_branch']['branch_target']for r in write_summaries['candidate'])),
    'original_direct_target_matches':direct,'additional_candidate_direct_targets':extra,
    'framework_sources':framework,'recommended_source_change':'Only Pool::try_serialize: direct ? propagation for discriminator and fields, then Ok(())',
    'source_patch_sha256':sha(patch.encode()),'fresh_build_or_runtime_validation':False,
    'full_byte_equality':False,'runtime_receipts':0,'handler_count_increment':0}
(W/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['original_direct_target_matches','additional_candidate_direct_targets','framework_sources']},indent=2))
