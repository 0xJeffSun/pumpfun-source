000ffc40: 7b 2a 98 ff 00 00 00 00  stxdw [r10 - 0x68], r2
000ffc48: 7b 1a 90 ff 00 00 00 00  stxdw [r10 - 0x70], r1
000ffc50: 7b 4a a8 ff 00 00 00 00  stxdw [r10 - 0x58], r4
000ffc58: 7b 3a a0 ff 00 00 00 00  stxdw [r10 - 0x60], r3
000ffc60: 18 01 00 00 c0 02 11 00 00 00 00 00 00 00 00 00  lddw r1, 0x1102c0 ; data 0x1102c0 b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\xd7\x10\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb8\xea\x0f\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00(\xfd\x0f\x00\x00\x00\x00\x000\x02\x10\x00\x00\x00\x00\x008\x0c\x10\x00'
000ffc70: 7b 1a b0 ff 00 00 00 00  stxdw [r10 - 0x50], r1
000ffc78: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ffc80: 07 01 00 00 e0 ff ff ff  add64 r1, -0x20
000ffc88: 7b 1a c0 ff 00 00 00 00  stxdw [r10 - 0x40], r1
000ffc90: 18 01 00 00 90 58 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x105890 ; data 0x105890 b'y\x13\x00\x00\x00\x00\x00\x00y\x11\x08\x00\x00\x00\x00\x00y\x14\x18\x00\x00\x00\x00\x00\xbf1\x00\x00\x00\x00\x00\x00\x8d\x00\x00\x00\x04\x00\x00\x00\x95\x00\x00\x00\x00\x00\x00\x00\xbf$\x00\x00\x00\x00\x00\x00y\x13\x08\x00\x00\x00\x00\x00y\x12\x00\x00\x00\x00\x00\x00\xbfA\x00\x00\x00\x00\x00\x00'
000ffca0: 7b 1a f8 ff 00 00 00 00  stxdw [r10 - 0x8], r1
000ffca8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ffcb0: 07 01 00 00 a0 ff ff ff  add64 r1, -0x60
000ffcb8: 7b 1a f0 ff 00 00 00 00  stxdw [r10 - 0x10], r1
000ffcc0: 18 01 00 00 c0 58 10 00 00 00 00 00 00 00 00 00  lddw r1, 0x1058c0 ; data 0x1058c0 b'\xbf$\x00\x00\x00\x00\x00\x00y\x13\x08\x00\x00\x00\x00\x00y\x12\x00\x00\x00\x00\x00\x00\xbfA\x00\x00\x00\x00\x00\x00\x85\x10\x00\x00\xcb\xf7\xff\xff\x95\x00\x00\x00\x00\x00\x00\x00\xb7\x00\x00\x00\x00\x00\x00\x00\xb7\x03\x00\x00!\x00\x00\x00\xbf\x14\x00\x00\x00\x00\x00\x00g\x04\x00\x00\x0b\x00\x00\x00'
000ffcd0: 7b 1a e8 ff 00 00 00 00  stxdw [r10 - 0x18], r1
000ffcd8: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ffce0: 07 01 00 00 90 ff ff ff  add64 r1, -0x70
000ffce8: 7b 1a e0 ff 00 00 00 00  stxdw [r10 - 0x20], r1
000ffcf0: 7a 0a d0 ff 00 00 00 00  stdw [r10 - 0x30], 0x0
000ffcf8: 7a 0a b8 ff 02 00 00 00  stdw [r10 - 0x48], 0x2
000ffd00: 7a 0a c8 ff 02 00 00 00  stdw [r10 - 0x38], 0x2
000ffd08: bf a1 00 00 00 00 00 00  mov64 r1, r10
000ffd10: 07 01 00 00 b0 ff ff ff  add64 r1, -0x50
000ffd18: bf 52 00 00 00 00 00 00  mov64 r2, r5
000ffd20: 85 10 00 00 a3 ff ff ff  call -0x5d ; call 0xffa40 _ZN4core9panicking9panic_fmt17h0ab812365a8ecef3E
