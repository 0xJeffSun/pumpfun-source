05b5b8: mov64 r8, r2
05b5c0: mov64 r6, r1
05b5c8: ldxdw r7, [r8 + 0x8]
05b5d0: mov64 r1, r10
05b5d8: add64 r1, -0x158
05b5e0: call 0x1570a ; call 0x106e38
05b5e8: ldxdw r1, [r10 - 0x158]
05b5f0: jne r1, 0x0, +0x45 ; branch 0x5b820
05b5f8: ldxdw r1, [r10 - 0x130]
05b600: stxdw [r10 - 0x1b0], r1
05b608: ldxdw r2, [r7 + 0x2f0]
05b610: ldxdw r9, [r7 + 0xe8]
05b618: ldxdw r1, [r7 + 0x230]
05b620: ldxdw r3, [r1 + 0x18]
05b628: stxdw [r10 - 0x140], r3
05b630: ldxdw r3, [r1 + 0x10]
05b638: stxdw [r10 - 0x148], r3
05b640: ldxdw r3, [r1 + 0x8]
05b648: stxdw [r10 - 0x150], r3
05b650: ldxdw r1, [r1 + 0x0]
05b658: stxdw [r10 - 0x158], r1
05b660: ldxb r1, [r8 + 0x20]
05b668: mov64 r3, r7
05b670: add64 r3, 0x290
05b678: stxdw [r10 - 0xfe8], r3
05b680: stxdw [r10 - 0xfe0], r1
05b688: mov64 r1, r10
05b690: add64 r1, -0x158
05b698: stxdw [r10 - 0xff0], r1
05b6a0: mov64 r1, r7
05b6a8: add64 r1, 0x158
05b6b0: stxdw [r10 - 0x1000], r1
05b6b8: stxdw [r10 - 0xff8], r9
05b6c0: mov64 r4, r7
05b6c8: add64 r4, 0x80
05b6d0: mov64 r1, r10
05b6d8: add64 r1, -0x178
05b6e0: mov64 r5, r10
05b6e8: mov64 r3, r7
05b6f0: call 0x2db5 ; call 0x724a0
05b6f8: ldxdw r1, [r10 - 0x178]
05b700: jeq r1, 0x2, +0x1 ; branch 0x5b710
05b708: ja +0x30 ; branch 0x5b890
05b710: ldxdw r2, [r7 + 0x2e0]
05b718: mov64 r3, r2
05b720: add64 r3, r9
05b728: mov64 r1, 0x1
05b730: jlt r3, r2, +0x1 ; branch 0x5b740
05b738: mov64 r1, 0x0
05b740: and64 r1, 0x1
05b748: jne r1, 0x0, +0x1 ; branch 0x5b758
05b750: ja +0x29 ; branch 0x5b8a0
05b758: mov64 r1, r10
05b760: add64 r1, -0xb8
05b768: lddw r2, 0x11c040 ; rodata b'\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00Non'
05b778: call 0x338f ; call 0x753f8
05b780: stdw [r10 - 0x58], 0x0
05b788: stdw [r10 - 0x60], 0x1
05b790: stdw [r10 - 0x68], 0x0
05b798: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
05b7a8: stxdw [r10 - 0x20], r1
05b7b0: mov64 r1, r10
05b7b8: add64 r1, -0x68
05b7c0: stxdw [r10 - 0x28], r1
05b7c8: stb [r10 - 0x10], 0x3
05b7d0: stdw [r10 - 0x18], 0x20
05b7d8: stdw [r10 - 0x38], 0x0
05b7e0: stdw [r10 - 0x48], 0x0
05b7e8: mov64 r2, r10
05b7f0: add64 r2, -0x48
05b7f8: lddw r1, 0x11c040 ; rodata b'\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00Non'
05b808: call 0x3e72 ; call 0x7aba0
05b810: jeq r0, 0x0, +0x35 ; branch 0x5b9c0
05b818: ja +0x2a ; branch 0x5b970
05b820: ldxdw r1, [r10 - 0x150]
05b828: ldxdw r2, [r10 - 0x148]
05b830: ldxdw r3, [r10 - 0x140]
05b838: stxdw [r10 - 0x148], r3
05b840: stxdw [r10 - 0x150], r2
05b848: stxdw [r10 - 0x158], r1
05b850: mov64 r1, r10
05b858: add64 r1, -0x168
05b860: mov64 r2, r10
05b868: add64 r2, -0x158
05b870: call 0x14ef9 ; call 0x103040
05b878: ldxdw r2, [r10 - 0x160]
05b880: ldxdw r1, [r10 - 0x168]
05b888: ja +0x19b ; branch 0x5c568
05b890: ldxdw r2, [r10 - 0x170]
05b898: ja +0x199 ; branch 0x5c568
05b8a0: stxdw [r10 - 0x1b8], r3
05b8a8: stxdw [r10 - 0x1c0], r9
05b8b0: mov64 r1, r10
05b8b8: add64 r1, -0xb8
05b8c0: lddw r2, 0x11c040 ; rodata b'\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00Non'
05b8d0: call 0x3364 ; call 0x753f8
05b8d8: stdw [r10 - 0x58], 0x0
05b8e0: stdw [r10 - 0x60], 0x1
05b8e8: stdw [r10 - 0x68], 0x0
05b8f0: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
05b900: stxdw [r10 - 0x20], r1
05b908: mov64 r1, r10
05b910: add64 r1, -0x68
05b918: stxdw [r10 - 0x28], r1
05b920: stb [r10 - 0x10], 0x3
05b928: stdw [r10 - 0x18], 0x20
05b930: stdw [r10 - 0x38], 0x0
05b938: stdw [r10 - 0x48], 0x0
05b940: mov64 r2, r10
05b948: add64 r2, -0x48
05b950: lddw r1, 0x11c040 ; rodata b'\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00Non'
05b960: call 0x3e47 ; call 0x7aba0
05b968: jeq r0, 0x0, +0x29 ; branch 0x5bab8
05b970: mov64 r3, r10
05b978: add64 r3, -0x1
05b980: lddw r1, 0x11c0fa ; rodata b'a Display implementation returned an error unexpectedly/home/runner/work/pl'
05b990: mov64 r2, 0x37
05b998: lddw r4, 0x122210 ; rodata b'\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \xac\x00\x00\x00\x00\x00\x001\xc1\x11\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00 \x9b\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00'
05b9a8: lddw r5, 0x122230 ; rodata b'\x00\x00\x00\x001\xc1\x11\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00 \x9b\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00`\x86\x00\x00\x00\x00\x00\x00\xd0\xc0\x11\x00\r\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00'
05b9b8: call 0x16ebb ; call 0x112f98
05b9c0: ldxdw r1, [r10 - 0xb8]
05b9c8: stxdw [r10 - 0x138], r1
05b9d0: ldxdw r1, [r10 - 0xb0]
05b9d8: stxdw [r10 - 0x130], r1
05b9e0: ldxdw r1, [r10 - 0xa8]
05b9e8: stxdw [r10 - 0x128], r1
05b9f0: ldxdw r1, [r10 - 0x68]
05b9f8: stxdw [r10 - 0xa0], r1
05ba00: stxdw [r10 - 0x120], r1
05ba08: ldxdw r1, [r10 - 0x60]
05ba10: stxdw [r10 - 0x98], r1
05ba18: stxdw [r10 - 0x118], r1
05ba20: ldxdw r1, [r10 - 0x58]
05ba28: stxdw [r10 - 0x90], r1
05ba30: stxdw [r10 - 0x110], r1
05ba38: stw [r10 - 0xc0], 0x1787
05ba40: lddw r1, 0x11ce40 ; rodata b'programs/pump-amm/src/instructions/token_incentives/claim.rsNo changes in a'
05ba50: stxdw [r10 - 0x150], r1
05ba58: stb [r10 - 0x108], 0x2
05ba60: stw [r10 - 0x140], 0xe4
05ba68: stdw [r10 - 0x148], 0x3c
05ba70: stdw [r10 - 0x158], 0x0
05ba78: mov64 r1, r10
05ba80: add64 r1, -0x1a8
05ba88: mov64 r2, r10
05ba90: add64 r2, -0x158
05ba98: call 0x14ea3 ; call 0x102fb8
05baa0: ldxdw r2, [r10 - 0x1a0]
05baa8: ldxdw r1, [r10 - 0x1a8]
05bab0: ja +0x156 ; branch 0x5c568
05bab8: ldxdw r1, [r10 - 0xb8]
05bac0: stxdw [r10 - 0x138], r1
05bac8: ldxdw r1, [r10 - 0xb0]
05bad0: stxdw [r10 - 0x130], r1
05bad8: ldxdw r1, [r10 - 0xa8]
05bae0: stxdw [r10 - 0x128], r1
05bae8: ldxdw r1, [r10 - 0x68]
05baf0: stxdw [r10 - 0xa0], r1
05baf8: stxdw [r10 - 0x120], r1
05bb00: ldxdw r1, [r10 - 0x60]
05bb08: stxdw [r10 - 0x98], r1
05bb10: stxdw [r10 - 0x118], r1
05bb18: ldxdw r1, [r10 - 0x58]
05bb20: stxdw [r10 - 0x90], r1
05bb28: stxdw [r10 - 0x110], r1
05bb30: stw [r10 - 0xc0], 0x1787
05bb38: lddw r1, 0x11ce40 ; rodata b'programs/pump-amm/src/instructions/token_incentives/claim.rsNo changes in a'
05bb48: stxdw [r10 - 0x150], r1
05bb50: stb [r10 - 0x108], 0x2
05bb58: stw [r10 - 0x140], 0xe4
05bb60: stdw [r10 - 0x148], 0x3c
05bb68: stdw [r10 - 0x158], 0x0
05bb70: mov64 r1, r10
05bb78: add64 r1, -0x188
05bb80: mov64 r2, r10
05bb88: add64 r2, -0x158
05bb90: call 0x14e84 ; call 0x102fb8
05bb98: ldxdw r1, [r10 - 0x180]
05bba0: ldxdw r2, [r10 - 0x188]
05bba8: jne r2, 0x0, +0x6 ; branch 0x5bbe0
05bbb0: ldxdw r2, [r1 + 0x0]
05bbb8: ldxdw r5, [r10 - 0x1b8]
05bbc0: jeq r2, 0x2, +0x0 ; branch 0x5bbc8
05bbc8: ldxb r1, [r1 + 0x50]
05bbd0: jne r1, 0x0, +0x6 ; branch 0x5bc08
05bbd8: ja +0x5 ; branch 0x5bc08
05bbe0: ldxdw r2, [r1 + 0x0]
05bbe8: ldxdw r5, [r10 - 0x1b8]
05bbf0: jeq r2, 0x2, +0x0 ; branch 0x5bbf8
05bbf8: ldxb r1, [r1 + 0x38]
05bc00: jne r1, 0x0, +0x0 ; branch 0x5bc08
05bc08: stxdw [r7 + 0x2e0], r5
05bc10: ldxdw r0, [r7 + 0x2d8]
05bc18: ldxdw r1, [r7 + 0x230]
05bc20: ldxdw r2, [r1 + 0x18]
05bc28: stxdw [r10 - 0x88], r2
05bc30: ldxdw r2, [r1 + 0x10]
05bc38: stxdw [r10 - 0x90], r2
05bc40: ldxdw r2, [r1 + 0x8]
05bc48: stxdw [r10 - 0x98], r2
05bc50: ldxdw r1, [r1 + 0x0]
05bc58: stxdw [r10 - 0xa0], r1
05bc60: lddw r1, 0x300000000
05bc70: ldxdw r2, [r1 + 0x0]
05bc78: mov64 r3, 0x0
05bc80: mov64 r4, 0x1
05bc88: mov64 r1, r2
05bc90: add64 r1, -0x100
05bc98: jgt r1, r2, +0x1 ; branch 0x5bca8
05bca0: mov64 r4, 0x0
05bca8: jne r4, 0x0, +0x1 ; branch 0x5bcb8
05bcb0: mov64 r3, r1
05bcb8: lddw r1, 0x300007f00
05bcc8: jeq r2, 0x0, +0x1 ; branch 0x5bcd8
05bcd0: mov64 r1, r3
05bcd8: lddw r2, 0x300000007
05bce8: jgt r1, r2, +0x3 ; branch 0x5bd08
05bcf0: mov64 r1, 0x1
05bcf8: mov64 r2, 0x100
05bd00: call 0x16ac8 ; call 0x111348
05bd08: lddw r2, 0x300000000
05bd18: stxdw [r2 + 0x0], r1
05bd20: lddw r2, -0x1a6c0df8de09291e
05bd30: stxdw [r1 + 0x0], r2
05bd38: ldxdw r2, [r10 - 0xa0]
05bd40: stxdw [r1 + 0x8], r2
05bd48: ldxdw r2, [r10 - 0x98]
05bd50: stxdw [r1 + 0x10], r2
05bd58: ldxdw r2, [r10 - 0x90]
05bd60: stxdw [r1 + 0x18], r2
05bd68: ldxdw r2, [r10 - 0x88]
05bd70: stxdw [r1 + 0x20], r2
05bd78: stxdw [r10 - 0x1d0], r0
05bd80: stxdw [r1 + 0x40], r0
05bd88: stxdw [r1 + 0x38], r5
05bd90: ldxdw r2, [r10 - 0x1b0]
05bd98: stxdw [r1 + 0x30], r2
05bda0: ldxdw r2, [r10 - 0x1c0]
05bda8: stxdw [r1 + 0x28], r2
05bdb0: stxdw [r10 - 0x158], r1
05bdb8: stdw [r10 - 0x150], 0x48
05bdc0: mov64 r1, r10
05bdc8: add64 r1, -0x158
05bdd0: mov64 r9, 0x1
05bdd8: mov64 r2, 0x1
05bde0: call 0x15593 ; call 0x106a80
05bde8: ldxdw r3, [r7 + 0x268]
05bdf0: ldxdw r1, [r3 + 0x0]
05bdf8: add64 r1, 0x1
05be00: jeq r1, 0x0, +0x1 ; branch 0x5be10
05be08: mov64 r9, 0x0
05be10: ldxdw r2, [r7 + 0x260]
05be18: stxdw [r10 - 0x1d8], r2
05be20: stxdw [r3 + 0x0], r1
05be28: jne r9, 0x1, +0x1 ; branch 0x5be38
05be30: call -0x1
05be38: ldxdw r4, [r7 + 0x270]
05be40: ldxdw r1, [r4 + 0x0]
05be48: add64 r1, 0x1
05be50: mov64 r2, 0x1
05be58: jeq r1, 0x0, +0x1 ; branch 0x5be68
05be60: mov64 r2, 0x0
05be68: stxdw [r10 - 0x1e0], r3
05be70: stxdw [r10 - 0x1c8], r4
05be78: stxdw [r4 + 0x0], r1
05be80: ldxdw r5, [r10 - 0x1b0]
05be88: jne r2, 0x1, +0x1 ; branch 0x5be98
05be90: ja -0xd ; branch 0x5be30
05be98: lddw r1, 0x300000000
05bea8: ldxdw r1, [r1 + 0x0]
05beb0: mov64 r2, r1
05beb8: add64 r2, -0x100
05bec0: mov64 r3, 0x0
05bec8: mov64 r4, 0x1
05bed0: jgt r2, r1, +0x1 ; branch 0x5bee0
05bed8: mov64 r4, 0x0
05bee0: jne r4, 0x0, +0x1 ; branch 0x5bef0
05bee8: mov64 r3, r2
05bef0: lddw r2, 0x300007f00
05bf00: jeq r1, 0x0, +0x1 ; branch 0x5bf10
05bf08: mov64 r2, r3
05bf10: lddw r1, 0x300000007
05bf20: jgt r2, r1, +0x1 ; branch 0x5bf30
05bf28: ja -0x48 ; branch 0x5bcf0
05bf30: ldxb r8, [r8 + 0x21]
05bf38: ldxb r1, [r7 + 0x28a]
05bf40: stxdw [r10 - 0x200], r1
05bf48: ldxb r1, [r7 + 0x289]
05bf50: stxdw [r10 - 0x1f8], r1
05bf58: ldxb r1, [r7 + 0x288]
05bf60: stxdw [r10 - 0x1f0], r1
05bf68: ldxdw r1, [r7 + 0x280]
05bf70: stxdw [r10 - 0x1e8], r1
05bf78: ldxdw r9, [r7 + 0x278]
05bf80: lddw r3, 0x300000000
05bf90: stxdw [r3 + 0x0], r2
05bf98: lddw r1, -0x1a6c0df8de09291e
05bfa8: stxdw [r2 + 0x0], r1
05bfb0: ldxdw r1, [r10 - 0xa0]
05bfb8: stxdw [r2 + 0x8], r1
05bfc0: ldxdw r1, [r10 - 0x98]
05bfc8: stxdw [r2 + 0x10], r1
05bfd0: ldxdw r1, [r10 - 0x90]
05bfd8: stxdw [r2 + 0x18], r1
05bfe0: ldxdw r1, [r10 - 0x88]
05bfe8: stxdw [r2 + 0x20], r1
05bff0: ldxdw r1, [r10 - 0x1d0]
05bff8: stxdw [r2 + 0x40], r1
05c000: ldxdw r1, [r10 - 0x1b8]
05c008: stxdw [r2 + 0x38], r1
05c010: stxdw [r2 + 0x30], r5
05c018: ldxdw r1, [r10 - 0x1c0]
05c020: stxdw [r2 + 0x28], r1
05c028: mov64 r1, 0x0
05c030: mov64 r4, 0x50
05c038: jslt r4, 0x0, +0xa8 ; branch 0x5c580
05c040: ldxdw r1, [r3 + 0x0]
05c048: lddw r0, 0x300008000
05c058: jeq r1, 0x0, +0x1 ; branch 0x5c068
05c060: mov64 r0, r1
05c068: mov64 r5, r0
05c070: sub64 r5, r4
05c078: mov64 r3, 0x0
05c080: mov64 r1, 0x1
05c088: mov64 r4, 0x1
05c090: jgt r5, r0, +0x1 ; branch 0x5c0a0
05c098: mov64 r4, 0x0
05c0a0: jne r4, 0x0, +0x1 ; branch 0x5c0b0
05c0a8: mov64 r3, r5
05c0b0: lddw r4, 0x300000008
05c0c0: jlt r3, r4, +0x97 ; branch 0x5c580
05c0c8: lddw r1, 0x300000000
05c0d8: stxdw [r1 + 0x0], r3
05c0e0: lddw r1, 0x1d9acb512ea545e4
05c0f0: stxdw [r3 + 0x0], r1
05c0f8: mov64 r1, 0x0
05c100: mov64 r4, r3
05c108: add64 r4, r1
05c110: mov64 r5, r2
05c118: add64 r5, r1
05c120: ldxb r5, [r5 + 0x0]
05c128: stxb [r4 + 0x8], r5
05c130: add64 r1, 0x1
05c138: jeq r1, 0x48, +0x1 ; branch 0x5c148
05c140: ja -0x9 ; branch 0x5c100
05c148: lddw r1, 0x300000000
05c158: ldxdw r2, [r1 + 0x0]
05c160: mov64 r1, r2
05c168: add64 r1, -0x22
05c170: mov64 r4, 0x0
05c178: mov64 r5, 0x1
05c180: jgt r1, r2, +0x1 ; branch 0x5c190
05c188: mov64 r5, 0x0
05c190: jne r5, 0x0, +0x1 ; branch 0x5c1a0
05c198: mov64 r4, r1
05c1a0: lddw r1, 0x300007fde
05c1b0: jeq r2, 0x0, +0x1 ; branch 0x5c1c0
05c1b8: mov64 r1, r4
05c1c0: stxdw [r10 - 0x1b0], r8
05c1c8: lddw r2, 0x300000007
05c1d8: jgt r1, r2, +0x3 ; branch 0x5c1f8
05c1e0: mov64 r1, 0x1
05c1e8: mov64 r2, 0x22
05c1f0: call 0x16a2d ; call 0x111360
05c1f8: lddw r2, 0x300000000
05c208: stxdw [r2 + 0x0], r1
05c210: ldxdw r8, [r10 - 0x1d8]
05c218: ldxdw r2, [r8 + 0x0]
05c220: ldxdw r4, [r8 + 0x8]
05c228: ldxdw r5, [r8 + 0x10]
05c230: ldxdw r0, [r8 + 0x18]
05c238: stxdw [r1 + 0x18], r0
05c240: stxdw [r1 + 0x10], r5
05c248: stxdw [r1 + 0x8], r4
05c250: stxdw [r1 + 0x0], r2
05c258: sth [r1 + 0x20], 0x1
05c260: stxdw [r10 - 0x40], r1
05c268: stdw [r10 - 0x38], 0x1
05c270: stdw [r10 - 0x48], 0x1
05c278: mov64 r7, r10
05c280: add64 r7, -0x158
05c288: mov64 r5, r10
05c290: add64 r5, -0x48
05c298: mov64 r1, r7
05c2a0: lddw r2, 0x11e53e ; rodata b'\x0c\x14\xde\xfc\x82^\xc6v\x94%\x08\x18\xbbe@e\xf4)\x8d1V\xd5q\xb4\xd4\xf8\t\x0c\x18\xe9\xa8c\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15h\xbf\x17[\xaaQ\x89\xcb\x97\xf5\xd2\xff;e]+\xb6\xfdm\x18\xb0\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15'
05c2b0: mov64 r4, 0x50
05c2b8: call 0x16312 ; call 0x10db50
05c2c0: ldxdw r1, [r10 - 0x200]
05c2c8: stxb [r10 - 0x1e], r1
05c2d0: ldxdw r1, [r10 - 0x1f8]
05c2d8: stxb [r10 - 0x1f], r1
05c2e0: ldxdw r1, [r10 - 0x1f0]
05c2e8: stxb [r10 - 0x20], r1
05c2f0: ldxdw r1, [r10 - 0x1e8]
05c2f8: stxdw [r10 - 0x28], r1
05c300: stxdw [r10 - 0x30], r9
05c308: ldxdw r1, [r10 - 0x1c8]
05c310: stxdw [r10 - 0x38], r1
05c318: ldxdw r9, [r10 - 0x1e0]
05c320: stxdw [r10 - 0x40], r9
05c328: stxdw [r10 - 0x48], r8
05c330: mov64 r1, r10
05c338: add64 r1, -0x68
05c340: stxdw [r10 - 0xb8], r1
05c348: mov64 r1, r10
05c350: add64 r1, -0x1
05c358: stxdw [r10 - 0x58], r1
05c360: lddw r1, 0x11c646 ; rodata b'__event_authorityGlobalVolumeAccumulator=programs/pump-amm/src/instructions'
05c370: stxdw [r10 - 0x68], r1
05c378: ldxdw r1, [r10 - 0x1b0]
05c380: stxb [r10 - 0x1], r1
05c388: stdw [r10 - 0xb0], 0x2
05c390: stdw [r10 - 0x50], 0x1
05c398: stdw [r10 - 0x60], 0x11
05c3a0: mov64 r1, r10
05c3a8: add64 r1, -0xb8
05c3b0: stxdw [r10 - 0x1000], r1
05c3b8: stdw [r10 - 0xff8], 0x1
05c3c0: mov64 r1, r10
05c3c8: add64 r1, -0x80
05c3d0: mov64 r3, r10
05c3d8: add64 r3, -0x48
05c3e0: mov64 r5, r10
05c3e8: mov64 r2, r7
05c3f0: mov64 r4, 0x1
05c3f8: call 0x154d7 ; call 0x106ab8
05c400: lddw r1, -0x7fffffffffffffe6
05c410: ldxdw r2, [r10 - 0x80]
05c418: jeq r2, r1, +0x1 ; branch 0x5c428
05c420: ja +0x11 ; branch 0x5c4b0
05c428: ldxdw r1, [r9 + 0x0]
05c430: add64 r1, -0x1
05c438: stxdw [r9 + 0x0], r1
05c440: jne r1, 0x0, +0x3 ; branch 0x5c460
05c448: ldxdw r1, [r9 + 0x8]
05c450: add64 r1, -0x1
05c458: stxdw [r9 + 0x8], r1
05c460: ldxdw r2, [r10 - 0x1c8]
05c468: ldxdw r1, [r2 + 0x0]
05c470: add64 r1, -0x1
05c478: stxdw [r2 + 0x0], r1
05c480: jne r1, 0x0, +0x3 ; branch 0x5c4a0
05c488: ldxdw r1, [r2 + 0x8]
05c490: add64 r1, -0x1
05c498: stxdw [r2 + 0x8], r1
05c4a0: mov64 r1, 0x2
05c4a8: ja +0x17 ; branch 0x5c568
05c4b0: mov64 r1, r10
05c4b8: add64 r1, -0x198
05c4c0: mov64 r2, r10
05c4c8: add64 r2, -0x80
05c4d0: call 0x14d6d ; call 0x103040
05c4d8: ldxdw r3, [r10 - 0x38]
05c4e0: ldxdw r2, [r10 - 0x190]
05c4e8: ldxdw r1, [r10 - 0x198]
05c4f0: ldxdw r4, [r10 - 0x40]
05c4f8: ldxdw r5, [r4 + 0x0]
05c500: add64 r5, -0x1
05c508: stxdw [r4 + 0x0], r5
05c510: jne r5, 0x0, +0x3 ; branch 0x5c530
05c518: ldxdw r5, [r4 + 0x8]
05c520: add64 r5, -0x1
05c528: stxdw [r4 + 0x8], r5
05c530: ldxdw r4, [r3 + 0x0]
05c538: add64 r4, -0x1
05c540: stxdw [r3 + 0x0], r4
05c548: jne r4, 0x0, +0x3 ; branch 0x5c568
05c550: ldxdw r4, [r3 + 0x8]
05c558: add64 r4, -0x1
05c560: stxdw [r3 + 0x8], r4
05c568: stxdw [r6 + 0x8], r2
05c570: stxdw [r6 + 0x0], r1
05c578: exit
05c580: mov64 r2, 0x50
05c588: call 0x169b7 ; call 0x111348
