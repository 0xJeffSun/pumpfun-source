0ed210: mov64 r8, r4
0ed218: mov64 r9, r3
0ed220: mov64 r7, r2
0ed228: mov64 r6, r1
0ed230: lddw r1, 0x11eb06 ; rodata b'Instruction: ClaimCashbacksol_destinationbufferidltoIdlAccount\x06\xdd\xf6\xe1\xd7e\xa1\x93\xd9\xcb\xe1F\xce'
0ed240: mov64 r2, 0x1a
0ed248: call -0x1
0ed250: sth [r10 - 0x622], 0xffff
0ed258: stxdw [r10 - 0x618], r8
0ed260: stxdw [r10 - 0x620], r9
0ed268: mov64 r1, r10
0ed270: add64 r1, -0x622
0ed278: stxdw [r10 - 0xff8], r1
0ed280: mov64 r1, r10
0ed288: add64 r1, -0x308
0ed290: mov64 r3, r10
0ed298: add64 r3, -0x620
0ed2a0: mov64 r5, r10
0ed2a8: mov64 r2, r7
0ed2b0: call -0x418c ; call 0xcc658
0ed2b8: ldxw r8, [r10 - 0x308]
0ed2c0: jeq r8, 0x2, +0x4e ; branch 0xed538
0ed2c8: stxdw [r10 - 0x650], r6
0ed2d0: ldxw r1, [r10 - 0x304]
0ed2d8: stxdw [r10 - 0x658], r1
0ed2e0: ldxdw r6, [r10 - 0x300]
0ed2e8: ldxdw r9, [r10 - 0x2f8]
0ed2f0: mov64 r1, r10
0ed2f8: add64 r1, -0x5f8
0ed300: mov64 r2, r10
0ed308: add64 r2, -0x2f0
0ed310: mov64 r3, 0x2f0
0ed318: call 0x58af ; call 0x119898
0ed320: stxdw [r10 - 0x600], r9
0ed328: stxdw [r10 - 0x608], r6
0ed330: ldxdw r1, [r10 - 0x658]
0ed338: stxw [r10 - 0x60c], r1
0ed340: stxw [r10 - 0x610], r8
0ed348: ldxb r1, [r10 - 0x621]
0ed350: stxb [r10 - 0x2e7], r1
0ed358: ldxb r1, [r10 - 0x622]
0ed360: stxb [r10 - 0x2e8], r1
0ed368: ldxdw r1, [r10 - 0x618]
0ed370: stxdw [r10 - 0x2f0], r1
0ed378: ldxdw r1, [r10 - 0x620]
0ed380: stxdw [r10 - 0x2f8], r1
0ed388: mov64 r1, r10
0ed390: add64 r1, -0x610
0ed398: stxdw [r10 - 0x300], r1
0ed3a0: stxdw [r10 - 0x308], r7
0ed3a8: mov64 r1, r10
0ed3b0: add64 r1, -0x638
0ed3b8: mov64 r2, r10
0ed3c0: add64 r2, -0x308
0ed3c8: call -0x123c3 ; call 0x5b5b8
0ed3d0: ldxdw r1, [r10 - 0x638]
0ed3d8: jeq r1, 0x2, +0x1 ; branch 0xed3e8
0ed3e0: ja +0x2f ; branch 0xed560
0ed3e8: mov64 r1, r10
0ed3f0: add64 r1, -0x648
0ed3f8: mov64 r2, r10
0ed400: add64 r2, -0x610
0ed408: mov64 r3, r7
0ed410: call -0x3dfc ; call 0xce438
0ed418: ldxdw r3, [r10 - 0x3d0]
0ed420: ldxdw r4, [r10 - 0x3d8]
0ed428: ldxdw r5, [r4 + 0x0]
0ed430: add64 r5, -0x1
0ed438: ldxdw r2, [r10 - 0x640]
0ed440: ldxdw r1, [r10 - 0x648]
0ed448: stxdw [r4 + 0x0], r5
0ed450: jne r5, 0x0, +0x3 ; branch 0xed470
0ed458: ldxdw r5, [r4 + 0x8]
0ed460: add64 r5, -0x1
0ed468: stxdw [r4 + 0x8], r5
0ed470: ldxdw r4, [r3 + 0x0]
0ed478: add64 r4, -0x1
0ed480: stxdw [r3 + 0x0], r4
0ed488: ldxdw r6, [r10 - 0x650]
0ed490: jne r4, 0x0, +0x3 ; branch 0xed4b0
0ed498: ldxdw r4, [r3 + 0x8]
0ed4a0: add64 r4, -0x1
0ed4a8: stxdw [r3 + 0x8], r4
0ed4b0: ldxdw r3, [r10 - 0x3a0]
0ed4b8: ldxdw r4, [r10 - 0x3a8]
0ed4c0: ldxdw r5, [r4 + 0x0]
0ed4c8: add64 r5, -0x1
0ed4d0: stxdw [r4 + 0x0], r5
0ed4d8: jne r5, 0x0, +0x3 ; branch 0xed4f8
0ed4e0: ldxdw r5, [r4 + 0x8]
0ed4e8: add64 r5, -0x1
0ed4f0: stxdw [r4 + 0x8], r5
0ed4f8: ldxdw r4, [r3 + 0x0]
0ed500: add64 r4, -0x1
0ed508: stxdw [r3 + 0x0], r4
0ed510: jne r4, 0x0, +0x6 ; branch 0xed548
0ed518: ldxdw r4, [r3 + 0x8]
0ed520: add64 r4, -0x1
0ed528: stxdw [r3 + 0x8], r4
0ed530: ja +0x2 ; branch 0xed548
0ed538: ldxdw r2, [r10 - 0x2f8]
0ed540: ldxdw r1, [r10 - 0x300]
0ed548: stxdw [r6 + 0x8], r2
0ed550: stxdw [r6 + 0x0], r1
0ed558: exit
0ed560: ldxdw r2, [r10 - 0x630]
0ed568: ldxdw r3, [r10 - 0x3d0]
0ed570: ldxdw r4, [r10 - 0x3d8]
0ed578: ldxdw r5, [r4 + 0x0]
0ed580: add64 r5, -0x1
0ed588: stxdw [r4 + 0x0], r5
0ed590: jne r5, 0x0, +0x3 ; branch 0xed5b0
0ed598: ldxdw r5, [r4 + 0x8]
0ed5a0: add64 r5, -0x1
0ed5a8: stxdw [r4 + 0x8], r5
0ed5b0: ldxdw r4, [r3 + 0x0]
0ed5b8: add64 r4, -0x1
0ed5c0: stxdw [r3 + 0x0], r4
0ed5c8: ldxdw r6, [r10 - 0x650]
0ed5d0: jne r4, 0x0, +0x3 ; branch 0xed5f0
0ed5d8: ldxdw r4, [r3 + 0x8]
0ed5e0: add64 r4, -0x1
0ed5e8: stxdw [r3 + 0x8], r4
0ed5f0: ldxdw r3, [r10 - 0x3a0]
0ed5f8: ldxdw r4, [r10 - 0x3a8]
0ed600: ldxdw r5, [r4 + 0x0]
0ed608: add64 r5, -0x1
0ed610: stxdw [r4 + 0x0], r5
0ed618: jne r5, 0x0, +0x3 ; branch 0xed638
0ed620: ldxdw r5, [r4 + 0x8]
0ed628: add64 r5, -0x1
0ed630: stxdw [r4 + 0x8], r5
0ed638: ldxdw r4, [r3 + 0x0]
0ed640: add64 r4, -0x1
0ed648: stxdw [r3 + 0x0], r4
0ed650: jne r4, 0x0, -0x22 ; branch 0xed548
0ed658: ja -0x29 ; branch 0xed518
