0cc658: mov64 r8, r3
0cc660: mov64 r6, r1
0cc668: ldxdw r1, [r8 + 0x8]
0cc670: jeq r1, 0x0, +0x4e ; branch 0xcc8e8
0cc678: ldxdw r5, [r5 - 0xff8]
0cc680: add64 r1, -0x1
0cc688: stxdw [r8 + 0x8], r1
0cc690: ldxdw r1, [r8 + 0x0]
0cc698: mov64 r3, r1
0cc6a0: add64 r3, 0x30
0cc6a8: stxdw [r8 + 0x0], r3
0cc6b0: ldxdw r9, [r1 + 0x8]
0cc6b8: ldxdw r0, [r9 + 0x0]
0cc6c0: add64 r0, 0x1
0cc6c8: mov64 r3, 0x1
0cc6d0: jeq r0, 0x0, +0x1 ; branch 0xcc6e0
0cc6d8: mov64 r3, 0x0
0cc6e0: ldxdw r4, [r1 + 0x0]
0cc6e8: stxdw [r9 + 0x0], r0
0cc6f0: jne r3, 0x1, +0x1 ; branch 0xcc700
0cc6f8: call -0x1
0cc700: ldxdw r7, [r1 + 0x10]
0cc708: ldxdw r0, [r7 + 0x0]
0cc710: add64 r0, 0x1
0cc718: mov64 r3, 0x1
0cc720: jeq r0, 0x0, +0x1 ; branch 0xcc730
0cc728: mov64 r3, 0x0
0cc730: stxdw [r10 - 0x628], r2
0cc738: stxdw [r10 - 0x620], r5
0cc740: stxdw [r10 - 0x618], r4
0cc748: stxdw [r7 + 0x0], r0
0cc750: jne r3, 0x1, +0x1 ; branch 0xcc760
0cc758: ja -0xd ; branch 0xcc6f8
0cc760: ldxb r2, [r1 + 0x2a]
0cc768: stxdw [r10 - 0x640], r2
0cc770: ldxb r2, [r1 + 0x29]
0cc778: stxdw [r10 - 0x610], r2
0cc780: ldxb r2, [r1 + 0x28]
0cc788: stxdw [r10 - 0x648], r2
0cc790: ldxdw r2, [r1 + 0x20]
0cc798: stxdw [r10 - 0x638], r2
0cc7a0: ldxdw r1, [r1 + 0x18]
0cc7a8: stxdw [r10 - 0x630], r1
0cc7b0: mov64 r1, r10
0cc7b8: add64 r1, -0x198
0cc7c0: mov64 r2, r8
0cc7c8: call -0x17867 ; call 0x10498
0cc7d0: ldxdw r3, [r10 - 0x190]
0cc7d8: ldxdw r2, [r10 - 0x198]
0cc7e0: ldxb r1, [r10 - 0x13f]
0cc7e8: jeq r1, 0x2, +0x31 ; branch 0xcc978
0cc7f0: stxdw [r10 - 0x660], r1
0cc7f8: stxdw [r10 - 0x650], r2
0cc800: stxdw [r10 - 0x658], r3
0cc808: mov64 r1, r10
0cc810: add64 r1, -0x3e0
0cc818: mov64 r2, r10
0cc820: add64 r2, -0x188
0cc828: mov64 r3, 0x49
0cc830: call 0x9a0c ; call 0x119898
0cc838: ldxw r1, [r10 - 0x13e]
0cc840: stxw [r10 - 0x3e8], r1
0cc848: ldxh r1, [r10 - 0x13a]
0cc850: stxh [r10 - 0x3e4], r1
0cc858: mov64 r1, r10
0cc860: add64 r1, -0x198
0cc868: mov64 r2, r8
0cc870: call -0x198be ; call 0x288
0cc878: ldxw r1, [r10 - 0x198]
0cc880: jeq r1, 0x2, +0x1 ; branch 0xcc890
0cc888: ja +0x37 ; branch 0xcca48
0cc890: ldxdw r3, [r10 - 0x188]
0cc898: ldxdw r2, [r10 - 0x190]
0cc8a0: mov64 r1, r10
0cc8a8: add64 r1, -0x5d8
0cc8b0: lddw r4, 0x11e1d6 ; rodata b'quote_mintbase_mintauthoritybase_token_programcoin_creator_vault_atacoin_cr'
0cc8c0: mov64 r5, 0xa
0cc8c8: call -0x1956b ; call 0x1d78
0cc8d0: ldxdw r1, [r10 - 0x5d8]
0cc8d8: ldxdw r2, [r10 - 0x5d0]
0cc8e0: ja +0x1a ; branch 0xcc9b8
0cc8e8: mov64 r1, r10
0cc8f0: add64 r1, -0x5f8
0cc8f8: mov64 r2, 0xbbd
0cc900: call 0x72a6 ; call 0x105e38
0cc908: ldxdw r3, [r10 - 0x5f0]
0cc910: ldxdw r2, [r10 - 0x5f8]
0cc918: mov64 r1, r10
0cc920: add64 r1, -0x608
0cc928: lddw r4, 0x11c004 ; rodata b'userbaseS\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x001\x00\x00\x00Some\x10\x00\x00\x00L\x00\x00\x00O\x00\x00\x00 <= trueM\x00\x00\x00\x06\x00\x00\x00\xd6\x07\x00\x00\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00'
0cc938: mov64 r5, 0x4
0cc940: call -0x1957a ; call 0x1d78
0cc948: ldxdw r1, [r10 - 0x608]
0cc950: ldxdw r2, [r10 - 0x600]
0cc958: stxdw [r6 + 0x10], r2
0cc960: stxdw [r6 + 0x8], r1
0cc968: stw [r6 + 0x0], 0x2
0cc970: ja +0x19 ; branch 0xcca40
0cc978: mov64 r1, r10
0cc980: add64 r1, -0x5e8
0cc988: lddw r4, 0x11cd4b ; rodata b'user_volume_accumulatorpool-v2programs/pump-amm/src/instructions/swap/trade'
0cc998: mov64 r5, 0x17
0cc9a0: call -0x19586 ; call 0x1d78
0cc9a8: ldxdw r1, [r10 - 0x5e8]
0cc9b0: ldxdw r2, [r10 - 0x5e0]
0cc9b8: stxdw [r6 + 0x10], r2
0cc9c0: stxdw [r6 + 0x8], r1
0cc9c8: stw [r6 + 0x0], 0x2
0cc9d0: ldxdw r1, [r9 + 0x0]
0cc9d8: add64 r1, -0x1
0cc9e0: stxdw [r9 + 0x0], r1
0cc9e8: jne r1, 0x0, +0x3 ; branch 0xcca08
0cc9f0: ldxdw r1, [r9 + 0x8]
0cc9f8: add64 r1, -0x1
0cca00: stxdw [r9 + 0x8], r1
0cca08: ldxdw r1, [r7 + 0x0]
0cca10: add64 r1, -0x1
0cca18: stxdw [r7 + 0x0], r1
0cca20: jne r1, 0x0, +0x3 ; branch 0xcca40
0cca28: ldxdw r1, [r7 + 0x8]
0cca30: add64 r1, -0x1
0cca38: stxdw [r7 + 0x8], r1
0cca40: exit
0cca48: stxdw [r10 - 0x680], r1
0cca50: ldxdw r1, [r10 - 0x188]
0cca58: stxdw [r10 - 0x678], r1
0cca60: ldxdw r1, [r10 - 0x190]
0cca68: stxdw [r10 - 0x670], r1
0cca70: ldxw r1, [r10 - 0x194]
0cca78: stxdw [r10 - 0x688], r1
0cca80: mov64 r1, r10
0cca88: add64 r1, -0x370
0cca90: mov64 r2, r10
0cca98: add64 r2, -0x180
0ccaa0: mov64 r3, 0x40
0ccaa8: call 0x99bd ; call 0x119898
0ccab0: ldxdw r1, [r10 - 0x138]
0ccab8: stxdw [r10 - 0x390], r1
0ccac0: ldxdw r1, [r10 - 0x130]
0ccac8: stxdw [r10 - 0x388], r1
0ccad0: ldxdw r1, [r10 - 0x128]
0ccad8: stxdw [r10 - 0x380], r1
0ccae0: ldxdw r1, [r10 - 0x120]
0ccae8: stxdw [r10 - 0x378], r1
0ccaf0: ldxdw r1, [r10 - 0x140]
0ccaf8: stxdw [r10 - 0x668], r1
0ccb00: mov64 r1, r10
0ccb08: add64 r1, -0x198
0ccb10: mov64 r2, r8
0ccb18: call -0x19940 ; call 0x120
0ccb20: ldxdw r3, [r10 - 0x190]
0ccb28: ldxdw r2, [r10 - 0x198]
0ccb30: jeq r2, 0x2, +0x1 ; branch 0xccb40
0ccb38: ja +0x13 ; branch 0xccbd8
0ccb40: stxdw [r10 - 0x690], r3
0ccb48: mov64 r1, r10
0ccb50: add64 r1, -0x198
0ccb58: mov64 r2, r8
0ccb60: call -0x19933 ; call 0x1d0
0ccb68: ldxdw r3, [r10 - 0x190]
0ccb70: ldxdw r2, [r10 - 0x198]
0ccb78: ldxw r1, [r10 - 0xe8]
0ccb80: jeq r1, 0x2, +0x1 ; branch 0xccb90
0ccb88: ja +0x12 ; branch 0xccc20
0ccb90: mov64 r1, r10
0ccb98: add64 r1, -0x5c8
0ccba0: lddw r4, 0x11e417 ; rodata b'user_volume_accumulator_wsol_token_accountuser_wsol_token_accountprograms/p'
0ccbb0: mov64 r5, 0x2a
0ccbb8: call -0x195c9 ; call 0x1d78
0ccbc0: ldxdw r1, [r10 - 0x5c8]
0ccbc8: ldxdw r2, [r10 - 0x5c0]
0ccbd0: ja -0x44 ; branch 0xcc9b8
0ccbd8: mov64 r1, r10
0ccbe0: add64 r1, -0x3f8
0ccbe8: lddw r4, 0x11e1ac ; rodata b'quote_token_programpool_base_token_accountquote_mintbase_mintauthoritybase_'
0ccbf8: mov64 r5, 0x13
0ccc00: call -0x195d2 ; call 0x1d78
0ccc08: ldxdw r1, [r10 - 0x3f8]
0ccc10: ldxdw r2, [r10 - 0x3f0]
0ccc18: ja -0x4d ; branch 0xcc9b8
0ccc20: stxdw [r10 - 0x6b0], r1
0ccc28: stxdw [r10 - 0x6a8], r2
0ccc30: stxdw [r10 - 0x6a0], r3
0ccc38: ldxdw r1, [r10 - 0x180]
0ccc40: stxdw [r10 - 0x278], r1
0ccc48: ldxdw r1, [r10 - 0x188]
0ccc50: stxdw [r10 - 0x280], r1
0ccc58: ldxdw r1, [r10 - 0x178]
0ccc60: stxdw [r10 - 0x698], r1
0ccc68: mov64 r1, r10
0ccc70: add64 r1, -0x2c0
0ccc78: mov64 r2, r10
0ccc80: add64 r2, -0x170
0ccc88: mov64 r3, 0x40
0ccc90: call 0x9980 ; call 0x119898
0ccc98: mov64 r1, r10
0ccca0: add64 r1, -0x308
0ccca8: mov64 r2, r10
0cccb0: add64 r2, -0x130
0cccb8: mov64 r3, 0x48
0cccc0: call 0x997a ; call 0x119898
0cccc8: ldxdw r1, [r10 - 0xe4]
0cccd0: stxdw [r10 - 0x330], r1
0cccd8: ldxdw r1, [r10 - 0xdc]
0ccce0: stxdw [r10 - 0x328], r1
0ccce8: ldxdw r1, [r10 - 0xd4]
0cccf0: stxdw [r10 - 0x320], r1
0cccf8: ldxdw r1, [r10 - 0xcc]
0ccd00: stxdw [r10 - 0x318], r1
0ccd08: ldxw r1, [r10 - 0xc4]
0ccd10: stxw [r10 - 0x310], r1
0ccd18: mov64 r1, r10
0ccd20: add64 r1, -0x198
0ccd28: mov64 r2, r8
0ccd30: call -0x1996d ; call 0x1d0
0ccd38: ldxdw r3, [r10 - 0x190]
0ccd40: ldxdw r2, [r10 - 0x198]
0ccd48: ldxw r1, [r10 - 0xe8]
0ccd50: jeq r1, 0x2, +0x1 ; branch 0xccd60
0ccd58: ja +0x9 ; branch 0xccda8
0ccd60: mov64 r1, r10
0ccd68: add64 r1, -0x5b8
0ccd70: lddw r4, 0x11e441 ; rodata b'user_wsol_token_accountprograms/pump-amm/src/instructions/token_incentives/'
0ccd80: mov64 r5, 0x17
0ccd88: call -0x19603 ; call 0x1d78
0ccd90: ldxdw r1, [r10 - 0x5b8]
0ccd98: ldxdw r2, [r10 - 0x5b0]
0ccda0: ja -0x7e ; branch 0xcc9b8
0ccda8: stxdw [r10 - 0x6c0], r1
0ccdb0: mov64 r1, r10
0ccdb8: add64 r1, -0x260
0ccdc0: stxdw [r10 - 0x6b8], r2
0ccdc8: mov64 r2, r10
0ccdd0: add64 r2, -0x188
0ccdd8: stxdw [r10 - 0x6c8], r3
0ccde0: mov64 r3, 0xa0
0ccde8: call 0x9955 ; call 0x119898
0ccdf0: ldxdw r1, [r10 - 0xe4]
0ccdf8: stxdw [r10 - 0x1bc], r1
0cce00: ldxdw r1, [r10 - 0xdc]
0cce08: stxdw [r10 - 0x1b4], r1
0cce10: ldxdw r1, [r10 - 0xd4]
0cce18: stxdw [r10 - 0x1ac], r1
0cce20: ldxdw r1, [r10 - 0xcc]
0cce28: stxdw [r10 - 0x1a4], r1
0cce30: ldxw r1, [r10 - 0xc4]
0cce38: stxw [r10 - 0x19c], r1
0cce40: ldxdw r1, [r10 - 0x6c0]
0cce48: stxw [r10 - 0x1c0], r1
0cce50: ldxdw r1, [r10 - 0x6c8]
0cce58: stxdw [r10 - 0x268], r1
0cce60: ldxdw r1, [r10 - 0x6b8]
0cce68: stxdw [r10 - 0x270], r1
0cce70: mov64 r1, r10
0cce78: add64 r1, -0x198
0cce80: mov64 r2, r8
0cce88: call -0x17868 ; call 0x10b50
0cce90: ldxdw r3, [r10 - 0x190]
0cce98: ldxdw r2, [r10 - 0x198]
0ccea0: jeq r2, 0x2, +0x1 ; branch 0xcceb0
0ccea8: ja +0x13 ; branch 0xccf48
0cceb0: stxdw [r10 - 0x6b8], r3
0cceb8: mov64 r1, r10
0ccec0: add64 r1, -0x198
0ccec8: mov64 r2, r8
0cced0: call -0x1956d ; call 0x2370
0cced8: ldxdw r3, [r10 - 0x190]
0ccee0: ldxdw r2, [r10 - 0x198]
0ccee8: ldxb r1, [r10 - 0x16e]
0ccef0: jeq r1, 0x2, +0x1 ; branch 0xccf00
0ccef8: ja +0x12 ; branch 0xccf90
0ccf00: mov64 r1, r10
0ccf08: add64 r1, -0x5a8
0ccf10: lddw r4, 0x11e0ad ; rodata b'event_authoritypool_authorityprogramsystem_programglobal_incentive_token_ac'
0ccf20: mov64 r5, 0xf
0ccf28: call -0x19637 ; call 0x1d78
0ccf30: ldxdw r1, [r10 - 0x5a8]
0ccf38: ldxdw r2, [r10 - 0x5a0]
0ccf40: ja -0xb2 ; branch 0xcc9b8
0ccf48: mov64 r1, r10
0ccf50: add64 r1, -0x408
0ccf58: lddw r4, 0x11e0d1 ; rodata b'system_programglobal_incentive_token_accountadmintoken_programassociated_to'
0ccf68: mov64 r5, 0xe
0ccf70: call -0x19640 ; call 0x1d78
0ccf78: ldxdw r1, [r10 - 0x408]
0ccf80: ldxdw r2, [r10 - 0x400]
0ccf88: ja -0xbb ; branch 0xcc9b8
0ccf90: stxdw [r10 - 0x6d8], r1
0ccf98: stxdw [r10 - 0x6d0], r2
0ccfa0: stxdw [r10 - 0x6c8], r3
0ccfa8: ldxdw r1, [r10 - 0x180]
0ccfb0: stxdw [r10 - 0xb8], r1
0ccfb8: ldxdw r1, [r10 - 0x178]
0ccfc0: stxdw [r10 - 0xb0], r1
0ccfc8: ldxh r1, [r10 - 0x170]
0ccfd0: stxh [r10 - 0xa8], r1
0ccfd8: ldxw r1, [r10 - 0x16d]
0ccfe0: stxw [r10 - 0xc0], r1
0ccfe8: ldxb r1, [r10 - 0x169]
0ccff0: stxb [r10 - 0xbc], r1
0ccff8: ldxdw r1, [r10 - 0x188]
0cd000: stxdw [r10 - 0x6c0], r1
0cd008: mov64 r1, r10
0cd010: add64 r1, -0x198
0cd018: mov64 r2, r8
0cd020: call -0x17856 ; call 0x10d78
0cd028: ldxdw r3, [r10 - 0x190]
0cd030: ldxdw r2, [r10 - 0x198]
0cd038: jeq r2, 0x2, +0x1 ; branch 0xcd048
0cd040: ja +0x5f ; branch 0xcd340
0cd048: ldxdw r1, [r10 - 0x610]
0cd050: jeq r1, 0x0, +0x66 ; branch 0xcd388
0cd058: stxdw [r10 - 0x6e0], r3
0cd060: ldxdw r2, [r10 - 0x618]
0cd068: ldxdw r1, [r2 + 0x18]
0cd070: stxdw [r10 - 0x8], r1
0cd078: ldxdw r1, [r2 + 0x10]
0cd080: stxdw [r10 - 0x10], r1
0cd088: ldxdw r1, [r2 + 0x8]
0cd090: stxdw [r10 - 0x18], r1
0cd098: ldxdw r1, [r2 + 0x0]
0cd0a0: stxdw [r10 - 0x20], r1
0cd0a8: mov64 r1, r10
0cd0b0: add64 r1, -0x20
0cd0b8: stxdw [r10 - 0x30], r1
0cd0c0: lddw r1, 0x11cd4b ; rodata b'user_volume_accumulatorpool-v2programs/pump-amm/src/instructions/swap/trade'
0cd0d0: stxdw [r10 - 0x40], r1
0cd0d8: stdw [r10 - 0x28], 0x20
0cd0e0: stdw [r10 - 0x38], 0x17
0cd0e8: mov64 r1, r10
0cd0f0: add64 r1, -0x198
0cd0f8: mov64 r2, r10
0cd100: add64 r2, -0x40
0cd108: mov64 r3, 0x2
0cd110: ldxdw r4, [r10 - 0x628]
0cd118: call 0x81e9 ; call 0x10e068
0cd120: ldxdw r1, [r10 - 0x180]
0cd128: stxdw [r10 - 0x88], r1
0cd130: ldxdw r1, [r10 - 0x188]
0cd138: stxdw [r10 - 0x90], r1
0cd140: ldxdw r1, [r10 - 0x190]
0cd148: stxdw [r10 - 0x98], r1
0cd150: ldxdw r1, [r10 - 0x198]
0cd158: stxdw [r10 - 0xa0], r1
0cd160: ldxb r1, [r10 - 0x178]
0cd168: ldxdw r2, [r10 - 0x620]
0cd170: stxb [r2 + 0x0], r1
0cd178: ldxdw r1, [r10 - 0x650]
0cd180: ldxdw r8, [r1 + 0x0]
0cd188: ldxdw r1, [r8 + 0x18]
0cd190: stxdw [r10 - 0x180], r1
0cd198: ldxdw r1, [r8 + 0x10]
0cd1a0: stxdw [r10 - 0x188], r1
0cd1a8: ldxdw r1, [r8 + 0x8]
0cd1b0: stxdw [r10 - 0x190], r1
0cd1b8: ldxdw r1, [r8 + 0x0]
0cd1c0: stxdw [r10 - 0x198], r1
0cd1c8: mov64 r1, r10
0cd1d0: add64 r1, -0x198
0cd1d8: mov64 r2, r10
0cd1e0: add64 r2, -0xa0
0cd1e8: mov64 r3, 0x20
0cd1f0: call 0x98dd ; call 0x1198e0
0cd1f8: lsh64 r0, 0x20
0cd200: rsh64 r0, 0x20
0cd208: jeq r0, 0x0, +0x51 ; branch 0xcd498
0cd210: mov64 r1, r10
0cd218: add64 r1, -0x428
0cd220: mov64 r2, 0x7d6
0cd228: call 0x7181 ; call 0x105e38
0cd230: ldxdw r3, [r10 - 0x420]
0cd238: ldxdw r2, [r10 - 0x428]
0cd240: mov64 r1, r10
0cd248: add64 r1, -0x438
0cd250: lddw r4, 0x11cd4b ; rodata b'user_volume_accumulatorpool-v2programs/pump-amm/src/instructions/swap/trade'
0cd260: mov64 r5, 0x17
0cd268: call -0x1969f ; call 0x1d78
0cd270: ldxdw r3, [r10 - 0x430]
0cd278: ldxdw r2, [r10 - 0x438]
0cd280: ldxdw r1, [r8 + 0x18]
0cd288: stxdw [r10 - 0x180], r1
0cd290: ldxdw r1, [r8 + 0x10]
0cd298: stxdw [r10 - 0x188], r1
0cd2a0: ldxdw r1, [r8 + 0x8]
0cd2a8: stxdw [r10 - 0x190], r1
0cd2b0: ldxdw r1, [r8 + 0x0]
0cd2b8: stxdw [r10 - 0x198], r1
0cd2c0: ldxdw r1, [r10 - 0xa0]
0cd2c8: stxdw [r10 - 0x178], r1
0cd2d0: ldxdw r1, [r10 - 0x98]
0cd2d8: stxdw [r10 - 0x170], r1
0cd2e0: ldxdw r1, [r10 - 0x90]
0cd2e8: stxdw [r10 - 0x168], r1
0cd2f0: ldxdw r1, [r10 - 0x88]
0cd2f8: stxdw [r10 - 0x160], r1
0cd300: mov64 r1, r10
0cd308: add64 r1, -0x448
0cd310: mov64 r4, r10
0cd318: add64 r4, -0x198
0cd320: call 0x6bd5 ; call 0x1031d0
0cd328: ldxdw r1, [r10 - 0x448]
0cd330: ldxdw r2, [r10 - 0x440]
0cd338: ja +0x17 ; branch 0xcd3f8
0cd340: mov64 r1, r10
0cd348: add64 r1, -0x418
0cd350: lddw r4, 0x11e0ca ; rodata b'programsystem_programglobal_incentive_token_accountadmintoken_programassoci'
0cd360: mov64 r5, 0x7
0cd368: call -0x196bf ; call 0x1d78
0cd370: ldxdw r1, [r10 - 0x418]
0cd378: ldxdw r2, [r10 - 0x410]
0cd380: ja +0xe ; branch 0xcd3f8
0cd388: mov64 r1, r10
0cd390: add64 r1, -0x588
0cd398: mov64 r2, 0x7d0
0cd3a0: call 0x7152 ; call 0x105e38
0cd3a8: ldxdw r3, [r10 - 0x580]
0cd3b0: ldxdw r2, [r10 - 0x588]
0cd3b8: mov64 r1, r10
0cd3c0: add64 r1, -0x598
0cd3c8: lddw r4, 0x11c004 ; rodata b'userbaseS\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x001\x00\x00\x00Some\x10\x00\x00\x00L\x00\x00\x00O\x00\x00\x00 <= trueM\x00\x00\x00\x06\x00\x00\x00\xd6\x07\x00\x00\x17\x00\x00\x00\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00'
0cd3d8: mov64 r5, 0x4
0cd3e0: call -0x196ce ; call 0x1d78
0cd3e8: ldxdw r1, [r10 - 0x598]
0cd3f0: ldxdw r2, [r10 - 0x590]
0cd3f8: stxdw [r6 + 0x10], r2
0cd400: stxdw [r6 + 0x8], r1
0cd408: stw [r6 + 0x0], 0x2
0cd410: ldxdw r3, [r10 - 0x6c0]
0cd418: ldxdw r2, [r10 - 0x6c8]
0cd420: ldxdw r1, [r2 + 0x0]
0cd428: add64 r1, -0x1
0cd430: stxdw [r2 + 0x0], r1
0cd438: jne r1, 0x0, +0x3 ; branch 0xcd458
0cd440: ldxdw r1, [r2 + 0x8]
0cd448: add64 r1, -0x1
0cd450: stxdw [r2 + 0x8], r1
0cd458: ldxdw r1, [r3 + 0x0]
0cd460: add64 r1, -0x1
0cd468: stxdw [r3 + 0x0], r1
0cd470: jne r1, 0x0, -0x155 ; branch 0xcc9d0
0cd478: ldxdw r1, [r3 + 0x8]
0cd480: add64 r1, -0x1
0cd488: stxdw [r3 + 0x8], r1
0cd490: ja -0x159 ; branch 0xcc9d0
0cd498: ldxdw r1, [r10 - 0x650]
0cd4a0: ldxb r1, [r1 + 0x29]
0cd4a8: jeq r1, 0x0, +0x1b ; branch 0xcd588
0cd4b0: ldxdw r1, [r10 - 0x690]
0cd4b8: ldxdw r2, [r1 + 0x0]
0cd4c0: ldxdw r1, [r2 + 0x18]
0cd4c8: stxdw [r10 - 0x180], r1
0cd4d0: ldxdw r1, [r2 + 0x10]
0cd4d8: stxdw [r10 - 0x188], r1
0cd4e0: ldxdw r1, [r2 + 0x8]
0cd4e8: stxdw [r10 - 0x190], r1
0cd4f0: stxdw [r10 - 0x6e8], r2
0cd4f8: ldxdw r1, [r2 + 0x0]
0cd500: stxdw [r10 - 0x198], r1
0cd508: ldxdw r1, [r10 - 0x698]
0cd510: ldxdw r1, [r1 + 0x18]
0cd518: mov64 r2, r10
0cd520: add64 r2, -0x198
0cd528: mov64 r3, 0x20
0cd530: call 0x9875 ; call 0x1198e0
0cd538: lsh64 r0, 0x20
0cd540: rsh64 r0, 0x20
0cd548: jeq r0, 0x0, +0x16 ; branch 0xcd600
0cd550: mov64 r1, r10
0cd558: add64 r1, -0x458
0cd560: mov64 r2, 0x7e7
0cd568: call 0x7119 ; call 0x105e38
0cd570: ldxdw r1, [r10 - 0x458]
0cd578: ldxdw r2, [r10 - 0x450]
0cd580: ja -0x32 ; branch 0xcd3f8
0cd588: mov64 r1, r10
0cd590: add64 r1, -0x568
0cd598: mov64 r2, 0x7d0
0cd5a0: call 0x7112 ; call 0x105e38
0cd5a8: ldxdw r3, [r10 - 0x560]
0cd5b0: ldxdw r2, [r10 - 0x568]
0cd5b8: mov64 r1, r10
0cd5c0: add64 r1, -0x578
0cd5c8: lddw r4, 0x11cd4b ; rodata b'user_volume_accumulatorpool-v2programs/pump-amm/src/instructions/swap/trade'
0cd5d8: mov64 r5, 0x17
0cd5e0: call -0x1970e ; call 0x1d78
0cd5e8: ldxdw r1, [r10 - 0x578]
0cd5f0: ldxdw r2, [r10 - 0x570]
0cd5f8: ja -0x41 ; branch 0xcd3f8
0cd600: ldxdw r1, [r10 - 0x288]
0cd608: stxdw [r10 - 0x68], r1
0cd610: ldxdw r1, [r10 - 0x290]
0cd618: stxdw [r10 - 0x70], r1
0cd620: ldxdw r1, [r10 - 0x298]
0cd628: stxdw [r10 - 0x78], r1
0cd630: ldxdw r1, [r10 - 0x2a0]
0cd638: stxdw [r10 - 0x80], r1
0cd640: ldxdw r1, [r8 + 0x18]
0cd648: stxdw [r10 - 0x48], r1
0cd650: ldxdw r1, [r8 + 0x10]
0cd658: stxdw [r10 - 0x50], r1
0cd660: ldxdw r1, [r8 + 0x8]
0cd668: stxdw [r10 - 0x58], r1
0cd670: ldxdw r1, [r8 + 0x0]
0cd678: stxdw [r10 - 0x60], r1
0cd680: mov64 r1, r10
0cd688: add64 r1, -0x80
0cd690: mov64 r2, r10
0cd698: add64 r2, -0x60
0cd6a0: mov64 r3, 0x20
0cd6a8: call 0x9846 ; call 0x1198e0
0cd6b0: lsh64 r0, 0x20
0cd6b8: rsh64 r0, 0x20
0cd6c0: jeq r0, 0x0, +0x26 ; branch 0xcd7f8
0cd6c8: mov64 r1, r10
0cd6d0: add64 r1, -0x468
0cd6d8: mov64 r2, 0x7df
0cd6e0: call 0x70ea ; call 0x105e38
0cd6e8: ldxdw r3, [r10 - 0x460]
0cd6f0: ldxdw r2, [r10 - 0x468]
0cd6f8: mov64 r1, r10
0cd700: add64 r1, -0x478
0cd708: lddw r4, 0x11e417 ; rodata b'user_volume_accumulator_wsol_token_accountuser_wsol_token_accountprograms/p'
0cd718: mov64 r5, 0x2a
0cd720: call -0x19736 ; call 0x1d78
0cd728: ldxdw r3, [r10 - 0x470]
0cd730: ldxdw r2, [r10 - 0x478]
0cd738: ldxdw r1, [r10 - 0x68]
0cd740: stxdw [r10 - 0x180], r1
0cd748: ldxdw r1, [r10 - 0x70]
0cd750: stxdw [r10 - 0x188], r1
0cd758: ldxdw r1, [r10 - 0x78]
0cd760: stxdw [r10 - 0x190], r1
0cd768: ldxdw r1, [r10 - 0x80]
0cd770: stxdw [r10 - 0x198], r1
0cd778: ldxdw r1, [r10 - 0x60]
0cd780: stxdw [r10 - 0x178], r1
0cd788: ldxdw r1, [r10 - 0x58]
0cd790: stxdw [r10 - 0x170], r1
0cd798: ldxdw r1, [r10 - 0x50]
0cd7a0: stxdw [r10 - 0x168], r1
0cd7a8: ldxdw r1, [r10 - 0x48]
0cd7b0: stxdw [r10 - 0x160], r1
0cd7b8: mov64 r1, r10
0cd7c0: add64 r1, -0x488
0cd7c8: mov64 r4, r10
0cd7d0: add64 r4, -0x198
0cd7d8: call 0x6b3e ; call 0x1031d0
0cd7e0: ldxdw r1, [r10 - 0x488]
0cd7e8: ldxdw r2, [r10 - 0x480]
0cd7f0: ja -0x80 ; branch 0xcd3f8
0cd7f8: ldxdw r1, [r10 - 0x668]
0cd800: ldxdw r2, [r1 + 0x0]
0cd808: ldxdw r1, [r2 + 0x18]
0cd810: stxdw [r10 - 0x8], r1
0cd818: ldxdw r1, [r2 + 0x10]
0cd820: stxdw [r10 - 0x10], r1
0cd828: ldxdw r1, [r2 + 0x8]
0cd830: stxdw [r10 - 0x18], r1
0cd838: stxdw [r10 - 0x6f0], r2
0cd840: ldxdw r1, [r2 + 0x0]
0cd848: stxdw [r10 - 0x20], r1
0cd850: ldxdw r2, [r10 - 0x6e8]
0cd858: ldxdw r1, [r2 + 0x18]
0cd860: stxdw [r10 - 0x180], r1
0cd868: ldxdw r1, [r2 + 0x10]
0cd870: stxdw [r10 - 0x188], r1
0cd878: ldxdw r1, [r2 + 0x8]
0cd880: stxdw [r10 - 0x190], r1
0cd888: ldxdw r1, [r2 + 0x0]
0cd890: stxdw [r10 - 0x198], r1
0cd898: mov64 r8, r10
0cd8a0: add64 r8, -0x40
0cd8a8: mov64 r2, r10
0cd8b0: add64 r2, -0x60
0cd8b8: mov64 r3, r10
0cd8c0: add64 r3, -0x20
0cd8c8: mov64 r4, r10
0cd8d0: add64 r4, -0x198
0cd8d8: mov64 r1, r8
0cd8e0: call 0x660e ; call 0x100958
0cd8e8: ldxdw r1, [r10 - 0x698]
0cd8f0: ldxdw r1, [r1 + 0x0]
0cd8f8: ldxdw r2, [r1 + 0x18]
0cd900: stxdw [r10 - 0x8], r2
0cd908: ldxdw r2, [r1 + 0x10]
0cd910: stxdw [r10 - 0x10], r2
0cd918: ldxdw r2, [r1 + 0x8]
0cd920: stxdw [r10 - 0x18], r2
0cd928: ldxdw r1, [r1 + 0x0]
0cd930: stxdw [r10 - 0x20], r1
0cd938: mov64 r1, r10
0cd940: add64 r1, -0x20
0cd948: mov64 r2, r8
0cd950: mov64 r3, 0x20
0cd958: call 0x97f0 ; call 0x1198e0
0cd960: lsh64 r0, 0x20
0cd968: rsh64 r0, 0x20
0cd970: jeq r0, 0x0, +0x26 ; branch 0xcdaa8
0cd978: mov64 r1, r10
0cd980: add64 r1, -0x498
0cd988: mov64 r2, 0x7d9
0cd990: call 0x7094 ; call 0x105e38
0cd998: ldxdw r3, [r10 - 0x490]
0cd9a0: ldxdw r2, [r10 - 0x498]
0cd9a8: mov64 r1, r10
0cd9b0: add64 r1, -0x4a8
0cd9b8: lddw r4, 0x11e417 ; rodata b'user_volume_accumulator_wsol_token_accountuser_wsol_token_accountprograms/p'
0cd9c8: mov64 r5, 0x2a
0cd9d0: call -0x1978c ; call 0x1d78
0cd9d8: ldxdw r3, [r10 - 0x4a0]
0cd9e0: ldxdw r2, [r10 - 0x4a8]
0cd9e8: ldxdw r1, [r10 - 0x8]
0cd9f0: stxdw [r10 - 0x180], r1
0cd9f8: ldxdw r1, [r10 - 0x10]
0cda00: stxdw [r10 - 0x188], r1
0cda08: ldxdw r1, [r10 - 0x18]
0cda10: stxdw [r10 - 0x190], r1
0cda18: ldxdw r1, [r10 - 0x20]
0cda20: stxdw [r10 - 0x198], r1
0cda28: ldxdw r1, [r10 - 0x40]
0cda30: stxdw [r10 - 0x178], r1
0cda38: ldxdw r1, [r10 - 0x38]
0cda40: stxdw [r10 - 0x170], r1
0cda48: ldxdw r1, [r10 - 0x30]
0cda50: stxdw [r10 - 0x168], r1
0cda58: ldxdw r1, [r10 - 0x28]
0cda60: stxdw [r10 - 0x160], r1
0cda68: mov64 r1, r10
0cda70: add64 r1, -0x4b8
0cda78: mov64 r4, r10
0cda80: add64 r4, -0x198
0cda88: call 0x6ae8 ; call 0x1031d0
0cda90: ldxdw r1, [r10 - 0x4b8]
0cda98: ldxdw r2, [r10 - 0x4b0]
0cdaa0: ja -0xd6 ; branch 0xcd3f8
0cdaa8: ldxdw r1, [r10 - 0x698]
0cdab0: ldxb r1, [r1 + 0x29]
0cdab8: jeq r1, 0x0, +0x3e ; branch 0xcdcb0
0cdac0: ldxdw r1, [r10 - 0x250]
0cdac8: stxdw [r10 - 0x6f8], r1
0cdad0: ldxb r1, [r1 + 0x29]
0cdad8: jne r1, 0x0, +0xf ; branch 0xcdb58
0cdae0: mov64 r1, r10
0cdae8: add64 r1, -0x528
0cdaf0: mov64 r2, 0x7d0
0cdaf8: call 0x7067 ; call 0x105e38
0cdb00: ldxdw r3, [r10 - 0x520]
0cdb08: ldxdw r2, [r10 - 0x528]
0cdb10: mov64 r1, r10
0cdb18: add64 r1, -0x538
0cdb20: lddw r4, 0x11e441 ; rodata b'user_wsol_token_accountprograms/pump-amm/src/instructions/token_incentives/'
0cdb30: mov64 r5, 0x17
0cdb38: call -0x197b9 ; call 0x1d78
0cdb40: ldxdw r1, [r10 - 0x538]
0cdb48: ldxdw r2, [r10 - 0x530]
0cdb50: ja -0xec ; branch 0xcd3f8
0cdb58: ldxdw r2, [r10 - 0x618]
0cdb60: ldxdw r1, [r2 + 0x18]
0cdb68: stxdw [r10 - 0x180], r1
0cdb70: ldxdw r1, [r2 + 0x10]
0cdb78: stxdw [r10 - 0x188], r1
0cdb80: ldxdw r1, [r2 + 0x8]
0cdb88: stxdw [r10 - 0x190], r1
0cdb90: ldxdw r1, [r2 + 0x0]
0cdb98: stxdw [r10 - 0x198], r1
0cdba0: mov64 r1, r10
0cdba8: add64 r1, -0x228
0cdbb0: mov64 r2, r10
0cdbb8: add64 r2, -0x198
0cdbc0: mov64 r3, 0x20
0cdbc8: call 0x97a2 ; call 0x1198e0
0cdbd0: lsh64 r0, 0x20
0cdbd8: rsh64 r0, 0x20
0cdbe0: jne r0, 0x0, +0x28 ; branch 0xcdd28
0cdbe8: ldxdw r2, [r10 - 0x6f0]
0cdbf0: ldxdw r1, [r2 + 0x18]
0cdbf8: stxdw [r10 - 0x180], r1
0cdc00: ldxdw r1, [r2 + 0x10]
0cdc08: stxdw [r10 - 0x188], r1
0cdc10: ldxdw r1, [r2 + 0x8]
0cdc18: stxdw [r10 - 0x190], r1
0cdc20: ldxdw r1, [r2 + 0x0]
0cdc28: stxdw [r10 - 0x198], r1
0cdc30: mov64 r1, r10
0cdc38: add64 r1, -0x248
0cdc40: mov64 r2, r10
0cdc48: add64 r2, -0x198
0cdc50: mov64 r3, 0x20
0cdc58: call 0x9790 ; call 0x1198e0
0cdc60: lsh64 r0, 0x20
0cdc68: rsh64 r0, 0x20
0cdc70: jeq r0, 0x0, +0x1d ; branch 0xcdd60
0cdc78: mov64 r1, r10
0cdc80: add64 r1, -0x4d8
0cdc88: mov64 r2, 0x7de
0cdc90: call 0x7034 ; call 0x105e38
0cdc98: ldxdw r1, [r10 - 0x4d8]
0cdca0: ldxdw r2, [r10 - 0x4d0]
0cdca8: ja -0x117 ; branch 0xcd3f8
0cdcb0: mov64 r1, r10
0cdcb8: add64 r1, -0x548
0cdcc0: mov64 r2, 0x7d0
0cdcc8: call 0x702d ; call 0x105e38
0cdcd0: ldxdw r3, [r10 - 0x540]
0cdcd8: ldxdw r2, [r10 - 0x548]
0cdce0: mov64 r1, r10
0cdce8: add64 r1, -0x558
0cdcf0: lddw r4, 0x11e417 ; rodata b'user_volume_accumulator_wsol_token_accountuser_wsol_token_accountprograms/p'
0cdd00: mov64 r5, 0x2a
0cdd08: call -0x197f3 ; call 0x1d78
0cdd10: ldxdw r1, [r10 - 0x558]
0cdd18: ldxdw r2, [r10 - 0x550]
0cdd20: ja -0x126 ; branch 0xcd3f8
0cdd28: mov64 r1, r10
0cdd30: add64 r1, -0x4c8
0cdd38: mov64 r2, 0x7df
0cdd40: call 0x701e ; call 0x105e38
0cdd48: ldxdw r1, [r10 - 0x4c8]
0cdd50: ldxdw r2, [r10 - 0x4c0]
0cdd58: ja -0x12d ; branch 0xcd3f8
0cdd60: ldxdw r2, [r10 - 0x6e8]
0cdd68: ldxdw r1, [r2 + 0x18]
0cdd70: stxdw [r10 - 0x180], r1
0cdd78: ldxdw r1, [r2 + 0x10]
0cdd80: stxdw [r10 - 0x188], r1
0cdd88: ldxdw r1, [r2 + 0x8]
0cdd90: stxdw [r10 - 0x190], r1
0cdd98: ldxdw r1, [r2 + 0x0]
0cdda0: stxdw [r10 - 0x198], r1
0cdda8: ldxdw r1, [r10 - 0x6f8]
0cddb0: ldxdw r1, [r1 + 0x18]
0cddb8: mov64 r2, r10
0cddc0: add64 r2, -0x198
0cddc8: mov64 r3, 0x20
0cddd0: call 0x9761 ; call 0x1198e0
0cddd8: lsh64 r0, 0x20
0cdde0: rsh64 r0, 0x20
0cdde8: jeq r0, 0x0, +0x7 ; branch 0xcde28
0cddf0: mov64 r1, r10
0cddf8: add64 r1, -0x4e8
0cde00: mov64 r2, 0x7e5
0cde08: call 0x7005 ; call 0x105e38
0cde10: ldxdw r1, [r10 - 0x4e8]
0cde18: ldxdw r2, [r10 - 0x4e0]
0cde20: ja -0x146 ; branch 0xcd3f8
0cde28: mov64 r1, r10
0cde30: add64 r1, -0x198
0cde38: lddw r2, 0x1229d0 ; rodata b"\x00\x00\x00\x00F\xc6\x11\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\x9b\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\xf9\x10\x00\x00\x00\x00\x00\x0f\xcd\x11\x00\r\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'\xce\x11\x00\x19\x00\x00"
0cde48: mov64 r3, 0x1
0cde50: ldxdw r4, [r10 - 0x628]
0cde58: call 0x8041 ; call 0x10e068
0cde60: ldxdw r1, [r10 - 0x180]
0cde68: stxdw [r10 - 0x8], r1
0cde70: ldxdw r1, [r10 - 0x188]
0cde78: stxdw [r10 - 0x10], r1
0cde80: ldxdw r1, [r10 - 0x190]
0cde88: stxdw [r10 - 0x18], r1
0cde90: ldxdw r1, [r10 - 0x198]
0cde98: stxdw [r10 - 0x20], r1
0cdea0: ldxb r1, [r10 - 0x178]
0cdea8: ldxdw r2, [r10 - 0x620]
0cdeb0: stxb [r2 + 0x1], r1
0cdeb8: ldxdw r2, [r10 - 0x6d0]
0cdec0: ldxdw r1, [r2 + 0x18]
0cdec8: stxdw [r10 - 0x180], r1
0cded0: ldxdw r1, [r2 + 0x10]
0cded8: stxdw [r10 - 0x188], r1
0cdee0: ldxdw r1, [r2 + 0x8]
0cdee8: stxdw [r10 - 0x190], r1
0cdef0: ldxdw r1, [r2 + 0x0]
0cdef8: stxdw [r10 - 0x198], r1
0cdf00: mov64 r1, r10
0cdf08: add64 r1, -0x198
0cdf10: mov64 r2, r10
0cdf18: add64 r2, -0x20
0cdf20: mov64 r3, 0x20
0cdf28: call 0x9736 ; call 0x1198e0
0cdf30: lsh64 r0, 0x20
0cdf38: rsh64 r0, 0x20
0cdf40: jeq r0, 0x0, +0x27 ; branch 0xce080
0cdf48: mov64 r1, r10
0cdf50: add64 r1, -0x4f8
0cdf58: mov64 r2, 0x7d6
0cdf60: call 0x6fda ; call 0x105e38
0cdf68: ldxdw r3, [r10 - 0x4f0]
0cdf70: ldxdw r2, [r10 - 0x4f8]
0cdf78: mov64 r1, r10
0cdf80: add64 r1, -0x508
0cdf88: lddw r4, 0x11e0ad ; rodata b'event_authoritypool_authorityprogramsystem_programglobal_incentive_token_ac'
0cdf98: mov64 r5, 0xf
0cdfa0: call -0x19846 ; call 0x1d78
0cdfa8: ldxdw r3, [r10 - 0x500]
0cdfb0: ldxdw r2, [r10 - 0x508]
0cdfb8: ldxdw r4, [r10 - 0x6d0]
0cdfc0: ldxdw r1, [r4 + 0x18]
0cdfc8: stxdw [r10 - 0x180], r1
0cdfd0: ldxdw r1, [r4 + 0x10]
0cdfd8: stxdw [r10 - 0x188], r1
0cdfe0: ldxdw r1, [r4 + 0x8]
0cdfe8: stxdw [r10 - 0x190], r1
0cdff0: ldxdw r1, [r4 + 0x0]
0cdff8: stxdw [r10 - 0x198], r1
0ce000: ldxdw r1, [r10 - 0x20]
0ce008: stxdw [r10 - 0x178], r1
0ce010: ldxdw r1, [r10 - 0x18]
0ce018: stxdw [r10 - 0x170], r1
0ce020: ldxdw r1, [r10 - 0x10]
0ce028: stxdw [r10 - 0x168], r1
0ce030: ldxdw r1, [r10 - 0x8]
0ce038: stxdw [r10 - 0x160], r1
0ce040: mov64 r1, r10
0ce048: add64 r1, -0x518
0ce050: mov64 r4, r10
0ce058: add64 r4, -0x198
0ce060: call 0x6a2d ; call 0x1031d0
0ce068: ldxdw r1, [r10 - 0x518]
0ce070: ldxdw r2, [r10 - 0x510]
0ce078: ja -0x191 ; branch 0xcd3f8
0ce080: mov64 r1, r6
0ce088: add64 r1, 0x158
0ce090: mov64 r2, r10
0ce098: add64 r2, -0x270
0ce0a0: mov64 r3, 0xd8
0ce0a8: call 0x96fd ; call 0x119898
0ce0b0: ldxdw r1, [r10 - 0xb8]
0ce0b8: stxdw [r6 + 0x278], r1
0ce0c0: ldxdw r1, [r10 - 0xb0]
0ce0c8: stxdw [r6 + 0x280], r1
0ce0d0: ldxh r1, [r10 - 0xa8]
0ce0d8: stxh [r6 + 0x288], r1
0ce0e0: ldxw r1, [r10 - 0xc0]
0ce0e8: stxw [r6 + 0x28b], r1
0ce0f0: ldxb r1, [r10 - 0xbc]
0ce0f8: stxb [r6 + 0x28f], r1
0ce100: mov64 r1, r6
0ce108: add64 r1, 0x2a0
0ce110: mov64 r2, r10
0ce118: add64 r2, -0x3e0
0ce120: mov64 r3, 0x49
0ce128: call 0x96ed ; call 0x119898
0ce130: ldxw r1, [r10 - 0x3e8]
0ce138: stxw [r6 + 0x2ea], r1
0ce140: ldxh r1, [r10 - 0x3e4]
0ce148: stxh [r6 + 0x2ee], r1
0ce150: mov64 r1, r6
0ce158: add64 r1, 0x18
0ce160: mov64 r2, r10
0ce168: add64 r2, -0x370
0ce170: mov64 r3, 0x40
0ce178: call 0x96e3 ; call 0x119898
0ce180: ldxdw r1, [r10 - 0x390]
0ce188: stxdw [r6 + 0x60], r1
0ce190: ldxdw r1, [r10 - 0x388]
0ce198: stxdw [r6 + 0x68], r1
0ce1a0: ldxdw r1, [r10 - 0x380]
0ce1a8: stxdw [r6 + 0x70], r1
0ce1b0: ldxdw r1, [r10 - 0x378]
0ce1b8: stxdw [r6 + 0x78], r1
0ce1c0: ldxdw r1, [r10 - 0x278]
0ce1c8: stxdw [r6 + 0x98], r1
0ce1d0: ldxdw r1, [r10 - 0x280]
0ce1d8: stxdw [r6 + 0x90], r1
0ce1e0: mov64 r1, r6
0ce1e8: add64 r1, 0xa8
0ce1f0: mov64 r2, r10
0ce1f8: add64 r2, -0x2c0
0ce200: mov64 r3, 0x40
0ce208: call 0x96d1 ; call 0x119898
0ce210: mov64 r1, r6
0ce218: add64 r1, 0xe8
0ce220: mov64 r2, r10
0ce228: add64 r2, -0x308
0ce230: mov64 r3, 0x48
0ce238: call 0x96cb ; call 0x119898
0ce240: ldxw r1, [r10 - 0x310]
0ce248: ldxdw r2, [r10 - 0x318]
0ce250: ldxdw r3, [r10 - 0x320]
0ce258: ldxdw r4, [r10 - 0x328]
0ce260: ldxdw r5, [r10 - 0x330]
0ce268: ldxdw r0, [r10 - 0x680]
0ce270: stxw [r6 + 0x0], r0
0ce278: ldxdw r0, [r10 - 0x688]
0ce280: stxw [r6 + 0x4], r0
0ce288: ldxdw r0, [r10 - 0x6b0]
0ce290: stxw [r6 + 0x130], r0
0ce298: ldxdw r0, [r10 - 0x648]
0ce2a0: stxb [r6 + 0x258], r0
0ce2a8: ldxdw r0, [r10 - 0x610]
0ce2b0: stxb [r6 + 0x259], r0
0ce2b8: ldxdw r0, [r10 - 0x640]
0ce2c0: stxb [r6 + 0x25a], r0
0ce2c8: ldxdw r0, [r10 - 0x6d8]
0ce2d0: stxb [r6 + 0x28a], r0
0ce2d8: ldxdw r0, [r10 - 0x660]
0ce2e0: stxb [r6 + 0x2e9], r0
0ce2e8: ldxdw r0, [r10 - 0x6e0]
0ce2f0: stxdw [r6 + 0x300], r0
0ce2f8: ldxdw r0, [r10 - 0x6b8]
0ce300: stxdw [r6 + 0x2f8], r0
0ce308: ldxdw r0, [r10 - 0x690]
0ce310: stxdw [r6 + 0x2f0], r0
0ce318: ldxdw r0, [r10 - 0x658]
0ce320: stxdw [r6 + 0x298], r0
0ce328: ldxdw r0, [r10 - 0x650]
0ce330: stxdw [r6 + 0x290], r0
0ce338: ldxdw r0, [r10 - 0x6c0]
0ce340: stxdw [r6 + 0x270], r0
0ce348: ldxdw r0, [r10 - 0x6c8]
0ce350: stxdw [r6 + 0x268], r0
0ce358: ldxdw r0, [r10 - 0x6d0]
0ce360: stxdw [r6 + 0x260], r0
0ce368: ldxdw r0, [r10 - 0x638]
0ce370: stxdw [r6 + 0x250], r0
0ce378: ldxdw r0, [r10 - 0x630]
0ce380: stxdw [r6 + 0x248], r0
0ce388: stxdw [r6 + 0x240], r7
0ce390: stxdw [r6 + 0x238], r9
0ce398: ldxdw r0, [r10 - 0x618]
0ce3a0: stxdw [r6 + 0x230], r0
0ce3a8: ldxdw r0, [r10 - 0x698]
0ce3b0: stxdw [r6 + 0xa0], r0
0ce3b8: ldxdw r0, [r10 - 0x6a0]
0ce3c0: stxdw [r6 + 0x88], r0
0ce3c8: ldxdw r0, [r10 - 0x6a8]
0ce3d0: stxdw [r6 + 0x80], r0
0ce3d8: ldxdw r0, [r10 - 0x668]
0ce3e0: stxdw [r6 + 0x58], r0
0ce3e8: ldxdw r0, [r10 - 0x678]
0ce3f0: stxdw [r6 + 0x10], r0
0ce3f8: ldxdw r0, [r10 - 0x670]
0ce400: stxdw [r6 + 0x8], r0
0ce408: stxdw [r6 + 0x134], r5
0ce410: stxdw [r6 + 0x13c], r4
0ce418: stxdw [r6 + 0x144], r3
0ce420: stxdw [r6 + 0x14c], r2
0ce428: stxw [r6 + 0x154], r1
0ce430: ja -0x33f ; branch 0xcca40
