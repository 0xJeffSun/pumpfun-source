0e5ce8: mov64 r7, r5
0e5cf0: mov64 r9, r4
0e5cf8: mov64 r8, r3
0e5d00: mov64 r6, r2
0e5d08: stxdw [r10 - 0xfb0], r1
0e5d10: lddw r1, 0x11e851 ; rodata b'Instruction: AdminUpdateTokenIncentivesInstruction: ClaimTokenIncentivesIns'
0e5d20: mov64 r2, 0x27
0e5d28: call -0x1
0e5d30: ldxdw r1, [r7 - 0xff8]
0e5d38: jlt r1, 0x8, +0x23 ; branch 0xe5e58
0e5d40: and64 r1, -0x8
0e5d48: jeq r1, 0x8, +0x21 ; branch 0xe5e58
0e5d50: jeq r1, 0x10, +0x20 ; branch 0xe5e58
0e5d58: jeq r1, 0x18, +0x1f ; branch 0xe5e58
0e5d60: jeq r1, 0x20, +0x1e ; branch 0xe5e58
0e5d68: ldxdw r1, [r7 - 0x1000]
0e5d70: ldxdw r7, [r1 + 0x0]
0e5d78: ldxdw r2, [r1 + 0x8]
0e5d80: stxdw [r10 - 0xfb8], r2
0e5d88: ldxdw r2, [r1 + 0x10]
0e5d90: stxdw [r10 - 0xfc0], r2
0e5d98: ldxdw r2, [r1 + 0x18]
0e5da0: stxdw [r10 - 0xfc8], r2
0e5da8: ldxdw r1, [r1 + 0x20]
0e5db0: stxdw [r10 - 0xfd0], r1
0e5db8: stb [r10 - 0xf71], 0xff
0e5dc0: sth [r10 - 0xf73], 0xffff
0e5dc8: stxdw [r10 - 0xf68], r9
0e5dd0: stxdw [r10 - 0xf70], r8
0e5dd8: mov64 r1, r10
0e5de0: add64 r1, -0xf73
0e5de8: stxdw [r10 - 0xff8], r1
0e5df0: mov64 r1, r10
0e5df8: add64 r1, -0x7b0
0e5e00: mov64 r3, r10
0e5e08: add64 r3, -0xf70
0e5e10: mov64 r5, r10
0e5e18: mov64 r2, r6
0e5e20: call -0xd0d5 ; call 0x7d780
0e5e28: ldxw r8, [r10 - 0x7b0]
0e5e30: jeq r8, 0x2, +0x1 ; branch 0xe5e40
0e5e38: ja +0x1a ; branch 0xe5f10
0e5e40: ldxdw r2, [r10 - 0x7a0]
0e5e48: ldxdw r1, [r10 - 0x7a8]
0e5e50: ja +0x13 ; branch 0xe5ef0
0e5e58: lddw r1, 0x1221c8 ; rodata b'\x00\x00\x00\x00\xdd\xc0\x11\x00\x1b\x00\x00\x00\x00\x00\x00\x00%\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00'
0e5e68: call 0x5234 ; call 0x10f010
0e5e70: mov64 r1, r0
0e5e78: and64 r1, 0x3
0e5e80: mov64 r2, r1
0e5e88: add64 r2, -0x2
0e5e90: jlt r2, 0x2, +0x5 ; branch 0xe5ec0
0e5e98: jeq r1, 0x0, +0x4 ; branch 0xe5ec0
0e5ea0: ldxdw r1, [r0 - 0x1]
0e5ea8: ldxdw r2, [r0 + 0x7]
0e5eb0: ldxdw r2, [r2 + 0x0]
0e5eb8: callx r2
0e5ec0: mov64 r1, r10
0e5ec8: add64 r1, -0xfa8
0e5ed0: mov64 r2, 0x66
0e5ed8: call 0x3feb ; call 0x105e38
0e5ee0: ldxdw r2, [r10 - 0xfa0]
0e5ee8: ldxdw r1, [r10 - 0xfa8]
0e5ef0: ldxdw r3, [r10 - 0xfb0]
0e5ef8: stxdw [r3 + 0x8], r2
0e5f00: stxdw [r3 + 0x0], r1
0e5f08: exit
0e5f10: ldxw r1, [r10 - 0x7ac]
0e5f18: stxdw [r10 - 0xfe0], r1
0e5f20: stxdw [r10 - 0xfd8], r7
0e5f28: ldxdw r7, [r10 - 0x7a8]
0e5f30: ldxdw r9, [r10 - 0x7a0]
0e5f38: mov64 r1, r10
0e5f40: add64 r1, -0xf48
0e5f48: mov64 r2, r10
0e5f50: add64 r2, -0x798
0e5f58: mov64 r3, 0x798
0e5f60: call 0x6726 ; call 0x119898
0e5f68: stxdw [r10 - 0xf50], r9
0e5f70: stxdw [r10 - 0xf58], r7
0e5f78: ldxdw r1, [r10 - 0xfe0]
0e5f80: stxw [r10 - 0xf5c], r1
0e5f88: stxw [r10 - 0xf60], r8
0e5f90: ldxh r1, [r10 - 0xf73]
0e5f98: stxh [r10 - 0x790], r1
0e5fa0: ldxb r1, [r10 - 0xf71]
0e5fa8: stxb [r10 - 0x78e], r1
0e5fb0: ldxdw r1, [r10 - 0xf68]
0e5fb8: stxdw [r10 - 0x798], r1
0e5fc0: ldxdw r1, [r10 - 0xf70]
0e5fc8: stxdw [r10 - 0x7a0], r1
0e5fd0: mov64 r1, r10
0e5fd8: add64 r1, -0xf60
0e5fe0: stxdw [r10 - 0x7a8], r1
0e5fe8: stxdw [r10 - 0x7b0], r6
0e5ff0: ldxdw r1, [r10 - 0xfc8]
0e5ff8: stxdw [r10 - 0xff8], r1
0e6000: ldxdw r1, [r10 - 0xfd0]
0e6008: stxdw [r10 - 0xff0], r1
0e6010: ldxdw r1, [r10 - 0xfc0]
0e6018: stxdw [r10 - 0x1000], r1
0e6020: mov64 r1, r10
0e6028: add64 r1, -0xf88
0e6030: mov64 r2, r10
0e6038: add64 r2, -0x7b0
0e6040: mov64 r5, r10
0e6048: ldxdw r3, [r10 - 0xfd8]
0e6050: ldxdw r4, [r10 - 0xfb8]
0e6058: call -0x19fe7 ; call 0x16128
0e6060: ldxdw r1, [r10 - 0xf88]
0e6068: jeq r1, 0x2, +0x1 ; branch 0xe6078
0e6070: ja +0x29 ; branch 0xe61c0
0e6078: mov64 r1, r10
0e6080: add64 r1, -0xf98
0e6088: mov64 r2, r10
0e6090: add64 r2, -0xf60
0e6098: mov64 r3, r6
0e60a0: call -0xcad5 ; call 0x80a00
0e60a8: ldxdw r3, [r10 - 0xdf8]
0e60b0: ldxdw r4, [r10 - 0xe00]
0e60b8: ldxdw r5, [r4 + 0x0]
0e60c0: add64 r5, -0x1
0e60c8: ldxdw r2, [r10 - 0xf90]
0e60d0: ldxdw r1, [r10 - 0xf98]
0e60d8: stxdw [r4 + 0x0], r5
0e60e0: jne r5, 0x0, +0x3 ; branch 0xe6100
0e60e8: ldxdw r5, [r4 + 0x8]
0e60f0: add64 r5, -0x1
0e60f8: stxdw [r4 + 0x8], r5
0e6100: ldxdw r4, [r3 + 0x0]
0e6108: add64 r4, -0x1
0e6110: stxdw [r3 + 0x0], r4
0e6118: jne r4, 0x0, +0x3 ; branch 0xe6138
0e6120: ldxdw r4, [r3 + 0x8]
0e6128: add64 r4, -0x1
0e6130: stxdw [r3 + 0x8], r4
0e6138: ldxdw r3, [r10 - 0xdc8]
0e6140: ldxdw r4, [r10 - 0xdd0]
0e6148: ldxdw r5, [r4 + 0x0]
0e6150: add64 r5, -0x1
0e6158: stxdw [r4 + 0x0], r5
0e6160: jne r5, 0x0, +0x3 ; branch 0xe6180
0e6168: ldxdw r5, [r4 + 0x8]
0e6170: add64 r5, -0x1
0e6178: stxdw [r4 + 0x8], r5
0e6180: ldxdw r4, [r3 + 0x0]
0e6188: add64 r4, -0x1
0e6190: stxdw [r3 + 0x0], r4
0e6198: jne r4, 0x0, -0x56 ; branch 0xe5ef0
0e61a0: ldxdw r4, [r3 + 0x8]
0e61a8: add64 r4, -0x1
0e61b0: stxdw [r3 + 0x8], r4
0e61b8: ja -0x5a ; branch 0xe5ef0
0e61c0: ldxdw r2, [r10 - 0xf80]
0e61c8: ldxdw r3, [r10 - 0xdf8]
0e61d0: ldxdw r4, [r10 - 0xe00]
0e61d8: ldxdw r5, [r4 + 0x0]
0e61e0: add64 r5, -0x1
0e61e8: stxdw [r4 + 0x0], r5
0e61f0: jne r5, 0x0, +0x3 ; branch 0xe6210
0e61f8: ldxdw r5, [r4 + 0x8]
0e6200: add64 r5, -0x1
0e6208: stxdw [r4 + 0x8], r5
0e6210: ldxdw r4, [r3 + 0x0]
0e6218: add64 r4, -0x1
0e6220: stxdw [r3 + 0x0], r4
0e6228: jne r4, 0x0, +0x3 ; branch 0xe6248
0e6230: ldxdw r4, [r3 + 0x8]
0e6238: add64 r4, -0x1
0e6240: stxdw [r3 + 0x8], r4
0e6248: ldxdw r3, [r10 - 0xdc8]
0e6250: ldxdw r4, [r10 - 0xdd0]
0e6258: ldxdw r5, [r4 + 0x0]
0e6260: add64 r5, -0x1
0e6268: stxdw [r4 + 0x0], r5
0e6270: jne r5, 0x0, +0x3 ; branch 0xe6290
0e6278: ldxdw r5, [r4 + 0x8]
0e6280: add64 r5, -0x1
0e6288: stxdw [r4 + 0x8], r5
0e6290: ldxdw r4, [r3 + 0x0]
0e6298: add64 r4, -0x1
0e62a0: stxdw [r3 + 0x0], r4
0e62a8: jne r4, 0x0, -0x78 ; branch 0xe5ef0
0e62b0: ja -0x23 ; branch 0xe61a0
