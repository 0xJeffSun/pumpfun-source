016128: mov64 r6, r5
016130: stxdw [r10 - 0x130], r4
016138: mov64 r8, r3
016140: mov64 r7, r2
016148: stxdw [r10 - 0x128], r1
016150: ldxdw r9, [r7 + 0x8]
016158: ldxdw r1, [r9 + 0x58]
016160: ldxdw r1, [r1 + 0x0]
016168: ldxdw r2, [r1 + 0x18]
016170: stxdw [r10 - 0xd8], r2
016178: ldxdw r2, [r1 + 0x10]
016180: stxdw [r10 - 0xe0], r2
016188: ldxdw r2, [r1 + 0x8]
016190: stxdw [r10 - 0xe8], r2
016198: ldxdw r1, [r1 + 0x0]
0161a0: stxdw [r10 - 0xf0], r1
0161a8: mov64 r1, r10
0161b0: add64 r1, -0xd0
0161b8: call 0x1e18f ; call 0x106e38
0161c0: ldxdw r1, [r10 - 0xd0]
0161c8: jne r1, 0x0, +0x32 ; branch 0x16360
0161d0: ldxdw r3, [r6 - 0xff0]
0161d8: ldxdw r1, [r6 - 0xff8]
0161e0: ldxdw r6, [r6 - 0x1000]
0161e8: ldxdw r2, [r10 - 0xa8]
0161f0: stxdw [r10 - 0x150], r3
0161f8: stxdw [r10 - 0xfe8], r3
016200: stxdw [r10 - 0x148], r1
016208: stxdw [r10 - 0xff0], r1
016210: mov64 r1, r10
016218: add64 r1, -0xf0
016220: stxdw [r10 - 0xff8], r1
016228: stxdw [r10 - 0x1000], r6
016230: stxdw [r10 - 0x140], r2
016238: stxdw [r10 - 0xfe0], r2
016240: stxdw [r10 - 0x138], r9
016248: add64 r9, 0x580
016250: mov64 r1, r10
016258: add64 r1, -0x110
016260: mov64 r5, r10
016268: mov64 r2, r9
016270: mov64 r3, r8
016278: ldxdw r9, [r10 - 0x130]
016280: mov64 r4, r9
016288: call 0xaf12 ; call 0x6db20
016290: ldxdw r1, [r10 - 0x110]
016298: mov64 r5, r9
0162a0: mov64 r0, r8
0162a8: jeq r1, 0x2, +0x1 ; branch 0x162b8
0162b0: ja +0x23 ; branch 0x163d0
0162b8: lddw r1, 0x300000000
0162c8: ldxdw r2, [r1 + 0x0]
0162d0: mov64 r1, r2
0162d8: add64 r1, -0x100
0162e0: mov64 r3, 0x0
0162e8: mov64 r4, 0x1
0162f0: jgt r1, r2, +0x1 ; branch 0x16300
0162f8: mov64 r4, 0x0
016300: jne r4, 0x0, +0x1 ; branch 0x16310
016308: mov64 r3, r1
016310: lddw r1, 0x300007f00
016320: jeq r2, 0x0, +0x1 ; branch 0x16330
016328: mov64 r1, r3
016330: lddw r2, 0x300000007
016340: jgt r1, r2, +0x13 ; branch 0x163e0
016348: mov64 r1, 0x1
016350: mov64 r2, 0x100
016358: call 0x1f5fd ; call 0x111348
016360: ldxdw r1, [r10 - 0xc8]
016368: ldxdw r2, [r10 - 0xc0]
016370: ldxdw r3, [r10 - 0xb8]
016378: stxdw [r10 - 0xc0], r3
016380: stxdw [r10 - 0xc8], r2
016388: stxdw [r10 - 0xd0], r1
016390: mov64 r1, r10
016398: add64 r1, -0x100
0163a0: mov64 r2, r10
0163a8: add64 r2, -0xd0
0163b0: call 0x1d991 ; call 0x103040
0163b8: ldxdw r2, [r10 - 0xf8]
0163c0: ldxdw r1, [r10 - 0x100]
0163c8: ja +0x131 ; branch 0x16d58
0163d0: ldxdw r2, [r10 - 0x108]
0163d8: ja +0x12f ; branch 0x16d58
0163e0: lddw r2, 0x300000000
0163f0: stxdw [r2 + 0x0], r1
0163f8: ldxdw r2, [r10 - 0x150]
016400: stxdw [r1 + 0x20], r2
016408: ldxdw r2, [r10 - 0x148]
016410: stxdw [r1 + 0x18], r2
016418: mov64 r9, r5
016420: stxdw [r1 + 0x10], r5
016428: mov64 r8, r0
016430: stxdw [r1 + 0x8], r0
016438: lddw r2, -0x21bce2088793056d
016448: stxdw [r1 + 0x0], r2
016450: ldxdw r2, [r10 - 0xf0]
016458: stxdw [r1 + 0x28], r2
016460: ldxdw r2, [r10 - 0xe8]
016468: stxdw [r1 + 0x30], r2
016470: ldxdw r2, [r10 - 0xe0]
016478: stxdw [r1 + 0x38], r2
016480: ldxdw r2, [r10 - 0xd8]
016488: stxdw [r1 + 0x40], r2
016490: ldxdw r2, [r10 - 0x140]
016498: stxdw [r1 + 0x50], r2
0164a0: stxdw [r10 - 0x160], r6
0164a8: stxdw [r1 + 0x48], r6
0164b0: stxdw [r10 - 0xd0], r1
0164b8: stdw [r10 - 0xc8], 0x58
0164c0: mov64 r1, r10
0164c8: add64 r1, -0xd0
0164d0: mov64 r6, 0x1
0164d8: mov64 r2, 0x1
0164e0: call 0x1e0b3 ; call 0x106a80
0164e8: ldxdw r2, [r10 - 0x138]
0164f0: ldxdw r5, [r2 + 0x160]
0164f8: ldxdw r1, [r5 + 0x0]
016500: add64 r1, 0x1
016508: jeq r1, 0x0, +0x1 ; branch 0x16518
016510: mov64 r6, 0x0
016518: ldxdw r3, [r2 + 0x158]
016520: stxdw [r5 + 0x0], r1
016528: jne r6, 0x1, +0x1 ; branch 0x16538
016530: call -0x1
016538: ldxdw r0, [r2 + 0x168]
016540: ldxdw r1, [r0 + 0x0]
016548: add64 r1, 0x1
016550: mov64 r2, 0x1
016558: jeq r1, 0x0, +0x1 ; branch 0x16568
016560: mov64 r2, 0x0
016568: mov64 r6, r3
016570: stxdw [r0 + 0x0], r1
016578: jne r2, 0x1, +0x1 ; branch 0x16588
016580: ja -0xb ; branch 0x16530
016588: lddw r1, 0x300000000
016598: ldxdw r1, [r1 + 0x0]
0165a0: mov64 r2, r1
0165a8: add64 r2, -0x100
0165b0: mov64 r3, 0x0
0165b8: mov64 r4, 0x1
0165c0: jgt r2, r1, +0x1 ; branch 0x165d0
0165c8: mov64 r4, 0x0
0165d0: jne r4, 0x0, +0x1 ; branch 0x165e0
0165d8: mov64 r3, r2
0165e0: stxdw [r10 - 0x158], r0
0165e8: lddw r2, 0x300007f00
0165f8: jeq r1, 0x0, +0x1 ; branch 0x16608
016600: mov64 r2, r3
016608: stxdw [r10 - 0x168], r5
016610: lddw r1, 0x300000007
016620: jgt r2, r1, +0x1 ; branch 0x16630
016628: ja -0x5d ; branch 0x16348
016630: ldxb r7, [r7 + 0x22]
016638: ldxdw r1, [r10 - 0x138]
016640: ldxb r3, [r1 + 0x182]
016648: stxdw [r10 - 0x190], r3
016650: ldxb r3, [r1 + 0x181]
016658: stxdw [r10 - 0x188], r3
016660: ldxb r3, [r1 + 0x180]
016668: stxdw [r10 - 0x180], r3
016670: ldxdw r3, [r1 + 0x178]
016678: stxdw [r10 - 0x178], r3
016680: ldxdw r1, [r1 + 0x170]
016688: stxdw [r10 - 0x170], r1
016690: lddw r3, 0x300000000
0166a0: stxdw [r3 + 0x0], r2
0166a8: ldxdw r1, [r10 - 0x150]
0166b0: stxdw [r2 + 0x20], r1
0166b8: ldxdw r1, [r10 - 0x148]
0166c0: stxdw [r2 + 0x18], r1
0166c8: stxdw [r2 + 0x10], r9
0166d0: stxdw [r2 + 0x8], r8
0166d8: lddw r1, -0x21bce2088793056d
0166e8: stxdw [r2 + 0x0], r1
0166f0: ldxdw r1, [r10 - 0xf0]
0166f8: stxdw [r2 + 0x28], r1
016700: ldxdw r1, [r10 - 0xe8]
016708: stxdw [r2 + 0x30], r1
016710: ldxdw r1, [r10 - 0xe0]
016718: stxdw [r2 + 0x38], r1
016720: ldxdw r1, [r10 - 0xd8]
016728: stxdw [r2 + 0x40], r1
016730: ldxdw r1, [r10 - 0x140]
016738: stxdw [r2 + 0x50], r1
016740: ldxdw r1, [r10 - 0x160]
016748: stxdw [r2 + 0x48], r1
016750: mov64 r1, 0x0
016758: mov64 r4, 0x60
016760: jslt r4, 0x0, +0xc2 ; branch 0x16d78
016768: ldxdw r1, [r3 + 0x0]
016770: lddw r0, 0x300008000
016780: jeq r1, 0x0, +0x1 ; branch 0x16790
016788: mov64 r0, r1
016790: mov64 r5, r0
016798: sub64 r5, r4
0167a0: mov64 r3, 0x0
0167a8: mov64 r1, 0x1
0167b0: mov64 r4, 0x1
0167b8: jgt r5, r0, +0x1 ; branch 0x167c8
0167c0: mov64 r4, 0x0
0167c8: jne r4, 0x0, +0x1 ; branch 0x167d8
0167d0: mov64 r3, r5
0167d8: lddw r4, 0x300000008
0167e8: jlt r3, r4, +0xb1 ; branch 0x16d78
0167f0: ldxdw r1, [r10 - 0x138]
0167f8: add64 r1, 0x578
016800: stxdw [r10 - 0x138], r1
016808: lddw r1, 0x300000000
016818: stxdw [r1 + 0x0], r3
016820: lddw r1, 0x1d9acb512ea545e4
016830: stxdw [r3 + 0x0], r1
016838: mov64 r1, 0x0
016840: mov64 r4, r3
016848: add64 r4, r1
016850: mov64 r5, r2
016858: add64 r5, r1
016860: ldxb r5, [r5 + 0x0]
016868: stxb [r4 + 0x8], r5
016870: add64 r1, 0x1
016878: jeq r1, 0x58, +0x1 ; branch 0x16888
016880: ja -0x9 ; branch 0x16840
016888: lddw r1, 0x300000000
016898: ldxdw r2, [r1 + 0x0]
0168a0: mov64 r1, r2
0168a8: add64 r1, -0x22
0168b0: mov64 r4, 0x0
0168b8: mov64 r5, 0x1
0168c0: jgt r1, r2, +0x1 ; branch 0x168d0
0168c8: mov64 r5, 0x0
0168d0: jne r5, 0x0, +0x1 ; branch 0x168e0
0168d8: mov64 r4, r1
0168e0: lddw r1, 0x300007fde
0168f0: jeq r2, 0x0, +0x1 ; branch 0x16900
0168f8: mov64 r1, r4
016900: mov64 r8, r7
016908: lddw r2, 0x300000007
016918: jgt r1, r2, +0x3 ; branch 0x16938
016920: mov64 r1, 0x1
016928: mov64 r2, 0x22
016930: call 0x1f545 ; call 0x111360
016938: lddw r2, 0x300000000
016948: stxdw [r2 + 0x0], r1
016950: ldxdw r2, [r6 + 0x0]
016958: ldxdw r4, [r6 + 0x8]
016960: ldxdw r5, [r6 + 0x10]
016968: ldxdw r0, [r6 + 0x18]
016970: stxdw [r1 + 0x18], r0
016978: stxdw [r1 + 0x10], r5
016980: stxdw [r1 + 0x8], r4
016988: stxdw [r1 + 0x0], r2
016990: sth [r1 + 0x20], 0x1
016998: stxdw [r10 - 0x60], r1
0169a0: stdw [r10 - 0x58], 0x1
0169a8: stdw [r10 - 0x68], 0x1
0169b0: mov64 r7, r10
0169b8: add64 r7, -0xd0
0169c0: mov64 r5, r10
0169c8: add64 r5, -0x68
0169d0: mov64 r1, r7
0169d8: lddw r2, 0x11e53e ; rodata b'\x0c\x14\xde\xfc\x82^\xc6v\x94%\x08\x18\xbbe@e\xf4)\x8d1V\xd5q\xb4\xd4\xf8\t\x0c\x18\xe9\xa8c\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15h\xbf\x17[\xaaQ\x89\xcb\x97\xf5\xd2\xff;e]+\xb6\xfdm\x18\xb0\x01V\xe0\xf6\x93fZ\xcfD\xdb\x15'
0169e8: mov64 r4, 0x60
0169f0: call 0x1ee2b ; call 0x10db50
0169f8: ldxdw r1, [r10 - 0x190]
016a00: stxb [r10 - 0x3e], r1
016a08: ldxdw r1, [r10 - 0x188]
016a10: stxb [r10 - 0x3f], r1
016a18: ldxdw r1, [r10 - 0x180]
016a20: stxb [r10 - 0x40], r1
016a28: ldxdw r1, [r10 - 0x178]
016a30: stxdw [r10 - 0x48], r1
016a38: ldxdw r1, [r10 - 0x170]
016a40: stxdw [r10 - 0x50], r1
016a48: ldxdw r1, [r10 - 0x158]
016a50: stxdw [r10 - 0x58], r1
016a58: ldxdw r9, [r10 - 0x168]
016a60: stxdw [r10 - 0x60], r9
016a68: stxdw [r10 - 0x68], r6
016a70: mov64 r1, r10
016a78: add64 r1, -0x28
016a80: stxdw [r10 - 0x38], r1
016a88: mov64 r1, r10
016a90: add64 r1, -0x1
016a98: stxdw [r10 - 0x18], r1
016aa0: lddw r1, 0x11c646 ; rodata b'__event_authorityGlobalVolumeAccumulator=programs/pump-amm/src/instructions'
016ab0: stxdw [r10 - 0x28], r1
016ab8: stxb [r10 - 0x1], r8
016ac0: stdw [r10 - 0x30], 0x2
016ac8: stdw [r10 - 0x10], 0x1
016ad0: stdw [r10 - 0x20], 0x11
016ad8: mov64 r1, r10
016ae0: add64 r1, -0x38
016ae8: stxdw [r10 - 0x1000], r1
016af0: stdw [r10 - 0xff8], 0x1
016af8: mov64 r1, r10
016b00: add64 r1, -0x80
016b08: mov64 r3, r10
016b10: add64 r3, -0x68
016b18: mov64 r5, r10
016b20: mov64 r2, r7
016b28: mov64 r4, 0x1
016b30: call 0x1dff0 ; call 0x106ab8
016b38: lddw r1, -0x7fffffffffffffe6
016b48: ldxdw r2, [r10 - 0x80]
016b50: jeq r2, r1, +0x1 ; branch 0x16b60
016b58: ja +0x28 ; branch 0x16ca0
016b60: ldxdw r1, [r9 + 0x0]
016b68: add64 r1, -0x1
016b70: stxdw [r9 + 0x0], r1
016b78: mov64 r6, r9
016b80: jne r1, 0x0, +0x3 ; branch 0x16ba0
016b88: ldxdw r1, [r6 + 0x8]
016b90: add64 r1, -0x1
016b98: stxdw [r6 + 0x8], r1
016ba0: ldxdw r2, [r10 - 0x158]
016ba8: ldxdw r1, [r2 + 0x0]
016bb0: add64 r1, -0x1
016bb8: stxdw [r2 + 0x0], r1
016bc0: jne r1, 0x0, +0x3 ; branch 0x16be0
016bc8: ldxdw r1, [r2 + 0x8]
016bd0: add64 r1, -0x1
016bd8: stxdw [r2 + 0x8], r1
016be0: lddw r1, 0x122380 ; rodata b'\x00\x00\x00\x00W\xc6\x11\x00\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xb6\xc6\x11\x00\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xce\xc6\x11\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc1\xc8\x11\x00C\x00\x00\x00\x00\x00\x00\x00M\x00\x00\x00$\x00\x00\x00\x00\x00\x00'
016bf0: stxdw [r10 - 0xd0], r1
016bf8: mov64 r1, r10
016c00: add64 r1, -0x28
016c08: stxdw [r10 - 0xc0], r1
016c10: lddw r1, 0xf978
016c20: stxdw [r10 - 0x20], r1
016c28: ldxdw r1, [r10 - 0x138]
016c30: stxdw [r10 - 0x28], r1
016c38: stdw [r10 - 0xb0], 0x0
016c40: stdw [r10 - 0xc8], 0x1
016c48: stdw [r10 - 0xb8], 0x1
016c50: mov64 r1, r10
016c58: add64 r1, -0x68
016c60: mov64 r2, r10
016c68: add64 r2, -0xd0
016c70: call 0x1f4f0 ; call 0x1113f8
016c78: ldxdw r1, [r10 - 0x60]
016c80: ldxdw r2, [r10 - 0x58]
016c88: call -0x1
016c90: mov64 r1, 0x2
016c98: ja +0x17 ; branch 0x16d58
016ca0: mov64 r1, r10
016ca8: add64 r1, -0x120
016cb0: mov64 r2, r10
016cb8: add64 r2, -0x80
016cc0: call 0x1d86f ; call 0x103040
016cc8: ldxdw r3, [r10 - 0x58]
016cd0: ldxdw r2, [r10 - 0x118]
016cd8: ldxdw r1, [r10 - 0x120]
016ce0: ldxdw r4, [r10 - 0x60]
016ce8: ldxdw r5, [r4 + 0x0]
016cf0: add64 r5, -0x1
016cf8: stxdw [r4 + 0x0], r5
016d00: jne r5, 0x0, +0x3 ; branch 0x16d20
016d08: ldxdw r5, [r4 + 0x8]
016d10: add64 r5, -0x1
016d18: stxdw [r4 + 0x8], r5
016d20: ldxdw r4, [r3 + 0x0]
016d28: add64 r4, -0x1
016d30: stxdw [r3 + 0x0], r4
016d38: jne r4, 0x0, +0x3 ; branch 0x16d58
016d40: ldxdw r4, [r3 + 0x8]
016d48: add64 r4, -0x1
016d50: stxdw [r3 + 0x8], r4
016d58: ldxdw r3, [r10 - 0x128]
016d60: stxdw [r3 + 0x8], r2
016d68: stxdw [r3 + 0x0], r1
016d70: exit
016d78: mov64 r2, 0x60
016d80: call 0x1f4b8 ; call 0x111348
