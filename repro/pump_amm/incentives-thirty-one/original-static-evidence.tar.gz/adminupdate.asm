06db20: mov64 r9, r3
06db28: mov64 r8, r2
06db30: stxdw [r10 - 0x248], r1
06db38: ldxdw r6, [r5 - 0x1000]
06db40: stxdw [r8 + 0x210], r6
06db48: ldxdw r1, [r5 - 0xff8]
06db50: ldxdw r2, [r1 + 0x0]
06db58: stxdw [r8 + 0x0], r2
06db60: ldxdw r2, [r1 + 0x8]
06db68: stxdw [r8 + 0x8], r2
06db70: ldxdw r2, [r1 + 0x10]
06db78: stxdw [r8 + 0x10], r2
06db80: ldxdw r1, [r1 + 0x18]
06db88: stxdw [r8 + 0x18], r1
06db90: ldxdw r7, [r5 - 0xfe0]
06db98: ldxdw r1, [r5 - 0xfe8]
06dba0: stxdw [r10 - 0x240], r1
06dba8: ldxdw r1, [r5 - 0xff0]
06dbb0: stxdw [r10 - 0x250], r1
06dbb8: jeq r9, 0x0, +0x1 ; branch 0x6dbc8
06dbc0: jne r4, 0x0, +0x22 ; branch 0x6dcd8
06dbc8: mov64 r9, 0x2
06dbd0: ldxdw r1, [r10 - 0x240]
06dbd8: jeq r1, 0x0, +0x2af ; branch 0x6f158
06dbe0: ldxdw r1, [r8 + 0x200]
06dbe8: jslt r7, r1, +0x5d ; branch 0x6ded8
06dbf0: ldxdw r2, [r8 + 0x208]
06dbf8: ldxdw r6, [r10 - 0x240]
06dc00: jslt r2, r7, +0x1 ; branch 0x6dc10
06dc08: ja +0xad ; branch 0x6e178
06dc10: mov64 r1, r10
06dc18: add64 r1, -0x78
06dc20: lddw r2, 0x11c0a0 ; rodata b'#\x00\x00\x00\x11\x00\x00\x00    >\x00\x00\x00N\x00\x00\x00data\x15\x00\x00\x00Q\x00\x00\x00,\x00\x00\x00mint8\x00\x00\x00!\x00\x00\x00src/de/mod.rsfailed to fill'
06dc30: call 0xef8 ; call 0x753f8
06dc38: stdw [r10 - 0x50], 0x0
06dc40: stdw [r10 - 0x58], 0x1
06dc48: stdw [r10 - 0x60], 0x0
06dc50: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06dc60: stxdw [r10 - 0x20], r1
06dc68: mov64 r1, r10
06dc70: add64 r1, -0x60
06dc78: stxdw [r10 - 0x28], r1
06dc80: stb [r10 - 0x10], 0x3
06dc88: stdw [r10 - 0x18], 0x20
06dc90: stdw [r10 - 0x38], 0x0
06dc98: stdw [r10 - 0x48], 0x0
06dca0: mov64 r2, r10
06dca8: add64 r2, -0x48
06dcb0: lddw r1, 0x11c0a0 ; rodata b'#\x00\x00\x00\x11\x00\x00\x00    >\x00\x00\x00N\x00\x00\x00data\x15\x00\x00\x00Q\x00\x00\x00,\x00\x00\x00mint8\x00\x00\x00!\x00\x00\x00src/de/mod.rsfailed to fill'
06dcc0: call 0x19db ; call 0x7aba0
06dcc8: jeq r0, 0x0, +0xb3 ; branch 0x6e268
06dcd0: ja +0x263 ; branch 0x6eff0
06dcd8: ldxdw r1, [r8 + 0x200]
06dce0: jeq r1, r9, +0xa ; branch 0x6dd38
06dce8: jslt r7, r9, +0x1 ; branch 0x6dcf8
06dcf0: ja +0x247 ; branch 0x6ef30
06dcf8: stxdw [r8 + 0x200], r9
06dd00: mov64 r1, r8
06dd08: add64 r1, 0x20
06dd10: mov64 r2, 0x0
06dd18: mov64 r3, 0x1e0
06dd20: stxdw [r10 - 0x258], r4
06dd28: call 0x15771 ; call 0x1198b8
06dd30: ldxdw r4, [r10 - 0x258]
06dd38: jsgt r4, r7, +0x1 ; branch 0x6dd48
06dd40: ja +0x48 ; branch 0x6df88
06dd48: stxdw [r10 - 0x258], r4
06dd50: jsgt r4, r9, +0x1 ; branch 0x6dd60
06dd58: ja +0xdb ; branch 0x6e438
06dd60: mov64 r3, r6
06dd68: arsh64 r3, 0x3f
06dd70: mov64 r1, r10
06dd78: add64 r1, -0x188
06dd80: mov64 r2, r6
06dd88: mov64 r4, 0x1e
06dd90: mov64 r5, 0x0
06dd98: call 0x15b52 ; call 0x11b830
06dda0: ldxdw r5, [r10 - 0x188]
06dda8: mov64 r2, r5
06ddb0: arsh64 r2, 0x3f
06ddb8: mov64 r1, 0x1
06ddc0: ldxdw r3, [r10 - 0x180]
06ddc8: jne r3, r2, +0x1 ; branch 0x6ddd8
06ddd0: mov64 r1, 0x0
06ddd8: and64 r1, 0x1
06dde0: jne r1, 0x0, +0x2aa ; branch 0x6f338
06dde8: mov64 r2, 0x1
06ddf0: mov64 r1, 0x1
06ddf8: mov64 r3, r9
06de00: ldxdw r4, [r10 - 0x258]
06de08: jsgt r9, 0x0, +0x1 ; branch 0x6de18
06de10: mov64 r1, 0x0
06de18: mov64 r9, r4
06de20: sub64 r9, r3
06de28: jslt r9, r4, +0x1 ; branch 0x6de38
06de30: mov64 r2, 0x0
06de38: xor64 r1, r2
06de40: and64 r1, 0x1
06de48: jne r1, 0x0, +0x2a3 ; branch 0x6f368
06de50: jsgt r5, r9, +0x1 ; branch 0x6de60
06de58: ja +0x13c ; branch 0x6e840
06de60: stxdw [r8 + 0x208], r4
06de68: mov64 r1, r3
06de70: jsgt r7, r1, +0x1 ; branch 0x6de80
06de78: ja -0x57 ; branch 0x6dbc8
06de80: jsgt r7, -0x1, +0x1b4 ; branch 0x6ec28
06de88: mov64 r3, r10
06de90: add64 r3, -0x1
06de98: lddw r1, 0x11d013 ; rodata b'SVM is 64-bitprograms/pump-amm/src/utils/token.rsprograms/pump-amm/src/util'
06dea8: mov64 r2, 0xd
06deb0: lddw r4, 0x1225b8 ; rodata b'\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \xe1\x00\x00\x00\x00\x00\x00\x9f\xce\x11\x00,\x00\x00\x00\x00\x00\x00\x00\x84\x01\x00\x00-\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x006\x00\x00'
06dec0: lddw r5, 0x122740 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x8e\x01\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00 \xd0\x11\x00$\x00\x00\x00\x00\x00\x00\x00U\x01\x00\x00$\x00\x00\x00\x00\x00\x00\x00\xc9\xd7\x11\x00/\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf8\xd7\x11\x00G\x00\x00'
06ded0: call 0x14a18 ; call 0x112f98
06ded8: mov64 r1, r8
06dee0: call 0x29c ; call 0x6f3c8
06dee8: ldxdw r1, [r10 - 0x250]
06def0: ldxdw r5, [r10 - 0x240]
06def8: jlt r1, 0x1e, +0x51 ; branch 0x6e188
06df00: mov64 r1, 0x0
06df08: add64 r8, 0x20
06df10: ja +0x4 ; branch 0x6df38
06df18: mov64 r3, 0x2
06df20: jge r1, r0, +0x1e5 ; branch 0x6ee50
06df28: add64 r1, r4
06df30: jgt r1, r0, +0x1e3 ; branch 0x6ee50
06df38: jgt r1, 0x1d, +0x26b ; branch 0x6f298
06df40: mov64 r2, r1
06df48: lsh64 r2, 0x3
06df50: mov64 r3, r8
06df58: add64 r3, r2
06df60: stxdw [r3 + 0x0], r5
06df68: mov64 r4, 0x1
06df70: jlt r1, r0, -0xc ; branch 0x6df18
06df78: mov64 r4, 0x0
06df80: ja -0xe ; branch 0x6df18
06df88: mov64 r6, r4
06df90: mov64 r1, r10
06df98: add64 r1, -0x78
06dfa0: lddw r2, 0x11c044 ; rodata b'\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00'
06dfb0: call 0xe88 ; call 0x753f8
06dfb8: stdw [r10 - 0x50], 0x0
06dfc0: stdw [r10 - 0x58], 0x1
06dfc8: stdw [r10 - 0x60], 0x0
06dfd0: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06dfe0: stxdw [r10 - 0x20], r1
06dfe8: mov64 r1, r10
06dff0: add64 r1, -0x60
06dff8: stxdw [r10 - 0x28], r1
06e000: stb [r10 - 0x10], 0x3
06e008: stdw [r10 - 0x18], 0x20
06e010: stdw [r10 - 0x38], 0x0
06e018: stdw [r10 - 0x48], 0x0
06e020: mov64 r2, r10
06e028: add64 r2, -0x48
06e030: lddw r1, 0x11c044 ; rodata b'\x1f\x00\x00\x00\xc5\t\x00\x00\x01\x00\x00\x00)\x00\x00\x00P\x00\x00\x00W\x00\x00\x002\x00\x00\x00%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00'
06e040: call 0x196b ; call 0x7aba0
06e048: jeq r0, 0x0, +0x1 ; branch 0x6e058
06e050: ja +0x1f3 ; branch 0x6eff0
06e058: ldxdw r1, [r10 - 0x50]
06e060: stxdw [r10 - 0xd0], r1
06e068: ldxdw r1, [r10 - 0x58]
06e070: stxdw [r10 - 0xd8], r1
06e078: ldxdw r1, [r10 - 0x60]
06e080: stxdw [r10 - 0xe0], r1
06e088: ldxdw r1, [r10 - 0x78]
06e090: stxdw [r10 - 0xf8], r1
06e098: ldxdw r1, [r10 - 0x70]
06e0a0: stxdw [r10 - 0xf0], r1
06e0a8: ldxdw r1, [r10 - 0x68]
06e0b0: stxdw [r10 - 0xe8], r1
06e0b8: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06e0c8: stxdw [r10 - 0x110], r1
06e0d0: stw [r10 - 0x80], 0x178f
06e0d8: stb [r10 - 0xc8], 0x2
06e0e0: stw [r10 - 0x100], 0x147
06e0e8: stdw [r10 - 0x108], 0x31
06e0f0: stdw [r10 - 0x118], 0x0
06e0f8: mov64 r1, r10
06e100: add64 r1, -0x148
06e108: mov64 r2, r10
06e110: add64 r2, -0x118
06e118: call 0x129d3 ; call 0x102fb8
06e120: ldxdw r3, [r10 - 0x140]
06e128: ldxdw r2, [r10 - 0x148]
06e130: mov64 r1, r10
06e138: add64 r1, -0x158
06e140: mov64 r4, r6
06e148: mov64 r5, r7
06e150: call -0xd9ca ; call 0x1308
06e158: ldxdw r2, [r10 - 0x150]
06e160: ldxdw r9, [r10 - 0x158]
06e168: jeq r9, 0x2, -0xb5 ; branch 0x6dbc8
06e170: ja +0x1fc ; branch 0x6f158
06e178: jsgt r7, -0x1, +0x39 ; branch 0x6e348
06e180: ja -0x60 ; branch 0x6de88
06e188: jlt r0, r1, +0x1 ; branch 0x6e198
06e190: ja +0x91 ; branch 0x6e620
06e198: mov64 r6, r0
06e1a0: mov64 r1, r10
06e1a8: add64 r1, -0x78
06e1b0: lddw r2, 0x11bf98 ; rodata b'$\x00\x00\x00code\x0c\x00\x00\x00\xca\t\x00\x00R\x00\x00\x00\x1c\x00\x00\x00K\x00\x00\x00"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00'
06e1c0: call 0xe46 ; call 0x753f8
06e1c8: stdw [r10 - 0x50], 0x0
06e1d0: stdw [r10 - 0x58], 0x1
06e1d8: stdw [r10 - 0x60], 0x0
06e1e0: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06e1f0: stxdw [r10 - 0x20], r1
06e1f8: mov64 r1, r10
06e200: add64 r1, -0x60
06e208: stxdw [r10 - 0x28], r1
06e210: stb [r10 - 0x10], 0x3
06e218: stdw [r10 - 0x18], 0x20
06e220: stdw [r10 - 0x38], 0x0
06e228: stdw [r10 - 0x48], 0x0
06e230: mov64 r2, r10
06e238: add64 r2, -0x48
06e240: lddw r1, 0x11bf98 ; rodata b'$\x00\x00\x00code\x0c\x00\x00\x00\xca\t\x00\x00R\x00\x00\x00\x1c\x00\x00\x00K\x00\x00\x00"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00'
06e250: call 0x1929 ; call 0x7aba0
06e258: jeq r0, 0x0, +0x7d ; branch 0x6e648
06e260: ja +0x1b1 ; branch 0x6eff0
06e268: ldxdw r1, [r10 - 0x50]
06e270: stxdw [r10 - 0xd0], r1
06e278: ldxdw r1, [r10 - 0x58]
06e280: stxdw [r10 - 0xd8], r1
06e288: ldxdw r1, [r10 - 0x60]
06e290: stxdw [r10 - 0xe0], r1
06e298: ldxdw r1, [r10 - 0x78]
06e2a0: stxdw [r10 - 0xf8], r1
06e2a8: ldxdw r1, [r10 - 0x70]
06e2b0: stxdw [r10 - 0xf0], r1
06e2b8: ldxdw r1, [r10 - 0x68]
06e2c0: stxdw [r10 - 0xe8], r1
06e2c8: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06e2d8: stxdw [r10 - 0x110], r1
06e2e0: stw [r10 - 0x80], 0x1793
06e2e8: stb [r10 - 0xc8], 0x2
06e2f0: stw [r10 - 0x100], 0xfb
06e2f8: stdw [r10 - 0x108], 0x31
06e300: stdw [r10 - 0x118], 0x0
06e308: mov64 r1, r10
06e310: add64 r1, -0x218
06e318: mov64 r2, r10
06e320: add64 r2, -0x118
06e328: call 0x12991 ; call 0x102fb8
06e330: ldxdw r2, [r10 - 0x210]
06e338: ldxdw r3, [r10 - 0x218]
06e340: ja +0x161 ; branch 0x6ee50
06e348: jsgt r1, -0x1, +0x1 ; branch 0x6e358
06e350: ja -0x9a ; branch 0x6de88
06e358: jlt r7, r1, +0x1f5 ; branch 0x6f308
06e360: ldxdw r2, [r8 + 0x210]
06e368: jeq r2, 0x0, +0x1f3 ; branch 0x6f308
06e370: jsgt r2, -0x1, +0x1 ; branch 0x6e380
06e378: ja -0x9f ; branch 0x6de88
06e380: sub64 r7, r1
06e388: div64 r7, r2
06e390: mov64 r1, r8
06e398: call 0x205 ; call 0x6f3c8
06e3a0: ldxdw r1, [r10 - 0x250]
06e3a8: jlt r1, 0x1e, +0x76 ; branch 0x6e760
06e3b0: mov64 r3, 0x2
06e3b8: jgt r7, r0, +0x152 ; branch 0x6ee50
06e3c0: add64 r8, 0x20
06e3c8: ja +0x3 ; branch 0x6e3e8
06e3d0: jge r7, r0, +0x14f ; branch 0x6ee50
06e3d8: add64 r7, r1
06e3e0: jgt r7, r0, +0x14d ; branch 0x6ee50
06e3e8: jgt r7, 0x1d, +0x1d9 ; branch 0x6f2b8
06e3f0: mov64 r1, r7
06e3f8: lsh64 r1, 0x3
06e400: mov64 r2, r8
06e408: add64 r2, r1
06e410: stxdw [r2 + 0x0], r6
06e418: mov64 r1, 0x1
06e420: jlt r7, r0, -0xb ; branch 0x6e3d0
06e428: mov64 r1, 0x0
06e430: ja -0xd ; branch 0x6e3d0
06e438: mov64 r1, r10
06e440: add64 r1, -0x78
06e448: lddw r2, 0x11c064 ; rodata b' \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00\x006\x00\x00\x00\xba\x0b\x00\x000\x00\x00\x00\x1b\x00\x00\x00#\x00\x00\x00\x11\x00\x00\x00    >\x00\x00'
06e458: call 0xdf3 ; call 0x753f8
06e460: stdw [r10 - 0x50], 0x0
06e468: stdw [r10 - 0x58], 0x1
06e470: stdw [r10 - 0x60], 0x0
06e478: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06e488: stxdw [r10 - 0x20], r1
06e490: mov64 r1, r10
06e498: add64 r1, -0x60
06e4a0: stxdw [r10 - 0x28], r1
06e4a8: stb [r10 - 0x10], 0x3
06e4b0: stdw [r10 - 0x18], 0x20
06e4b8: stdw [r10 - 0x38], 0x0
06e4c0: stdw [r10 - 0x48], 0x0
06e4c8: mov64 r2, r10
06e4d0: add64 r2, -0x48
06e4d8: lddw r1, 0x11c064 ; rodata b' \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00\x006\x00\x00\x00\xba\x0b\x00\x000\x00\x00\x00\x1b\x00\x00\x00#\x00\x00\x00\x11\x00\x00\x00    >\x00\x00'
06e4e8: call 0x18d6 ; call 0x7aba0
06e4f0: jeq r0, 0x0, +0x1 ; branch 0x6e500
06e4f8: ja +0x15e ; branch 0x6eff0
06e500: ldxdw r1, [r10 - 0x50]
06e508: stxdw [r10 - 0xd0], r1
06e510: ldxdw r1, [r10 - 0x58]
06e518: stxdw [r10 - 0xd8], r1
06e520: ldxdw r1, [r10 - 0x60]
06e528: stxdw [r10 - 0xe0], r1
06e530: ldxdw r1, [r10 - 0x78]
06e538: stxdw [r10 - 0xf8], r1
06e540: ldxdw r1, [r10 - 0x70]
06e548: stxdw [r10 - 0xf0], r1
06e550: ldxdw r1, [r10 - 0x68]
06e558: stxdw [r10 - 0xe8], r1
06e560: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06e570: stxdw [r10 - 0x110], r1
06e578: stw [r10 - 0x80], 0x1790
06e580: stb [r10 - 0xc8], 0x2
06e588: stw [r10 - 0x100], 0x149
06e590: stdw [r10 - 0x108], 0x31
06e598: stdw [r10 - 0x118], 0x0
06e5a0: mov64 r1, r10
06e5a8: add64 r1, -0x168
06e5b0: mov64 r2, r10
06e5b8: add64 r2, -0x118
06e5c0: call 0x1293e ; call 0x102fb8
06e5c8: ldxdw r3, [r10 - 0x160]
06e5d0: ldxdw r2, [r10 - 0x168]
06e5d8: mov64 r1, r10
06e5e0: add64 r1, -0x178
06e5e8: ldxdw r4, [r10 - 0x258]
06e5f0: mov64 r5, r9
06e5f8: call -0xda5f ; call 0x1308
06e600: ldxdw r2, [r10 - 0x170]
06e608: ldxdw r9, [r10 - 0x178]
06e610: jeq r9, 0x2, -0x14a ; branch 0x6dbc8
06e618: ja +0x167 ; branch 0x6f158
06e620: lsh64 r1, 0x3
06e628: add64 r8, r1
06e630: stxdw [r8 + 0x20], r5
06e638: mov64 r3, 0x2
06e640: ja +0x101 ; branch 0x6ee50
06e648: ldxdw r1, [r10 - 0x50]
06e650: stxdw [r10 - 0xd0], r1
06e658: ldxdw r1, [r10 - 0x58]
06e660: stxdw [r10 - 0xd8], r1
06e668: ldxdw r1, [r10 - 0x60]
06e670: stxdw [r10 - 0xe0], r1
06e678: ldxdw r1, [r10 - 0x78]
06e680: stxdw [r10 - 0xf8], r1
06e688: ldxdw r1, [r10 - 0x70]
06e690: stxdw [r10 - 0xf0], r1
06e698: ldxdw r1, [r10 - 0x68]
06e6a0: stxdw [r10 - 0xe8], r1
06e6a8: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06e6b8: stxdw [r10 - 0x110], r1
06e6c0: stw [r10 - 0x80], 0x1794
06e6c8: stb [r10 - 0xc8], 0x2
06e6d0: stw [r10 - 0x100], 0x107
06e6d8: stdw [r10 - 0x108], 0x31
06e6e0: stdw [r10 - 0x118], 0x0
06e6e8: mov64 r1, r10
06e6f0: add64 r1, -0x228
06e6f8: mov64 r2, r10
06e700: add64 r2, -0x118
06e708: call 0x12915 ; call 0x102fb8
06e710: ldxdw r3, [r10 - 0x220]
06e718: ldxdw r2, [r10 - 0x228]
06e720: mov64 r1, r10
06e728: add64 r1, -0x238
06e730: mov64 r4, r6
06e738: ldxdw r5, [r10 - 0x250]
06e740: call -0xdbda ; call 0x878
06e748: ldxdw r2, [r10 - 0x230]
06e750: ldxdw r3, [r10 - 0x238]
06e758: ja +0xde ; branch 0x6ee50
06e760: jlt r0, r1, +0x1 ; branch 0x6e770
06e768: ja +0x59 ; branch 0x6ea38
06e770: mov64 r6, r0
06e778: mov64 r1, r10
06e780: add64 r1, -0x78
06e788: lddw r2, 0x11bf98 ; rodata b'$\x00\x00\x00code\x0c\x00\x00\x00\xca\t\x00\x00R\x00\x00\x00\x1c\x00\x00\x00K\x00\x00\x00"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00'
06e798: call 0xd8b ; call 0x753f8
06e7a0: stdw [r10 - 0x50], 0x0
06e7a8: stdw [r10 - 0x58], 0x1
06e7b0: stdw [r10 - 0x60], 0x0
06e7b8: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06e7c8: stxdw [r10 - 0x20], r1
06e7d0: mov64 r1, r10
06e7d8: add64 r1, -0x60
06e7e0: stxdw [r10 - 0x28], r1
06e7e8: stb [r10 - 0x10], 0x3
06e7f0: stdw [r10 - 0x18], 0x20
06e7f8: stdw [r10 - 0x38], 0x0
06e800: stdw [r10 - 0x48], 0x0
06e808: mov64 r2, r10
06e810: add64 r2, -0x48
06e818: lddw r1, 0x11bf98 ; rodata b'$\x00\x00\x00code\x0c\x00\x00\x00\xca\t\x00\x00R\x00\x00\x00\x1c\x00\x00\x00K\x00\x00\x00"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00'
06e828: call 0x186e ; call 0x7aba0
06e830: jeq r0, 0x0, +0x5b ; branch 0x6eb10
06e838: ja +0xf6 ; branch 0x6eff0
06e840: mov64 r6, r5
06e848: mov64 r1, r10
06e850: add64 r1, -0x78
06e858: lddw r2, 0x11c0cc ; rodata b'!\x00\x00\x00src/de/mod.rsfailed to fill whole buffer()a Display implementation retu'
06e868: call 0xd71 ; call 0x753f8
06e870: stdw [r10 - 0x50], 0x0
06e878: stdw [r10 - 0x58], 0x1
06e880: stdw [r10 - 0x60], 0x0
06e888: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06e898: stxdw [r10 - 0x20], r1
06e8a0: mov64 r1, r10
06e8a8: add64 r1, -0x60
06e8b0: stxdw [r10 - 0x28], r1
06e8b8: stb [r10 - 0x10], 0x3
06e8c0: stdw [r10 - 0x18], 0x20
06e8c8: stdw [r10 - 0x38], 0x0
06e8d0: stdw [r10 - 0x48], 0x0
06e8d8: mov64 r2, r10
06e8e0: add64 r2, -0x48
06e8e8: lddw r1, 0x11c0cc ; rodata b'!\x00\x00\x00src/de/mod.rsfailed to fill whole buffer()a Display implementation retu'
06e8f8: call 0x1854 ; call 0x7aba0
06e900: jeq r0, 0x0, +0x1 ; branch 0x6e910
06e908: ja +0xdc ; branch 0x6eff0
06e910: add64 r6, -0x1
06e918: ldxdw r1, [r10 - 0x50]
06e920: stxdw [r10 - 0xd0], r1
06e928: ldxdw r1, [r10 - 0x58]
06e930: stxdw [r10 - 0xd8], r1
06e938: ldxdw r1, [r10 - 0x60]
06e940: stxdw [r10 - 0xe0], r1
06e948: ldxdw r1, [r10 - 0x78]
06e950: stxdw [r10 - 0xf8], r1
06e958: ldxdw r1, [r10 - 0x70]
06e960: stxdw [r10 - 0xf0], r1
06e968: ldxdw r1, [r10 - 0x68]
06e970: stxdw [r10 - 0xe8], r1
06e978: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06e988: stxdw [r10 - 0x110], r1
06e990: stw [r10 - 0x80], 0x1791
06e998: stb [r10 - 0xc8], 0x2
06e9a0: stw [r10 - 0x100], 0x14b
06e9a8: stdw [r10 - 0x108], 0x31
06e9b0: stdw [r10 - 0x118], 0x0
06e9b8: mov64 r1, r10
06e9c0: add64 r1, -0x198
06e9c8: mov64 r2, r10
06e9d0: add64 r2, -0x118
06e9d8: call 0x128bb ; call 0x102fb8
06e9e0: ldxdw r3, [r10 - 0x190]
06e9e8: ldxdw r2, [r10 - 0x198]
06e9f0: mov64 r1, r10
06e9f8: add64 r1, -0x1a8
06ea00: mov64 r4, r6
06ea08: mov64 r5, r9
06ea10: call -0xdae2 ; call 0x1308
06ea18: ldxdw r2, [r10 - 0x1a0]
06ea20: ldxdw r9, [r10 - 0x1a8]
06ea28: jeq r9, 0x2, -0x1cd ; branch 0x6dbc8
06ea30: ja +0xe4 ; branch 0x6f158
06ea38: jgt r7, r1, +0x1 ; branch 0x6ea48
06ea40: ja +0x5a ; branch 0x6ed18
06ea48: mov64 r1, r10
06ea50: add64 r1, -0x78
06ea58: lddw r2, 0x11c060 ; rodata b'%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00\x006\x00\x00\x00\xba\x0b\x00\x000\x00\x00\x00\x1b\x00\x00\x00#\x00\x00\x00\x11\x00\x00\x00   '
06ea68: call 0xd31 ; call 0x753f8
06ea70: stdw [r10 - 0x50], 0x0
06ea78: stdw [r10 - 0x58], 0x1
06ea80: stdw [r10 - 0x60], 0x0
06ea88: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06ea98: stxdw [r10 - 0x20], r1
06eaa0: mov64 r1, r10
06eaa8: add64 r1, -0x60
06eab0: stxdw [r10 - 0x28], r1
06eab8: stb [r10 - 0x10], 0x3
06eac0: stdw [r10 - 0x18], 0x20
06eac8: stdw [r10 - 0x38], 0x0
06ead0: stdw [r10 - 0x48], 0x0
06ead8: mov64 r2, r10
06eae0: add64 r2, -0x48
06eae8: lddw r1, 0x11c060 ; rodata b'%\x00\x00\x00 \x00\x00\x00\x19\x00\x00\x00+\x00\x00\x00;\x00\x00\x00=\x00\x00\x00<\x00\x00\x00\x18\x00\x00\x00G\x00\x00\x00\x0b\x00\x00\x00None\r\x00\x00\x006\x00\x00\x00\xba\x0b\x00\x000\x00\x00\x00\x1b\x00\x00\x00#\x00\x00\x00\x11\x00\x00\x00   '
06eaf8: call 0x1814 ; call 0x7aba0
06eb00: jeq r0, 0x0, +0x47 ; branch 0x6ed40
06eb08: ja +0x9c ; branch 0x6eff0
06eb10: ldxdw r1, [r10 - 0x50]
06eb18: stxdw [r10 - 0xd0], r1
06eb20: ldxdw r1, [r10 - 0x58]
06eb28: stxdw [r10 - 0xd8], r1
06eb30: ldxdw r1, [r10 - 0x60]
06eb38: stxdw [r10 - 0xe0], r1
06eb40: ldxdw r1, [r10 - 0x78]
06eb48: stxdw [r10 - 0xf8], r1
06eb50: ldxdw r1, [r10 - 0x70]
06eb58: stxdw [r10 - 0xf0], r1
06eb60: ldxdw r1, [r10 - 0x68]
06eb68: stxdw [r10 - 0xe8], r1
06eb70: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06eb80: stxdw [r10 - 0x110], r1
06eb88: stw [r10 - 0x80], 0x1794
06eb90: stb [r10 - 0xc8], 0x2
06eb98: stw [r10 - 0x100], 0x123
06eba0: stdw [r10 - 0x108], 0x31
06eba8: stdw [r10 - 0x118], 0x0
06ebb0: mov64 r1, r10
06ebb8: add64 r1, -0x1f8
06ebc0: mov64 r2, r10
06ebc8: add64 r2, -0x118
06ebd0: call 0x1287c ; call 0x102fb8
06ebd8: ldxdw r3, [r10 - 0x1f0]
06ebe0: ldxdw r2, [r10 - 0x1f8]
06ebe8: mov64 r1, r10
06ebf0: add64 r1, -0x208
06ebf8: mov64 r4, r6
06ec00: ldxdw r5, [r10 - 0x250]
06ec08: call -0xdc73 ; call 0x878
06ec10: ldxdw r2, [r10 - 0x200]
06ec18: ldxdw r3, [r10 - 0x208]
06ec20: ja +0x45 ; branch 0x6ee50
06ec28: jsgt r1, -0x1, +0x1 ; branch 0x6ec38
06ec30: ja -0x1b6 ; branch 0x6de88
06ec38: jlt r7, r1, +0xeb ; branch 0x6f398
06ec40: jeq r6, 0x0, +0xea ; branch 0x6f398
06ec48: jsgt r6, -0x1, +0x1 ; branch 0x6ec58
06ec50: ja -0x1ba ; branch 0x6de88
06ec58: mov64 r9, r7
06ec60: sub64 r9, r3
06ec68: div64 r9, r6
06ec70: mov64 r1, r8
06ec78: call 0xe9 ; call 0x6f3c8
06ec80: mov64 r6, r0
06ec88: jle r6, r9, +0x3b ; branch 0x6ee68
06ec90: mov64 r1, r8
06ec98: add64 r1, 0x110
06eca0: add64 r9, 0x1
06eca8: ja +0x3 ; branch 0x6ecc8
06ecb0: jge r9, r6, -0x21e ; branch 0x6dbc8
06ecb8: add64 r9, r2
06ecc0: jgt r9, r6, -0x220 ; branch 0x6dbc8
06ecc8: jgt r9, 0x1d, +0xc2 ; branch 0x6f2e0
06ecd0: mov64 r2, r9
06ecd8: lsh64 r2, 0x3
06ece0: mov64 r3, r1
06ece8: add64 r3, r2
06ecf0: stdw [r3 + 0x0], 0x0
06ecf8: mov64 r2, 0x1
06ed00: jlt r9, r6, -0xb ; branch 0x6ecb0
06ed08: mov64 r2, 0x0
06ed10: ja -0xd ; branch 0x6ecb0
06ed18: lsh64 r1, 0x3
06ed20: add64 r8, r1
06ed28: stxdw [r8 + 0x20], r6
06ed30: mov64 r3, 0x2
06ed38: ja +0x22 ; branch 0x6ee50
06ed40: ldxdw r1, [r10 - 0x50]
06ed48: stxdw [r10 - 0xd0], r1
06ed50: ldxdw r1, [r10 - 0x58]
06ed58: stxdw [r10 - 0xd8], r1
06ed60: ldxdw r1, [r10 - 0x60]
06ed68: stxdw [r10 - 0xe0], r1
06ed70: ldxdw r1, [r10 - 0x78]
06ed78: stxdw [r10 - 0xf8], r1
06ed80: ldxdw r1, [r10 - 0x70]
06ed88: stxdw [r10 - 0xf0], r1
06ed90: ldxdw r1, [r10 - 0x68]
06ed98: stxdw [r10 - 0xe8], r1
06eda0: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06edb0: stxdw [r10 - 0x110], r1
06edb8: stw [r10 - 0x80], 0x1795
06edc0: stb [r10 - 0xc8], 0x2
06edc8: stw [r10 - 0x100], 0x124
06edd0: stdw [r10 - 0x108], 0x31
06edd8: stdw [r10 - 0x118], 0x0
06ede0: mov64 r1, r10
06ede8: add64 r1, -0x1d8
06edf0: mov64 r2, r10
06edf8: add64 r2, -0x118
06ee00: call 0x12836 ; call 0x102fb8
06ee08: ldxdw r3, [r10 - 0x1d0]
06ee10: ldxdw r2, [r10 - 0x1d8]
06ee18: mov64 r1, r10
06ee20: add64 r1, -0x1e8
06ee28: ldxdw r4, [r10 - 0x250]
06ee30: mov64 r5, r7
06ee38: call -0xdcb9 ; call 0x878
06ee40: ldxdw r2, [r10 - 0x1e0]
06ee48: ldxdw r3, [r10 - 0x1e8]
06ee50: jeq r3, 0x2, +0x60 ; branch 0x6f158
06ee58: mov64 r9, r3
06ee60: ja +0x5e ; branch 0x6f158
06ee68: mov64 r1, r10
06ee70: add64 r1, -0x78
06ee78: lddw r2, 0x11bfb4 ; rodata b'"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00\x00U\x00\x00\x009\x00\x00\x00?\x00\x00\x005\x00\x00\x00\x05\x10\x00\x00E\x00\x00\x00B\x00\x00'
06ee88: call 0xcad ; call 0x753f8
06ee90: stdw [r10 - 0x50], 0x0
06ee98: stdw [r10 - 0x58], 0x1
06eea0: stdw [r10 - 0x60], 0x0
06eea8: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06eeb8: stxdw [r10 - 0x20], r1
06eec0: mov64 r1, r10
06eec8: add64 r1, -0x60
06eed0: stxdw [r10 - 0x28], r1
06eed8: stb [r10 - 0x10], 0x3
06eee0: stdw [r10 - 0x18], 0x20
06eee8: stdw [r10 - 0x38], 0x0
06eef0: stdw [r10 - 0x48], 0x0
06eef8: mov64 r2, r10
06ef00: add64 r2, -0x48
06ef08: lddw r1, 0x11bfb4 ; rodata b'"\x00\x00\x00\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00\x00U\x00\x00\x009\x00\x00\x00?\x00\x00\x005\x00\x00\x00\x05\x10\x00\x00E\x00\x00\x00B\x00\x00'
06ef18: call 0x1790 ; call 0x7aba0
06ef20: jeq r0, 0x0, +0x4a ; branch 0x6f178
06ef28: ja +0x18 ; branch 0x6eff0
06ef30: mov64 r1, r10
06ef38: add64 r1, -0x78
06ef40: lddw r2, 0x11bfb8 ; rodata b'\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00\x00U\x00\x00\x009\x00\x00\x00?\x00\x00\x005\x00\x00\x00\x05\x10\x00\x00E\x00\x00\x00B\x00\x00\x00\x12\x00\x00'
06ef50: call 0xc94 ; call 0x753f8
06ef58: stdw [r10 - 0x50], 0x0
06ef60: stdw [r10 - 0x58], 0x1
06ef68: stdw [r10 - 0x60], 0x0
06ef70: lddw r1, 0x1221e0 ; rodata b'\x00\x00\x00\x000\x9b\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xaf\x00\x00\x00\x00\x00\x00P\xac\x00\x00\x00\x00\x00\x00\x98\x89\x00\x00\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
06ef80: stxdw [r10 - 0x20], r1
06ef88: mov64 r1, r10
06ef90: add64 r1, -0x60
06ef98: stxdw [r10 - 0x28], r1
06efa0: stb [r10 - 0x10], 0x3
06efa8: stdw [r10 - 0x18], 0x20
06efb0: stdw [r10 - 0x38], 0x0
06efb8: stdw [r10 - 0x48], 0x0
06efc0: mov64 r2, r10
06efc8: add64 r2, -0x48
06efd0: lddw r1, 0x11bfb8 ; rodata b'\x1e\x00\x00\x00Kind3\x00\x00\x00C\x00\x00\x007\x00\x00\x00fromkindD\x00\x00\x00\x14\x00\x00\x00\x13\x00\x00\x00:\x00\x00\x00U\x00\x00\x009\x00\x00\x00?\x00\x00\x005\x00\x00\x00\x05\x10\x00\x00E\x00\x00\x00B\x00\x00\x00\x12\x00\x00'
06efe0: call 0x1777 ; call 0x7aba0
06efe8: jeq r0, 0x0, +0xa ; branch 0x6f040
06eff0: mov64 r3, r10
06eff8: add64 r3, -0x1
06f000: lddw r1, 0x11c0fa ; rodata b'a Display implementation returned an error unexpectedly/home/runner/work/pl'
06f010: mov64 r2, 0x37
06f018: lddw r4, 0x122210 ; rodata b'\x00\x00\x00\x00(\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \xac\x00\x00\x00\x00\x00\x001\xc1\x11\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00 \x9b\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00'
06f028: lddw r5, 0x122230 ; rodata b'\x00\x00\x00\x001\xc1\x11\x00T\x00\x00\x00\x00\x00\x00\x00\xff\t\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00 \x9b\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00`\x86\x00\x00\x00\x00\x00\x00\xd0\xc0\x11\x00\r\x00\x00\x00\x00\x00\x00\x00\xa1\x00\x00'
06f038: call 0x147eb ; call 0x112f98
06f040: ldxdw r1, [r10 - 0x50]
06f048: stxdw [r10 - 0xd0], r1
06f050: ldxdw r1, [r10 - 0x58]
06f058: stxdw [r10 - 0xd8], r1
06f060: ldxdw r1, [r10 - 0x60]
06f068: stxdw [r10 - 0xe0], r1
06f070: ldxdw r1, [r10 - 0x78]
06f078: stxdw [r10 - 0xf8], r1
06f080: ldxdw r1, [r10 - 0x70]
06f088: stxdw [r10 - 0xf0], r1
06f090: ldxdw r1, [r10 - 0x68]
06f098: stxdw [r10 - 0xe8], r1
06f0a0: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06f0b0: stxdw [r10 - 0x110], r1
06f0b8: stw [r10 - 0x80], 0x178e
06f0c0: stb [r10 - 0xc8], 0x2
06f0c8: stw [r10 - 0x100], 0x139
06f0d0: stdw [r10 - 0x108], 0x31
06f0d8: stdw [r10 - 0x118], 0x0
06f0e0: mov64 r1, r10
06f0e8: add64 r1, -0x128
06f0f0: mov64 r2, r10
06f0f8: add64 r2, -0x118
06f100: call 0x127d6 ; call 0x102fb8
06f108: ldxdw r3, [r10 - 0x120]
06f110: ldxdw r2, [r10 - 0x128]
06f118: mov64 r1, r10
06f120: add64 r1, -0x138
06f128: mov64 r4, r9
06f130: mov64 r5, r7
06f138: call -0xdbc7 ; call 0x1308
06f140: ldxdw r2, [r10 - 0x130]
06f148: ldxdw r9, [r10 - 0x138]
06f150: jeq r9, 0x2, -0x2b2 ; branch 0x6dbc8
06f158: ldxdw r1, [r10 - 0x248]
06f160: stxdw [r1 + 0x8], r2
06f168: stxdw [r1 + 0x0], r9
06f170: exit
06f178: ldxdw r1, [r10 - 0x50]
06f180: stxdw [r10 - 0xd0], r1
06f188: ldxdw r1, [r10 - 0x58]
06f190: stxdw [r10 - 0xd8], r1
06f198: ldxdw r1, [r10 - 0x60]
06f1a0: stxdw [r10 - 0xe0], r1
06f1a8: ldxdw r1, [r10 - 0x78]
06f1b0: stxdw [r10 - 0xf8], r1
06f1b8: ldxdw r1, [r10 - 0x70]
06f1c0: stxdw [r10 - 0xf0], r1
06f1c8: ldxdw r1, [r10 - 0x68]
06f1d0: stxdw [r10 - 0xe8], r1
06f1d8: lddw r1, 0x11cf5e ; rodata b'programs/pump-amm/src/state/volume_accumulator.rsUnexpected overflowcurrent'
06f1e8: stxdw [r10 - 0x110], r1
06f1f0: stw [r10 - 0x80], 0x1792
06f1f8: stb [r10 - 0xc8], 0x2
06f200: stw [r10 - 0x100], 0x160
06f208: stdw [r10 - 0x108], 0x31
06f210: stdw [r10 - 0x118], 0x0
06f218: mov64 r1, r10
06f220: add64 r1, -0x1b8
06f228: mov64 r2, r10
06f230: add64 r2, -0x118
06f238: call 0x127af ; call 0x102fb8
06f240: ldxdw r3, [r10 - 0x1b0]
06f248: ldxdw r2, [r10 - 0x1b8]
06f250: mov64 r1, r10
06f258: add64 r1, -0x1c8
06f260: mov64 r4, r6
06f268: mov64 r5, r9
06f270: call -0xdd40 ; call 0x878
06f278: ldxdw r2, [r10 - 0x1c0]
06f280: ldxdw r9, [r10 - 0x1c8]
06f288: jeq r9, 0x2, -0x2d9 ; branch 0x6dbc8
06f290: ja -0x28 ; branch 0x6f158
06f298: mov64 r2, 0x1e
06f2a0: lddw r3, 0x122650 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x0f\x01\x00\x00\r\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x1d\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00,\x01\x00\x00\r\x00\x00\x00\x00\x00\x00'
06f2b0: call 0x14712 ; call 0x112b48
06f2b8: mov64 r1, r7
06f2c0: mov64 r2, 0x1e
06f2c8: lddw r3, 0x122680 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00,\x01\x00\x00\r\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\\\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00g\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00'
06f2d8: call 0x1470d ; call 0x112b48
06f2e0: mov64 r1, r9
06f2e8: mov64 r2, 0x1e
06f2f0: lddw r3, 0x1226b0 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00g\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00S\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00N\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00'
06f300: call 0x14708 ; call 0x112b48
06f308: lddw r1, 0x11cfa2 ; rodata b'current_timestamp should be bigger than start_timeend_time should be bigger'
06f318: mov64 r2, 0x32
06f320: lddw r3, 0x122668 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x1d\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00,\x01\x00\x00\r\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\\\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00'
06f330: call 0x1466e ; call 0x1126a8
06f338: lddw r1, 0x11cf8f ; rodata b'Unexpected overflowcurrent_timestamp should be bigger than start_timeend_ti'
06f348: mov64 r2, 0x13
06f350: lddw r3, 0x1226e0 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00N\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x83\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x87\x01\x00\x00+\x00\x00\x00\x00\x00\x00'
06f360: call 0x14668 ; call 0x1126a8
06f368: lddw r1, 0x11cf8f ; rodata b'Unexpected overflowcurrent_timestamp should be bigger than start_timeend_ti'
06f378: mov64 r2, 0x13
06f380: lddw r3, 0x1226c8 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00S\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00N\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\x83\x01\x00\x00\x0e\x00\x00\x00\x00\x00\x00'
06f390: call 0x14662 ; call 0x1126a8
06f398: lddw r1, 0x11cfa2 ; rodata b'current_timestamp should be bigger than start_timeend_time should be bigger'
06f3a8: mov64 r2, 0x32
06f3b0: lddw r3, 0x122698 ; rodata b'\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00\\\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00g\x01\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00^\xcf\x11\x001\x00\x00\x00\x00\x00\x00\x00S\x01\x00\x00\x12\x00\x00\x00\x00\x00\x00'
06f3c0: call 0x1465c ; call 0x1126a8
