use anchor_lang::prelude::*;
use crate::PumpAmmError;
use super::GlobalConfig;

impl GlobalConfig {
    pub(crate) fn set_lp_fee_basis_points(&mut self, fee: u64) -> Result<()> {
        require_gte!(1000u64, fee, PumpAmmError::FeeBasisPointsExceedsMaximum);
        self.lp_fee_basis_points = fee;
        Ok(())
    }

    pub(crate) fn set_protocol_fee_basis_points(&mut self, fee: u64) -> Result<()> {
        require_gte!(1000u64, fee, PumpAmmError::FeeBasisPointsExceedsMaximum);
        self.protocol_fee_basis_points = fee;
        Ok(())
    }

    pub(crate) fn set_coin_creator_fee_basis_points(&mut self, fee: u64) -> Result<()> {
        require_gte!(1000u64, fee, PumpAmmError::FeeBasisPointsExceedsMaximum);
        self.coin_creator_fee_basis_points = fee;
        Ok(())
    }

    pub(crate) fn set_protocol_fee_recipients(&mut self, recipients: [Pubkey; 8]) -> Result<()> {
        require!(recipients.iter().all(|key| *key != Pubkey::default()),
            PumpAmmError::AllProtocolFeeRecipientsShouldBeNonZero);
        require!(recipients.windows(2).all(|pair| pair[0] < pair[1]),
            PumpAmmError::UnsortedNotUniqueProtocolFeeRecipients);
        self.protocol_fee_recipients = recipients;
        Ok(())
    }
}

// Reconstructed source spacer: measured panic Locations; not historical source.
























































































































































































































































































































































impl GlobalConfig {
    // Shared legacy swap split; explicit reconstructed source coordinates.
    pub fn split_buyback(&self, protocol_fee: u64, is_mayhem_mode: bool) -> (u64, u64) {
        if is_mayhem_mode {
            return (0, protocol_fee);
        }
        let buyback_fee = u64::try_from(
            (self.buyback_basis_points as u128) * (protocol_fee as u128) / 10000,
        )
                                           .expect("buyback fee is at most protocol_fee");
        let net_protocol = protocol_fee
            .checked_sub(buyback_fee)
            .expect("buyback_fee never exceeds protocol_fee");
        (buyback_fee, net_protocol)
    }
}
