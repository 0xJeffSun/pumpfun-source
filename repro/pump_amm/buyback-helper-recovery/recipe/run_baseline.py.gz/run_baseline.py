from pathlib import Path
import json,subprocess,hashlib,sys,importlib.util
P=Path(__file__).resolve().parent;D=P/'build-root';R=Path('/Users/shawwalters/.codex/worktrees/relay-canonical-exact/pumpfun-source');B=R/'repro/pump_amm/owner6048-v144'
sys.dont_write_bytecode=True
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=json.loads((D/'env.json').read_text());allowed=['HOME','RUSTUP_HOME','CARGO_HOME','CARGO_NET_OFFLINE','PYTHONDONTWRITEBYTECODE','PATH'];env={k:env[k] for k in allowed};env.update(LANG='en_US.UTF-8',TMPDIR='/tmp');(D/'env.json').write_text(json.dumps(env,indent=2)+'\n')
label=sys.argv[1] if len(sys.argv)>1 else 'baseline';out=D/(label+'-build');assert not out.exists()
if label=='probe-location':env['RUSTC_WRAPPER']=str(D/'root_remap.py')
cmd=[sys.executable,'-B',str(D/'source/scripts/build_partial_candidate.py'),'--manifest',str(D/'source/programs/pump-amm/Cargo.toml'),'--program','pump_amm','--artifact-name','pump_amm_recovered.so','--tools-version','v1.44','--extra-input',str(D/'source/programs/pump-amm/vendor/solana-pubkey'),'--output',str(out)]
(D/(label+'-launch.json')).write_text(json.dumps({'command':cmd,'environment':env},indent=2)+'\n')
with (D/(label+'.stdout')).open('wb') as so,(D/(label+'.stderr')).open('wb') as se: r=subprocess.run(cmd,cwd=D/'source',env=env,stdout=so,stderr=se)
result={'returncode':r.returncode,'candidate_equal':False,'symbols_equal':False}
spec=importlib.util.spec_from_file_location('backend',B/'build-plan/backend_gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
logs=[D/(label+'.stdout'),D/(label+'.stderr')]
if (out/'build.log').exists():logs.append(out/'build.log')
result['backend']=m.check(logs)
if r.returncode==0 and result['backend']['diagnostic_gate_passed']:
 for name,path,expected in [('candidate',out/'artifacts/pump_amm_recovered.so','09bee0dfd751dc6ae0240bbac262933c6bda6e0c94aa643f82c57f2956c3a117'),('symbols',out/'target/sbf-solana-solana/release/pump_amm_recovered.so','f6e504317ba774325c0ba682e2529c7f18d1ae645a0d7aa239de557729dd0cb4')]:
  result[name+'_sha256']=H(path);result[name+'_equal']=H(path)==expected
(D/(label+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(0 if (result['candidate_equal'] and result['symbols_equal']) or (label.startswith('probe') and r.returncode==0 and result['backend']['diagnostic_gate_passed']) else 1)
