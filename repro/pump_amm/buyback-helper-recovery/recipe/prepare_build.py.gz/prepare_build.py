from pathlib import Path
import json,hashlib,os,shutil,subprocess
P=Path(__file__).resolve().parent
R=Path('/Users/shawwalters/.codex/worktrees/relay-canonical-exact/pumpfun-source')
B=R/'repro/pump_amm/owner6048-v144'; D=P/'build-root'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tools=json.loads((B/'build-plan/tools.json').read_text())
for f,e in tools['tools'].items():assert H(Path(f))==e['sha256'],f
assert not D.exists(); D.mkdir()
def clone(a,b):
 b.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['/bin/cp','-cR',str(a.resolve()),str(b)],check=True)
home=D/'home';home.mkdir();bin=D/'bin';bin.mkdir()
for version in ['v1.44','v1.52']:
 clone(Path('/Users/shawwalters/.cache/solana')/version/'platform-tools',home/'.cache/solana'/version/'platform-tools')
clone(Path('/Users/shawwalters/.cache/solana/v2.3.2/criterion'),home/'.cache/solana/v2.3.2/criterion')
clone(Path('/Users/shawwalters/.rustup/toolchains/stable-aarch64-apple-darwin'),home/'.rustup/toolchains/stable-aarch64-apple-darwin')
(home/'.rustup/settings.toml').write_text('version = "12"\ndefault_toolchain = "stable-aarch64-apple-darwin"\nprofile = "minimal"\n')
for name in ['rustup','cargo']:shutil.copy2('/Users/shawwalters/.cargo/bin/rustup',bin/name)
shutil.copy2('/Users/shawwalters/.local/share/solana/install/releases/2.1.21/solana-release/bin/cargo-build-sbf',bin/'cargo-build-sbf')
sdk=Path('/Users/shawwalters/.local/share/solana/install/releases/2.1.21/solana-release/bin/sdk/sbf')
shutil.copytree(sdk,bin/'sdk/sbf',ignore=shutil.ignore_patterns('dependencies'))
assert {str(p.relative_to(bin/'sdk/sbf')):H(p) for p in (bin/'sdk/sbf').rglob('*') if p.is_file()}==tools['sdk_source']
clone(B/'build-plan/registry',D/'cargo-home/registry')
source=D/'source';shutil.copytree(P/'baseline',source)
shutil.copytree(B/'build-plan/source/scripts',source/'scripts')
e=source/'evidence/original/pump_amm/deployed.so';e.parent.mkdir(parents=True);shutil.copy2(R/'evidence/original/pump_amm/deployed.so',e)
assert {f:H(source/f) for f in json.loads((B/'main/build-launch.json').read_text())['source30']}==json.loads((B/'main/build-launch.json').read_text())['source30']
env=dict(LANG='en_US.UTF-8',TMPDIR='/tmp',HOME=str(home),RUSTUP_HOME=str(home/'.rustup'),CARGO_HOME=str(D/'cargo-home'),CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1',PATH=str(bin)+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET']:env.pop(key,None)
(D/'env.json').write_text(json.dumps(env,indent=2)+'\n')
# Only non-secret controlled fields are retained for review.
(D/'environment-controls.json').write_text(json.dumps({k:env[k] for k in ['HOME','RUSTUP_HOME','CARGO_HOME','CARGO_NET_OFFLINE','PATH']},indent=2)+'\n')
(D/'env.json').chmod(0o600)
print('Prepared private copies. No build executed.')
