#!/opt/homebrew/opt/python@3.14/bin/python3.14
import os,sys,json
from pathlib import Path
args=sys.argv[2:]
if '--crate-name' in args and args[args.index('--crate-name')+1]=='pump_amm_recovered':
    args.append('--remap-path-prefix=src/=programs/pump-amm/src/')
    Path(__file__).with_name('root-remap-invocation.json').write_text(json.dumps({'compiler':sys.argv[1],'arguments':args},indent=2)+'\n')
os.execv(sys.argv[1],[sys.argv[1],*args])
