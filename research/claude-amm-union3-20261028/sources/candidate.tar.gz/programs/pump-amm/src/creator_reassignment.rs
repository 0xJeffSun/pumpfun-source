use crate::*;
use anchor_lang::Discriminator;
use anchor_spl::metadata::MetadataAccount;
pub const FEES_PROGRAM: Pubkey = anchor_lang::solana_program::pubkey!("pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ");
pub use crate::pump_fees::types::{ConfigStatus, Shareholder};
pub use crate::pump_fees::accounts::SharingConfig;
pub use crate::pump::accounts::BondingCurve;
#[event_cpi]
#[derive(Accounts)]
pub struct MigratePoolCoinCreator<'info>{
 #[account(mut,seeds=[b"pool",pool.index.to_le_bytes().as_ref(),pool.creator.as_ref(),pool.base_mint.as_ref(),pool.quote_mint.as_ref()],bump,constraint=pool.creator==crate::utils::pool_authority(&pool.base_mint) @ PumpAmmError::OnlyCanonicalPumpPoolsCanHaveCoinCreator)]pub pool:Account<'info,Pool>,
 #[account(seeds=[b"sharing-config",pool.base_mint.as_ref()],bump,seeds::program=FEES_PROGRAM,constraint=sharing_config.mint==pool.base_mint @ PumpAmmError::InvalidSharingConfigBaseMint,constraint=sharing_config.admin==pool.coin_creator @ PumpAmmError::InvalidSharingConfigCoinCreator)]pub sharing_config:Account<'info,SharingConfig>,
}
pub use crate::instructions::coin_creator::migrate_pool_coin_creator::migrate;






#[event_cpi]
#[derive(Accounts)]
pub struct SetCoinCreator<'info>{
 #[account(mut)]pub pool:Account<'info,Pool>,
 #[account(seeds=[b"metadata",anchor_spl::metadata::ID.as_ref(),pool.base_mint.as_ref()],bump,seeds::program=anchor_spl::metadata::ID)]pub metadata:Account<'info,MetadataAccount>,
 #[account(seeds=[b"bonding-curve",pool.base_mint.as_ref()],bump,seeds::program=trade::PUMP)]pub bonding_curve:Account<'info,BondingCurve>,
}
pub fn set(ctx:Context<SetCoinCreator>)->Result<()>{
 let pool=&mut ctx.accounts.pool;
 let authority=Pubkey::find_program_address(&[b"pool-authority",pool.base_mint.as_ref()],&trade::PUMP).0;
 require_keys_eq!(pool.creator,authority,PumpAmmError::OnlyCanonicalPumpPoolsCanHaveCoinCreator);
 if pool.coin_creator!=Pubkey::default(){msg!("Pool has coin_creator already set");return Ok(())}
 if let Some(creators)=&ctx.accounts.metadata.creators{
  pool.coin_creator=creators[0].address;
  let event=SetMetaplexCoinCreatorEvent{timestamp:Clock::get()?.unix_timestamp,base_mint:pool.base_mint,pool:pool.key(),metadata:ctx.accounts.metadata.key(),coin_creator:pool.coin_creator};emit!(event.clone());emit_cpi!(event);
 }else{
  pool.coin_creator=ctx.accounts.bonding_curve.creator;
  let event=SetBondingCurveCoinCreatorEvent{timestamp:Clock::get()?.unix_timestamp,base_mint:pool.base_mint,pool:pool.key(),bonding_curve:ctx.accounts.bonding_curve.key(),coin_creator:pool.coin_creator};emit!(event.clone());emit_cpi!(event);
 }Ok(())
}
#[event]#[derive(Clone)]pub struct MigratePoolCoinCreatorEvent{pub timestamp:i64,pub base_mint:Pubkey,pub pool:Pubkey,pub sharing_config:Pubkey,pub old_coin_creator:Pubkey,pub new_coin_creator:Pubkey}
#[event]#[derive(Clone)]pub struct SetMetaplexCoinCreatorEvent{pub timestamp:i64,pub base_mint:Pubkey,pub pool:Pubkey,pub metadata:Pubkey,pub coin_creator:Pubkey}
#[event]#[derive(Clone)]pub struct SetBondingCurveCoinCreatorEvent{pub timestamp:i64,pub base_mint:Pubkey,pub pool:Pubkey,pub bonding_curve:Pubkey,pub coin_creator:Pubkey}

