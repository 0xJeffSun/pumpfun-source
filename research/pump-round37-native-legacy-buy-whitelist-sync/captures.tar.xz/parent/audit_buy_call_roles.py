from pathlib import Path
from collections import Counter,defaultdict
import importlib.util,hashlib,json
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('iv',W/'inventory.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);a=(W/'reference/original.so').read_bytes();b=(W/'builds/specialized/unstripped.so').read_bytes();ss=[m.sections(x)for x in[a,b]];iv=json.loads((W/'specialized-inventory.json').read_text());af={r['start']:r for r in iv['windows']};bf={r['start']:r for r in m.functions(b)}
sha=lambda b:hashlib.sha256(b).hexdigest()
def ident(im,sec,row):return row['bytes'],sha(m.normalize(m.body(im,sec,row['start'],row['bytes']),row['start'],sec)[0])
names=defaultdict(list)
for r in bf.values():names[ident(b,ss[1],r)].extend(r['symbols'])
def calls(im,sec,row,rows):
 raw=m.body(im,sec,row['start'],row['bytes']);n,ops=m.normalize(raw,row['start'],sec);out=[]
 for op in ops:
  if op['kind']!='direct-call':continue
  t=rows[op['target']];key=ident(im,sec,t);out.append(dict(offset=op['offset'],target=t['start'],bytes=t['bytes'],shape=key[1],names=names.get(key,[])))
 return out
out=[]
for orig,cand in [(1359928,1328296),(1373408,1344144)]:
 x=calls(a,ss[0],af[orig],af);y=calls(b,ss[1],bf[cand],bf);cx=Counter((r['bytes'],r['shape'])for r in x);cy=Counter((r['bytes'],r['shape'])for r in y);new=[];lost=[]
 for key,count in(cy-cx).items():new.append(dict(bytes=key[0],shape=key[1],count=count,names=names[key]))
 for key,count in(cx-cy).items():lost.append(dict(bytes=key[0],shape=key[1],count=count,names=names[key]))
 out.append(dict(original=orig,candidate=cand,original_bytes=af[orig]['bytes'],candidate_bytes=bf[cand]['bytes'],original_calls=x,candidate_calls=y,extra_candidate=new,missing_candidate=lost))
result=dict(original_sha256=sha(a),candidate_symbols_sha256=sha(b),handlers=out,scope='Entry-wrapper-bound direct call roles via complete normalized callee identities. Ambiguous names remain arrays; unmatched identities remain unnamed. This is static diagnostic, not path execution or body identity.')
(W/'buy-call-role-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for r in out:
 print('HANDLER',r['original'],r['original_bytes'],r['candidate_bytes'],'CALLS',len(r['original_calls']),len(r['candidate_calls']))
 for key in ['extra_candidate','missing_candidate']:
  print(key,[(x['bytes'],x['count'],x['names'])for x in r[key]])
