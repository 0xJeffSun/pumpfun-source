"""Read-only independent checks of four saved whitelist diagnostics, no VM runs."""
from pathlib import Path
import base64,hashlib,json,struct
from solders.transaction import Transaction
W=Path(__file__).resolve().parent
j=json.loads((W/'whitelist-sync-diagnostic.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert j['candidate_sha256']=='373ca1f993d10dfcf3c8db610db17b0ff8228e5c6ec763e0cb6d8db944ab1bca'
assert j['pairs']==4 and j['signed_records']==8 and j['frozen_unchanged']
for p,v in j['frozen_before'].items():assert sha(Path(p).read_bytes())==v
rows=[];signed=0
for r in j['cases']:
 actual=[k for k in ['error','accounts','events','inner','return_data']if r['original'][k]!=r['candidate'][k]]
 assert actual==r['different_fields']
 mode=bool(r['case']['curve_bytes'][0][1])
 assert actual==(['accounts','events','inner']if mode else [])
 assert r['original']['error']is None and r['candidate']['error']is None
 details=[]
 for side in ['original','candidate']:
  tx=Transaction.from_bytes(base64.b64decode(r[side]['transaction_base64']))
  assert all(tx.verify_with_results());signed+=1
  signer=bytes(tx.message.account_keys[0])
  # Verify the configured whitelist bytes from the actual pre-execution snapshot.
  matches=[a for a in r[side]['before'].values()if a and a['data']and len(base64.b64decode(a['data']))>=483 and base64.b64decode(a['data'])[451:483]==signer]
  assert len(matches)==1
 if mode:
  keys=[k for k,a in r['original']['accounts'].items()if a!=r['candidate']['accounts'][k]]
  assert len(keys)==1
  a,b=[r[s]['accounts'][keys[0]]for s in ['original','candidate']]
  assert all(a[k]==b[k]for k in ['lamports','owner','executable'])
  x,y=[base64.b64decode(z['data'])for z in [a,b]]
  assert len(x)==len(y) and x[:16]==y[:16]and x[24:]==y[24:]
  details=dict(account=keys[0],original_virtual_quote=struct.unpack_from('<Q',x,16)[0],candidate_virtual_quote=struct.unpack_from('<Q',y,16)[0])
 rows.append(dict(name=r['case']['name'],different_fields=actual,state=details))
header=(W/'runtime-root/evidence/original/pump/programdata-account.bin').read_bytes()[:45]
known={j['candidate_sha256']:W/'builds/specialized/candidate.so',sha((W/'reference/original.so').read_bytes()):W/'reference/original.so'}
assert {r['elf_sha256']for r in j['loader_loads']}==set(known)
for r in j['loader_loads']:
 b=known[r['elf_sha256']].read_bytes()
 assert r['elf_prefix_unchanged']and r['zero_allocation_tail']
 assert sha(header+b+bytes(r['programdata_bytes']-45-len(b)))==r['programdata_sha256']
result=dict(pairs=4,signed_records=signed,success=4,agreeing_pairs=2,differing_pairs=2,loader_images=len(j['loader_loads']),cases=rows,scope=__doc__+' Finite synthetic cases on published PR359 only; separate from its original 284 pairs. No raw compute/log equality or generalized callback/path coverage.')
(W/'whitelist-sync-checked.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
