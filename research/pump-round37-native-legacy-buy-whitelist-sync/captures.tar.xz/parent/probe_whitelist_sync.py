"""Four new, normally signed fixture cases with the signer configured in Global's whitelist.

Uses only the frozen harness's existing account_mutations interface. No signer,
authority, comparison, loader, or program checks are bypassed.
"""
from pathlib import Path
import base64,hashlib,json,sys
from solders.transaction import Transaction
W=Path(__file__).resolve().parent;R=W/'runtime-root'
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen={str(p):sha(p.read_bytes())for p in sorted(R.rglob('*'))if p.is_file()and p.suffix in ['.py','.json','.so','.bin']}
sys.path.insert(0,str(R/'scripts'))
import pump_captured_loader as loader
loader.install()
import pump_legacy_buy_differential as h
candidate=W/'builds/specialized/candidate.so'
assert sha(candidate.read_bytes())=='373ca1f993d10dfcf3c8db610db17b0ff8228e5c6ec763e0cb6d8db944ab1bca'
assert sha(Path(h.__file__).read_bytes())==json.loads((W/'mayhem-sync-boundary-diagnostic.json').read_text())['frozen_harness_sha256']
# Serialized Global: discriminator(8), bool(1), two keys(64), five u64(40),
# key(32), bool(1), two u64(16), seven keys(224), two keys(64), bool(1).
whitelist_offset=8+1+64+40+32+1+16+224+64+1
assert whitelist_offset==451
rows=[]
for kind in ['buy','buy_exact_sol_in']:
 for mode in [False,True]:
  c=dict(name=f'whitelisted-sync-{kind}-{mode}',kind=kind,amount=10**9,minimum=10**12 if kind=='buy'else 1,reserved=mode,curve_bytes=[[81,int(mode)]],curve_u64=[[32,100000000]],account_mutations={'global':{'bytes':[[whitelist_offset+i,b]for i,b in enumerate(bytes(h.USER.pubkey()))]}})
  a=h.run(c);b=h.run(c,candidate)
  rows.append(dict(case=c,original=a,candidate=b,different_fields=[k for k in ['error','accounts','events','inner','return_data']if a[k]!=b[k]]))
result=dict(scope=__doc__,candidate_sha256=sha(candidate.read_bytes()),pairs=len(rows),signed_records=2*len(rows),cases=rows,loader_loads=loader.LOADS,frozen_before=frozen,frozen_unchanged=all(sha(Path(p).read_bytes())==v for p,v in frozen.items()))
(W/'whitelist-sync-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['frozen_unchanged']
for r in rows:
 for side in ['original','candidate']:assert all(Transaction.from_bytes(base64.b64decode(r[side]['transaction_base64'])).verify_with_results())
print(json.dumps([(r['case']['name'],r['original']['error'],r['candidate']['error'],r['different_fields'])for r in rows]))
