from pathlib import Path
import importlib.util,json,struct
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('iv',W/'inventory.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);im=(W/'reference/original.so').read_bytes();ss=m.sections(im);reports=[]
for start,size,call in [(1359928,10880,5808),(1373408,13224,8320)]:
 raw=m.body(im,ss,start,size);inst={};pos=0
 while pos<size:
  item=struct.unpack_from('<BBhi',raw,pos);inst[pos]=item;pos+=16 if item[0]==0x18 else 8
 nodes=set(inst);edges={};pred={n:set()for n in nodes}
 for n,(op,reg,off,imm)in inst.items():
  nxt=n+(16 if op==0x18 else 8)
  if op==0x95:targets=[]
  elif op==0x05:targets=[n+8+off*8]
  elif op&7 in [5,6]and op not in [0x85,0x8d]:targets=[nxt,n+8+off*8]
  else:targets=[nxt]if nxt<size else[]
  assert all(t in nodes for t in targets);edges[n]=targets
  for t in targets:pred[t].add(n)
 reach={0};q=[0]
 while q:
  for t in edges[q.pop()]:
   if t not in reach:reach.add(t);q.append(t)
 assert call in reach;dom={n:({0}if n==0 else set(reach))for n in reach};change=True
 while change:
  change=False
  for n in sorted(reach-{0}):
   ins=[dom[p]for p in pred[n]if p in reach];d={n}|set.intersection(*ins)
   if d!=dom[n]:dom[n]=d;change=True
 guards=[n for n in sorted(dom[call])if len(edges[n])==2];chosen=guards[-4:];details=[]
 for guard in chosen:
  seq=[dict(offset=o,opcode=hex(inst[o][0]),dst=inst[o][1]&15,src=inst[o][1]>>4,displacement=inst[o][2],immediate=inst[o][3])for o in sorted(inst)if guard-48<=o<=guard+8];details.append(dict(branch=guard,successors=edges[guard],instructions=seq))
 reports.append(dict(original_start=start,call_offset=call,reachable_instructions=len(reach),conditional_dominators=guards,last_guards=details))
(W/'sync-call-guard-audit.json').write_text(json.dumps(dict(handlers=reports,scope='Static conservative intraprocedural CFG and dominators; calls modeled returning. Not concrete VM paths or alias/value provenance proof.'),indent=2)+'\n');print(json.dumps(reports,indent=2))
