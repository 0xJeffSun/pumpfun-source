"""Full reload body and finite immediate-callee comparison, unchanged normalizer."""
from pathlib import Path
import hashlib,importlib.util,json
D=Path(__file__).resolve().parent
W=D.parent/'pump-legacy-specialization-work'
s=importlib.util.spec_from_file_location('iv',W/'inventory.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
a=(W/'reference/original.so').read_bytes();b=(D/'builds/whitelist-sync-v2/unstripped.so').read_bytes()
ss=[m.sections(x)for x in [a,b]]
parent=json.loads((W/'specialized-inventory.json').read_text());new=json.loads((D/'inventory.json').read_text())
matched=lambda j:{r['start']for r in j['windows']if r['candidates']}
raw=lambda j:{r['start']for r in j['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])}
assert matched(parent)<=matched(new)and raw(parent)<=raw(new)
assert matched(new)-matched(parent)=={30864}
assert(new['injective_normalized'],new['membership_normalized'],new['injective_raw'])==(755,755,131)
original={r['start']:r for r in new['windows']};candidate={r['start']:r for r in m.functions(b)}
r=original[30864];assert r['bytes']==688 and len(r['candidates'])==1
t=r['candidates'][0];x=m.body(a,ss[0],30864,688);y=m.body(b,ss[1],t['start'],688)
nx,ox=m.normalize(x,30864,ss[0]);ny,oy=m.normalize(y,t['start'],ss[1]);assert nx==ny
calls=[]
for p,q in zip([r for r in ox if r['kind']=='direct-call'],[r for r in oy if r['kind']=='direct-call'],strict=True):
 assert p['offset']==q['offset']
 u,v=original[p['target']],candidate[q['target']]
 un=m.normalize(m.body(a,ss[0],u['start'],u['bytes']),u['start'],ss[0])[0]
 vn=m.normalize(m.body(b,ss[1],v['start'],v['bytes']),v['start'],ss[1])[0]
 calls.append(dict(offset=p['offset'],original=u['start'],candidate=v['start'],original_bytes=u['bytes'],candidate_bytes=v['bytes'],equal=un==vn))
# Actual unmasked one-byte mutations; raw captures are never edited.
mutations=[]
for index in [0,1,2,4]:
 z=bytearray(y);z[index]^=1;assert m.normalize(bytes(z),t['start'],ss[1])[0]!=nx;mutations.append(index)
result=dict(original_sha256=hashlib.sha256(a).hexdigest(),candidate_symbols_sha256=hashlib.sha256(b).hexdigest(),normalized=755,raw=131,gain=[30864],old_normalized_and_raw_sets_held=True,original=30864,candidate=t['start'],bytes=688,body_equal=True,immediate_calls=calls,unmasked_mutation_byte_offsets=mutations,scope=__doc__+' Original/new source interpretation is inferred. Readonly-data, indirect, transitive, complete business-body and whole-file identities are not proved.')
(D/'reload-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
