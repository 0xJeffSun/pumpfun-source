"""Offline, finite source/build/body and independent signed-record checks; no VM/compiler fallback."""
from pathlib import Path
import base64,hashlib,importlib.util,json
from solders.transaction import Transaction
if not __debug__:raise RuntimeError('Assertions required')
D=Path(__file__).resolve().parent;W=D/'parent'
if not W.exists():W=D.parent/'pump-legacy-specialization-work'
R=D/'runtime-root'if(D/'runtime-root').exists()else W/'runtime-root'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('iv',W/'inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
parent=json.loads((W/'specialized-inventory.json').read_text());new=json.loads((D/'inventory.json').read_text())
matched=lambda j:{r['start']for r in j['windows']if r['candidates']}
raw=lambda j:{r['start']for r in j['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])}
assert matched(parent)<=matched(new)and raw(parent)<=raw(new)
assert matched(new)-matched(parent)=={30864}
assert(new['injective_normalized'],new['membership_normalized'],new['injective_raw'])==(755,755,131)
assert m.inventory(D/'builds/whitelist-sync-v2/unstripped.so')==new
assert m.inventory(W/'builds/specialized/unstripped.so')==parent
sources=lambda p:{str(n.relative_to(p)):sha(n)for n in p.rglob('*')if n.is_file()}
before=sources(W/'source');after=sources(D/'source');assert len(before)==len(after)==58 and before.keys()==after.keys()
changed=sorted(n for n in before if before[n]!=after[n]);assert changed==['programs/pump/src/buy.rs','programs/pump/src/mayhem_virtual_params.rs']
for n in changed:assert(W/'source'/n).read_bytes().count(b'\n')==(D/'source'/n).read_bytes().count(b'\n')
for label in ['whitelist-sync-v2','repeat']:
 r=json.loads((D/'builds'/label/'result.json').read_text());launch=json.loads((D/'builds'/label/'launch.json').read_text())
 assert r['exit_code']==0 and r['root_invocations']==1 and all(r[k]is True for k in ['source_unchanged','primary_unchanged','sdk_unchanged'])
 assert launch['workspace_inputs']==after and launch['primary_source_inputs']==sources(D/'primary')
 assert len(launch['sdk_inputs'])==2775
 for kind in ['unstripped','candidate']:
  p=D/'builds'/label/(kind+'.so');assert sha(p)==r[kind+'_sha256'];assert p.read_bytes()==(D/'builds/whitelist-sync-v2'/(kind+'.so')).read_bytes()
# Bind runtime scripts/data to the already authenticated, unchanged public pins.
for name in ['runtime-input-pins.json','runtime-data-pins.json']:
 for n,h in json.loads((W/name).read_text())['files'].items():assert sha(R/n)==h
header=(R/'evidence/original/pump/programdata-account.bin').read_bytes()[:45]
original=W/'reference/original.so';candidate=D/'builds/whitelist-sync-v2/candidate.so'
known={sha(original):original,sha(candidate):candidate}
def check_loads(loads,images):
 assert {r['elf_sha256']for r in loads}==set(images)
 for r in loads:
  b=images[r['elf_sha256']].read_bytes();assert r['elf_prefix_unchanged']and r['zero_allocation_tail']
  assert r['program_sha256']==sha(R/'evidence/original/pump/program-account.bin')
  assert hashlib.sha256(header+b+bytes(r['programdata_bytes']-45-len(b))).hexdigest()==r['programdata_sha256']
def check_record(side):
 tx=Transaction.from_bytes(base64.b64decode(side['transaction_base64']));assert all(tx.verify_with_results())and side['signatures_verified']is True
 return tx
fields=['error','accounts','events','inner','return_data']
report=json.loads((D/'runtime-report.json').read_text());assert report['candidate_sha256']==sha(candidate)and report['case_count']==284 and not report['mismatches'];success=0;signed=0
for r in report['cases']:
 assert r['match']and not r['different_fields']and all(r['original'][k]==r['candidate'][k]for k in fields)
 success+=r['original']['error']is None
 for side in ['original','candidate']:check_record(r[side]);signed+=1
loads=json.loads((D/'runtime-loader.json').read_text())['loads'];check_loads(loads,known)
focused=json.loads((D/'whitelist-sync-diagnostic.json').read_text());assert focused['candidate_sha256']==sha(candidate)and focused['pairs']==4
old=json.loads((W/'whitelist-sync-diagnostic.json').read_text());assert old['candidate_sha256']==sha(W/'builds/specialized/candidate.so')and old['pairs']==4
parent_signed=0
for capture,is_parent in [(focused,False),(old,True)]:
 for p,h in capture['frozen_before'].items():
  rel=p.split('/runtime-root/',1)[1];assert sha(R/rel)==h
 for r in capture['cases']:
  actual=[k for k in fields if r['original'][k]!=r['candidate'][k]];assert actual==r['different_fields']
  mode=bool(r['case']['curve_bytes'][0][1]);assert actual==(['accounts','events','inner']if is_parent and mode else [])
  assert r['original']['error']is None and r['candidate']['error']is None
  for side in ['original','candidate']:
   tx=check_record(r[side]);signer=bytes(tx.message.account_keys[0]);assert sum(a is not None and a['data']is not None and base64.b64decode(a['data'])[451:483]==signer for a in r[side]['before'].values())==1
   if is_parent:parent_signed+=1
   else:signed+=1
 check_loads(capture['loader_loads'],{sha(original):original,sha(W/'builds/specialized/candidate.so'):W/'builds/specialized/candidate.so'}if is_parent else known)
success+=4
# Recompute all five same-offset immediate callee identities of the recovered body.
inspection=json.loads((D/'reload-inspection.json').read_text());row=next(r for r in new['windows']if r['start']==30864);assert row['bytes']==688 and len(row['candidates'])==1
ar={r['start']:r for r in new['windows']};bi=(D/'builds/whitelist-sync-v2/unstripped.so').read_bytes();ai=original.read_bytes();br={r['start']:r for r in m.functions(bi)};sa,sb=m.sections(ai),m.sections(bi)
t=row['candidates'][0]['start'];ax,ao=m.normalize(m.body(ai,sa,30864,688),30864,sa);bx,bo=m.normalize(m.body(bi,sb,t,688),t,sb);assert ax==bx
ac=[x for x in ao if x['kind']=='direct-call'];bc=[x for x in bo if x['kind']=='direct-call'];assert len(ac)==len(bc)==5
for x,y in zip(ac,bc):
 assert x['offset']==y['offset'];u,v=ar[x['target']],br[y['target']]
 assert u['bytes']==v['bytes']and m.normalize(m.body(ai,sa,u['start'],u['bytes']),u['start'],sa)[0]==m.normalize(m.body(bi,sb,v['start'],v['bytes']),v['start'],sb)[0]
result=dict(normalized=755,membership=755,raw=131,gain=[30864],old_sets_held=True,complete_repeat_equal=True,pairs=288,signed_records=signed,success=success,reject=288-success,parent_counterexample_pairs=4,parent_signed_records=parent_signed,parent_differing_pairs=2,loader_images=len(loads)+len(focused['loader_loads']),immediate_callee_checks=5,scope=__doc__+' Focused legacy-buy coverage only. No raw logs/CU, readonly/indirect/transitive, full business body or whole-file identity.')
(D/'qualification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
