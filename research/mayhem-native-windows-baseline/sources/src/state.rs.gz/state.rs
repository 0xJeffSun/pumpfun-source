use anchor_lang::prelude::*;
pub const PUMP_ID: Pubkey = pubkey!("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");









#[account]
pub struct GlobalParams {
    pub field_0: u32, // serialized 8; original object 232
    pub field_1: u32, // serialized 12; original object 236
    pub field_2: u64, // serialized 16; original object 96
    pub field_3: u64, // serialized 24; original object 104
    pub field_4: u64, // serialized 32; original object 112
    pub field_5: u64, // serialized 40; original object 120
    pub paused: bool, // serialized 48; original object 245
    pub admin: Pubkey, // serialized 49; original object 0
    pub trader: Pubkey, // serialized 81; original object 32
    pub sol_deployed: i128, // serialized 113; original object 64
    pub field_9: u64, // serialized 129; original object 128
    pub field_6: u8, // serialized 137; original object 244
    pub field_138: u64, // serialized 138; original object 136
    pub field_7: u64, // serialized 146; original object 144
    pub field_8: u64, // serialized 154; original object 152
    pub version: u32, // serialized 162; original object 240
    pub field_10: u64, // serialized 166; original object 160
    pub max_sol_per_sweep: u64, // serialized 174; original object 168
    pub field_11: u64, // serialized 182; original object 176
    pub field_12: u64, // serialized 190; original object 184
    pub field_13: u64, // serialized 198; original object 192
    pub stable_deployed: i128, // serialized 206; original object 80
    pub field_14: u64, // serialized 222; original object 200
    pub field_15: u64, // serialized 230; original object 208
    pub field_238: u64, // serialized 238; original object 216
    pub max_stable_per_sweep: u64, // serialized 246; original object 224
}

/// Serialized offsets are recovered from 0x685f0 and 0x68ce0.
/// Neutral field names avoid claiming unavailable historical semantics.
#[account]
pub struct MayhemState {
    pub field_8: u64,             // 8
    pub end_timestamp: i64,        // 16: signed Clock comparison in burn
    pub mint: Pubkey,              // 24
    pub field_56: i128,            // 56: exact width; signedness not proven here
    pub field_72: i128,            // 72: exact width; signedness not proven here
    pub flag_88: bool,             // 88: decoder accepts only 0 or 1
    pub field_89: u64,             // 89
    pub status: MayhemStatus,      // 97: decoder accepts only 0, 1 or 2
    pub burned_amount: u64,        // 98
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub enum MayhemStatus { Variant0, Variant1, Ended }

/// A separate namespace suppresses the automatic Mayhem Owner implementation.
/// The codec at 0x6dc00 writes 82 bytes including this account discriminator.
#[account("account")]
pub struct BondingCurve {
    pub virtual_token_reserves: u64,
    pub virtual_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub token_total_supply: u64,
    pub complete: bool,
    pub creator: Pubkey,
    pub is_mayhem_mode: bool,
}
impl Owner for BondingCurve { fn owner() -> Pubkey { PUMP_ID } }































































































































































































































































































































































































































































































impl MayhemState {
    pub fn validate_trade(&mut self, global_params: &crate::GlobalParams) -> Result<()> {

        require!(!global_params.paused, crate::MayhemError::TradingPaused);

        let current_time = Clock::get().unwrap().unix_timestamp;
        let last = self.field_89 as i64;
        let interval = (global_params.field_7 as i64);
        if last != 0 && interval != 0 {
          let next_time = last + interval;


            require!(current_time >= next_time, crate::MayhemError::TradeRateLimit);
        }
        self.field_89 = current_time as u64;
        Ok(())
    }
}
