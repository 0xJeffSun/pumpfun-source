from pathlib import Path
import gzip
import json
import subprocess
import sys

W=Path(__file__).resolve().parent
P=W/'mayhem-qualified-native'
for label in sys.argv[1:]:
    command=[sys.executable,'-I','-B',str(P/'build.py'),'--sdk',str(W/'mayhem-native-build/sdk'),
        '--target-sysroot',str(W/'windows-typeid-probe/linux-sysroot/rust'),'--vendor',str(W/'mayhem-native-build/vendor'),
        '--msvc','C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207',
        '--windows-sdk','C:/Program Files (x86)/Windows Kits/10','--output',str(P/label)]
    with(P/(label+'.stdout.log')).open('wb')as out,(P/(label+'.stderr.log')).open('wb')as err:
        result=subprocess.run(command,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print(label,'exit',result.returncode,flush=True)
    if (P/label/'result.json').exists():
        data=json.loads((P/label/'result.json').read_bytes())
        print(json.dumps(data.get('outputs',{'error':data.get('error')})),flush=True)
    result.check_returncode()
    for native, reference in [('symbols.so','symbols.so.gz'),('candidate-v154-strip.so','candidate.so.gz')]:
        assert (P/label/native).read_bytes()==gzip.decompress((P/'upstream/mayhem-initializer-source-origins/artifacts/recovered'/reference).read_bytes())
    print(label,'raw and stripped reference identity passed',flush=True)
