from pathlib import Path
import difflib
import gzip
import io
import json
import tarfile

W = Path(__file__).resolve().parent
P = W / 'mayhem-qualified-native'
native = W / 'pumpfun-source/research/mayhem-initializer-origins/latest'
with tarfile.open(P / 'upstream/mayhem-initializer-source-origins/source.tar.gz', 'r:gz') as archive:
    sources = {m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
out = {}
for name,data in sources.items():
    old = gzip.decompress((native / 'sources' / (name + '.gz')).read_bytes())
    if old != data:
        out[name] = dict(non_whitespace_equal=b''.join(old.split()) == b''.join(data.split()),
                         diff=''.join(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='PR248/'+name,tofile='upstream/'+name)))
(P / 'source-difference.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf8',newline='\n')
print(json.dumps(out, indent=2))
