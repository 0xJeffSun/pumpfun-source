from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import subprocess
import sys

W = Path(__file__).resolve().parent
P = W / 'mayhem-qualified-native'
OLD = W / 'mayhem-current-native/latest/corrected/build-01'
def save(path, data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
launch = json.loads((OLD / 'launch.json').read_bytes())
env = {k:os.environ[k] for k in ('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE') if k in os.environ}
env.update(launch['environment_overrides'])
sdk = W / 'mayhem-native-build/sdk'
real = sdk / 'rust/lib/rustlib/x86_64-pc-windows-msvc/bin/rust-lld.exe'
wrapper = P / 'linker.exe'
if not wrapper.exists():
    command = [env['RUSTC'],'--edition=2021','-C','opt-level=2',str(P/'linker.rs'),'-o',str(wrapper)]
    result = subprocess.run(command,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
    (P/'linker-compile.stdout.log').write_bytes(result.stdout)
    (P/'linker-compile.stderr.log').write_bytes(result.stderr)
    save(P/'linker-compile.json',dict(command=command,returncode=result.returncode,source_sha256=sha(P/'linker.rs'),compiler_sha256=sha(Path(env['RUSTC'])),wrapper_sha256=sha(wrapper) if wrapper.exists() else None))
    result.check_returncode()
records = [json.loads(p.read_bytes()) for p in (OLD/'wrapper-records').glob('*.json')]
root = [r for r in records if '--crate-name' in r['after'] and r['after'][r['after'].index('--crate-name')+1]=='mayhem_recovered']
assert len(root)==1
for label in sys.argv[1:]:
    output = P / ('probe-'+label)
    output.mkdir(exist_ok=False)
    source = output/'source/programs/mayhem'
    rows = json.loads((P/'source-inputs.json').read_bytes())['source_files']
    for row in rows:
        dest=source/row['path'];dest.parent.mkdir(parents=True,exist_ok=True)
        data=gzip.decompress((P/'sources'/(row['path']+'.gz')).read_bytes())
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        dest.write_bytes(data)
    outdir=output/'compiled';outdir.mkdir()
    temp=output/'temp';temp.mkdir()
    args=list(root[0]['after'])
    args[args.index('--out-dir')+1]=str(outdir)
    args.extend(['-C','linker='+str(wrapper)])
    selected=P/('ordered-original.ld' if label=='original-selectors' else 'ordered-native.ld')
    env.update(TEMP=str(temp),TMP=str(temp),MAYHEM_LINKER_REAL=str(real),MAYHEM_LINKER_DEFAULT=str(P/'default.ld'),
               MAYHEM_LINKER_SCRIPT=str(selected),MAYHEM_LINKER_OUTPUT=str(output/'link'))
    command=[env['RUSTC'],*args]
    save(output/'launch.json',dict(command=command,cwd=str(source),environment=env,source_inputs=rows,
         started_at=datetime.now(timezone.utc).isoformat(),script_sha256=sha(selected),wrapper_sha256=sha(wrapper),real_sha256=sha(real),target_executions=0))
    with (output/'stdout.log').open('wb')as stdout,(output/'stderr.log').open('wb')as stderr:
        run=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    result=dict(returncode=run.returncode,target_executions=0)
    if run.returncode==0:
        outputs=list(outdir.glob('*.so'));assert len(outputs)==1
        raw=outputs[0].read_bytes();(output/'symbols.so').write_bytes(raw)
        strip=[str(sdk/'llvm/bin/llvm-objcopy.exe'),'--strip-all',str(output/'symbols.so'),str(output/'candidate.so')]
        subprocess.run(strip,env=env,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        result['outputs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in output.glob('*.so')}
        expected=P/'upstream/mayhem-initializer-source-origins/artifacts/recovered'
        result['exact_raw_reference']=raw==gzip.decompress((expected/'symbols.so.gz').read_bytes())
        result['exact_stripped_reference']=(output/'candidate.so').read_bytes()==gzip.decompress((expected/'candidate.so.gz').read_bytes())
    save(output/'result.json',result)
    print(label,json.dumps(result),flush=True)
    run.check_returncode()
