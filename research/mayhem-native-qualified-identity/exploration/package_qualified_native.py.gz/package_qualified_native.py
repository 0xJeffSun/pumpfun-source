from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

W=Path(__file__).resolve().parent
P=W/'mayhem-qualified-native'
R=W/'pumpfun-source'
D=P/'publication'
D.mkdir(exist_ok=True)
def put(name,data):
    dest=D/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
def compressed(name,data):
    put(name+'.gz',gzip.compress(data,mtime=0))
for name in ('build.py','linker.rs','wrapper.rs','metadata-map.tsv','path-map.tsv','default.ld','ordered-original.ld','ordered-native.ld','selector-bindings.json','source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','source-difference.json'):
    put(name,(P/name).read_bytes())
for folder in ('sources','upstream'):
    for path in(P/folder).rglob('*'):
        if path.is_file():put(folder+'/'+path.relative_to(P/folder).as_posix(),path.read_bytes())
pins={'upstream/'+name:row for name,row in json.loads((P/'upstream-inputs.json').read_bytes()).items()}
reference='77a2b85af086a514c83178866c17a1e84663b315'
for dest,source in {
    'tools/compiler_records.py':'tools/compiler_records.py',
    'tools/reader.py':'tools/reader.py',
    'initializer_evidence.py':'verify.py',
    'reference/main-build.log':'reference/main-build.log',
    'reference/recent-build.log.gz':'latest/parent/builds/recovered/stderr.gz',
    'reference/native-records.json.gz':'latest/builds/corrected/records.json.gz',
    'reference/native-launch.json.gz':'latest/builds/corrected/launch.json.gz',
    'reference/original.so.gz':'reference/original.so.gz',
    'reference/prior-inventory.json.gz':'reference/prior-inventory.json.gz',
}.items():
    path='research/mayhem-initializer-origins/'+source
    data=subprocess.check_output(['git','show',reference+':'+path],cwd=R)
    put(dest,data)
    pins[dest]=dict(revision=reference,path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
put('upstream-inputs.json',(json.dumps(pins,indent=2)+'\n').encode())
for label in ('build-01','build-repeat','portable-build'):
    folder=P/label
    if not(folder/'result.json').exists():continue
    for path in folder.iterdir():
        if path.is_file()and path.suffix in('.json','.log','.so','.exe'):compressed('builds/'+label+'/'+path.name,path.read_bytes())
    records=[json.loads(p.read_bytes())for p in sorted((folder/'wrapper-records').glob('*.json'))]
    compressed('builds/'+label+'/records.json',(json.dumps(records,indent=2)+'\n').encode())
    for path in(folder/'link').iterdir():
        if path.is_file():compressed('builds/'+label+'/link/'+path.name,path.read_bytes())
    invocation=json.loads((folder/'link/invocation.json').read_bytes())
    inputs=[]
    for row in invocation['inputs']:
        path=folder/'link'/row['retained']if row['retained']else Path(row['path'])
        data=path.read_bytes()
        inputs.append(dict(**row,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        if not row['retained']:
            blob='link-inputs/'+hashlib.sha256(data).hexdigest()+'.gz'
            if not(D/blob).exists():put(blob,gzip.compress(data,mtime=0))
    compressed('builds/'+label+'/link-inputs.json',(json.dumps(inputs,indent=2)+'\n').encode())
for folder in sorted(P.glob('probe-*')):
    if not folder.is_dir():continue
    for path in folder.iterdir():
        if path.is_file()and path.suffix in('.json','.log','.so'):compressed('probes/'+folder.name+'/'+path.name,path.read_bytes())
    if(folder/'link').exists():
        for path in(folder/'link').iterdir():
            if path.is_file():compressed('probes/'+folder.name+'/link/'+path.name,path.read_bytes())
for pattern in ('*-attempt*.py','linker-attempt*.rs','linker-compile*','linker-*.exe','linker.exe'):
    for path in P.glob(pattern):
        if path.is_file():compressed('exploration/'+path.name,path.read_bytes())
for name in ('prepare_qualified_native.py','inspect_qualified_source.py','probe_qualified_native.py','run_qualified_full.py','package_qualified_native.py'):
    compressed('exploration/'+name,(W/name).read_bytes())
print('Packaged',sum(p.is_file()for p in D.rglob('*')),'files')
