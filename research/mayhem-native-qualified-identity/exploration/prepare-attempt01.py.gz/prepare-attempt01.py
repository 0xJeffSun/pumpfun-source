from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import shutil
import subprocess

W = Path(__file__).resolve().parent
R = W / 'pumpfun-source'
P = W / 'mayhem-qualified-native'
P.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('origins', R / 'research/mayhem-initializer-origins/verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
pins = {}
rev = '21bf0cf41ffed3c753630235969b6f183efabf35'
for packet, names in {
    'mayhem-qualified-linker-layout': ['config/ordered.ld', 'config/default.ld', 'config/linker.py', 'builds/recovered/linker-invocation.json', 'maps/recovered.map', 'artifacts/recovered/symbols.so.gz', 'artifacts/recovered/candidate.so.gz'],
    'mayhem-initializer-source-origins': ['README.md', 'source.tar.gz', 'source-inputs.json', 'source.patch', 'artifacts/recovered/symbols.so.gz', 'artifacts/recovered/candidate.so.gz', 'proof.py', 'proof.json', 'builds/recovered/stderr.gz'],
}.items():
    for name in names:
        source = 'research/' + packet + '/' + name
        data = subprocess.check_output(['git', 'show', rev + ':' + source], cwd=R)
        relative = packet + '/' + name
        dest = P / 'upstream' / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        pins[relative] = dict(revision=rev, path=source, bytes=len(data), sha256=v.digest(data), git_blob=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest())
(P / 'upstream-inputs.json').write_text(json.dumps(pins, indent=2) + '\n', encoding='utf8', newline='\n')
sources = v.archive_sources((P / 'upstream/mayhem-initializer-source-origins/source.tar.gz').read_bytes())
assert {n:v.digest(b) for n,b in sources.items()} == v.read(P / 'upstream/mayhem-initializer-source-origins/source-inputs.json')
native = R / 'research/mayhem-initializer-origins/latest'
assert {n:v.digest(b) for n,b in sources.items()} == {r['path']:r['sha256'] for r in v.read(native / 'source-inputs.json')['source_files']}
for name in ('build.py', 'wrapper.rs', 'source-inputs.json', 'sdk-components.json.gz', 'target-components.json', 'vendor-inputs.json', 'host-tools.json', 'metadata-map.tsv', 'path-map.tsv'):
    shutil.copyfile(native / name, P / name)
shutil.copytree(native / 'sources', P / 'sources')
old = v.v.published_units(v.raw(R / 'research/mayhem-initializer-origins/reference/main-build.log').decode())
recent = v.v.published_units(v.raw(native / 'parent/builds/recovered/stderr.gz').decode())
replace = {v.v.value(a,'--crate-name') for a in recent}
published = {v.v.source_key(v.v.source(a)):a for a in [a for a in old if v.v.value(a,'--crate-name') not in replace]+recent}
records = v.read(native / 'builds/corrected/records.json.gz')
units = [r for r in records if v.v.is_compile(r['before']) and v.v.is_target(r['before'])]
assert len(units) == len(published) == 85
changes = {}
rows = []
def suffix(args):
    items = [a.split('=',1)[1] for a in args if a.startswith('extra-filename=')]
    return items[0] if items else ''
for r in units:
    before = r['before']
    pub = published[v.v.source_key(v.v.source(before))]
    crate = v.v.value(before,'--crate-name')
    assert v.v.signature(before) == v.v.signature(pub)
    a, b = crate + suffix(pub), crate + suffix(before)
    if a != b:
        assert a not in changes
        changes[a] = b
    rows.append(dict(crate=crate, source=v.v.source_key(v.v.source(before)), published=a, native=b,
                     published_metadata=v.v.metadata(pub), native_metadata=v.v.metadata(before)))
script = (P / 'upstream/mayhem-qualified-linker-layout/config/ordered.ld').read_bytes()
default = (P / 'upstream/mayhem-qualified-linker-layout/config/default.ld').read_bytes()
(P / 'default.ld').write_bytes(default)
(P / 'ordered-original.ld').write_bytes(script)
lines = script.decode().splitlines(True)
applied = []
for index,line in enumerate(lines):
    if '(".text' not in line:
        continue
    prefix, section = line.split('("',1)
    before = prefix
    for a,b in changes.items():
        prefix = prefix.replace(a,b)
    if prefix != before:
        applied.append(dict(line=index+1, published=before.strip(), native=prefix.strip()))
    lines[index] = prefix + '("' + section
(P / 'ordered-native.ld').write_text(''.join(lines), encoding='utf8', newline='\n')
(P / 'selector-bindings.json').write_text(json.dumps(dict(units=rows, selectors=applied), indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(dict(source_files=len(sources), target_units=len(rows), changed_unit_filenames=len(changes), changed_selectors=len(applied))))
