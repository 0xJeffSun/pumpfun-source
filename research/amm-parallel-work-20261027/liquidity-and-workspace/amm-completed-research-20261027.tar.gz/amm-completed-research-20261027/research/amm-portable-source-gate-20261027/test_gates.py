from pathlib import Path
import hashlib,json,shutil,sys,tempfile
sys.path.insert(0,str(Path(__file__).resolve().parent))
import verify_source_binding as source
import verify_dependency_proof as dependency
W=Path(__file__).resolve().parent
ROOT=W.parents[1]
B=ROOT/'work/amm-parser-liquidity-composite-20261027'
P=W/'fixture-dependency-proof'
args=(B/'canonical-source',B/'clean-workspace',B/'build/build-comparison.json',B/'build/artifacts/pump_amm_recovered.so',B/'build/artifacts/unstripped.so',P)
results={}
results['source_positive']=source.verify(*args,current_source=B/'canonical-source')
results['dependency_positive']=dependency.verify(B/'canonical-source',B/'build/build-comparison.json',P)
def reject(name,call):
 try:call()
 except (AssertionError,FileNotFoundError,KeyError)as error:results[name]={'rejected':True,'error':str(error)[:300]}
 else:raise AssertionError('Negative accepted: '+name)
with tempfile.TemporaryDirectory(prefix='gate-negative-',dir=W)as name:
 current=Path(name)/'current';shutil.copytree(B/'canonical-source',current)
 rust=current/'programs/pump-amm/src/lib.rs';rust.write_bytes(rust.read_bytes()+b'\n// mutation\n')
 reject('current_rust_mutation',lambda:source.verify(*args,current_source=current))
 reject('canonical_rust_mutation',lambda:source.verify(current,*args[1:]))
 file=P/'active-sources/solana-instruction-2.2.1/src/lib.rs';original=file.read_bytes()
 try:
  file.write_bytes(original+b'\n// mutation\n')
  reject('external_source_mutation',lambda:source.verify(*args))
  reject('external_dependency_mutation',lambda:dependency.verify(B/'canonical-source',B/'build/build-comparison.json',P))
 finally:file.write_bytes(original)
extra=P/'not-recorded';extra.write_text('unlisted')
try:reject('unlisted_dependency_file',lambda:dependency.verify(B/'canonical-source',B/'build/build-comparison.json',P))
finally:extra.unlink()
# The explicit mapping API must reject either direction of inventory drift.
mapping=source.archived_external_inputs(args[2],P)
missing=dict(mapping);missing.pop(next(iter(missing)))
reject('missing_external_key',lambda:source.recipe.verify_build(*args[:5],external_inputs=missing))
extra=dict(mapping);extra['unrecorded']=next(iter(extra.values()))
reject('extra_external_key',lambda:source.recipe.verify_build(*args[:5],external_inputs=extra))
results['all_passed']=True
(W/'test-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in results.items()if k not in('source_positive','dependency_positive')},indent=2))
print(json.dumps(results['dependency_positive'],indent=2))
