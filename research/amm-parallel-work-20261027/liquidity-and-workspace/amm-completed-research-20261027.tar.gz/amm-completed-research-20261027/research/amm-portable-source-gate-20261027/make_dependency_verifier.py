from pathlib import Path
p=Path('repro/pump_amm/dependency-liquidity-recovery-20261027/results/dependency-proof/verify.py')
s=p.read_text().replace('def verify(source,record):\n','''def verify(source,record,proof_root=None,expected_seal=None):
 D=Path(proof_root).resolve() if proof_root is not None else Path(__file__).resolve().parent
 source=Path(source);record=Path(record)
 if expected_seal is not None:assert H(D/'manifest.json')==expected_seal
 seal=J(D/'manifest.json');assert isinstance(seal['files'],dict)
 actual={str(p.relative_to(D))for p in D.rglob('*')if p.is_file()}
 assert actual==set(seal['files'])|{'manifest.json'},('dependency-proof inventory mismatch',actual-set(seal['files'])-{'manifest.json'},set(seal['files'])-actual)
 for name,digest in seal['files'].items():
  rel=PurePosixPath(name);assert not rel.is_absolute() and '..'not in rel.parts and str(rel)==name
  target=D/name;assert not any(p.is_symlink()for p in(target,*target.parents)if p!=D.parent)
  assert H(target)==digest,name
''')
a=s.index(' app={};registry={}')
b=s.index(" assert H(D/'builder-executed.py')",a)
s=s[:a]+''' suffix='programs/pump-amm/Cargo.toml';roots=[name[:-len(suffix)]for name in r['source_sha256']if name.endswith(suffix)];assert len(roots)==1 and roots[0]
 prefix=roots[0];app={};registry={}
 for name,digest in r['source_sha256'].items():
  if name.startswith(prefix):app[name[len(prefix):]]=digest
  else:
   assert name.count('/registry/src/')==1,name
   tail=name.split('/registry/src/',1)[1].split('/',1)[1];assert tail not in registry;registry[tail]=digest
 assert registry==expected and len(registry)==169;assert len(app)==45 and len(r['source_sha256'])==214
 assert 'Cargo.toml'in app and 'Cargo.lock'in app and 'programs/pump-amm/Cargo.toml'in app
 # Exact local bytes, including relocated profile/lock, are bound by the
 # canonical standalone -> workspace recipe in verify_source_binding.py.
''' +s[b:]
s=s.replace("'application_inputs_bound':len(app)","'workspace_inputs_delegated_to_source_recipe':len(app),'canonical_inputs_delegated_to_source_recipe':44")
s=s.replace("default=D.parent/'source'","default=D.parent/'canonical-source'")
s=s.replace("p.add_argument('--expected-seal');a=p.parse_args()", "p.add_argument('--expected-seal');a=p.parse_args()")
s=s.replace(" print(json.dumps(verify(a.source,a.build_record),indent=2))", " print(json.dumps(verify(a.source,a.build_record,expected_seal=a.expected_seal),indent=2))")
Path('work/amm-portable-source-gate-20261027/verify_dependency_proof.py').write_text(s)
