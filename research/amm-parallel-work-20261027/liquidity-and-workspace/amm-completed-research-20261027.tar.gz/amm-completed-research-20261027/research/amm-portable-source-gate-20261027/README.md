# Portable AMM workspace checkpoint gates

These files are ready to copy into a sealed checkpoint. They read only saved
artifacts; they do not compile, execute programs, or open private Cargo cache
paths recorded as provenance.

- Copy `verify_source_binding.py` and the unchanged `workspace_recipe_v2.py` to
  the checkpoint root. `verify(canonical_source, workspace, build_record,
  candidate, symbols, dependency_proof, current_source=None)` binds 44 canonical
  standalone inputs to 45 exact compiled workspace inputs and maps all 169
  recorded external keys to `dependency-proof/active-sources`. Both keysets and
  every file hash are checked. `current_source` additionally binds the maintained
  standalone tree. All Rust bytes are unchanged by the recipe.
- Copy `verify_dependency_proof.py` as `results/dependency-proof/verify.py`.
  `verify(source, record, proof_root=None, expected_seal=None)` checks the exact
  sealed proof inventory, eight crate archives, 161 archive files, eight Cargo
  metadata files, coherent canonical Cargo manifest/lock, 732 unchanged saved
  dependency artifacts, and existing builder/SDK/target/tool proof. Local
  workspace file bytes are explicitly delegated to the source gate above;
  this verifier does not substitute the former 41-file standalone check.
- The new proof must archive the actual 5c1e `build_workspace.py` as
  `builder-executed.py` (SHA256 `196fd44217ffdd9fa45f9465a8af3c7d2f65163cb0a87658a7b5f38f92de3dd3`).
  Regenerate and pin its manifest after adding the new verifier. Other
  dependency proof inputs remain those of the prior authenticated package.
- Copy `verify_pool_abi.py` to the checkpoint root. Its API is
  `verify(candidate, symbols, repo_root)`; the CLI accepts explicit versions of
  all three paths. It compares four entire Pool helper instruction/relocation
  windows, allows only their actual source-line immediate differences, checks
  the exact 224-byte Pool::can_boost window, follows the real deposit dispatcher
  call, and checks the actual Pool-reference/quote amount helper arguments.

`test-results.json` records the positive 5c1e run and rejection of current Rust,
canonical Rust, external source (both gates), an unlisted proof file, and missing
or extra external mapping keys. The private fixture replaces only the old
builder and verifier and reseals the copied package for this test.
`pool-abi-results.json` records the positive static gate. The original V1 recipe
was not changed. Existing V2's 15 tests, including its original 11, were already
saved under `work/amm-workspace-recipe-v2-20261027`.

The input build is `5c1e8b18ead27d0b3c1840f37b24ef5044adb65e2a3a566d5be7694ff8737c05`.
No retained historical package, maintained source, root Cargo manifest/lock,
build cache, Git state, or public checkpoint was modified.
