# Portable AMM workspace verification, v2

V1 remains unchanged. `workspace_recipe_v2.py` preserves the staging recipe and default physical-path checks, and extends the Python API:

```python
result = verify_build(
    source_root=current_canonical_repository,
    workspace=staged_workspace,
    build_record=sealed_build_record,
    candidate=sealed_candidate,
    symbols=sealed_symbols,
    repository_root=repository,
    external_inputs={recorded_name: archived_file_path, ...},
)
```

When `external_inputs` is supplied, its keys must equal the complete set of non-workspace entries in `source_sha256`. Missing and extra keys fail before verification. Every mapped file is read and SHA-256 checked against the recorded digest. A supplied empty mapping does not fall back to private paths. Ordinary mapped files are required; their explicit paths are resolved once, allowing system directory aliases such as macOS `/var`. The canonical Rust/workspace inventory, successful build record, before/after input equality and both output hashes are still checked.

When the argument is omitted (`None`), the existing repository-relative external-path verification remains active. The CLI retains that default; the portable checkpoint wrapper should use the Python API after authenticating its dependency archive proof and resolving archive-member paths.

## Tests

All15 tests pass: the existing11 recipe tests plus portable success without a private-cache root and rejection of missing keys, extra keys and mutated archived content. A real saved build was also checked twice: once with the default paths and once with all169 external source inputs copied into an archive fixture. The portable run deliberately names a nonexistent private-cache root. Both modes validate the same candidate, `5c250b4a7dc9e410de4af29e6241310204e993ac6003de7e2956f8783f69a9c2`, against an equivalent canonical standalone snapshot of that saved source. This does not relabel it as a build of the current maintained source. No new compiler or target execution occurred.

`archived-map.json` stores paths relative to this packet directory for the local fixture. The publication wrapper should instead derive its mapping from the eight authenticated dependency archives; it must not copy these local fixture paths into public metadata.

## Quarantining the uncompiled B2 backup

Keep the original build record unchanged. Before moving `programs/pump-amm/src/trade.rs.orig`, confirm it is absent from both recorded input dictionaries (`source_sha256` and `source_after_sha256`) and is not a Rust `include!`/`include_bytes!`/`include_str!` input. Move only that file to a quarantine directory outside the compiled workspace, preserving its bytes. Record old path, new path, byte count, SHA-256, and the unchanged build-record hash in a quarantine manifest outside the workspace. Verify the moved copy's hash, then run the recipe's exact workspace/build-input verification again.

Do not alter the build record, retained Rust files, lockfiles, profiles or sealed package manifests to excuse a mismatch. If B2 is already sealed, first preserve the original sealed packet and make a separately described cleaned materialization. The backup is not a compiler input, so its quarantine does not require a rebuild; the positive condition is that every recorded compiler input and artifact hash still agrees, and the cleaned workspace inventory is exactly the recipe output.
