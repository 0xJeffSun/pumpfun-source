# Explicit AMM standalone-to-workspace recipe

`workspace_recipe.py` is a private candidate helper for the next checkpoint. It never changes the repository workspace, maintained sources or other programs. It materializes a new sole-member workspace from the maintained standalone AMM crate:

- Rust and retained IDL/vendor inputs are copied byte-for-byte.
- The empty AMM `[workspace]` is removed from the staged member manifest.
- Profile tables move verbatim into the new workspace root; only trailing blank-line normalization is applied at table/file boundaries. Parsed package/dependency/profile data must remain identical.
- The AMM crate's Cargo.lock moves byte-for-byte to the new workspace root. The Fees repository-root manifest and lockfile are never used as AMM Cargo inputs.
- The output must be new and its complete staged-file inventory must match the recipe. Symlinks, unexpected files, missing files and changed bytes fail verification.

Version1 deliberately rejects ambient Cargo/toolchain configuration. Moving Cargo's invocation directory changes config discovery, so adding a `.cargo/config*` or `rust-toolchain*` selector requires an explicit reviewed recipe extension, not automatic copying or suppression.

## Commands

```sh
python -B workspace_recipe.py stage --source-root /path/to/repo --output /new/private/workspace
python -B workspace_recipe.py verify --source-root /path/to/repo --workspace /new/private/workspace
python -B workspace_recipe.py verify --source-root /path/to/repo --workspace /new/private/workspace --build-record /path/to/build-comparison.json --candidate /path/to/candidate.so --symbols /path/to/unstripped.so --repository-root /path/to/repo
```

`verify --build-record` checks every recorded local compiler input against the derived workspace and every recorded external input against its hash. It checks before/after input equality, successful build status and both artifact hashes. A different recorded workspace prefix is supported because checkpoint archives relocate the source directory. The exact local input set must still match. Toolchain authentication, dependency-resolution provenance, runtime receipts and selected status bindings remain the responsibility of the enclosing sealed checkpoint verifier.

## Validation

All11 boundary tests pass: Rust drift on either side, profile changes, lock changes, extra files, duplicate member lock, missing inputs, preexisting output, nonempty standalone workspace, new Cargo config, and compiled-input drift are rejected. The tests also assert that the unrelated Fees root manifest/lock stay unchanged.

The live maintained AMM stages as41 standalone inputs →42 workspace inputs, with34 Rust files unchanged. The helper independently binds an existing real workspace build with42 local+169 external inputs and verifies its two artifact hashes. That positive test uses an equivalent standalone snapshot of the saved build's own source. It is **not** relabeled as a build of today's maintained source: the saved workspace has a different `lib.rs`, and verifying it against the live tree correctly fails. `live-drift-rejection.json` retains that observation.

The old saved workspace also contains an uncompiled `src/trade.rs.orig` backup. Strict workspace inventory rejects it. The positive build-input test therefore uses a clean recipe-derived workspace with exactly the recorded compiler inputs; no legacy workspace files were removed or edited.

No compiler, VM or network operation was performed by this helper validation.
