"""Boundary tests for the explicit AMM workspace materialization recipe."""
from pathlib import Path
import json
import tempfile
import unittest

import workspace_recipe as recipe


MANIFEST = b'''[package]
name = "pump-amm-recovered"
version = "0.1.0"
edition = "2021"

[dependencies]
uint = "=0.9.5"

[profile.release]
panic = "abort"
overflow-checks = true
lto = false
codegen-units = 1

[workspace]
'''


class RecipeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'canonical'
        self.crate = self.root / recipe.CRATE
        (self.crate / 'src').mkdir(parents=True)
        (self.crate / 'idls').mkdir()
        (self.root / 'Cargo.toml').write_bytes(b'[workspace]\nmembers=["programs/pump-fees"]\n')
        (self.root / 'Cargo.lock').write_bytes(b'Fees lock must remain untouched\n')
        (self.crate / 'Cargo.toml').write_bytes(MANIFEST)
        (self.crate / 'Cargo.lock').write_bytes(b'version = 3\n')
        (self.crate / 'src/lib.rs').write_bytes(b'pub fn recovered() {}\n')
        (self.crate / 'idls/fees.json').write_bytes(b'{"name":"fees"}\n')
        self.output = Path(self.temp.name) / 'compiled'
        self.root_before = {(self.root / name): (self.root / name).read_bytes()
                            for name in ('Cargo.toml', 'Cargo.lock')}
        recipe.stage(self.root, self.output)

    def tearDown(self):
        for path, data in self.root_before.items():
            self.assertEqual(path.read_bytes(), data)

    def test_positive_exact_recipe_and_rust(self):
        result = recipe.verify_workspace(self.root, self.output)
        self.assertEqual(result['rust_transformations'], 0)
        self.assertEqual((self.output / 'Cargo.lock').read_bytes(), b'version = 3\n')
        self.assertNotIn(b'[workspace]', (self.output / recipe.CRATE / 'Cargo.toml').read_bytes())
        self.assertNotIn(b'[profile.', (self.output / recipe.CRATE / 'Cargo.toml').read_bytes())
        self.assertIn(b'[profile.release]\npanic = "abort"', (self.output / 'Cargo.toml').read_bytes())

    def test_changed_canonical_rust_rejected(self):
        (self.crate / 'src/lib.rs').write_bytes(b'pub fn changed() {}\n')
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_changed_staged_rust_rejected(self):
        (self.output / recipe.CRATE / 'src/lib.rs').write_bytes(b'pub fn changed() {}\n')
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_changed_profile_rejected(self):
        p = self.crate / 'Cargo.toml'
        p.write_bytes(p.read_bytes().replace(b'overflow-checks = true', b'overflow-checks = false'))
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_changed_lock_rejected(self):
        (self.output / 'Cargo.lock').write_bytes(b'version = 4\n')
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_extra_file_and_duplicate_crate_lock_rejected(self):
        for name in ('unrecorded.txt', recipe.CRATE + '/Cargo.lock'):
            p = self.output / name
            p.write_bytes(b'extra\n')
            with self.assertRaises(AssertionError):
                recipe.verify_workspace(self.root, self.output)
            p.unlink()

    def test_missing_input_rejected(self):
        (self.output / recipe.CRATE / 'idls/fees.json').unlink()
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_existing_output_rejected(self):
        with self.assertRaises(AssertionError):
            recipe.stage(self.root, self.output)

    def test_new_cargo_configuration_requires_review(self):
        folder = self.root / '.cargo'
        folder.mkdir()
        (folder / 'config.toml').write_bytes(b'[build]\nrustflags=["--cfg", "changed"]\n')
        with self.assertRaises(AssertionError):
            recipe.verify_workspace(self.root, self.output)

    def test_nonempty_source_workspace_rejected(self):
        p = self.crate / 'Cargo.toml'
        p.write_bytes(p.read_bytes() + b'members = ["nested"]\n')
        with self.assertRaises(AssertionError):
            recipe.expected_workspace(self.root)

    def test_build_input_and_artifact_binding(self):
        _, files = recipe.expected_workspace(self.root)
        external = self.root / 'dependency.rs'
        external.write_bytes(b'pub const PIN: u8 = 1;\n')
        sources = {'compiled/' + n: recipe.digest(b) for n, b in files.items()}
        sources['dependency.rs'] = recipe.digest(external.read_bytes())
        candidate = Path(self.temp.name) / 'candidate.so'
        symbols = Path(self.temp.name) / 'symbols.so'
        candidate.write_bytes(b'fixture artifact; not a real ELF')
        symbols.write_bytes(b'fixture symbols; not a real ELF')
        record = {'returncode': 0, 'source_unchanged': True, 'source_sha256': sources,
                  'source_after_sha256': sources,
                  'comparison': {'candidate_sha256': recipe.digest(candidate.read_bytes())},
                  'unstripped_sha256': recipe.digest(symbols.read_bytes())}
        path = Path(self.temp.name) / 'build.json'
        path.write_text(json.dumps(record))
        result = recipe.verify_build(self.root, self.output, path, candidate, symbols)
        self.assertTrue(result['compiled_inputs_verified'])
        self.assertEqual(result['external_inputs_verified'], 1)
        record['source_sha256'] = dict(sources)
        record['source_sha256']['compiled/' + recipe.CRATE + '/src/lib.rs'] = '0' * 64
        record['source_after_sha256'] = record['source_sha256']
        path.write_text(json.dumps(record))
        with self.assertRaises(AssertionError):
            recipe.verify_build(self.root, self.output, path, candidate, symbols)


if __name__ == '__main__':
    unittest.main()
