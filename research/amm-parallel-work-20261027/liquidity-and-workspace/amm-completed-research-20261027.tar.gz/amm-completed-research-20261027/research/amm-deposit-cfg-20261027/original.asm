
evidence/original/pump_amm/deployed.so:	file format elf64-sbf

Disassembly of section .text:

0000000000000120 <.text>:
   24423:	mov64 r6, r1
   24424:	ldxdw r8, [r2 + 0x8]
   24425:	ldxdw r1, [r8 + 0x8]
   24426:	ldxb r1, [r1 + 0x3b0]
   24427:	and64 r1, 0x2
   24428:	jne r1, 0x0, +0x87 <.text+0x2fe80>
   24429:	stxdw [r10 - 0x408], r3
   24430:	stxdw [r10 - 0x418], r5
   24431:	stxdw [r10 - 0x428], r2
   24432:	stxdw [r10 - 0x410], r4
   24433:	ldxdw r1, [r8 + 0x48]
   24434:	ldxdw r9, [r1 + 0x68]
   24435:	ldxdw r1, [r8 + 0x38]
   24436:	ldxdw r1, [r1 + 0x68]
   24437:	stxdw [r10 - 0x430], r1
   24438:	ldxdw r1, [r8 + 0x30]
   24439:	ldxdw r1, [r1 + 0x68]
   24440:	stxdw [r10 - 0x440], r1
   24441:	ldxdw r1, [r8 + 0x50]
   24442:	ldxdw r3, [r1 + 0x68]
   24443:	ldxdw r2, [r8 + 0x0]
   24444:	add64 r2, 0x8
   24445:	mov64 r1, r10
   24446:	add64 r1, -0x260
   24447:	stxdw [r10 - 0x438], r3
   24448:	call 0x7819
   24449:	ldxdw r7, [r10 - 0x260]
   24450:	jeq r7, 0x2, +0x1 <.text+0x2fb00>
   24451:	ja +0x137 <.text+0x304b8>
   24452:	stxdw [r10 - 0x420], r6
   24453:	mov64 r1, r10
   24454:	add64 r1, -0x2a0
   24455:	mov64 r2, r9
   24456:	mov64 r3, 0x0
   24457:	ldxdw r4, [r10 - 0x408]
   24458:	mov64 r5, 0x0
   24459:	call 0x1d77a
   24460:	ldxdw r7, [r10 - 0x258]
   24461:	ldxdw r1, [r8 + 0x0]
   24462:	ldxdw r6, [r1 + 0xf8]
   24463:	mov64 r1, r10
   24464:	add64 r1, -0x260
   24465:	ldxdw r2, [r10 - 0x2a0]
   24466:	ldxdw r3, [r10 - 0x298]
   24467:	mov64 r4, r6
   24468:	mov64 r5, 0x0
   24469:	call -0x3a35
   24470:	ldxdw r2, [r10 - 0x258]
   24471:	ldxdw r1, [r10 - 0x260]
   24472:	jeq r1, 0x0, +0x4 <.text+0x2fbc8>
   24473:	ldxdw r1, [r10 - 0x250]
   24474:	mov64 r7, r2
   24475:	ldxdw r6, [r10 - 0x420]
   24476:	ja +0x11f <.text+0x304c0>
   24477:	stxdw [r10 - 0x448], r6
   24478:	ldxdw r1, [r10 - 0x250]
   24479:	jeq r1, 0x0, +0x36 <.text+0x2fd90>
   24480:	mov64 r1, r10
   24481:	add64 r1, -0x28
   24482:	lddw r2, 0x11c07c
   24484:	call 0x8ada
   24485:	stdw [r10 - 0x58], 0x0
   24486:	stdw [r10 - 0x60], 0x1
   24487:	stdw [r10 - 0x68], 0x0
   24488:	lddw r1, 0x1221e0
   24490:	stxdw [r10 - 0xa8], r1
   24491:	mov64 r1, r10
   24492:	add64 r1, -0x68
   24493:	stxdw [r10 - 0xb0], r1
   24494:	stb [r10 - 0x98], 0x3
   24495:	stdw [r10 - 0xa0], 0x20
   24496:	stdw [r10 - 0xc0], 0x0
   24497:	stdw [r10 - 0xd0], 0x0
   24498:	mov64 r2, r10
   24499:	add64 r2, -0xd0
   24500:	lddw r1, 0x11c07c
   24502:	call 0x95bd
   24503:	ldxdw r6, [r10 - 0x420]
   24504:	jeq r0, 0x0, +0x1 <.text+0x2fcb0>
   24505:	ja +0x52 <.text+0x2ff40>
   24506:	ldxdw r1, [r10 - 0x58]
   24507:	stxdw [r10 - 0x218], r1
   24508:	ldxdw r1, [r10 - 0x60]
   24509:	stxdw [r10 - 0x220], r1
   24510:	ldxdw r1, [r10 - 0x68]
   24511:	stxdw [r10 - 0x228], r1
   24512:	ldxdw r1, [r10 - 0x28]
   24513:	stxdw [r10 - 0x240], r1
   24514:	ldxdw r1, [r10 - 0x20]
   24515:	stxdw [r10 - 0x238], r1
   24516:	ldxdw r1, [r10 - 0x18]
   24517:	stxdw [r10 - 0x230], r1
   24518:	lddw r1, 0x11cc2b
   24520:	stxdw [r10 - 0x258], r1
   24521:	stw [r10 - 0x1c8], 0x1788
   24522:	stb [r10 - 0x210], 0x2
   24523:	stw [r10 - 0x248], 0x4d
   24524:	stdw [r10 - 0x250], 0x37
   24525:	stdw [r10 - 0x260], 0x0
   24526:	mov64 r1, r10
   24527:	add64 r1, -0x2b0
   24528:	mov64 r2, r10
   24529:	add64 r2, -0x260
   24530:	call 0x1a624
   24531:	ldxdw r1, [r10 - 0x2a8]
   24532:	ldxdw r7, [r10 - 0x2b0]
   24533:	ja +0xe6 <.text+0x304c0>
   24534:	ldxdw r1, [r10 - 0x410]
   24535:	stxdw [r10 - 0x450], r2
   24536:	jgt r2, r1, +0x1 <.text+0x2fdb0>
   24537:	ja +0x58 <.text+0x30070>
   24538:	mov64 r1, r10
   24539:	add64 r1, -0x28
   24540:	lddw r2, 0x11bf74
   24542:	call 0x8aa0
   24543:	stdw [r10 - 0x58], 0x0
   24544:	stdw [r10 - 0x60], 0x1
   24545:	stdw [r10 - 0x68], 0x0
   24546:	lddw r1, 0x1221e0
   24548:	stxdw [r10 - 0xa8], r1
   24549:	mov64 r1, r10
   24550:	add64 r1, -0x68
   24551:	stxdw [r10 - 0xb0], r1
   24552:	stb [r10 - 0x98], 0x3
   24553:	stdw [r10 - 0xa0], 0x20
   24554:	stdw [r10 - 0xc0], 0x0
   24555:	stdw [r10 - 0xd0], 0x0
   24556:	mov64 r2, r10
   24557:	add64 r2, -0xd0
   24558:	lddw r1, 0x11bf74
   24560:	call 0x9583
   24561:	ldxdw r6, [r10 - 0x420]
   24562:	jeq r0, 0x0, +0x53 <.text+0x30110>
   24563:	ja +0x18 <.text+0x2ff40>
   24564:	mov64 r1, r10
   24565:	add64 r1, -0x28
   24566:	lddw r2, 0x11c000
   24568:	call 0x8a86
   24569:	stdw [r10 - 0x58], 0x0
   24570:	stdw [r10 - 0x60], 0x1
   24571:	stdw [r10 - 0x68], 0x0
   24572:	lddw r1, 0x1221e0
   24574:	stxdw [r10 - 0xa8], r1
   24575:	mov64 r1, r10
   24576:	add64 r1, -0x68
   24577:	stxdw [r10 - 0xb0], r1
   24578:	stb [r10 - 0x98], 0x3
   24579:	stdw [r10 - 0xa0], 0x20
   24580:	stdw [r10 - 0xc0], 0x0
   24581:	stdw [r10 - 0xd0], 0x0
   24582:	mov64 r2, r10
   24583:	add64 r2, -0xd0
   24584:	lddw r1, 0x11c000
   24586:	call 0x9569
   24587:	jeq r0, 0x0, +0xa <.text+0x2ff90>
   24588:	mov64 r3, r10
   24589:	add64 r3, -0x280
   24590:	lddw r1, 0x11c0fa
   24592:	mov64 r2, 0x37
   24593:	lddw r4, 0x122210
   24595:	lddw r5, 0x122230
   24597:	call 0x1c5dd
   24598:	ldxdw r1, [r10 - 0x58]
   24599:	stxdw [r10 - 0x218], r1
   24600:	ldxdw r1, [r10 - 0x60]
   24601:	stxdw [r10 - 0x220], r1
   24602:	ldxdw r1, [r10 - 0x68]
   24603:	stxdw [r10 - 0x228], r1
   24604:	ldxdw r1, [r10 - 0x28]
   24605:	stxdw [r10 - 0x240], r1
   24606:	ldxdw r1, [r10 - 0x20]
   24607:	stxdw [r10 - 0x238], r1
   24608:	ldxdw r1, [r10 - 0x18]
   24609:	stxdw [r10 - 0x230], r1
   24610:	lddw r1, 0x11cc2b
   24612:	stxdw [r10 - 0x258], r1
   24613:	stw [r10 - 0x1c8], 0x1782
   24614:	stb [r10 - 0x210], 0x2
   24615:	stw [r10 - 0x248], 0x38
   24616:	stdw [r10 - 0x250], 0x37
   24617:	stdw [r10 - 0x260], 0x0
   24618:	mov64 r1, r10
   24619:	add64 r1, -0x290
   24620:	mov64 r2, r10
   24621:	add64 r2, -0x260
   24622:	call 0x1a5c8
   24623:	ldxdw r1, [r10 - 0x288]
   24624:	ldxdw r7, [r10 - 0x290]
   24625:	ja +0x8a <.text+0x304c0>
   24626:	mov64 r1, r10
   24627:	add64 r1, -0x2c0
   24628:	mov64 r2, r7
   24629:	mov64 r3, 0x0
   24630:	ldxdw r4, [r10 - 0x408]
   24631:	mov64 r5, 0x0
   24632:	call 0x1d6cd
   24633:	mov64 r1, r10
   24634:	add64 r1, -0x260
   24635:	ldxdw r2, [r10 - 0x2c0]
   24636:	ldxdw r3, [r10 - 0x2b8]
   24637:	ldxdw r4, [r10 - 0x448]
   24638:	mov64 r5, 0x0
   24639:	call -0x3adf
   24640:	ldxdw r7, [r10 - 0x258]
   24641:	ldxdw r1, [r10 - 0x260]
   24642:	ldxdw r6, [r10 - 0x420]
   24643:	jeq r1, 0x0, +0x25 <.text+0x30228>
   24644:	ldxdw r1, [r10 - 0x250]
   24645:	ja +0x76 <.text+0x304c0>
   24646:	ldxdw r1, [r10 - 0x58]
   24647:	stxdw [r10 - 0x218], r1
   24648:	ldxdw r1, [r10 - 0x60]
   24649:	stxdw [r10 - 0x220], r1
   24650:	ldxdw r1, [r10 - 0x68]
   24651:	stxdw [r10 - 0x228], r1
   24652:	ldxdw r1, [r10 - 0x28]
   24653:	stxdw [r10 - 0x240], r1
   24654:	ldxdw r1, [r10 - 0x20]
   24655:	stxdw [r10 - 0x238], r1
   24656:	ldxdw r1, [r10 - 0x18]
   24657:	stxdw [r10 - 0x230], r1
   24658:	lddw r1, 0x11cc2b
   24660:	stxdw [r10 - 0x258], r1
   24661:	stw [r10 - 0x1c8], 0x1774
   24662:	stb [r10 - 0x210], 0x2
   24663:	stw [r10 - 0x248], 0x4f
   24664:	stdw [r10 - 0x250], 0x37
   24665:	stdw [r10 - 0x260], 0x0
   24666:	mov64 r1, r10
   24667:	add64 r1, -0x3f0
   24668:	mov64 r2, r10
   24669:	add64 r2, -0x260
   24670:	call 0x1a598
   24671:	ldxdw r3, [r10 - 0x3e8]
   24672:	ldxdw r2, [r10 - 0x3f0]
   24673:	mov64 r1, r10
   24674:	add64 r1, -0x400
   24675:	ldxdw r4, [r10 - 0x410]
   24676:	ldxdw r5, [r10 - 0x450]
   24677:	call -0x5d5e
   24678:	ldxdw r1, [r10 - 0x3f8]
   24679:	ldxdw r7, [r10 - 0x400]
   24680:	ja +0x53 <.text+0x304c0>
   24681:	ldxdw r1, [r10 - 0x250]
   24682:	jeq r1, 0x0, +0x6 <.text+0x30268>
   24683:	mov64 r1, r10
   24684:	add64 r1, -0x2d0
   24685:	call 0x274
   24686:	ldxdw r1, [r10 - 0x2c8]
   24687:	ldxdw r7, [r10 - 0x2d0]
   24688:	ja +0x4b <.text+0x304c0>
   24689:	stxdw [r10 - 0x458], r7
   24690:	ldxdw r1, [r8 + 0x20]
   24691:	ldxdw r2, [r1 + 0x58]
   24692:	mov64 r7, r10
   24693:	add64 r7, -0x260
   24694:	mov64 r1, r7
   24695:	call -0x4449
   24696:	mov64 r1, r10
   24697:	add64 r1, -0xd0
   24698:	mov64 r2, r7
   24699:	call 0x87a9
   24700:	ldxdw r1, [r10 - 0xc0]
   24701:	ldxdw r7, [r10 - 0xc8]
   24702:	ldxdw r2, [r10 - 0xd0]
   24703:	jeq r2, 0x2, +0x1 <.text+0x302e8>
   24704:	ja +0x11 <.text+0x30370>
   24705:	ldxdw r2, [r10 - 0x250]
   24706:	ldxdw r3, [r10 - 0x258]
   24707:	ldxdw r4, [r3 + 0x0]
   24708:	add64 r4, -0x1
   24709:	stxdw [r3 + 0x0], r4
   24710:	jne r4, 0x0, +0x3 <.text+0x30330>
   24711:	ldxdw r4, [r3 + 0x8]
   24712:	add64 r4, -0x1
   24713:	stxdw [r3 + 0x8], r4
   24714:	ldxdw r3, [r2 + 0x0]
   24715:	add64 r3, -0x1
   24716:	stxdw [r2 + 0x0], r3
   24717:	jne r3, 0x0, +0x2e <.text+0x304c0>
   24718:	ldxdw r3, [r2 + 0x8]
   24719:	add64 r3, -0x1
   24720:	stxdw [r2 + 0x8], r3
   24721:	ja +0x2a <.text+0x304c0>
   24722:	ldxdw r3, [r10 - 0xb8]
   24723:	stxdw [r10 - 0x268], r3
   24724:	stxdw [r10 - 0x270], r1
   24725:	stxdw [r10 - 0x278], r7
   24726:	stxdw [r10 - 0x280], r2
   24727:	ldxdw r1, [r10 - 0x250]
   24728:	ldxdw r2, [r10 - 0x258]
   24729:	ldxdw r3, [r2 + 0x0]
   24730:	add64 r3, -0x1
   24731:	stxdw [r2 + 0x0], r3
   24732:	jne r3, 0x0, +0x3 <.text+0x303e0>
   24733:	ldxdw r3, [r2 + 0x8]
   24734:	add64 r3, -0x1
   24735:	stxdw [r2 + 0x8], r3
   24736:	ldxdw r2, [r1 + 0x0]
   24737:	add64 r2, -0x1
   24738:	stxdw [r1 + 0x0], r2
   24739:	ldxdw r7, [r10 - 0x458]
   24740:	jne r2, 0x0, +0x3 <.text+0x30420>
   24741:	ldxdw r2, [r1 + 0x8]
   24742:	add64 r2, -0x1
   24743:	stxdw [r1 + 0x8], r2
   24744:	mov64 r1, r10
   24745:	add64 r1, -0x260
   24746:	mov64 r2, r10
   24747:	add64 r2, -0x280
   24748:	mov64 r3, r7
   24749:	call 0x88c2
   24750:	mov64 r1, r7
   24751:	ldxdw r7, [r10 - 0x260]
   24752:	jeq r7, 0x2, +0x1 <.text+0x30470>
   24753:	ja +0x9 <.text+0x304b8>
   24754:	ldxdw r7, [r10 - 0x258]
   24755:	jlt r7, r1, +0x1 <.text+0x30488>
   24756:	ja +0xa <.text+0x304d8>
   24757:	mov64 r1, r10
   24758:	add64 r1, -0x3e0
   24759:	call 0x26b
   24760:	ldxdw r1, [r10 - 0x3d8]
   24761:	ldxdw r7, [r10 - 0x3e0]
   24762:	ja +0x1 <.text+0x304c0>
   24763:	ldxdw r1, [r10 - 0x258]
   24764:	stxdw [r6 + 0x8], r1
   24765:	stxdw [r6 + 0x0], r7
   24766:	exit
   24767:	ldxdw r1, [r10 - 0x418]
   24768:	jgt r7, r1, +0x88 <.text+0x30928>
   24769:	ldxdw r1, [r8 + 0x18]
   24770:	ldxdw r2, [r1 + 0x58]
   24771:	mov64 r1, r10
   24772:	add64 r1, -0x260
   24773:	call -0x4497
   24774:	ldxdw r1, [r8 + 0x58]
   24775:	ldxdw r2, [r1 + 0x0]
   24776:	ldxdw r1, [r10 - 0x248]
   24777:	mov64 r3, 0x20
   24778:	call 0x1d251
   24779:	ldxdw r1, [r10 - 0x250]
   24780:	ldxdw r2, [r10 - 0x258]
   24781:	ldxdw r3, [r2 + 0x0]
   24782:	add64 r3, -0x1
   24783:	stxdw [r2 + 0x0], r3
   24784:	jne r3, 0x0, +0x3 <.text+0x30580>
   24785:	ldxdw r3, [r2 + 0x8]
   24786:	add64 r3, -0x1
   24787:	stxdw [r2 + 0x8], r3
   24788:	ldxdw r2, [r1 + 0x0]
   24789:	add64 r2, -0x1
   24790:	stxdw [r1 + 0x0], r2
   24791:	jne r2, 0x0, +0x3 <.text+0x305b8>
   24792:	ldxdw r2, [r1 + 0x8]
   24793:	add64 r2, -0x1
   24794:	stxdw [r1 + 0x8], r2
   24795:	stxdw [r10 - 0x460], r7
   24796:	lsh64 r0, 0x20
   24797:	rsh64 r0, 0x20
   24798:	mov64 r1, 0x58
   24799:	jeq r0, 0x0, +0x1 <.text+0x305e8>
   24800:	mov64 r1, 0x60
   24801:	mov64 r2, r8
   24802:	add64 r2, r1
   24803:	ldxdw r2, [r2 + 0x0]
   24804:	ldxdw r4, [r8 + 0x30]
   24805:	ldxdw r3, [r8 + 0x18]
   24806:	ldxdw r1, [r8 + 0x48]
   24807:	ldxdw r5, [r8 + 0x10]
   24808:	ldxdw r0, [r10 - 0x450]
   24809:	stxdw [r10 - 0xff0], r0
   24810:	stxdw [r10 - 0xff8], r5
   24811:	stxdw [r10 - 0x1000], r1
   24812:	stdw [r10 - 0xfe8], 0x8
   24813:	stdw [r10 - 0xfe0], 0x0
   24814:	mov64 r1, r10
   24815:	add64 r1, -0x2e0
   24816:	mov64 r5, r10
   24817:	call 0x8405
   24818:	ldxdw r7, [r10 - 0x2e0]
   24819:	jeq r7, 0x2, +0x1 <.text+0x30688>
   24820:	ja +0x75 <.text+0x30a30>
   24821:	ldxdw r1, [r8 + 0x20]
   24822:	ldxdw r2, [r1 + 0x58]
   24823:	mov64 r1, r10
   24824:	add64 r1, -0x260
   24825:	call -0x44cb
   24826:	ldxdw r1, [r8 + 0x58]
   24827:	ldxdw r2, [r1 + 0x0]
   24828:	ldxdw r1, [r10 - 0x248]
   24829:	mov64 r3, 0x20
   24830:	call 0x1d21d
   24831:	ldxdw r1, [r10 - 0x250]
   24832:	ldxdw r2, [r10 - 0x258]
   24833:	ldxdw r3, [r2 + 0x0]
   24834:	add64 r3, -0x1
   24835:	stxdw [r2 + 0x0], r3
   24836:	jne r3, 0x0, +0x3 <.text+0x30720>
   24837:	ldxdw r3, [r2 + 0x8]
   24838:	add64 r3, -0x1
   24839:	stxdw [r2 + 0x8], r3
   24840:	ldxdw r2, [r1 + 0x0]
   24841:	add64 r2, -0x1
   24842:	stxdw [r1 + 0x0], r2
   24843:	jne r2, 0x0, +0x3 <.text+0x30758>
   24844:	ldxdw r2, [r1 + 0x8]
   24845:	add64 r2, -0x1
   24846:	stxdw [r1 + 0x8], r2
   24847:	lsh64 r0, 0x20
   24848:	rsh64 r0, 0x20
   24849:	mov64 r1, 0x58
   24850:	jeq r0, 0x0, +0x1 <.text+0x30780>
   24851:	mov64 r1, 0x60
   24852:	mov64 r2, r8
   24853:	add64 r2, r1
   24854:	ldxdw r2, [r2 + 0x0]
   24855:	ldxdw r4, [r8 + 0x38]
   24856:	ldxdw r3, [r8 + 0x20]
   24857:	ldxdw r1, [r8 + 0x50]
   24858:	ldxdw r5, [r8 + 0x10]
   24859:	ldxdw r0, [r10 - 0x460]
   24860:	stxdw [r10 - 0xff0], r0
   24861:	stxdw [r10 - 0xff8], r5
   24862:	stxdw [r10 - 0x1000], r1
   24863:	stdw [r10 - 0xfe8], 0x8
   24864:	stdw [r10 - 0xfe0], 0x0
   24865:	mov64 r1, r10
   24866:	add64 r1, -0x2f0
   24867:	mov64 r5, r10
   24868:	call 0x83d2
   24869:	ldxdw r7, [r10 - 0x2f0]
   24870:	jeq r7, 0x2, +0x1 <.text+0x30820>
   24871:	ja +0x44 <.text+0x30a40>
   24872:	mov64 r2, r8
   24873:	add64 r2, 0x60
   24874:	ldxdw r4, [r8 + 0x40]
   24875:	ldxdw r3, [r8 + 0x28]
   24876:	ldxdw r1, [r8 + 0x0]
   24877:	ldxdw r5, [r10 - 0x408]
   24878:	stxdw [r10 - 0x1000], r5
   24879:	stxdw [r10 - 0xff8], r1
   24880:	mov64 r1, r10
   24881:	add64 r1, -0x300
   24882:	mov64 r5, r10
   24883:	call 0x84ef
   24884:	ldxdw r7, [r10 - 0x300]
   24885:	jeq r7, 0x2, +0x1 <.text+0x30898>
   24886:	ja +0x38 <.text+0x30a58>
   24887:	ldxdw r1, [r8 + 0x0]
   24888:	ldxdw r4, [r1 + 0xf8]
   24889:	mov64 r2, r4
   24890:	ldxdw r3, [r10 - 0x408]
   24891:	add64 r2, r3
   24892:	mov64 r3, 0x1
   24893:	jlt r2, r4, +0x1 <.text+0x308d8>
   24894:	mov64 r3, 0x0
   24895:	and64 r3, 0x1
   24896:	jne r3, 0x0, +0x1 <.text+0x308f0>
   24897:	ja +0x30 <.text+0x30a70>
   24898:	mov64 r1, r10
   24899:	add64 r1, -0x3b0
   24900:	call 0x21f
   24901:	ldxdw r1, [r10 - 0x3a8]
   24902:	ldxdw r7, [r10 - 0x3b0]
   24903:	ldxdw r6, [r10 - 0x420]
   24904:	ja -0x8d <.text+0x304c0>
   24905:	mov64 r1, r10
   24906:	add64 r1, -0x240
   24907:	lddw r2, 0x11bf74
   24909:	call 0x8931
   24910:	mov64 r1, r10
   24911:	add64 r1, -0x228
   24912:	lddw r2, 0x11bf74
   24914:	call -0x505f
   24915:	lddw r1, 0x11cc2b
   24917:	stxdw [r10 - 0x258], r1
   24918:	stb [r10 - 0x210], 0x2
   24919:	stw [r10 - 0x248], 0x64
   24920:	stdw [r10 - 0x250], 0x37
   24921:	stdw [r10 - 0x260], 0x0
   24922:	stw [r10 - 0x1c8], 0x1774
   24923:	mov64 r1, r10
   24924:	add64 r1, -0x3c0
   24925:	mov64 r2, r10
   24926:	add64 r2, -0x260
   24927:	call 0x1a497
   24928:	ldxdw r3, [r10 - 0x3b8]
   24929:	ldxdw r2, [r10 - 0x3c0]
   24930:	mov64 r1, r10
   24931:	add64 r1, -0x3d0
   24932:	ldxdw r4, [r10 - 0x418]
   24933:	mov64 r5, r7
   24934:	call -0x5e5f
   24935:	ldxdw r1, [r10 - 0x3c8]
   24936:	ldxdw r7, [r10 - 0x3d0]
   24937:	ja -0xae <.text+0x304c0>
   24938:	ldxdw r1, [r10 - 0x2d8]
   24939:	ja -0xb0 <.text+0x304c0>
   24940:	ldxdw r1, [r10 - 0x2e8]
   24941:	ldxdw r6, [r10 - 0x420]
   24942:	ja -0xb3 <.text+0x304c0>
   24943:	ldxdw r1, [r10 - 0x2f8]
   24944:	ldxdw r6, [r10 - 0x420]
   24945:	ja -0xb6 <.text+0x304c0>
   24946:	stxdw [r1 + 0xf8], r2
   24947:	ldxdw r1, [r8 + 0x0]
   24948:	add64 r1, 0x8
   24949:	call 0x76d3
   24950:	jne r0, 0x0, +0x1 <.text+0x30aa0>
   24951:	ja +0x6d <.text+0x30e08>
   24952:	ldxdw r2, [r8 + 0x0]
   24953:	add64 r2, 0x8
   24954:	mov64 r1, r10
   24955:	add64 r1, -0x260
   24956:	call 0x766d
   24957:	ldxdw r7, [r10 - 0x258]
   24958:	ldxdw r1, [r10 - 0x260]
   24959:	jeq r1, 0x0, +0x3 <.text+0x30af8>
   24960:	ldxdw r1, [r10 - 0x250]
   24961:	ldxdw r6, [r10 - 0x420]
   24962:	ja -0xc7 <.text+0x304c0>
   24963:	ldxdw r2, [r10 - 0x250]
   24964:	jsgt r2, -0x1, +0x1 <.text+0x30b10>
   24965:	ja +0x41 <.text+0x30d18>
   24966:	mov64 r1, r10
   24967:	add64 r1, -0x330
   24968:	mov64 r3, 0x0
   24969:	ldxdw r6, [r10 - 0x408]
   24970:	mov64 r4, r6
   24971:	mov64 r5, 0x0
   24972:	call 0x1d579
   24973:	mov64 r1, r10
   24974:	add64 r1, -0x320
   24975:	mov64 r2, r7
   24976:	mov64 r3, 0x0
   24977:	mov64 r4, r6
   24978:	mov64 r5, 0x0
   24979:	call 0x1d572
   24980:	mov64 r2, 0x1
   24981:	ldxdw r3, [r10 - 0x328]
   24982:	mov64 r1, 0x1
   24983:	jne r3, 0x0, +0x1 <.text+0x30ba8>
   24984:	mov64 r1, 0x0
   24985:	ldxdw r4, [r10 - 0x330]
   24986:	ldxdw r5, [r10 - 0x318]
   24987:	mov64 r3, r5
   24988:	add64 r3, r4
   24989:	jlt r3, r5, +0x1 <.text+0x30bd8>
   24990:	mov64 r2, 0x0
   24991:	or64 r1, r2
   24992:	and64 r1, 0x1
   24993:	jne r1, 0x0, +0x2c <.text+0x30d50>
   24994:	ldxdw r1, [r10 - 0x448]
   24995:	jeq r1, 0x0, +0x31 <.text+0x30d88>
   24996:	ldxdw r2, [r10 - 0x320]
   24997:	mov64 r1, r10
   24998:	add64 r1, -0x340
   24999:	ldxdw r4, [r10 - 0x448]
   25000:	mov64 r5, 0x0
   25001:	call 0x1d2b4
   25002:	ldxdw r3, [r10 - 0x338]
   25003:	jslt r3, 0x0, +0x30 <.text+0x30dc0>
   25004:	ldxdw r1, [r8 + 0x0]
   25005:	ldxdw r4, [r10 - 0x340]
   25006:	ldxdw r0, [r1 + 0xe8]
   25007:	mov64 r2, r0
   25008:	add64 r2, r4
   25009:	mov64 r5, 0x1
   25010:	jlt r2, r0, +0x1 <.text+0x30c80>
   25011:	mov64 r5, 0x0
   25012:	ldxdw r0, [r1 + 0xf0]
   25013:	mov64 r4, r0
   25014:	add64 r4, r3
   25015:	add64 r4, r5
   25016:	mov64 r5, r0
   25017:	xor64 r5, r3
   25018:	xor64 r0, r4
   25019:	xor64 r5, -0x1
   25020:	and64 r5, r0
   25021:	jslt r5, 0x0, +0x0 <.text+0x30cd0>
   25022:	jslt r5, 0x0, +0x1 <.text+0x30ce0>
   25023:	ja +0x23 <.text+0x30df8>
   25024:	mov64 r1, r10
   25025:	add64 r1, -0x370
   25026:	call 0x2e6
   25027:	ldxdw r1, [r10 - 0x368]
   25028:	ldxdw r7, [r10 - 0x370]
   25029:	ldxdw r6, [r10 - 0x420]
   25030:	ja -0x10b <.text+0x304c0>
   25031:	mov64 r1, r10
   25032:	add64 r1, -0x310
   25033:	call 0x1db
   25034:	ldxdw r1, [r10 - 0x308]
   25035:	ldxdw r7, [r10 - 0x310]
   25036:	ldxdw r6, [r10 - 0x420]
   25037:	ja -0x112 <.text+0x304c0>
   25038:	mov64 r1, r10
   25039:	add64 r1, -0x3a0
   25040:	call 0x215
   25041:	ldxdw r1, [r10 - 0x398]
   25042:	ldxdw r7, [r10 - 0x3a0]
   25043:	ldxdw r6, [r10 - 0x420]
   25044:	ja -0x119 <.text+0x304c0>
   25045:	mov64 r1, r10
   25046:	add64 r1, -0x390
   25047:	call 0x24f
   25048:	ldxdw r1, [r10 - 0x388]
   25049:	ldxdw r7, [r10 - 0x390]
   25050:	ldxdw r6, [r10 - 0x420]
   25051:	ja -0x120 <.text+0x304c0>
   25052:	mov64 r1, r10
   25053:	add64 r1, -0x380
   25054:	call 0x289
   25055:	ldxdw r1, [r10 - 0x378]
   25056:	ldxdw r7, [r10 - 0x380]
   25057:	ldxdw r6, [r10 - 0x420]
   25058:	ja -0x127 <.text+0x304c0>
   25059:	stxdw [r1 + 0xe8], r2
   25060:	stxdw [r1 + 0xf0], r4
   25061:	mov64 r1, r10
   25062:	add64 r1, -0xd0
   25063:	call 0x1abdf
   25064:	ldxdw r1, [r10 - 0xd0]
   25065:	jeq r1, 0x0, +0xf <.text+0x30ea8>
   25066:	ldxdw r1, [r10 - 0xc8]
   25067:	ldxdw r2, [r10 - 0xc0]
   25068:	ldxdw r3, [r10 - 0xb8]
   25069:	stxdw [r10 - 0xc0], r3
   25070:	stxdw [r10 - 0xc8], r2
   25071:	stxdw [r10 - 0xd0], r1
   25072:	mov64 r1, r10
   25073:	add64 r1, -0x350
   25074:	mov64 r2, r10
   25075:	add64 r2, -0xd0
   25076:	call 0x1a413
   25077:	ldxdw r1, [r10 - 0x348]
   25078:	ldxdw r7, [r10 - 0x350]
   25079:	ldxdw r6, [r10 - 0x420]
   25080:	ja -0x13d <.text+0x304c0>
   25081:	ldxdw r0, [r10 - 0x458]
   25082:	ldxdw r6, [r10 - 0x460]
   25083:	sub64 r6, r0
   25084:	ldxdw r1, [r10 - 0xa8]
   25085:	ldxdw r2, [r8 + 0x0]
   25086:	ldxdw r2, [r2 + 0x0]
   25087:	ldxdw r2, [r2 + 0x0]
   25088:	ldxdw r3, [r2 + 0x18]
   25089:	stxdw [r10 - 0x248], r3
   25090:	ldxdw r3, [r2 + 0x10]
   25091:	stxdw [r10 - 0x250], r3
   25092:	ldxdw r3, [r2 + 0x8]
   25093:	stxdw [r10 - 0x258], r3
   25094:	ldxdw r2, [r2 + 0x0]
   25095:	stxdw [r10 - 0x260], r2
   25096:	ldxdw r2, [r8 + 0x10]
   25097:	ldxdw r2, [r2 + 0x0]
   25098:	ldxdw r3, [r2 + 0x18]
   25099:	stxdw [r10 - 0x228], r3
   25100:	ldxdw r3, [r2 + 0x10]
   25101:	stxdw [r10 - 0x230], r3
   25102:	ldxdw r3, [r2 + 0x8]
   25103:	stxdw [r10 - 0x238], r3
   25104:	ldxdw r2, [r2 + 0x0]
   25105:	stxdw [r10 - 0x240], r2
   25106:	ldxdw r2, [r8 + 0x30]
   25107:	ldxdw r2, [r2 + 0x20]
   25108:	ldxdw r2, [r2 + 0x0]
   25109:	ldxdw r3, [r2 + 0x18]
   25110:	stxdw [r10 - 0x208], r3
   25111:	ldxdw r3, [r2 + 0x10]
   25112:	stxdw [r10 - 0x210], r3
   25113:	ldxdw r3, [r2 + 0x8]
   25114:	stxdw [r10 - 0x218], r3
   25115:	ldxdw r2, [r2 + 0x0]
   25116:	stxdw [r10 - 0x220], r2
   25117:	ldxdw r2, [r8 + 0x38]
   25118:	ldxdw r2, [r2 + 0x20]
   25119:	ldxdw r2, [r2 + 0x0]
   25120:	ldxdw r3, [r2 + 0x18]
   25121:	stxdw [r10 - 0x1e8], r3
   25122:	ldxdw r3, [r2 + 0x10]
   25123:	stxdw [r10 - 0x1f0], r3
   25124:	ldxdw r3, [r2 + 0x8]
   25125:	stxdw [r10 - 0x1f8], r3
   25126:	ldxdw r2, [r2 + 0x0]
   25127:	stxdw [r10 - 0x200], r2
   25128:	ldxdw r2, [r8 + 0x40]
   25129:	ldxdw r2, [r2 + 0x20]
   25130:	ldxdw r2, [r2 + 0x0]
   25131:	ldxdw r3, [r2 + 0x0]
   25132:	ldxdw r4, [r2 + 0x8]
   25133:	ldxdw r5, [r2 + 0x10]
   25134:	ldxdw r2, [r2 + 0x18]
   25135:	stxdw [r10 - 0x1c0], r1
   25136:	ldxdw r1, [r10 - 0x408]
   25137:	stxdw [r10 - 0x1b8], r1
   25138:	ldxdw r1, [r10 - 0x410]
   25139:	stxdw [r10 - 0x1b0], r1
   25140:	ldxdw r1, [r10 - 0x418]
   25141:	stxdw [r10 - 0x1a8], r1
   25142:	ldxdw r1, [r10 - 0x440]
   25143:	stxdw [r10 - 0x1a0], r1
   25144:	ldxdw r1, [r10 - 0x430]
   25145:	stxdw [r10 - 0x198], r1
   25146:	stxdw [r10 - 0x190], r9
   25147:	ldxdw r1, [r10 - 0x438]
   25148:	stxdw [r10 - 0x188], r1
   25149:	ldxdw r1, [r10 - 0x450]
   25150:	stxdw [r10 - 0x180], r1
   25151:	stxdw [r10 - 0x178], r0
   25152:	ldxdw r1, [r10 - 0x448]
   25153:	stxdw [r10 - 0x170], r1
   25154:	stxdw [r10 - 0x168], r6
   25155:	stxdw [r10 - 0x1c8], r2
   25156:	stxdw [r10 - 0x1d0], r5
   25157:	stxdw [r10 - 0x1d8], r4
   25158:	stxdw [r10 - 0x1e0], r3
   25159:	mov64 r1, r10
   25160:	add64 r1, -0xd0
   25161:	mov64 r9, r10
   25162:	add64 r9, -0x260
   25163:	mov64 r2, r9
   25164:	call 0xed61
   25165:	ldxdw r1, [r10 - 0xc0]
   25166:	stxdw [r10 - 0x60], r1
   25167:	ldxdw r1, [r10 - 0xc8]
   25168:	stxdw [r10 - 0x68], r1
   25169:	mov64 r1, r10
   25170:	add64 r1, -0x68
   25171:	mov64 r2, 0x1
   25172:	call 0x1aafb
   25173:	add64 r8, 0x68
   25174:	mov64 r6, r10
   25175:	add64 r6, -0x160
   25176:	mov64 r1, r6
   25177:	mov64 r2, r8
   25178:	call -0x462c
   25179:	ldxdw r1, [r10 - 0x428]
   25180:	ldxb r1, [r1 + 0x20]
   25181:	stxdw [r10 - 0x408], r1
   25182:	mov64 r1, r10
   25183:	add64 r1, -0x130
   25184:	mov64 r2, r9
   25185:	call 0xed4c
   25186:	lddw r1, 0x11c606
   25188:	lddw r2, 0x11c606
   25190:	add64 r2, 0x8
   25191:	stxdw [r10 - 0xd8], r2
   25192:	stxdw [r10 - 0xe0], r1
   25193:	ldxdw r1, [r10 - 0x130]
   25194:	stxdw [r10 - 0xf0], r1
   25195:	ldxdw r1, [r10 - 0x128]
   25196:	stxdw [r10 - 0xf8], r1
   25197:	stxdw [r10 - 0x100], r1
   25198:	ldxdw r2, [r10 - 0x120]
   25199:	add64 r1, r2
   25200:	stxdw [r10 - 0xe8], r1
   25201:	mov64 r1, r10
   25202:	add64 r1, -0x118
   25203:	mov64 r2, r10
   25204:	add64 r2, -0x100
   25205:	call -0x42bd
   25206:	ldxdw r9, [r10 - 0x110]
   25207:	ldxdw r7, [r10 - 0x108]
   25208:	mov64 r1, 0x22
   25209:	mov64 r2, 0x1
   25210:	call -0x4c4e
   25211:	ldxdw r1, [r10 - 0x160]
   25212:	ldxdw r2, [r1 + 0x18]
   25213:	ldxdw r3, [r1 + 0x10]
   25214:	ldxdw r4, [r1 + 0x8]
   25215:	ldxdw r1, [r1 + 0x0]
   25216:	stxdw [r0 + 0x0], r1
   25217:	stxdw [r0 + 0x8], r4
   25218:	stxdw [r0 + 0x10], r3
   25219:	stxdw [r0 + 0x18], r2
   25220:	sth [r0 + 0x20], 0x1
   25221:	stxdw [r10 - 0x60], r0
   25222:	stdw [r10 - 0x68], 0x1
   25223:	stdw [r10 - 0x58], 0x1
   25224:	mov64 r8, r10
   25225:	add64 r8, -0xd0
   25226:	mov64 r5, r10
   25227:	add64 r5, -0x68
   25228:	mov64 r1, r8
   25229:	lddw r2, 0x11e53e
   25231:	mov64 r3, r9
   25232:	mov64 r4, r7
   25233:	call 0x1b8d8
   25234:	mov64 r7, r10
   25235:	add64 r7, -0x68
   25236:	mov64 r1, r7
   25237:	mov64 r2, r6
   25238:	mov64 r3, 0x30
   25239:	call 0x1d07b
   25240:	mov64 r1, r10
   25241:	add64 r1, -0x28
   25242:	stxdw [r10 - 0x38], r1
   25243:	mov64 r1, r10
   25244:	add64 r1, -0x1
   25245:	stxdw [r10 - 0x18], r1
   25246:	lddw r1, 0x11c646
   25248:	stxdw [r10 - 0x28], r1
   25249:	ldxdw r1, [r10 - 0x408]
   25250:	stxb [r10 - 0x1], r1
   25251:	stdw [r10 - 0x30], 0x2
   25252:	stdw [r10 - 0x10], 0x1
   25253:	stdw [r10 - 0x20], 0x11
   25254:	mov64 r1, r10
   25255:	add64 r1, -0x38
   25256:	stxdw [r10 - 0x1000], r1
   25257:	stdw [r10 - 0xff8], 0x1
   25258:	mov64 r1, r10
   25259:	add64 r1, -0x80
   25260:	mov64 r5, r10
   25261:	mov64 r2, r8
   25262:	mov64 r3, r7
   25263:	mov64 r4, 0x1
   25264:	call 0x1aaa6
   25265:	lddw r1, -0x7fffffffffffffe6
   25267:	ldxdw r2, [r10 - 0x80]
   25268:	jeq r2, r1, +0x1 <.text+0x31490>
   25269:	ja +0x13 <.text+0x31528>
   25270:	ldxdw r1, [r10 - 0x58]
   25271:	ldxdw r2, [r10 - 0x60]
   25272:	ldxdw r3, [r2 + 0x0]
   25273:	add64 r3, -0x1
   25274:	stxdw [r2 + 0x0], r3
   25275:	jne r3, 0x0, +0x3 <.text+0x314d8>
   25276:	ldxdw r3, [r2 + 0x8]
   25277:	add64 r3, -0x1
   25278:	stxdw [r2 + 0x8], r3
   25279:	ldxdw r2, [r1 + 0x0]
   25280:	add64 r2, -0x1
   25281:	stxdw [r1 + 0x0], r2
   25282:	jne r2, 0x0, +0x3 <.text+0x31510>
   25283:	ldxdw r2, [r1 + 0x8]
   25284:	add64 r2, -0x1
   25285:	stxdw [r1 + 0x8], r2
   25286:	mov64 r7, 0x2
   25287:	ldxdw r6, [r10 - 0x420]
   25288:	ja -0x20d <.text+0x304c0>
   25289:	mov64 r1, r10
   25290:	add64 r1, -0x360
   25291:	mov64 r2, r10
   25292:	add64 r2, -0x80
   25293:	call 0x1a33a
   25294:	ldxdw r1, [r10 - 0x358]
   25295:	ldxdw r7, [r10 - 0x360]
   25296:	ldxdw r2, [r10 - 0x58]
   25297:	ldxdw r3, [r10 - 0x60]
   25298:	ldxdw r4, [r3 + 0x0]
   25299:	add64 r4, -0x1
   25300:	stxdw [r3 + 0x0], r4
   25301:	jne r4, 0x0, +0x3 <.text+0x315a8>
   25302:	ldxdw r4, [r3 + 0x8]
   25303:	add64 r4, -0x1
   25304:	stxdw [r3 + 0x8], r4
   25305:	ldxdw r3, [r2 + 0x0]
   25306:	add64 r3, -0x1
   25307:	stxdw [r2 + 0x0], r3
   25308:	jne r3, 0x0, -0xe6 <.text+0x30e98>
   25309:	ldxdw r3, [r2 + 0x8]
   25310:	add64 r3, -0x1
   25311:	stxdw [r2 + 0x8], r3
   25312:	ldxdw r6, [r10 - 0x420]
   25313:	ja -0x226 <.text+0x304c0>
