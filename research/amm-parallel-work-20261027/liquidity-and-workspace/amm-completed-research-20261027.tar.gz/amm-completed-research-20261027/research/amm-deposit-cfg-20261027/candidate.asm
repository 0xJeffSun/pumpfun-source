
work/amm-deposit-borrow-captures-20261027/build/artifacts/unstripped.so:	file format elf64-sbf

Disassembly of section .text:

00000000000c56c8 <_ZN18pump_amm_recovered18pump_amm_recovered7deposit17hf8ed615aa5ad40e9E>:
  101081:	mov64 r6, r1
  101082:	ldxdw r8, [r2 + 0x8]
  101083:	ldxdw r1, [r8 + 0x8]
  101084:	ldxb r1, [r1 + 0x3b0]
  101085:	and64 r1, 0x2
  101086:	jeq r1, 0x0, +0x22 <LBB742_4>
  101087:	mov64 r1, r10
  101088:	add64 r1, -0x100
  101089:	lddw r2, 0x1257c0
  101091:	call 0x4589
  101092:	stdw [r10 - 0x58], 0x0
  101093:	stdw [r10 - 0x60], 0x1
  101094:	stdw [r10 - 0x68], 0x0
  101095:	lddw r1, 0x12b698
  101097:	stxdw [r10 - 0xa8], r1
  101098:	mov64 r1, r10
  101099:	add64 r1, -0x68
  101100:	stxdw [r10 - 0xb0], r1
  101101:	stb [r10 - 0x98], 0x3
  101102:	stdw [r10 - 0xa0], 0x20
  101103:	stdw [r10 - 0xc0], 0x0
  101104:	stdw [r10 - 0xd0], 0x0
  101105:	mov64 r2, r10
  101106:	add64 r2, -0xd0
  101107:	lddw r1, 0x1257c0
  101109:	call 0x506c
  101110:	jeq r0, 0x0, +0x3a <LBB742_3>

00000000000c57b8 <LBB742_2>:
  101111:	mov64 r3, r10
  101112:	add64 r3, -0x160
  101113:	lddw r1, 0x1258d8
  101115:	mov64 r2, 0x37
  101116:	lddw r4, 0x12b6c8
  101118:	lddw r5, 0x12b6e8
  101120:	call 0xad45

00000000000c5808 <LBB742_4>:
  101121:	stxdw [r10 - 0x3e8], r3
  101122:	stxdw [r10 - 0x3f8], r5
  101123:	stxdw [r10 - 0x3f0], r4
  101124:	ldxb r1, [r2 + 0x20]
  101125:	stxdw [r10 - 0x408], r1
  101126:	ldxdw r1, [r8 + 0x30]
  101127:	ldxdw r1, [r1 + 0x68]
  101128:	stxdw [r10 - 0x410], r1
  101129:	ldxdw r1, [r8 + 0x38]
  101130:	ldxdw r1, [r1 + 0x68]
  101131:	stxdw [r10 - 0x418], r1
  101132:	ldxdw r1, [r8 + 0x48]
  101133:	ldxdw r9, [r1 + 0x68]
  101134:	ldxdw r1, [r8 + 0x50]
  101135:	ldxdw r3, [r1 + 0x68]
  101136:	ldxdw r2, [r8 + 0x0]
  101137:	add64 r2, 0x8
  101138:	mov64 r1, r10
  101139:	add64 r1, -0x260
  101140:	stxdw [r10 - 0x420], r3
  101141:	call -0x162bc
  101142:	ldxdw r7, [r10 - 0x260]
  101143:	jne r7, 0x2, +0x115 <LBB742_88>
  101144:	stxdw [r10 - 0x400], r6
  101145:	mov64 r1, r10
  101146:	add64 r1, -0x280
  101147:	mov64 r2, r9
  101148:	mov64 r3, 0x0
  101149:	ldxdw r4, [r10 - 0x3e8]
  101150:	mov64 r5, 0x0
  101151:	call 0xbec9
  101152:	ldxdw r7, [r10 - 0x258]
  101153:	ldxdw r1, [r8 + 0x0]
  101154:	ldxdw r6, [r1 + 0xf8]
  101155:	mov64 r1, r10
  101156:	add64 r1, -0x260
  101157:	ldxdw r2, [r10 - 0x280]
  101158:	ldxdw r3, [r10 - 0x278]
  101159:	mov64 r4, r6
  101160:	mov64 r5, 0x0
  101161:	call -0x14a30
  101162:	ldxdw r2, [r10 - 0x258]
  101163:	ldxdw r1, [r10 - 0x260]
  101164:	jeq r1, 0x0, +0x20 <LBB742_6>
  101165:	ldxdw r1, [r10 - 0x250]
  101166:	mov64 r7, r2
  101167:	ldxdw r6, [r10 - 0x400]
  101168:	ja +0xfd <LBB742_89>

00000000000c5988 <LBB742_3>:
  101169:	ldxdw r1, [r10 - 0x58]
  101170:	stxdw [r10 - 0x218], r1
  101171:	ldxdw r1, [r10 - 0x60]
  101172:	stxdw [r10 - 0x220], r1
  101173:	ldxdw r1, [r10 - 0x68]
  101174:	stxdw [r10 - 0x228], r1
  101175:	ldxdw r1, [r10 - 0x100]
  101176:	stxdw [r10 - 0x240], r1
  101177:	ldxdw r1, [r10 - 0xf8]
  101178:	stxdw [r10 - 0x238], r1
  101179:	ldxdw r1, [r10 - 0xf0]
  101180:	stxdw [r10 - 0x230], r1
  101181:	lddw r1, 0x1258b1
  101183:	stxdw [r10 - 0x258], r1
  101184:	stw [r10 - 0x1c8], 0x1782
  101185:	stb [r10 - 0x210], 0x2
  101186:	stw [r10 - 0x248], 0x1f8
  101187:	stdw [r10 - 0x250], 0xa
  101188:	stdw [r10 - 0x260], 0x0
  101189:	mov64 r1, r10
  101190:	add64 r1, -0x270
  101191:	mov64 r2, r10
  101192:	add64 r2, -0x260
  101193:	call 0x8a92
  101194:	ldxdw r1, [r10 - 0x268]
  101195:	ldxdw r7, [r10 - 0x270]
  101196:	ja +0xe1 <LBB742_89>

00000000000c5a68 <LBB742_6>:
  101197:	stxdw [r10 - 0x428], r6
  101198:	ldxdw r1, [r10 - 0x250]
  101199:	jeq r1, 0x0, +0x36 <LBB742_8>
  101200:	mov64 r1, r10
  101201:	add64 r1, -0x100
  101202:	lddw r2, 0x12583c
  101204:	call 0x4518
  101205:	stdw [r10 - 0x58], 0x0
  101206:	stdw [r10 - 0x60], 0x1
  101207:	stdw [r10 - 0x68], 0x0
  101208:	lddw r1, 0x12b698
  101210:	stxdw [r10 - 0xa8], r1
  101211:	mov64 r1, r10
  101212:	add64 r1, -0x68
  101213:	stxdw [r10 - 0xb0], r1
  101214:	stb [r10 - 0x98], 0x3
  101215:	stdw [r10 - 0xa0], 0x20
  101216:	stdw [r10 - 0xc0], 0x0
  101217:	stdw [r10 - 0xd0], 0x0
  101218:	mov64 r2, r10
  101219:	add64 r2, -0xd0
  101220:	lddw r1, 0x12583c
  101222:	call 0x4ffb
  101223:	ldxdw r6, [r10 - 0x400]
  101224:	jeq r0, 0x0, +0x1 <LBB742_11>
  101225:	ja -0x73 <LBB742_2>

00000000000c5b50 <LBB742_11>:
  101226:	ldxdw r1, [r10 - 0x58]
  101227:	stxdw [r10 - 0x218], r1
  101228:	ldxdw r1, [r10 - 0x60]
  101229:	stxdw [r10 - 0x220], r1
  101230:	ldxdw r1, [r10 - 0x68]
  101231:	stxdw [r10 - 0x228], r1
  101232:	ldxdw r1, [r10 - 0x100]
  101233:	stxdw [r10 - 0x240], r1
  101234:	ldxdw r1, [r10 - 0xf8]
  101235:	stxdw [r10 - 0x238], r1
  101236:	ldxdw r1, [r10 - 0xf0]
  101237:	stxdw [r10 - 0x230], r1
  101238:	lddw r1, 0x1258b1
  101240:	stxdw [r10 - 0x258], r1
  101241:	stw [r10 - 0x1c8], 0x1788
  101242:	stb [r10 - 0x210], 0x2
  101243:	stw [r10 - 0x248], 0x206
  101244:	stdw [r10 - 0x250], 0xa
  101245:	stdw [r10 - 0x260], 0x0
  101246:	mov64 r1, r10
  101247:	add64 r1, -0x290
  101248:	mov64 r2, r10
  101249:	add64 r2, -0x260
  101250:	call 0x8a59
  101251:	ldxdw r1, [r10 - 0x288]
  101252:	ldxdw r7, [r10 - 0x290]
  101253:	ja +0xa8 <LBB742_89>

00000000000c5c30 <LBB742_8>:
  101254:	ldxdw r1, [r10 - 0x3f0]
  101255:	stxdw [r10 - 0x430], r2
  101256:	jgt r2, r1, +0x1 <LBB742_12>
  101257:	ja +0x1a <LBB742_15>

00000000000c5c50 <LBB742_12>:
  101258:	mov64 r1, r10
  101259:	add64 r1, -0x100
  101260:	lddw r2, 0x125738
  101262:	call 0x44de
  101263:	stdw [r10 - 0x58], 0x0
  101264:	stdw [r10 - 0x60], 0x1
  101265:	stdw [r10 - 0x68], 0x0
  101266:	lddw r1, 0x12b698
  101268:	stxdw [r10 - 0xa8], r1
  101269:	mov64 r1, r10
  101270:	add64 r1, -0x68
  101271:	stxdw [r10 - 0xb0], r1
  101272:	stb [r10 - 0x98], 0x3
  101273:	stdw [r10 - 0xa0], 0x20
  101274:	stdw [r10 - 0xc0], 0x0
  101275:	stdw [r10 - 0xd0], 0x0
  101276:	mov64 r2, r10
  101277:	add64 r2, -0xd0
  101278:	lddw r1, 0x125738
  101280:	call 0x4fc1
  101281:	ldxdw r6, [r10 - 0x400]
  101282:	jeq r0, 0x0, +0x1b <LBB742_14>
  101283:	ja -0xad <LBB742_2>

00000000000c5d20 <LBB742_15>:
  101284:	mov64 r1, r10
  101285:	add64 r1, -0x2a0
  101286:	mov64 r2, r7
  101287:	mov64 r3, 0x0
  101288:	ldxdw r4, [r10 - 0x3e8]
  101289:	mov64 r5, 0x0
  101290:	call 0xbe3e
  101291:	mov64 r1, r10
  101292:	add64 r1, -0x260
  101293:	ldxdw r2, [r10 - 0x2a0]
  101294:	ldxdw r3, [r10 - 0x298]
  101295:	ldxdw r4, [r10 - 0x428]
  101296:	mov64 r5, 0x0
  101297:	call -0x14ab8
  101298:	ldxdw r7, [r10 - 0x258]
  101299:	ldxdw r1, [r10 - 0x260]
  101300:	ldxdw r6, [r10 - 0x400]
  101301:	jne r1, 0x0, +0x2b <LBB742_17>
  101302:	ldxdw r1, [r10 - 0x250]
  101303:	jeq r1, 0x0, +0x2b <LBB742_18>
  101304:	mov64 r1, r10
  101305:	add64 r1, -0x2b0
  101306:	call -0xe516
  101307:	ldxdw r1, [r10 - 0x2a8]
  101308:	ldxdw r7, [r10 - 0x2b0]
  101309:	ja +0x70 <LBB742_89>

00000000000c5df0 <LBB742_14>:
  101310:	ldxdw r1, [r10 - 0x58]
  101311:	stxdw [r10 - 0x218], r1
  101312:	ldxdw r1, [r10 - 0x60]
  101313:	stxdw [r10 - 0x220], r1
  101314:	ldxdw r1, [r10 - 0x68]
  101315:	stxdw [r10 - 0x228], r1
  101316:	ldxdw r1, [r10 - 0x100]
  101317:	stxdw [r10 - 0x240], r1
  101318:	ldxdw r1, [r10 - 0xf8]
  101319:	stxdw [r10 - 0x238], r1
  101320:	ldxdw r1, [r10 - 0xf0]
  101321:	stxdw [r10 - 0x230], r1
  101322:	lddw r1, 0x1258b1
  101324:	stxdw [r10 - 0x258], r1
  101325:	stw [r10 - 0x1c8], 0x1774
  101326:	stb [r10 - 0x210], 0x2
  101327:	stw [r10 - 0x248], 0x20c
  101328:	stdw [r10 - 0x250], 0xa
  101329:	stdw [r10 - 0x260], 0x0
  101330:	mov64 r1, r10
  101331:	add64 r1, -0x3d0
  101332:	mov64 r2, r10
  101333:	add64 r2, -0x260
  101334:	call 0x8a05
  101335:	ldxdw r3, [r10 - 0x3c8]
  101336:	ldxdw r2, [r10 - 0x3d0]
  101337:	mov64 r1, r10
  101338:	add64 r1, -0x3e0
  101339:	ldxdw r4, [r10 - 0x3f0]
  101340:	ldxdw r5, [r10 - 0x430]
  101341:	call -0x18acf
  101342:	ldxdw r1, [r10 - 0x3d8]
  101343:	ldxdw r7, [r10 - 0x3e0]
  101344:	ja +0x4d <LBB742_89>

00000000000c5f08 <LBB742_17>:
  101345:	ldxdw r1, [r10 - 0x250]
  101346:	ja +0x4b <LBB742_89>

00000000000c5f18 <LBB742_18>:
  101347:	stxdw [r10 - 0x438], r7
  101348:	ldxdw r1, [r8 + 0x20]
  101349:	ldxdw r2, [r1 + 0x58]
  101350:	mov64 r7, r10
  101351:	add64 r7, -0x260
  101352:	mov64 r1, r7
  101353:	call -0x16f88
  101354:	mov64 r1, r10
  101355:	add64 r1, -0xd0
  101356:	mov64 r2, r7
  101357:	call -0x14336
  101358:	ldxdw r1, [r10 - 0xc0]
  101359:	ldxdw r7, [r10 - 0xc8]
  101360:	ldxdw r2, [r10 - 0xd0]
  101361:	jeq r2, 0x2, +0x1 <LBB742_25>
  101362:	ja +0x11 <LBB742_20>

00000000000c5f98 <LBB742_25>:
  101363:	ldxdw r2, [r10 - 0x250]
  101364:	ldxdw r3, [r10 - 0x258]
  101365:	ldxdw r4, [r3 + 0x0]
  101366:	add64 r4, -0x1
  101367:	stxdw [r3 + 0x0], r4
  101368:	jne r4, 0x0, +0x3 <LBB742_27>
  101369:	ldxdw r4, [r3 + 0x8]
  101370:	add64 r4, -0x1
  101371:	stxdw [r3 + 0x8], r4

00000000000c5fe0 <LBB742_27>:
  101372:	ldxdw r3, [r2 + 0x0]
  101373:	add64 r3, -0x1
  101374:	stxdw [r2 + 0x0], r3
  101375:	jne r3, 0x0, +0x2e <LBB742_89>
  101376:	ldxdw r3, [r2 + 0x8]
  101377:	add64 r3, -0x1
  101378:	stxdw [r2 + 0x8], r3
  101379:	ja +0x2a <LBB742_89>

00000000000c6020 <LBB742_20>:
  101380:	ldxdw r3, [r10 - 0xb8]
  101381:	stxdw [r10 - 0x50], r3
  101382:	stxdw [r10 - 0x58], r1
  101383:	stxdw [r10 - 0x60], r7
  101384:	stxdw [r10 - 0x68], r2
  101385:	ldxdw r1, [r10 - 0x250]
  101386:	ldxdw r2, [r10 - 0x258]
  101387:	ldxdw r3, [r2 + 0x0]
  101388:	add64 r3, -0x1
  101389:	stxdw [r2 + 0x0], r3
  101390:	jne r3, 0x0, +0x3 <LBB742_22>
  101391:	ldxdw r3, [r2 + 0x8]
  101392:	add64 r3, -0x1
  101393:	stxdw [r2 + 0x8], r3

00000000000c6090 <LBB742_22>:
  101394:	ldxdw r2, [r1 + 0x0]
  101395:	add64 r2, -0x1
  101396:	stxdw [r1 + 0x0], r2
  101397:	ldxdw r7, [r10 - 0x438]
  101398:	jne r2, 0x0, +0x3 <LBB742_24>
  101399:	ldxdw r2, [r1 + 0x8]
  101400:	add64 r2, -0x1
  101401:	stxdw [r1 + 0x8], r2

00000000000c60d0 <LBB742_24>:
  101402:	mov64 r1, r10
  101403:	add64 r1, -0x260
  101404:	mov64 r2, r10
  101405:	add64 r2, -0x68
  101406:	mov64 r3, r7
  101407:	call -0x1421d
  101408:	mov64 r1, r7
  101409:	ldxdw r7, [r10 - 0x260]
  101410:	jeq r7, 0x2, +0x1 <LBB742_29>
  101411:	ja +0x9 <LBB742_88>

00000000000c6120 <LBB742_29>:
  101412:	ldxdw r7, [r10 - 0x258]
  101413:	jlt r7, r1, +0x1 <LBB742_30>
  101414:	ja +0xa <LBB742_31>

00000000000c6138 <LBB742_30>:
  101415:	mov64 r1, r10
  101416:	add64 r1, -0x3c0
  101417:	call -0xe503
  101418:	ldxdw r1, [r10 - 0x3b8]
  101419:	ldxdw r7, [r10 - 0x3c0]
  101420:	ja +0x1 <LBB742_89>

00000000000c6168 <LBB742_88>:
  101421:	ldxdw r1, [r10 - 0x258]

00000000000c6170 <LBB742_89>:
  101422:	stxdw [r6 + 0x8], r1
  101423:	stxdw [r6 + 0x0], r7
  101424:	exit

00000000000c6188 <LBB742_31>:
  101425:	ldxdw r1, [r10 - 0x3f8]
  101426:	jle r7, r1, +0x21 <LBB742_33>
  101427:	mov64 r1, r10
  101428:	add64 r1, -0x240
  101429:	lddw r2, 0x125738
  101431:	call 0x4435
  101432:	mov64 r1, r10
  101433:	add64 r1, -0x228
  101434:	lddw r2, 0x125738
  101436:	call -0x17a16
  101437:	lddw r1, 0x1258b1
  101439:	stxdw [r10 - 0x258], r1
  101440:	stb [r10 - 0x210], 0x2
  101441:	stw [r10 - 0x248], 0x224
  101442:	stdw [r10 - 0x250], 0xa
  101443:	stdw [r10 - 0x260], 0x0
  101444:	stw [r10 - 0x1c8], 0x1774
  101445:	mov64 r1, r10
  101446:	add64 r1, -0x3a0
  101447:	mov64 r2, r10
  101448:	add64 r2, -0x260
  101449:	call 0x8992
  101450:	ldxdw r3, [r10 - 0x398]
  101451:	ldxdw r2, [r10 - 0x3a0]
  101452:	mov64 r1, r10
  101453:	add64 r1, -0x3b0
  101454:	ldxdw r4, [r10 - 0x3f8]
  101455:	mov64 r5, r7
  101456:	call -0x18b42
  101457:	ldxdw r1, [r10 - 0x3a8]
  101458:	ldxdw r7, [r10 - 0x3b0]
  101459:	ja -0x26 <LBB742_89>

00000000000c62a0 <LBB742_33>:
  101460:	ldxdw r1, [r8 + 0x18]
  101461:	ldxdw r2, [r1 + 0x58]
  101462:	mov64 r1, r10
  101463:	add64 r1, -0x260
  101464:	call -0x16ff7
  101465:	ldxdw r1, [r10 - 0x248]
  101466:	lddw r2, 0x125510
  101468:	mov64 r3, 0x20
  101469:	call 0xb911
  101470:	ldxdw r1, [r10 - 0x250]
  101471:	ldxdw r2, [r10 - 0x258]
  101472:	ldxdw r3, [r2 + 0x0]
  101473:	add64 r3, -0x1
  101474:	stxdw [r2 + 0x0], r3
  101475:	jne r3, 0x0, +0x3 <LBB742_35>
  101476:	ldxdw r3, [r2 + 0x8]
  101477:	add64 r3, -0x1
  101478:	stxdw [r2 + 0x8], r3

00000000000c6338 <LBB742_35>:
  101479:	ldxdw r2, [r1 + 0x0]
  101480:	add64 r2, -0x1
  101481:	stxdw [r1 + 0x0], r2
  101482:	jne r2, 0x0, +0x3 <LBB742_37>
  101483:	ldxdw r2, [r1 + 0x8]
  101484:	add64 r2, -0x1
  101485:	stxdw [r1 + 0x8], r2

00000000000c6370 <LBB742_37>:
  101486:	stxdw [r10 - 0x440], r7
  101487:	lsh64 r0, 0x20
  101488:	rsh64 r0, 0x20
  101489:	mov64 r1, 0x58
  101490:	jeq r0, 0x0, +0x1 <LBB742_39>
  101491:	mov64 r1, 0x60

00000000000c63a0 <LBB742_39>:
  101492:	mov64 r2, r8
  101493:	add64 r2, r1
  101494:	ldxdw r2, [r2 + 0x0]
  101495:	ldxdw r4, [r8 + 0x30]
  101496:	ldxdw r3, [r8 + 0x18]
  101497:	ldxdw r1, [r8 + 0x48]
  101498:	ldxdw r5, [r8 + 0x10]
  101499:	ldxdw r0, [r10 - 0x430]
  101500:	stxdw [r10 - 0xff0], r0
  101501:	stxdw [r10 - 0xff8], r5
  101502:	stxdw [r10 - 0x1000], r1
  101503:	stdw [r10 - 0xfe8], 0x8
  101504:	stdw [r10 - 0xfe0], 0x0
  101505:	mov64 r1, r10
  101506:	add64 r1, -0x2c0
  101507:	mov64 r5, r10
  101508:	call -0x14a68
  101509:	ldxdw r1, [r10 - 0x2b8]
  101510:	ldxdw r7, [r10 - 0x2c0]
  101511:	jne r7, 0x2, -0x5a <LBB742_89>
  101512:	ldxdw r1, [r8 + 0x20]
  101513:	ldxdw r2, [r1 + 0x58]
  101514:	mov64 r1, r10
  101515:	add64 r1, -0x260
  101516:	call -0x1702b
  101517:	ldxdw r1, [r10 - 0x248]
  101518:	lddw r2, 0x125510
  101520:	mov64 r3, 0x20
  101521:	call 0xb8dd
  101522:	ldxdw r1, [r10 - 0x250]
  101523:	ldxdw r2, [r10 - 0x258]
  101524:	ldxdw r3, [r2 + 0x0]
  101525:	add64 r3, -0x1
  101526:	stxdw [r2 + 0x0], r3
  101527:	jne r3, 0x0, +0x3 <LBB742_42>
  101528:	ldxdw r3, [r2 + 0x8]
  101529:	add64 r3, -0x1
  101530:	stxdw [r2 + 0x8], r3

00000000000c64d8 <LBB742_42>:
  101531:	ldxdw r2, [r1 + 0x0]
  101532:	add64 r2, -0x1
  101533:	stxdw [r1 + 0x0], r2
  101534:	jne r2, 0x0, +0x3 <LBB742_44>
  101535:	ldxdw r2, [r1 + 0x8]
  101536:	add64 r2, -0x1
  101537:	stxdw [r1 + 0x8], r2

00000000000c6510 <LBB742_44>:
  101538:	lsh64 r0, 0x20
  101539:	rsh64 r0, 0x20
  101540:	mov64 r1, 0x58
  101541:	jeq r0, 0x0, +0x1 <LBB742_46>
  101542:	mov64 r1, 0x60

00000000000c6538 <LBB742_46>:
  101543:	mov64 r2, r8
  101544:	add64 r2, r1
  101545:	ldxdw r2, [r2 + 0x0]
  101546:	ldxdw r4, [r8 + 0x38]
  101547:	ldxdw r3, [r8 + 0x20]
  101548:	ldxdw r1, [r8 + 0x50]
  101549:	ldxdw r5, [r8 + 0x10]
  101550:	ldxdw r0, [r10 - 0x440]
  101551:	stxdw [r10 - 0xff0], r0
  101552:	stxdw [r10 - 0xff8], r5
  101553:	stxdw [r10 - 0x1000], r1
  101554:	stdw [r10 - 0xfe8], 0x8
  101555:	stdw [r10 - 0xfe0], 0x0
  101556:	mov64 r1, r10
  101557:	add64 r1, -0x2d0
  101558:	mov64 r5, r10
  101559:	call -0x14a9b
  101560:	ldxdw r1, [r10 - 0x2c8]
  101561:	ldxdw r7, [r10 - 0x2d0]
  101562:	ldxdw r6, [r10 - 0x400]
  101563:	jne r7, 0x2, -0x8e <LBB742_89>
  101564:	mov64 r2, r8
  101565:	add64 r2, 0x60
  101566:	ldxdw r4, [r8 + 0x40]
  101567:	ldxdw r3, [r8 + 0x28]
  101568:	ldxdw r1, [r8 + 0x0]
  101569:	ldxdw r5, [r10 - 0x3e8]
  101570:	stxdw [r10 - 0x1000], r5
  101571:	stxdw [r10 - 0xff8], r1
  101572:	mov64 r1, r10
  101573:	add64 r1, -0x2e0
  101574:	mov64 r5, r10
  101575:	call -0x1497f
  101576:	ldxdw r7, [r10 - 0x2e0]
  101577:	jne r7, 0x2, +0x12 <LBB742_51>
  101578:	ldxdw r1, [r8 + 0x0]
  101579:	ldxdw r4, [r1 + 0xf8]
  101580:	mov64 r2, r4
  101581:	ldxdw r3, [r10 - 0x3e8]
  101582:	add64 r2, r3
  101583:	mov64 r3, 0x1
  101584:	jlt r2, r4, +0x1 <LBB742_50>
  101585:	mov64 r3, 0x0

00000000000c6690 <LBB742_50>:
  101586:	and64 r3, 0x1
  101587:	jne r3, 0x0, +0x1 <LBB742_87>
  101588:	ja +0xa <LBB742_52>

00000000000c66a8 <LBB742_87>:
  101589:	mov64 r1, r10
  101590:	add64 r1, -0x390
  101591:	call -0xe52f
  101592:	ldxdw r1, [r10 - 0x388]
  101593:	ldxdw r7, [r10 - 0x390]
  101594:	ldxdw r6, [r10 - 0x400]
  101595:	ja -0xae <LBB742_89>

00000000000c66e0 <LBB742_51>:
  101596:	ldxdw r1, [r10 - 0x2d8]
  101597:	ldxdw r6, [r10 - 0x400]
  101598:	ja -0xb1 <LBB742_89>

00000000000c66f8 <LBB742_52>:
  101599:	stxdw [r1 + 0xf8], r2
  101600:	ldxdw r1, [r8 + 0x0]
  101601:	add64 r1, 0x8
  101602:	call -0xe6b3
  101603:	jeq r0, 0x0, +0x6e <LBB742_72>
  101604:	ldxdw r2, [r8 + 0x0]
  101605:	add64 r2, 0x8
  101606:	mov64 r1, r10
  101607:	add64 r1, -0x260
  101608:	call -0x16386
  101609:	ldxdw r7, [r10 - 0x258]
  101610:	ldxdw r1, [r10 - 0x260]
  101611:	jne r1, 0x0, +0x44 <LBB742_55>
  101612:	ldxdw r2, [r10 - 0x250]
  101613:	jsgt r2, -0x1, +0x1 <LBB742_57>
  101614:	ja +0x44 <LBB742_56>

00000000000c6778 <LBB742_57>:
  101615:	mov64 r1, r10
  101616:	add64 r1, -0x310
  101617:	mov64 r3, 0x0
  101618:	ldxdw r6, [r10 - 0x3e8]
  101619:	mov64 r4, r6
  101620:	mov64 r5, 0x0
  101621:	call 0xbcf3
  101622:	mov64 r1, r10
  101623:	add64 r1, -0x300
  101624:	mov64 r2, r7
  101625:	mov64 r3, 0x0
  101626:	mov64 r4, r6
  101627:	mov64 r5, 0x0
  101628:	call 0xbcec
  101629:	mov64 r2, 0x1
  101630:	ldxdw r3, [r10 - 0x308]
  101631:	mov64 r1, 0x1
  101632:	jne r3, 0x0, +0x1 <LBB742_59>
  101633:	mov64 r1, 0x0

00000000000c6810 <LBB742_59>:
  101634:	ldxdw r4, [r10 - 0x310]
  101635:	ldxdw r5, [r10 - 0x2f8]
  101636:	mov64 r3, r5
  101637:	add64 r3, r4
  101638:	jlt r3, r5, +0x1 <LBB742_61>
  101639:	mov64 r2, 0x0

00000000000c6840 <LBB742_61>:
  101640:	or64 r1, r2
  101641:	and64 r1, 0x1
  101642:	jne r1, 0x0, +0x2f <LBB742_63>
  101643:	ldxdw r1, [r10 - 0x428]
  101644:	jeq r1, 0x0, +0x34 <LBB742_65>
  101645:	ldxdw r2, [r10 - 0x300]
  101646:	mov64 r1, r10
  101647:	add64 r1, -0x320
  101648:	ldxdw r4, [r10 - 0x428]
  101649:	mov64 r5, 0x0
  101650:	call 0xb99e
  101651:	ldxdw r3, [r10 - 0x318]
  101652:	jslt r3, 0x0, +0x34 <LBB742_70>
  101653:	ldxdw r4, [r10 - 0x320]
  101654:	ldxdw r1, [r8 + 0x0]
  101655:	ldxdw r0, [r1 + 0xe8]
  101656:	mov64 r2, r0
  101657:	add64 r2, r4
  101658:	mov64 r5, 0x1
  101659:	jlt r2, r0, +0x1 <LBB742_68>
  101660:	mov64 r5, 0x0

00000000000c68e8 <LBB742_68>:
  101661:	ldxdw r0, [r1 + 0xf0]
  101662:	mov64 r4, r0
  101663:	add64 r4, r3
  101664:	add64 r4, r5
  101665:	mov64 r5, r0
  101666:	xor64 r5, r3
  101667:	xor64 r0, r4
  101668:	xor64 r5, -0x1
  101669:	and64 r5, r0
  101670:	jslt r5, 0x0, +0x0 <LBB742_69>

00000000000c6938 <LBB742_69>:
  101671:	jslt r5, 0x0, +0x1 <LBB742_85>
  101672:	ja +0x27 <LBB742_71>

00000000000c6948 <LBB742_85>:
  101673:	mov64 r1, r10
  101674:	add64 r1, -0x350
  101675:	call -0xe43e
  101676:	ldxdw r1, [r10 - 0x348]
  101677:	ldxdw r7, [r10 - 0x350]
  101678:	ldxdw r6, [r10 - 0x400]
  101679:	ja -0x102 <LBB742_89>

00000000000c6980 <LBB742_55>:
  101680:	ldxdw r1, [r10 - 0x250]
  101681:	ldxdw r6, [r10 - 0x400]
  101682:	ja -0x105 <LBB742_89>

00000000000c6998 <LBB742_56>:
  101683:	mov64 r1, r10
  101684:	add64 r1, -0x2f0
  101685:	call -0xe54c
  101686:	ldxdw r1, [r10 - 0x2e8]
  101687:	ldxdw r7, [r10 - 0x2f0]
  101688:	ldxdw r6, [r10 - 0x400]
  101689:	ja -0x10c <LBB742_89>

00000000000c69d0 <LBB742_63>:
  101690:	mov64 r1, r10
  101691:	add64 r1, -0x380
  101692:	call -0xe512
  101693:	ldxdw r1, [r10 - 0x378]
  101694:	ldxdw r7, [r10 - 0x380]
  101695:	ldxdw r6, [r10 - 0x400]
  101696:	ja -0x113 <LBB742_89>

00000000000c6a08 <LBB742_65>:
  101697:	mov64 r1, r10
  101698:	add64 r1, -0x370
  101699:	mov64 r2, 0x19
  101700:	call 0x4dde
  101701:	ldxdw r1, [r10 - 0x368]
  101702:	ldxdw r7, [r10 - 0x370]
  101703:	ldxdw r6, [r10 - 0x400]
  101704:	ja -0x11b <LBB742_89>

00000000000c6a48 <LBB742_70>:
  101705:	mov64 r1, r10
  101706:	add64 r1, -0x360
  101707:	call -0xe49f
  101708:	ldxdw r1, [r10 - 0x358]
  101709:	ldxdw r7, [r10 - 0x360]
  101710:	ldxdw r6, [r10 - 0x400]
  101711:	ja -0x122 <LBB742_89>

00000000000c6a80 <LBB742_71>:
  101712:	stxdw [r1 + 0xe8], r2
  101713:	stxdw [r1 + 0xf0], r4

00000000000c6a90 <LBB742_72>:
  101714:	mov64 r1, r10
  101715:	add64 r1, -0xd0
  101716:	call 0x9057
  101717:	ldxdw r1, [r10 - 0xd0]
  101718:	jne r1, 0x0, +0xcd <LBB742_74>
  101719:	ldxdw r0, [r10 - 0x438]
  101720:	ldxdw r6, [r10 - 0x440]
  101721:	sub64 r6, r0
  101722:	ldxdw r1, [r10 - 0xa8]
  101723:	ldxdw r2, [r8 + 0x0]
  101724:	ldxdw r2, [r2 + 0x0]
  101725:	ldxdw r2, [r2 + 0x0]
  101726:	ldxdw r3, [r2 + 0x18]
  101727:	stxdw [r10 - 0x248], r3
  101728:	ldxdw r3, [r2 + 0x10]
  101729:	stxdw [r10 - 0x250], r3
  101730:	ldxdw r3, [r2 + 0x8]
  101731:	stxdw [r10 - 0x258], r3
  101732:	ldxdw r2, [r2 + 0x0]
  101733:	stxdw [r10 - 0x260], r2
  101734:	ldxdw r2, [r8 + 0x10]
  101735:	ldxdw r2, [r2 + 0x0]
  101736:	ldxdw r3, [r2 + 0x18]
  101737:	stxdw [r10 - 0x228], r3
  101738:	ldxdw r3, [r2 + 0x10]
  101739:	stxdw [r10 - 0x230], r3
  101740:	ldxdw r3, [r2 + 0x8]
  101741:	stxdw [r10 - 0x238], r3
  101742:	ldxdw r2, [r2 + 0x0]
  101743:	stxdw [r10 - 0x240], r2
  101744:	ldxdw r2, [r8 + 0x30]
  101745:	ldxdw r2, [r2 + 0x20]
  101746:	ldxdw r2, [r2 + 0x0]
  101747:	ldxdw r3, [r2 + 0x18]
  101748:	stxdw [r10 - 0x208], r3
  101749:	ldxdw r3, [r2 + 0x10]
  101750:	stxdw [r10 - 0x210], r3
  101751:	ldxdw r3, [r2 + 0x8]
  101752:	stxdw [r10 - 0x218], r3
  101753:	ldxdw r2, [r2 + 0x0]
  101754:	stxdw [r10 - 0x220], r2
  101755:	ldxdw r2, [r8 + 0x38]
  101756:	ldxdw r2, [r2 + 0x20]
  101757:	ldxdw r2, [r2 + 0x0]
  101758:	ldxdw r3, [r2 + 0x18]
  101759:	stxdw [r10 - 0x1e8], r3
  101760:	ldxdw r3, [r2 + 0x10]
  101761:	stxdw [r10 - 0x1f0], r3
  101762:	ldxdw r3, [r2 + 0x8]
  101763:	stxdw [r10 - 0x1f8], r3
  101764:	ldxdw r2, [r2 + 0x0]
  101765:	stxdw [r10 - 0x200], r2
  101766:	ldxdw r2, [r8 + 0x40]
  101767:	ldxdw r2, [r2 + 0x20]
  101768:	ldxdw r2, [r2 + 0x0]
  101769:	ldxdw r3, [r2 + 0x0]
  101770:	ldxdw r4, [r2 + 0x8]
  101771:	ldxdw r5, [r2 + 0x10]
  101772:	ldxdw r2, [r2 + 0x18]
  101773:	stxdw [r10 - 0x1c0], r1
  101774:	ldxdw r1, [r10 - 0x3e8]
  101775:	stxdw [r10 - 0x1b8], r1
  101776:	ldxdw r1, [r10 - 0x3f0]
  101777:	stxdw [r10 - 0x1b0], r1
  101778:	ldxdw r1, [r10 - 0x3f8]
  101779:	stxdw [r10 - 0x1a8], r1
  101780:	ldxdw r1, [r10 - 0x410]
  101781:	stxdw [r10 - 0x1a0], r1
  101782:	ldxdw r1, [r10 - 0x418]
  101783:	stxdw [r10 - 0x198], r1
  101784:	stxdw [r10 - 0x190], r9
  101785:	ldxdw r1, [r10 - 0x420]
  101786:	stxdw [r10 - 0x188], r1
  101787:	ldxdw r1, [r10 - 0x430]
  101788:	stxdw [r10 - 0x180], r1
  101789:	stxdw [r10 - 0x178], r0
  101790:	ldxdw r1, [r10 - 0x428]
  101791:	stxdw [r10 - 0x170], r1
  101792:	stxdw [r10 - 0x168], r6
  101793:	stxdw [r10 - 0x1c8], r2
  101794:	stxdw [r10 - 0x1d0], r5
  101795:	stxdw [r10 - 0x1d8], r4
  101796:	stxdw [r10 - 0x1e0], r3
  101797:	mov64 r1, r10
  101798:	add64 r1, -0xd0
  101799:	mov64 r7, r10
  101800:	add64 r7, -0x260
  101801:	mov64 r2, r7
  101802:	call -0xe17e
  101803:	ldxdw r1, [r10 - 0xc0]
  101804:	stxdw [r10 - 0x60], r1
  101805:	ldxdw r1, [r10 - 0xc8]
  101806:	stxdw [r10 - 0x68], r1
  101807:	mov64 r1, r10
  101808:	add64 r1, -0x68
  101809:	mov64 r2, 0x1
  101810:	call 0x8f82
  101811:	add64 r8, 0x68
  101812:	mov64 r6, r10
  101813:	add64 r6, -0x160
  101814:	mov64 r1, r6
  101815:	mov64 r2, r8
  101816:	call -0x17157
  101817:	mov64 r1, r10
  101818:	add64 r1, -0x130
  101819:	mov64 r2, r7
  101820:	call -0xe190
  101821:	lddw r1, 0x125e36
  101823:	lddw r2, 0x125e36
  101825:	add64 r2, 0x8
  101826:	stxdw [r10 - 0xd8], r2
  101827:	stxdw [r10 - 0xe0], r1
  101828:	ldxdw r1, [r10 - 0x130]
  101829:	stxdw [r10 - 0xf0], r1
  101830:	ldxdw r1, [r10 - 0x128]
  101831:	stxdw [r10 - 0xf8], r1
  101832:	stxdw [r10 - 0x100], r1
  101833:	ldxdw r2, [r10 - 0x120]
  101834:	add64 r1, r2
  101835:	stxdw [r10 - 0xe8], r1
  101836:	mov64 r1, r10
  101837:	add64 r1, -0x118
  101838:	mov64 r2, r10
  101839:	add64 r2, -0x100
  101840:	call -0x16e3d
  101841:	ldxdw r9, [r10 - 0x110]
  101842:	ldxdw r7, [r10 - 0x108]
  101843:	mov64 r1, 0x22
  101844:	mov64 r2, 0x1
  101845:	call -0x1773b
  101846:	ldxdw r1, [r10 - 0x160]
  101847:	ldxdw r2, [r1 + 0x18]
  101848:	ldxdw r3, [r1 + 0x10]
  101849:	ldxdw r4, [r1 + 0x8]
  101850:	ldxdw r1, [r1 + 0x0]
  101851:	stxdw [r0 + 0x0], r1
  101852:	stxdw [r0 + 0x8], r4
  101853:	stxdw [r0 + 0x10], r3
  101854:	stxdw [r0 + 0x18], r2
  101855:	sth [r0 + 0x20], 0x1
  101856:	stxdw [r10 - 0x60], r0
  101857:	stdw [r10 - 0x68], 0x1
  101858:	stdw [r10 - 0x58], 0x1
  101859:	mov64 r8, r10
  101860:	add64 r8, -0xd0
  101861:	mov64 r5, r10
  101862:	add64 r5, -0x68
  101863:	mov64 r1, r8
  101864:	lddw r2, 0x1267ff
  101866:	mov64 r3, r9
  101867:	mov64 r4, r7
  101868:	call 0x9d62
  101869:	mov64 r7, r10
  101870:	add64 r7, -0x68
  101871:	mov64 r1, r7
  101872:	mov64 r2, r6
  101873:	mov64 r3, 0x30
  101874:	call 0xb773
  101875:	mov64 r1, r10
  101876:	add64 r1, -0x28
  101877:	stxdw [r10 - 0x38], r1
  101878:	mov64 r1, r10
  101879:	add64 r1, -0x1
  101880:	stxdw [r10 - 0x18], r1
  101881:	lddw r1, 0x125f38
  101883:	stxdw [r10 - 0x28], r1
  101884:	ldxdw r1, [r10 - 0x408]
  101885:	stxb [r10 - 0x1], r1
  101886:	stdw [r10 - 0x30], 0x2
  101887:	stdw [r10 - 0x10], 0x1
  101888:	stdw [r10 - 0x20], 0x11
  101889:	mov64 r1, r10
  101890:	add64 r1, -0x38
  101891:	stxdw [r10 - 0x1000], r1
  101892:	stdw [r10 - 0xff8], 0x1
  101893:	mov64 r1, r10
  101894:	add64 r1, -0x80
  101895:	mov64 r5, r10
  101896:	mov64 r2, r8
  101897:	mov64 r3, r7
  101898:	mov64 r4, 0x1
  101899:	call 0x8f30
  101900:	lddw r1, -0x7fffffffffffffe6
  101902:	ldxdw r2, [r10 - 0x80]
  101903:	jeq r2, r1, +0x1 <LBB742_75>
  101904:	ja +0x22 <LBB742_80>

00000000000c7088 <LBB742_75>:
  101905:	ldxdw r1, [r10 - 0x58]
  101906:	ldxdw r2, [r10 - 0x60]
  101907:	ldxdw r3, [r2 + 0x0]
  101908:	add64 r3, -0x1
  101909:	stxdw [r2 + 0x0], r3
  101910:	jne r3, 0x0, +0x3 <LBB742_77>
  101911:	ldxdw r3, [r2 + 0x8]
  101912:	add64 r3, -0x1
  101913:	stxdw [r2 + 0x8], r3

00000000000c70d0 <LBB742_77>:
  101914:	ldxdw r2, [r1 + 0x0]
  101915:	add64 r2, -0x1
  101916:	stxdw [r1 + 0x0], r2
  101917:	jne r2, 0x0, +0x3 <LBB742_79>
  101918:	ldxdw r2, [r1 + 0x8]
  101919:	add64 r2, -0x1
  101920:	stxdw [r1 + 0x8], r2

00000000000c7108 <LBB742_79>:
  101921:	mov64 r7, 0x2
  101922:	ldxdw r6, [r10 - 0x400]
  101923:	ja -0x1f6 <LBB742_89>

00000000000c7120 <LBB742_74>:
  101924:	ldxdw r1, [r10 - 0xc8]
  101925:	ldxdw r2, [r10 - 0xc0]
  101926:	ldxdw r3, [r10 - 0xb8]
  101927:	stxdw [r10 - 0xc0], r3
  101928:	stxdw [r10 - 0xc8], r2
  101929:	stxdw [r10 - 0xd0], r1
  101930:	mov64 r1, r10
  101931:	add64 r1, -0x330
  101932:	mov64 r2, r10
  101933:	add64 r2, -0xd0
  101934:	call 0x87be
  101935:	ldxdw r1, [r10 - 0x328]
  101936:	ldxdw r7, [r10 - 0x330]
  101937:	ldxdw r6, [r10 - 0x400]
  101938:	ja -0x205 <LBB742_89>

00000000000c7198 <LBB742_80>:
  101939:	mov64 r1, r10
  101940:	add64 r1, -0x340
  101941:	mov64 r2, r10
  101942:	add64 r2, -0x80
  101943:	call 0x87b5
  101944:	ldxdw r1, [r10 - 0x338]
  101945:	ldxdw r7, [r10 - 0x340]
  101946:	ldxdw r2, [r10 - 0x58]
  101947:	ldxdw r3, [r10 - 0x60]
  101948:	ldxdw r4, [r3 + 0x0]
  101949:	add64 r4, -0x1
  101950:	stxdw [r3 + 0x0], r4
  101951:	jne r4, 0x0, +0x3 <LBB742_82>
  101952:	ldxdw r4, [r3 + 0x8]
  101953:	add64 r4, -0x1
  101954:	stxdw [r3 + 0x8], r4

00000000000c7218 <LBB742_82>:
  101955:	ldxdw r3, [r2 + 0x0]
  101956:	add64 r3, -0x1
  101957:	stxdw [r2 + 0x0], r3
  101958:	jne r3, 0x0, +0x3 <LBB742_84>
  101959:	ldxdw r3, [r2 + 0x8]
  101960:	add64 r3, -0x1
  101961:	stxdw [r2 + 0x8], r3

00000000000c7250 <LBB742_84>:
  101962:	ldxdw r6, [r10 - 0x400]
  101963:	ja -0x21e <LBB742_89>
