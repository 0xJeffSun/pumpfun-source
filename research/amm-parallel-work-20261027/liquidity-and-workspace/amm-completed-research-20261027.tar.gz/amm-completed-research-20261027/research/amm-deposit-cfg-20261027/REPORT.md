# Dedicated deposit module and remaining machine-code differences

The frozen four-file `recovery.patch` replaces the const-generic deposit call path with an ordinary dedicated business function in the original logical module, `instructions/liquidity/deposit.rs`. It preserves the validated deposit calculations, error precedence, transfer order, event borrowing and early reserve snapshots from89cc. Withdraw continues through its existing implementation. No padding, representation attributes, artificial compiler barriers or source-coordinate edits are used.

Private build: `2f8a5c6582a14d8e84113f61d031b13feed9d03d4100f35b8629ba09ec53f18d`. The frozen source has43 local inputs; `build/` preserves compiler commands, dependency identities, source hashes, logs and stripped/unstripped artifacts. The root's genuine workspace build is the separate next integration step.

## Structural evidence

The original business body is7,128 bytes. The89cc composite body is7,064 bytes; the dedicated-module body is7,024 bytes. Size alone does not assess the result. Using the same unchanged normalized8-byte instruction stream and SequenceMatcher with `autojunk=False`, complete original slots aligned increase from568/891 to804/891. `sequence-alignment.json` records every matched interval and edit span.

The exact normalized global deposit wrapper still calls the actual business body at offset544. All55 direct calls occur in corresponding semantic order. The first29 call offsets are uniformly original+8, through LP minting and its error path; `calls.json` and this packet's disassemblies retain the evidence. The dedicated body uses the original1,120-byte deepest ordinary local stack offset, versus1,088 in89cc. Outgoing argument slots remain in the separate -4,096 region.

All original branch/arithmetic/call opcode counts are restored. The size remainder is entirely17 fewer LDXDW instructions, one fewer STXDW, two extra16-byte LDDW pairs, and one extra MOV-immediate. There are104 basic blocks on each side, versus97 in89cc. This is not an assertion of graph identity: `dedicated-cfg-comparison.json` and `graph-traversal.json` show remaining edge/return-block placement differences, especially around shared error returns and Clock::get error propagation.

The earlier significant scalar argument-promotion gap is corrected by the root's Pool methods: available-quote reserves receives `&Pool` inr2 and raw quote inr3. The old private free function instead took protocol fees, creator fees and quote inr2/r3/r4. No extra visibility or Pool-source trial was duplicated here.

## Validation and limits

The dedicated candidate passes44 signed deposit cases and680 existing liquidity cases, covering successes, zero/one reserves/supplies, transfer-fee errors and limits, frozen accounts and virtual-reserve conditions. `signed-verification.json` independently re-decodes1,448 transactions, verifies every signature and checks identical original/candidate signed messages. All43 source inputs are rehashed against the successful build record.

The complete785-window census remains586 normalized and123 raw. The deposit business window is still unmatched. Exact body, raw data, full transitive closure and original source reconstruction are not claimed. The seven outlined error closures now originate in the authentic logical deposit module, but their line numbers remain those of the recovered Rust source.

The strongest remaining read-only lead is the shared error-return/Clock-error CFG region, together with Context-bump liveness. Original retains the Context pointer until event CPI; the candidate extracts the bump byte early. No source-level change is yet justified solely to force that register/lifetime decision. The combined proper-workspace build should be measured before another source experiment, because it restores original path prefixes and composes the separately recovered math/Pool methods.
