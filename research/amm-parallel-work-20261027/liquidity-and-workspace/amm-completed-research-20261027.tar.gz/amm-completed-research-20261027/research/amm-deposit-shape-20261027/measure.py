from pathlib import Path
import sys,json,hashlib,collections,importlib.util
w=Path(__file__).resolve().parent;root=w.parents[1];sys.path.insert(0,str(root/'repro/pump_amm/claim-self-transfer-v144/static-tool'));from elf_reader import Elf
base=root/'work/amm-post-publication-deposit-composite-20261027';old=json.loads((base/'measurement.json').read_text());o=Elf(root/'evidence/original/pump_amm/deployed.so')
def sha(b):return hashlib.sha256(b).hexdigest()
def measure(cp,sp):
 c=Elf(cp);s=Elf(sp);assert c.b[c.lo:c.hi]==s.b[s.lo:s.hi];idx=collections.defaultdict(list)
 for f in s.funcs:
  n=f['size'];k=(n,c.normalized[f['start']:f['start']+n],json.dumps(c.pattern(f['start'],n),sort_keys=True));idx[k].append(f)
 rows=[];raw=0
 for b in old['rows']:
  a,z=b['start'],b['end'];n=z-a;k=(n,o.normalized[a:z],json.dumps(o.pattern(a,n),sort_keys=True));matches=[]
  for f in idx[k]:matches.append({'start':f['start'],'name':f['name'],'raw_sha256':sha(c.b[f['start']:f['start']+n])})
  raw+=any(o.b[a:z]==c.b[f['start']:f['start']+n]for f in idx[k]);rows.append({'start':a,'end':z,'matches':matches})
 return {'candidate_sha256':sha(c.b),'symbols_sha256':sha(s.b),'reader_sha256':sha((root/'repro/pump_amm/claim-self-transfer-v144/static-tool/elf_reader.py').read_bytes()),'windows':len(rows),'raw_matches':raw,'normalized_matches':sum(bool(r['matches'])for r in rows),'unmatched':sum(not r['matches']for r in rows),'rows':rows}
verified=measure(base/'build/artifacts/pump_amm_recovered.so',base/'build/artifacts/unstripped.so');assert [verified[x]for x in ['windows','raw_matches','normalized_matches','unmatched']]==[old[x]for x in ['windows','raw_matches','normalized_matches','unmatched']]
assert {r['start']for r in verified['rows']if r['matches']}=={r['start']for r in old['rows']if r['matches']}
now=measure(w/'build-unwrap/artifacts/pump_amm_recovered.so',w/'build-unwrap/artifacts/unstripped.so');(w/'measurement.json').write_text(json.dumps(now,indent=2)+'\n')
a={r['start']for r in old['rows']if r['matches']};b={r['start']for r in now['rows']if r['matches']}
d={'baseline':{x:old[x]for x in ['windows','raw_matches','normalized_matches','unmatched']},'candidate':{x:now[x]for x in ['windows','raw_matches','normalized_matches','unmatched']},'baseline_measurer_reproduction_exact':True,'gained_original_windows':sorted(b-a),'lost_original_windows':sorted(a-b)}
sp=importlib.util.spec_from_file_location('closure',root/'repro/pump_amm/call-closure-audit-20261027/audit.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
newclosure=m.analyze(w/'build-unwrap/artifacts/pump_amm_recovered.so',w/'build-unwrap/artifacts/unstripped.so',w/'measurement.json');(w/'call-closure.json').write_text(json.dumps(newclosure,indent=2)+'\n')
oldclosure=m.analyze(base/'build/artifacts/pump_amm_recovered.so',base/'build/artifacts/unstripped.so',base/'measurement.json');d['baseline_closure']=oldclosure['counts'];d['candidate_closure']=newclosure['counts']
(w/'measurement-comparison.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
