# Liquidity predicate recovery and deposit-shape negative trial

The selected change is the one-line `recovery.patch`, based on the frozen8885208c deposit composite. It replaces `liquidity_effective_virtual(pool).is_ok_and(|value| value != 0)` with `liquidity_effective_virtual(pool).unwrap_or_default() != 0`. No account policy, arithmetic, source-coordinate or layout directive changes.

Original helper `0x6c248` is224 bytes. It computes the nonzero predicate from the returned128-bit value before checking the Result discriminant; on an error it drops the error and returns false. The old232-byte `is_ok_and` form checks the discriminant first. The ordinary `unwrap_or_default` form produces the exact224-byte normalized body and relocation pattern. `unwrap-function-proof.json` records zero differing normalized bytes and both call lists. The called effective-virtual helper remains a separate recovery gap; this result is not transitive call/data closure.

Candidate: `285e71bce0d13fa14b204c997e403a5451609eb64f5b515c6e16bccc52646db4`, under `build-unwrap/artifacts/`. All785 windows were remeasured:586 normalized,123 raw,199 unmatched; the sole gain is442952 (`0x6c248`), with no losses. Direct-call-closed/no-indirect/strict-boundary window counts remain523/272/77 because this helper's direct callee is still unmatched.

The selected source passes16 targeted deposit/withdraw predicate cases,44 deposit arithmetic/order cases and680 existing liquidity cases. These include zero, positive and negative virtual reserves, i128 extremes and effective-virtual addition overflow, as well as frozen accounts and transfer fees in the broader suite. All1,480 selected-candidate transaction records were independently re-decoded and cryptographically checked; the original/candidate signed messages match per case. All41 private source inputs were rehashed. The build used a private copy of the authenticated dependency cache, with unchanged dependency artifacts. Root will additionally compose and verify this source with its210-input provenance adapter.

## Rejected lifetime trial

Original deposit loads user-base/user-quote/pool-quote event snapshots early, and rereads live pool LP supply after minting. A first private trial restored those source bindings and read order. Its44 signed cases pass, but deposit grows from7,464 to7,584 bytes; it does not close the original7,128-byte window. This variant is not proposed. Its source and artifacts are retained separately as `trial1-source/` and `build/`; its patch is `trial1.patch` and its88 signed transactions are preserved.

The selected one-line predicate patch leaves deposit at7,464 bytes and withdraw at7,480. No complete deposit-body match is claimed. `recovery.patch`, `source/` and `build-unwrap/` contain only the selected predicate change over the8885208c source. `patch-manifest.json`, `measurement-comparison.json` and `independent-verification.json` provide hashes and scoped results.
