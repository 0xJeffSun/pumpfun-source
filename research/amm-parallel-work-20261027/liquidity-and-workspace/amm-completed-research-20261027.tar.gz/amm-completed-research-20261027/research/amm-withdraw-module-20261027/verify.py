"""Recheck the private withdraw module's signed receipts and frozen inputs."""
from pathlib import Path
import base64, gzip, hashlib, json
from solders.transaction import Transaction

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks = []
for prefix, build, source in [('', 'build', 'trial1-source'), ('u64-', 'build-u64', 'source')]:
    for suite in ['order', 'burn', 'liquidity']:
        name = prefix + suite
        result = json.loads((W/(name+'.json')).read_text())
        observed = json.loads(gzip.decompress((W/(name+'-transactions.json.gz')).read_bytes()))
        rows = observed['transactions']
        assert len(rows) == 2*result['case_count']
        for i in range(0, len(rows), 2):
            transactions = [Transaction.from_bytes(base64.b64decode(row['transaction_base64'], validate=True)) for row in rows[i:i+2]]
            assert all(transactions[0].verify_with_results()) and all(transactions[1].verify_with_results())
            assert bytes(transactions[0].message) == bytes(transactions[1].message)
            assert rows[i]['amm_program_sha256'] == result['original_sha256']
            assert rows[i+1]['amm_program_sha256'] == result['candidate_sha256']
        assert result.get('mismatch_count', len(result.get('mismatches', []))) == 0
        checks.append(dict(suite=name, cases=result['case_count'], signed_transactions=len(rows)))
    record = json.loads((W/build/'build-comparison.json').read_text())
    assert record['source_unchanged'] and record['returncode'] == 0
    current_prefix = str(W.relative_to(ROOT)/'source') + '/'
    for name, digest in record['source_sha256'].items():
        path = W/source/name[len(current_prefix):] if name.startswith(current_prefix) else ROOT/name
        assert sha(path) == digest, name
print(json.dumps(dict(checks=checks, selected_cases=716,
                      selected_signed_transactions=1432,
                      total_retained_signed_transactions=sum(row['signed_transactions'] for row in checks),
                      both_build_source_snapshots_rehashed=True), indent=2))
