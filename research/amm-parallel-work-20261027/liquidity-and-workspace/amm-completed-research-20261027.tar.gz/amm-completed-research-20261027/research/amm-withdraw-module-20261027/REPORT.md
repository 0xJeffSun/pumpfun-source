# Dedicated withdraw module

The frozen `recovery.patch` creates `instructions/liquidity/withdraw.rs`, routes the public withdraw entry through it, and removes the now-unused const-generic liquidity implementation. Deposit already uses its dedicated module and is unchanged. The base is the frozen structural composite, candidatef4cbab585a0791b1919568a753745cc977424f4780fc53674b5d7a828b4f58d1. Math calls remain at the previously recovered `curve::constant_product::liquidity_floor_ratio` and `curve::fees::ceil_div` paths.

The module preserves disabled/seed-lock validation, base-minimum precedence before quote arithmetic, decoded quote-transfer fees, both pool transfers, burn, LP-supply storage before virtual adjustment, and event values. It captures pre-transfer balances and borrows the event for ordinary emission, as observed in the original. It also keeps the successfully narrowed virtual-reserve change as a u64 before infallibly widening it for i128 subtraction. Original instructions use this narrowed low word; the former source discarded the u64 conversion result and reused the u128.

## Build and structural evidence

Selected private candidate: `8653ee229902580ce5f81979a475320e8742a8b091c32267a9c42c1b3330f3dd`, in `build-u64/artifacts/`. The genuine workspace build authenticates214 input files and preserves the cached dependency artifacts. Commands, source snapshots, SDK/target proofs, logs and unstripped output are retained. The first module trial is separately preserved in `build/` and `trial1-source/`.

The original7200-byte body at0x32750 is bound through the exact1336-byte global wrapper and its call at offset544. The selected candidate retains that wrapper and calls the actual7064-byte business body. There is no standalone replacement outside the real call path.

Alignment uses the unchanged normalized8-byte instruction stream and SequenceMatcher with `autojunk=False`, as a diagnostic only:

| Source | Body bytes | Matched original slots |
| --- | ---: | ---: |
| Structural base | 7520 | 443/900 |
| Dedicated module, discarded narrowing result | 7088 | 784/900 |
| Dedicated module, retained u64 result | 7064 | 800/900 |

All56 direct calls remain. The deepest ordinary local stack offset is1080 bytes, matching the original. After retaining the narrowed value, original arithmetic-opcode counts agree. Remaining opcode-count differences are19 fewer LDXDW, one fewer STXDW, one fewer unconditional jump, and two extra LDDW pairs. Full body/CFG identity is not asserted.

The complete785-window census remains586 normalized,123 raw,199 unmatched, with no gains or losses against the structural base. This patch improves the active business-handler organization and alignment; it does not claim another complete function-window match.

## Runtime evidence

Both module trials pass the existing18 withdraw-order cases,18 burn/virtual-order cases and680 liquidity cases. Selected-candidate evidence therefore covers716 cases and1432 signed transactions. `verify.py` independently re-decodes every retained transaction, verifies all signatures, pairs identical original/candidate messages and rehashes both frozen build-source snapshots. The two trials share scenarios and must not be counted as1432 distinct scenarios.

`patch-manifest.json`, `call-anchor.json`, `baseline-assessment.json`, `function-assessment.json`, `u64-function-assessment.json`, `measurement-comparison.json` and `signed-verification.json` contain exact provenance and measurements. No padding, fabricated source coordinates, representation coercion, executable patches, shared-cache mutations or maintained-source edits were used.
