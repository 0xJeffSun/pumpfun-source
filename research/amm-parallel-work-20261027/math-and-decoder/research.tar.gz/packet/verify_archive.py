#!/usr/bin/env python3
"""Read-only verification of the archived, nonselected AMM research."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,base64,collections,gzip,hashlib,importlib.util,json
from solders.transaction import Transaction
HERE=Path(__file__).resolve().parent
ORIGINAL='6a7ad34596d83b4c435b32f458a56e718e9f82eb4ad38e4316616d15d24d8ff7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
 p=Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b)if p.suffix=='.gz'else b)
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 args=argparse.ArgumentParser(description=__doc__);args.add_argument('--output',type=Path);a=args.parse_args()
 manifest=load(HERE/'manifest.json');inventory=manifest['files'];actual={str(p.relative_to(HERE))for p in HERE.rglob('*')if p.is_file()}
 assert actual==set(inventory)|{'manifest.json'}
 for name,item in inventory.items():
  p=HERE/name;assert not p.is_symlink() and '..'not in Path(name).parts and not Path(name).is_absolute()
  assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],name
 claims=load(HERE/'claims.json');assert claims['status']=='experimental-not-selected'
 direct=module('archive_direct',HERE/'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py')
 elf=module('archive_elf',HERE/'repro/pump_amm/claim-self-transfer-v144/static-tool/elf_reader.py')
 original=elf.Elf(HERE/'evidence/original/pump_amm/deployed.so');assert sha(original.path)==ORIGINAL
 loaded={h:HERE/p for h,p in claims['loaded_elfs_by_sha256'].items()}
 for h,p in loaded.items():assert sha(p)==h
 total=0;runs=[]
 for spec in claims['runs']:
  report=load(HERE/spec['report']);obs=load(HERE/spec['receipt']);candidate=sha(HERE/spec['candidate']);assert candidate==report['candidate_sha256'];assert report['original_sha256']==ORIGINAL
  assert sha(HERE/spec['producer'])==obs['script_sha256'];assert report['case_count']==spec['cases']==len(report['cases']);assert len(obs['transactions'])==2*spec['cases'];count=0
  for i,row in enumerate(report['cases']):
   assert direct.clean(row['original'])==direct.clean(row['candidate']),(spec['label'],i)
   pair=obs['transactions'][2*i:2*i+2];assert pair[0]['transaction_sha256']==pair[1]['transaction_sha256']
   for side,t in zip(['original','candidate'],pair):
    raw=base64.b64decode(t['transaction_base64'],validate=True);tx=Transaction.from_bytes(raw);checks=tx.verify_with_results();assert checks and all(checks)and t['all_signatures_verified'];assert len(tx.signatures)==t['signature_count'];assert hashlib.sha256(raw).hexdigest()==t['transaction_sha256'];assert t['amm_program_sha256']==(ORIGINAL if side=='original'else candidate);assert t['logs_sha256']==hashlib.sha256(json.dumps(row[side]['logs'],separators=(',',':')).encode()).hexdigest();assert t['error']==row[side]['error'];count+=len(checks)
    for program in t['loaded_programs'].values():assert program['sha256']in loaded
   if 'original_receipt'in row:
    assert row['original_receipt']['before']==row['candidate_receipt']['before'];assert row['original_receipt']['after']==row['candidate_receipt']['after']
  total+=count;runs.append({'label':spec['label'],'cases':spec['cases'],'mismatches':0,'signatures_verified':count})
 builds=[]
 for directory in claims['builds']:
  base=HERE/directory;r=load(base/'build-comparison.json');assert r['returncode']==0 and r['source_unchanged'];assert r['source_sha256']==r['source_after_sha256'];assert r['dependency_cache_before']==r['dependency_cache_after'];assert sha(base/'build.log')==r['build_log_sha256'];assert sha(base/'artifacts/pump_amm_recovered.so')==r['comparison']['candidate_sha256'];assert sha(base/'artifacts/unstripped.so')==r['unstripped_sha256']
  checked=0
  for path,digest in r['source_sha256'].items():
   p=HERE/path
   if p.is_file():assert sha(p)==digest,path;checked+=1
  assert checked>=40,(directory,checked)
  builds.append({'directory':directory,'application_inputs_checked':checked,'recorded_input_count':len(r['source_sha256']),'recorded_source_and_dependency_snapshots_equal':True})
 measurements=[]
 for spec in claims['measurements']:
  record=load(HERE/spec['record']);c=elf.Elf(HERE/spec['candidate']);symbols=elf.Elf(HERE/spec['symbols']);assert record['candidate_sha256']==sha(c.path) and record['symbols_sha256']==sha(symbols.path);assert c.b[c.lo:c.hi]==symbols.b[symbols.lo:symbols.hi]
  index=collections.defaultdict(list)
  for f in symbols.funcs:
   start,size=f['start'],f['size'];key=(size,hashlib.sha256(c.normalized[start:start+size]).hexdigest(),json.dumps(c.pattern(start,size),sort_keys=True));index[key].append(hashlib.sha256(c.b[start:start+size]).hexdigest())
  normalized=raw=0;entries=sorted(set(original.entries)|{original.lo})
  for start,end in zip(entries,entries[1:]+[original.hi]):
   hits=index[(end-start,hashlib.sha256(original.normalized[start:end]).hexdigest(),json.dumps(original.pattern(start,end-start),sort_keys=True))];normalized+=bool(hits);raw+=hashlib.sha256(original.b[start:end]).hexdigest()in hits
  assert normalized==record['normalized_matches'] and raw==record['raw_matches'] and len(entries)==record['windows']
  measurements.append({'record':spec['record'],'normalized':normalized,'raw':raw,'windows':len(entries)})
 organization=HERE/'work/amm-pool-source-organization-20261027';c=elf.Elf(organization/'build/artifacts/unstripped.so');readers=load(organization/'pool-readers.json')
 for row in readers['readers']:
  old,new,size=row['original'],row['candidate']['start'],row['candidate']['size'];assert original.normalized[old:old+size]==c.normalized[new:new+size];assert original.pattern(old,size)==c.pattern(new,size)
  for call in row['direct_callees']:
   old,new,size=call['original'],call['candidate'],call['bytes'];assert original.normalized[old:old+size]==c.normalized[new:new+size]
 result={'status':'experimental-not-selected','manifest_sha256':sha(HERE/'manifest.json'),'files_verified':len(inventory),'runs':runs,'signatures_verified':total,'builds':builds,'measurements':measurements,'exact_organization_readers_verified':len(readers['readers']),'executes_sbf':False,'rebuilds_sources':False,'limitations':'Toolchains and Cargo caches are intentionally excluded. Build records preserve their historical dependency checks; the verifier authenticates the included application inputs and saved observations.'}
 text=json.dumps(result,indent=2)+'\n'
 if a.output:
  assert HERE not in a.output.resolve().parents;a.output.write_text(text)
 print(text,end='')
if __name__=='__main__':main()
