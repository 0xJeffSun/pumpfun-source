"""Read-only whole helper comparison and actual call edge inventory."""
from pathlib import Path
import bisect, hashlib, importlib.util, json, struct
D = Path(__file__).resolve().parent; ROOT = D.parents[1]
s = importlib.util.spec_from_file_location('elf', ROOT/'repro/pump_amm/claim-self-transfer-v144/static-tool/elf_reader.py')
m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
o = m.Elf(ROOT/'evidence/original/pump_amm/deployed.so'); c = m.Elf(D/'build-final/artifacts/unstripped.so')
rows=[]
for name, start, size in [('market_cap',0x6b780,744),('total_virtual_quote_reserves',0x6bf50,760)]:
 f = next(f for f in c.funcs if 'state4pool' in f['name'] and (str(len(name))+name+'17h') in f['name'])
 differences=[]
 for off in range(0,min(size,f['size']),8):
  a=o.normalized[start+off:start+off+8];b=c.normalized[f['start']+off:f['start']+off+8]
  if a!=b:differences.append({'offset':hex(off),'original':a.hex(),'candidate':b.hex(),'original_immediate':struct.unpack('<i',a[4:])[0],'candidate_immediate':struct.unpack('<i',b[4:])[0]})
 callers=lambda e, target:[{'site':hex(at),'enclosing':hex(e.entries[bisect.bisect_right(e.entries,at)-1])}for at,t in e.calls.items()if t==target]
 rows.append({'name':name,'original':hex(start),'original_size':size,'candidate':hex(f['start']),'candidate_size':f['size'],'normalized_equal':not differences and size==f['size'],'differences':differences,'relocations_equal':o.pattern(start,size)==c.pattern(f['start'],f['size']),'original_calls':o.callsites(start,size),'candidate_calls':c.callsites(f['start'],f['size']),'original_callers':callers(o,start),'candidate_callers':callers(c,f['start'])})
report={'original_sha256':hashlib.sha256(o.b).hexdigest(),'candidate_unstripped_sha256':hashlib.sha256(c.b).hexdigest(),'helpers':rows}
(D/'helper-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
