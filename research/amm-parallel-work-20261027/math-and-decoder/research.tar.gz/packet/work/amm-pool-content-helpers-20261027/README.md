# Pool market-cap and virtual-reserve helpers

The stable patch `pool-content.patch` starts from the `8885208c…` deposit
composite source and changes four files. It moves market-cap arithmetic from
`utils/math.rs` into `Pool::market_cap`, moves signed virtual-plus-accrued-fee
arithmetic into `Pool::total_virtual_quote_reserves`, and routes fee selectors
and liquidity wrappers through the recovered Pool methods. Pool codecs and
the separate `can_boost` predicate are unchanged.

Original `0x6b780` is 744 bytes; original `0x6bf50` is 760 bytes. Both new methods
have those exact sizes and instruction forms/order, relocation patterns, and
call offsets. The only body differences under the unchanged normalization are
the two genuine source-origin stores in each method: original lines 386/426
versus new lines 87/94, and original filename length 35 versus 17. No padding or
diagnostic substitutions were made.

Market cap selects ordinary or fixed mayhem supply, widens both operands,
multiplies, and checks the base-reserve divisor. Every arithmetic/runtime callee
matches the original. The virtual-reserve helper reads the signed reserve,
checks the unsigned protocol-plus-creator sum, then checks signed addition.
Its runtime callees match; the shared total-fees callee retains its known
source-origin-only differences.

The final strict build uses a private copy2 clone of the completed SBPF target
and the authorized original 2.2.1 Cargo home. All 17,731 registry source/archive
files and cached dependency artifacts stayed byte-identical. Candidate:
`4e69403c9d35fcab3ee85ecc47fb0c58097dadd9a78729af8289d37afb83e344`.
The unchanged matcher reports 585/785 normalized windows and 123 raw bodies,
exactly the baseline scores, with no gained or lost windows.

`verify.py` authenticates 788 post-change cases: 60 new signed virtual/fee
ordering collisions, 48 market-cap precedence cases, and all 680 existing
liquidity cases. The 60 baseline collision cases are retained, making 1,696
verified signed records overall. Full recorded results, log hashes, and
available pre/post account snapshots are checked; only source locations and
compute-consumption log lines are normalized.

The earlier `build/` attempt failed offline dependency resolution before
compilation because the old SBF Cargo cache lacked the registry 2.2.1 package.
It is retained as a failed attempt, not used as evidence. `build-final/` is the
successful current-cohort build. See `findings.json`, `helper-comparison.json`,
`delta.json`, and `verification.json` for the precise boundaries.
