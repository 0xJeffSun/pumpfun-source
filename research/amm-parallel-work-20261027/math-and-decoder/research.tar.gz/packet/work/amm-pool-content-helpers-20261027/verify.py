"""Authenticate helper probes, complete liquidity results and unchanged build inputs."""
from pathlib import Path
import base64, gzip, hashlib, importlib.util, json
from solders.transaction import Transaction
D=Path(__file__).resolve().parent;ROOT=D.parents[1]
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def load(path):
 p=Path(path);b=p.read_bytes();return json.loads(gzip.decompress(b)if p.suffix=='.gz'else b)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
direct=mod('direct',ROOT/'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py')
route=mod('route',ROOT/'repro/pump_amm/error-order-recovery-20261027/verify_routes.py')
v2=mod('v2',ROOT/'repro/pump_amm/v2-fee-boundaries-20261027/verify.py')
candidate=D/'build-final/artifacts/pump_amm_recovered.so'
summary={'candidate_sha256':sha(candidate),'runs':[]}
for name,binary in [('before',ROOT/'work/amm-post-publication-deposit-composite-20261027/build/artifacts/pump_amm_recovered.so'),('after',candidate)]:
 proof=route.verify(D/('virtual-'+name+'.json.gz'),D/('virtual-'+name+'-observer.json.gz'),binary,D/'probe_virtual.py',60)
 summary['runs'].append({'name':'virtual-'+name,**proof})
before,after=load(D/'virtual-before.json.gz'),load(D/'virtual-after.json.gz')
for a,b in zip(before['cases'],after['cases']):
 assert a['case']==b['case'] and a['original_receipt']==b['original_receipt'] and direct.clean(a['original'])==direct.clean(b['original'])
proof=v2.verify(D/'market-cap.json',D/'market-cap-observer.json.gz',candidate,'../fee-selection-recovery-20261027/probe_market_cap_order.py',48,0)
summary['runs'].append({'name':'market-cap',**proof})
r=load(D/'liquidity.json');obs=load(D/'liquidity-observer.json.gz');assert r['candidate_sha256']==sha(candidate) and r['script_sha256']==obs['script_sha256']==sha(ROOT/'scripts/pump_amm_liquidity_differential.py');assert len(obs['transactions'])==2*r['case_count'];signatures=0
for i,row in enumerate(r['cases']):
 assert direct.clean(row['original'])==direct.clean(row['candidate']),(i,row['case'])
 pair=obs['transactions'][2*i:2*i+2];assert pair[0]['transaction_sha256']==pair[1]['transaction_sha256']
 for side,t in zip(['original','candidate'],pair):
  raw=base64.b64decode(t['transaction_base64']);tx=Transaction.from_bytes(raw);assert all(tx.verify_with_results())and t['all_signatures_verified'];assert hashlib.sha256(raw).hexdigest()==t['transaction_sha256'];assert t['amm_program_sha256']==r[side+'_sha256'];assert t['logs_sha256']==hashlib.sha256(json.dumps(row[side]['logs'],separators=(',',':')).encode()).hexdigest();signatures+=len(tx.signatures)
summary['runs'].append({'name':'liquidity','cases':r['case_count'],'signatures':signatures,'mismatches':0})
build=load(D/'build-final/build-comparison.json');assert build['source_unchanged']and build['source_sha256']==build['source_after_sha256'];assert build['dependency_cache_before']==build['dependency_cache_after'];assert load(D/'registry-before.json')==load(D/'registry-after.json');summary['registry_files_unchanged']=len(load(D/'registry-before.json'))
delta=load(D/'delta.json');assert not delta['lost'];summary['delta']=delta;summary['cases_after']=60+48+r['case_count'];summary['normalization']='Only exact source locations and compute-consumption log lines; every other recorded result field and full raw log hash is checked.'
(D/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
