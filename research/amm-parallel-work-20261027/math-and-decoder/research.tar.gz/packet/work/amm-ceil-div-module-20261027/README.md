# Ceiling/floor helper module recovery

The original ceiling helper `0x12b08` is already reproduced by the arithmetic
in `89cc…`: all 1,672 bytes agree under the standard normalization except six
genuine source-origin immediates. Its arguments are the hidden Result output
pointer followed by the two low/high u128 operand pairs. The related floor
helper `0x12840` is 712 bytes, likewise differing only in its line/path-length
stores. There is no arithmetic or argument-layout correction to make.

The actual original file literals establish two logical modules:

- Ceiling division belongs to `programs/pump-amm/src/curve/fees.rs`, with checked
  addition, subtraction and division errors at lines 17, 19 and 21.
- The liquidity floor-ratio helper belongs to
  `programs/pump-amm/src/curve/constant_product.rs`, error line 112.

`module.patch` moves the existing ceiling function verbatim into `curve/fees.rs`
after the unchanged AppliedFees preamble and updates its callers. It is based
on `work/amm-deposit-borrow-captures-20261027/source`. Its successful candidate is
`00c33fcff749346cf1d67a687b477b8b3bb4b44e64491d69f0f7db61bbfdf0b5`.

`floor-module.patch` is a separately built incremental patch on that source. It
moves the unchanged floor formula into `curve/constant_product.rs` and updates
the two liquidity calls. The source is `source-floor/`; its candidate is
`2387f1264820f53b8101efcd4592aba1f5becafed17d6ba68a36dbe6ab9da22b` in
`build-floor/artifacts/`.

Both complete helper instruction shapes, relocation patterns and direct
callee bodies remain unchanged except real origin stores. Both trials retain
586/785 normalized matches and 123 raw matches, with no gains or losses. The
ceiling source now reports lines 17/18/19; floor reports line 29. Those are the
ordinary relocated source positions, not attempts to manufacture the original
lines. No padding, artificial comments, source-coordinate constants or remap
flags were introduced. Root's separate workspace experiment owns restoration
of the actual workspace path prefix.

The ceiling-only trial passes 740 signed cases. The incremental floor trial
passes 760: all 680 existing liquidity cases, 48 fee/market-cap cases, and 32
explicit arithmetic boundaries. The latter includes actual original failures
at each ceiling error site: addition overflow, subtraction underflow, and zero
division. Every recorded field and raw log hash is checked; only source
locations and compute-consumption lines are normalized. The final trial
authenticates 1,520 signatures.

`compare_helpers.py`, `verify.py`, and `verify_floor.py` reproduce the static and
saved-receipt checks. Both builds preserve their source inputs and cached
dependency artifacts. `registry-check.json` separately checks that the existing
17,731 registry source/archive files remained unchanged across these builds.
