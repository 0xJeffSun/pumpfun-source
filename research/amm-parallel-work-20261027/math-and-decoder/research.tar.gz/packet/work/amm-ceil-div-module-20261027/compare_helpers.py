"""Compare complete ceil/floor bodies without masking additional instruction bytes."""
from pathlib import Path
import argparse,bisect,hashlib,importlib.util,json,struct
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('elf',ROOT/'repro/pump_amm/claim-self-transfer-v144/static-tool/elf_reader.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('--symbols',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
o=m.Elf(ROOT/'evidence/original/pump_amm/deployed.so');c=m.Elf(a.symbols.resolve());rows=[]
for name,at,size,allowed in [('ceil_div',0x12b08,1672,[0x278,0x280,0x530,0x538,0x630,0x638]),('liquidity_floor_ratio',0x12840,712,[0x250,0x258])]:
 f=next(f for f in c.funcs if str(len(name))+name+'17h' in f['name']);assert f['size']==size
 x=o.normalized[at:at+size];y=c.normalized[f['start']:f['start']+size];diff=[]
 for i in range(0,size,8):
  if x[i:i+8]!=y[i:i+8]:
   assert x[i:i+4]==y[i:i+4];diff.append({'offset':hex(i),'original':x[i:i+8].hex(),'candidate':y[i:i+8].hex(),'original_imm':struct.unpack_from('<i',x,i+4)[0],'candidate_imm':struct.unpack_from('<i',y,i+4)[0]})
 assert all(int(d['offset'],16)in allowed for d in diff)
 assert o.pattern(at,size)==c.pattern(f['start'],size)
 calls=[]
 for left,right in zip(o.callsites(at,size),c.callsites(f['start'],size)):
  assert left['offset']==right['offset'];end=o.entries[bisect.bisect_right(o.entries,left['target'])];n=end-left['target'];cf=next(q for q in c.funcs if q['start']==right['target']);assert cf['size']==n
  calls.append({'offset':left['offset'],'original':hex(left['target']),'candidate':hex(right['target']),'size':n,'normalized_equal':o.normalized[left['target']:end]==c.normalized[right['target']:right['target']+n]})
 rows.append({'name':name,'original':hex(at),'candidate':hex(f['start']),'size':size,'complete_non_origin_instructions_equal':True,'differences':diff,'relocation_pattern_equal':True,'calls':calls})
r={'original_sha256':hashlib.sha256(o.b).hexdigest(),'symbols_sha256':hashlib.sha256(c.b).hexdigest(),'helpers':rows,'scope':'Only actual source-origin immediate stores differ; no byte rewriting or permissive normalization performed.'};a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
