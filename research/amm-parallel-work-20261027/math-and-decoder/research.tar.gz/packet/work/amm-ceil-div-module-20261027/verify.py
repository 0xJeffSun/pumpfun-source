"""Authenticate the ceil-div relocation and all recorded arithmetic probe fields."""
from pathlib import Path
import base64,gzip,hashlib,importlib.util,json
from solders.transaction import Transaction
D=Path(__file__).resolve().parent;ROOT=D.parents[1]
s=importlib.util.spec_from_file_location('direct',ROOT/'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py');direct=importlib.util.module_from_spec(s);s.loader.exec_module(direct)
def load(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)if p.suffix=='.gz'else b)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
candidate=D/'build/artifacts/pump_amm_recovered.so';assert sha(candidate)=='00c33fcff749346cf1d67a687b477b8b3bb4b44e64491d69f0f7db61bbfdf0b5'
summary={'candidate_sha256':sha(candidate),'runs':[],'signatures':0}
for name,producer in [('liquidity',ROOT/'scripts/pump_amm_liquidity_differential.py'),('market-cap',ROOT/'repro/pump_amm/fee-selection-recovery-20261027/probe_market_cap_order.py'),('arithmetic',D/'probe_arithmetic.py')]:
 r=load(D/(name+'.json'));o=load(D/(name+'-transactions.json.gz'));assert r['candidate_sha256']==sha(candidate);assert o['script_sha256']==sha(producer)==r.get('probe_sha256',r.get('script_sha256'));assert len(o['transactions'])==r['case_count']*2
 for i,row in enumerate(r['cases']):
  assert direct.clean(row['original'])==direct.clean(row['candidate']);pair=o['transactions'][2*i:2*i+2];assert pair[0]['transaction_sha256']==pair[1]['transaction_sha256']
  for side,t in zip(['original','candidate'],pair):
   raw=base64.b64decode(t['transaction_base64'],validate=True);tx=Transaction.from_bytes(raw);assert all(tx.verify_with_results())and t['all_signatures_verified'];assert len(tx.signatures)==t['signature_count'];assert hashlib.sha256(raw).hexdigest()==t['transaction_sha256'];assert t['amm_program_sha256']==r[side+'_sha256'];assert t['logs_sha256']==hashlib.sha256(json.dumps(row[side]['logs'],separators=(',',':')).encode()).hexdigest();summary['signatures']+=len(tx.signatures)
 summary['runs'].append({'suite':name,'cases':r['case_count'],'mismatches':0,'all_recorded_fields_and_logs_equal':True})
r=load(D/'arithmetic.json')
for index,line,code in [(0,19,6023),(1,21,6025),(8,17,6023),(9,17,6023)]:
 assert any('curve/fees.rs:'+str(line)+'.'in x and 'Error Number: '+str(code)+'.'in x for x in r['cases'][index]['original']['logs'])
a=load(ROOT/'work/amm-deposit-borrow-captures-20261027/measurement.json');b=load(D/'measurement.json');x={r['start']for r in a['rows']if r['matches']};y={r['start']for r in b['rows']if r['matches']};summary['delta']={'base':a['candidate_sha256'],'gained':[hex(n)for n in sorted(y-x)],'lost':[hex(n)for n in sorted(x-y)],'normalized':b['normalized_matches'],'raw':b['raw_matches']};assert not summary['delta']['lost']
build=load(D/'build/build-comparison.json');assert build['source_unchanged']and build['source_sha256']==build['source_after_sha256'];assert build['dependency_cache_before']==build['dependency_cache_after'];summary['build_source_and_dependencies_unchanged']=True
proof=load(D/'helper-proof.json');assert proof['symbols_sha256']==sha(D/'build/artifacts/unstripped.so');assert all(x['complete_non_origin_instructions_equal']and x['relocation_pattern_equal']and all(c['normalized_equal']for c in x['calls'])for x in proof['helpers'])
(D/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
