"""Signed synthetic ceiling/floor division boundary cases through liquidity."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,struct,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'))
import pump_amm_liquidity_differential as h
s=importlib.util.spec_from_file_location('direct',ROOT/'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py');direct=importlib.util.module_from_spec(s);s.loader.exec_module(direct)
U=2**64-1;I=2**127-1
CASES=[('deposit',0,0,0,0,0),('deposit',0,1,1,1,0),('deposit',1,U,U,1,0),('deposit',U,U,U,U,0),('deposit',U,1,1,1,0),('deposit',1,1,0,0,0),('withdraw',0,1,1,1,0),('withdraw',1,0,0,0,0),('withdraw',U,2,1,1,I),('withdraw',U,2,1,1,I-1),('withdraw',U,1,1,1,I),('withdraw',1,1,1,1,-1)]
def main():
 p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists();rows=[]
 for name,supply,amount,base,quote,virtual in CASES:
  change=h.combine(h.mutate(h.pool,203,struct.pack('<Q',supply)),h.mutate(h.lp,36,struct.pack('<Q',supply)),h.mutate(h.vaultbase,64,struct.pack('<Q',base)),h.mutate(h.vaultquote,64,struct.pack('<Q',quote)))
  kw=dict(name=name,amount=amount,maxbase=U if name=='deposit'else 0,maxquote=U if name=='deposit'else 0,virtual=virtual,overrides=change)
  x=h.run(**kw);y=h.run(candidate=a.candidate,**kw);xx,yy=map(direct.clean,[x,y]);diff=[k for k in xx if xx[k]!=yy[k]];rows.append({'case':{'instruction':name,'supply':supply,'amount':amount,'base':base,'quote':quote,'virtual':virtual,'synthetic':True},'original':x,'candidate':y,'differences':diff})
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r={'original_sha256':sha(ROOT/'evidence/original/pump_amm/deployed.so'),'candidate_sha256':sha(a.candidate),'probe_sha256':sha(Path(__file__)),'case_count':len(rows),'cases':rows};a.output.write_text(json.dumps(r,separators=(',',':'))+'\n');print(json.dumps({'cases':len(rows),'mismatches':sum(bool(x['differences'])for x in rows)}))
if __name__=='__main__':main()
