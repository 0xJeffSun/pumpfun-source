from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'diagnostic.rs';t=p.read_text()
a=t.index('#[no_mangle]\npub fn fee_else(');b=t.index('#[no_mangle]\npub fn fee_return(',a);f=t[a:b].replace('fee_else','fee_owned').replace('fee:&DecodedTransferFee','fee:DecodedTransferFee')
a=t.index('#[no_mangle]\npub fn inverse_match(');b=t.index('#[no_mangle]\npub fn inverse_return(',a);i=t[a:b].replace('inverse_match','inverse_owned').replace('fee:&DecodedTransferFee','fee:DecodedTransferFee')
p.write_text(t+'\n'+f+'\n'+i)
