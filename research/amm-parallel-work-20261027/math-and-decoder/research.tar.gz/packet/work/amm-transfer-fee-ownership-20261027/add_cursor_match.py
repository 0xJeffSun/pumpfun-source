from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'diagnostic.rs';t=p.read_text();a=t.index('#[no_mangle]\npub fn decoder_cursor_split(');base=t[a:]
fn=base.replace('decoder_cursor_split','decoder_cursor_match')
fn=fn.replace('        if kind == 1 {','        match kind { 1 => {').replace('        offset = offset.checked_add(4 + length).ok_or(())?;','        _ => {} }\n        offset = offset.checked_add(4 + length).ok_or(())?;')
fn2=fn.replace('decoder_cursor_match','decoder_cursor_guard_match').replace('    if data.len() == 82 {\n        return Ok(None);\n    }\n    if data.len() < 167 { return Err(()); }','    match data.len() {82 => return Ok(None), 0..=166 => return Err(()), _ => {}}')
fn3=base.replace('decoder_cursor_split','decoder_cursor_continue')
fn3=fn3.replace('        if kind == 1 {','        if kind != 1 {\n            offset = offset.checked_add(4 + length).ok_or(())?;\n            continue;\n        }\n        {')
p.write_text(t+'\n'+fn+'\n'+fn2+'\n'+fn3)
