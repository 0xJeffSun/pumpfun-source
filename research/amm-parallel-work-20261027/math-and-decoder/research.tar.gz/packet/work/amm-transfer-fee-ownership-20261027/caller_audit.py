from pathlib import Path
import hashlib,importlib.util,json,struct
D=Path(__file__).resolve().parent;R=D.parents[1]
s=importlib.util.spec_from_file_location('e',R/'repro/pump_amm/claim-self-transfer-v144/static-tool/elf_reader.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);e=m.Elf(R/'evidence/original/pump_amm/deployed.so');rows=[]
for target in [0xf31d8,0xf2d60,0xf2ed0]:
 direct=[{'site':hex(at),'instruction':e.b[at:at+8].hex()}for at,t in e.calls.items()if t==target];references=[]
 for at,rel in e.relocations.items():
  if rel['type']!=8:continue
  p=(struct.unpack_from('<I',e.b,at+4)[0]|struct.unpack_from('<I',e.b,at+12)[0]<<32)if e.lo<=at<e.hi and e.b[at]==0x18 else struct.unpack_from('<Q',e.b,at)[0]>>32
  if p==target:references.append({'site':hex(at),'relocation':rel})
 rows.append({'target':hex(target),'direct_calls':direct,'relocated_function_pointer_references':references})
out={'original_sha256':hashlib.sha256(e.b).hexdigest(),'targets':rows,'scope':'All decoded direct calls and type8 relocation pointers in original ELF. This does not exclude dynamically calculated indirect targets.'};(D/'caller-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
