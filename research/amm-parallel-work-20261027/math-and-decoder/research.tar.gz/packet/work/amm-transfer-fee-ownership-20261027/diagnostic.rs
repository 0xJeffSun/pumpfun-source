#![no_std]
#[derive(Clone,Copy,Debug)]
pub struct DecodedTransferFee {pub epoch:u64,pub maximum_fee:u64,pub transfer_fee_basis_points:u16}
#[no_mangle]
pub fn decoder_slice(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 || data[82..165].iter().any(|byte| *byte != 0) || data[165] != 1 {
        return Err(());
    }
    let mut remaining = &data[166..];
    let mut fees = None;
    while remaining.len() >= 2 {
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            break;
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        remaining = &remaining[4 + length..];
    }
    Ok(fees)
}

#[no_mangle]
pub fn fee_else(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let bps=fee.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {Some(0)} else {
        let n=(amount as u128).checked_mul(bps)?;
        let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
        Some(core::cmp::min(raw,fee.maximum_fee))
    }
}
#[no_mangle]
pub fn fee_return(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let bps=fee.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {return Some(0);}
    let n=(amount as u128).checked_mul(bps)?;
    let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
    Some(core::cmp::min(raw,fee.maximum_fee))
}
#[no_mangle]
pub fn inverse_match(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let max=fee.maximum_fee; let bps=fee.transfer_fee_basis_points as u128;
    match (bps,amount) {
        (0,_)=>Some(amount),(_,0)=>Some(0),(10000,_)=>max.checked_add(amount),
        _=>{let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
        if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}}
    }
}
#[no_mangle]
pub fn inverse_return(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let max=fee.maximum_fee; let bps=fee.transfer_fee_basis_points as u128;
    if bps==0{return Some(amount);} if amount==0{return Some(0);} if bps==10000{return max.checked_add(amount);}
    let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
    if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}
}

#[no_mangle]
pub fn decoder_cursor(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 || data[82..165].iter().any(|byte| *byte != 0) || data[165] != 1 {
        return Err(());
    }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { break; }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            break;
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
    Ok(fees)
}

#[no_mangle]
pub fn decoder_cursor_return(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 || data[82..165].iter().any(|byte| *byte != 0) || data[165] != 1 {
        return Err(());
    }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_cursor_split(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_cursor_match(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        match kind { 1 => {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        _ => {} }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_cursor_guard_match(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    match data.len() {82 => return Ok(None), 0..=166 => return Err(()), _ => {}}
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        match kind { 1 => {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        _ => {} }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_cursor_continue(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind != 1 {
            offset = offset.checked_add(4 + length).ok_or(())?;
            continue;
        }
        {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_separate_fee_checks(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() { return Err(()); }
            if length < 108 { return Err(()); }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}

#[no_mangle]
pub fn decoder_inverted_guard(data: &[u8]) -> core::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() != 82 {
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() { return Err(()); }
            if length < 108 { return Err(()); }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
    }
    Ok(None)
}

#[no_mangle]
pub fn fee_owned(fee:DecodedTransferFee, amount:u64)->Option<u64> {
    let bps=fee.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {Some(0)} else {
        let n=(amount as u128).checked_mul(bps)?;
        let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
        Some(core::cmp::min(raw,fee.maximum_fee))
    }
}

#[no_mangle]
pub fn inverse_owned(fee:DecodedTransferFee, amount:u64)->Option<u64> {
    let max=fee.maximum_fee; let bps=fee.transfer_fee_basis_points as u128;
    match (bps,amount) {
        (0,_)=>Some(amount),(_,0)=>Some(0),(10000,_)=>max.checked_add(amount),
        _=>{let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
        if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}}
    }
}
