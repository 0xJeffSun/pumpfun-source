use crate::*;

#[derive(Clone, Copy, Debug)]
pub struct DecodedTransferFee {
    pub epoch: u64,
    pub maximum_fee: u64,
    pub transfer_fee_basis_points: u16,
}

impl DecodedTransferFee {
pub fn native_calculate_fee(self, amount:u64)->Option<u64> {
    let bps=self.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {Some(0)} else {
        let n=(amount as u128).checked_mul(bps)?;
        let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
        Some(core::cmp::min(raw,self.maximum_fee))
    }
}


pub fn native_pre_fee_amount(self, amount:u64)->Option<u64> {
    let max=self.maximum_fee; let bps=self.transfer_fee_basis_points as u128;
    match (bps,amount) {
        (0,_)=>Some(amount),(_,0)=>Some(0),(10000,_)=>max.checked_add(amount),
        _=>{let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
        if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}}
    }
}

}

pub type TransferFeeData = Option<DecodedTransferFee>;

pub fn from_mint(mint: &AccountInfo) -> Result<TransferFeeData> {
    if mint.owner != &anchor_spl::token_2022::ID {
        return Ok(None);
    }
    let data = mint.try_borrow_data()?;
    let fees = decode_transfer_fees(&data)
        .map_err(|_| error!(PumpAmmError::UnsupportedQuoteMint))?;
    let Some((older, newer)) = fees else {
        return Ok(None);
    };
    let epoch = Clock::get()?.epoch;
    Ok(Some(if epoch >= newer.epoch { newer } else { older }))
}

pub fn calculate_fee(data: &TransferFeeData, amount: u64) -> Result<u64> {
    match data {
        None => Ok(0),
        Some(fee) => fee.native_calculate_fee(amount)
            .ok_or_else(|| error!(PumpAmmError::Overflow)),
    }
}

pub fn amount_after_fee(data: &TransferFeeData, amount: u64) -> Result<u64> {
    amount.checked_sub(calculate_fee(data, amount)?)
        .ok_or_else(|| error!(PumpAmmError::Overflow))
}

pub fn amount_before_fee(data: &TransferFeeData, amount: u64) -> Result<u64> {
    match data {
        None => Ok(amount),
        Some(fee) => fee.native_pre_fee_amount(amount)
            .ok_or_else(|| error!(PumpAmmError::Overflow)),
    }
}


fn decode_transfer_fees(data: &[u8]) -> std::result::Result<Option<(DecodedTransferFee, DecodedTransferFee)>, ()> {
    if data.len() == 82 {
        return Ok(None);
    }
    if data.len() < 167 { return Err(()); }
    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }
    if data[165] != 1 { return Err(()); }
    let tlv = &data[166..];
    let mut offset = 0usize;
    let mut fees = None;
    loop {
        let remaining = tlv.get(offset..).ok_or(())?;
        if remaining.len() < 2 { return Ok(fees); }
        let kind = u16::from_le_bytes(remaining[..2].try_into().unwrap());
        if kind == 0 {
            return Ok(fees);
        }
        if remaining.len() < 4 {
            return Err(());
        }
        let length = u16::from_le_bytes(remaining[2..4].try_into().unwrap()) as usize;
        let value = remaining.get(4..4 + length).ok_or(())?;
        if kind == 1 {
            if fees.is_some() || length < 108 {
                return Err(());
            }
            let read_fee = |bytes: &[u8]| DecodedTransferFee {
                epoch: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
                maximum_fee: u64::from_le_bytes(bytes[8..16].try_into().unwrap()),
                transfer_fee_basis_points: u16::from_le_bytes(bytes[16..18].try_into().unwrap()),
            };
            fees = Some((read_fee(&value[72..90]), read_fee(&value[90..108])));
        }
        offset = offset.checked_add(4 + length).ok_or(())?;
    }
}
