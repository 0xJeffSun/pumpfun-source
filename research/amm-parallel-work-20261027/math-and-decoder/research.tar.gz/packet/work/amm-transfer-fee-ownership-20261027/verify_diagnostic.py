from pathlib import Path
import base64,gzip,hashlib,importlib.util,json
from solders.transaction import Transaction
D=Path(__file__).resolve().parent;R=D.parents[1]
s=importlib.util.spec_from_file_location('clean',R/'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((D/'native-cursor.json').read_text());o=json.loads(gzip.decompress((D/'native-cursor-transactions.json.gz').read_bytes()));base=json.loads((D/'published.json').read_text());assert r['candidate_sha256']==sha(D/'build-native-cursor/artifacts/pump_amm_recovered.so');assert o['script_sha256']==r['producer_sha256']==sha(D/'probe_decoder.py');assert len(o['transactions'])==2*r['case_count']==116
count=0
for i,row in enumerate(r['cases']):
 assert row['original']==base['cases'][i]['original'];assert m.clean(row['original'])==m.clean(row['candidate']) and not row['mismatched_fields'];pair=o['transactions'][i*2:i*2+2];assert pair[0]['transaction_sha256']==pair[1]['transaction_sha256']
 for side,x in zip(['original','candidate'],pair):
  raw=base64.b64decode(x['transaction_base64']);tx=Transaction.from_bytes(raw);assert all(tx.verify_with_results()) and x['all_signatures_verified'];assert x['amm_program_sha256']==r[side+'_sha256'];assert x['logs_sha256']==hashlib.sha256(json.dumps(row[side]['logs'],separators=(',',':')).encode()).hexdigest();assert x['error']==row[side]['error'];count+=len(tx.signatures)
build=json.loads((D/'build-native-cursor/build-comparison.json').read_text());assert build['source_unchanged']and build['source_sha256']==build['source_after_sha256'];assert build['dependency_cache_before']==build['dependency_cache_after']
report={'candidate_sha256':r['candidate_sha256'],'cases':58,'mismatches':0,'signatures_verified':count,'source_and_dependency_inputs_unchanged':True,'promoted':False,'reason':'All arithmetic and parser helpers still inline; wrappers get larger and no exact helper boundary is restored.'};(D/'diagnostic-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
