from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'diagnostic.rs';t=p.read_text();a=t.index('#[no_mangle]\npub fn decoder_cursor(');fn=t[a:].replace('decoder_cursor','decoder_cursor_return').replace('if remaining.len() < 2 { break; }','if remaining.len() < 2 { return Ok(fees); }').replace('            break;','            return Ok(fees);');fn=fn.replace('    Ok(fees)\n}','}')
fn2=fn.replace('decoder_cursor_return','decoder_cursor_split').replace('    if data.len() < 167 || data[82..165].iter().any(|byte| *byte != 0) || data[165] != 1 {\n        return Err(());\n    }','    if data.len() < 167 { return Err(()); }\n    if data[82..165].iter().any(|byte| *byte != 0) { return Err(()); }\n    if data[165] != 1 { return Err(()); }')
p.write_text(t+'\n'+fn+'\n'+fn2)
