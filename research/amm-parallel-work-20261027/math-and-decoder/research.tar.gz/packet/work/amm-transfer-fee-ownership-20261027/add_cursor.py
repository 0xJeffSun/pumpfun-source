from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'diagnostic.rs';t=p.read_text();a=t.index('#[no_mangle]\npub fn decoder_slice(');b=t.index('\n#[no_mangle]\npub fn fee_else',a);fn=t[a:b].replace('decoder_slice','decoder_cursor')
fn=fn.replace('    let mut remaining = &data[166..];\n    let mut fees = None;\n    while remaining.len() >= 2 {','    let tlv = &data[166..];\n    let mut offset = 0usize;\n    let mut fees = None;\n    loop {\n        let remaining = tlv.get(offset..).ok_or(())?;\n        if remaining.len() < 2 { break; }')
fn=fn.replace('        remaining = &remaining[4 + length..];','        offset = offset.checked_add(4 + length).ok_or(())?;')
p.write_text(t+'\n'+fn)
