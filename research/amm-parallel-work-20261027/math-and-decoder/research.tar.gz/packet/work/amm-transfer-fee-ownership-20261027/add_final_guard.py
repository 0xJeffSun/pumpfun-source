from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'diagnostic.rs';t=p.read_text();a=t.index('#[no_mangle]\npub fn decoder_cursor_split(');b=t.index('\n#[no_mangle]',a+2);base=t[a:b]
sep=base.replace('decoder_cursor_split','decoder_separate_fee_checks').replace('            if fees.is_some() || length < 108 {\n                return Err(());\n            }','            if fees.is_some() { return Err(()); }\n            if length < 108 { return Err(()); }')
guard=sep.replace('decoder_separate_fee_checks','decoder_inverted_guard');guard=guard.replace('    if data.len() == 82 {\n        return Ok(None);\n    }','    if data.len() != 82 {');guard=guard.rstrip()[:-1]+'    }\n    Ok(None)\n}\n'
p.write_text(t+'\n'+sep+'\n'+guard)
