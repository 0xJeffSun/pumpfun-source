from pathlib import Path
D=Path(__file__).resolve().parent
text=(D/'source-decoder/programs/pump-amm/src/utils/transfer_fee.rs').read_text()
parser=text[text.index('fn decode_transfer_fees('):].replace('fn decode_transfer_fees(', '#[no_mangle]\npub fn decoder_slice(').replace('std::result','core::result')
base='''#![no_std]
#[derive(Clone,Copy,Debug)]
pub struct DecodedTransferFee {pub epoch:u64,pub maximum_fee:u64,pub transfer_fee_basis_points:u16}
'''
scalar='''
#[no_mangle]
pub fn fee_else(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let bps=fee.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {Some(0)} else {
        let n=(amount as u128).checked_mul(bps)?;
        let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
        Some(core::cmp::min(raw,fee.maximum_fee))
    }
}
#[no_mangle]
pub fn fee_return(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let bps=fee.transfer_fee_basis_points as u128;
    if bps==0 || amount==0 {return Some(0);}
    let n=(amount as u128).checked_mul(bps)?;
    let raw=n.checked_add(10000)?.checked_sub(1)?.checked_div(10000)?.try_into().ok()?;
    Some(core::cmp::min(raw,fee.maximum_fee))
}
#[no_mangle]
pub fn inverse_match(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let max=fee.maximum_fee; let bps=fee.transfer_fee_basis_points as u128;
    match (bps,amount) {
        (0,_)=>Some(amount),(_,0)=>Some(0),(10000,_)=>max.checked_add(amount),
        _=>{let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
        if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}}
    }
}
#[no_mangle]
pub fn inverse_return(fee:&DecodedTransferFee, amount:u64)->Option<u64> {
    let max=fee.maximum_fee; let bps=fee.transfer_fee_basis_points as u128;
    if bps==0{return Some(amount);} if amount==0{return Some(0);} if bps==10000{return max.checked_add(amount);}
    let n=(amount as u128).checked_mul(10000)?;let d=10000u128.checked_sub(bps)?;let raw=n.checked_add(d)?.checked_sub(1)?.checked_div(d)?;
    if raw.checked_sub(amount as u128)? >= max as u128 {amount.checked_add(max)}else{u64::try_from(raw).ok()}
}
'''
(D/'diagnostic.rs').write_text(base+parser+scalar)
