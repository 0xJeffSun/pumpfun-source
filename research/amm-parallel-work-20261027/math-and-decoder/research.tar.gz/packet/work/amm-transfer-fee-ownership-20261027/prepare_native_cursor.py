from pathlib import Path
import shutil
D=Path(__file__).resolve().parent;S=D/'source-native-cursor';shutil.copytree(D/'source-decoder',S);p=S/'programs/pump-amm/src/utils/transfer_fee.rs';t=p.read_text();diag=(D/'diagnostic.rs').read_text()
a=diag.index('#[no_mangle]\npub fn decoder_cursor_split(');b=diag.index('\n#[no_mangle]',a+2);parser=diag[a:b].replace('#[no_mangle]\n','').replace('pub fn decoder_cursor_split','fn decode_transfer_fees').replace('core::result','std::result')
t=t[:t.index('/// Extract the epoch fee pair')]+parser
# Receiver ownership is a genuine Rust API variation. No representation,
# inline, or padding attributes are added to application code.
a=diag.index('#[no_mangle]\npub fn fee_owned(');b=diag.index('#[no_mangle]\npub fn inverse_owned(',a);fee=diag[a:b].replace('#[no_mangle]\n','').replace('pub fn fee_owned(fee:DecodedTransferFee, amount:u64)','pub fn native_calculate_fee(self, amount:u64)').replace('fee.','self.')
inv=diag[b:].replace('#[no_mangle]\n','').replace('pub fn inverse_owned(fee:DecodedTransferFee, amount:u64)','pub fn native_pre_fee_amount(self, amount:u64)').replace('fee.','self.')
a=t.index('impl DecodedTransferFee {');b=t.index('pub type TransferFeeData',a);t=t[:a]+'impl DecodedTransferFee {\n'+fee+'\n'+inv+'\n}\n\n'+t[b:]
t=t.replace('use anchor_spl::token_2022::spl_token_2022::{\n    extension::transfer_fee::TransferFee,\n};\n','').replace('fee.spl_fee().calculate_fee(amount)','fee.native_calculate_fee(amount)').replace('fee.spl_fee().calculate_pre_fee_amount(amount)','fee.native_pre_fee_amount(amount)');p.write_text(t)
root=Path('work/amm-pool-content-helpers-20261027/target-sbpf/sbpf-solana-solana/release/.fingerprint/pump-amm-recovered-79b27c85817e204f')
for f in root.glob('*'):
 if f.is_file():f.unlink()
