# Original source-origin atlas (8e69)

The conservative census has 71 bodies: 37 unique masked candidates and 34 with ambiguous candidates. Masked similarity is not a byte-equality or call-identity claim.

| Original file | Original error lines | Body addresses |
| --- | --- | --- |
| programs/pump-amm/src/curve/constant_product.rs | 45, 47, 85, 87, 112 | 0x11e70, 0x123a0, 0x12840 |
| programs/pump-amm/src/curve/fees.rs | 17, 19, 21, 32, 160 | 0x12b08, 0x13190, 0x13d30 |
| programs/pump-amm/src/instructions/admin/create_config.rs | 6 | 0x82630 |
| programs/pump-amm/src/instructions/admin/toggle_boost.rs | 14 | 0x1b7c0 |
| programs/pump-amm/src/instructions/admin/toggle_cashback_enabled.rs | 21 | 0x1b510 |
| programs/pump-amm/src/instructions/admin/toggle_mayhem_mode.rs | 17 | 0x1bb00 |
| programs/pump-amm/src/instructions/boost.rs | 258 | 0x22c80 |
| programs/pump-amm/src/instructions/create_pool.rs | 21, 339 | 0x2e468, 0x9e3b0, 0xa0068 |
| programs/pump-amm/src/instructions/liquidity/deposit.rs | 91, 99, 143, 152, 154, 156, 160, 162 | 0x31710, 0x31918, 0x31b20, 0x31d28, 0x31f30, 0x32138, 0x32340, 0x32548 |
| programs/pump-amm/src/instructions/liquidity/withdraw.rs | 98, 106, 150, 160, 162, 166, 170 | 0x34370, 0x34578, 0x34780, 0x34988, 0x34b90, 0x34d98, 0x34fa0 |
| programs/pump-amm/src/instructions/swap/buy.rs | 116, 121, 133, 387, 391, 395, 404, 409 | 0x37150, 0x39d80, 0x39f88, 0x3a190, 0x3a398, 0xaf3b0, 0xb3460 |
| programs/pump-amm/src/instructions/swap/multi_hop_swap.rs | 68, 579, 586, 636, 671, 718, 941 | 0x446a0, 0x448a8, 0x44cc8, 0x44ed0, 0x450d8, 0xb5a90, 0xb92c8 |
| programs/pump-amm/src/instructions/swap/sell.rs | 167, 179, 183, 196 | 0x4bf30, 0x4c138, 0x4c340, 0x4c548 |
| programs/pump-amm/src/instructions/swap/trade_v2.rs | 31, 302, 376, 377, 385, 913 | 0x50ca8, 0x516e0, 0x57e20, 0xbd3b0 |
| programs/pump-amm/src/instructions/token_incentives/init_user_volume_accumulator.rs | 8 | 0xd1290 |
| programs/pump-amm/src/lib.rs | 22, 23, 36 | 0xd7048, 0xd9dc0, 0xda540, 0xe0148, 0xe0720, 0xf23f0 |
| programs/pump-amm/src/state/global_config.rs | 220, 230, 243, 256, 263, 321, 326, 336 | 0x61630, 0x61898, 0x61b00, 0x61d68, 0x62e68 |
| programs/pump-amm/src/state/pool.rs | 386, 417, 439, 440, 458, 462, 465, 469 | 0x6b780, 0x6bcd0, 0x6c328, 0x6c768 |
| programs/pump-amm/src/state/volume_accumulator.rs | 8, 25 | 0xd44e0, 0xd4f90 |
| programs/pump-amm/src/utils/token.rs | 21 | 0x6f608 |
| programs/pump-amm/src/utils/transfer_fee.rs | 57 | 0x74900 |

Natural organization follows the observed paths: Pool methods belong in `state/pool.rs`; liquidity entry helpers belong in `instructions/liquidity`; swap entry helpers belong in `instructions/swap`. The original line positions do not determine the missing declarations, comments, blank lines, or formatting. No padding, generated line constants or remap directives are justified by this atlas.

The prior sealed workspace experiment already reproduces the path prefix through ordinary workspace membership. Recovering the original logical modules and real preceding code is still required to approach line identity.
