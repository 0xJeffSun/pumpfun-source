use anchor_lang::{prelude::*, Discriminator};
use super::GlobalConfig;
use crate::PumpAmmError;

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct Pool {
    pub pool_bump: u8,
    pub index: u16,
    pub creator: Pubkey,
    pub base_mint: Pubkey,
    pub quote_mint: Pubkey,
    pub lp_mint: Pubkey,
    pub pool_base_token_account: Pubkey,
    pub pool_quote_token_account: Pubkey,
    pub lp_supply: u64,
    pub coin_creator: Pubkey,
    pub is_mayhem_mode: bool,
    pub is_cashback_coin: bool,
    pub virtual_quote_reserves: i128,
    pub creator_fee_bps: u64,
    pub can_edit_creator_fee: bool,
    pub is_holder_reward: bool,
    pub protocol_fees: u64,
    pub creator_fees: u64,
}

impl Owner for Pool { fn owner() -> Pubkey { crate::ID } }
impl Discriminator for Pool { const DISCRIMINATOR: &'static [u8] = &[241,154,109,4,17,177,109,188]; }
impl AccountDeserialize for Pool {
    fn try_deserialize(buf: &mut &[u8]) -> Result<Self> {
        if buf.len() < 8 {
            return Err(anchor_lang::solana_program::program_error::ProgramError::InvalidAccountData.into());
        }
        let data = *buf;
        *buf = &data[8..];
        if &data[..8] != Self::DISCRIMINATOR {
            return Err(anchor_lang::solana_program::program_error::ProgramError::InvalidAccountData.into());
        }
        if buf.len() < 203 {
            return Err(anchor_lang::solana_program::program_error::ProgramError::InvalidAccountData.into());
        }
        if buf.len() < 235 { read_pool_203(buf) }
        else if buf.len() < 236 { read_pool_235(buf) }
        else if buf.len() < 237 { read_pool_236(buf) }
        else if buf.len() < 253 { read_pool_237(buf) }
        else if buf.len() < 262 { read_pool_253(buf) }
        else if buf.len() < 263 { read_pool_262(buf) }
        else if buf.len() < 279 { read_pool_263(buf) }
        else { read_pool_279(buf) }
    }
    fn try_deserialize_unchecked(buf: &mut &[u8]) -> Result<Self> {
        if buf.len() < 8 {
            return Err(anchor_lang::solana_program::program_error::ProgramError::InvalidAccountData.into());
        }
        *buf = &buf[8..];
        if buf.len() < 203 {
            return Err(anchor_lang::solana_program::program_error::ProgramError::InvalidAccountData.into());
        }
        if buf.len() < 235 { read_pool_203(buf) }
        else if buf.len() < 236 { read_pool_235(buf) }
        else if buf.len() < 237 { read_pool_236(buf) }
        else if buf.len() < 253 { read_pool_237(buf) }
        else if buf.len() < 262 { read_pool_253(buf) }
        else if buf.len() < 263 { read_pool_262(buf) }
        else if buf.len() < 279 { read_pool_263(buf) }
        else { read_pool_279(buf) }
    }
}

fn read_pool_203(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::default(),
        is_mayhem_mode: false,
        is_cashback_coin: false,
        virtual_quote_reserves: 0,
        creator_fee_bps: 0,
        can_edit_creator_fee: false,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_235(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: false,
        is_cashback_coin: false,
        virtual_quote_reserves: 0,
        creator_fee_bps: 0,
        can_edit_creator_fee: false,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_236(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: false,
        virtual_quote_reserves: 0,
        creator_fee_bps: 0,
        can_edit_creator_fee: false,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_237(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: bool::deserialize(buf)?,
        virtual_quote_reserves: 0,
        creator_fee_bps: 0,
        can_edit_creator_fee: false,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_253(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: bool::deserialize(buf)?,
        virtual_quote_reserves: i128::deserialize(buf)?,
        creator_fee_bps: 0,
        can_edit_creator_fee: false,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_262(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: bool::deserialize(buf)?,
        virtual_quote_reserves: i128::deserialize(buf)?,
        creator_fee_bps: u64::deserialize(buf)?,
        can_edit_creator_fee: bool::deserialize(buf)?,
        is_holder_reward: false,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_263(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: bool::deserialize(buf)?,
        virtual_quote_reserves: i128::deserialize(buf)?,
        creator_fee_bps: u64::deserialize(buf)?,
        can_edit_creator_fee: bool::deserialize(buf)?,
        is_holder_reward: bool::deserialize(buf)?,
        protocol_fees: 0,
        creator_fees: 0,
    })
}

fn read_pool_279(buf: &mut &[u8]) -> Result<Pool> {
    Ok(Pool {
        pool_bump: u8::deserialize(buf)?,
        index: u16::deserialize(buf)?,
        creator: Pubkey::deserialize(buf)?,
        base_mint: Pubkey::deserialize(buf)?,
        quote_mint: Pubkey::deserialize(buf)?,
        lp_mint: Pubkey::deserialize(buf)?,
        pool_base_token_account: Pubkey::deserialize(buf)?,
        pool_quote_token_account: Pubkey::deserialize(buf)?,
        lp_supply: u64::deserialize(buf)?,
        coin_creator: Pubkey::deserialize(buf)?,
        is_mayhem_mode: bool::deserialize(buf)?,
        is_cashback_coin: bool::deserialize(buf)?,
        virtual_quote_reserves: i128::deserialize(buf)?,
        creator_fee_bps: u64::deserialize(buf)?,
        can_edit_creator_fee: bool::deserialize(buf)?,
        is_holder_reward: bool::deserialize(buf)?,
        protocol_fees: u64::deserialize(buf)?,
        creator_fees: u64::deserialize(buf)?,
    })
}

impl AccountSerialize for Pool {
    fn try_serialize<W: std::io::Write>(&self, writer: &mut W) -> Result<()> {
        writer.write_all(Self::DISCRIMINATOR)?;
        self.serialize(writer)?;
        Ok(())
    }
}

impl Pool {
    #[inline(never)]
    pub fn total_accrued_fees(&self) -> Result<u64> {
        self.protocol_fees
            .checked_add(self.creator_fees)
            .ok_or_else(|| error!(PumpAmmError::Overflow))
    }

    #[inline(never)]
    pub fn available_quote_reserves(&self, quote_token_reserves: u64) -> Result<u64> {
        quote_token_reserves
            .checked_sub(self.total_accrued_fees()?)
            .ok_or_else(|| error!(PumpAmmError::Overflow))
    }

    #[inline(never)]
    pub fn effective_quote_reserves(&self, quote_token_reserves: u64) -> Result<u64> {
        let amount = (quote_token_reserves as i128).checked_add(self.virtual_quote_reserves)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        u64::try_from(amount).map_err(|_| error!(PumpAmmError::Overflow))
    }

    #[inline(never)]
    pub fn accrue_fees(
        &mut self,
        global_config: &GlobalConfig,
        mut protocol_fee: u64,
        creator_fee: u64,
    ) -> Result<u64> {
        let buyback_fee = if self.is_mayhem_mode {
            0
        } else {
            let buyback_fee = u64::try_from(
                (protocol_fee as u128) * (global_config.buyback_basis_points as u128) / 10_000,
            )
            .expect("buyback fee is at most protocol_fee");
            protocol_fee = protocol_fee
                .checked_sub(buyback_fee)
                .expect("buyback_fee never exceeds protocol_fee");
            buyback_fee
        };
        self.protocol_fees = self
            .protocol_fees
            .checked_add(protocol_fee)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        self.creator_fees = self
            .creator_fees
            .checked_add(creator_fee)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        let total = protocol_fee
            .checked_add(creator_fee)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        self.virtual_quote_reserves = self
            .virtual_quote_reserves
            .checked_sub(total as i128)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        Ok(buyback_fee)
    }

    #[inline(never)]
    pub fn take_accrued_fees(&mut self, creator: bool) -> Result<u64> {
        let amount = core::mem::take(if creator {
            &mut self.creator_fees
        } else {
            &mut self.protocol_fees
        });
        self.virtual_quote_reserves = self.virtual_quote_reserves
            .checked_add(amount as i128)
            .ok_or_else(|| error!(PumpAmmError::Overflow))?;
        Ok(amount)
    }
}
