#!/usr/bin/env python3
"""Authenticate full-field sweep-helper replays without discarding diagnostics."""
from pathlib import Path
import base64, gzip, hashlib, importlib.util, json
from solders.transaction import Transaction

D = Path(__file__).resolve().parent
ROOT = D.parents[1]
spec = importlib.util.spec_from_file_location('direct', ROOT / 'repro/pump_amm/diagnostic-parity-20261027/compare_direct.py')
direct = importlib.util.module_from_spec(spec)
spec.loader.exec_module(direct)
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
sha = lambda b: hashlib.sha256(b).hexdigest()
candidate_sha = sha((D / 'build/artifacts/pump_amm_recovered.so').read_bytes())
summary = {'candidate_sha256': candidate_sha, 'runs': [], 'signatures': 0}
for name, report_path, sidecar_path, producer in [
    ('focused', 'focused-results.json.gz', 'focused-transactions.json.gz', ROOT / 'work/amm-fee-payout-edge-audit-20261027/probe.py'),
    ('existing', 'existing-full.json.gz', 'existing-transactions.json.gz', ROOT / 'work/amm-pool-sweep-helpers-20261027/run_existing.py'),
]:
    report, observed = load(D / report_path), load(D / sidecar_path)
    rows, transactions = report['cases'], observed['transactions']
    assert report['candidate_sha256'] == candidate_sha
    assert len(transactions) == 2 * len(rows) == 2 * report['case_count']
    assert observed['script_sha256'] == sha(producer.read_bytes())
    if name == 'focused':
        assert report['producer_sha256'] == observed['script_sha256']
    else:
        assert report['full_diagnostic_adapter_sha256'] == observed['script_sha256']
        assert report['original_suite_sha256'] == sha((ROOT / 'scripts/pump_amm_sweep_differential.py').read_bytes())
    failures = []
    for i, row in enumerate(rows):
        assert direct.clean(row['original']) == direct.clean(row['candidate']), (name, i)
        assert row['original_receipt']['before'] == row['candidate_receipt']['before']
        assert row['original_receipt']['after'] == row['candidate_receipt']['after']
        left, right = transactions[2 * i:2 * i + 2]
        assert left['transaction_sha256'] == right['transaction_sha256'] == row['original_receipt']['tx_sha256'] == row['candidate_receipt']['tx_sha256']
        for side, txrow in [('original', left), ('candidate', right)]:
            raw = base64.b64decode(txrow['transaction_base64'], validate=True)
            assert sha(raw) == txrow['transaction_sha256']
            tx = Transaction.from_bytes(raw)
            assert all(tx.verify_with_results()) and txrow['all_signatures_verified']
            assert len(tx.signatures) == txrow['signature_count']
            summary['signatures'] += len(tx.signatures)
            assert txrow['logs_sha256'] == sha(json.dumps(row[side]['logs'], separators=(',', ':')).encode())
            assert txrow['amm_program_sha256'] == report[side + '_sha256']
    summary['runs'].append({'name': name, 'cases': len(rows), 'mismatches': 0, 'same_signed_transactions': True, 'same_account_prestates': True, 'same_full_account_poststates': True, 'full_logs_bound_to_receipts': True})
summary['case_count'] = sum(run['cases'] for run in summary['runs'])
summary['normalization'] = 'Only source locations and compute-consumption log lines, using the unchanged compare_direct.clean; all other recorded fields compared.'
(D / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))

route_spec = importlib.util.spec_from_file_location('routes', ROOT / 'repro/pump_amm/error-order-recovery-20261027/verify_routes.py')
route = importlib.util.module_from_spec(route_spec)
route_spec.loader.exec_module(route)
proof = route.verify(D/'decoder-results.json', D/'decoder-observer.json.gz', D/'build/artifacts/pump_amm_recovered.so', ROOT/'repro/pump_amm/error-order-recovery-20261027/probe_pool_decoders.py', 46, own=D/'decoder-results-transactions.json.gz')
summary['runs'].append({'name':'pool-decoders', **proof})
summary['case_count'] += proof['cases']
summary['signatures'] += proof['signatures']
(D/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
