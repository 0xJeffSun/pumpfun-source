# Pool source organization, private evidence

`organization.patch` is based on frozen `8e69` plus the already validated
`work/amm-pool-sweep-helpers-20261027/pool-sweep-helpers.patch`. It moves Pool and
its unchanged codecs into `src/state/pool.rs`, re-exports the type, and orders
the known methods by their original source locations. This is a natural source
organization hypothesis, not proof of the complete original source text.

The original binary directly records `programs/pump-amm/src/state/pool.rs` and
the following error locations: market capitalization helper 386; total fees
408; available quote 417; total virtual/fee reserve helper 426; effective quote
439/440; accrual 458/462/465/469; taking fees 484. The two additional helper
bodies at `0x6b780` and `0x6bf50` are not reconstructed by this patch.

One strict cached Linux v1.44 SBF build succeeded with source and dependency
bytes unchanged. Candidate SHA-256 is
`0abc1bf4db0f807f05ccad8ad97dee2f5e9fb872db3d2e5d33819d449657ab57`.
The prerequisite and relocated builds both match 579 normalized windows / 115
raw bodies, with no gains or losses. This SBF count excludes the separately
proven SBPF TypeId gains and is not a new selected checkpoint score.

All eight historical Pool readers and their direct callees remain exact; both
complete decoder frontends remain exact. The serializer source is moved
verbatim. All 636 signed cases pass: 336 payout edges, 254 existing sweeps, and
46 Pool decoder cases. Verification authenticates 1,272 signatures and compares
all preserved logs and account snapshots, normalizing only source locations
and compute-consumption logs.

The prior sealed `repro/pump_amm/workspace-layout-20261026` experiment already
shows that ordinary Cargo workspace membership yields the original
`programs/pump-amm/src/...` prefix. It reported no exact-window gains. Its Darwin
result is not silently treated as a Linux result here. No workspace-only build
was repeated. The older census counted 69 source-origin-only bodies; rerunning it on 8e69
finds 71, including 34 with ambiguous candidate counterparts. The source atlas
keeps those ambiguities explicit; prefix changes do not establish full source
identity.

No source padding, line directives, synthetic diagnostic values or remap flags
were introduced. Exact original line layout remains underdetermined; this
bounded experiment preserves codecs but supplies no identity gain. See
`findings.json`, `original-pool-source-locations.json`, and `verification.json`.
