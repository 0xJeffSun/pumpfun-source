from pathlib import Path
import json,sys,tarfile,hashlib,subprocess,difflib
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'research/mayhem-sweep-failure-recovery'))
from static import module
from source import recover
base={}
with tarfile.open(R/'research/mayhem-initializer-current-recovery-20261027/source.tar.gz') as t:
 for m in t:base[m.name]=t.extractfile(m).read()
base['src/instructions/pump_interface.rs']=(R/'research/mayhem-current-ownership-composition-20261027/sources/qualified.rs').read_bytes()
for n in ('src/state.rs','src/instructions/sell_pump_swap.rs'):base[n]=(R/'research/mayhem-sell-current-recovery-20261027/overrides'/n).read_bytes()
for n in ('src/state.rs','src/instructions/buy_pump_swap.rs'):base[n]=(R/'research/mayhem-quotes-current-recovery-20261027/overrides'/n).read_bytes()
assert {n:hashlib.sha256(b).hexdigest() for n,b in base.items()}==json.loads((R/'research/mayhem-quotes-current-recovery-20261027/source-inputs.json').read_bytes())
reader=module('rate_reader',R/'research/mayhem-trade-origins-validator/reader.py');o=reader.Elf(R/'evidence/original/mayhem/deployed.so');on,op=o.norm(65472,66384)
path='src/instructions/fee_recipients.rs';text=base[path].decode()
load='let last = if native {self.field_10}else{self.field_34} as i64;'
store='if native {self.field_10=current_time as u64;}else{self.field_34=current_time as u64;}'
assert text.count(load)==text.count(store)==1
# Variants preserve all source line numbers unless named otherwise; build records bind exact inputs.
cases=[('baseline',text,False),('comparison-load',text.replace(load,'let last = if native == false {self.field_34}else{self.field_10} as i64;'),False)]
start=cases[1][1]
for hint in ('likely','unlikely'):
 for expr in ('current_time >= next_time','last != 0 && interval != 0','native'):
  if expr=='native':
   # Only hint the final store branch.
   t=start.replace(store,store.replace('if native','if core::intrinsics::'+hint+'(native)'))
  else:t=start.replace(expr,'core::intrinsics::'+hint+'('+expr+')')
  cases.append((hint+'-'+expr.split()[0],t,True))
for expr in ('current_time >= next_time','last != 0','interval != 0'):
 for prob in (0.01,0.10,0.25,0.75,0.90,0.99):
  t=start.replace(expr,f'core::intrinsics::likely({expr})') if prob==0.99 else start.replace(expr,f'core::intrinsics::unlikely(!({expr})) == false')
  # Two alternative polarity spellings, no numeric branch probability intrinsic required.
  if prob not in (0.01,0.99):continue
  cases.append(('polarity-'+expr.split()[0]+'-'+str(prob),t,True))
cases.extend([
 ('require-in-closure',start.replace('        if last != 0 && interval != 0 {','        let validate = || -> Result<()> { if last != 0 && interval != 0 {').replace('        }\n        '+store,'        } Ok(()) }; validate()?;\n        '+store),False),
 ('whole-body-closure',start.replace('        let last =','        (|| { let last =',1).replace('        Ok(())','        Ok(()) })()',1),False),
 ('store-closure',start.replace(store,'(|| {'+store+'})();'),False),
 ('store-result-closure',start.replace(store,'return (|| {'+store+' Ok(())})();').replace('        Ok(())','',1),False),
 ('returned-check-closure',start.replace('        if last != 0 && interval != 0 {','        let result = (|| -> Result<()> { if last != 0 && interval != 0 {').replace('        }\n        '+store,'        } Ok(()) })(); result?;\n        '+store),False),
 ('store-via-match-ref',start.replace(store,'*match native {true => &mut self.field_10, false => &mut self.field_34}=current_time as u64;'),False),
 ('scoped-mutable-ref',start.replace(store,'{let slot=if native {&mut self.field_10}else{&mut self.field_34};*slot=current_time as u64;}'),False),
 ('error-result-if',start.replace('require!(current_time >= next_time, crate::MayhemError::SweepFeeRateLimit);','if current_time < next_time {return err!(crate::MayhemError::SweepFeeRateLimit);}'),False),
 ('postguard-match',start.replace('require!(current_time >= next_time, crate::MayhemError::SweepFeeRateLimit);','match current_time >= next_time {true=>(),false=>return Err(error!(crate::MayhemError::SweepFeeRateLimit))}'),False),
 ('postguard-boolean-false',start.replace('current_time >= next_time','(current_time < next_time) == false'),False),
 ('postguard-boolean-true',start.replace('current_time >= next_time','(current_time >= next_time) == true'),False),
 ('bool-tuple-match',start.replace('if last != 0 && interval != 0 {','if let (true,true) = (last != 0, interval != 0) {'),False),
 ('interval-before-last',start.replace('last != 0 && interval != 0','interval != 0 && last != 0'),False),
 ('select-global-interval',start.replace('let interval = global_params.field_10 as i64;','let interval; {interval=global_params.field_10 as i64;}'),False),
])
for hint in ('likely','unlikely'):
 for native in ('native','native == false'):
  t=start.replace('if native == false',f'if core::intrinsics::{hint}({native})')
  if native=='native':t=t.replace('{self.field_34}else{self.field_10}','{self.field_10}else{self.field_34}')
  # Hint both checks on distinct predicates.
  for checkhint in ('likely','unlikely'):
   t2=t.replace('current_time >= next_time',f'core::intrinsics::{checkhint}(current_time >= next_time)')
   cases.append((f'combined-{hint}-{native.replace(" ","")}-{checkhint}',t2,True))
for name,guard in [('early-empty','if last == 0 || interval == 0'),('early-not-active','if !(last != 0 && interval != 0)'),('early-inverse','if (last != 0 && interval != 0) == false')]:
 t=start.replace('if last != 0 && interval != 0 {',guard+' {'+store+' return Ok(()); } {')
 cases.append((name,t,False))
for name,guard in [('branch-store','if last != 0 && interval != 0'),('match-state','if let (false,false) = (last==0,interval==0)')]:
 t=start.replace('if last != 0 && interval != 0 {',guard+' {').replace('        }\n        '+store,'        '+store+' } else { '+store+' }\n')
 cases.append((name,t,False))
for loadexpr in ('if native {self.field_10}else{self.field_34}', 'if native == false {self.field_34}else{self.field_10}'):
 for shape in ('cold','inline-never','optimize-size','optimize-speed'):
  feature='optimize_attribute' if shape.startswith('optimize') else None
  attr={'cold':'#[cold]','inline-never':'#[inline(never)]','optimize-size':'#[optimize(size)]','optimize-speed':'#[optimize(speed)]'}[shape]
  t=start.replace('    pub fn validate_sweep',attr+' pub fn validate_sweep').replace('if native == false {self.field_34}else{self.field_10}',loadexpr)
  cases.append((shape+('-plain' if '== false' not in loadexpr else '-comparison'),t,feature))
# Reordering logically independent nonzero conditions and success paths changes CFG construction.
for typename in ('i64','u64'):
 t=start.replace('let last = if native == false {self.field_34}else{self.field_10} as i64;',f'let last:{typename} = if native == false {{self.field_34 as {typename}}}else{{self.field_10 as {typename}}};')
 if typename=='u64':t=t.replace('last + interval','last as i64 + interval')
 cases.append(('load-casts-'+typename,t,False))
for form in ('scope','map','and_then','match'):
 t=start.replace('        if last != 0 && interval != 0 {','        let checked=(|| -> Result<()> { if last != 0 && interval != 0 {').replace('        }\n        '+store,'        } Ok(()) })();\n        '+store)
 if form=='scope':t=t.replace(store,'checked?; '+store)
 if form=='map':t=t.replace(store,'return checked.map(|()| {'+store+'});').replace('        Ok(())','',1)
 if form=='and_then':t=t.replace(store,'return checked.and_then(|()| {'+store+' Ok(())});').replace('        Ok(())','',1)
 if form=='match':t=t.replace(store,'match checked {Ok(())=>{'+store+'},Err(error)=>return Err(error)}')
 cases.append(('checked-'+form,t,False))
for returnform in ('if-result','if-error','match-result'):
 if returnform=='if-result':check='let checked=if current_time >= next_time {Ok(())} else {Err(error!(crate::MayhemError::SweepFeeRateLimit))}; checked?;'
 if returnform=='if-error':check='let checked=if current_time < next_time {Err(error!(crate::MayhemError::SweepFeeRateLimit))} else {Ok(())}; checked?;'
 if returnform=='match-result':check='let checked=match current_time >= next_time {true=>Ok(()), false=>Err(error!(crate::MayhemError::SweepFeeRateLimit))}; checked?;'
 cases.append((returnform,start.replace('require!(current_time >= next_time, crate::MayhemError::SweepFeeRateLimit);',check),False))

for reference in (False,True):
 for placement in ('nested','earlier'):
  lines=start.splitlines(True)
  args='last:&i64,interval:&i64,current_time:&i64' if reference else 'last:i64,interval:i64,current_time:i64'
  lines[50]='        let last = if native == false {self.field_34}else{self.field_10} as i64;\n'
  lines[51]='        let interval = global_params.field_10 as i64;\n'
  lines[53]='        #[inline(always)] fn check('+args+')->Result<()> {\n'
  lines[54]='        let (last,interval,current_time)=(*last,*interval,*current_time);\n' if reference else '\n'
  lines[61]='        } Ok(()) }\n'
  lines[62]='        check('+('&last,&interval,&current_time' if reference else 'last,interval,current_time')+')?; '+store+'\n'
  if placement=='earlier':
   # Keep the actual panic/error lines by declaring the nested function before the clock read.
   lines[46]='        let current_time = Clock::get().unwrap().unix_timestamp;\n'
   lines[53]='        #[inline] fn check('+args+')->Result<()> {\n'
  cases.append((f'helper-{placement}-'+str(reference),''.join(lines),False))
for native in (True,False):
 t=start.replace('let last = if native == false {self.field_34}else{self.field_10} as i64;', 'let last = match native { false => {self.field_34 as i64}, true => {self.field_10 as i64}};')
 if native:t=t.replace('false => {self.field_34 as i64}, true => {self.field_10 as i64}','true => {self.field_10 as i64}, false => {self.field_34 as i64}')
 cases.append(('match-load-casts-'+str(native),t,False))

for shape in ('optional','optional-match','nested','tuple','while','loop','loop-guard','loop-block','and-then-optional'):
 lines=start.splitlines(True)
 if shape in ('optional','optional-match','and-then-optional'):
  lines[55]='        let next = if last != 0 && interval != 0 {\n'
  lines[58]='            Some(next_time)\n'
  lines[59]='        } else { None }; if let Some(next_time) = next {\n'
  if shape=='optional-match':lines[59]='        } else { None }; match next { None=>{}, Some(next_time) => {\n';lines[61]='        }}\n'
  if shape=='and-then-optional':
   lines[59]='        } else { None }; let result=next.map_or(Ok(()), |next_time| {\n'
   lines[61]='        Ok(()) }); result?;\n'
 if shape=='nested':lines[55]='        if last != 0 { if interval != 0 {\n';lines[61]='        }}\n'
 if shape=='tuple':lines[55]='        match (last,interval) { (0,_)|(_,0) => {}, _ => {\n';lines[61]='        }}\n'
 if shape=='while':lines[55]='        while last != 0 && interval != 0 {\n';lines[61]='        break; }\n'
 if shape=='loop':lines[55]='        loop { if last == 0 || interval == 0 {break;}\n';lines[61]='        break; }\n'
 if shape=='loop-guard':lines[55]='        loop { if last != 0 && interval != 0 {\n';lines[61]='        } break; }\n'
 if shape=='loop-block':lines[55]="        'checked: { if last == 0 || interval == 0 { break 'checked; }\n"
 cases.append((shape,''.join(lines),False))
for shape in ('clock-closure','clock-helper','clock-match','clock-local','global-borrow','self-borrow'):
 t=start
 if shape=='clock-closure':t=t.replace('Clock::get().unwrap().unix_timestamp','(|| {Clock::get().unwrap().unix_timestamp})()')
 if shape=='clock-helper':t=t.replace('let current_time = Clock::get().unwrap().unix_timestamp;','#[inline(always)] fn now()->i64 {Clock::get().unwrap().unix_timestamp} let current_time=now();')
 if shape=='clock-match':t=t.replace('Clock::get().unwrap().unix_timestamp','match Clock::get() {Ok(clock)=>clock.unix_timestamp,Err(err)=>Err::<Clock,_>(err).unwrap().unix_timestamp}')
 if shape=='clock-local':t=t.replace('let current_time = Clock::get().unwrap().unix_timestamp;','let clock = Clock::get().unwrap(); let current_time = clock.unix_timestamp;')
 if shape=='global-borrow':t=t.replace('let interval = global_params.field_10 as i64;','let interval = *&global_params.field_10 as i64;')
 if shape=='self-borrow':t=t.replace('let last = if native == false {self.field_34}else{self.field_10} as i64;','let last = if native == false {*&self.field_34}else{*&self.field_10} as i64;')
 cases.append((shape,t,False))

for first,last in ((True,False),(False,True),(True,True)):
 t=start
 if first:t=t.replace('field_10:u64','field_10:i64').replace('self.field_10=current_time as u64','self.field_10=current_time').replace('{self.field_10} as i64','{self.field_10 as u64} as i64')
 if last:t=t.replace('field_34:u64','field_34:i64').replace('self.field_34=current_time as u64','self.field_34=current_time').replace('{self.field_34}else','{self.field_34 as u64}else')
 if first and last:t=t.replace('if native == false {self.field_34 as u64}else{self.field_10 as u64} as i64','if native == false {self.field_34}else{self.field_10}')
 cases.append((f'signed-fields-{first}-{last}',t,False))
for kind in ('u8','u32','u64','usize'):
 for cmp in ('eq','ne'):
  t=start.replace('native:bool','native:'+kind)
  if cmp=='eq':t=t.replace('if native == false','if native == 0').replace('if native {','if native != 0 {')
  else:t=t.replace('if native == false {self.field_34}else{self.field_10}','if native != 0 {self.field_10}else{self.field_34}').replace('if native {','if native != 0 {')
  marker='\n#[derive(Accounts)]';t=t[:t.index(marker)]+start[start.index(marker):]
  cases.append((f'arg-{kind}-{cmp}',t,False))

selected=set(sys.argv[1:]);shared=W/'source'
if not shared.exists():
 for n,b in base.items():p=shared/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for name,t,feature in cases:
 if selected and name not in selected:continue
 d=W/name
 if d.exists():continue
 d.mkdir();after=dict(base);after[path]=t.encode()
 if name.startswith('arg-'):
  old=b'.validate_sweep(global_params, mint == anchor_spl::token::spl_token::native_mint::ID)?';assert after['src/lib.rs'].count(old)==1
  after['src/lib.rs']=after['src/lib.rs'].replace(old,('.validate_sweep(global_params, (mint == anchor_spl::token::spl_token::native_mint::ID) as '+name.split('-')[1]+')?').encode())
 if feature:
  lines=after['src/lib.rs'].decode().splitlines(True);lines[2]='#![feature('+('core_intrinsics' if feature is True else feature)+')]\n';after['src/lib.rs']=''.join(lines).encode()
 for n in (path,'src/lib.rs'):(shared/n).write_bytes(after[n])
 for n,b in after.items():
  if b!=base[n]:p=d/'overrides'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 cmd=[sys.executable,'-B',str(R/'research/mayhem-sizing-panic-recovery/build.py'),'--source',str(shared),'--sdk',str(R/'work/mayhem-recovery/verified-sdk'),'--cargo-home',str(R/'work/mayhem-recovery/cargo-home'),'--target',str(W/'target'),'--output',str(d/'build'),'--strip',str(R/'work/mayhem-recovery/llvm-objcopy-v152'),'--linker-script',str(R/'research/mayhem-trade-origins-validator/config/ordered.ld')]
 (d/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (d/'driver.log').open('wb') as log:res=subprocess.run(cmd,cwd=R,stdout=log,stderr=log)
 if res.returncode:print(name,'failed',flush=True);continue
 e=reader.Elf(d/'build/symbols.so');fs=[s for s in e.symbols if '14validate_sweep' in s['name'] and s['info']&15==2];assert len(fs)==1;f=fs[0];cn,cp=e.norm(f['value'],f['value']+f['size']);aa=[on[i:i+8] for i in range(0,len(on),8)];bb=[cn[i:i+8] for i in range(0,len(cn),8)]
 score=dict(name=name,start=f['value'],bytes=f['size'],equal=cn==on and cp==op,equal_slots=sum(a==b for a,b in zip(aa,bb)),aligned_slots=sum(x.size for x in difflib.SequenceMatcher(a=aa,b=bb,autojunk=False).get_matching_blocks()))
 (d/'measurement.json').write_text(json.dumps(score,indent=2)+'\n');print(json.dumps(score),flush=True)
 if score['equal']:print('MATCH FOUND',name,flush=True);break
