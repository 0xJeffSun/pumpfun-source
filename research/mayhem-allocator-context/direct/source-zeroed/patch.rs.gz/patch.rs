
pub fn allocation_context_probe(length: usize) -> Vec<u8> { vec![0; length] }
