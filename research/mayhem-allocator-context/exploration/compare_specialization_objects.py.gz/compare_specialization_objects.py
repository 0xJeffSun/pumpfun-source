from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent
P=W/'mayhem-specialization-provenance'
def ident(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def members(b):
    assert b[:8]==b'!<arch>\n'
    at=8;long=b'';result={}
    while at<len(b):
        h=b[at:at+60];assert len(h)==60 and h[58:]==b'`\n'
        n=h[:16].decode().strip();size=int(h[48:58]);at+=60;d=b[at:at+size];at+=size+(size%2)
        if n=='//':long=d
        elif n.startswith('/')and n[1:].isdigit():
            start=int(n[1:]);end=long.index(b'/\n',start);n=long[start:end].decode()
        elif n.endswith('/')and n!='/':n=n[:-1]
        assert n not in result;result[n]=d
    assert at==len(b);return result
report={}
for crate in ('curve_accounts','spl_token_2022_interface'):
    baseline=next((P/(crate+'-baseline')).glob('*.rlib'))
    launch=json.loads((baseline.parent/'launch.json').read_bytes())
    args=launch['reference_record']['after'];old=Path(args[args.index('--out-dir')+1])/baseline.name
    paths={'reference':old,'baseline':baseline,'llvm-ir':next((P/(crate+'-llvm-ir')).glob('*.rlib'))}
    contents={k:members(p.read_bytes())for k,p in paths.items()}
    report[crate]={'archives':{k:dict(path=str(p),**ident(p.read_bytes()))for k,p in paths.items()},'members':{}}
    for name in contents['reference']:
        rows={k:ident(v[name])for k,v in contents.items()}
        report[crate]['members'][name]=rows
        if name.endswith('.o'):
            print(crate,name,rows)
            for k,v in contents.items():
                output=P/(crate+'-'+k+'.o');output.write_bytes(v[name])
                r=subprocess.run([str(W/'mayhem-native-build/sdk/llvm/bin/llvm-objdump.exe'),'--syms',str(output)],capture_output=True)
                (P/(crate+'-'+k+'-symbols.txt')).write_bytes(r.stdout);r.check_returncode()
    report[crate]['object_equal']=all(len({x['sha256']for x in rows.values()})==1 for n,rows in report[crate]['members'].items()if n.endswith('.o'))
(P/'object-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
