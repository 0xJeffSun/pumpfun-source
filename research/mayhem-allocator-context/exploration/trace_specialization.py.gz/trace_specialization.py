from pathlib import Path
import re,json,difflib
P=Path(__file__).resolve().parent/'mayhem-specialization-provenance'
def trace(crate):
    text=(P/(crate+'-trace/stderr.log')).read_text()
    chunks=re.split(r'(?m)^(?:; )?\*\*\* IR Dump After ',text)
    out=[]
    for c in chunks[1:]:
        title,_,body=c.partition('\n')
        m=re.search(r'(?ms)^define .*?^}\n',body)
        if not m:continue
        body=m.group()
        normalized=re.sub(r'17h[0-9a-f]{16}E','17hHASHE',body)
        normalized=re.sub(r'![0-9]+','!ID',normalized)
        normalized=re.sub(r'#[0-9]+','#ID',normalized)
        normalized=re.sub(r';[^\n]*','',normalized)
        normalized='\n'.join(x.rstrip()for x in normalized.splitlines()if x.strip())
        title=re.sub(r'17h[0-9a-f]{16}E','17hHASHE',title)
        out.append(dict(title=title,ir=body,normalized=normalized))
    return out
a,b=[trace(x)for x in ('curve_accounts','spl_token_2022_interface')]
for crate,rows in zip(('curve_accounts','spl_token_2022_interface'),(a,b)):
    (P/(crate+'-pass-dumps.json')).write_text(json.dumps(rows,indent=2)+'\n')
    changes=[(i,r['title'])for i,r in enumerate(rows)if i==0 or r['normalized']!=rows[i-1]['normalized']]
    print(crate,'dumps',len(rows),'changes',changes)
titlesa=[r['title']for r in a];titlesb=[r['title']for r in b]
matcher=difflib.SequenceMatcher(None,titlesa,titlesb,autojunk=False)
same=True
for block in matcher.get_matching_blocks():
    for ai,bi in zip(range(block.a,block.a+block.size),range(block.b,block.b+block.size)):
        equal=a[ai]['normalized']==b[bi]['normalized']
        if equal!=same:
            print('EQUALITY CHANGE',ai,bi,equal,a[ai]['title'])
            diff='\n'.join(difflib.unified_diff(a[ai]['normalized'].splitlines(),b[bi]['normalized'].splitlines(),fromfile='curve',tofile='token22'))
            (P/('first-difference-'+str(ai)+'.diff')).write_text(diff+'\n')
            print(diff[:5000]);same=equal
