from pathlib import Path
import re,json,difflib
P=Path(__file__).resolve().parent/'mayhem-specialization-provenance'
def canonical(text):
    text=re.sub(r'17h[0-9a-f]{16}E','17hHASHE',text)
    text=re.sub(r'![0-9]+','!ID',text);text=re.sub(r'#[0-9]+','#ID',text)
    text=re.sub(r'@[0-9]+','@GLOBAL',text)
    text=re.sub(r';[^\n]*','',text)
    return '\n'.join(x.rstrip()for x in text.splitlines()if x.strip())
def parse(crate):
    text=(P/(crate+'-expanded/stderr.log')).read_text();out={}
    for c in re.split(r'(?m)^(?:; )?\*\*\* IR Dump After ',text)[1:]:
        title,_,body=c.partition('\n')
        for m in re.finditer(r'(?ms)^define .*?^}\n',body):
            ir=m.group();n=re.search(r'@"?([^" (]+)',ir).group(1);key=canonical(n)
            out.setdefault(key,[]).append(dict(title=canonical(title),ir=ir,normalized=canonical(ir)))
    return out
a,b=[parse(x)for x in ('curve_accounts','spl_token_2022_interface')];report={}
for n in sorted(a.keys()&b.keys()):
    aa,bb=a[n],b[n];pairs=[]
    m=difflib.SequenceMatcher(None,[r['title']for r in aa],[r['title']for r in bb],autojunk=False)
    for block in m.get_matching_blocks():
        pairs.extend((ai,bi)for ai,bi in zip(range(block.a,block.a+block.size),range(block.b,block.b+block.size)))
    mismatch=next(((i,j)for i,j in pairs if aa[i]['normalized']!=bb[j]['normalized']),None)
    report[n]=dict(dumps=[len(aa),len(bb)],aligned=len(pairs),first_mismatch=mismatch)
    print(n,report[n])
    if mismatch:
        i,j=mismatch;print('PASS',aa[i]['title'])
        diff='\n'.join(difflib.unified_diff(aa[i]['normalized'].splitlines(),bb[j]['normalized'].splitlines(),fromfile='curve',tofile='token22'))
        short=re.sub(r'[^a-zA-Z0-9_]','_',n)
        (P/(short+'-first.diff')).write_text(diff+'\n')
        report[n].update(title=aa[i]['title'],curve_before=aa[i-1]if i else None,token_before=bb[j-1]if j else None,curve_after=aa[i],token_after=bb[j])
        if '10alloc_impl'in n or '8allocate'in n:print(diff[:6000])
(P/'callee-trace-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
