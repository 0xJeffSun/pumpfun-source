from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent/'mayhem-specialization-provenance'
expanded=json.loads((P/'curve_accounts-expanded/launch.json').read_bytes())
flags=[a for a in expanded['command']if a.startswith('-Cllvm-args=')]
for mode in ('source-zeroed','source-nonzero'):
    launch=json.loads((P/mode/'launch.json').read_bytes());out=P/(mode+'-trace');out.mkdir(exist_ok=False)
    launch['command'][launch['command'].index('--out-dir')+1]=str(out);launch['command']+=flags
    (out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
    with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
        r=subprocess.run(launch['command'],cwd=launch['cwd'],env=launch['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    identity=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (out/'result.json').write_text(json.dumps(dict(returncode=r.returncode,outputs={p.name:identity(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta')}),indent=2)+'\n')
    print(mode,r.returncode,flush=True);r.check_returncode()
