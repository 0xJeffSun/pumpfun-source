from pathlib import Path
import hashlib,json,re,struct,runpy
W=Path(__file__).resolve().parent;P=W/'mayhem-specialization-provenance'
ar=runpy.run_path(str(W/'compare_specialization_objects.py'))['members']
def identity(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def sections(b):
    assert b[:6]==b'\x7fELF\x02\x01'
    off=struct.unpack_from('<Q',b,40)[0];size,count,strings=struct.unpack_from('<HHH',b,58)
    assert size==64
    headers=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)for i in range(count)]
    h=headers[strings];names=b[h[4]:h[4]+h[5]];out={}
    for h in headers:
        n=names[h[0]:names.index(b'\0',h[0])].decode();out[n]=dict(type=h[1],flags=h[2],offset=h[4],size=h[5],data=b[h[4]:h[4]+h[5]])
    return out
result={}
for crate in ('curve_accounts','spl_token_2022_interface'):
    ref=(P/(crate+'-reference.o')).read_bytes();rs=sections(ref)
    result[crate]={}
    for mode in ('baseline','llvm-ir','corrected','corrected-ir','trace'):
        archive=next((P/(crate+'-'+mode)).glob('*.rlib'));objects={n:b for n,b in ar(archive.read_bytes()).items()if n.endswith('.o')};assert len(objects)==1
        name,b=next(iter(objects.items()));ss=sections(b)
        target=next(n for n in rs if n.startswith('.text')and 'finish_grow'in n)
        changed=[n for n in rs if n not in ss or rs[n]['data']!=ss[n]['data']]
        result[crate][mode]=dict(object=identity(b),object_equal=b==ref,changed_sections=changed,
           changed_text=[n for n in changed if rs[n]['flags']&4],finish=identity(ss[target]['data']),finish_equal=ss[target]['data']==rs[target]['data'])
        print(crate,mode,'whole_object',b==ref,'changedtext',len(result[crate][mode]['changed_text']),'finishsame',result[crate][mode]['finish_equal'])
    trace=(P/(crate+'-trace')/'stderr.log').read_text()
    chunks=re.split(r'(?m)^\*\*\* IR Dump After ',trace)
    prior=None;changes=[]
    for i,c in enumerate(chunks[1:]):
        title,_,body=c.partition('\n')
        if body!=prior:
            changes.append(dict(index=i,title=title,ir=body));prior=body
    (P/(crate+'-changes.json')).write_text(json.dumps(changes,indent=2)+'\n')
    print(crate,'passdumps',len(chunks)-1,'changes',len(changes),'tracebytes',len(trace))
(P/'section-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
