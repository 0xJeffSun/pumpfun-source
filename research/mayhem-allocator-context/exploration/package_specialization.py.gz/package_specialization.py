from pathlib import Path
import gzip,hashlib,json,shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-specialization-provenance';D=P/'publication';Q=W/'pumpfun-source/research/mayhem-native-qualified-identity'
D.mkdir(exist_ok=True)
def put(n,b):
    p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def gz(n,b):put(n+'.gz',gzip.compress(b,mtime=0))
def save(n,v):put(n,(json.dumps(v,indent=2)+'\n').encode())
for p in(P/'full-controller').rglob('*'):
    if p.is_file():put('controller/'+p.relative_to(P/'full-controller').as_posix(),p.read_bytes())
for n in ('tools/compiler_records.py','tools/reader.py','tools/archive.py'):
    put(n,(Q/n).read_bytes())
for n,source in [('original.so.gz','reference/original.so.gz'),('prior-inventory.json.gz','reference/prior-inventory.json.gz'),('parent.so.gz','builds/build-01/symbols.so.gz'),('parent.map.gz','builds/build-01/link/link.map.gz'),('source-inputs.json','source-inputs.json')]:
    put('reference/'+n,(Q/source).read_bytes())
for c in ('curve_accounts','spl_token_2022_interface'):
    launch=json.loads((P/(c+'-baseline/launch.json')).read_bytes());a=launch['reference_record']['after'];folder=Path(a[a.index('--out-dir')+1]);name=next((P/(c+'-baseline')).glob('*.rlib')).name
    gz('reference/'+c+'.rlib',(folder/name).read_bytes())
direct=[]
for folder in P.iterdir():
    if not folder.is_dir()or not(folder/'launch.json').exists()or folder.name.startswith('full-'):continue
    direct.append(folder.name)
    for p in folder.iterdir():
        if p.is_file()and p.suffix in('.json','.log','.rlib','.rmeta','.ll','.rs'):
            gz('direct/'+folder.name+'/'+p.name,p.read_bytes())
save('direct-builds.json',sorted(direct))
for label in ('full-zeroed-01','full-zeroed-02'):
    folder=P/label
    for p in folder.iterdir():
        if p.is_file()and p.suffix in('.json','.log','.so'):
            gz('builds/'+label+'/'+p.name,p.read_bytes())
    for p in(folder/'link').iterdir():
        if p.is_file():gz('builds/'+label+'/link/'+p.name,p.read_bytes())
    records=[json.loads(p.read_bytes())for p in sorted((folder/'wrapper-records').glob('*.json'))]
    gz('builds/'+label+'/records.json',(json.dumps(records,indent=2)+'\n').encode())
    arc=next((folder/'target/sbpf-solana-solana/release/deps').glob('libcurve_accounts-*.rlib'))
    gz('builds/'+label+'/curve_accounts.rlib',arc.read_bytes())
    invocation=json.loads((folder/'link/invocation.json').read_bytes());inputs=[]
    for r in invocation['inputs']:
        p=folder/'link'/r['retained']if r['retained']else Path(r['path']);data=p.read_bytes()
        inputs.append(dict(**r,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    gz('builds/'+label+'/link-input-identities.json',(json.dumps(inputs,indent=2)+'\n').encode())
for n in ('inspection.json','source-controls.json','object-comparison.json','section-comparison.json','full-measurement.json','callee-trace-comparison.json'):
    gz('exploration/'+n,(P/n).read_bytes())
for p in W.glob('*specialization*.py'):
    gz('exploration/'+p.name,p.read_bytes())
save('provenance.json',dict(parent_revision='c268a71bce3047f8b700673fec9f5d86af13c516',source_revision='21bf0cf41ffed3c753630235969b6f183efabf35',upstream_reviewed='ff6cb0b9f4b7f82f1fb57abad232dd2035eb7e56',direct_compilations=len(direct),target_executions=0,failures=['Initial curve replay used the workspace manifest environment instead of curve-accounts: eight executable sections changed. Original outputs retained under curve_accounts-baseline and curve_accounts-llvm-ir; corrected controls reproduce the reference object.','The parent map verifier correctly rejected the new text extent: 664400 instead of 664384. New analysis checks that explicit extent.','IR-emitting objects differ in symbol/data section naming, so complete-object equality is asserted for diagnostic trace builds and ordinary controls, not IR-emitting builds.']))
print('direct',len(direct),'files',sum(p.is_file()for p in D.rglob('*')),'bytes',sum(p.stat().st_size for p in D.rglob('*')if p.is_file()))
