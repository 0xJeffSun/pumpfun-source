from pathlib import Path
import hashlib,json,subprocess,shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-specialization-provenance'
prior=json.loads((P/'curve_accounts-corrected/launch.json').read_bytes())
for mode,extra in [('source-control',''),('source-zeroed','\npub fn allocation_context_probe(length: usize) -> Vec<u8> { vec![0; length] }\n'),('source-nonzero','\npub fn allocation_context_probe(length: usize) -> Vec<u8> { vec![1; length] }\n')]:
    out=P/mode;out.mkdir(exist_ok=False)
    shutil.copytree(Path(prior['cwd']),out/'source')
    source=out/'source/curve-accounts/src/lib.rs';source.write_bytes(source.read_bytes()+extra.encode())
    (out/'patch.rs').write_text(extra)
    args=list(prior['command']);args[args.index('--out-dir')+1]=str(out)
    env=dict(prior['environment'],CARGO_MANIFEST_DIR=str(out/'source/curve-accounts'),CARGO_MANIFEST_PATH=str(out/'source/curve-accounts/Cargo.toml'))
    launch=dict(command=args,cwd=str(out/'source'),environment=env,source_files={p.relative_to(out/'source').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(out/'source').rglob('*')if p.is_file()},target_executions=0)
    (out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
    with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
        r=subprocess.run(args,cwd=launch['cwd'],env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    identity=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (out/'result.json').write_text(json.dumps(dict(returncode=r.returncode,outputs={p.name:identity(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta')}),indent=2)+'\n')
    print(mode,r.returncode,flush=True);r.check_returncode()
