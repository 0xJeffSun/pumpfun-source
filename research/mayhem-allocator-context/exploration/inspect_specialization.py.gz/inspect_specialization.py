from pathlib import Path
import gzip
import importlib.util
import json
import subprocess

W=Path(__file__).resolve().parent
R=W/'pumpfun-source'
P=W/'mayhem-specialization-provenance'
P.mkdir(exist_ok=True)
base=R/'research/mayhem-native-qualified-identity'
s=importlib.util.spec_from_file_location('qualified',base/'verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
for name,path in [('original',base/'reference/original.so.gz'),('candidate',base/'builds/build-01/symbols.so.gz')]:
    (P/(name+'.so')).write_bytes(gzip.decompress(path.read_bytes()))
o,c=v.layer.Elf(P/'original.so'),v.layer.Elf(P/'candidate.so')
rows=v.read(base/'reference/prior-inventory.json.gz')['original_rows']
originals={r['id']:o.window(r['start'],r['end'])for r in rows}
cw=v.v.functions(c)
maprows=v.map_sections(v.raw(base/'builds/build-01/link/link.map.gz'))
mapbyaddr={r[0]:dict(bytes=r[1],owner=r[2],section=r[3])for r in maprows}
out={}
for key in ['O0209','O0210','O0232','O0237','O0246']:
    w=originals[key]
    matched=[dict(**z,**mapbyaddr[z['start']])for z in cw.values()if v.v.shape(w)==v.v.shape(z)]
    out[key]=dict(original=w,candidates=matched)
out['finish_grow']=[dict(**w,**mapbyaddr[a])for(a,b),w in cw.items()if 'finish_grow' in mapbyaddr[a]['section']]
(P/'inspection.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8',newline='\n')
for key,value in out.items():
    items=value if isinstance(value,list)else value['candidates']
    print(key,json.dumps([dict(start=w['start'],bytes=w['end']-w['start'],owner=w['owner'],section=w['section'],calls=[x['target']for x in w['direct']])for w in items]))
objdump=W/'mayhem-native-build/sdk/llvm/bin/llvm-objdump.exe'
for name,elf,items in [('original',o,[originals['O0209'],originals['O0210'],originals['O0237']]),('candidate',c,out['finish_grow']+[x for x in out['O0210']['candidates']])]:
    for w in items:
        command=[str(objdump),'--disassemble','--no-show-raw-insn','--start-address='+str(w['start']),'--stop-address='+str(w['end']),str(P/(name+'.so'))]
        result=subprocess.run(command,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
        (P/(name+'-'+str(w['start'])+'.asm')).write_bytes(result.stdout)
        (P/(name+'-'+str(w['start'])+'.stderr.log')).write_bytes(result.stderr)
        result.check_returncode()
