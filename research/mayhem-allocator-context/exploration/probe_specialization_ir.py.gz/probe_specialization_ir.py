from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tomllib

W=Path(__file__).resolve().parent
P=W/'mayhem-specialization-provenance'
OLD=W/'mayhem-qualified-native/build-01'
records=[json.loads(p.read_bytes())for p in(OLD/'wrapper-records').glob('*.json')]
launch=json.loads((OLD/'launch.json').read_bytes())
baseenv={k:os.environ[k]for k in ('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE')if k in os.environ}
baseenv.update(launch['environment_overrides'])
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
def identity(path):
    data=path.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
for name in sys.argv[1:]:
    matches=[r for r in records if '--crate-name'in r['after']and r['after'][r['after'].index('--crate-name')+1]==name and '--target'in r['after']]
    assert len(matches)==1,name
    r=matches[0]
    cwd=Path(r['cwd'])
    package=tomllib.loads((cwd/'Cargo.toml').read_text())['package']
    for mode in ('baseline','llvm-ir'):
        output=P/(name+'-'+mode);output.mkdir(exist_ok=False)
        env=dict(baseenv,CARGO_MANIFEST_DIR=str(cwd),CARGO_MANIFEST_PATH=str(cwd/'Cargo.toml'),
                 CARGO_PKG_NAME=package['name'],CARGO_PKG_VERSION=package['version'],CARGO_CRATE_NAME=name)
        args=list(r['after']);args[args.index('--out-dir')+1]=str(output)
        emit=next(i for i,a in enumerate(args)if a.startswith('--emit='))
        if mode=='llvm-ir':args[emit]+=',llvm-ir'
        command=[r['compiler'],*args]
        save(output/'launch.json',dict(command=command,cwd=str(cwd),environment=env,reference_record=r,
              compiler=identity(Path(r['compiler'])),target_executions=0))
        with(output/'stdout.log').open('wb')as out,(output/'stderr.log').open('wb')as err:
            result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(output/'result.json',dict(returncode=result.returncode,target_executions=0,outputs={p.name:identity(p)for p in output.iterdir()if p.is_file()and p.suffix in('.rlib','.rmeta','.ll','.o')}))
        print(name,mode,'exit',result.returncode,flush=True)
        if result.returncode:raise SystemExit(result.returncode)
