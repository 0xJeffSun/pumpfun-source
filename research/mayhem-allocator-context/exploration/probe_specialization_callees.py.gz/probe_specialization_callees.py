from pathlib import Path
import hashlib,json,re,subprocess
P=Path(__file__).resolve().parent/'mayhem-specialization-provenance'
for crate in ('curve_accounts','spl_token_2022_interface'):
    prior=json.loads((P/(crate+'-trace/launch.json')).read_bytes())
    before=json.loads((P/(crate+'-pass-dumps.json')).read_bytes())[26]['ir']
    names=re.findall(r'@"?(_ZN[^" (]+)',before)
    out=P/(crate+'-callees');out.mkdir(exist_ok=False)
    args=prior['command'];args[args.index('--out-dir')+1]=str(out)
    i=next(i for i,x in enumerate(args)if x.startswith('-Cllvm-args=-filter-print-funcs='));args[i]='-Cllvm-args=-filter-print-funcs='+','.join(names)
    (out/'launch.json').write_text(json.dumps(prior,indent=2)+'\n')
    with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
        r=subprocess.run(args,cwd=prior['cwd'],env=prior['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    ident=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (out/'result.json').write_text(json.dumps(dict(returncode=r.returncode,outputs={p.name:ident(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta')}),indent=2)+'\n')
    print(crate,r.returncode,'logbytes',(out/'stderr.log').stat().st_size,flush=True);r.check_returncode()
