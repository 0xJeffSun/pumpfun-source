from pathlib import Path
import hashlib,json,subprocess,tomllib
W=Path(__file__).resolve().parent
P=W/'mayhem-specialization-provenance'
def ident(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for name in ('curve_accounts','spl_token_2022_interface'):
    prior=json.loads((P/(name+'-baseline')/'launch.json').read_bytes())
    cwd=Path(prior['cwd']);r=prior['reference_record'];args=r['after']
    source=next(x for x in args if x.endswith('.rs'));sourcepath=(cwd/source).resolve()
    manifest=sourcepath.parent
    while not(manifest/'Cargo.toml').is_file():manifest=manifest.parent
    package=tomllib.loads((manifest/'Cargo.toml').read_text())['package']
    env=dict(prior['environment'],CARGO_MANIFEST_DIR=str(manifest),CARGO_MANIFEST_PATH=str(manifest/'Cargo.toml'),CARGO_PKG_NAME=package['name'],CARGO_PKG_VERSION=package['version'])
    for part,value in zip(('MAJOR','MINOR','PATCH'),package['version'].split('.')):env['CARGO_PKG_VERSION_'+part]=value
    env['CARGO_PKG_VERSION_PRE']=''
    for mode in ('corrected','corrected-ir','trace'):
        out=P/(name+'-'+mode);out.mkdir(exist_ok=False)
        a=list(args);a[a.index('--out-dir')+1]=str(out)
        if mode=='corrected-ir':
            i=next(i for i,x in enumerate(a)if x.startswith('--emit='));a[i]+=',llvm-ir'
        if mode=='trace':
            symbol={'curve_accounts':'_ZN5alloc7raw_vec11finish_grow17h3c4322077d308122E','spl_token_2022_interface':'_ZN5alloc7raw_vec11finish_grow17h17edbe0f41563d73E'}[name]
            a+=['-Cllvm-args=-filter-print-funcs='+symbol,'-Cllvm-args=-print-after-all']
        launch=dict(command=[r['compiler'],*a],cwd=str(cwd),environment=env,compiler=ident(Path(r['compiler'])),source=ident(sourcepath),manifest=ident(manifest/'Cargo.toml'),target_executions=0)
        (out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
        with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
            result=subprocess.run(launch['command'],cwd=cwd,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'result.json').write_text(json.dumps(dict(returncode=result.returncode,outputs={p.name:ident(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta','.ll','.o')}),indent=2)+'\n')
        print(name,mode,result.returncode,flush=True)
        if result.returncode:raise SystemExit(result.returncode)
