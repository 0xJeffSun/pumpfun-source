from pathlib import Path
import json,hashlib,subprocess,runpy
W=Path(__file__).resolve().parent;P=W/'mayhem-specialization-provenance'
helpers=runpy.run_path(str(W/'analyze_specialization.py'));sections=helpers['sections'];ar=helpers['ar']
ref=(P/'curve_accounts-reference.o').read_bytes();rs=sections(ref);result={}
for mode in ('source-control','source-zeroed','source-nonzero'):
    archive=next((P/mode).glob('*.rlib'));objects={n:b for n,b in ar(archive.read_bytes()).items()if n.endswith('.o')};assert len(objects)==1
    name,b=next(iter(objects.items()));ss=sections(b);objectpath=P/mode/'object.o';objectpath.write_bytes(b)
    changed=[n for n in rs if n not in ss or rs[n]['data']!=ss[n]['data']]
    row=dict(object_equal=b==ref,changed_text=[n for n in changed if rs[n]['flags']&4],new_text=[n for n in ss if n not in rs and ss[n]['flags']&4],finish=[dict(section=n,bytes=s['size'],sha256=hashlib.sha256(s['data']).hexdigest())for n,s in ss.items()if n.startswith('.text')and 'finish_grow'in n])
    r=subprocess.run([str(W/'mayhem-native-build/sdk/llvm/bin/llvm-objdump.exe'),'--disassemble','--reloc','--no-show-raw-insn','--section='+row['finish'][0]['section'],str(objectpath)],capture_output=True);r.check_returncode();(P/mode/'finish.asm').write_bytes(r.stdout)
    result[mode]=row;print(mode,json.dumps(row))
(P/'source-controls.json').write_text(json.dumps(result,indent=2)+'\n')
