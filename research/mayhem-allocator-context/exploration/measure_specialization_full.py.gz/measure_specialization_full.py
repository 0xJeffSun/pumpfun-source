from pathlib import Path
import gzip,importlib.util,json,re
W=Path(__file__).resolve().parent;P=W/'mayhem-specialization-provenance';R=W/'pumpfun-source/research/mayhem-native-qualified-identity'
s=importlib.util.spec_from_file_location('q',R/'verify.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
original=q.layer.Elf(P/'original.so');ref=q.layer.Elf(P/'candidate.so')
def mapping(data):
    # Extract with the parent's parser grammar, while checking this new extent.
    code=__import__('inspect').getsource(q.map_sections).replace('def map_sections(', 'def adapted(').replace('==664384','==664400')
    env=dict(q.__dict__);exec(code,env);return env['adapted'](data)
rows=q.read(R/'reference/prior-inventory.json.gz')['original_rows'];ow={r['id']:original.window(r['start'],r['end'])for r in rows}
def inventory(e):
    cw=q.v.functions(e);matches={k:[a for(a,b),c in cw.items()if q.v.shape(w)==q.v.shape(c)]for k,w in ow.items()}
    raw={k:[a for(a,b),c in cw.items()if original.b[w['start']:w['end']]==e.b[a:b]]for k,w in ow.items()}
    taken={}
    def assign(key,seen):
        for a in matches[key]:
            if a in seen:continue
            seen.add(a)
            if a not in taken or assign(taken[a],seen):taken[a]=key;return True
        return False
    for key in matches:assign(key,set())
    return dict(normalized=sum(bool(a)for a in matches.values()),raw=sum(bool(a)for a in raw.values()),injective=len(taken),candidates=len(cw),matches=matches)
out={'reference':inventory(ref),'builds':{}}
for label in ('full-zeroed-01','full-zeroed-02'):
    path=P/label/'symbols.so';e=q.layer.Elf(path);mapped=mapping((P/label/'link/link.map').read_bytes());fw=q.v.functions(e)
    result=inventory(e);result['raw_elf']=q.identity(path.read_bytes())
    result['stripped']=q.identity((P/label/'candidate-v154-strip.so').read_bytes())
    result['probe_linked']=any('allocation_context_probe'in r[3]for r in mapped)
    result['finish_grow']=[dict(start=a,size=n,owner=owner,section=section,direct=fw[(a,a+n)]['direct'])for a,n,owner,section in mapped if 'finish_grow'in section]
    result['reserve_edges']=[dict(start=a,direct=fw[next(k for k in fw if k[0]==a)]['direct'])for a in result['matches']['O0210']]
    before=q.map_sections(q.raw(R/'builds/build-01/link/link.map.gz'))
    assert [(a[2],a[3])for a in before]==[(a[2],a[3])for a in mapped]
    result['changed_shapes']=[a[3]for a,b in zip(before,mapped)if q.v.shape(ref.window(a[0],a[0]+a[1]))!=q.v.shape(e.window(b[0],b[0]+b[1]))]
    out['builds'][label]=result
    print(label,{k:result[k]for k in ('normalized','raw','injective','candidates','probe_linked','changed_shapes','raw_elf')})
    print('pairs',{k:result['matches'][k]for k in ('O0209','O0210','O0237')})
(P/'full-measurement.json').write_text(json.dumps(out,indent=2)+'\n')
