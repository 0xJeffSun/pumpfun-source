"""Independent finite saved-record validation, no VM invocation."""
from pathlib import Path
import base64,hashlib,json,struct,sys
from solders.transaction import Transaction
W=Path(__file__).resolve().parent;name=sys.argv[1]if len(sys.argv)>1 else'diagnostic.json'
j=json.loads((W/name).read_text());R=W/'runtime-root';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in j['frozen_inputs'].items():assert sha(R/p)==h
assert j['pairs']==4 and j['signed_records']==8 and j['frozen_unchanged']
rows=[];signed=0
for row in j['cases']:
 c=row['case'];diff=[k for k in ['error','accounts','events','inner','return_data']if row['original'][k]!=row['candidate'][k]];assert diff==row['different_fields']
 assert row['original']['error']is None and row['candidate']['error']is None
 for side in ['original','candidate']:
  tx=Transaction.from_bytes(base64.b64decode(row[side]['transaction_base64']));assert all(tx.verify_with_results());signed+=1
  configured='account_mutations'in c;signer=bytes(tx.message.account_keys[0]);hits=sum(a is not None and a['data']is not None and base64.b64decode(a['data'])[451:483]==signer for a in row[side]['before'].values());assert hits==int(configured)
 details={}
 if diff:
  assert diff==['accounts','events','inner']and'account_mutations'in c and c['curve_bytes']==[[81,1]]
  changed=[k for k,v in row['original']['accounts'].items()if v!=row['candidate']['accounts'][k]];assert len(changed)==1
  a,b=[row[s]['accounts'][changed[0]]for s in ['original','candidate']];assert all(a[k]==b[k]for k in ['lamports','owner','executable'])
  x,y=[base64.b64decode(z['data'])for z in [a,b]];assert len(x)==len(y)and x[:16]==y[:16]and x[24:]==y[24:]
  details=dict(original_virtual_quote=struct.unpack_from('<Q',x,16)[0],candidate_virtual_quote=struct.unpack_from('<Q',y,16)[0])
 rows.append(dict(name=c['name'],different_fields=diff,state=details))
paths=[R/'evidence/original/pump/deployed.so',(W/'parent/candidate.so'if(W/'parent/candidate.so').exists()else W.parent/'pump-legacy-whitelist-sync-control/builds/whitelist-sync-v2/candidate.so')]
if (W/'builds/sell-sync/candidate.so').exists():paths.append(W/'builds/sell-sync/candidate.so')
known={sha(p):p for p in paths};header=(R/'evidence/original/pump/programdata-account.bin').read_bytes()[:45]
assert {r['elf_sha256']for r in j['loader_loads']}=={sha(paths[0]),j['candidate_sha256']}
for r in j['loader_loads']:
 b=known[r['elf_sha256']].read_bytes();assert r['elf_prefix_unchanged']and r['zero_allocation_tail']and r['program_sha256']==sha(R/'evidence/original/pump/program-account.bin');assert hashlib.sha256(header+b+bytes(r['programdata_bytes']-45-len(b))).hexdigest()==r['programdata_sha256']
out=dict(candidate=j['candidate_sha256'],pairs=4,signed_records=signed,success=4,differing_pairs=sum(bool(r['different_fields'])for r in rows),loader_images=len(j['loader_loads']),cases=rows,scope=__doc__+' New finite legacy-sell cases only; distinct from PR364 buy coverage. No whole body, full suite, raw logs/CU or callback execution claim.')
(W/(name.removesuffix('.json')+'-checked.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
