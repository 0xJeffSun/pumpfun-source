"""New finite legacy-sell whitelist cases on the exact PR364 artifact only."""
from pathlib import Path
import base64,hashlib,json,sys
from solders.transaction import Transaction
W=Path(__file__).resolve().parent;R=W/'runtime-root';sys.path.insert(0,str(R/'scripts'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p.relative_to(R)):sha(p)for p in R.rglob('*')if p.is_file()and '__pycache__'not in p.parts}
import pump_captured_loader as loader
loader.install()
import pump_legacy_sell_differential as h
assert sha(Path(h.__file__))==json.loads((W/'harness-pin.json').read_text())['sha256']
candidate=W.parent/'pump-legacy-whitelist-sync-control/builds/whitelist-sync-v2/candidate.so'
assert sha(candidate)=='1ea7ec419d11026d6292f42cc5866436dd9bce708a5cacbb00c1e275e1aaec99'
rows=[]
for whitelisted in [False,True]:
 for mode in [False,True]:
  c=dict(name=f'sell-whitelist-{whitelisted}-mayhem-{mode}',amount=500000000,minimum=0,reserved=mode,curve_bytes=[[81,int(mode)]],curve_u64=[[32,100000000]])
  if whitelisted:c['account_mutations']={'global':{'bytes':[[451+i,b]for i,b in enumerate(bytes(h.USER.pubkey()))]}}
  a=h.run(c);b=h.run(c,candidate)
  rows.append(dict(case=c,original=a,candidate=b,different_fields=[k for k in ['error','accounts','events','inner','return_data']if a[k]!=b[k]]))
result=dict(scope=__doc__,candidate_sha256=sha(candidate),pairs=len(rows),signed_records=len(rows)*2,cases=rows,loader_loads=loader.LOADS,frozen_inputs=pins,frozen_unchanged=all(sha(R/n)==v for n,v in pins.items()))
(W/'diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['frozen_unchanged']
for r in rows:
 for side in ['original','candidate']:assert all(Transaction.from_bytes(base64.b64decode(r[side]['transaction_base64'])).verify_with_results())
print(json.dumps([(r['case']['name'],r['original']['error'],r['candidate']['error'],r['different_fields'])for r in rows]))
