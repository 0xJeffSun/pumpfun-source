"""Independent saved source/build/inventory/crypto/loader verification; no compiler/VM fallback."""
from pathlib import Path
import base64,hashlib,importlib.util,json,subprocess,sys
from solders.transaction import Transaction
if not __debug__:raise RuntimeError('Assertions required')
D=Path(__file__).resolve().parent;P=D/'parent';S=D/'runtime-root';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'candidate.so')=='1ea7ec419d11026d6292f42cc5866436dd9bce708a5cacbb00c1e275e1aaec99'
assert sha(P/'unstripped.so')=='a97506acd4af21e13ad7ceba1992c2a40ddc944ca106c5d3ebe47404fefe4e22'
inputs=lambda p:{str(n.relative_to(p)):sha(n)for n in p.rglob('*')if n.is_file()}
old,source=inputs(P/'source'),inputs(D/'source');assert len(old)==len(source)==58 and old.keys()==source.keys()
assert old==json.loads((P/'launch.json').read_text())['workspace_inputs']
assert[n for n in old if old[n]!=source[n]]==['programs/pump/src/sell.rs']
for n in old:assert(P/'source'/n).read_bytes().count(b'\n')==(D/'source'/n).read_bytes().count(b'\n')
for label in ['sell-sync','repeat']:
 r=json.loads((D/'builds'/label/'result.json').read_text());l=json.loads((D/'builds'/label/'launch.json').read_text());assert r['exit_code']==0 and r['root_invocations']==1 and all(r[k]for k in ['primary_unchanged','source_unchanged','sdk_unchanged'])
 assert l['workspace_inputs']==source and l['primary_source_inputs']==inputs(D/'primary')and len(l['sdk_inputs'])==2775
 for kind in ['candidate','unstripped']:
  p=D/'builds'/label/(kind+'.so');assert sha(p)==r[kind+'_sha256']and p.read_bytes()==(D/'builds/sell-sync'/(kind+'.so')).read_bytes()
spec=importlib.util.spec_from_file_location('iv',P/'inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
new=json.loads((D/'inventory.json').read_text());parent=json.loads((P/'inventory.json').read_text());assert m.inventory(D/'builds/sell-sync/unstripped.so')==new and m.inventory(P/'unstripped.so')==parent
matched=lambda j:{r['start']for r in j['windows']if r['candidates']}
raw=lambda j:{r['start']for r in j['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])}
assert matched(new)==matched(parent)and raw(new)==raw(parent)
assert(new['injective_normalized'],new['membership_normalized'],new['injective_raw'])==(755,755,131)
for n in ['runtime-input-pins.json','runtime-data-pins.json']:
 for name,h in json.loads((P/n).read_text())['files'].items():assert sha(S/name)==h
pin=json.loads((D/'harness-pin.json').read_text());assert sha(S/pin['path'])==pin['sha256']
for name,expected in [('diagnostic.json',1),('fixed-diagnostic.json',0)]:
 r=subprocess.run([sys.executable,'-I','-B',str(D/'check_saved.py'),name],capture_output=True,text=True);assert r.returncode==0,r.stderr;j=json.loads(r.stdout);assert j['differing_pairs']==expected and j['signed_records']==8
j=json.loads((D/'runtime-report.json').read_text());assert not j['mismatches']and j['candidate_sha256']==sha(D/'builds/sell-sync/candidate.so');assert j['harness_sha256']==pin['sha256']
success=0;signed=0
for r in j['cases']:
 assert r['match']and not r['different_fields']and all(r['original'][k]==r['candidate'][k]for k in ['error','accounts','events','inner','return_data']);success+=r['original']['error']is None
 for side in ['original','candidate']:assert all(Transaction.from_bytes(base64.b64decode(r[side]['transaction_base64'])).verify_with_results());signed+=1
assert len(j['cases'])==j['case_count']
images={sha(P/'reference/original.so'):P/'reference/original.so',sha(D/'builds/sell-sync/candidate.so'):D/'builds/sell-sync/candidate.so'};loads=json.loads((D/'runtime-loader.json').read_text())['loads'];assert {r['elf_sha256']for r in loads}==set(images)
header=(S/'evidence/original/pump/programdata-account.bin').read_bytes()[:45]
for r in loads:
 b=images[r['elf_sha256']].read_bytes();assert r['elf_prefix_unchanged']and r['zero_allocation_tail']and r['program_sha256']==sha(S/'evidence/original/pump/program-account.bin');assert hashlib.sha256(header+b+bytes(r['programdata_bytes']-45-len(b))).hexdigest()==r['programdata_sha256']
result=dict(normalized=755,membership=new['membership_normalized'],raw=131,gain=[],old_sets_held=True,complete_repeat_equal=True,frozen_sell_pairs=j['case_count'],new_whitelist_pairs=4,signed_records=signed+8,success=success+4,reject=j['case_count']-success,parent_differing_pairs=1,parent_signed_records=8,loader_images=len(loads)+9,scope=__doc__+' New artifact legacy-sell coverage only; PR364 buy receipts are not retagged. No body gain, complete business-body/data/transitive/raw-log/CU/whole identity claimed.')
(D/'qualification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
