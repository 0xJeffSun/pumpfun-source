from pathlib import Path
import importlib.util,json,sys
W=Path(__file__).resolve().parent;R=W.parent/'pumpfun-current';s=importlib.util.spec_from_file_location('w',R/'research/mayhem-native-quote-controls/window_map.py');w=importlib.util.module_from_spec(s);s.loader.exec_module(w);a=(R/'evidence/original/mayhem/deployed.so').read_bytes();aw=w.windows(a);x=next(z for z in aw if z['address']==186552)
def norm(image,win):
 data=bytearray(w.m.at_address(image,win['address'],win['bytes']));rel=dict(w.m.relocations(image))
 for r in w.m.instructions(image,win['address'],win['bytes']):
  off=r['offset'];info=rel.get(win['address']+off,0)
  if 'call_target'in r or info&0xffffffff==10:data[off+4:off+8]=bytes(4)
  elif info&0xffffffff==8:data[off+4:off+8]=data[off+12:off+16]=bytes(4)
 return [bytes(data[i:i+8]) for i in range(0,len(data),8)]
an=norm(a,x)
for label in sys.argv[1:]:
 p=W/(label+'-build');b=(p/'symbols.so').read_bytes();bw=w.windows(b);y=next(z for z in bw if z['name'] and 'state10sell_quote17' in z['name']);bn=norm(b,y);cmp=w.compare(aw,bw);report=dict(label=label,bytes=y['bytes'],same_position_slots=sum(v==u for v,u in zip(an,bn)),complete_match=x['signature']==y['signature'],matched=441-len(cmp['unmatched_original']),original=x,candidate=y,differences=[(i,an[i].hex(),bn[i].hex()) for i in range(min(len(an),len(bn))) if an[i]!=bn[i]])
 (W/(label+'-sell-score.json')).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['original','candidate','differences']});print(report['differences'])
