#[derive(Debug,Clone,Copy)]
#[repr(u32)]
pub enum FeeError {
    UnauthorizedProgram = 0,
    InvalidAdmin = 1,
    NoFeeTiers = 2,
    TooManyFeeTiers = 3,
    OffsetNotContinuous = 4,
    FeeTiersNotSorted = 5,
    InvalidFeeTotal = 6,
    InvalidSharingConfig = 7,
    InvalidPool = 8,
    SharingConfigAdminRevoked = 9,
    NoShareholders = 10,
    TooManyShareholders = 11,
    DuplicateShareholder = 12,
    NotEnoughRemainingAccounts = 13,
    InvalidShareTotal = 14,
    ShareCalculationOverflow = 15,
    NotAuthorized = 16,
    ZeroShareNotAllowed = 17,
    SharingConfigNotActive = 18,
    AmmAccountsRequiredForGraduatedCoin = 19,
    ShareholderAccountMismatch = 20,
    FeatureDeactivated = 21,
    UserIdTooLong = 22,
    DeprecatedInstruction = 23,
    FeeSharesAlreadyUpdated = 24,
    MathOverflow = 25,
    InvalidBuybackIndex = 26,
    ClaimRateLimitExceeded = 27,
    InvalidFeeConfigAccount = 28,
    AccountTypeNotSupported = 29,
    InvalidMint = 30,
    UnsupportedQuoteMint = 31,
    InvalidRemainingAccounts = 32,
    PoolCreatorFeesNotSwept = 33,
    InvalidQuoteMint = 34,
    IncompleteTokenAccounts = 35,
    NothingToWithdraw = 36,
}
extern "Rust" { #[link_name="_ZN19pump_fees_candidate24recovered_fee_error_name17hd3fad0b07befc218E"] fn host_error_name(error: &FeeError)->String; }
impl FeeError { #[inline(always)] pub fn name(&self)->String { unsafe { host_error_name(self) } } }

impl From<FeeError> for u32 { #[inline(always)] fn from(e:FeeError)->u32 { e as u32 + anchor_lang::error::ERROR_CODE_OFFSET }}
extern "Rust" { #[link_name="_ZN19pump_fees_candidate30recovered_fee_error_into_error17h85b7e0d2ff622284E"] fn host_error_into_error(error: FeeError)->anchor_lang::error::Error; }
impl From<FeeError> for anchor_lang::error::Error { #[inline(always)] fn from(error_code:FeeError)->anchor_lang::error::Error { unsafe { host_error_into_error(error_code) } } }

impl std::fmt::Display for FeeError {fn fmt(&self,fmt:&mut std::fmt::Formatter)->std::fmt::Result {match self {Self::UnauthorizedProgram=>write!(fmt, "Only Pump and PumpSwap programs can call this instruction"),Self::InvalidAdmin=>write!(fmt, "Invalid admin"),Self::NoFeeTiers=>write!(fmt, "No fee tiers provided"),Self::TooManyFeeTiers=>write!(fmt, "format"),Self::OffsetNotContinuous=>write!(fmt, "The offset should be <= fee_config.fee_tiers.len()"),Self::FeeTiersNotSorted=>write!(fmt, "Fee tiers must be sorted by market cap threshold (ascending)"),Self::InvalidFeeTotal=>write!(fmt, "Fee total must not exceed 10_000bps"),Self::InvalidSharingConfig=>write!(fmt, "Invalid Sharing Config"),Self::InvalidPool=>write!(fmt, "Invalid Pool"),Self::SharingConfigAdminRevoked=>write!(fmt, "Sharing config authority has been revoked - sharing config can only be updated once"),Self::NoShareholders=>write!(fmt, "No shareholders provided"),Self::TooManyShareholders=>write!(fmt, "format"),Self::DuplicateShareholder=>write!(fmt, "Duplicate shareholder address"),Self::NotEnoughRemainingAccounts=>write!(fmt, "Not enough remaining accounts"),Self::InvalidShareTotal=>write!(fmt, "Invalid share total - must equal 10_000 basis points"),Self::ShareCalculationOverflow=>write!(fmt, "Share calculation overflow"),Self::NotAuthorized=>write!(fmt, "The given account is not authorized to execute this instruction."),Self::ZeroShareNotAllowed=>write!(fmt, "Shareholder cannot have zero share"),Self::SharingConfigNotActive=>write!(fmt, "Fee sharing config is not active"),Self::AmmAccountsRequiredForGraduatedCoin=>write!(fmt, "AMM accounts are required for graduated coins"),Self::ShareholderAccountMismatch=>write!(fmt, "Remaining account key doesn't match shareholder address"),Self::FeatureDeactivated=>write!(fmt, "Feature is currently deactivated"),Self::UserIdTooLong=>write!(fmt, "User ID exceeds maximum length"),Self::DeprecatedInstruction=>write!(fmt, "Instruction is deprecated"),Self::FeeSharesAlreadyUpdated=>write!(fmt, "Reward split can only be updated once"),Self::MathOverflow=>write!(fmt, "Math overflow"),Self::InvalidBuybackIndex=>write!(fmt, "Invalid buybackindex"),Self::ClaimRateLimitExceeded=>write!(fmt, "Claim rate limit exceeded"),Self::InvalidFeeConfigAccount=>write!(fmt, "Account is not a valid FeeConfig for this instruction"),Self::AccountTypeNotSupported=>write!(fmt, "Account type not supported"),Self::InvalidMint=>write!(fmt, "Mint does not match quote mint"),Self::UnsupportedQuoteMint=>write!(fmt, "Unsupported quote mint"),Self::InvalidRemainingAccounts=>write!(fmt, "Invalid remaining accounts"),Self::PoolCreatorFeesNotSwept=>write!(fmt, "Pool creator_fees must be swept before the shares change"),Self::InvalidQuoteMint=>write!(fmt, "quote_mint is not the bonding curve's quote mint"),Self::IncompleteTokenAccounts=>write!(fmt, "Token withdrawals need quote_mint, vault_ata, user_ata and token_program"),Self::NothingToWithdraw=>write!(fmt, "Nothing to withdraw")}}}

pub static CLAIM_RATE_MESSAGE: [u8;25] = *b"Claim rate limit exceeded";
#[inline(always)] pub fn claim_rate_message()->&'static str { unsafe {std::str::from_utf8_unchecked(&CLAIM_RATE_MESSAGE)} }
