#[inline(always)]
pub fn render_pool_error()->String { fees_error_types::FeeError::InvalidPool.to_string() }
