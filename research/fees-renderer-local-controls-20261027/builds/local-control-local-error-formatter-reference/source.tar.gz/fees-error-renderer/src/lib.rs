#[inline(always)]
pub fn render_pool_error(error:&fees_error_types::FeeError)->String {error.to_string()}
