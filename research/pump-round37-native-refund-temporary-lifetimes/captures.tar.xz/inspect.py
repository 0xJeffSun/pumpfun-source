from pathlib import Path
import importlib.util,json,hashlib
W=Path(__file__).resolve().parent
p=W.parent/'pump-sol-vault-account-info-control/captures/analysis/inventory.py';s=importlib.util.spec_from_file_location('iv',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
label=__import__('sys').argv[1];d=W/'builds'/label
r=json.loads((d/'result.json').read_text());assert r['exit_code']==0
j=m.inventory(d/'unstripped.so');old=json.loads((W.parent/'pump-sol-vault-account-info-control/inventory.json').read_text())
matched=lambda x:{r['start']for r in x['windows']if r['candidates']}
rawset=lambda x:{r['start']for r in x['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])}
a=(p.parent/'reference/original.so').read_bytes();b=(d/'unstripped.so').read_bytes();sa,sb=m.sections(a),m.sections(b)
rows=[]
for q in m.functions(b):
 if not any('refund_pool_authority' in n for n in q['symbols']):continue
 orig=353880 if any('10migrate_v2' in n for n in q['symbols']) else 300808
 ar,ao=m.normalize(m.body(a,sa,orig,384),orig,sa);br,bo=m.normalize(m.body(b,sb,q['start'],q['bytes']),q['start'],sb)
 rows.append(dict(original=orig,candidate=q['start'],bytes=q['bytes'],normalized_equal=ar==br,different_slots=sum(ar[i:i+8]!=br[i:i+8]for i in range(0,max(len(ar),len(br)),8)),operands=bo))
result=dict(candidate=r['candidate_sha256'],symbols=r['unstripped_sha256'],membership=j['membership_normalized'],injective=j['injective_normalized'],raw=j['injective_raw'],gains=sorted(matched(j)-matched(old)),losses=sorted(matched(old)-matched(j)),raw_losses=sorted(rawset(old)-rawset(j)),refunds=rows)
(d/'inventory.json').write_text(json.dumps(j,indent=2)+'\n');(d/'inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
