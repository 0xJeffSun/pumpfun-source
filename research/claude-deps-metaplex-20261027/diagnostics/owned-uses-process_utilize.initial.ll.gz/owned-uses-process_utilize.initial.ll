*** IR Dump After Annotation2MetadataPass on [module] ***
; Function Attrs: minsize nounwind optsize
define void @_ZN14token_metadata9processor4uses7utilize15process_utilize17h9789c7990f4c0b83E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias noundef readonly align 1 dereferenceable(32) %1, ptr noalias noundef nonnull readonly align 8 %2, i64 noundef %3, i64 noundef %4) unnamed_addr #1 {
  %6 = alloca %67, align 8
  %7 = alloca %67, align 8
  %8 = alloca { ptr, i64 }, align 8
  %9 = alloca %44, align 8
  %10 = alloca %44, align 8
  %11 = alloca %44, align 8
  %12 = alloca %44, align 8
  %13 = alloca %1196, align 8
  %14 = alloca %89, align 8
  %15 = alloca %795, align 8
  %16 = alloca %67, align 8
  %17 = alloca %67, align 8
  %18 = alloca { ptr, i64 }, align 8
  %19 = alloca %44, align 8
  %20 = alloca %44, align 8
  %21 = alloca %44, align 8
  %22 = alloca %44, align 8
  %23 = alloca %1196, align 8
  %24 = alloca %89, align 8
  %25 = alloca %795, align 8
  %26 = alloca [1 x i8], align 1
  %27 = alloca [4 x { ptr, i64 }], align 8
  %28 = alloca { i8, i8 }, align 1
  %29 = alloca %67, align 8
  %30 = alloca %67, align 8
  %31 = alloca %63, align 8
  %32 = alloca %851, align 8
  %33 = alloca i8, align 1
  %34 = alloca %67, align 8
  %35 = alloca %67, align 8
  %36 = alloca %1199, align 8
  %37 = alloca %867, align 8
  %38 = alloca { ptr, ptr }, align 8
  %39 = alloca ptr, align 8
  %40 = alloca i8, align 1
  %41 = alloca %64, align 8
  %42 = alloca ptr, align 8
  %43 = alloca i8, align 1
  %44 = alloca %535, align 8
  %45 = alloca %1051, align 8
  %46 = alloca %67, align 8
  %47 = alloca %67, align 8
  %48 = alloca %89, align 8
  %49 = alloca %795, align 8
  %50 = alloca %854, align 8
  %51 = alloca %67, align 8
  %52 = alloca %67, align 8
  %53 = alloca %84, align 8
  %54 = alloca %870, align 8
  %55 = alloca %854, align 8
  %56 = alloca %67, align 8
  %57 = alloca %67, align 8
  %58 = alloca %1160, align 8
  %59 = alloca %1001, align 8
  %60 = alloca %67, align 8
  %61 = alloca %67, align 8
  %62 = alloca %89, align 8
  %63 = alloca %795, align 8
  %64 = alloca %67, align 8
  %65 = alloca %67, align 8
  %66 = alloca %89, align 8
  %67 = alloca %795, align 8
  %68 = alloca %67, align 8
  %69 = alloca %67, align 8
  %70 = alloca %1199, align 8
  %71 = alloca %867, align 8
  %72 = alloca { ptr, ptr }, align 8
  %73 = alloca %67, align 8
  %74 = alloca %67, align 8
  %75 = alloca %63, align 8
  %76 = alloca %851, align 8
  %77 = alloca %499, align 8
  %78 = alloca %370, align 8
  %79 = alloca i8, align 1
  %80 = alloca %535, align 8
  %81 = alloca %1051, align 8
  %82 = alloca i8, align 1
  %83 = alloca %64, align 8
  %84 = alloca i8, align 1
  %85 = alloca %370, align 8
  %86 = alloca %499, align 8
  %87 = alloca %372, align 8
  %88 = alloca %67, align 8
  %89 = alloca %67, align 8
  %90 = alloca %137, align 8
  %91 = alloca %768, align 8
  %92 = alloca %372, align 8
  %93 = alloca %67, align 8
  %94 = alloca %67, align 8
  %95 = alloca %89, align 8
  %96 = alloca %795, align 8
  %97 = alloca %67, align 8
  %98 = alloca %67, align 8
  %99 = alloca %89, align 8
  %100 = alloca %795, align 8
  %101 = alloca i8, align 1
  %102 = alloca %64, align 8
  %103 = alloca i8, align 1
  %104 = alloca %64, align 8
  %105 = alloca i8, align 1
  %106 = alloca i8, align 1
  %107 = alloca %64, align 8
  %108 = alloca %372, align 8
  %109 = alloca %67, align 8
  %110 = alloca %67, align 8
  %111 = alloca %137, align 8
  %112 = alloca %768, align 8
  %113 = alloca %372, align 8
  %114 = alloca ptr, align 8
  %115 = alloca i8, align 1
  %116 = alloca %67, align 8
  %117 = alloca %67, align 8
  %118 = alloca %63, align 8
  %119 = alloca %851, align 8
  %120 = alloca %67, align 8
  %121 = alloca %67, align 8
  %122 = alloca %63, align 8
  %123 = alloca %851, align 8
  %124 = alloca %67, align 8
  %125 = alloca %67, align 8
  %126 = alloca %63, align 8
  %127 = alloca %851, align 8
  %128 = alloca %67, align 8
  %129 = alloca %67, align 8
  %130 = alloca %63, align 8
  %131 = alloca %851, align 8
  %132 = alloca %67, align 8
  %133 = alloca %67, align 8
  %134 = alloca %63, align 8
  %135 = alloca %851, align 8
  %136 = alloca %67, align 8
  %137 = alloca %67, align 8
  %138 = alloca %63, align 8
  %139 = alloca %851, align 8
  %140 = alloca %67, align 8
  %141 = alloca %67, align 8
  %142 = alloca %63, align 8
  %143 = alloca %851, align 8
  %144 = alloca %67, align 8
  %145 = alloca %67, align 8
  %146 = alloca %63, align 8
  %147 = alloca %851, align 8
  %148 = alloca %46, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr %148)
  %149 = call { ptr, ptr } @"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$4iter17hc9ef4411aca7a418E"(ptr noalias noundef nonnull readonly align 8 %2, i64 noundef %3) #20
  %150 = extractvalue { ptr, ptr } %149, 0
  %151 = extractvalue { ptr, ptr } %149, 1
  call void @_ZN4core4iter6traits8iterator8Iterator8peekable17h1fbde6f420c6d727E(ptr noalias nocapture noundef sret(%46) dereferenceable(32) %148, ptr noundef %150, ptr noundef nonnull %151) #20
  call void @llvm.lifetime.start.p0(i64 32, ptr %147)
  call void @llvm.lifetime.start.p0(i64 32, ptr %146)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %146, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %147, ptr noalias nocapture noundef dereferenceable(32) %146) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %146)
  %152 = load i32, ptr %147, align 8, !range !12, !noundef !2
  %153 = icmp eq i32 %152, 22
  %154 = select i1 %153, i64 0, i64 1
  switch i64 %154, label %155 [
    i64 0, label %156
    i64 1, label %162
  ]

155:                                              ; preds = %5
  unreachable

156:                                              ; preds = %5
  %157 = getelementptr inbounds %852, ptr %147, i32 0, i32 1
  %158 = load ptr, ptr %157, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %147)
  call void @llvm.lifetime.start.p0(i64 32, ptr %143)
  call void @llvm.lifetime.start.p0(i64 32, ptr %142)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %142, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %143, ptr noalias nocapture noundef dereferenceable(32) %142) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %142)
  %159 = load i32, ptr %143, align 8, !range !12, !noundef !2
  %160 = icmp eq i32 %159, 22
  %161 = select i1 %160, i64 0, i64 1
  switch i64 %161, label %164 [
    i64 0, label %165
    i64 1, label %171
  ]

162:                                              ; preds = %5
  call void @llvm.lifetime.start.p0(i64 32, ptr %145)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %145, ptr align 8 %147, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %144)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %144, ptr align 8 %145, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %144, ptr noalias noundef readonly align 8 dereferenceable(24) @1143) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %144)
  call void @llvm.lifetime.end.p0(i64 32, ptr %145)
  call void @llvm.lifetime.end.p0(i64 32, ptr %147)
  br label %163

163:                                              ; preds = %172, %162
  call void @llvm.lifetime.end.p0(i64 32, ptr %148)
  br label %569

164:                                              ; preds = %156
  unreachable

165:                                              ; preds = %156
  %166 = getelementptr inbounds %852, ptr %143, i32 0, i32 1
  %167 = load ptr, ptr %166, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %143)
  call void @llvm.lifetime.start.p0(i64 32, ptr %139)
  call void @llvm.lifetime.start.p0(i64 32, ptr %138)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %138, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %139, ptr noalias nocapture noundef dereferenceable(32) %138) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %138)
  %168 = load i32, ptr %139, align 8, !range !12, !noundef !2
  %169 = icmp eq i32 %168, 22
  %170 = select i1 %169, i64 0, i64 1
  switch i64 %170, label %173 [
    i64 0, label %174
    i64 1, label %180
  ]

171:                                              ; preds = %156
  call void @llvm.lifetime.start.p0(i64 32, ptr %141)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %143, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %140)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %141, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %140, ptr noalias noundef readonly align 8 dereferenceable(24) @1144) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %140)
  call void @llvm.lifetime.end.p0(i64 32, ptr %141)
  call void @llvm.lifetime.end.p0(i64 32, ptr %143)
  br label %172

172:                                              ; preds = %181, %171
  br label %163

173:                                              ; preds = %165
  unreachable

174:                                              ; preds = %165
  %175 = getelementptr inbounds %852, ptr %139, i32 0, i32 1
  %176 = load ptr, ptr %175, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %139)
  call void @llvm.lifetime.start.p0(i64 32, ptr %135)
  call void @llvm.lifetime.start.p0(i64 32, ptr %134)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %134, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %135, ptr noalias nocapture noundef dereferenceable(32) %134) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %134)
  %177 = load i32, ptr %135, align 8, !range !12, !noundef !2
  %178 = icmp eq i32 %177, 22
  %179 = select i1 %178, i64 0, i64 1
  switch i64 %179, label %182 [
    i64 0, label %183
    i64 1, label %189
  ]

180:                                              ; preds = %165
  call void @llvm.lifetime.start.p0(i64 32, ptr %137)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %139, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %136)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %136, ptr align 8 %137, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %136, ptr noalias noundef readonly align 8 dereferenceable(24) @1145) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %136)
  call void @llvm.lifetime.end.p0(i64 32, ptr %137)
  call void @llvm.lifetime.end.p0(i64 32, ptr %139)
  br label %181

181:                                              ; preds = %190, %180
  br label %172

182:                                              ; preds = %174
  unreachable

183:                                              ; preds = %174
  %184 = getelementptr inbounds %852, ptr %135, i32 0, i32 1
  %185 = load ptr, ptr %184, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %135)
  call void @llvm.lifetime.start.p0(i64 32, ptr %131)
  call void @llvm.lifetime.start.p0(i64 32, ptr %130)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %130, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %131, ptr noalias nocapture noundef dereferenceable(32) %130) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %130)
  %186 = load i32, ptr %131, align 8, !range !12, !noundef !2
  %187 = icmp eq i32 %186, 22
  %188 = select i1 %187, i64 0, i64 1
  switch i64 %188, label %191 [
    i64 0, label %192
    i64 1, label %198
  ]

189:                                              ; preds = %174
  call void @llvm.lifetime.start.p0(i64 32, ptr %133)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %135, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %132)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %133, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %132, ptr noalias noundef readonly align 8 dereferenceable(24) @1146) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %132)
  call void @llvm.lifetime.end.p0(i64 32, ptr %133)
  call void @llvm.lifetime.end.p0(i64 32, ptr %135)
  br label %190

190:                                              ; preds = %199, %189
  br label %181

191:                                              ; preds = %183
  unreachable

192:                                              ; preds = %183
  %193 = getelementptr inbounds %852, ptr %131, i32 0, i32 1
  %194 = load ptr, ptr %193, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %131)
  call void @llvm.lifetime.start.p0(i64 32, ptr %127)
  call void @llvm.lifetime.start.p0(i64 32, ptr %126)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %126, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %127, ptr noalias nocapture noundef dereferenceable(32) %126) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %126)
  %195 = load i32, ptr %127, align 8, !range !12, !noundef !2
  %196 = icmp eq i32 %195, 22
  %197 = select i1 %196, i64 0, i64 1
  switch i64 %197, label %200 [
    i64 0, label %201
    i64 1, label %207
  ]

198:                                              ; preds = %183
  call void @llvm.lifetime.start.p0(i64 32, ptr %129)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %129, ptr align 8 %131, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %128)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %129, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %128, ptr noalias noundef readonly align 8 dereferenceable(24) @1147) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %128)
  call void @llvm.lifetime.end.p0(i64 32, ptr %129)
  call void @llvm.lifetime.end.p0(i64 32, ptr %131)
  br label %199

199:                                              ; preds = %208, %198
  br label %190

200:                                              ; preds = %192
  unreachable

201:                                              ; preds = %192
  %202 = getelementptr inbounds %852, ptr %127, i32 0, i32 1
  %203 = load ptr, ptr %202, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %127)
  call void @llvm.lifetime.start.p0(i64 32, ptr %123)
  call void @llvm.lifetime.start.p0(i64 32, ptr %122)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %122, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %123, ptr noalias nocapture noundef dereferenceable(32) %122) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %122)
  %204 = load i32, ptr %123, align 8, !range !12, !noundef !2
  %205 = icmp eq i32 %204, 22
  %206 = select i1 %205, i64 0, i64 1
  switch i64 %206, label %209 [
    i64 0, label %210
    i64 1, label %214
  ]

207:                                              ; preds = %192
  call void @llvm.lifetime.start.p0(i64 32, ptr %125)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %125, ptr align 8 %127, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %124)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %125, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %124, ptr noalias noundef readonly align 8 dereferenceable(24) @1148) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %124)
  call void @llvm.lifetime.end.p0(i64 32, ptr %125)
  call void @llvm.lifetime.end.p0(i64 32, ptr %127)
  br label %208

208:                                              ; preds = %215, %207
  br label %199

209:                                              ; preds = %201
  unreachable

210:                                              ; preds = %201
  call void @llvm.lifetime.end.p0(i64 32, ptr %123)
  call void @llvm.lifetime.start.p0(i64 32, ptr %119)
  call void @llvm.lifetime.start.p0(i64 32, ptr %118)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %118, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %119, ptr noalias nocapture noundef dereferenceable(32) %118) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %118)
  %211 = load i32, ptr %119, align 8, !range !12, !noundef !2
  %212 = icmp eq i32 %211, 22
  %213 = select i1 %212, i64 0, i64 1
  switch i64 %213, label %216 [
    i64 0, label %217
    i64 1, label %220
  ]

214:                                              ; preds = %201
  call void @llvm.lifetime.start.p0(i64 32, ptr %121)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %121, ptr align 8 %123, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %120)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %120, ptr align 8 %121, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %120, ptr noalias noundef readonly align 8 dereferenceable(24) @1149) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %120)
  call void @llvm.lifetime.end.p0(i64 32, ptr %121)
  call void @llvm.lifetime.end.p0(i64 32, ptr %123)
  br label %215

215:                                              ; preds = %221, %214
  br label %208

216:                                              ; preds = %210
  unreachable

217:                                              ; preds = %210
  call void @llvm.lifetime.end.p0(i64 32, ptr %119)
  call void @llvm.lifetime.start.p0(i64 1, ptr %115)
  call void @llvm.lifetime.start.p0(i64 8, ptr %114)
  %218 = call noundef align 8 dereferenceable_or_null(48) ptr @"_ZN4core4iter8adapters8peekable17Peekable$LT$I$GT$7next_if17h8be795c6e429a654E"(ptr noalias noundef align 8 dereferenceable(32) %148) #20
  store ptr %218, ptr %114, align 8
  %219 = call noundef zeroext i1 @"_ZN4core6option15Option$LT$T$GT$7is_some17h10059c7a91b7b969E"(ptr noalias noundef readonly align 8 dereferenceable(8) %114) #20
  call void @llvm.lifetime.end.p0(i64 8, ptr %114)
  br i1 %219, label %225, label %222

220:                                              ; preds = %210
  call void @llvm.lifetime.start.p0(i64 32, ptr %117)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %119, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %116)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %116, ptr align 8 %117, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %116, ptr noalias noundef readonly align 8 dereferenceable(24) @1150) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %116)
  call void @llvm.lifetime.end.p0(i64 32, ptr %117)
  call void @llvm.lifetime.end.p0(i64 32, ptr %119)
  br label %221

221:                                              ; preds = %238, %220
  br label %215

222:                                              ; preds = %217
  %223 = icmp eq i64 %3, 10
  %224 = zext i1 %223 to i8
  store i8 %224, ptr %115, align 1
  br label %228

225:                                              ; preds = %217
  %226 = icmp eq i64 %3, 11
  %227 = zext i1 %226 to i8
  store i8 %227, ptr %115, align 1
  br label %228

228:                                              ; preds = %222, %225
  call void @llvm.lifetime.start.p0(i64 304, ptr %113)
  call void @llvm.lifetime.start.p0(i64 304, ptr %112)
  call void @llvm.lifetime.start.p0(i64 304, ptr %111)
  call void @_ZN14token_metadata5state20TokenMetadataAccount17from_account_info17hcfef9f224c5b6ff6E(ptr noalias nocapture noundef sret(%137) dereferenceable(304) %111, ptr noalias noundef readonly align 8 dereferenceable(48) %158) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h1ade9d6e6b4ad0ceE"(ptr noalias nocapture noundef sret(%768) dereferenceable(304) %112, ptr noalias nocapture noundef dereferenceable(304) %111) #20
  call void @llvm.lifetime.end.p0(i64 304, ptr %111)
  %229 = getelementptr inbounds %768, ptr %112, i32 0, i32 1
  %230 = load i32, ptr %229, align 8, !range !32, !noundef !2
  %231 = icmp eq i32 %230, 2
  %232 = select i1 %231, i64 1, i64 0
  switch i64 %232, label %233 [
    i64 0, label %234
    i64 1, label %237
  ]

233:                                              ; preds = %228
  unreachable

234:                                              ; preds = %228
  call void @llvm.lifetime.start.p0(i64 304, ptr %108)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %112, i64 304, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %113, ptr align 8 %108, i64 304, i1 false)
  call void @llvm.lifetime.end.p0(i64 304, ptr %108)
  call void @llvm.lifetime.end.p0(i64 304, ptr %112)
  %235 = getelementptr inbounds %372, ptr %113, i32 0, i32 11
  %236 = call noundef zeroext i1 @"_ZN4core6option15Option$LT$T$GT$7is_none17hf222829b32cd4369E"(ptr noalias noundef readonly align 8 dereferenceable(24) %235) #20
  br i1 %236, label %245, label %239

237:                                              ; preds = %228
  call void @llvm.lifetime.start.p0(i64 32, ptr %110)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %110, ptr align 8 %112, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %109)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %109, ptr align 8 %110, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %109, ptr noalias noundef readonly align 8 dereferenceable(24) @1151) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %109)
  call void @llvm.lifetime.end.p0(i64 32, ptr %110)
  call void @llvm.lifetime.end.p0(i64 304, ptr %112)
  br label %238

238:                                              ; preds = %247, %237
  call void @llvm.lifetime.end.p0(i64 304, ptr %113)
  call void @llvm.lifetime.end.p0(i64 1, ptr %115)
  br label %221

239:                                              ; preds = %234
  call void @llvm.lifetime.start.p0(i64 1, ptr %105)
  %240 = getelementptr inbounds %372, ptr %113, i32 0, i32 8
  %241 = load i32, ptr %240, align 4, !range !28, !noundef !2
  %242 = icmp eq i32 %241, 6
  %243 = select i1 %242, i64 0, i64 1
  %244 = icmp eq i64 %243, 1
  br i1 %244, label %248, label %252

245:                                              ; preds = %234
  call void @llvm.lifetime.start.p0(i64 32, ptr %107)
  call void @llvm.lifetime.start.p0(i64 1, ptr %106)
  store i8 85, ptr %106, align 1
  %246 = load i8, ptr %106, align 1, !range !11, !noundef !2
  call void @"_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17h9e10898212785e2dE"(ptr noalias nocapture noundef sret(%64) dereferenceable(32) %107, i8 noundef %246) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %106)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %107, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr %107)
  br label %247

247:                                              ; preds = %288, %281, %274, %267, %261, %245
  call void @"_ZN4core3ptr62drop_in_place$LT$token_metadata..state..metadata..Metadata$GT$17h8848245800f3afa5E"(ptr noundef %113) #20
  br label %238

248:                                              ; preds = %239
  %249 = getelementptr inbounds %372, ptr %113, i32 0, i32 8
  %250 = load i32, ptr %249, align 4, !range !29, !noundef !2
  %251 = zext i32 %250 to i64
  switch i64 %251, label %252 [
    i64 0, label %253
    i64 3, label %253
    i64 4, label %253
    i64 5, label %253
  ]

252:                                              ; preds = %248, %239
  store i8 0, ptr %105, align 1
  br label %254

253:                                              ; preds = %248, %248, %248, %248
  store i8 1, ptr %105, align 1
  br label %254

254:                                              ; preds = %253, %252
  %255 = load i8, ptr %105, align 1, !range !9, !noundef !2
  %256 = trunc i8 %255 to i1
  %257 = xor i1 %256, true
  call void @llvm.lifetime.end.p0(i64 1, ptr %105)
  br i1 %257, label %261, label %258

258:                                              ; preds = %254
  %259 = load ptr, ptr %203, align 8, !nonnull !2, !align !4, !noundef !2
  %260 = call noundef zeroext i1 @_ZN4core3cmp9PartialEq2ne17h0d0d6ae917ee2100E(ptr noalias noundef readonly align 1 dereferenceable(32) %259, ptr noalias noundef readonly align 1 dereferenceable(32) @265) #20
  br i1 %260, label %267, label %263

261:                                              ; preds = %254
  call void @llvm.lifetime.start.p0(i64 32, ptr %104)
  call void @llvm.lifetime.start.p0(i64 1, ptr %103)
  store i8 -121, ptr %103, align 1
  %262 = load i8, ptr %103, align 1, !range !11, !noundef !2
  call void @"_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17h9e10898212785e2dE"(ptr noalias nocapture noundef sret(%64) dereferenceable(32) %104, i8 noundef %262) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %103)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %104, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr %104)
  br label %247

263:                                              ; preds = %258
  call void @llvm.lifetime.start.p0(i64 32, ptr %100)
  call void @llvm.lifetime.start.p0(i64 32, ptr %99)
  call void @_ZN9mpl_utils10assertions13assert_signer17hc5021f06096037b1E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %99, ptr noalias noundef readonly align 8 dereferenceable(48) %185) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %100, ptr noalias nocapture noundef dereferenceable(32) %99) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %99)
  %264 = load i32, ptr %100, align 8, !range !12, !noundef !2
  %265 = icmp eq i32 %264, 22
  %266 = select i1 %265, i64 0, i64 1
  switch i64 %266, label %269 [
    i64 0, label %270
    i64 1, label %274
  ]

267:                                              ; preds = %258
  call void @llvm.lifetime.start.p0(i64 32, ptr %102)
  call void @llvm.lifetime.start.p0(i64 1, ptr %101)
  store i8 62, ptr %101, align 1
  %268 = load i8, ptr %101, align 1, !range !11, !noundef !2
  call void @"_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17h9e10898212785e2dE"(ptr noalias nocapture noundef sret(%64) dereferenceable(32) %102, i8 noundef %268) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %101)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %102, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr %102)
  br label %247

269:                                              ; preds = %263
  unreachable

270:                                              ; preds = %263
  call void @llvm.lifetime.end.p0(i64 32, ptr %100)
  call void @llvm.lifetime.start.p0(i64 32, ptr %96)
  call void @llvm.lifetime.start.p0(i64 32, ptr %95)
  call void @_ZN14token_metadata10assertions8metadata24assert_currently_holding17h9773fdd27308f043E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %95, ptr noalias noundef readonly align 1 dereferenceable(32) %1, ptr noalias noundef readonly align 8 dereferenceable(48) %194, ptr noalias noundef readonly align 8 dereferenceable(48) %158, ptr noalias noundef readonly align 8 dereferenceable(304) %113, ptr noalias noundef readonly align 8 dereferenceable(48) %176, ptr noalias noundef readonly align 8 dereferenceable(48) %167) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %96, ptr noalias nocapture noundef dereferenceable(32) %95) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %95)
  %271 = load i32, ptr %96, align 8, !range !12, !noundef !2
  %272 = icmp eq i32 %271, 22
  %273 = select i1 %272, i64 0, i64 1
  switch i64 %273, label %275 [
    i64 0, label %276
    i64 1, label %281
  ]

274:                                              ; preds = %263
  call void @llvm.lifetime.start.p0(i64 32, ptr %98)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %100, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %97)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %98, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %97, ptr noalias noundef readonly align 8 dereferenceable(24) @1152) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %97)
  call void @llvm.lifetime.end.p0(i64 32, ptr %98)
  call void @llvm.lifetime.end.p0(i64 32, ptr %100)
  br label %247

275:                                              ; preds = %270
  unreachable

276:                                              ; preds = %270
  call void @llvm.lifetime.end.p0(i64 32, ptr %96)
  call void @llvm.lifetime.start.p0(i64 304, ptr %92)
  call void @llvm.lifetime.start.p0(i64 304, ptr %91)
  call void @llvm.lifetime.start.p0(i64 304, ptr %90)
  call void @_ZN14token_metadata5state20TokenMetadataAccount17from_account_info17hcfef9f224c5b6ff6E(ptr noalias nocapture noundef sret(%137) dereferenceable(304) %90, ptr noalias noundef readonly align 8 dereferenceable(48) %158) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h1ade9d6e6b4ad0ceE"(ptr noalias nocapture noundef sret(%768) dereferenceable(304) %91, ptr noalias nocapture noundef dereferenceable(304) %90) #20
  call void @llvm.lifetime.end.p0(i64 304, ptr %90)
  %277 = getelementptr inbounds %768, ptr %91, i32 0, i32 1
  %278 = load i32, ptr %277, align 8, !range !32, !noundef !2
  %279 = icmp eq i32 %278, 2
  %280 = select i1 %279, i64 1, i64 0
  switch i64 %280, label %282 [
    i64 0, label %283
    i64 1, label %287
  ]

281:                                              ; preds = %270
  call void @llvm.lifetime.start.p0(i64 32, ptr %94)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %96, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %93)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %94, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %93, ptr noalias noundef readonly align 8 dereferenceable(24) @1153) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %93)
  call void @llvm.lifetime.end.p0(i64 32, ptr %94)
  call void @llvm.lifetime.end.p0(i64 32, ptr %96)
  br label %247

282:                                              ; preds = %276
  unreachable

283:                                              ; preds = %276
  call void @llvm.lifetime.start.p0(i64 304, ptr %87)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %91, i64 304, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %87, i64 304, i1 false)
  call void @llvm.lifetime.end.p0(i64 304, ptr %87)
  call void @llvm.lifetime.end.p0(i64 304, ptr %91)
  call void @llvm.lifetime.start.p0(i64 24, ptr %86)
  call void @llvm.lifetime.start.p0(i64 24, ptr %85)
  %284 = getelementptr inbounds %372, ptr %92, i32 0, i32 11
  call void @"_ZN68_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h4d8ccf9a2d363941E"(ptr noalias nocapture noundef sret(%370) dereferenceable(24) %85, ptr noalias noundef readonly align 8 dereferenceable(24) %284) #20
  call void @"_ZN4core6option15Option$LT$T$GT$6unwrap17h43982a0059e73655E"(ptr noalias nocapture noundef sret(%499) dereferenceable(24) %86, ptr noalias nocapture noundef dereferenceable(24) %85, ptr noalias noundef readonly align 8 dereferenceable(24) @1155) #20
  call void @llvm.lifetime.end.p0(i64 24, ptr %85)
  %285 = call noundef zeroext i1 @"_ZN79_$LT$token_metadata..state..uses..UseMethod$u20$as$u20$core..cmp..PartialEq$GT$2eq17habbf24101f576131E"(ptr noalias noundef readonly align 4 dereferenceable(4) %86, ptr noalias noundef readonly align 4 dereferenceable(4) @220) #20
  call void @llvm.lifetime.start.p0(i64 1, ptr %84)
  %286 = icmp eq i64 %4, 0
  br i1 %286, label %289, label %290

287:                                              ; preds = %276
  call void @llvm.lifetime.start.p0(i64 32, ptr %89)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %91, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %88)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %88, ptr align 8 %89, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %88, ptr noalias noundef readonly align 8 dereferenceable(24) @1154) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %88)
  call void @llvm.lifetime.end.p0(i64 32, ptr %89)
  call void @llvm.lifetime.end.p0(i64 304, ptr %91)
  br label %288

288:                                              ; preds = %310, %287
  call void @llvm.lifetime.end.p0(i64 304, ptr %92)
  br label %247

289:                                              ; preds = %283
  store i8 1, ptr %84, align 1
  br label %295

290:                                              ; preds = %283
  %291 = getelementptr inbounds %499, ptr %86, i32 0, i32 3
  %292 = load i64, ptr %291, align 8, !noundef !2
  %293 = icmp ugt i64 %4, %292
  %294 = zext i1 %293 to i8
  store i8 %294, ptr %84, align 1
  br label %295

295:                                              ; preds = %289, %290
  %296 = load i8, ptr %84, align 1, !range !9, !noundef !2
  %297 = trunc i8 %296 to i1
  br i1 %297, label %308, label %298

298:                                              ; preds = %295
  call void @llvm.lifetime.end.p0(i64 1, ptr %84)
  call void @llvm.lifetime.start.p0(i64 16, ptr %81)
  call void @llvm.lifetime.start.p0(i64 16, ptr %80)
  %299 = getelementptr inbounds %499, ptr %86, i32 0, i32 2
  %300 = load i64, ptr %299, align 8, !noundef !2
  %301 = call { i64, i64 } @"_ZN4core3num21_$LT$impl$u20$u64$GT$11checked_sub17hc10230cee7723e3eE"(i64 noundef %300, i64 noundef %4) #20
  %302 = extractvalue { i64, i64 } %301, 0
  %303 = extractvalue { i64, i64 } %301, 1
  call void @llvm.lifetime.start.p0(i64 1, ptr %79)
  store i8 86, ptr %79, align 1
  %304 = load i8, ptr %79, align 1, !range !11, !noundef !2
  call void @"_ZN4core6option15Option$LT$T$GT$5ok_or17he3864607c060f194E"(ptr noalias nocapture noundef sret(%535) dereferenceable(16) %80, i64 noundef %302, i64 %303, i8 noundef %304) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %79)
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17haf388c60a5037cb8E"(ptr noalias nocapture noundef sret(%1051) dereferenceable(16) %81, ptr noalias nocapture noundef dereferenceable(16) %80) #20
  call void @llvm.lifetime.end.p0(i64 16, ptr %80)
  %305 = load i8, ptr %81, align 8, !range !9, !noundef !2
  %306 = trunc i8 %305 to i1
  %307 = zext i1 %306 to i64
  switch i64 %307, label %311 [
    i64 0, label %312
    i64 1, label %323
  ]

308:                                              ; preds = %295
  call void @llvm.lifetime.start.p0(i64 32, ptr %83)
  call void @llvm.lifetime.start.p0(i64 1, ptr %82)
  store i8 86, ptr %82, align 1
  %309 = load i8, ptr %82, align 1, !range !11, !noundef !2
  call void @"_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17h9e10898212785e2dE"(ptr noalias nocapture noundef sret(%64) dereferenceable(32) %83, i8 noundef %309) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %82)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %83, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr %83)
  call void @llvm.lifetime.end.p0(i64 1, ptr %84)
  br label %310

310:                                              ; preds = %326, %308
  call void @llvm.lifetime.end.p0(i64 24, ptr %86)
  call void @"_ZN4core3ptr62drop_in_place$LT$token_metadata..state..metadata..Metadata$GT$17h8848245800f3afa5E"(ptr noundef %92) #20
  br label %288

311:                                              ; preds = %298
  unreachable

312:                                              ; preds = %298
  %313 = getelementptr inbounds %1052, ptr %81, i32 0, i32 1
  %314 = load i64, ptr %313, align 8, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr %81)
  call void @llvm.lifetime.start.p0(i64 24, ptr %78)
  call void @llvm.lifetime.start.p0(i64 24, ptr %77)
  %315 = load i32, ptr %86, align 8, !range !32, !noundef !2
  %316 = getelementptr inbounds %499, ptr %86, i32 0, i32 3
  %317 = load i64, ptr %316, align 8, !noundef !2
  store i32 %315, ptr %77, align 8
  %318 = getelementptr inbounds %499, ptr %77, i32 0, i32 2
  store i64 %314, ptr %318, align 8
  %319 = getelementptr inbounds %499, ptr %77, i32 0, i32 3
  store i64 %317, ptr %319, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %77, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 24, ptr %77)
  %320 = getelementptr inbounds %372, ptr %92, i32 0, i32 11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %320, ptr align 8 %78, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 24, ptr %78)
  %321 = load i8, ptr %115, align 1, !range !9, !noundef !2
  %322 = trunc i8 %321 to i1
  br i1 %322, label %329, label %327

323:                                              ; preds = %298
  %324 = getelementptr inbounds %1053, ptr %81, i32 0, i32 1
  %325 = load i8, ptr %324, align 1, !range !11, !noundef !2
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h2831557941d89e32E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, i8 noundef %325, ptr noalias noundef readonly align 8 dereferenceable(24) @1156) #20
  call void @llvm.lifetime.end.p0(i64 16, ptr %81)
  br label %326

326:                                              ; preds = %564, %465, %436, %323
  br label %310

327:                                              ; preds = %312
  %328 = call noundef zeroext i1 @"_ZN4core3cmp5impls69_$LT$impl$u20$core..cmp..PartialEq$LT$$RF$B$GT$$u20$for$u20$$RF$A$GT$2ne17h034b8f2a183c21c2E"(ptr noalias noundef readonly align 8 dereferenceable(8) %185, ptr noalias noundef readonly align 8 dereferenceable(8) %194) #20
  br i1 %328, label %442, label %441

329:                                              ; preds = %312
  call void @llvm.lifetime.start.p0(i64 32, ptr %76)
  call void @llvm.lifetime.start.p0(i64 32, ptr %75)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %75, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %76, ptr noalias nocapture noundef dereferenceable(32) %75) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %75)
  %330 = load i32, ptr %76, align 8, !range !12, !noundef !2
  %331 = icmp eq i32 %330, 22
  %332 = select i1 %331, i64 0, i64 1
  switch i64 %332, label %333 [
    i64 0, label %334
    i64 1, label %340
  ]

333:                                              ; preds = %329
  unreachable

334:                                              ; preds = %329
  %335 = getelementptr inbounds %852, ptr %76, i32 0, i32 1
  %336 = load ptr, ptr %335, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %76)
  call void @llvm.lifetime.start.p0(i64 16, ptr %72)
  call void @llvm.lifetime.start.p0(i64 32, ptr %71)
  call void @llvm.lifetime.start.p0(i64 32, ptr %70)
  call void @_ZN14solana_program12account_info11AccountInfo19try_borrow_mut_data17hcf238957d2f67b88E(ptr noalias nocapture noundef sret(%1199) dereferenceable(32) %70, ptr noalias noundef readonly align 8 dereferenceable(48) %336) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h56808349007f2d72E"(ptr noalias nocapture noundef sret(%867) dereferenceable(32) %71, ptr noalias nocapture noundef dereferenceable(32) %70) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %70)
  %337 = load i32, ptr %71, align 8, !range !12, !noundef !2
  %338 = icmp eq i32 %337, 22
  %339 = select i1 %338, i64 0, i64 1
  switch i64 %339, label %342 [
    i64 0, label %343
    i64 1, label %359
  ]

340:                                              ; preds = %329
  call void @llvm.lifetime.start.p0(i64 32, ptr %74)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %74, ptr align 8 %76, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %73)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %74, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %73, ptr noalias noundef readonly align 8 dereferenceable(24) @1157) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %73)
  call void @llvm.lifetime.end.p0(i64 32, ptr %74)
  call void @llvm.lifetime.end.p0(i64 32, ptr %76)
  br label %341

341:                                              ; preds = %360, %340
  br label %436

342:                                              ; preds = %334
  unreachable

343:                                              ; preds = %334
  %344 = getelementptr inbounds %869, ptr %71, i32 0, i32 1
  %345 = getelementptr inbounds { ptr, ptr }, ptr %344, i32 0, i32 0
  %346 = load ptr, ptr %345, align 8, !nonnull !2, !noundef !2
  %347 = getelementptr inbounds { ptr, ptr }, ptr %344, i32 0, i32 1
  %348 = load ptr, ptr %347, align 8, !nonnull !2, !align !5, !noundef !2
  %349 = getelementptr inbounds { ptr, ptr }, ptr %72, i32 0, i32 0
  store ptr %346, ptr %349, align 8
  %350 = getelementptr inbounds { ptr, ptr }, ptr %72, i32 0, i32 1
  store ptr %348, ptr %350, align 8
  %351 = call noundef align 8 dereferenceable(16) ptr @"_ZN74_$LT$core..cell..RefMut$LT$T$GT$$u20$as$u20$core..ops..deref..DerefMut$GT$9deref_mut17he70b4964f8115a65E"(ptr noalias noundef align 8 dereferenceable(16) %72) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %71)
  call void @llvm.lifetime.start.p0(i64 32, ptr %67)
  call void @llvm.lifetime.start.p0(i64 32, ptr %66)
  %352 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 0
  %353 = load ptr, ptr %352, align 8, !nonnull !2, !align !4, !noundef !2
  %354 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 1
  %355 = load i64, ptr %354, align 8, !noundef !2
  call void @_ZN14token_metadata10assertions4uses32process_use_authority_validation17hd1179a3685fd4eebE(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %66, i64 noundef %355, i1 noundef zeroext false) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %67, ptr noalias nocapture noundef dereferenceable(32) %66) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %66)
  %356 = load i32, ptr %67, align 8, !range !12, !noundef !2
  %357 = icmp eq i32 %356, 22
  %358 = select i1 %357, i64 0, i64 1
  switch i64 %358, label %361 [
    i64 0, label %362
    i64 1, label %366
  ]

359:                                              ; preds = %334
  call void @llvm.lifetime.start.p0(i64 32, ptr %69)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %69, ptr align 8 %71, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %68)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %68, ptr align 8 %69, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %68, ptr noalias noundef readonly align 8 dereferenceable(24) @1158) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %68)
  call void @llvm.lifetime.end.p0(i64 32, ptr %69)
  call void @llvm.lifetime.end.p0(i64 32, ptr %71)
  br label %360

360:                                              ; preds = %367, %359
  call void @llvm.lifetime.end.p0(i64 16, ptr %72)
  br label %341

361:                                              ; preds = %343
  unreachable

362:                                              ; preds = %343
  call void @llvm.lifetime.end.p0(i64 32, ptr %67)
  call void @llvm.lifetime.start.p0(i64 32, ptr %63)
  call void @llvm.lifetime.start.p0(i64 32, ptr %62)
  call void @_ZN14token_metadata10assertions4misc15assert_owned_by17h280f82a67421a794E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %62, ptr noalias noundef readonly align 8 dereferenceable(48) %336, ptr noalias noundef readonly align 1 dereferenceable(32) %1) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %63, ptr noalias nocapture noundef dereferenceable(32) %62) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %62)
  %363 = load i32, ptr %63, align 8, !range !12, !noundef !2
  %364 = icmp eq i32 %363, 22
  %365 = select i1 %364, i64 0, i64 1
  switch i64 %365, label %368 [
    i64 0, label %369
    i64 1, label %373
  ]

366:                                              ; preds = %343
  call void @llvm.lifetime.start.p0(i64 32, ptr %65)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %67, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %64)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %65, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %64, ptr noalias noundef readonly align 8 dereferenceable(24) @1159) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %64)
  call void @llvm.lifetime.end.p0(i64 32, ptr %65)
  call void @llvm.lifetime.end.p0(i64 32, ptr %67)
  br label %367

367:                                              ; preds = %386, %373, %366
  call void @"_ZN4core3ptr71drop_in_place$LT$core..cell..RefMut$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$GT$17h25100c6545d6e811E"(ptr noundef %72) #20
  br label %360

368:                                              ; preds = %362
  unreachable

369:                                              ; preds = %362
  call void @llvm.lifetime.end.p0(i64 32, ptr %63)
  call void @llvm.lifetime.start.p0(i64 32, ptr %59)
  call void @llvm.lifetime.start.p0(i64 32, ptr %58)
  call void @_ZN14token_metadata10assertions4uses31assert_use_authority_derivation17h9f9a4e6bb881fba5E(ptr noalias nocapture noundef sret(%1160) dereferenceable(32) %58, ptr noalias noundef readonly align 1 dereferenceable(32) %1, ptr noalias noundef readonly align 8 dereferenceable(48) %336, ptr noalias noundef readonly align 8 dereferenceable(48) %185, ptr noalias noundef readonly align 8 dereferenceable(48) %176) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h936dcb87cec0d7a5E"(ptr noalias nocapture noundef sret(%1001) dereferenceable(32) %59, ptr noalias nocapture noundef dereferenceable(32) %58) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %58)
  %370 = load i32, ptr %59, align 8, !range !12, !noundef !2
  %371 = icmp eq i32 %370, 22
  %372 = select i1 %371, i64 0, i64 1
  switch i64 %372, label %374 [
    i64 0, label %375
    i64 1, label %385
  ]

373:                                              ; preds = %362
  call void @llvm.lifetime.start.p0(i64 32, ptr %61)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %63, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %60)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %61, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %60, ptr noalias noundef readonly align 8 dereferenceable(24) @1160) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %60)
  call void @llvm.lifetime.end.p0(i64 32, ptr %61)
  call void @llvm.lifetime.end.p0(i64 32, ptr %63)
  br label %367

374:                                              ; preds = %369
  unreachable

375:                                              ; preds = %369
  %376 = getelementptr inbounds %1002, ptr %59, i32 0, i32 1
  %377 = load i8, ptr %376, align 4, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %59)
  call void @llvm.lifetime.start.p0(i64 24, ptr %55)
  call void @llvm.lifetime.start.p0(i64 32, ptr %54)
  call void @llvm.lifetime.start.p0(i64 32, ptr %53)
  %378 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 0
  %379 = load ptr, ptr %378, align 8, !nonnull !2, !align !4, !noundef !2
  %380 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 1
  %381 = load i64, ptr %380, align 8, !noundef !2
  call void @_ZN14token_metadata5state4uses18UseAuthorityRecord10from_bytes17h225c712c2b66acceE(ptr noalias nocapture noundef sret(%84) dereferenceable(32) %53, ptr noalias noundef nonnull readonly align 1 %379, i64 noundef %381) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h5bc41cc1c5bbc05eE"(ptr noalias nocapture noundef sret(%870) dereferenceable(32) %54, ptr noalias nocapture noundef dereferenceable(32) %53) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %53)
  %382 = load i32, ptr %54, align 8, !range !12, !noundef !2
  %383 = icmp eq i32 %382, 22
  %384 = select i1 %383, i64 0, i64 1
  switch i64 %384, label %387 [
    i64 0, label %388
    i64 1, label %391
  ]

385:                                              ; preds = %369
  call void @llvm.lifetime.start.p0(i64 32, ptr %57)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %59, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %56)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %57, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %56, ptr noalias noundef readonly align 8 dereferenceable(24) @1161) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %56)
  call void @llvm.lifetime.end.p0(i64 32, ptr %57)
  call void @llvm.lifetime.end.p0(i64 32, ptr %59)
  br label %386

386:                                              ; preds = %392, %385
  br label %367

387:                                              ; preds = %375
  unreachable

388:                                              ; preds = %375
  call void @llvm.lifetime.start.p0(i64 24, ptr %50)
  %389 = getelementptr inbounds %872, ptr %54, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %389, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %50, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 24, ptr %50)
  call void @llvm.lifetime.end.p0(i64 32, ptr %54)
  %390 = call noundef zeroext i1 @_ZN14token_metadata5state4uses18UseAuthorityRecord10bump_empty17hdc6f66347aded34aE(ptr noalias noundef readonly align 8 dereferenceable(24) %55) #20
  br i1 %390, label %397, label %393

391:                                              ; preds = %375
  call void @llvm.lifetime.start.p0(i64 32, ptr %52)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %54, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %51)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %52, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %51, ptr noalias noundef readonly align 8 dereferenceable(24) @1162) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %51)
  call void @llvm.lifetime.end.p0(i64 32, ptr %52)
  call void @llvm.lifetime.end.p0(i64 32, ptr %54)
  br label %392

392:                                              ; preds = %434, %429, %410, %391
  call void @llvm.lifetime.end.p0(i64 24, ptr %55)
  br label %386

393:                                              ; preds = %397, %388
  call void @llvm.lifetime.start.p0(i64 32, ptr %49)
  call void @llvm.lifetime.start.p0(i64 32, ptr %48)
  call void @_ZN14token_metadata10assertions4uses17assert_valid_bump17hca80a9cfff66ad94E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %48, i8 noundef %377, ptr noalias noundef readonly align 8 dereferenceable(24) %55) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %49, ptr noalias nocapture noundef dereferenceable(32) %48) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %48)
  %394 = load i32, ptr %49, align 8, !range !12, !noundef !2
  %395 = icmp eq i32 %394, 22
  %396 = select i1 %395, i64 0, i64 1
  switch i64 %396, label %399 [
    i64 0, label %400
    i64 1, label %410
  ]

397:                                              ; preds = %388
  %398 = getelementptr inbounds %854, ptr %55, i32 0, i32 3
  store i8 %377, ptr %398, align 8
  br label %393

399:                                              ; preds = %393
  unreachable

400:                                              ; preds = %393
  call void @llvm.lifetime.end.p0(i64 32, ptr %49)
  call void @llvm.lifetime.start.p0(i64 16, ptr %45)
  call void @llvm.lifetime.start.p0(i64 16, ptr %44)
  %401 = getelementptr inbounds %854, ptr %55, i32 0, i32 2
  %402 = load i64, ptr %401, align 8, !noundef !2
  %403 = call { i64, i64 } @"_ZN4core3num21_$LT$impl$u20$u64$GT$11checked_sub17hc10230cee7723e3eE"(i64 noundef %402, i64 noundef %4) #20
  %404 = extractvalue { i64, i64 } %403, 0
  %405 = extractvalue { i64, i64 } %403, 1
  call void @llvm.lifetime.start.p0(i64 1, ptr %43)
  store i8 86, ptr %43, align 1
  %406 = load i8, ptr %43, align 1, !range !11, !noundef !2
  call void @"_ZN4core6option15Option$LT$T$GT$5ok_or17he3864607c060f194E"(ptr noalias nocapture noundef sret(%535) dereferenceable(16) %44, i64 noundef %404, i64 %405, i8 noundef %406) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %43)
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17haf388c60a5037cb8E"(ptr noalias nocapture noundef sret(%1051) dereferenceable(16) %45, ptr noalias nocapture noundef dereferenceable(16) %44) #20
  call void @llvm.lifetime.end.p0(i64 16, ptr %44)
  %407 = load i8, ptr %45, align 8, !range !9, !noundef !2
  %408 = trunc i8 %407 to i1
  %409 = zext i1 %408 to i64
  switch i64 %409, label %411 [
    i64 0, label %412
    i64 1, label %429
  ]

410:                                              ; preds = %393
  call void @llvm.lifetime.start.p0(i64 32, ptr %47)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %49, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %46)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %46, ptr align 8 %47, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %46, ptr noalias noundef readonly align 8 dereferenceable(24) @1163) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %46)
  call void @llvm.lifetime.end.p0(i64 32, ptr %47)
  call void @llvm.lifetime.end.p0(i64 32, ptr %49)
  br label %392

411:                                              ; preds = %400
  unreachable

412:                                              ; preds = %400
  %413 = getelementptr inbounds %1052, ptr %45, i32 0, i32 1
  %414 = load i64, ptr %413, align 8, !noundef !2
  %415 = getelementptr inbounds %854, ptr %55, i32 0, i32 2
  store i64 %414, ptr %415, align 8
  call void @llvm.lifetime.end.p0(i64 16, ptr %45)
  call void @llvm.lifetime.start.p0(i64 8, ptr %42)
  %416 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 0
  %417 = load ptr, ptr %416, align 8, !nonnull !2, !align !4, !noundef !2
  %418 = getelementptr inbounds { ptr, i64 }, ptr %351, i32 0, i32 1
  %419 = load i64, ptr %418, align 8, !noundef !2
  %420 = call { ptr, i64 } @"_ZN4core5slice5index77_$LT$impl$u20$core..ops..index..IndexMut$LT$I$GT$$u20$for$u20$$u5b$T$u5d$$GT$9index_mut17h6e98d4f10ba37405E"(ptr noalias noundef nonnull align 1 %417, i64 noundef %419, ptr noalias noundef readonly align 8 dereferenceable(24) @1165) #20
  %421 = extractvalue { ptr, i64 } %420, 0
  %422 = extractvalue { ptr, i64 } %420, 1
  %423 = call noundef ptr @_ZN5borsh3ser7helpers9to_writer17hfa629f22abad9120E(ptr noalias noundef nonnull align 1 %421, i64 noundef %422, ptr noalias noundef readonly align 8 dereferenceable(24) %55) #20
  %424 = call noundef ptr @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17hb7d26cbfc643638cE"(ptr noundef %423) #20
  store ptr %424, ptr %42, align 8
  %425 = load ptr, ptr %42, align 8, !noundef !2
  %426 = ptrtoint ptr %425 to i64
  %427 = icmp eq i64 %426, 0
  %428 = select i1 %427, i64 0, i64 1
  switch i64 %428, label %432 [
    i64 0, label %433
    i64 1, label %434
  ]

429:                                              ; preds = %400
  %430 = getelementptr inbounds %1053, ptr %45, i32 0, i32 1
  %431 = load i8, ptr %430, align 1, !range !11, !noundef !2
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h2831557941d89e32E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, i8 noundef %431, ptr noalias noundef readonly align 8 dereferenceable(24) @1164) #20
  call void @llvm.lifetime.end.p0(i64 16, ptr %45)
  br label %392

432:                                              ; preds = %412
  unreachable

433:                                              ; preds = %412
  call void @llvm.lifetime.end.p0(i64 8, ptr %42)
  call void @llvm.lifetime.end.p0(i64 24, ptr %55)
  call void @"_ZN4core3ptr71drop_in_place$LT$core..cell..RefMut$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$GT$17h25100c6545d6e811E"(ptr noundef %72) #20
  call void @llvm.lifetime.end.p0(i64 16, ptr %72)
  br label %437

434:                                              ; preds = %412
  %435 = load ptr, ptr %42, align 8, !nonnull !2, !noundef !2
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h72ab80bd5dac5d86E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noundef nonnull %435, ptr noalias noundef readonly align 8 dereferenceable(24) @1166) #20
  call void @llvm.lifetime.end.p0(i64 8, ptr %42)
  br label %392

436:                                              ; preds = %442, %341
  br label %326

437:                                              ; preds = %441, %433
  call void @llvm.lifetime.start.p0(i64 8, ptr %39)
  call void @llvm.lifetime.start.p0(i64 16, ptr %38)
  call void @llvm.lifetime.start.p0(i64 32, ptr %37)
  call void @llvm.lifetime.start.p0(i64 32, ptr %36)
  call void @_ZN14solana_program12account_info11AccountInfo19try_borrow_mut_data17hcf238957d2f67b88E(ptr noalias nocapture noundef sret(%1199) dereferenceable(32) %36, ptr noalias noundef readonly align 8 dereferenceable(48) %158) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h56808349007f2d72E"(ptr noalias nocapture noundef sret(%867) dereferenceable(32) %37, ptr noalias nocapture noundef dereferenceable(32) %36) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %36)
  %438 = load i32, ptr %37, align 8, !range !12, !noundef !2
  %439 = icmp eq i32 %438, 22
  %440 = select i1 %439, i64 0, i64 1
  switch i64 %440, label %444 [
    i64 0, label %445
    i64 1, label %464
  ]

441:                                              ; preds = %327
  br label %437

442:                                              ; preds = %327
  call void @llvm.lifetime.start.p0(i64 32, ptr %41)
  call void @llvm.lifetime.start.p0(i64 1, ptr %40)
  store i8 98, ptr %40, align 1
  %443 = load i8, ptr %40, align 1, !range !11, !noundef !2
  call void @"_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17h9e10898212785e2dE"(ptr noalias nocapture noundef sret(%64) dereferenceable(32) %41, i8 noundef %443) #20
  call void @llvm.lifetime.end.p0(i64 1, ptr %40)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %41, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr %41)
  br label %436

444:                                              ; preds = %437
  unreachable

445:                                              ; preds = %437
  %446 = getelementptr inbounds %869, ptr %37, i32 0, i32 1
  %447 = getelementptr inbounds { ptr, ptr }, ptr %446, i32 0, i32 0
  %448 = load ptr, ptr %447, align 8, !nonnull !2, !noundef !2
  %449 = getelementptr inbounds { ptr, ptr }, ptr %446, i32 0, i32 1
  %450 = load ptr, ptr %449, align 8, !nonnull !2, !align !5, !noundef !2
  %451 = getelementptr inbounds { ptr, ptr }, ptr %38, i32 0, i32 0
  store ptr %448, ptr %451, align 8
  %452 = getelementptr inbounds { ptr, ptr }, ptr %38, i32 0, i32 1
  store ptr %450, ptr %452, align 8
  %453 = call noundef align 8 dereferenceable(16) ptr @"_ZN74_$LT$core..cell..RefMut$LT$T$GT$$u20$as$u20$core..ops..deref..DerefMut$GT$9deref_mut17he70b4964f8115a65E"(ptr noalias noundef align 8 dereferenceable(16) %38) #20
  %454 = getelementptr inbounds { ptr, i64 }, ptr %453, i32 0, i32 0
  %455 = load ptr, ptr %454, align 8, !nonnull !2, !align !4, !noundef !2
  %456 = getelementptr inbounds { ptr, i64 }, ptr %453, i32 0, i32 1
  %457 = load i64, ptr %456, align 8, !noundef !2
  %458 = call noundef ptr @_ZN14token_metadata5state8metadata8Metadata4save17h9a6561ae9bd1b989E(ptr noalias noundef readonly align 8 dereferenceable(304) %92, ptr noalias noundef nonnull align 1 %455, i64 noundef %457) #20
  %459 = call noundef ptr @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17hb7d26cbfc643638cE"(ptr noundef %458) #20
  store ptr %459, ptr %39, align 8
  %460 = load ptr, ptr %39, align 8, !noundef !2
  %461 = ptrtoint ptr %460 to i64
  %462 = icmp eq i64 %461, 0
  %463 = select i1 %462, i64 0, i64 1
  switch i64 %463, label %466 [
    i64 0, label %467
    i64 1, label %469
  ]

464:                                              ; preds = %437
  call void @llvm.lifetime.start.p0(i64 32, ptr %35)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %37, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %34)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %35, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %34, ptr noalias noundef readonly align 8 dereferenceable(24) @1167) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %34)
  call void @llvm.lifetime.end.p0(i64 32, ptr %35)
  br label %465

465:                                              ; preds = %469, %464
  call void @llvm.lifetime.end.p0(i64 32, ptr %37)
  call void @llvm.lifetime.end.p0(i64 16, ptr %38)
  call void @llvm.lifetime.end.p0(i64 8, ptr %39)
  br label %326

466:                                              ; preds = %445
  unreachable

467:                                              ; preds = %445
  call void @"_ZN4core3ptr71drop_in_place$LT$core..cell..RefMut$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$GT$17h25100c6545d6e811E"(ptr noundef %38) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %37)
  call void @llvm.lifetime.end.p0(i64 16, ptr %38)
  call void @llvm.lifetime.end.p0(i64 8, ptr %39)
  call void @llvm.lifetime.start.p0(i64 1, ptr %33)
  %468 = icmp eq i64 %314, 0
  br i1 %468, label %471, label %473

469:                                              ; preds = %445
  %470 = load ptr, ptr %39, align 8, !nonnull !2, !noundef !2
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h72ab80bd5dac5d86E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noundef nonnull %470, ptr noalias noundef readonly align 8 dereferenceable(24) @1168) #20
  call void @"_ZN4core3ptr71drop_in_place$LT$core..cell..RefMut$LT$$RF$mut$u20$$u5b$u8$u5d$$GT$$GT$17h25100c6545d6e811E"(ptr noundef %38) #20
  br label %465

471:                                              ; preds = %467
  %472 = zext i1 %285 to i8
  store i8 %472, ptr %33, align 1
  br label %474

473:                                              ; preds = %467
  store i8 0, ptr %33, align 1
  br label %474

474:                                              ; preds = %471, %473
  %475 = load i8, ptr %33, align 1, !range !9, !noundef !2
  %476 = trunc i8 %475 to i1
  br i1 %476, label %478, label %477

477:                                              ; preds = %565, %474
  call void @llvm.lifetime.end.p0(i64 1, ptr %33)
  store i32 22, ptr %0, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr %86)
  call void @"_ZN4core3ptr62drop_in_place$LT$token_metadata..state..metadata..Metadata$GT$17h8848245800f3afa5E"(ptr noundef %92) #20
  call void @llvm.lifetime.end.p0(i64 304, ptr %92)
  call void @"_ZN4core3ptr62drop_in_place$LT$token_metadata..state..metadata..Metadata$GT$17h8848245800f3afa5E"(ptr noundef %113) #20
  call void @llvm.lifetime.end.p0(i64 304, ptr %113)
  call void @llvm.lifetime.end.p0(i64 1, ptr %115)
  call void @llvm.lifetime.end.p0(i64 32, ptr %148)
  br label %569

478:                                              ; preds = %474
  %479 = load i8, ptr %115, align 1, !range !9, !noundef !2
  %480 = trunc i8 %479 to i1
  br i1 %480, label %496, label %481

481:                                              ; preds = %478
  call void @llvm.lifetime.start.p0(i64 32, ptr %15)
  call void @llvm.lifetime.start.p0(i64 32, ptr %14)
  call void @llvm.lifetime.start.p0(i64 216, ptr %13)
  call void @llvm.lifetime.start.p0(i64 48, ptr %12)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %12, ptr noalias noundef readonly align 8 dereferenceable(48) %176) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %11)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %11, ptr noalias noundef readonly align 8 dereferenceable(48) %194) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %10)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %10, ptr noalias noundef readonly align 8 dereferenceable(48) %203) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %9)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %9, ptr noalias noundef readonly align 8 dereferenceable(48) %167) #20
  call void @llvm.lifetime.start.p0(i64 16, ptr %8)
  store ptr null, ptr %8, align 8
  %482 = getelementptr inbounds %1196, ptr %13, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %482, ptr align 8 %12, i64 48, i1 false)
  %483 = getelementptr inbounds %1196, ptr %13, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %483, ptr align 8 %9, i64 48, i1 false)
  %484 = getelementptr inbounds %1196, ptr %13, i32 0, i32 5
  store i64 1, ptr %484, align 8
  %485 = getelementptr inbounds %1196, ptr %13, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %485, ptr align 8 %11, i64 48, i1 false)
  %486 = getelementptr inbounds { ptr, i64 }, ptr %8, i32 0, i32 0
  %487 = load ptr, ptr %486, align 8, !align !5, !noundef !2
  %488 = getelementptr inbounds { ptr, i64 }, ptr %8, i32 0, i32 1
  %489 = load i64, ptr %488, align 8
  %490 = getelementptr inbounds { ptr, i64 }, ptr %13, i32 0, i32 0
  store ptr %487, ptr %490, align 8
  %491 = getelementptr inbounds { ptr, i64 }, ptr %13, i32 0, i32 1
  store i64 %489, ptr %491, align 8
  %492 = getelementptr inbounds %1196, ptr %13, i32 0, i32 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %492, ptr align 8 %10, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(i64 16, ptr %8)
  call void @llvm.lifetime.end.p0(i64 48, ptr %9)
  call void @llvm.lifetime.end.p0(i64 48, ptr %10)
  call void @llvm.lifetime.end.p0(i64 48, ptr %11)
  call void @llvm.lifetime.end.p0(i64 48, ptr %12)
  call void @_ZN9mpl_utils5token3cpi14spl_token_burn17h4104af3a4b0840c1E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %14, ptr noalias nocapture noundef readonly dereferenceable(216) %13) #20
  call void @llvm.lifetime.end.p0(i64 216, ptr %13)
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %15, ptr noalias nocapture noundef dereferenceable(32) %14) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %14)
  %493 = load i32, ptr %15, align 8, !range !12, !noundef !2
  %494 = icmp eq i32 %493, 22
  %495 = select i1 %494, i64 0, i64 1
  switch i64 %495, label %566 [
    i64 0, label %567
    i64 1, label %568
  ]

496:                                              ; preds = %478
  call void @llvm.lifetime.start.p0(i64 32, ptr %32)
  call void @llvm.lifetime.start.p0(i64 32, ptr %31)
  call void @_ZN14solana_program12account_info17next_account_info17h843076ed74682877E(ptr noalias nocapture noundef sret(%63) dereferenceable(32) %31, ptr noalias noundef align 8 dereferenceable(32) %148) #20
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h516994cf4c8af86cE"(ptr noalias nocapture noundef sret(%851) dereferenceable(32) %32, ptr noalias nocapture noundef dereferenceable(32) %31) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %31)
  %497 = load i32, ptr %32, align 8, !range !12, !noundef !2
  %498 = icmp eq i32 %497, 22
  %499 = select i1 %498, i64 0, i64 1
  switch i64 %499, label %500 [
    i64 0, label %501
    i64 1, label %513
  ]

500:                                              ; preds = %496
  unreachable

501:                                              ; preds = %496
  %502 = getelementptr inbounds %852, ptr %32, i32 0, i32 1
  %503 = load ptr, ptr %502, align 8, !nonnull !2, !align !5, !noundef !2
  call void @llvm.lifetime.end.p0(i64 32, ptr %32)
  call void @llvm.lifetime.start.p0(i64 2, ptr %28)
  %504 = load ptr, ptr %503, align 8, !nonnull !2, !align !4, !noundef !2
  %505 = call { i8, i8 } @_ZN14token_metadata10assertions4uses13assert_burner17hf2b7dbd81c686392E(ptr noalias noundef readonly align 1 dereferenceable(32) %504) #20
  %506 = extractvalue { i8, i8 } %505, 0
  %507 = trunc i8 %506 to i1
  %508 = extractvalue { i8, i8 } %505, 1
  %509 = call { i8, i8 } @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h926961b184aab48dE"(i1 noundef zeroext %507, i8 noundef %508) #20
  store { i8, i8 } %509, ptr %28, align 1
  %510 = load i8, ptr %28, align 1, !range !9, !noundef !2
  %511 = trunc i8 %510 to i1
  %512 = zext i1 %511 to i64
  switch i64 %512, label %515 [
    i64 0, label %516
    i64 1, label %557
  ]

513:                                              ; preds = %496
  call void @llvm.lifetime.start.p0(i64 32, ptr %30)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %32, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %29)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %30, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %29, ptr noalias noundef readonly align 8 dereferenceable(24) @1169) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %29)
  call void @llvm.lifetime.end.p0(i64 32, ptr %30)
  call void @llvm.lifetime.end.p0(i64 32, ptr %32)
  br label %514

514:                                              ; preds = %560, %513
  br label %564

515:                                              ; preds = %501
  unreachable

516:                                              ; preds = %501
  %517 = getelementptr inbounds { i8, i8 }, ptr %28, i32 0, i32 1
  %518 = load i8, ptr %517, align 1, !noundef !2
  call void @llvm.lifetime.end.p0(i64 2, ptr %28)
  call void @llvm.lifetime.start.p0(i64 64, ptr %27)
  %519 = call { ptr, i64 } @"_ZN4core3str21_$LT$impl$u20$str$GT$8as_bytes17hbbd1e904243a29d1E"(ptr noalias noundef nonnull readonly align 1 @184, i64 noundef 8) #20
  %520 = extractvalue { ptr, i64 } %519, 0
  %521 = extractvalue { ptr, i64 } %519, 1
  %522 = call { ptr, i64 } @"_ZN91_$LT$solana_program..pubkey..Pubkey$u20$as$u20$core..convert..AsRef$LT$$u5b$u8$u5d$$GT$$GT$6as_ref17h56c78400b7ec32e8E"(ptr noalias noundef readonly align 1 dereferenceable(32) %1) #20
  %523 = extractvalue { ptr, i64 } %522, 0
  %524 = extractvalue { ptr, i64 } %522, 1
  %525 = call { ptr, i64 } @"_ZN4core3str21_$LT$impl$u20$str$GT$8as_bytes17hbbd1e904243a29d1E"(ptr noalias noundef nonnull readonly align 1 @325, i64 noundef 4) #20
  %526 = extractvalue { ptr, i64 } %525, 0
  %527 = extractvalue { ptr, i64 } %525, 1
  call void @llvm.lifetime.start.p0(i64 1, ptr %26)
  %528 = getelementptr inbounds [1 x i8], ptr %26, i64 0, i64 0
  store i8 %518, ptr %528, align 1
  %529 = getelementptr inbounds [4 x { ptr, i64 }], ptr %27, i64 0, i64 0
  %530 = getelementptr inbounds { ptr, i64 }, ptr %529, i32 0, i32 0
  store ptr %520, ptr %530, align 8
  %531 = getelementptr inbounds { ptr, i64 }, ptr %529, i32 0, i32 1
  store i64 %521, ptr %531, align 8
  %532 = getelementptr inbounds [4 x { ptr, i64 }], ptr %27, i64 0, i64 1
  %533 = getelementptr inbounds { ptr, i64 }, ptr %532, i32 0, i32 0
  store ptr %523, ptr %533, align 8
  %534 = getelementptr inbounds { ptr, i64 }, ptr %532, i32 0, i32 1
  store i64 %524, ptr %534, align 8
  %535 = getelementptr inbounds [4 x { ptr, i64 }], ptr %27, i64 0, i64 2
  %536 = getelementptr inbounds { ptr, i64 }, ptr %535, i32 0, i32 0
  store ptr %526, ptr %536, align 8
  %537 = getelementptr inbounds { ptr, i64 }, ptr %535, i32 0, i32 1
  store i64 %527, ptr %537, align 8
  %538 = getelementptr inbounds [4 x { ptr, i64 }], ptr %27, i64 0, i64 3
  %539 = getelementptr inbounds { ptr, i64 }, ptr %538, i32 0, i32 0
  store ptr %26, ptr %539, align 8
  %540 = getelementptr inbounds { ptr, i64 }, ptr %538, i32 0, i32 1
  store i64 1, ptr %540, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr %25)
  call void @llvm.lifetime.start.p0(i64 32, ptr %24)
  call void @llvm.lifetime.start.p0(i64 216, ptr %23)
  call void @llvm.lifetime.start.p0(i64 48, ptr %22)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %22, ptr noalias noundef readonly align 8 dereferenceable(48) %176) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %21)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %21, ptr noalias noundef readonly align 8 dereferenceable(48) %503) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %20)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %20, ptr noalias noundef readonly align 8 dereferenceable(48) %203) #20
  call void @llvm.lifetime.start.p0(i64 48, ptr %19)
  call void @"_ZN80_$LT$solana_program..account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17he2725f70e343ca4bE"(ptr noalias nocapture noundef sret(%44) dereferenceable(48) %19, ptr noalias noundef readonly align 8 dereferenceable(48) %167) #20
  call void @llvm.lifetime.start.p0(i64 16, ptr %18)
  %541 = getelementptr inbounds { ptr, i64 }, ptr %18, i32 0, i32 0
  store ptr %27, ptr %541, align 8
  %542 = getelementptr inbounds { ptr, i64 }, ptr %18, i32 0, i32 1
  store i64 4, ptr %542, align 8
  %543 = getelementptr inbounds %1196, ptr %23, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %543, ptr align 8 %22, i64 48, i1 false)
  %544 = getelementptr inbounds %1196, ptr %23, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %544, ptr align 8 %19, i64 48, i1 false)
  %545 = getelementptr inbounds %1196, ptr %23, i32 0, i32 5
  store i64 1, ptr %545, align 8
  %546 = getelementptr inbounds %1196, ptr %23, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %546, ptr align 8 %21, i64 48, i1 false)
  %547 = getelementptr inbounds { ptr, i64 }, ptr %18, i32 0, i32 0
  %548 = load ptr, ptr %547, align 8, !align !5, !noundef !2
  %549 = getelementptr inbounds { ptr, i64 }, ptr %18, i32 0, i32 1
  %550 = load i64, ptr %549, align 8
  %551 = getelementptr inbounds { ptr, i64 }, ptr %23, i32 0, i32 0
  store ptr %548, ptr %551, align 8
  %552 = getelementptr inbounds { ptr, i64 }, ptr %23, i32 0, i32 1
  store i64 %550, ptr %552, align 8
  %553 = getelementptr inbounds %1196, ptr %23, i32 0, i32 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %553, ptr align 8 %20, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(i64 16, ptr %18)
  call void @llvm.lifetime.end.p0(i64 48, ptr %19)
  call void @llvm.lifetime.end.p0(i64 48, ptr %20)
  call void @llvm.lifetime.end.p0(i64 48, ptr %21)
  call void @llvm.lifetime.end.p0(i64 48, ptr %22)
  call void @_ZN9mpl_utils5token3cpi14spl_token_burn17h4104af3a4b0840c1E(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %24, ptr noalias nocapture noundef readonly dereferenceable(216) %23) #20
  call void @llvm.lifetime.end.p0(i64 216, ptr %23)
  call void @"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h27148f3755b7ccf4E"(ptr noalias nocapture noundef sret(%795) dereferenceable(32) %25, ptr noalias nocapture noundef dereferenceable(32) %24) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %24)
  %554 = load i32, ptr %25, align 8, !range !12, !noundef !2
  %555 = icmp eq i32 %554, 22
  %556 = select i1 %555, i64 0, i64 1
  switch i64 %556, label %561 [
    i64 0, label %562
    i64 1, label %563
  ]

557:                                              ; preds = %501
  %558 = getelementptr inbounds { i8, i8 }, ptr %28, i32 0, i32 1
  %559 = load i8, ptr %558, align 1, !range !11, !noundef !2
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h2831557941d89e32E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, i8 noundef %559, ptr noalias noundef readonly align 8 dereferenceable(24) @1170) #20
  call void @llvm.lifetime.end.p0(i64 2, ptr %28)
  br label %560

560:                                              ; preds = %563, %557
  br label %514

561:                                              ; preds = %516
  unreachable

562:                                              ; preds = %516
  call void @llvm.lifetime.end.p0(i64 32, ptr %25)
  call void @llvm.lifetime.end.p0(i64 1, ptr %26)
  call void @llvm.lifetime.end.p0(i64 64, ptr %27)
  br label %565

563:                                              ; preds = %516
  call void @llvm.lifetime.start.p0(i64 32, ptr %17)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %25, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %16)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %17, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %16, ptr noalias noundef readonly align 8 dereferenceable(24) @1171) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %16)
  call void @llvm.lifetime.end.p0(i64 32, ptr %17)
  call void @llvm.lifetime.end.p0(i64 32, ptr %25)
  call void @llvm.lifetime.end.p0(i64 1, ptr %26)
  call void @llvm.lifetime.end.p0(i64 64, ptr %27)
  br label %560

564:                                              ; preds = %568, %514
  call void @llvm.lifetime.end.p0(i64 1, ptr %33)
  br label %326

565:                                              ; preds = %567, %562
  br label %477

566:                                              ; preds = %481
  unreachable

567:                                              ; preds = %481
  call void @llvm.lifetime.end.p0(i64 32, ptr %15)
  br label %565

568:                                              ; preds = %481
  call void @llvm.lifetime.start.p0(i64 32, ptr %7)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %15, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr %6)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %7, i64 32, i1 false)
  call void @"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17ha2af8b033ad5a5d8E"(ptr noalias nocapture noundef sret(%89) dereferenceable(32) %0, ptr noalias nocapture noundef dereferenceable(32) %6, ptr noalias noundef readonly align 8 dereferenceable(24) @1172) #20
  call void @llvm.lifetime.end.p0(i64 32, ptr %6)
  call void @llvm.lifetime.end.p0(i64 32, ptr %7)
  call void @llvm.lifetime.end.p0(i64 32, ptr %15)
  br label %564

569:                                              ; preds = %477, %163
  ret void
}
*** IR Dump After ForceFunctionAttrsPass on [module] ***
