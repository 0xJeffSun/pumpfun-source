"""Independently verify focused receipts and compare full runtime metadata."""
from pathlib import Path
import base64
from collections import Counter
import gzip
import hashlib
import json
import re
from solders.transaction import Transaction

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
report = json.loads((HERE / 'result.json').read_bytes())
observer = json.loads(gzip.decompress((HERE / 'signed-transactions.json.gz').read_bytes()))
with gzip.open(HERE / 'raw-transactions.jsonl.gz', 'rt') as stream:
    receipts = [json.loads(line) for line in stream]
assert len(receipts) == len(observer['transactions']) == 288
assert len({row['vm'] for row in receipts}) == 288
assert observer['transaction_count'] == observer['signature_count'] == 288
assert report['counts'] == dict(vms=288, transactions=288, signature_fields=288)
assert observer['script_sha256'] == sha(ROOT / 'work/amm-transfer-fee-20261028/focused.py')
assert observer['observer_sha256'] == sha(ROOT / 'repro/pump_amm/owner6048-v144/runtime/observe_suite.py')
assert all(sha(ROOT / path) == digest for path, digest in report['input_sha256'].items())
assert all(sha(path) == item['sha256'] for path, item in observer['program_file_sha256'].items())
assert not report['mismatches']

def comparable(receipt):
    metadata = dict(receipt['metadata'])
    metadata.pop('compute_units_consumed')
    metadata['logs'] = [line for line in metadata['logs'] if not re.fullmatch(
        r'Program \S+ consumed \d+ of \d+ compute units', line)]
    return {key: receipt[key] for key in ('before', 'after', 'transaction_sha256', 'clock', 'error')} | dict(metadata=metadata)

for receipt, observed in zip(receipts, observer['transactions']):
    raw = base64.b64decode(receipt['transaction_base64'])
    tx = Transaction.from_bytes(raw)
    assert all(tx.verify_with_results())
    assert receipt['all_signatures_verified'] and observed['all_signatures_verified']
    assert receipt['transaction_base64'] == observed['transaction_base64']
    assert hashlib.sha256(raw).hexdigest() == receipt['transaction_sha256'] == observed['transaction_sha256']
    assert observed['amm_program_sha256'] == report['image_sha256'][receipt['context']['image']]
    assert observed['logs_sha256'] == hashlib.sha256(json.dumps(receipt['metadata']['logs'], separators=(',', ':')).encode()).hexdigest()
    if receipt['error'] is not None:
        assert receipt['rollback_except_payer_fee'] is True
        assert receipt['payer_fee_lamports'] == 5000

for index in range(96):
    original, control, candidate = receipts[index * 3:index * 3 + 3]
    assert [row['context']['image'] for row in (original, control, candidate)] == ['original', 'control', 'candidate']
    assert comparable(original) == comparable(control) == comparable(candidate), index

summary = dict(case_count=96, signed_transactions=288, independent_signature_fields=288,
               fresh_vm_count=288, full_message_state_and_metadata_mismatches=0,
               classifications=report['classifications'],
               failed_transactions_with_verified_rollback=96,
               verified_payer_fee_lamports=5000,
               image_sha256=report['image_sha256'],
               epoch_selection=report['epoch_selection_evidence'],
               compute_units_compared=False,
               scope='All message non-executable account before/after snapshots, raw transaction bytes, errors, clocks, inner instructions, return data, signatures, and logs compare exactly across each triple after removing only runtime compute-unit log lines and compute_units_consumed. Full raw receipts retain those measurements. No Clock failure injection.',
               verification_script_sha256=sha(__file__),
               files={name: sha(HERE / name) for name in ('result.json', 'raw-transactions.jsonl.gz', 'signed-transactions.json.gz')})
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('case_count', 'signed_transactions', 'fresh_vm_count', 'classifications', 'full_message_state_and_metadata_mismatches')}))
