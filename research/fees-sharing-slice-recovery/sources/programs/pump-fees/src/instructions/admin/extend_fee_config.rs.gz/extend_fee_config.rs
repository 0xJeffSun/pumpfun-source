use anchor_lang::prelude::*;
use crate::{FeeError, ID};
pub use crate::contexts::ExtendFeeConfig;
use crate::types::ExtendFeeConfigEvent;

































pub fn execute(ctx: Context<ExtendFeeConfig>) -> Result<()> {
    let info = &ctx.accounts.fee_config;
    require_keys_eq!(*info.owner, ID, FeeError::InvalidFeeConfigAccount);




    let data = info.try_borrow_data()?;

    require_gte!(data.len(), 9usize, FeeError::InvalidFeeConfigAccount);




    require!(data[..8] == [143,52,146,187,219,123,76,155], FeeError::InvalidFeeConfigAccount);


    let bump = [data[8]];
    let config_program = ctx.accounts.config_program_id.key();




    let expected_result = Pubkey::create_program_address(&[b"fee_config", config_program.as_ref(), &bump], ctx.program_id);
    require!(expected_result.is_ok(), FeeError::InvalidFeeConfigAccount);
    require_keys_eq!(expected_result.clone().unwrap(), info.key(), FeeError::InvalidFeeConfigAccount);
    drop(data);
    let current_size = info.data_len(); let new_size = 4097usize;
    if current_size == new_size { msg!("Fee config account already has the correct size"); return Ok(()); } if current_size > new_size { msg!("Fee config account already has more than {} bytes: {}", new_size, current_size); return Ok(()); }
    let rent = Rent::get()?;
    let new_minimum = rent.minimum_balance(new_size);
    let current_minimum = rent.minimum_balance(current_size);
    if new_minimum > current_minimum {
    anchor_lang::system_program::transfer(CpiContext::new(
        ctx.accounts.system_program.to_account_info(), anchor_lang::system_program::Transfer {
            from: ctx.accounts.user.to_account_info(), to: info.clone(),
        }), new_minimum.saturating_sub(current_minimum))?;
    }
    info.realloc(new_size, true)?;
    let event = ExtendFeeConfigEvent { fee_config: info.key(), user: ctx.accounts.user.key(),
        current_size: current_size as u64, new_size: new_size as u64, timestamp: Clock::get()?.unix_timestamp };
    emit!(event); emit_cpi!(event); Ok(())
}
