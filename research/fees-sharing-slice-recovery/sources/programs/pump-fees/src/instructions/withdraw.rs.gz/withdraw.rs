use anchor_lang::prelude::*;
use crate::FeeError;
pub use crate::withdrawal::{Withdraw, WithdrawEvent};








































































pub fn execute(ctx:Context<Withdraw>)->Result<()> {
  let user=ctx.accounts.user.key();
  let signer_seeds: &[&[&[u8]]] = &[&[b"referral-vault",user.as_ref(),&[ctx.bumps.referral_vault]]];
  let amount; let mint;
  if ctx.accounts.quote_mint.is_none() { mint = Pubkey::default();
   amount=ctx.accounts.referral_vault.lamports().saturating_sub(Rent::get()?.minimum_balance(0));









   require!(amount>0,FeeError::NothingToWithdraw);
   anchor_lang::system_program::transfer(CpiContext::new_with_signer(ctx.accounts.system_program.to_account_info(),anchor_lang::system_program::Transfer{from:ctx.accounts.referral_vault.to_account_info(),to:ctx.accounts.user.to_account_info()},signer_seeds),amount)?;
   }else{
   let quote=ctx.accounts.quote_mint.as_ref().unwrap(); mint=quote.key();
   let vault=ctx.accounts.vault_ata.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
   let destination=ctx.accounts.user_ata.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
   let token=ctx.accounts.token_program.as_ref().ok_or(FeeError::IncompleteTokenAccounts)?;
   amount=vault.amount;


























   require!(amount>0,FeeError::NothingToWithdraw);
   anchor_spl::token_interface::transfer_checked(CpiContext::new_with_signer(token.to_account_info(),anchor_spl::token_interface::TransferChecked{from:vault.to_account_info(),mint:quote.to_account_info(),to:destination.to_account_info(),authority:ctx.accounts.referral_vault.to_account_info()},signer_seeds),amount,quote.decimals)?;
   };
  let event=WithdrawEvent{timestamp:Clock::get()?.unix_timestamp,user,quote_mint:mint,amount};
  emit!(event);emit_cpi!(event);Ok(())
 }
