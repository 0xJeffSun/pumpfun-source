//! Independently reconstructed PumpSwap handler and account constraints.
//! Byte-checked original parser 0x46378 (buy), 0x4cc98 (sell).
use anchor_lang::prelude::*;
use anchor_spl::associated_token::AssociatedToken;
use curve_accounts::token_interface::{Mint,TokenAccount,TokenInterface};
use anchor_spl::token_2022::Token2022;
use crate::{GlobalParams,MayhemError};
use crate::state::MayhemStatus;
use anchor_lang::solana_program::{instruction::Instruction,program::invoke_signed};
use super::sell::{SellEvent,SellError};
use super::buy::BuyError;
use super::pump_swap_types::{SwapPool,SwapGlobalConfig,AMM_ID,PumpSwapError};
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
use crate::state::MayhemState;
use crate::checked_program::{CheckedSystemProgram,CheckedSystemProgramBumps,__client_accounts_checked_system_program,__cpi_client_accounts_checked_system_program};
const SPL_TOKEN_ID:Pubkey=pubkey!("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
#[derive(Accounts)]
pub struct SellPumpSwap<'info> {
 #[account(mut)]pub trader:Signer<'info>,
 #[account(mut,seeds=[b"global-params"],bump,has_one=trader)]pub global_params:Box<Account<'info,GlobalParams>>,
 #[account(mut,seeds=[b"mayhem-state",mint.key().as_ref()],bump)]pub mayhem_state:Box<Account<'info,MayhemState>>,
 pub mint:Box<InterfaceAccount<'info,Mint>>,
 #[account(mut,associated_token::mint=mint,associated_token::authority=sol_vault,associated_token::token_program=mint.to_account_info().owner)]
 pub mayhem_token_vault:Box<InterfaceAccount<'info,TokenAccount>>,
 #[account(init_if_needed,payer=trader,associated_token::mint=quote_mint,associated_token::authority=sol_vault,associated_token::token_program=quote_token_program)]
 pub mayhem_quote_vault:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: original PDA+mut only; no SystemAccount ownership check.
 #[account(mut,seeds=[b"sol-vault"],bump)]pub sol_vault:UncheckedAccount<'info>,
 pub system_program:Program<'info,System>,
 // Original parses Interface then applies address constraint 2012 at 0x49568.
 #[account(address=SPL_TOKEN_ID)]pub quote_token_program:Interface<'info,TokenInterface>,
 pub base_token_program:Program<'info,Token2022>,
 pub associated_token_program:Program<'info,AssociatedToken>,
 // Original has no pool seeds or has_one checks, only typed owner/discriminator + mut.
 #[account(mut)]pub pool:Box<Account<'info,SwapPool>>,
 pub global_config:Box<Account<'info,SwapGlobalConfig>>,
 /// CHECK: original consumes AccountInfo directly at 0x47560, no Mint deserialize.
 pub quote_mint:UncheckedAccount<'info>,
 #[account(mut)]pub pool_base_token_account:Box<InterfaceAccount<'info,TokenAccount>>,
 #[account(mut)]pub pool_quote_token_account:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: original mut only; membership checked by AMM CPI.
 #[account(mut)]pub protocol_fee_recipient:UncheckedAccount<'info>,
 #[account(mut,associated_token::mint=quote_mint,associated_token::authority=protocol_fee_recipient,associated_token::token_program=quote_token_program)]
 pub protocol_fee_recipient_token_account:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: original unchecked, no outer seed check.
 pub pump_swap_event_authority:UncheckedAccount<'info>,
 /// CHECK: original fixed address only, not Program<...>.
 #[account(address=AMM_ID)]pub pump_swap_program:UncheckedAccount<'info>,
 #[account(mut,associated_token::mint=quote_mint,associated_token::authority=coin_creator_vault_authority,associated_token::token_program=quote_token_program)]
 pub coin_creator_vault_ata:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: original unchecked, actual AMM CPI validates authority.
 pub coin_creator_vault_authority:UncheckedAccount<'info>,
 /// CHECK: original unchecked.
 pub fee_config:UncheckedAccount<'info>,
 /// CHECK: original unchecked.
 pub fee_program:UncheckedAccount<'info>,
 /// CHECK: original Mayhem-derived event authority.
 #[account(seeds=[b"__event_authority"],bump)]pub event_authority:UncheckedAccount<'info>,
 pub program:Program<'info,crate::program::MayhemRecovered>,
 /// CHECK: original PDA is derived under MAYHEM; not AMM; no mut/owner check.
 #[account(seeds=[b"pool-v2",mint.key().as_ref()],bump)]pub pool_v2:UncheckedAccount<'info>,
 /// CHECK: original unchecked and read-only.
 pub buyback_recipient:UncheckedAccount<'info>,
 /// CHECK: original unchecked + mut; actual AMM CPI validates ATA.
 #[account(mut)]pub buyback_recipient_ata:UncheckedAccount<'info>,
}

fn math()->Error {MayhemError::MathOverflow.into()}
pub fn handler(ctx:Context<SellPumpSwap>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;


 a.mayhem_state.validate_trade(&a.global_params)?;





 let effective_result:std::result::Result<u64,MayhemError> = (|| {
 (a.pool_quote_token_account.amount as i128).checked_add(a.pool.virtual_quote_reserves).and_then(|v|u64::try_from(v).ok()).ok_or(MayhemError::MathOverflow)
 })();let effective_quote=effective_result?;
 a.mayhem_state.validate_quote(effective_quote,&a.global_params,&a.quote_mint.key())?;
 let price_check:std::result::Result<(),MayhemError> = (|| {
 let vt=a.pool_base_token_account.amount as u128;let vs=effective_quote as u128;
 let price=match (vs*1_000_000_000_000_000u128).checked_div(vt){Some(v)=>v,None=>return Err(MayhemError::MathOverflow)};
 let scaled=match reference.checked_mul(tolerance_bps as u128){Some(v)=>v,None=>return Err(MayhemError::MathOverflow)};
 let delta=scaled/10_000;
 let low=match reference.checked_sub(delta){Some(v)=>v,None=>return Err(MayhemError::MathOverflow)};
 let high=match reference.checked_add(delta){Some(v)=>v,None=>return Err(MayhemError::MathOverflow)};
 if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);}
 Ok(())
 })();price_check?;
 let (input,minimum)=crate::state::sell_quote(&a.global_params,a.pool_base_token_account.amount,effective_quote,a.mayhem_token_vault.amount,retained_reserve_bps,a.quote_mint.key())?;






 let native=a.quote_mint.key()==WSOL;
 let before_sol=if native{a.sol_vault.lamports()}else{a.mayhem_quote_vault.amount};let before_tokens=a.mayhem_token_vault.amount;

 let sol_vault_bump=ctx.bumps.sol_vault;
 execute_sell(a,sol_vault_bump,input,minimum)?;



 if native {curve_accounts::token_interface::close_account(CpiContext::new_with_signer(a.quote_token_program.key(),curve_accounts::token_interface::CloseAccount{account:a.mayhem_quote_vault.to_account_info(),destination:a.sol_vault.to_account_info(),authority:a.sol_vault.to_account_info()},&[&[b"sol-vault",&[sol_vault_bump]]]))?;}
 a.mayhem_token_vault.reload()?;a.pool_base_token_account.reload()?;a.pool_quote_token_account.reload()?;if !native{a.mayhem_quote_vault.reload()?;}
 let after_quote=if native{a.sol_vault.lamports()}else{a.mayhem_quote_vault.amount};
 let (sol,tokens)=super::pump_amm_interface::sold_amounts(before_sol,after_quote,before_tokens,a.mayhem_token_vault.amount);
 crate::state::record_sell(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&a.quote_mint.key())?;

 let (sol_amount,sol_vault_balance,global_sol_deployed,state_sol_deployed,virtual_sol,quote_mint,quote_vault_balance,global_quote_deployed,state_quote_deployed,virtual_quote)=if native {
 let vault_balance=a.sol_vault.lamports();let global_deployed=a.global_params.sol_deployed;let state_deployed=a.mayhem_state.field_56;let quote_reserve=a.pool_quote_token_account.amount;
 (sol,vault_balance,global_deployed,state_deployed,quote_reserve,Pubkey::default(),vault_balance,global_deployed,state_deployed,quote_reserve)
 } else {
 let global_deployed=a.global_params.stable_deployed;let quote_reserve=a.pool_quote_token_account.amount;let vault_balance=a.mayhem_quote_vault.amount;let state_deployed=a.mayhem_state.field_56;let mint=a.quote_mint.key();
 (0,0,0,0,0,mint,vault_balance,global_deployed,state_deployed,quote_reserve)
 };
 let event=SellEvent{side:1,sol_vault:a.sol_vault.key(),mint:a.mint.key(),sol_amount,token_amount:tokens,sol_vault_balance,token_vault_balance:a.mayhem_token_vault.amount,state_sol_deployed,state_token_net:a.mayhem_state.field_72,virtual_sol,virtual_tokens:a.pool_base_token_account.amount,global_sol_deployed,timestamp:Clock::get()?.unix_timestamp,end_timestamp:a.mayhem_state.end_timestamp,real_sol:virtual_sol,real_tokens:a.pool_base_token_account.amount,version:a.global_params.version,retained_reserve_bps,quote_amount:sol,quote_vault_balance,state_quote_deployed,virtual_quote,global_quote_deployed,real_quote:virtual_quote,quote_mint};
 emit!(event);emit_cpi!(event);Ok(())
}

#[inline(always)]
fn inline_cpi_info<'info>(info:&AccountInfo<'info>)->AccountInfo<'info> {
 AccountInfo { key:info.key, lamports:std::rc::Rc::clone(&info.lamports), data:std::rc::Rc::clone(&info.data), owner:info.owner, _unused:info._unused, is_signer:info.is_signer, is_writable:info.is_writable, executable:info.executable }
}

#[inline(always)]
fn execute_sell<'info>(a:&SellPumpSwap<'info>,sol_vault_bump:u8,input:u64,minimum:u64)->Result<()> {
 crate::amm_cpi::cpi::sell(CpiContext::new(a.pump_swap_program.key(),crate::amm_cpi::cpi::accounts::Sell{user:inline_cpi_info(a.sol_vault.as_ref()),pool:inline_cpi_info(a.pool.as_ref().as_ref()),global_config:inline_cpi_info(a.global_config.as_ref().as_ref()),pool_base_token_account:inline_cpi_info(a.pool_base_token_account.as_ref().as_ref()),pool_quote_token_account:inline_cpi_info(a.pool_quote_token_account.as_ref().as_ref()),user_base_token_account:inline_cpi_info(a.mayhem_token_vault.as_ref().as_ref()),user_quote_token_account:inline_cpi_info(a.mayhem_quote_vault.as_ref().as_ref()),quote_token_program:inline_cpi_info(a.quote_token_program.as_ref()),base_token_program:inline_cpi_info(a.base_token_program.as_ref()),system_program:inline_cpi_info(a.system_program.as_ref()),quote_mint:inline_cpi_info(a.quote_mint.as_ref()),base_mint:inline_cpi_info(a.mint.as_ref().as_ref()),associated_token_program:inline_cpi_info(a.associated_token_program.as_ref()),event_authority:inline_cpi_info(a.pump_swap_event_authority.as_ref()),program:inline_cpi_info(a.pump_swap_program.as_ref()),protocol_fee_recipient:inline_cpi_info(a.protocol_fee_recipient.as_ref()),protocol_fee_recipient_token_account:inline_cpi_info(a.protocol_fee_recipient_token_account.as_ref().as_ref()),coin_creator_vault_ata:inline_cpi_info(a.coin_creator_vault_ata.as_ref().as_ref()),coin_creator_vault_authority:inline_cpi_info(a.coin_creator_vault_authority.as_ref()),fee_config:inline_cpi_info(a.fee_config.as_ref()),fee_program:inline_cpi_info(a.fee_program.as_ref())}).with_signer(&[&[b"sol-vault",&[sol_vault_bump]]]).with_remaining_accounts(vec![inline_cpi_info(a.buyback_recipient.as_ref()),inline_cpi_info(a.buyback_recipient_ata.as_ref())]),input,minimum).map_err(super::pump_amm_interface::sell_cpi_failed)
}
