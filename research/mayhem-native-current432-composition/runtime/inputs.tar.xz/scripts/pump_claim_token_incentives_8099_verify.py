"""Verify the 8099031-source claim build and signed offline differential."""

import gzip
import hashlib
import json
from pathlib import Path

import pump_claim_token_incentives_differential as diff
import pump_claim_token_incentives_verify as historical


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "repro/pump/claim-token-incentives-8099"
SOURCE_BASE = "80990317bd9c0363e071646b892490886d7bf946"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    receipt = json.loads(gzip.decompress((PACKAGE / "differential.json.gz").read_bytes()))
    first = json.loads((PACKAGE / "build-comparison.json").read_text())
    second = json.loads((PACKAGE / "second-build-comparison.json").read_text())
    reproducibility = json.loads((PACKAGE / "build-reproducibility.json").read_text())
    candidate = PACKAGE / "candidate.so"
    assert receipt["baseline_commit"] == reproducibility["source_base_commit"] == SOURCE_BASE
    assert receipt["candidate_sha256"] == reproducibility["candidate_sha256"] == sha(candidate)
    assert receipt["candidate_path"] == str(candidate.relative_to(ROOT))
    assert receipt["build_receipt_sha256"] == sha(PACKAGE / "build-comparison.json")
    assert receipt["second_build_comparison_sha256"] == sha(PACKAGE / "second-build-comparison.json")
    assert reproducibility["build_comparison_sha256"] == [
        receipt["build_receipt_sha256"], receipt["second_build_comparison_sha256"]]
    assert first["source_sha256"] == second["source_sha256"] == reproducibility["source_sha256"]
    assert first["selected_toolchain"] == second["selected_toolchain"] == "v1.44"
    assert first["comparison"]["candidate_sha256"] == second["comparison"]["candidate_sha256"] == sha(candidate)
    assert not first["comparison"]["full_byte_equality"] and reproducibility["builds_identical"]
    assert receipt["source_sha256"] == {
        **first["source_sha256"],
        "scripts/pump_claim_token_incentives_differential.py": sha(Path(diff.__file__)),
    }
    assert all(sha(ROOT / path) == digest for path, digest in receipt["source_sha256"].items())
    assert receipt["script_sha256"] == sha(Path(diff.__file__))
    for attempt_name in ("build-attempt.json", "second-build-attempt.json"):
        attempt = json.loads((PACKAGE / attempt_name).read_text())
        assert attempt["returncode"] == 0 and attempt["source_unchanged"]
        assert attempt["source_sha256"] == first["source_sha256"]
    for report, log_name in ((first, "build.log.gz"), (second, "second-build.log.gz")):
        assert hashlib.sha256(gzip.decompress((PACKAGE / log_name).read_bytes())).hexdigest() == report["build_log_sha256"]
    assert receipt["target_sha256"] == sha(diff.ORIGINAL)
    assert receipt["idl_sha256"] == sha(diff.IDL)
    assert receipt["fixture_sha256"] == sha(diff.FIXTURE)
    assert receipt["dependency_sha256"] == {
        name: sha(ROOT / f"evidence/dependencies/{name}/deployed.so")
        for name in ("spl_token_2022", "associated_token")}
    regressions = json.loads((PACKAGE / "regression-summary.json").read_text())
    assert regressions["candidate_sha256"] == sha(candidate)
    quote = json.loads(gzip.decompress((PACKAGE / "quote-control-regression.json.gz").read_bytes()))
    curve = json.loads(gzip.decompress((PACKAGE / "multi-hop-regression.json.gz").read_bytes()))
    assert regressions["quote_control"]["receipt_sha256"] == sha(PACKAGE / "quote-control-regression.json.gz")
    assert regressions["multi_hop_curve"]["receipt_sha256"] == sha(PACKAGE / "multi-hop-regression.json.gz")
    assert quote["cases"] == 507 and quote["mismatches"] == 0
    assert all(sha(ROOT / path) == digest for path, digest in quote["bound_inputs_sha256"].items())
    assert curve["case_count"] == curve["passed"] == 56
    assert curve["candidate_sha256"] == sha(candidate)

    idl = json.loads(diff.IDL.read_text())
    event_discriminator = bytes(next(item for item in idl["events"]
        if item["name"] == "ClaimTokenIncentivesEvent")["discriminator"])
    _, keys, _, user_volume, global_ata = diff.fixture_data()
    keys["user_ata"] = keys["user_base"]
    keys["global_ata"] = global_ata
    assert user_volume == keys["volume"]
    assert len(receipt["cases"]) == len(diff.CASES) == 60
    successes = events = 0
    for row, case in zip(receipt["cases"], diff.CASES):
        name = case["name"]
        assert row["case"] == case
        target = diff.run_case(diff.ORIGINAL, case)
        current = diff.run_case(candidate, case)
        assert row["target"] == target and row["candidate"] == current
        assert not row["differences"]
        historical.assert_signature(target)
        historical.assert_signature(current)
        for field in ("error", "before", "after", "event_data_base64", "inner",
                      "signature", "transaction_base64"):
            assert target[field] == current[field], (name, field)
        assert target["error_code"] == historical.EXPECTED_ERRORS.get(name)
        if target["success"]:
            successes += 1
            if target["event_data_base64"]:
                events += 1
                historical.assert_event_and_cpis(target, event_discriminator, keys)
        else:
            assert target["before"]["user_volume"] == target["after"]["user_volume"]
            assert not target["event_data_base64"]
    assert receipt["summary"] == {"cases": 60, "matched": 60, "target_successes": 48}
    assert successes == 48 and events == 31
    print(json.dumps({"verified": True, "signed_cases": 60, "matches": 60,
                      "successes": successes, "payout_events": events,
                      "candidate_sha256": sha(candidate)}))


if __name__ == "__main__":
    main()
