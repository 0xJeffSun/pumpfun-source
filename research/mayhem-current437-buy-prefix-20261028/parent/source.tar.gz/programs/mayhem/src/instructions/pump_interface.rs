use anchor_lang::prelude::*;



































































































































































































#[event(discriminator=[0x31,0x48,0x7b,0x2d,0x6e,0x40,0xb0,0x85])]
pub struct SellEvent {
 pub side: bool,
 pub sol_vault: Pubkey,
 pub mint: Pubkey,
 pub sol_amount: u64,
 pub token_amount: u64,
 pub sol_vault_balance: u64,
 pub token_vault_balance: u64,
 pub state_sol_deployed: i128,
 pub state_token_net: i128,
 pub virtual_sol: u64,
 pub virtual_tokens: u64,
 pub global_sol_deployed: i128,
 pub timestamp: i64,
 pub end_timestamp: i64,
 pub real_sol: u64,
 pub real_tokens: u64,
 pub version: u32,
 pub retained_reserve_bps: u16,
 pub quote_amount: u64,
 pub quote_vault_balance: u64,
 pub state_quote_deployed: i128,
 pub virtual_quote: u64,
 pub global_quote_deployed: i128,
 pub real_quote: u64,
 pub quote_mint: Pubkey,
}
use super::sell::{LegacySell,SellCurve}; use super::buy::{LegacyBuy,clone_info,BuyError};
use crate::MayhemError;

















































pub fn legacy_buy_handler(ctx:Context<LegacyBuy>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;
 a.mayhem_state.validate_trade(&a.global_params)?;





 a.mayhem_state.validate_quote(a.bonding_curve.real_sol_reserves,&a.global_params,&Pubkey::default())?;





 let c=&a.bonding_curve;

 let price_check:std::result::Result<(),MayhemError> = (|| {
 let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;
 let Some(price)=(vs*1_000_000_000_000_000u128).checked_div(vt) else {return Err(MayhemError::MathOverflow)};
 let Some(scaled)=reference.checked_mul(tolerance_bps as u128) else {return Err(MayhemError::MathOverflow)};
 let delta=scaled/10_000;
 let Some(low)=reference.checked_sub(delta) else {return Err(MayhemError::MathOverflow)};
 let Some(high)=reference.checked_add(delta) else {return Err(MayhemError::MathOverflow)};
 if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);}
 Ok(())
 })();price_check?;let vt=c.virtual_token_reserves as u128;

 let (input,output)=crate::state::buy_amounts(vt,c,&a.global_params.field_2,a.mayhem_token_vault.amount as u128,retained_reserve_bps);
 let before_sol=a.sol_vault.lamports();let before_tokens=a.mayhem_token_vault.amount;


 
 crate::pump::cpi::buy(CpiContext::new_with_signer(a.pump_program.key(),crate::pump::cpi::accounts::Buy {global:clone_info(a.global.as_ref()),fee_recipient:clone_info(a.fee_recipient.as_ref()),mint:clone_info(a.mint.as_ref().as_ref()),bonding_curve:clone_info(a.bonding_curve.as_ref().as_ref()),associated_bonding_curve:clone_info(a.associated_bonding_curve.as_ref().as_ref()),associated_user:clone_info(a.mayhem_token_vault.as_ref().as_ref()),user:clone_info(a.sol_vault.as_ref()),system_program:clone_info(a.system_program.as_ref()),token_program:clone_info(a.token_program.as_ref()),creator_vault:clone_info(a.creator_vault.as_ref()),event_authority:clone_info(a.pump_event_authority.as_ref()),program:clone_info(a.pump_program.as_ref()),global_volume_accumulator:clone_info(a.global_volume_accumulator.as_ref()),user_volume_accumulator:clone_info(a.user_volume_accumulator.as_ref()),fee_config:clone_info(a.fee_config.as_ref()),fee_program:clone_info(a.fee_program.as_ref())},&[&[b"sol-vault",&[ctx.bumps.sol_vault]]])
 .with_remaining_accounts(vec![clone_info(a.bonding_curve_v2.as_ref()),clone_info(a.buyback_recipient.as_ref())])
 ,input,output,false).map_err(|_| {


    error!(BuyError::PumpCpiFailed)
 })?;

 a.mayhem_token_vault.reload()?;a.bonding_curve.reload()?;




              let sol=before_sol-a.sol_vault.lamports();
              let tokens=a.mayhem_token_vault.amount-before_tokens;
 crate::state::record_amm_buy(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&Pubkey::default())?;






 let event=SellEvent{side:false,sol_vault:a.sol_vault.key(),mint:a.mint.key(),sol_amount:sol,token_amount:tokens,sol_vault_balance:a.sol_vault.lamports(),token_vault_balance:a.mayhem_token_vault.amount,state_sol_deployed:a.mayhem_state.field_56,state_token_net:a.mayhem_state.field_72,end_timestamp:a.mayhem_state.end_timestamp,virtual_sol:a.bonding_curve.virtual_sol_reserves,virtual_tokens:a.bonding_curve.virtual_token_reserves,timestamp:Clock::get()?.unix_timestamp,real_sol:a.bonding_curve.real_sol_reserves,real_tokens:a.bonding_curve.real_token_reserves,version:a.global_params.version,global_sol_deployed:a.global_params.sol_deployed,retained_reserve_bps,quote_amount:sol,quote_vault_balance:a.sol_vault.lamports(),state_quote_deployed:a.mayhem_state.field_56,virtual_quote:a.bonding_curve.virtual_sol_reserves,global_quote_deployed:a.global_params.sol_deployed,real_quote:a.bonding_curve.real_sol_reserves,quote_mint:Pubkey::default()};
 emit!(event);emit_cpi!(event);Ok(())
}


































































pub fn legacy_sell_handler(ctx:Context<LegacySell>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;
 a.mayhem_state.validate_trade(&a.global_params)?;
 a.mayhem_state.validate_quote(a.bonding_curve.real_sol_reserves, &a.global_params, &Pubkey::default())?;

 let c=&a.bonding_curve;
 let price_check:std::result::Result<(),MayhemError> = (|| {
 let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;
 let Some(price)=(vs*1_000_000_000_000_000u128).checked_div(vt) else {return Err(MayhemError::MathOverflow)};
 let Some(scaled)=reference.checked_mul(tolerance_bps as u128) else {return Err(MayhemError::MathOverflow)};let delta=scaled/10_000;
 let Some(low)=reference.checked_sub(delta) else {return Err(MayhemError::MathOverflow)};let Some(high)=reference.checked_add(delta) else {return Err(MayhemError::MathOverflow)};
 if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);} Ok(())
 })();price_check?;
 let (input, minimum) = crate::state::sell_amounts(c.virtual_token_reserves,c,&a.global_params.field_2,a.mayhem_token_vault.amount,retained_reserve_bps);




 let before_sol=a.sol_vault.lamports();let before_tokens=a.mayhem_token_vault.amount;


 crate::pump::cpi::sell(CpiContext::new_with_signer(a.pump_program.key(),crate::pump::cpi::accounts::Sell {
  global:clone_sell_info(a.global.as_ref()),
  fee_recipient:clone_sell_info(a.fee_recipient.as_ref()),
  mint:clone_sell_info(a.mint.as_ref().as_ref()),
  bonding_curve:clone_sell_info(a.bonding_curve.as_ref().as_ref()),
  associated_bonding_curve:clone_sell_info(a.associated_bonding_curve.as_ref().as_ref()),
  associated_user:clone_sell_info(a.mayhem_token_vault.as_ref().as_ref()),
  user:clone_sell_info(a.sol_vault.as_ref()),
  system_program:clone_sell_info(a.system_program.as_ref()),
  token_program:clone_sell_info(a.token_program.as_ref()),
  creator_vault:clone_sell_info(a.creator_vault.as_ref()),
  event_authority:clone_sell_info(a.pump_event_authority.as_ref()),
  program:clone_sell_info(a.pump_program.as_ref()),
  fee_config:clone_sell_info(a.fee_config.as_ref()),
  fee_program:clone_sell_info(a.fee_program.as_ref()),
 },&[&[b"sol-vault",&[ctx.bumps.sol_vault]]])
  .with_remaining_accounts(vec![clone_sell_info(a.bonding_curve_v2.as_ref()),clone_sell_info(a.buyback_recipient.as_ref())]),input,minimum).map_err(|_|error!(MayhemError::PumpCpiFailed))?;
 a.mayhem_token_vault.reload()?;a.bonding_curve.reload()?;






    let sol=          a.sol_vault.lamports()-before_sol;
    let tokens=          before_tokens-a.mayhem_token_vault.amount;
 crate::state::record_sell(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&Pubkey::default())?;


 let event=SellEvent{side:true,sol_vault:a.sol_vault.key(),mint:a.mint.key(),sol_amount:sol,token_amount:tokens,sol_vault_balance:a.sol_vault.lamports(),token_vault_balance:a.mayhem_token_vault.amount,state_sol_deployed:a.mayhem_state.field_56,state_token_net:a.mayhem_state.field_72,end_timestamp:a.mayhem_state.end_timestamp,virtual_sol:a.bonding_curve.virtual_sol_reserves,virtual_tokens:a.bonding_curve.virtual_token_reserves,timestamp:Clock::get()?.unix_timestamp,global_sol_deployed:a.global_params.sol_deployed,real_sol:a.bonding_curve.real_sol_reserves,real_tokens:a.bonding_curve.real_token_reserves,version:a.global_params.version,retained_reserve_bps,quote_amount:sol,quote_vault_balance:a.sol_vault.lamports(),state_quote_deployed:a.mayhem_state.field_56,virtual_quote:a.bonding_curve.virtual_sol_reserves,global_quote_deployed:a.global_params.sol_deployed,real_quote:a.bonding_curve.real_sol_reserves,quote_mint:Pubkey::default()};
 emit!(event);emit_cpi!(event);Ok(())
}

#[inline(always)]
fn clone_sell_info<'a>(info:&AccountInfo<'a>)->AccountInfo<'a> {
 AccountInfo { key:info.key, lamports:std::rc::Rc::clone(&info.lamports), data:std::rc::Rc::clone(&info.data), owner:info.owner, _unused:info._unused, is_signer:info.is_signer, is_writable:info.is_writable, executable:info.executable }
}

