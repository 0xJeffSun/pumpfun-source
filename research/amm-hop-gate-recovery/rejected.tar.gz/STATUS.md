# Active: real AMM multi-hop helper gain, runtime/repeat in progress

2026-10-28, heartbeat starting07:55Z. Checkout stays clean on closed PR411
branch codex/amm-native-inverse-fee at da0fea0290ee45c312b3bb00af273f420a511264.
Latest upstream fetched1fa7b5338 (maintainedAMM660, PumpRound47). Read latest
README, SECURITY, remaining/parallel work and recent PRs/direct source diffs.
No overlapping apply_hop_fees change found. PR408 merged with48queued/3running
at this run's scope check; no own open PR. PR411 remains closed unmerged.

H=/home/ahi200/pumpfun-work/20261028-amm-select-resume.
G=/home/ahi200/pumpfun-work/20261028-amm-incentive-regression.
Corrected baseline is G/source-guard and G/guard,735normalized/159raw, strip
d7eb57fc57f18b0f6690206d785db576e7c4cd233cca7bdb9c625b443b541ef6.
The inherited128 incentive errors were already corrected by upstream H11.
This correction is imported, not a new source contribution. Old PR411 artifacts
and evidence are unchanged. Do not use their runtime for this artifact.

## Actual new source result

H/source-hop-lp-first -> H/hop-lp-first normal full build:736/785normalized,
159raw, exactly one gained full536-byte window0x44ab0, no losses. Strip
8538bc26ce126d63bf9fbdf0547780e1f893ac2655689a4c4b08c3ef435b20b5;
symbols86a1414ef62270db1f6267b7f2edac33d0d78f5e82e11532dbd163eaaa50a44f.
Only programs/pump-amm/src/instructions/swap/multi_hop_swap.rs changes among
54 source inputs; all396dependency artifacts unchanged. Source line counts
preserved. No flags/assembly/binary editing. build_hop_lp_first.py and
measurement-hop-lp-first.json retain exact evidence. This is not maintained
main's660 count and not raw function or whole ELF equality.

Source: match selector Result with borrowed Ok payload; call a pure
HopFeeGates::apply(self, &AppliedFees) helper returning AppliedFees; select LP
pair first, then creator, then protocol. Aggregate gate transfer restores the
original i24 copy and packed bool masking; borrowing preserves field-read/error
boundaries; LP-first order restores original load/store scheduling.
The actual direct callee is select_and_apply_v2, itself still unmatched.
Need explicitly report that remaining callee obligation, not claim closure.

Active at this checkpoint: normal repeat exec71631 (H/hop-repeat), runtime
exec16183 (H/hop-runtime, observer H/hop-observed.json.gz). Do NOT duplicate.
Runtime replays original/corrected735/candidate736 on existing multi-hop cases,
observes real ELF load hashes, all signatures and full account snapshots.
Results not yet known; do not claim pass before independent audit.
Next finish/audit, refresh direct source overlap, prepare source-recovery packet,
Draft PR, attach it, check exact head. No PR for this gain yet.

## Failed source experiments, retained and excluded

Read prior7fee-selection failures and compressed archives before experiments.
select_and_apply0x13458 remains unmatched. New cpi-parts helper moves actual
AccountInfo parts, returning Fees before override:2344B,735/159. Qualified IR
restores common low payload load and removes184Bcopy but changes stack/lifetime.
cpi-tail returns CPI Return before get/global flag:2280B,735/159. No gains.
Stop this lane rather than repeating context expressions.

New hop0x44ab0 (original536B) trials on corrected baseline:
- hop-mask: wrapping_neg masks480B,735/159; qualified IR differs from original
  packed bool behavior. Strip227f09972d7c6f9b5b12c30a4372ffd5a2362714f0813ffbb54aeed90c4542f7.
- hop-mask-if: MAX/0 masks528B,735/159; wrong negate/extend code.
- hop-borrow: borrow ? temporary544B,735/159; eagerly reads both error fields.
- hop-gates: generator missed compressed `)?;`, compileE0425; no artifact.
- hop-gates-copy: generator fixed, direct Copy local optimizes away; whole ELF
  exactly baseline d7eb57fc..., no gain. Do not retry direct gate copy.
- hop-apply: pure gate helper takes fees by value552B,735/159; creates correct
  packed gates/masks but early payload reads plus one spill remain.
- hop-apply-ref: coordinate-budget assertion before build, no artifact.
- hop-apply-ref2: pure helper takes borrowed Ok payload536B,735/159; original
  control flow and mask operations,24positional instruction differences remain.
  Strip efe367da57efd96114434e892671d103bcd080ad8fb8663fb2b9a64545a62bb6.
- hop-gate-first: borrow Ok then evaluate gate receiver before copying fee arg;
  entire ELF identical to hop-apply-ref2, no gain.
- hop-lp-first: SUCCESS above, grounded by qualified backend experiment.

## Compiler evidence and diagnostic failures

IR baseline, hop-mask and hop-apply-ref2 each strip exactly to corresponding
normal source artifact. Separate diagnostic symbol hashes retained. Ref2 IR
loads i24 gates then tests bits256/65536/1. This is not vectorization; original
packed bool masks arise from aggregate transfer across the pure helper.
Do not repeat early speculative vectorization explanation as established fact.

hop-codegen-qualified2: same llc -O3 -mattr=+store-imm,+jmp-ext reproduces all67
normal ref2 instructions with only call operand masked. Reordering independent
IR gate blocks gives CLP24diff, CPL24, LCP0, LPC0, PCL24, PLC4. Modified IR
is diagnostic only; the separate normal Rust LCP build supplies the real gain.
Whole-module llc reports inherited admin_update_token_incentives stack warnings;
no diagnostic object was executed or substituted into a source build.
Earlier diagnostics retained: llvm-extract missing; broad numeric renaming
accidentally touched an unrelated constant (parser rejected); objdump symbol
filter cut off local error labels (qualification rejected). Final qualified2
uses named locals only within target and complete symbol-sized disassembly.

Commands/controllers, exact normal launch.json/build.log/result.json, failed
source copies, qualifiedIR/MIR and all measurements remain in A/H. No original
or sealed evidence was changed. No runtime run was performed for failed source
candidates, and none was submitted as a new recovery.
