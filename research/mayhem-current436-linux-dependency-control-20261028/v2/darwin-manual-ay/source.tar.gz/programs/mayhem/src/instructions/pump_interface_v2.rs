use anchor_lang::prelude::*;
use crate::MayhemError;
use super::sell_v2::SellV2;
use super::sell::SellEvent;
use super::buy::BuyError;
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
use super::buy_v2::BuyV2;
#[inline(always)] fn inline_buy_cpi_info<'info>(info:&AccountInfo<'info>)->AccountInfo<'info>{info.clone()}















































































































































































































































































































































pub fn buy_v2_handler(ctx:Context<BuyV2>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;
 a.mayhem_state.validate_trade(&a.global_params)?;





 a.mayhem_state.validate_quote(a.bonding_curve.real_sol_reserves,&a.global_params,&a.quote_mint.key())?;




 let c=&a.bonding_curve;

 let price_check:std::result::Result<(),MayhemError> = (|| {
 let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;let Some(price)=(vs*1_000_000_000_000_000u128).checked_div(vt) else {return Err(MayhemError::MathOverflow)};
 let Some(scaled)=reference.checked_mul(tolerance_bps as u128) else {return Err(MayhemError::MathOverflow)};
 let delta=scaled/10_000;
 let Some(low)=reference.checked_sub(delta) else {return Err(MayhemError::MathOverflow)};
 let Some(high)=reference.checked_add(delta) else {return Err(MayhemError::MathOverflow)};
 if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);}
 Ok(())
 })();price_check?;let vt=c.virtual_token_reserves as u128;let retained=crate::state::retained_basis_points(retained_reserve_bps);

 let tokens=a.mayhem_base_token_vault.amount as u128;let quote_mint=a.quote_mint.key();let output=crate::state::raw_trade_output(vt,c,tokens);
 let native_accounting=quote_mint==Pubkey::default()||quote_mint==WSOL;
 let cap=if native_accounting{&a.global_params.field_2}else{&a.global_params.field_11};
 let mut output=output;if *cap!=0{output=output.min(*cap);}let max=(c.real_sol_reserves as u128*retained as u128/10_000)as u64;let output=output.min(max);let input=crate::state::buy_input(vt,c,output);let native=a.quote_mint.key()==WSOL;
 let before_sol=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};let before_tokens=a.mayhem_base_token_vault.amount;


 crate::pump_v2::buy_v2_recovered(CpiContext::new_with_signer(a.pump_program.key(),crate::pump_v2::BuyV2Accounts{global:inline_buy_cpi_info(a.global.as_ref()),mint:inline_buy_cpi_info(a.mint.as_ref().as_ref()),quote_mint:inline_buy_cpi_info(a.quote_mint.as_ref()),token_program:inline_buy_cpi_info(a.token_program.as_ref()),quote_token_program:inline_buy_cpi_info(a.quote_token_program.as_ref()),associated_token_program:inline_buy_cpi_info(a.associated_token_program.as_ref()),fee_recipient:inline_buy_cpi_info(a.fee_recipient.as_ref()),fee_recipient_ata:inline_buy_cpi_info(a.fee_recipient_ata.as_ref()),buyback_recipient:inline_buy_cpi_info(a.buyback_recipient.as_ref()),buyback_recipient_ata:inline_buy_cpi_info(a.buyback_recipient_ata.as_ref()),bonding_curve:inline_buy_cpi_info(a.bonding_curve.as_ref().as_ref()),associated_bonding_curve:inline_buy_cpi_info(a.associated_base_bonding_curve.as_ref().as_ref()),associated_quote_bonding_curve:inline_buy_cpi_info(a.associated_quote_bonding_curve.as_ref()),user:inline_buy_cpi_info(a.sol_vault.as_ref()),associated_user:inline_buy_cpi_info(a.mayhem_base_token_vault.as_ref().as_ref()),associated_quote_user:inline_buy_cpi_info(a.mayhem_quote_token_vault.as_ref().as_ref()),creator_vault:inline_buy_cpi_info(a.creator_vault.as_ref()),associated_creator_vault:inline_buy_cpi_info(a.associated_creator_vault.as_ref()),sharing_config:inline_buy_cpi_info(a.sharing_config.as_ref()),global_volume_accumulator:inline_buy_cpi_info(a.global_volume_accumulator.as_ref()),user_volume_accumulator:inline_buy_cpi_info(a.user_volume_accumulator.as_ref()),associated_user_volume_accumulator:inline_buy_cpi_info(a.associated_user_volume_accumulator.as_ref()),fee_config:inline_buy_cpi_info(a.fee_config.as_ref()),fee_program:inline_buy_cpi_info(a.fee_program.as_ref()),system_program:inline_buy_cpi_info(a.system_program.as_ref()),event_authority:inline_buy_cpi_info(a.pump_event_authority.as_ref()),program:inline_buy_cpi_info(a.pump_program.as_ref())},&[&[b"sol-vault".as_ref(), &[ctx.bumps.sol_vault]]]),input,output,false).map_err(|_|error!(BuyError::PumpCpiFailed))?;



 a.mayhem_base_token_vault.reload()?;a.bonding_curve.reload()?;if !native{a.mayhem_quote_token_vault.reload()?;}
 let after_quote=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};











    let sol=            before_sol-after_quote;
    let tokens=          a.mayhem_base_token_vault.amount-before_tokens;
 crate::state::record_amm_buy(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&a.quote_mint.key())?;







 let event={  let (quote_vault_balance,global_quote_deployed,state_quote_deployed,real_quote,virtual_quote)=if native {let vault=a.sol_vault.lamports();let global=a.global_params.sol_deployed;let state=a.mayhem_state.field_56;let real=a.bonding_curve.real_sol_reserves;let virtual_reserve=a.bonding_curve.virtual_sol_reserves;(vault,global,state,real,virtual_reserve)}else{let global=if native_accounting{a.global_params.sol_deployed}else{a.global_params.stable_deployed};let vault=a.mayhem_quote_token_vault.amount;let state=a.mayhem_state.field_56;let real=a.bonding_curve.real_sol_reserves;let virtual_reserve=a.bonding_curve.virtual_sol_reserves;(vault,global,state,real,virtual_reserve)};  let quote_mint=if native{Pubkey::default()}else{a.quote_mint.key()};let sol_amount=if native{sol}else{0};let sol_vault_balance=if native{quote_vault_balance}else{0};let global_sol_deployed=if native{global_quote_deployed}else{0};let state_sol_deployed=if native{state_quote_deployed}else{0};let virtual_sol=if native{virtual_quote}else{0};let real_sol=if native{real_quote}else{0};  let sol_vault=a.sol_vault.key();let mint=a.mint.key();let token_vault_balance=a.mayhem_base_token_vault.amount;let state_token_net=a.mayhem_state.field_72;let end_timestamp=a.mayhem_state.end_timestamp;let virtual_tokens=a.bonding_curve.virtual_token_reserves;let timestamp=Clock::get()?.unix_timestamp;let real_tokens=a.bonding_curve.real_token_reserves;let version=a.global_params.version;  SellEvent{quote_mint,sol_vault,side:false,sol_amount,token_amount:tokens,sol_vault_balance,token_vault_balance,virtual_tokens,timestamp,end_timestamp,virtual_sol,real_sol,real_tokens,retained_reserve_bps,version,global_sol_deployed,state_token_net,state_sol_deployed,mint,global_quote_deployed,state_quote_deployed,real_quote,virtual_quote,quote_vault_balance,quote_amount:sol}};







 emit!(event);emit_cpi!(event);Ok(())
}



































































































































pub fn sell_v2_handler(ctx:Context<SellV2>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;
 a.mayhem_state.validate_trade(&a.global_params)?;





 a.mayhem_state.validate_quote(a.bonding_curve.real_sol_reserves,&a.global_params,&a.quote_mint.key())?;




 let c=&a.bonding_curve;

 let price_check:std::result::Result<(),MayhemError> = (|| {
 let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;let Some(price)=(vs*1_000_000_000_000_000u128).checked_div(vt) else {return Err(MayhemError::MathOverflow)};
 let Some(scaled)=reference.checked_mul(tolerance_bps as u128) else {return Err(MayhemError::MathOverflow)};
 let delta=scaled/10_000;
 let Some(low)=reference.checked_sub(delta) else {return Err(MayhemError::MathOverflow)};
 let Some(high)=reference.checked_add(delta) else {return Err(MayhemError::MathOverflow)};
 if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);}
 Ok(())
 })();price_check?;
 let native_accounting=a.quote_mint.key()==Pubkey::default()||a.quote_mint.key()==WSOL;let cap=if native_accounting{&a.global_params.field_2}else{&a.global_params.field_11};
 let (input,minimum)=crate::state::sell_amounts(c.virtual_token_reserves,c,cap,a.mayhem_base_token_vault.amount,retained_reserve_bps);
 let native=a.quote_mint.key()==WSOL;
 let before_sol=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};let before_tokens=a.mayhem_base_token_vault.amount;


 crate::pump_v2::cpi::sell_v2(CpiContext::new_with_signer(a.pump_program.key(),crate::pump_v2::cpi::accounts::SellV2{global:inline_cpi_info(a.global.as_ref()),mint:inline_cpi_info(a.mint.as_ref().as_ref()),quote_mint:inline_cpi_info(a.quote_mint.as_ref()),token_program:inline_cpi_info(a.token_program.as_ref()),quote_token_program:inline_cpi_info(a.quote_token_program.as_ref()),associated_token_program:inline_cpi_info(a.associated_token_program.as_ref()),fee_recipient:inline_cpi_info(a.fee_recipient.as_ref()),fee_recipient_ata:inline_cpi_info(a.fee_recipient_ata.as_ref()),buyback_recipient:inline_cpi_info(a.buyback_recipient.as_ref()),buyback_recipient_ata:inline_cpi_info(a.buyback_recipient_ata.as_ref()),bonding_curve:inline_cpi_info(a.bonding_curve.as_ref().as_ref()),associated_bonding_curve:inline_cpi_info(a.associated_base_bonding_curve.as_ref().as_ref()),associated_quote_bonding_curve:inline_cpi_info(a.associated_quote_bonding_curve.as_ref()),user:inline_cpi_info(a.sol_vault.as_ref()),associated_user:inline_cpi_info(a.mayhem_base_token_vault.as_ref().as_ref()),associated_quote_user:inline_cpi_info(a.mayhem_quote_token_vault.as_ref().as_ref()),creator_vault:inline_cpi_info(a.creator_vault.as_ref()),associated_creator_vault:inline_cpi_info(a.associated_creator_vault.as_ref()),sharing_config:inline_cpi_info(a.sharing_config.as_ref()),user_volume_accumulator:inline_cpi_info(a.user_volume_accumulator.as_ref()),associated_user_volume_accumulator:inline_cpi_info(a.associated_user_volume_accumulator.as_ref()),fee_config:inline_cpi_info(a.fee_config.as_ref()),fee_program:inline_cpi_info(a.fee_program.as_ref()),system_program:inline_cpi_info(a.system_program.as_ref()),event_authority:inline_cpi_info(a.pump_event_authority.as_ref()),program:inline_cpi_info(a.pump_program.as_ref())},&[&[b"sol-vault",&[ctx.bumps.sol_vault]]]),input,minimum).map_err(|_|error!(BuyError::PumpCpiFailed))?;




 a.mayhem_base_token_vault.reload()?;a.bonding_curve.reload()?;if !native{a.mayhem_quote_token_vault.reload()?;}
 let after_quote=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};










    let sol=            after_quote-before_sol;
    let tokens=          before_tokens-a.mayhem_base_token_vault.amount;
 crate::state::record_sell(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&a.quote_mint.key())?;
 let event={ let (quote_vault_balance,global_quote_deployed,state_quote_deployed,real_quote,virtual_quote)=if native {let vault=a.sol_vault.lamports();let global=a.global_params.sol_deployed;let state=a.mayhem_state.field_56;let real=a.bonding_curve.real_sol_reserves;let virtual_reserve=a.bonding_curve.virtual_sol_reserves;(vault,global,state,real,virtual_reserve)}else{let global=if native_accounting{a.global_params.sol_deployed}else{a.global_params.stable_deployed};let vault=a.mayhem_quote_token_vault.amount;let state=a.mayhem_state.field_56;let real=a.bonding_curve.real_sol_reserves;let virtual_reserve=a.bonding_curve.virtual_sol_reserves;(vault,global,state,real,virtual_reserve)}; let quote_mint=if native{Pubkey::default()}else{a.quote_mint.key()};let sol_amount=if native{sol}else{0};let sol_vault_balance=if native{quote_vault_balance}else{0};let global_sol_deployed=if native{global_quote_deployed}else{0};let state_sol_deployed=if native{state_quote_deployed}else{0};let virtual_sol=if native{virtual_quote}else{0};let real_sol=if native{real_quote}else{0}; let sol_vault=a.sol_vault.key();let mint=a.mint.key();let token_vault_balance=a.mayhem_base_token_vault.amount;let state_token_net=a.mayhem_state.field_72;let end_timestamp=a.mayhem_state.end_timestamp;let virtual_tokens=a.bonding_curve.virtual_token_reserves;let timestamp=Clock::get()?.unix_timestamp;let version=a.global_params.version;let real_tokens=a.bonding_curve.real_token_reserves; SellEvent{quote_mint,sol_vault,side:true,sol_amount,token_amount:tokens,sol_vault_balance,token_vault_balance,virtual_tokens,timestamp,end_timestamp,virtual_sol,real_sol,real_tokens,retained_reserve_bps,version,global_sol_deployed,state_token_net,state_sol_deployed,mint,global_quote_deployed,state_quote_deployed,real_quote,virtual_quote,quote_vault_balance,quote_amount:sol}};







 emit!(event);emit_cpi!(event);Ok(())
}
#[inline(always)]
fn inline_cpi_info<'info>(info:&AccountInfo<'info>)->AccountInfo<'info>{AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}}
