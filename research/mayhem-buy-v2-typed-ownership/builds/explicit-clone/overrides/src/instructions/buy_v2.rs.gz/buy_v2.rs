//! BuyV2 recovered from wrapper 0x81a78, parser 0x5c6d8 and handler 0x224e0.
use anchor_lang::prelude::*;
use anchor_lang::solana_program::{instruction::Instruction,program::invoke_signed};
use anchor_spl::token_interface::{Mint,TokenAccount,TokenInterface};
use anchor_spl::token_2022::Token2022;
use crate::{GlobalParams,MayhemError};
use crate::state::{MayhemState,MayhemStatus,PUMP_ID};
use crate::checked_program::{CheckedSystemProgram,CheckedSystemProgramBumps,__client_accounts_checked_system_program,__cpi_client_accounts_checked_system_program};

use anchor_spl::associated_token::AssociatedToken;
use super::sell::{SellCurve,SellEvent,SellError};
use super::buy::BuyError;
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
#[derive(Accounts)]
pub struct BuyV2<'info> {
 #[account(mut)]pub trader:Signer<'info>,
 #[account(mut,seeds=[b"global-params"],bump,has_one=trader)]pub global_params:Box<Account<'info,GlobalParams>>,
 #[account(mut,seeds=[b"mayhem-state",mint.key().as_ref()],bump)]pub mayhem_state:Box<Account<'info,MayhemState>>,
 pub mint:Box<InterfaceAccount<'info,Mint>>,
 /// CHECK: Original unchecked quote account; ATA owner and Pump CPI constrain its use.
 pub quote_mint:UncheckedAccount<'info>,
 pub associated_token_program:Program<'info,AssociatedToken>,
 #[account(mut,associated_token::mint=mint,associated_token::authority=sol_vault,associated_token::token_program=mint.to_account_info().owner)]pub mayhem_base_token_vault:Box<InterfaceAccount<'info,TokenAccount>>,
 #[account(mut,associated_token::mint=quote_mint,associated_token::authority=sol_vault,associated_token::token_program=quote_mint.to_account_info().owner)]pub mayhem_quote_token_vault:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: Original writable PDA.
 #[account(mut,seeds=[b"sol-vault"],bump)]pub sol_vault:UncheckedAccount<'info>,
 pub system_program:Program<'info,System>,
 pub token_program:Program<'info,Token2022>,
 pub quote_token_program:Interface<'info,TokenInterface>,
 /// CHECK: Passed through to Pump.
 pub global:UncheckedAccount<'info>,
 #[account(mut,seeds=[b"bonding-curve",mint.key().as_ref()],bump,seeds::program=PUMP_ID)]pub bonding_curve:Box<Account<'info,SellCurve>>,
 /// CHECK: Pump validates quote ATA.
 #[account(mut)]pub associated_quote_bonding_curve:UncheckedAccount<'info>,
 /// CHECK: Pump validates recipient membership.
 #[account(mut)]pub fee_recipient:UncheckedAccount<'info>,
 /// CHECK: Pump validates recipient ATA.
 #[account(mut)]pub fee_recipient_ata:UncheckedAccount<'info>,
 #[account(mut,associated_token::mint=mint,associated_token::authority=bonding_curve,associated_token::token_program=mint.to_account_info().owner)]pub associated_base_bonding_curve:Box<InterfaceAccount<'info,TokenAccount>>,
 /// CHECK: Pump validates creator PDA.
 #[account(mut)]pub creator_vault:UncheckedAccount<'info>,
 /// CHECK: Pump validates creator ATA.
 #[account(mut)]pub associated_creator_vault:UncheckedAccount<'info>,
 /// CHECK: Pump validates sharing config.
 pub sharing_config:UncheckedAccount<'info>,
 /// CHECK: Pump event authority.
 pub pump_event_authority:UncheckedAccount<'info>,
 /// CHECK: Original fixed address.
 #[account(address=PUMP_ID)]pub pump_program:UncheckedAccount<'info>,
 /// CHECK: Original unchecked read-only global volume account passed through to Pump.
 pub global_volume_accumulator:UncheckedAccount<'info>,
 /// CHECK: Pump validates volume PDA.
 #[account(mut)]pub user_volume_accumulator:UncheckedAccount<'info>,
 /// CHECK: Pump validates volume ATA.
 #[account(mut)]pub associated_user_volume_accumulator:UncheckedAccount<'info>,
 /// CHECK: Pump validates fee config.
 pub fee_config:UncheckedAccount<'info>,
 /// CHECK: Pump validates fee program.
 pub fee_program:UncheckedAccount<'info>,
 /// CHECK: Original event PDA.
 #[account(seeds=[b"__event_authority"],bump)]pub event_authority:UncheckedAccount<'info>,
 pub program:Program<'info,crate::program::MayhemRecovered>,
 /// CHECK: Pump validates buyback recipient.
 #[account(mut)]pub buyback_recipient:UncheckedAccount<'info>,
 /// CHECK: Pump validates buyback ATA.
 #[account(mut)]pub buyback_recipient_ata:UncheckedAccount<'info>,
}
fn math()->Error {MayhemError::MathOverflow.into()}
pub fn handler(ctx:Context<BuyV2>,reference:u128,tolerance_bps:u16,retained_reserve_bps:u16)->Result<()> {
 let a=&mut *ctx.accounts;
 let native=a.quote_mint.key()==WSOL;
 let native_accounting=native||a.quote_mint.key()==Pubkey::default();
 a.mayhem_state.validate_trade(&a.global_params)?;





 a.mayhem_state.validate_quote(a.bonding_curve.real_sol_reserves,&a.global_params,&a.quote_mint.key())?;




 let c=&a.bonding_curve;
 let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;
 if vt==0{return Err(math());}
 let scaled=reference.checked_mul(tolerance_bps as u128).ok_or_else(math)?;
 let price=vs*1_000_000_000_000_000u128/vt;let delta=scaled/10_000;
 let low=reference.checked_sub(delta).ok_or_else(math)?;let high=reference.checked_add(delta).ok_or_else(math)?;
 if price<low||price>high{return Err(SellError::PumpCpiSlippage.into());}
 let retained=crate::state::retained_basis_points(retained_reserve_bps);
 let cap=if native_accounting{a.global_params.field_2}else{a.global_params.field_11};
 let (input,output)=crate::state::buy_amounts(vt,vs,c.real_sol_reserves,c.real_token_reserves,a.mayhem_base_token_vault.amount as u128,cap,retained);




 let before_sol=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};let before_tokens=a.mayhem_base_token_vault.amount;
 let accounts=crate::pump_v2::BuyV2Accounts{global:{let info:&AccountInfo<'_>=a.global.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},mint:{let info:&AccountInfo<'_>=a.mint.as_ref().as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},quote_mint:{let info:&AccountInfo<'_>=a.quote_mint.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},token_program:{let info:&AccountInfo<'_>=a.token_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},quote_token_program:{let info:&AccountInfo<'_>=a.quote_token_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_token_program:{let info:&AccountInfo<'_>=a.associated_token_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},fee_recipient:{let info:&AccountInfo<'_>=a.fee_recipient.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},fee_recipient_ata:{let info:&AccountInfo<'_>=a.fee_recipient_ata.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},buyback_recipient:{let info:&AccountInfo<'_>=a.buyback_recipient.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},buyback_recipient_ata:{let info:&AccountInfo<'_>=a.buyback_recipient_ata.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},bonding_curve:{let info:&AccountInfo<'_>=a.bonding_curve.as_ref().as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_bonding_curve:{let info:&AccountInfo<'_>=a.associated_base_bonding_curve.as_ref().as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_quote_bonding_curve:{let info:&AccountInfo<'_>=a.associated_quote_bonding_curve.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},user:{let info:&AccountInfo<'_>=a.sol_vault.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_user:{let info:&AccountInfo<'_>=a.mayhem_base_token_vault.as_ref().as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_quote_user:{let info:&AccountInfo<'_>=a.mayhem_quote_token_vault.as_ref().as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},creator_vault:{let info:&AccountInfo<'_>=a.creator_vault.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_creator_vault:{let info:&AccountInfo<'_>=a.associated_creator_vault.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},sharing_config:{let info:&AccountInfo<'_>=a.sharing_config.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},global_volume_accumulator:{let info:&AccountInfo<'_>=a.global_volume_accumulator.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},user_volume_accumulator:{let info:&AccountInfo<'_>=a.user_volume_accumulator.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},associated_user_volume_accumulator:{let info:&AccountInfo<'_>=a.associated_user_volume_accumulator.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},fee_config:{let info:&AccountInfo<'_>=a.fee_config.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},fee_program:{let info:&AccountInfo<'_>=a.fee_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},system_program:{let info:&AccountInfo<'_>=a.system_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},event_authority:{let info:&AccountInfo<'_>=a.pump_event_authority.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}},program:{let info:&AccountInfo<'_>=a.pump_program.as_ref();AccountInfo{key:info.key,lamports:std::rc::Rc::clone(&info.lamports),data:std::rc::Rc::clone(&info.data),owner:info.owner,_unused:info._unused,is_signer:info.is_signer,is_writable:info.is_writable,executable:info.executable}}};
 let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];
 require!(crate::pump_v2::buy_v2_recovered(CpiContext::new_with_signer(a.pump_program.key(),accounts,&[seeds]),input,output,false).is_ok(),BuyError::PumpCpiFailed);



 a.mayhem_base_token_vault.reload()?;a.bonding_curve.reload()?;if !native{a.mayhem_quote_token_vault.reload()?;}
 let after_quote=if native{a.sol_vault.lamports()}else{a.mayhem_quote_token_vault.amount};
 let sol=before_sol-after_quote;let tokens=a.mayhem_base_token_vault.amount-before_tokens;
 crate::state::record_amm_buy(&mut a.global_params,&mut a.mayhem_state,sol,tokens,&a.quote_mint.key())?;







 let event=SellEvent{side:0,sol_vault:a.sol_vault.key(),mint:a.mint.key(),sol_amount:if native{sol}else{0},token_amount:tokens,sol_vault_balance:if native{a.sol_vault.lamports()}else{0},token_vault_balance:a.mayhem_base_token_vault.amount,state_sol_deployed:if native{a.mayhem_state.field_56}else{0},state_token_net:a.mayhem_state.field_72,virtual_sol:if native{a.bonding_curve.virtual_sol_reserves}else{0},virtual_tokens:a.bonding_curve.virtual_token_reserves,global_sol_deployed:if native{a.global_params.sol_deployed}else{0},timestamp:Clock::get()?.unix_timestamp,end_timestamp:a.mayhem_state.end_timestamp,real_sol:if native{a.bonding_curve.real_sol_reserves}else{0},real_tokens:a.bonding_curve.real_token_reserves,version:a.global_params.version,retained_reserve_bps,quote_amount:sol,quote_vault_balance:after_quote,state_quote_deployed:a.mayhem_state.field_56,virtual_quote:a.bonding_curve.virtual_sol_reserves,global_quote_deployed:if native_accounting{a.global_params.sol_deployed}else{a.global_params.stable_deployed},real_quote:a.bonding_curve.real_sol_reserves,quote_mint:if native{Pubkey::default()}else{a.quote_mint.key()}};
 emit!(event);emit_cpi!(event);Ok(())
}

