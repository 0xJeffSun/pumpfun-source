from pathlib import Path
import sys,json,gzip,hashlib
ROOT=Path('/Users/shawwalters/.codex/worktrees/relay-canonical-exact/pumpfun-source');sys.path.insert(0,str(ROOT/'scripts'))
import fees_social_claim_v2_differential as f
R=Path(__file__).resolve().parent
bins={'original':ROOT/'evidence/original/pump_fees/deployed.so','control':R.parent/'next581/social-unlikely-safe-candidate.so','proposal':R/'social-v2-public-union-candidate.so'}
cases=[]
for quote in [f.WSOL,f.USDC]:
 for time in [-1,-2,1700000000]:
  for last in [0,1,1700000000,2**64-2,2**64-1]:
   for rate in [0,1,2**64-1]:cases.append(dict(name=f'rate-{quote}-{time}-{last}-{rate}',quote=str(quote),time=time,last=last,rate=rate))
 for amount in [0,1]:
  for source in [False,True]:cases.append(dict(name=f'executable-{quote}-{amount}-{source}',quote=str(quote),recipient_kind='program',native=amount,tokens=amount,source_exists=source))
fields=['error','before','after','events','inner','return','transaction_base64']
app=lambda x:[s for s in x['logs']if s.startswith(('Program log:','Program data:','Program return:'))]
rows=[]
for c in cases:
 v={k:f.run(c,p)for k,p in bins.items()};diff={k:[n for n in fields if v[k][n]!=v['original'][n]]for k in ['control','proposal']};log={k:app(v[k])!=app(v['original'])for k in ['control','proposal']};rows.append(dict(case=c,results=v,differences=diff,log_differences=log))
report=dict(case_count=len(rows),fields=fields,hashes={k:hashlib.sha256(p.read_bytes()).hexdigest()for k,p in bins.items()},cases=rows,mismatches={k:[x['case']['name']for x in rows if x['differences'][k]or x['log_differences'][k]]for k in ['control','proposal']})
(R/'admission-boundary.json.gz').write_bytes(gzip.compress(json.dumps(report).encode(),mtime=0));print(json.dumps(dict(cases=len(rows),semantic_mismatches={k:sum(bool(x['differences'][k])for x in rows)for k in ['control','proposal']},application_log_mismatches={k:sum(x['log_differences'][k]for x in rows)for k in ['control','proposal']})))
assert not report['mismatches']['proposal']
