from pathlib import Path
import gzip,importlib.util,json
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source';P.mkdir(exist_ok=True)
Q=W/'pumpfun-source/research/mayhem-allocator-context'
s=importlib.util.spec_from_file_location('context',Q/'verify.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
for name in ('original','parent'):(P/(name+'.so')).write_bytes(q.raw(Q/'reference'/(name+'.so.gz')))
o,c=q.layer.Elf(P/'original.so'),q.layer.Elf(P/'parent.so')
rows=q.read(Q/'reference/prior-inventory.json.gz')['original_rows'];ow={r['id']:o.window(r['start'],r['end'])for r in rows};cw=q.v.functions(c)
maps=q.map_sections(q.raw(Q/'reference/parent.map.gz'),664384);owners={a:(owner,section)for a,n,owner,section in maps}
out={}
for key in ('O0209','O0210','O0237'):
    addr=ow[key]['start'];callers=[]
    for k,w in ow.items():
        calls=[d for d in w['direct']if d['target']==addr]
        if not calls:continue
        counterparts=[dict(start=a,owner=owners[a][0],symbol=owners[a][1])for(a,b),x in cw.items()if q.v.shape(w)==q.v.shape(x)]
        callers.append(dict(id=k,start=w['start'],bytes=w['end']-w['start'],calls=calls,counterparts=counterparts))
    out[key]=dict(start=addr,callers=callers)
for a,n,owner,section in maps:
    if 'AccountWrapper'in section and 'deserialize'in section or 'SellCurve'in section and 'deserialize'in section:
        w=cw[(a,a+n)];matches=[k for k,x in ow.items()if q.v.shape(w)==q.v.shape(x)]
        out[section]=dict(start=a,bytes=n,owner=owner,originals=matches,direct=w['direct'])
(P/'source-relationships.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8',newline='\n')
for key,r in out.items():
    if key.startswith('O'):print(key,json.dumps(r))
    else:print(key,{k:v for k,v in r.items()if k!='direct'})
