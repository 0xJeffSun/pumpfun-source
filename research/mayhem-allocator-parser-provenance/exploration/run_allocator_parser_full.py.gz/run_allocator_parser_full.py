from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,sys
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source';OLD=W/'mayhem-qualified-native'
for variant,source_label,labels in [('gated','parser-create-gated',['full-parser-gated']),('enabled','parser-create',['full-parser-01','full-parser-02'])]:
    C=P/('controller-'+variant);C.mkdir(exist_ok=False)
    for name in ('build.py','wrapper.rs','linker.rs','metadata-map.tsv','path-map.tsv','ordered-native.ld','default.ld','host-tools.json','vendor-inputs.json','sdk-components.json.gz','target-components.json','source-inputs.json'):
        shutil.copyfile(OLD/name,C/name)
    shutil.copytree(OLD/'sources',C/'sources')
    inputs=json.loads((C/'source-inputs.json').read_bytes())
    for row in inputs['source_files']:
        if row['path']in('curve-accounts/src/lib.rs','curve-accounts/idls/pump.json'):
            data=(P/source_label/'source'/row['path']).read_bytes();(C/'sources'/(row['path']+'.gz')).write_bytes(gzip.compress(data,mtime=0));row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    inputs['scope']='Historical Anchor event-parser template plus current public CreateEvent definition; controlled sufficient context, not original-source attribution.'
    (C/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8',newline='\n')
    for label in labels:
        cmd=[sys.executable,'-I','-B',str(C/'build.py'),'--sdk',str(W/'mayhem-native-build/sdk'),'--target-sysroot',str(W/'windows-typeid-probe/linux-sysroot/rust'),'--vendor',str(W/'mayhem-native-build/vendor'),'--msvc','C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207','--windows-sdk','C:/Program Files (x86)/Windows Kits/10','--output',str(P/label)]
        with(P/(label+'.stdout.log')).open('wb')as out,(P/(label+'.stderr.log')).open('wb')as err:r=subprocess.run(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        print(label,r.returncode,flush=True);r.check_returncode();print(json.loads((P/label/'result.json').read_bytes())['outputs'],flush=True)
