from pathlib import Path
import hashlib,json,shutil,subprocess
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source'
captured=(P/'captured-pump.json').read_bytes();receipt=json.loads((P/'public-idl-origin.json').read_bytes())
assert hashlib.sha1(b'blob '+str(len(captured)).encode()+b'\0'+captured).hexdigest()==receipt['git_blob']
tool=(P/'public-pump.json').read_bytes();assert tool==captured+b'\n'
shutil.copyfile(P/'public-pump.json',P/'public-pump-tool-newline.json');(P/'public-pump.json').write_bytes(captured)
full=json.loads(captured)
prior=json.loads((W/'mayhem-specialization-provenance/curve_accounts-corrected/launch.json').read_bytes())
source=Path(prior['cwd']);small=json.loads((source/'curve-accounts/idls/pump.json').read_bytes())
def serialize(d):return(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
all_sections=dict(small,**{k:full[k]for k in ('accounts','events','errors','types')})
events=dict(small,events=full['events'],types=full['types'])
create=dict(small,events=[e for e in full['events']if e['name']=='CreateEvent'],types=[t for t in full['types']if t['name']=='CreateEvent'])
variants={'public-full':captured,'public-sections':serialize(all_sections),'public-events':serialize(events),'public-create-event':serialize(create)}
for name,data in variants.items():
    out=P/name;out.mkdir(exist_ok=False);shutil.copytree(source,out/'source')
    (out/'source/curve-accounts/idls/pump.json').write_bytes(data)
    args=list(prior['command']);args[args.index('--out-dir')+1]=str(out)
    env=dict(prior['environment'],CARGO_MANIFEST_DIR=str(out/'source/curve-accounts'),CARGO_MANIFEST_PATH=str(out/'source/curve-accounts/Cargo.toml'))
    launch=dict(command=args,cwd=str(out/'source'),environment=env,idl=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()),target_executions=0)
    (out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n',encoding='utf8',newline='\n')
    with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:r=subprocess.run(args,cwd=launch['cwd'],env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    identity=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (out/'result.json').write_text(json.dumps(dict(returncode=r.returncode,outputs={p.name:identity(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta')}),indent=2)+'\n',encoding='utf8',newline='\n')
    print(name,r.returncode,flush=True)
