from pathlib import Path
import importlib.util,json,tempfile
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source';Q=W/'pumpfun-source/research/mayhem-allocator-context'
s=importlib.util.spec_from_file_location('context',Q/'verify.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
out={}
with tempfile.TemporaryDirectory()as td:
    td=Path(td);(td/'original.so').write_bytes(q.raw(Q/'reference/original.so.gz'));o=q.layer.Elf(td/'original.so')
    rows=q.read(Q/'reference/prior-inventory.json.gz')['original_rows'];ow={r['id']:o.window(r['start'],r['end'])for r in rows}
    for label,ref in [('full-parser-gated','reference/parent.so.gz'),('full-parser-01','builds/full-zeroed-01/symbols.so.gz'),('full-parser-02','builds/full-zeroed-01/symbols.so.gz')]:
        b=q.raw(Q/ref);(td/'ref.so').write_bytes(b);r=q.layer.Elf(td/'ref.so');e=q.layer.Elf(P/label/'symbols.so');inv=q.inventory(e,ow)
        changes={}
        for name,h in r.sec.items():
            hh=e.sec.get(name)
            if not hh:changes[name]='missing';continue
            a=r.b[h['offset']:h['offset']+h['size']];bb=e.b[hh['offset']:hh['offset']+hh['size']]
            if a!=bb:changes[name]=dict(before=len(a),after=len(bb),overlap=sum(x!=y for x,y in zip(a,bb)))
        diff=[i for i,(a,b)in enumerate(zip(r.b,e.b))if a!=b]
        strtab=e.sec['.strtab'];only_strings=len(r.b)==len(e.b)and all(strtab['offset']<=i<strtab['offset']+strtab['size']for i in diff)
        out[label]=dict(raw=q.identity(e.b),inventory={k:v for k,v in inv.items()if k!='matches'},section_changes=changes,raw_changed_bytes=len(diff),only_strtab=only_strings)
        print(label,'inventory',{k:inv[k]for k in('normalized','raw_local','injective')},'sections',changes,'only_strtab',only_strings,'diffbytes',len(diff))
(P/'full-comparison.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8',newline='\n')
