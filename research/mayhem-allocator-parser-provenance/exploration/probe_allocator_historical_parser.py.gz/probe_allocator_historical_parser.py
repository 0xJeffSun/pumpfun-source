from pathlib import Path
import hashlib,json,re,shutil,subprocess
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source'
template=(P/'anchor-utils-before-gate.rs').read_text(encoding='utf8')
before=(P/'anchor-utils-before-gate.rs').read_bytes()
post=before.replace(b'        /// Program utilities.\n        pub mod utils {',b'        /// Program utilities.\n        #[cfg(not(target_os = "solana"))]\n        pub mod utils {')
receipt=json.loads((P/'anchor-gate-change.json').read_bytes());expected=receipt['files'][0]['sha']
assert hashlib.sha1(b'blob '+str(len(post)).encode()+b'\0'+post).hexdigest()==expected
block=template[template.index('fn gen_event('):template.index('fn gen_instruction(')]
statement=block.split('        quote! {\n',1)[1].split('        }\n    });',1)[0]
final=block.rsplit('    quote! {\n',1)[1];assert final.endswith('    }\n}\n\n');final=final[:-len('    }\n}\n\n')]
for label,parent,gated in [('parser-create','public-create-event',False),('parser-create-gated','public-create-event',True),('parser-events','public-events',False)]:
    old=P/parent;out=P/label;out.mkdir(exist_ok=False);shutil.copytree(old/'source',out/'source')
    idl=json.loads((out/'source/curve-accounts/idls/pump.json').read_bytes());names=[e['name']for e in idl['events']]
    assert all(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',n)for n in names)
    generated=final.replace('#(#variants,)*',','.join(n+'('+n+')'for n in names)+',').replace('#(#if_statements)*',''.join(statement.replace('#name',n)for n in names))
    addition='\n'+('#[cfg(not(target_os = "solana"))]\n'if gated else '')+'pub mod legacy_event_utils {\nuse anchor_lang::prelude::*;\nuse super::cpi_interface::pump::events::*;\n'+generated+'}\n'
    source=out/'source/curve-accounts/src/lib.rs';source.write_bytes(source.read_bytes()+addition.encode())
    (out/'generated.rs').write_text(addition,encoding='utf8',newline='\n')
    prior=json.loads((old/'launch.json').read_bytes());args=list(prior['command']);args[args.index('--out-dir')+1]=str(out)
    env=dict(prior['environment'],CARGO_MANIFEST_DIR=str(out/'source/curve-accounts'),CARGO_MANIFEST_PATH=str(out/'source/curve-accounts/Cargo.toml'))
    launch=dict(command=args,cwd=str(out/'source'),environment=env,source_files={p.relative_to(out/'source').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(out/'source').rglob('*')if p.is_file()},events=names,gated=gated,target_executions=0)
    (out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n',encoding='utf8',newline='\n')
    with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:r=subprocess.run(args,cwd=launch['cwd'],env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    identity=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (out/'result.json').write_text(json.dumps(dict(returncode=r.returncode,outputs={p.name:identity(p)for p in out.iterdir()if p.suffix in('.rlib','.rmeta')}),indent=2)+'\n',encoding='utf8',newline='\n')
    print(label,r.returncode,flush=True)
