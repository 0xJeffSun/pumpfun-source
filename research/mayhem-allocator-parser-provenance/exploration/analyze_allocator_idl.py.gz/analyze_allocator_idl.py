from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;P=W/'mayhem-allocator-source';Q=W/'pumpfun-source/research/mayhem-allocator-context'
s=importlib.util.spec_from_file_location('context',Q/'verify.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
ref=q.objects(q.raw(Q/'reference/curve_accounts.rlib.gz'));rs=q.text_sections(ref);report={}
for name in ('public-full','public-sections','public-events','public-create-event','parser-create','parser-create-gated','parser-events'):
    folder=P/name;result=json.loads((folder/'result.json').read_bytes())
    if result['returncode']:continue
    path=next(folder.glob('*.rlib'));ob=q.objects(path.read_bytes());(folder/'object.o').write_bytes(ob);ss=q.text_sections(ob)
    changed=[n for n in rs if n not in ss or rs[n]!=ss[n]]
    row=dict(object=q.identity(ob),finish=[dict(name=n,**q.identity(b))for n,b in ss.items()if 'finish_grow'in n],existing_text=len(rs),changed_text=changed,added_text=[n for n in ss if n not in rs],missing_text=[n for n in rs if n not in ss])
    report[name]=row;print(name,'finish',row['finish'],'changed',len(changed),'added',len(row['added_text']),'missing',len(row['missing_text']))
    print('changed_names',changed)
(P/'idl-analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n')
