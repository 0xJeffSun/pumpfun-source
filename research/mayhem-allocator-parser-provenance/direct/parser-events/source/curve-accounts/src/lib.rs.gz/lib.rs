include!("interface_definition.rs");






    recovered_interfaces!();






    recovered_pool!();

pub mod legacy_event_utils {
use anchor_lang::prelude::*;
use super::cpi_interface::pump::events::*;
        /// An enum that includes all events of the declared program as a tuple variant.
        ///
        /// See [`Self::try_from_bytes`] to create an instance from bytes.
        pub enum Event {
            AddQuoteControlMintEvent(AddQuoteControlMintEvent),AdminCtoEvent(AdminCtoEvent),AdminSetIdlAuthorityEvent(AdminSetIdlAuthorityEvent),AdminUpdateTokenIncentivesEvent(AdminUpdateTokenIncentivesEvent),ClaimCashbackEvent(ClaimCashbackEvent),ClaimTokenIncentivesEvent(ClaimTokenIncentivesEvent),CloseUserVolumeAccumulatorEvent(CloseUserVolumeAccumulatorEvent),CollectCreatorFeeEvent(CollectCreatorFeeEvent),CompleteEvent(CompleteEvent),CompletePumpAmmMigrationEvent(CompletePumpAmmMigrationEvent),CreateEvent(CreateEvent),DistributeCreatorFeesEvent(DistributeCreatorFeesEvent),DistributeFeeToHoldersEvent(DistributeFeeToHoldersEvent),ExtendAccountEvent(ExtendAccountEvent),InitUserVolumeAccumulatorEvent(InitUserVolumeAccumulatorEvent),MigrateBondingCurveCreatorEvent(MigrateBondingCurveCreatorEvent),MinimumDistributableFeeEvent(MinimumDistributableFeeEvent),PostCompleteBuyEvent(PostCompleteBuyEvent),RemoveQuoteControlMintEvent(RemoveQuoteControlMintEvent),ReservedFeeRecipientsEvent(ReservedFeeRecipientsEvent),SetCreatorEvent(SetCreatorEvent),SetMetaplexCreatorEvent(SetMetaplexCreatorEvent),SetParamsEvent(SetParamsEvent),SetQuoteControlAdminEvent(SetQuoteControlAdminEvent),SetQuoteControlMintReservesEvent(SetQuoteControlMintReservesEvent),SetQuoteControlReservesAdminEvent(SetQuoteControlReservesAdminEvent),SweepBondingCurveFeeEvent(SweepBondingCurveFeeEvent),SyncUserVolumeAccumulatorEvent(SyncUserVolumeAccumulatorEvent),TradeEvent(TradeEvent),UpdateCreatorFeeConfigEvent(UpdateCreatorFeeConfigEvent),UpdateGlobalAuthorityEvent(UpdateGlobalAuthorityEvent),UpdateMayhemVirtualParamsEvent(UpdateMayhemVirtualParamsEvent),
        }

        impl Event {
            /// Try to create an event based on the given bytes.
            ///
            /// This method returns an error if the discriminator of the given bytes don't match
            /// with any of the existing events, or if the deserialization fails.
            pub fn try_from_bytes(bytes: &[u8]) -> Result<Self> {
                Self::try_from(bytes)
            }
        }

        impl TryFrom<&[u8]> for Event {
            type Error = anchor_lang::error::Error;

            fn try_from(value: &[u8]) -> Result<Self> {
                            if value.starts_with(AddQuoteControlMintEvent::DISCRIMINATOR) {
                return AddQuoteControlMintEvent::try_from_slice(&value[AddQuoteControlMintEvent::DISCRIMINATOR.len()..])
                    .map(Self::AddQuoteControlMintEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(AdminCtoEvent::DISCRIMINATOR) {
                return AdminCtoEvent::try_from_slice(&value[AdminCtoEvent::DISCRIMINATOR.len()..])
                    .map(Self::AdminCtoEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(AdminSetIdlAuthorityEvent::DISCRIMINATOR) {
                return AdminSetIdlAuthorityEvent::try_from_slice(&value[AdminSetIdlAuthorityEvent::DISCRIMINATOR.len()..])
                    .map(Self::AdminSetIdlAuthorityEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(AdminUpdateTokenIncentivesEvent::DISCRIMINATOR) {
                return AdminUpdateTokenIncentivesEvent::try_from_slice(&value[AdminUpdateTokenIncentivesEvent::DISCRIMINATOR.len()..])
                    .map(Self::AdminUpdateTokenIncentivesEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(ClaimCashbackEvent::DISCRIMINATOR) {
                return ClaimCashbackEvent::try_from_slice(&value[ClaimCashbackEvent::DISCRIMINATOR.len()..])
                    .map(Self::ClaimCashbackEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(ClaimTokenIncentivesEvent::DISCRIMINATOR) {
                return ClaimTokenIncentivesEvent::try_from_slice(&value[ClaimTokenIncentivesEvent::DISCRIMINATOR.len()..])
                    .map(Self::ClaimTokenIncentivesEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(CloseUserVolumeAccumulatorEvent::DISCRIMINATOR) {
                return CloseUserVolumeAccumulatorEvent::try_from_slice(&value[CloseUserVolumeAccumulatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::CloseUserVolumeAccumulatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(CollectCreatorFeeEvent::DISCRIMINATOR) {
                return CollectCreatorFeeEvent::try_from_slice(&value[CollectCreatorFeeEvent::DISCRIMINATOR.len()..])
                    .map(Self::CollectCreatorFeeEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(CompleteEvent::DISCRIMINATOR) {
                return CompleteEvent::try_from_slice(&value[CompleteEvent::DISCRIMINATOR.len()..])
                    .map(Self::CompleteEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(CompletePumpAmmMigrationEvent::DISCRIMINATOR) {
                return CompletePumpAmmMigrationEvent::try_from_slice(&value[CompletePumpAmmMigrationEvent::DISCRIMINATOR.len()..])
                    .map(Self::CompletePumpAmmMigrationEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(CreateEvent::DISCRIMINATOR) {
                return CreateEvent::try_from_slice(&value[CreateEvent::DISCRIMINATOR.len()..])
                    .map(Self::CreateEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(DistributeCreatorFeesEvent::DISCRIMINATOR) {
                return DistributeCreatorFeesEvent::try_from_slice(&value[DistributeCreatorFeesEvent::DISCRIMINATOR.len()..])
                    .map(Self::DistributeCreatorFeesEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(DistributeFeeToHoldersEvent::DISCRIMINATOR) {
                return DistributeFeeToHoldersEvent::try_from_slice(&value[DistributeFeeToHoldersEvent::DISCRIMINATOR.len()..])
                    .map(Self::DistributeFeeToHoldersEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(ExtendAccountEvent::DISCRIMINATOR) {
                return ExtendAccountEvent::try_from_slice(&value[ExtendAccountEvent::DISCRIMINATOR.len()..])
                    .map(Self::ExtendAccountEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(InitUserVolumeAccumulatorEvent::DISCRIMINATOR) {
                return InitUserVolumeAccumulatorEvent::try_from_slice(&value[InitUserVolumeAccumulatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::InitUserVolumeAccumulatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(MigrateBondingCurveCreatorEvent::DISCRIMINATOR) {
                return MigrateBondingCurveCreatorEvent::try_from_slice(&value[MigrateBondingCurveCreatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::MigrateBondingCurveCreatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(MinimumDistributableFeeEvent::DISCRIMINATOR) {
                return MinimumDistributableFeeEvent::try_from_slice(&value[MinimumDistributableFeeEvent::DISCRIMINATOR.len()..])
                    .map(Self::MinimumDistributableFeeEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(PostCompleteBuyEvent::DISCRIMINATOR) {
                return PostCompleteBuyEvent::try_from_slice(&value[PostCompleteBuyEvent::DISCRIMINATOR.len()..])
                    .map(Self::PostCompleteBuyEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(RemoveQuoteControlMintEvent::DISCRIMINATOR) {
                return RemoveQuoteControlMintEvent::try_from_slice(&value[RemoveQuoteControlMintEvent::DISCRIMINATOR.len()..])
                    .map(Self::RemoveQuoteControlMintEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(ReservedFeeRecipientsEvent::DISCRIMINATOR) {
                return ReservedFeeRecipientsEvent::try_from_slice(&value[ReservedFeeRecipientsEvent::DISCRIMINATOR.len()..])
                    .map(Self::ReservedFeeRecipientsEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetCreatorEvent::DISCRIMINATOR) {
                return SetCreatorEvent::try_from_slice(&value[SetCreatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetCreatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetMetaplexCreatorEvent::DISCRIMINATOR) {
                return SetMetaplexCreatorEvent::try_from_slice(&value[SetMetaplexCreatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetMetaplexCreatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetParamsEvent::DISCRIMINATOR) {
                return SetParamsEvent::try_from_slice(&value[SetParamsEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetParamsEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetQuoteControlAdminEvent::DISCRIMINATOR) {
                return SetQuoteControlAdminEvent::try_from_slice(&value[SetQuoteControlAdminEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetQuoteControlAdminEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetQuoteControlMintReservesEvent::DISCRIMINATOR) {
                return SetQuoteControlMintReservesEvent::try_from_slice(&value[SetQuoteControlMintReservesEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetQuoteControlMintReservesEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SetQuoteControlReservesAdminEvent::DISCRIMINATOR) {
                return SetQuoteControlReservesAdminEvent::try_from_slice(&value[SetQuoteControlReservesAdminEvent::DISCRIMINATOR.len()..])
                    .map(Self::SetQuoteControlReservesAdminEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SweepBondingCurveFeeEvent::DISCRIMINATOR) {
                return SweepBondingCurveFeeEvent::try_from_slice(&value[SweepBondingCurveFeeEvent::DISCRIMINATOR.len()..])
                    .map(Self::SweepBondingCurveFeeEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(SyncUserVolumeAccumulatorEvent::DISCRIMINATOR) {
                return SyncUserVolumeAccumulatorEvent::try_from_slice(&value[SyncUserVolumeAccumulatorEvent::DISCRIMINATOR.len()..])
                    .map(Self::SyncUserVolumeAccumulatorEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(TradeEvent::DISCRIMINATOR) {
                return TradeEvent::try_from_slice(&value[TradeEvent::DISCRIMINATOR.len()..])
                    .map(Self::TradeEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(UpdateCreatorFeeConfigEvent::DISCRIMINATOR) {
                return UpdateCreatorFeeConfigEvent::try_from_slice(&value[UpdateCreatorFeeConfigEvent::DISCRIMINATOR.len()..])
                    .map(Self::UpdateCreatorFeeConfigEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(UpdateGlobalAuthorityEvent::DISCRIMINATOR) {
                return UpdateGlobalAuthorityEvent::try_from_slice(&value[UpdateGlobalAuthorityEvent::DISCRIMINATOR.len()..])
                    .map(Self::UpdateGlobalAuthorityEvent)
                    .map_err(Into::into)
            }
            if value.starts_with(UpdateMayhemVirtualParamsEvent::DISCRIMINATOR) {
                return UpdateMayhemVirtualParamsEvent::try_from_slice(&value[UpdateMayhemVirtualParamsEvent::DISCRIMINATOR.len()..])
                    .map(Self::UpdateMayhemVirtualParamsEvent)
                    .map_err(Into::into)
            }

                Err(ProgramError::InvalidArgument.into())
            }
        }
}
