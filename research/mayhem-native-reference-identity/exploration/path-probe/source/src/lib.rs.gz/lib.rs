mod child;
#[no_mangle] pub fn root_path() -> &static str { file!() }
