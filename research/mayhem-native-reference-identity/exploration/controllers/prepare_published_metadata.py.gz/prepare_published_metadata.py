from pathlib import Path
import hashlib,json,os,subprocess,shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-published-metadata';B=W/'mayhem-source-data-native';R=W/'pumpfun-source/research/mayhem-sharing-matrix'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
source=(R/'wrapper-control/wrapper.rs').read_text()
source=source.replace('MAYHEM_SHARING_MODE','MAYHEM_METADATA_MODE').replace('omit-sysvar-no','published-target-metadata')
start=source.index('    let is_sysvar =');end=source.index('    let path =',start)
source=source[:start]+'''    let is_target = command.windows(2).any(|w| w[0] == "--target" && w[1] == "sbpf-solana-solana");
    let is_compile = command.iter().any(|a| a == "--emit=dep-info,metadata,link" || a == "--emit=dep-info,link");
    let mut removed = 0;
    if mode == "published-target-metadata" && is_target && is_compile {
        let crate_name = command.windows(2).find(|w| w[0] == "--crate-name").expect("crate name")[1].to_str().unwrap();
        let positions: Vec<usize> = command.iter().enumerate().filter(|(_, v)| v.to_str().unwrap().starts_with("metadata=")).map(|(i, _)| i).collect();
        assert_eq!(positions.len(), 1, "one metadata argument required");
        let position = positions[0];
        let old = command[position].to_str().unwrap().strip_prefix("metadata=").unwrap();
        let map = fs::read_to_string(env::var_os("MAYHEM_METADATA_MAP").expect("metadata map")).expect("read metadata map");
        let matched: Vec<Vec<&str>> = map.lines().map(|line| line.split('\\t').collect()).filter(|parts: &Vec<&str>| parts.len() == 3 && parts[0] == old && parts[2] == crate_name).collect();
        assert_eq!(matched.len(), 1, "exactly one bound metadata mapping required");
        command[position] = OsString::from(format!("metadata={}", matched[0][1]));
        removed = 1;
    }
'''+source[end:]
source=source.replace('\\"removed\\"','\\"metadata_replaced\\"')
(P/'wrapper.rs').write_text(source,encoding='utf8',newline='\n')
L=json.loads((B/'build-01/launch.json').read_bytes());env={k:os.environ[k]for k in('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE')if k in os.environ};env.update(L['environment_overrides'])
compiler=Path(L['environment_overrides']['RUSTC']);assert sha(compiler)==L['checked_executables'][str(compiler)]
cmd=[str(compiler),'--crate-name','metadata_wrapper','--edition=2021','-C','opt-level=2',str(P/'wrapper.rs'),'-o',str(P/'wrapper.exe')]
save(P/'wrapper-compile-launch.json',dict(command=cmd,environment=env,source_sha256=sha(P/'wrapper.rs'),compiler_sha256=sha(compiler)))
p=subprocess.run(cmd,env=env,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
(P/'wrapper-compile.stdout.log').write_bytes(p.stdout);(P/'wrapper-compile.stderr.log').write_bytes(p.stderr)
save(P/'wrapper-compile-result.json',dict(returncode=p.returncode,wrapper_sha256=sha(P/'wrapper.exe')if(P/'wrapper.exe').exists()else None));assert p.returncode==0,p.stderr.decode(errors='replace')
for label,mode in [('passthrough','passthrough'),('published','published-target-metadata'),('published-repeat','published-target-metadata')]:
 dest=P/label;dest.mkdir(exist_ok=False)
 for n in ['sources','builds']:shutil.copytree(B/n,dest/n)
 for n in ['source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json']:shutil.copyfile(B/n,dest/n)
 builder=(B/'build.py').read_text();old='        env.update(extra)';assert builder.count(old)==1
 insertion="        records = output / 'wrapper-records'\n        records.mkdir()\n        wrapper = HERE.parent / 'wrapper.exe'\n        metadata_map = HERE.parent / 'metadata-map.tsv'\n        require(sha(wrapper) == "+repr(sha(P/'wrapper.exe'))+", 'wrapper differs')\n        require(sha(metadata_map) == "+repr(sha(P/'metadata-map.tsv'))+", 'metadata map differs')\n        extra.update(RUSTC_WRAPPER=str(wrapper), MAYHEM_METADATA_MODE="+repr(mode)+", MAYHEM_METADATA_MAP=str(metadata_map), MAYHEM_WRAPPER_RECORDS=str(records))\n        env.update(extra)"
 builder=builder.replace(old,insertion)
 old="        result['outputs'] =";assert builder.count(old)==1
 builder=builder.replace(old,"        require(sha(wrapper) == "+repr(sha(P/'wrapper.exe'))+" and sha(metadata_map) == "+repr(sha(P/'metadata-map.tsv'))+", 'wrapper/map changed')\n"+old)
 (dest/'build.py').write_text(builder,encoding='utf8',newline='\n')
print('Compiled metadata wrapper and prepared three frozen-source full builds.')
