from pathlib import Path
import gzip,hashlib,json,re,shlex,subprocess
W=Path(__file__).resolve().parent;R=W/'pumpfun-source';P=W/'mayhem-published-metadata';O=P/'logs';O.mkdir(exist_ok=True)
REV='e57657def421f34ceb31166626e6a07b801ebb6f'
selected={
 'main-v154':'repro/mayhem/compiler-v154-main/main/build.log',
 'native-program':'research/mayhem-native-program-recovery/builds/recovered/stderr.gz',
 'amm-origins':'research/mayhem-amm-source-origins/builds/recovered/stderr.gz',
 'full-curve':'research/mayhem-full-curve-recovery/builds/recovered/stderr.gz',
 'interval-corrected':'research/mayhem-interval-location-recovery/builds/corrected/stderr.gz',
 'parallel':'research/mayhem-parallel-recovery/builds/recovered/stderr.gz',
 'composed':'research/mayhem-composed-recovery/builds/recovered/stderr.gz',
 'source-data':'research/mayhem-source-data-recovery/builds/recovered/stderr.gz',
 'quote-controls':'research/mayhem-quote-validator-controls/builds/baseline-clean/stderr.gz',
 'quote-followups':'research/mayhem-quote-validator-followups/builds/baseline-clean/stderr.gz',
 'external-curve':'research/mayhem-external-curve-decoder/builds/curve-external-resolved/build.log',
 'buy-v2':'research/mayhem-buy-v2-shared-validation/builds/current/build.log'
}
result={}
for label,path in selected.items():
 data=subprocess.check_output(['git','show',REV+':'+path],cwd=R);raw=gzip.decompress(data)if path.endswith('.gz')else data;(O/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
 rows=[]
 for line in raw.decode().splitlines():
  if 'Running `'not in line or '--crate-name'not in line:continue
  command=line.strip()[len('Running `'):-1];args=shlex.split(command)
  if '--target'not in args or args[args.index('--target')+1]!='sbpf-solana-solana':continue
  name=args[args.index('--crate-name')+1];metadata=[a.removeprefix('metadata=')for a in args if a.startswith('metadata=')];extra=[a.removeprefix('extra-filename=')for a in args if a.startswith('extra-filename=')]
  source=next((a for a in args if a.endswith('.rs')),None)
  rows.append(dict(crate=name,metadata=metadata,extra_filename=extra,source=source,args=args))
 result[label]=dict(path=path,git_blob=subprocess.check_output(['git','rev-parse',REV+':'+path],cwd=R,text=True).strip(),compressed_sha256=hashlib.sha256(data).hexdigest(),raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),target_invocations=rows)
 print(label,len(raw),len(rows),flush=True)
(P/'collected-logs.json').write_text(json.dumps(dict(revision=REV,logs=result),indent=2)+'\n',encoding='utf8',newline='\n')
