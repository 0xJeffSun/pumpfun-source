from pathlib import Path
import hashlib,json,os,subprocess,shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-published-metadata';B=W/'mayhem-source-data-native'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
sources=json.loads((B/'source-inputs.json').read_bytes())['source_files'];units=json.loads((P/'metadata-map.json').read_bytes());common=['src/lib.rs','src/instruction.rs','src/state.rs','src/syscalls.rs','src/internal.rs','src/encode.rs','src/ser/mod.rs','src/extension/mod.rs','src/account_wrapper.rs']
mapping=[]
for name in sorted({r['crate']for r in units}):
 if name=='mayhem_recovered':
  paths=[r['path']for r in sources if r['path'].startswith('src/')and r['path'].endswith('.rs')]
  pairs=[(n,n if n=='src/account_wrapper.rs'else'programs/mayhem-program/'+n)for n in paths]
 elif name=='anchor_lang':
  pairs=[(r['path'],r['path'])for r in sources if r['path'].startswith('vendor/anchor-lang/')and r['path'].endswith('.rs')]
 elif name=='curve_accounts':
  pairs=[(n,n)for n in common]+[(r['path'],r['path'].removeprefix('curve-accounts/'))for r in sources if r['path'].startswith('curve-accounts/')and r['path'].endswith('.rs')]
 else:pairs=[(n,n)for n in common]
 mapping.extend((name,old,new)for old,new in pairs)
(P/'path-map.tsv').write_text(''.join('\t'.join(row)+'\n'for row in mapping),encoding='utf8',newline='\n')
src=(P/'wrapper.rs').read_text();src=src.replace('mode == "passthrough" || mode == "published-target-metadata"','mode == "passthrough" || mode == "published-target-metadata" || mode == "published-with-paths"').replace('if mode == "published-target-metadata" && is_target && is_compile','if mode != "passthrough" && is_target && is_compile')
point='    let path = PathBuf::from';assert src.count(point)==1
src=src.replace(point,'''    if mode == "published-with-paths" && is_target && is_compile {
        let crate_name = command.windows(2).find(|w| w[0] == "--crate-name").unwrap()[1].to_str().unwrap().to_owned();
        let map = fs::read_to_string(env::var_os("MAYHEM_PATH_MAP").expect("path map")).expect("read path map");
        for line in map.lines() {
            let parts: Vec<&str> = line.split('\\t').collect();
            assert_eq!(parts.len(), 3);
            if parts[0] == crate_name {
                command.push(OsString::from(format!("--remap-path-prefix={}={}", parts[1], parts[2])));
            }
        }
    }
'''+point)
(P/'wrapper-paths.rs').write_text(src,encoding='utf8',newline='\n')
L=json.loads((B/'build-01/launch.json').read_bytes());env={k:os.environ[k]for k in('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE')if k in os.environ};env.update(L['environment_overrides']);compiler=Path(L['environment_overrides']['RUSTC'])
cmd=[str(compiler),'--crate-name','metadata_paths_wrapper','--edition=2021','-C','opt-level=2',str(P/'wrapper-paths.rs'),'-o',str(P/'wrapper-paths.exe')]
save(P/'wrapper-paths-compile-launch.json',dict(command=cmd,environment=env,source_sha256=sha(P/'wrapper-paths.rs'),compiler_sha256=sha(compiler)))
p=subprocess.run(cmd,env=env,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW);(P/'wrapper-paths-compile.stdout.log').write_bytes(p.stdout);(P/'wrapper-paths-compile.stderr.log').write_bytes(p.stderr);save(P/'wrapper-paths-compile-result.json',dict(returncode=p.returncode,wrapper_sha256=sha(P/'wrapper-paths.exe')if(P/'wrapper-paths.exe').exists()else None));assert p.returncode==0,p.stderr
for label in ['paths','paths-repeat']:
 dest=P/label;dest.mkdir(exist_ok=False)
 for n in ['sources','builds']:shutil.copytree(B/n,dest/n)
 for n in ['source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json']:shutil.copyfile(B/n,dest/n)
 builder=(P/'published/build.py').read_text().replace("wrapper = HERE.parent / 'wrapper.exe'","wrapper = HERE.parent / 'wrapper-paths.exe'").replace(sha(P/'wrapper.exe'),sha(P/'wrapper-paths.exe')).replace("MAYHEM_METADATA_MODE='published-target-metadata'","MAYHEM_METADATA_MODE='published-with-paths', MAYHEM_PATH_MAP=str(HERE.parent / 'path-map.tsv')")
 builder=builder.replace("        metadata_map = HERE.parent / 'metadata-map.tsv'","        require(sha(HERE.parent / 'path-map.tsv') == "+repr(sha(P/'path-map.tsv'))+", 'path map differs')\n        metadata_map = HERE.parent / 'metadata-map.tsv'")
 (dest/'build.py').write_text(builder,encoding='utf8',newline='\n')
print('Prepared exact-file source path remaps;',len(mapping),'map rows across',len({r[0]for r in mapping}),'crate names.')
