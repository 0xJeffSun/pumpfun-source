from pathlib import Path
from collections import Counter
import importlib.util,json,hashlib,gzip
W=Path(__file__).resolve().parent;P=W/'mayhem-published-metadata';R=W/'pumpfun-source'
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
v=mod('v',R/'research/mayhem-allocator-sharing/verify.py');layer=mod('layer',W/'mayhem-native-build/comparison/layer01.py')
original=layer.Elf(W/'mayhem-native-build/comparison/original.so');originals={r['id']:original.window(r['start'],r['end'])for r in json.loads((W/'mayhem-native-build/comparison/prior-inventory.json').read_bytes())['original_rows']}
paths={'published-reference':W/'mayhem-source-data-native/published-symbols.so','native-baseline':W/'mayhem-source-data-native/build-01/symbols.so','profile-control':W/'mayhem-source-data-native/alloc-provider/build-01/symbols.so'}
for label in ['passthrough','published','published-repeat','paths','paths-repeat','relative','relative-repeat']:
 if(P/label/'build-01/result.json').exists():paths[label]=P/label/'build-01/symbols.so'
report={};counts={};elfs={}
for label,path in paths.items():
 elf=layer.Elf(path);elfs[label]=elf;windows=v.functions(elf);count=Counter(v.shape(w)for w in windows.values());counts[label]=count;hashes={w['raw_sha256']for w in windows.values()}
 row=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=len(elf.b),text_bytes=elf.hi-elf.lo,functions=len(windows),normalized_ids=sorted(k for k,w in originals.items()if v.shape(w)in count),raw_ids=sorted(k for k,w in originals.items()if w['raw_sha256']in hashes))
 if label!='published-reference':
  a=elfs['published-reference'];row['whole_normalized_text_equal']=a.norm(a.lo,a.hi)==elf.norm(elf.lo,elf.hi);row['function_multiset_equal']=count==counts['published-reference'];row['sections']={}
  for name in ['.text','.rodata','.data.rel.ro','.rel.dyn','.symtab','.strtab']:
   sa,sb=a.sec[name],elf.sec[name];aa=a.b[sa['offset']:sa['offset']+sa['size']];bb=elf.b[sb['offset']:sb['offset']+sb['size']]
   row['sections'][name]=dict(reference_bytes=len(aa),control_bytes=len(bb),equal=aa==bb,differing_overlap_positions=sum(x!=y for x,y in zip(aa,bb)),tail_bytes=abs(len(aa)-len(bb)))
  pa={(w['start'],w['end']):w for w in v.functions(a).values()};same_address_raw=sum(k in pa and w['raw_sha256']==pa[k]['raw_sha256']for k,w in windows.items());row['same_address_raw_function_extents']=same_address_raw
 report[label]=row
 print(label,row['bytes'],row['text_bytes'],row['functions'],'matches',len(row['normalized_ids']),len(row['raw_ids']),'multiset',row.get('function_multiset_equal'),'textdelta',row.get('sections',{}).get('.text'),flush=True)
(P/'analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n')
