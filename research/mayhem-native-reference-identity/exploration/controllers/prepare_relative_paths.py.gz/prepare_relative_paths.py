from pathlib import Path
import hashlib,json,os,subprocess,shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-published-metadata';B=W/'mayhem-source-data-native'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
src=(P/'wrapper-paths.rs').read_text();src=src.replace('mode == "published-with-paths");','mode == "published-with-paths" || mode == "published-with-paths-relative");').replace('if mode == "published-with-paths" && is_target && is_compile','if mode.starts_with("published-with-paths") && is_target && is_compile')
point='    let path = PathBuf::from';assert src.count(point)==1
src=src.replace(point,'''    if mode == "published-with-paths-relative" && is_target && is_compile {
        let cwd = env::current_dir().expect("cwd");
        for value in command.iter_mut() {
            let text = value.to_str().expect("UTF-8 argument");
            if !text.starts_with('-') && text.ends_with(".rs") && PathBuf::from(text).is_absolute() {
                let source = PathBuf::from(text);
                let relative = source.strip_prefix(&cwd).expect("registry input is within crate cwd");
                *value = OsString::from(relative.to_str().expect("UTF-8 source").replace('\\\\', "/"));
            }
        }
    }
'''+point)
(P/'wrapper-relative.rs').write_text(src,encoding='utf8',newline='\n')
L=json.loads((B/'build-01/launch.json').read_bytes());env={k:os.environ[k]for k in('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE')if k in os.environ};env.update(L['environment_overrides']);compiler=Path(L['environment_overrides']['RUSTC'])
cmd=[str(compiler),'--crate-name','metadata_relative_wrapper','--edition=2021','-C','opt-level=2',str(P/'wrapper-relative.rs'),'-o',str(P/'wrapper-relative.exe')]
save(P/'wrapper-relative-compile-launch.json',dict(command=cmd,environment=env,source_sha256=sha(P/'wrapper-relative.rs'),compiler_sha256=sha(compiler)))
p=subprocess.run(cmd,env=env,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW);(P/'wrapper-relative-compile.stdout.log').write_bytes(p.stdout);(P/'wrapper-relative-compile.stderr.log').write_bytes(p.stderr);save(P/'wrapper-relative-compile-result.json',dict(returncode=p.returncode,wrapper_sha256=sha(P/'wrapper-relative.exe')if(P/'wrapper-relative.exe').exists()else None));assert p.returncode==0,p.stderr
for label in ['relative','relative-repeat']:
 dest=P/label;dest.mkdir(exist_ok=False)
 for n in ['sources','builds']:shutil.copytree(B/n,dest/n)
 for n in ['source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json']:shutil.copyfile(B/n,dest/n)
 builder=(P/'paths/build.py').read_text().replace("wrapper = HERE.parent / 'wrapper-paths.exe'","wrapper = HERE.parent / 'wrapper-relative.exe'").replace(sha(P/'wrapper-paths.exe'),sha(P/'wrapper-relative.exe')).replace("MAYHEM_METADATA_MODE='published-with-paths'","MAYHEM_METADATA_MODE='published-with-paths-relative'")
 (dest/'build.py').write_text(builder,encoding='utf8',newline='\n')
print('Prepared metadata plus full-path-remap controls with relative registry source inputs.')
