from pathlib import Path
import ctypes,hashlib,json,re
W=Path(__file__).resolve().parent;P=W/'mayhem-published-metadata'
def parse(command):
 api=ctypes.windll.shell32.CommandLineToArgvW;api.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];api.restype=ctypes.POINTER(ctypes.c_wchar_p);n=ctypes.c_int();p=api(command,ctypes.byref(n))
 if not p:raise ctypes.WinError()
 try:return[p[i]for i in range(n.value)]
 finally:
  free=ctypes.windll.kernel32.LocalFree;free.argtypes=[ctypes.c_void_p];free.restype=ctypes.c_void_p;free(p)
def source_key(source):
 source=source.replace('\\','/')
 if source in ['src/lib.rs','curve-accounts/src/lib.rs','vendor/anchor-lang/src/lib.rs']:return source
 found=re.search(r'/([^/]+-\d+\.\d+\.\d+[^/]*)/(.+\.rs)$',source);assert found,source
 return found[1]+'/'+found[2]
def signature(args):
 result=[];skip=False
 for i,a in enumerate(args[1:]):
  if skip:skip=False;continue
  if a in ['--out-dir','-L','--extern']:skip=True;continue
  if a=='-C':
   value=args[i+2]
   if value.startswith(('metadata=','extra-filename=')):skip=True;continue
  if a.startswith('--sysroot='):continue
  if a.endswith('.rs') and not a.startswith('-'):a=source_key(a)
  result.append(a)
 return result
published=json.loads((P/'initial-binding.json').read_bytes())['combined'];by_source={source_key(r['source']):r for r in published};assert len(by_source)==85
native=[]
log=W/'mayhem-source-data-native/build-01/stderr.log'
for line in log.read_text().splitlines():
 if 'Running `'not in line or '--crate-name'not in line:continue
 args=parse(line.strip()[len('Running `'):-1])
 if '--target'not in args or args[args.index('--target')+1]!='sbpf-solana-solana':continue
 name=args[args.index('--crate-name')+1];source=next(a for a in args if a.endswith('.rs'));old=[a.removeprefix('metadata=')for a in args if a.startswith('metadata=')];assert len(old)==1
 published_row=by_source[source_key(source)];assert published_row['crate']==name and len(published_row['metadata'])==1
 left,right=signature(args),signature(published_row['args']);native.append(dict(crate=name,source_key=source_key(source),native_metadata=old[0],published_metadata=published_row['metadata'][0],native_args=args,published_args=published_row['args'],native_signature=left,published_signature=right,remaining_args_equal=left==right))
assert len(native)==85 and len({r['native_metadata']for r in native})==85
(P/'metadata-map.json').write_text(json.dumps(native,indent=2)+'\n',encoding='utf8',newline='\n')
(P/'metadata-map.tsv').write_text(''.join(r['native_metadata']+'\t'+r['published_metadata']+'\t'+r['crate']+'\n'for r in sorted(native,key=lambda r:r['native_metadata'])),encoding='utf8',newline='\n')
print('Bound',len(native),'target units; equal remaining argument sequences',sum(r['remaining_args_equal']for r in native))
for r in native:
 if not r['remaining_args_equal']:print(r['crate'],r['source_key'],'native-only',[a for a in r['native_signature']if a not in r['published_signature']],'published-only',[a for a in r['published_signature']if a not in r['native_signature']])
