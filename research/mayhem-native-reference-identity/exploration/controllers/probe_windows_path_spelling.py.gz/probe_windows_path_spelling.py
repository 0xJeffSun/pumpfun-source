from pathlib import Path
import hashlib,json,os,re,subprocess
W=Path(__file__).resolve().parent;O=W/'mayhem-published-metadata/path-probe-02';O.mkdir(exist_ok=False);S=O/'source';(S/'src').mkdir(parents=True)
(S/'src/lib.rs').write_text("mod child;\n#[no_mangle] pub fn root_path() -> &'static str { file!() }\n",encoding='utf8',newline='\n')
(S/'src/child.rs').write_text("#[no_mangle] pub fn child_path() -> &'static str { file!() }\n",encoding='utf8',newline='\n')
L=json.loads((W/'mayhem-source-data-native/build-01/launch.json').read_bytes());env={k:os.environ[k]for k in('SystemRoot','WINDIR','SystemDrive','COMSPEC','PROCESSOR_ARCHITECTURE')if k in os.environ};env.update(L['environment_overrides'])
base=[L['environment_overrides']['RUSTC'],'--crate-name','path_spelling','--crate-type=lib','--edition=2021','--emit=obj','-C','opt-level=2','--target','sbpf-solana-solana','--sysroot='+str(W/'windows-typeid-probe/linux-sysroot/rust'),'-Zremap-cwd-prefix=']
variants={'relative':('src/lib.rs',[]),'same-remap':('src/lib.rs',['--remap-path-prefix=src/child.rs=src/child.rs','--remap-path-prefix=src/lib.rs=src/lib.rs']),'absolute-remap':(str(S/'src/lib.rs'),['--remap-path-prefix='+str(S/'src'/f)+'=src/'+f for f in ['lib.rs','child.rs']]),'absolute-input':(str(S/'src/lib.rs'),[])}
results={}
for label,(source,flags)in variants.items():
 d=O/label;d.mkdir();cmd=base+[source,'-o',str(d/'out.o')]+flags;p=subprocess.run(cmd,cwd=S,env=env,capture_output=True,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW);(d/'stderr.log').write_bytes(p.stderr);(d/'stdout.log').write_bytes(p.stdout);assert p.returncode==0,p.stderr
 data=(d/'out.o').read_bytes();strings=[m.group().decode()for m in re.finditer(rb'[\x20-\x7e]{4,}',data)if b'.rs'in m.group()];results[label]=dict(command=cmd,cwd=str(S),source_files={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in(S/'src').glob('*.rs')},sha256=hashlib.sha256(data).hexdigest(),strings=strings,target_executions=0);print(label,strings)
(O/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8',newline='\n')
