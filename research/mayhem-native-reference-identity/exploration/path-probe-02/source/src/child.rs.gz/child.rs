#[no_mangle] pub fn child_path() -> &'static str { file!() }
