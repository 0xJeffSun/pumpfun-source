from experiment import *
t=parent[F].decode();a,b=t.split('pub fn legacy_sell_handler',1);body,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
price=tail.split('fn legacy_price_check',1)[1].split('{',1)[1].rsplit('}',1)[0]
flat=' '.join(price.split())
forms={
 'price-inline-closure':body.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(),MayhemError>=(||{'+flat+'})();price_check?;'),
 'price-inner-reference':body.replace('let c=&a.bonding_curve;', '').replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(),MayhemError>=(||{let c=&a.bonding_curve;'+flat+'})();price_check?;let c=&a.bonding_curve;'),
 'price-temporary-reference':body.replace('let c=&a.bonding_curve;', '').replace('legacy_price_check(c,reference,tolerance_bps)?;','legacy_price_check(&a.bonding_curve,reference,tolerance_bps)?;let c=&a.bonding_curve;'),
 'price-move-closure':body.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(),MayhemError>=(move ||{'+flat+'})();price_check?;'),
 'price-eager-result':body.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check=legacy_price_check(c,reference,tolerance_bps);if let Err(error)=price_check{return Err(error.into());}'),
 'named-context-fixed':body.replace(' crate::pump::cpi::sell(CpiContext::new_with_signer(', ' let cpi_ctx=CpiContext::new_with_signer(').replace(']),input,minimum)', ']);crate::pump::cpi::sell(cpi_ctx,input,minimum)').replace('let seeds:&[&[u8]]=&[b"sol-vault",&bump];','let seeds:&[&[u8]]=&[b"sol-vault",&bump];let signer_seeds=&[seeds];').replace(' },&[seeds])',' },signer_seeds)'),
}
for n,v in forms.items():
 assert v!=body and v.count('\n')==body.count('\n'),n
 compile(n,a+'pub fn legacy_sell_handler'+v+'\n#[inline(always)]\nfn clone_sell_info'+tail)
clone=tail.replace(' AccountInfo { key:info.key, lamports:std::rc::Rc::clone(&info.lamports), data:std::rc::Rc::clone(&info.data), owner:info.owner, _unused:info._unused, is_signer:info.is_signer, is_writable:info.is_writable, executable:info.executable }',' info.clone()')
assert clone!=tail
compile('derived-clone',a+'pub fn legacy_sell_handler'+body+'\n#[inline(always)]\nfn clone_sell_info'+clone)
