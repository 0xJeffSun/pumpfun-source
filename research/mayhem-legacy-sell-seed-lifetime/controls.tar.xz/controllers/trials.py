from experiment import *
t=parent[F].decode();a,b=t.split('pub fn legacy_sell_handler',1);body,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
forms={}
# Retain the exact line count because panic/error Source coordinates are part
# of the existing accepted comparison.
forms['remaining-assignment']=body.replace(' crate::pump::cpi::sell(CpiContext::new_with_signer(', ' let mut cpi_ctx=CpiContext::new_with_signer(').replace(' },&[seeds])',' },&[seeds]);').replace('  .with_remaining_accounts(vec![clone_sell_info(a.bonding_curve_v2.as_ref()),clone_sell_info(a.buyback_recipient.as_ref())]),input,minimum)', '  cpi_ctx.remaining_accounts=vec![clone_sell_info(a.bonding_curve_v2.as_ref()),clone_sell_info(a.buyback_recipient.as_ref())];crate::pump::cpi::sell(cpi_ctx,input,minimum)')
# An explicit local makes the seed slice live across the full consuming call.
forms['remaining-assignment']=forms['remaining-assignment'].replace('let seeds:&[&[u8]]=&[b"sol-vault",&bump];','let seeds:&[&[u8]]=&[b"sol-vault",&bump];let signer_seeds=&[seeds];').replace(' },&[seeds]);',' },signer_seeds);')
forms['named-context']=body.replace(' crate::pump::cpi::sell(CpiContext::new_with_signer(', ' let cpi_ctx=CpiContext::new_with_signer(').replace(']),input,minimum)', ']);crate::pump::cpi::sell(cpi_ctx,input,minimum)')
forms['typed-cpi-result']=body.replace(' crate::pump::cpi::sell(', ' let cpi_result=crate::pump::cpi::sell(').replace('input,minimum).map_err(', 'input,minimum);cpi_result.map_err(')
forms['typed-price-scope']=body.replace(' legacy_price_check(c,reference,tolerance_bps)?;', ' let price_check:core::result::Result<(),MayhemError>=(||legacy_price_check(c,reference,tolerance_bps))();price_check?;')
forms['owned-cpi-error']=body.replace('.map_err(|_|error!(MayhemError::PumpCpiFailed))', '.map_err(|old|{let new=error!(MayhemError::PumpCpiFailed);drop(old);new})')
forms['remaining-owned-error']=forms['remaining-assignment'].replace('.map_err(|_|error!(MayhemError::PumpCpiFailed))', '.map_err(|old|{let new=error!(MayhemError::PumpCpiFailed);drop(old);new})')
forms['program-local']=body.replace(' let bump=', ' let cpi_program=a.pump_program.key();let bump=').replace('CpiContext::new_with_signer(a.pump_program.key(),','CpiContext::new_with_signer(cpi_program,')
forms['remaining-program-local']=forms['remaining-assignment'].replace(' let bump=', ' let cpi_program=a.pump_program.key();let bump=').replace('CpiContext::new_with_signer(a.pump_program.key(),','CpiContext::new_with_signer(cpi_program,')
for n,v in forms.items():
 assert v!=body and v.count('\n')==body.count('\n'),n
 compile(n,a+'pub fn legacy_sell_handler'+v+'\n#[inline(always)]\nfn clone_sell_info'+tail)
