from experiment import *
t=parent[F].decode();a,b=t.split('pub fn legacy_sell_handler',1);body,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
forms={
 'accounts-move':body.replace('let a=&mut *ctx.accounts;','let a=ctx.accounts;'),
 'accounts-reference':body.replace('ctx:Context<LegacySell>','mut ctx:Context<LegacySell>').replace('let a=&mut *ctx.accounts;','let a=&mut ctx.accounts;'),
 'accounts-direct':body.replace('let a=&mut *ctx.accounts;','').replace('a.','ctx.accounts.'),
 'accounts-shared-reborrow':body.replace('let a=&mut *ctx.accounts;','let a=ctx.accounts;let a=&mut *a;'),
 'price-explicit-if':body.replace('legacy_price_check(c,reference,tolerance_bps)?;','match legacy_price_check(c,reference,tolerance_bps){Ok(())=>(),Err(e)=>return Err(e.into())};'),
 'retain-guard-first':body.replace('let (input, minimum) =','let _=crate::state::retained_basis_points(retained_reserve_bps);let (input, minimum) ='),
 'typed-seeds-array':body.replace('let seeds:&[&[u8]]=&[b"sol-vault",&bump];','let seeds:[&[u8];2]=[b"sol-vault",&bump];').replace(' },&[seeds])',' },&[&seeds])'),
}
for n,v in forms.items():
 assert v!=body and v.count('\n')==body.count('\n'),n
 compile(n,a+'pub fn legacy_sell_handler'+v+'\n#[inline(always)]\nfn clone_sell_info'+tail)
