from experiment import *
state=parent['src/state.rs'].decode();body=parent[F].decode();forms={}
# Preserve the existing checked rejection before any output arithmetic, but
# defer recomputation of the retained value until after cap selection.
f=state.replace('cap:u64,real_sol:u64,retained:u16)->u64','cap:u64,real_sol:u64,retained:impl FnOnce()->u16)->u64').replace('real_sol as u128*retained as u128','real_sol as u128*retained() as u128')
f=f.replace('real_sol,retained);','real_sol,||retained);')
f=f.replace('let retained=retained_basis_points(retained_bps);\n    let output=initial_trade_output(vt as u128,vs as u128,balance as u128,cap,real,retained);','let _=retained_basis_points(retained_bps);\n    let output=initial_trade_output(vt as u128,vs as u128,balance as u128,cap,real,||retained_basis_points(retained_bps));')
assert f!=state and f.count('\n')==state.count('\n')
forms['late-retained']=f
forms['closure-retained-control']=f.replace('let _=retained_basis_points(retained_bps);\n    let output=initial_trade_output(vt as u128,vs as u128,balance as u128,cap,real,||retained_basis_points(retained_bps));','let retained=retained_basis_points(retained_bps);\n    let output=initial_trade_output(vt as u128,vs as u128,balance as u128,cap,real,||retained);')
for name,text in forms.items():compile(name,body,{'src/state.rs':text.encode()})
# Return conversion is held to the original panic source and error variant.
a,b=body.split('pub fn legacy_sell_handler',1);handler,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
forms2={
 'inline-seeds':handler.replace('let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];','').replace(' },&[seeds])',' },&[&[b"sol-vault",&[ctx.bumps.sol_vault]]])'),
 'direct-result-match':handler.replace('.map_err(|_|error!(MayhemError::PumpCpiFailed))?;', ';if let Err(old)=cpi_result {let new=error!(MayhemError::PumpCpiFailed);drop(old);return Err(new);}').replace(' crate::pump::cpi::sell(', ' let cpi_result=crate::pump::cpi::sell('),
 'owned-program-info':handler.replace('let bump=[ctx.bumps.sol_vault];','let cpi_program=clone_sell_info(a.pump_program.as_ref());let bump=[ctx.bumps.sol_vault];').replace('CpiContext::new_with_signer(a.pump_program.key(),','CpiContext::new_with_signer(*cpi_program.key,'),
}
for name,h in forms2.items():
 assert h!=handler and h.count('\n')==handler.count('\n')
 compile(name,a+'pub fn legacy_sell_handler'+h+'\n#[inline(always)]\nfn clone_sell_info'+tail)
