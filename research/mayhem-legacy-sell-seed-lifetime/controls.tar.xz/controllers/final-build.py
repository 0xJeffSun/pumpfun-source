from experiment import *
compile('recovered',(W/'inline-seeds/source.rs').read_text())
compile('repeat',(W/'inline-seeds/source.rs').read_text())
