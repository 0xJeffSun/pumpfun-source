from experiment import *
t=parent[F].decode();a,b=t.split('pub fn legacy_sell_handler',1);body,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
inline=(W/'inline-seeds/source.rs').read_text().split('pub fn legacy_sell_handler',1)[1].split('\n#[inline(always)]\nfn clone_sell_info',1)[0]
price=tail.split('fn legacy_price_check',1)[1].split('{',1)[1].rsplit('}',1)[0];flat=' '.join(price.split())
for parent_name,h in [('original',body),('inline',inline)]:
 forms={}
 forms['tuple-price']=h.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(u64,u64),MayhemError>=(||{'+flat.replace('Ok(())','Ok((vt as u64,vs as u64))')+'})();let (vt,vs)=price_check?;').replace('sell_amounts(c.virtual_token_reserves,c.virtual_sol_reserves,','sell_amounts(vt,vs,')
 forms['outer-price-values']=h.replace('legacy_price_check(c,reference,tolerance_bps)?;','let vt=c.virtual_token_reserves as u128;let vs=c.virtual_sol_reserves as u128;let price_check:core::result::Result<(),MayhemError>=(||{'+flat.replace('let vt=c.virtual_token_reserves as u128;','').replace('let vs=c.virtual_sol_reserves as u128;','')+'})();price_check?;').replace('sell_amounts(c.virtual_token_reserves,c.virtual_sol_reserves,','sell_amounts(vt as u64,vs as u64,')
 forms['early-scaled-check']=h.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(),MayhemError>=(||{'+flat.replace('reference.checked_mul(tolerance_bps as u128);','reference.checked_mul(tolerance_bps as u128).ok_or(MayhemError::MathOverflow)?;').replace('scaled.ok_or(MayhemError::MathOverflow)?','scaled')+'})();price_check?;')
 forms['separate-price-checks']=h.replace('legacy_price_check(c,reference,tolerance_bps)?;','let price_check:core::result::Result<(),MayhemError>=(||{'+flat.replace('if price<low||price>high{return Err(MayhemError::PumpCpiSlippage);}', 'if price<low{return Err(MayhemError::PumpCpiSlippage);}if price>high{return Err(MayhemError::PumpCpiSlippage);}')+'})();price_check?;')
 for name,v in forms.items():
  assert v.count('\n')==body.count('\n')
  compile(parent_name+'-'+name,a+'pub fn legacy_sell_handler'+v+'\n#[inline(always)]\nfn clone_sell_info'+tail)
