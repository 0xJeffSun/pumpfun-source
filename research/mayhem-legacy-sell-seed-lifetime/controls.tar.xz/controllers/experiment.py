from pathlib import Path
import importlib.util,sys,json,hashlib,subprocess,gzip,difflib,shutil
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'work/mayhem-legacy-sell-next'
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
s=module('src',W/'previous-source.py');s.ROOT=R
parent=s.parent();F='src/instructions/pump_interface.rs'
reader=module('elf',R/'research/mayhem-trade-origins-validator/reader.py')
o=reader.Elf(R/'evidence/original/mayhem/deployed.so');rows=json.loads((R/'research/mayhem-trade-origins-validator/audit.json').read_bytes())['rows'];ow={r['start']:o.window(r['start'],r['end']) for r in rows};original=ow[127520]
key=lambda w:(w['end']-w['start'],w['normalized_sha256'],json.dumps(w['normalization_pattern'],sort_keys=True))
def score(path):
 e=reader.Elf(path);cw={s['value']:e.window(s['value'],s['value']+s['size']) for s in e.symbols if s['info']&15==2 and s['size']>=8 and e.lo<=s['value']<e.hi};sym=next(s for s in e.symbols if 'legacy_sell_handler17' in s['name']);w=cw[sym['value']]
 a=o.norm(original['start'],original['end'])[0];b=e.norm(w['start'],w['end'])[0];aa=[a[i:i+8] for i in range(0,len(a),8)];bb=[b[i:i+8] for i in range(0,len(b),8)]
 ac=[key(ow[x['target']]) for x in original['direct']];bc=[key(cw[x['target']]) for x in w['direct']]
 return dict(start=w['start'],bytes=w['end']-w['start'],equal=key(original)==key(w),equal_slots=sum(x==y for x,y in zip(aa,bb)),aligned_slots=sum(x.size for x in difflib.SequenceMatcher(a=aa,b=bb,autojunk=False).get_matching_blocks()),original_calls=len(ac),calls=len(bc),call_lcs=sum(x.size for x in difflib.SequenceMatcher(a=ac,b=bc,autojunk=False).get_matching_blocks()),normalized_matches=sum(any(key(x)==key(w) for x in cw.values()) for w in ow.values()))
def compile(name,text,extra=None):
 src=W/'source';src.mkdir(exist_ok=True)
 files=dict(parent);files[F]=text.encode();files.update(extra or {})
 for n,b in files.items():p=src/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 out=W/name;out.mkdir(exist_ok=True)
 (out/'source.rs').write_text(text)
 for n,b in files.items():
  if b!=parent[n]:p=out/'overrides'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 cmd=[sys.executable,'-B',str(W/'build.py'),'--source',str(src),'--sdk',str(R/'work/mayhem-recovery/verified-sdk'),'--cargo-home',str(R/'work/mayhem-recovery/cargo-home'),'--target',str(W/'target'),'--output',str(out/'build'),'--strip',str(R/'work/mayhem-recovery/llvm-objcopy-v152'),'--linker-script',str(R/'research/mayhem-trade-origins-validator/config/ordered.ld')]
 (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (out/'driver.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=log)
 if r.returncode:print(name,'FAILED',flush=True);return
 d=score(out/'build/symbols.so');(out/'measurement.json').write_text(json.dumps(d,indent=2)+'\n');print(name,d,flush=True)
if __name__=='__main__':compile('baseline',parent[F].decode())
