from experiment import *
t=parent[F].decode();a,b=t.split('pub fn legacy_sell_handler',1);body,tail=b.split('\n#[inline(always)]\nfn clone_sell_info',1)
inline=body.replace('let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];','').replace(' },&[seeds])',' },&[&[b"sol-vault",&[ctx.bumps.sol_vault]]])')
forms={
 'inline-seeds-named-bump':body.replace('let seeds:&[&[u8]]=&[b"sol-vault",&bump];','').replace(' },&[seeds])',' },&[&[b"sol-vault",&bump]])'),
 'named-seeds-inline-bump':body.replace('let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];','let seeds:&[&[u8]]=&[b"sol-vault",&[ctx.bumps.sol_vault]];'),
 'inline-seeds-result':inline.replace(' crate::pump::cpi::sell(', ' let cpi_result=crate::pump::cpi::sell(').replace('input,minimum).map_err(', 'input,minimum);cpi_result.map_err('),
 'inline-seeds-retain-first':inline.replace('let (input, minimum) =','let _=crate::state::retained_basis_points(retained_reserve_bps);let (input, minimum) ='),
 'inline-seeds-program-local':inline.replace(' let before_sol=', ' let cpi_program=a.pump_program.key();let before_sol=').replace('CpiContext::new_with_signer(a.pump_program.key(),','CpiContext::new_with_signer(cpi_program,'),
 'early-seeds':body.replace(' let before_sol=', ' let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];let before_sol=').replace('\n let bump=[ctx.bumps.sol_vault];let seeds:&[&[u8]]=&[b"sol-vault",&bump];','\n'),
 'inline-seeds-one-array':inline.replace('&[&[b"sol-vault",&[ctx.bumps.sol_vault]]]', '&[&[b"sol-vault" as &[u8],&[ctx.bumps.sol_vault]]]'),
}
for name,h in forms.items():
 assert h!=body and h.count('\n')==body.count('\n'),name
 compile(name,a+'pub fn legacy_sell_handler'+h+'\n#[inline(always)]\nfn clone_sell_info'+tail)
