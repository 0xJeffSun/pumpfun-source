# AMM v2 selector source recovery, in progress

Root checkout unchanged CLEAN codex/amm-hop-gate-recovery c6701a14.
PR422 merged 2026-10-28T09:22:24Z after maintainer commit7d45400cc hardened packet
inventory and transitive ELF parser binding. Exact remotehead67checks queued at
09:23 UTC; not passes. Original draft-pr.json head is historical; do not assert
remote head remains c6701a14. See pr422-current.json.
Latest upstream scope recorded in latest-scope.json (1df6e956), no observed v2 overlap.

J=/home/ahi200/pumpfun-work/20261028-amm-v2-selector.
H=/home/ahi200/pumpfun-work/20261028-amm-select-resume.
54source inputs and396dependency artifacts bound per normal build launch/result.
Every completed candidate below retains736normalized/159raw with no new/lost
complete windows; these are experiments, NOT new recovery credit or PRs.

- import-quote:1760->1632B, existing upstream borrowed quote source imported only.
  strip988946f1170a92b68448bc21a251deba7c47698efeb5a4386b15c800c7c8cbd3.
- scoped-authority:1696B, block lifetime makes memcmp precede guard and restores
  original reuse of authority/error-formatting stack space. requireSource184.
  strip945991421a6d2398735a3e50f6dca992c79643d8c0f48450b6d26744fd8915b6.
- owned-fees:1688B, pure ownedFees override boundary restores3rate loads before
  globalflag exactly; still separate guard/tier error outputs.
  stripf5815d7a5babe8eecd4812c63408bba36a29ff94b966c56592fb6c9591586b92.
- selection-boundary:1704B, Result<&Fees> adds unwanted niche-discriminant2 check.
  stripea0e5360aa165168a12050bceea5b1157da4ae266b3b0582ddb7b126cbfd33fe.
- owned-selection:1616B, ownedResult removes nichecheck but also merges outercap
  errors, changing output lifetime/registerallocation. Includes cap/PDA in helper.
  strip8e759a2bf0fb076c21c99b3103b9f8462aa148fe01c5386131af0a3dd1528ada.
- owned-direct: ENTIRE ELF IDENTICAL to owned-selection; do not retry direct
  creatoroverride spelling in this ownedResult context.
- route-boundary:1656B/195instructions, cap/PDA outside ownedResult helper;
  merges onlyguard/tier errors, restores original errorfallthrough and loads.
  stripdf40bffda295440b0c6325c031474eb9a0e7cae9daf70722d31bbfbba6db4bbc.
  Still differs R8/R9 allocation and normal/exotic/flat block layout.

All diagnosticIR captures except redundant owned-direct strip exactly to normal
candidate. Prior compressed failure archive scan in prior-compressed.json excludes
alreadyfailed explicit early-rate locals. NO runtime run for these candidates.
Codegen-layout/merge/route controls reproduce normal195/199instruction sequences
masking call and data operands only; modifiedIR artifacts are diagnostic, never
candidate source/runtime. normal-last route ordering reduces positional diffs46->19
but still16register differences and3branch differences; no full match claim.

Active at note creation: codegen-route-order diagnostic process. Inspect result/
process before relaunch. No new Gitbranch, commit, PR or original evidence edit.
