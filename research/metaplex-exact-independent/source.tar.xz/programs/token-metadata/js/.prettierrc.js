module.exports = require('../../.prettierrc');
