"""Read-only qualification of this exact candidate's already-produced evidence."""
from pathlib import Path
import base64,hashlib,importlib.util,json
from solders.transaction import Transaction
import tempfile
W=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((W/'inventory.json').read_text());new=json.loads((W/'specialized-inventory.json').read_text());matched=lambda j:{r['start']for r in j['windows']if r['candidates']};raw=lambda j:{r['start']for r in j['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])};assert matched(parent)<=matched(new)and raw(parent)<=raw(new);assert matched(new)-matched(parent)=={1221856,1223624};assert(new['injective_normalized'],new['membership_normalized'],new['injective_raw'])==(754,754,131)
for label in ['specialized','repeat']:
 r=json.loads((W/'builds'/label/'result.json').read_text());assert r['exit_code']==0 and r['root_invocations']==1;assert all(r[k]is True for k in ['source_unchanged','primary_unchanged','sdk_unchanged']);launch=json.loads((W/'builds'/label/'launch.json').read_text());assert launch['workspace_inputs']=={str(p.relative_to(W/'source')):sha(p)for p in(W/'source').rglob('*')if p.is_file()}
 for kind in ['unstripped','candidate']:
  p=W/'builds'/label/(kind+'.so');assert sha(p)==r[kind+'_sha256'];assert p.read_bytes()==(W/'builds/specialized'/(kind+'.so')).read_bytes()
report=json.loads((W/'runtime-report.json').read_text());loader=json.loads((W/'runtime-loader.json').read_text());assert report['case_count']==284 and not report['mismatches'];assert report['candidate_sha256']==sha(W/'builds/specialized/candidate.so');count=0;success=0
for row in report['cases']:
 assert row['match']is True and not row['different_fields'];assert all(row['original'][k]==row['candidate'][k]for k in ['error','accounts','events','inner','return_data']);success+=row['original']['error']is None
 for side in ['original','candidate']:
  tx=Transaction.from_bytes(base64.b64decode(row[side]['transaction_base64']));assert all(tx.verify_with_results());assert row[side]['signatures_verified']is True;count+=1
header=(W/'runtime-root/evidence/original/pump/programdata-account.bin').read_bytes()[:45]
for row in loader['loads']:
 binary=(W/'builds/specialized/candidate.so')if row['elf_sha256']==report['candidate_sha256']else(W/'runtime-root/evidence/original/pump/deployed.so');elf=binary.read_bytes();assert row['program_sha256']==sha(W/'runtime-root/evidence/original/pump/program-account.bin');assert hashlib.sha256(header+elf+bytes(row['programdata_bytes']-45-len(elf))).hexdigest()==row['programdata_sha256']
known={report['original_sha256'],report['candidate_sha256']};assert {r['elf_sha256']for r in loader['loads']}==known
for row in loader['loads']:assert row['elf_prefix_unchanged']is True and row['zero_allocation_tail']is True and row['program_owner']=='BPFLoaderUpgradeab1e11111111111111111111111'
for name in ['runtime-input-pins.json','runtime-data-pins.json']:
 pins=json.loads((W/name).read_text())
 for n,h in pins['files'].items():assert sha(W/'runtime-root'/n)==h
spec=importlib.util.spec_from_file_location('iv',W/'inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.inventory(W/'builds/specialized/unstripped.so')==new
if(W/'native-parent.so').exists():assert m.inventory(W/'native-parent.so')==parent
result=dict(normalized=754,raw=131,gain=[1221856,1223624],complete_repeat_equal=True,pairs=284,signed_records=count,success=success,reject=284-success,loader_loads=len(loader['loads']),scope='Exact new native artifact, focused legacy-buy corpus only. Two wrapper root bodies equal; each has one unmatched main-body callee. No full suite, data/transitive closure, raw-log/CU equality or whole identity.')
(W/'qualification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
