use crate::*;
use anchor_spl::{associated_token::AssociatedToken, token_interface::TokenInterface};

#[event_cpi]
#[derive(Accounts)]
pub struct SyncUserVolumeAccumulator<'info>{
    /// CHECK: PDA seed only, no signature required.
    pub user:AccountInfo<'info>,
    #[account(seeds=[b"global_volume_accumulator"],bump)]
    pub global_volume_accumulator:Account<'info,GlobalVolumeAccumulator>,
    #[account(mut,seeds=[b"user_volume_accumulator",user.key().as_ref()],bump)]
    pub user_volume_accumulator:Account<'info,UserVolumeAccumulator>,
}
pub(crate) fn reset(g:&GlobalVolumeAccumulator,u:&mut UserVolumeAccumulator,now:i64){
    if u.last_update_timestamp<g.start_time && now<g.start_time {
        u.total_claimed_tokens=0;
        u.has_total_claimed_tokens=false;
    }
}
#[event_cpi]
#[derive(Accounts)]
pub struct AdminUpdateTokenIncentives<'info>{
    #[account(mut)] pub admin:Signer<'info>,
    #[account(seeds=[b"global_config"],bump,has_one=admin @ PumpAmmError::InvalidAdmin)]
    pub global_config:Account<'info,GlobalConfig>,
    #[account(mut,seeds=[b"global_volume_accumulator"],bump)]
    pub global_volume_accumulator:Account<'info,GlobalVolumeAccumulator>,
    pub mint:InterfaceAccount<'info,Mint>,
    #[account(init_if_needed,payer=admin,associated_token::mint=mint,associated_token::authority=global_volume_accumulator,associated_token::token_program=token_program)]
    pub global_incentive_token_account:InterfaceAccount<'info,TokenAccount>,
    pub associated_token_program:Program<'info,AssociatedToken>,
    pub system_program:Program<'info,System>,
    pub token_program:Interface<'info,TokenInterface>,
}
pub fn admin(ctx:Context<AdminUpdateTokenIncentives>,start_time:i64,end_time:i64,seconds_in_a_day:i64,day_number:u64,token_supply_per_day:u64)->Result<()> {
    let timestamp=Clock::get()?.unix_timestamp;
    ctx.accounts.global_volume_accumulator.update_token_incentives(start_time,end_time,seconds_in_a_day,&ctx.accounts.mint.key(),day_number,token_supply_per_day,timestamp)?;
    let event=AdminUpdateTokenIncentivesEvent{start_time,end_time,day_number,token_supply_per_day,mint:ctx.accounts.mint.key(),seconds_in_a_day,timestamp};
    emit!(event.clone());emit_cpi!(event);
    msg!("GlobalVolumeAccumulator={:?}",ctx.accounts.global_volume_accumulator);
    Ok(())
}
#[event]
#[derive(Clone)]
pub struct SyncUserVolumeAccumulatorEvent{pub user:Pubkey,pub total_claimed_tokens_before:u64,pub total_claimed_tokens_after:u64,pub timestamp:i64}
#[event]
#[derive(Clone)]
pub struct AdminUpdateTokenIncentivesEvent{pub start_time:i64,pub end_time:i64,pub day_number:u64,pub token_supply_per_day:u64,pub mint:Pubkey,pub seconds_in_a_day:i64,pub timestamp:i64}
