from pathlib import Path
import gzip, hashlib, json, shutil
W=Path(__file__).resolve().parent;P=W/'mayhem-current-native';D=P/'variants/origin-only';D.mkdir(parents=True,exist_ok=False)
base=gzip.decompress((P/'sources/src/state.rs.gz').read_bytes()).decode();lines=base.splitlines(True)
assert lines[530].strip()=='let now=Clock::get().unwrap().unix_timestamp;'
assert lines[531]=='\n' and lines[532].strip()=='let state=&mut ctx.accounts.mayhem_state;' and lines[533].strip()=='state.field_8=now as u64;'
assert lines[534].strip()=='state.end_timestamp=now+duration_hours*3600;'
lines[530]=' '*17+lines[530].rstrip('\n')+' '+lines[532].strip()+' '+lines[533].strip()+'\n'
lines[531]=' '*7+lines[534]
lines[532:535]=['\n']*3
after=''.join(lines).encode()
assert b''.join(base.encode().split())==b''.join(after.split()),'non-whitespace source change'
assert base.count('\n')==after.count(b'\n')
for name in ('source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv','path-map.tsv','build.py'):
 shutil.copyfile(P/name,D/name)
shutil.copytree(P/'sources',D/'sources');(D/'sources/src/state.rs.gz').write_bytes(gzip.compress(after,mtime=0))
inputs=json.loads((D/'source-inputs.json').read_bytes())
for row in inputs['source_files']:
 if row['path']=='src/state.rs':row.update(bytes=len(after),sha256=hashlib.sha256(after).hexdigest())
(D/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8',newline='\n')
(D/'edit.json').write_text(json.dumps(dict(label='origin-only',source_file='src/state.rs',before_sha256=hashlib.sha256(base.encode()).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),tokens_ignoring_whitespace_equal=True,source_edit='Whitespace-only initializer origins: Clock unwrap531:43 and signed addition532:32; preserve statement order and all later source lines.',binary_basis='Original O0193 carries two24-byte Rust Source records at the actual overflow and unwrap call sites.'),indent=2)+'\n')
print(D)
