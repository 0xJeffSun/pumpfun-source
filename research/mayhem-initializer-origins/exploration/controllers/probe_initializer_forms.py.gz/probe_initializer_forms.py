from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, sys
W=Path(__file__).resolve().parent;P=W/'mayhem-current-native'
base=gzip.decompress((P/'sources/src/state.rs.gz').read_bytes()).decode()
start=base.index('    let state=&mut ctx.accounts.mayhem_state;',base.index('pub fn initialize('))
end=base.index('    Ok(())',start)
block=base[start:end]
fields='MayhemState {field_8:now as u64,end_timestamp:now+duration_hours*3600,mint:mint_key,field_56:0,field_72:0,flag_88:false,field_89:now as u64,status:MayhemStatus::Variant0,burned_amount:0}'
prekey=base.replace('    let mint=ctx.accounts.mint.to_account_info();','    let mint=ctx.accounts.mint.to_account_info(); let mint_key=mint.key();').replace('state.mint=mint.key();','state.mint=mint_key;')
forms={
 'aggregate-set-inner':prekey.replace(prekey[start:end], '    let state=&mut ctx.accounts.mayhem_state; state.set_inner('+fields+');'+'\n'*block.count('\n')) if False else None,
 'aggregate-assign':None,
 'key-clone-from':prekey.replace('state.mint=mint_key;','state.mint.clone_from(&mint_key);'),
 'key-clone-value':prekey.replace('state.mint=mint_key;','state.mint=mint_key.clone();'),
}
# Locate on the edited string; preceding key declaration changed byte offsets.
a=prekey.index('    let state=&mut ctx.accounts.mayhem_state;',prekey.index('pub fn initialize('));b=prekey.index('    Ok(())',a)
forms['aggregate-set-inner']=prekey[:a]+'    let state=&mut ctx.accounts.mayhem_state; state.set_inner('+fields+');'+'\n'*block.count('\n')+prekey[b:]
forms['aggregate-assign']=prekey[:a]+'    let state=&mut ctx.accounts.mayhem_state; **state='+fields+';'+'\n'*block.count('\n')+prekey[b:]
for label,source in forms.items():
 D=P/'variants'/label;D.mkdir(parents=True,exist_ok=False)
 for name in ('source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv','path-map.tsv','build.py'):
  shutil.copyfile(P/name,D/name)
 shutil.copytree(P/'sources',D/'sources')
 after=source.encode();assert source.count('\n')==base.count('\n')
 (D/'sources/src/state.rs.gz').write_bytes(gzip.compress(after,mtime=0))
 inputs=json.loads((D/'source-inputs.json').read_bytes())
 for row in inputs['source_files']:
  if row['path']=='src/state.rs':row.update(bytes=len(after),sha256=hashlib.sha256(after).hexdigest())
 (D/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8',newline='\n')
 (D/'edit.json').write_text(json.dumps(dict(label=label,before_sha256=hashlib.sha256(base.encode()).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),source_file='src/state.rs',source_edit='Copy mint key before clock, then vary used state assignment spelling; preserve all line counts.',limitation='Aggregate controls relocate panic-origin columns, so require exact body and data verification before acceptance.'),indent=2)+'\n')
 cmd=[sys.executable,'-I','-B',str(D/'build.py'),'--sdk',str(W/'mayhem-native-build/sdk'),'--target-sysroot',str(W/'windows-typeid-probe/linux-sysroot/rust'),'--vendor',str(W/'mayhem-native-build/vendor'),'--msvc','C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207','--windows-sdk','C:/Program Files (x86)/Windows Kits/10','--output',str(D/'build-01')]
 with(D/'controller.stdout.log').open('wb')as out,(D/'controller.stderr.log').open('wb')as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 print(label,'exit',p.returncode,flush=True)
 assert p.returncode==0
 p=subprocess.run([sys.executable,'-I','-B',str(W/'measure_current_native.py')],creationflags=subprocess.CREATE_NO_WINDOW);assert p.returncode==0
