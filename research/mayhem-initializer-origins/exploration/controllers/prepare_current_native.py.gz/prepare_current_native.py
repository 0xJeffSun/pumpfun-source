from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, shutil, subprocess, tarfile, importlib.util

W=Path(__file__).resolve().parent; R=W/'pumpfun-source'; P=W/'mayhem-current-native'
OLD=R/'research/mayhem-native-reference-identity'
REV='15e1a7af2e74ce6fd27c9da3090856415b826279'
PACK='research/mayhem-accounting-extend-recovery'
P.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def save(p,x): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
pins={}
for name in ('source.tar.gz','source-inputs.json','source.patch','builds/recovered/launch.json','builds/recovered/stderr.gz','builds/recovered/result.json','artifacts/recovered/symbols.so.gz','artifacts/recovered/candidate.so.gz','audit.json','functions.tsv','reader.py','README.md'):
 data=subprocess.check_output(['git','show',REV+':'+PACK+'/'+name],cwd=R)
 dest=P/'upstream'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 pins[name]=dict(revision=REV,path=PACK+'/'+name,bytes=len(data),sha256=sha(data),git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
save(P/'upstream-inputs.json',pins)
inventory=json.loads((P/'upstream/source-inputs.json').read_bytes())
sources={}
with tarfile.open(P/'upstream/source.tar.gz','r:gz')as tf:
 for m in tf.getmembers():
  if m.isdir():continue
  assert m.isfile() and m.name not in sources and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,m.name
  sources[m.name]=tf.extractfile(m).read()
assert {n:sha(b)for n,b in sources.items()}==inventory
assert len(sources)==66
for name,data in sources.items():
 dest=P/'sources'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(data,mtime=0))
save(P/'source-inputs.json',dict(revision=REV,source_files=[dict(path=n,bytes=len(b),sha256=sha(b))for n,b in sorted(sources.items())]))
for name in ('sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv'):
 shutil.copyfile(OLD/name,P/name)
spec=importlib.util.spec_from_file_location('prior',OLD/'verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
prior={v.source_key(v.source(a)):a for a in v.published_units(v.raw(OLD/'reference/main-build.log').decode())}
prior.update({v.source_key(v.source(a)):a for a in v.published_units(v.raw(OLD/'reference/source-data-stderr.gz').decode())})
current=v.published_units(gzip.decompress((P/'upstream/builds/recovered/stderr.gz').read_bytes()).decode())
assert len(current)==4
assert all(v.metadata(a)==v.metadata(prior[v.source_key(v.source(a))])and v.signature(a)==v.signature(prior[v.source_key(v.source(a))]) for a in current)
save(P/'current-invocation-binding.json',dict(target_recompilations=len(current),units=[dict(crate=v.value(a,'--crate-name'),source=v.source(a),metadata=v.metadata(a),args=a)for a in current],unchanged_from_retained_metadata=True))
# Re-derive the full-file maps from the current source inventory, including ExtendAccount.
v.HERE=P
names={line.split('\t')[2]for line in(P/'metadata-map.tsv').read_text().splitlines()}
common=['src/lib.rs','src/instruction.rs','src/state.rs','src/syscalls.rs','src/internal.rs','src/encode.rs','src/ser/mod.rs','src/extension/mod.rs','src/account_wrapper.rs']
rows=[]
for name in sorted(names):
 if name=='mayhem_recovered':pairs=[(n,n if n=='src/account_wrapper.rs'else'programs/mayhem-program/'+n)for n in sorted(sources)if n.startswith('src/')and n.endswith('.rs')]
 elif name=='anchor_lang':pairs=[(n,n)for n in sorted(sources)if n.startswith('vendor/anchor-lang/')and n.endswith('.rs')]
 elif name=='curve_accounts':pairs=[(n,n)for n in common]+[(n,n.removeprefix('curve-accounts/'))for n in sorted(sources)if n.startswith('curve-accounts/')and n.endswith('.rs')]
 else:pairs=[(n,n)for n in common]
 rows.extend((name,a,b)for a,b in pairs)
(P/'path-map.tsv').write_text(''.join('\t'.join(r)+'\n'for r in rows),encoding='utf8',newline='\n')
builder=(OLD/'build.py').read_text().replace('cf4fbf7ca12307e14ea9ddee4356217c6ee0dc24d8aff5141fb1962fe8d5210d',sha((P/'path-map.tsv').read_bytes()))
(P/'build.py').write_text(builder,encoding='utf8',newline='\n')
old={r['path']:r['sha256']for r in json.loads((OLD/'source-inputs.json').read_bytes())['source_files']}
save(P/'source-delta.json',dict(changed=[n for n,b in sources.items()if n in old and old[n]!=sha(b)],added=sorted(sources.keys()-old.keys()),removed=sorted(old.keys()-sources.keys())))
print(json.dumps(dict(source_files=66,path_maps=len(rows),target_recompilations=len(current),metadata_unchanged=True)))
