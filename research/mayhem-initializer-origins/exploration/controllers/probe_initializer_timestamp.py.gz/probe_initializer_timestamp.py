from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, sys
W=Path(__file__).resolve().parent;P=W/'mayhem-current-native'
base=gzip.decompress((P/'sources/src/state.rs.gz').read_bytes()).decode()
early=base.replace('    let mint=ctx.accounts.mint.to_account_info();','    let mint=ctx.accounts.mint.to_account_info(); let mint_key=mint.key();').replace('state.mint=mint.key();','state.mint=mint_key;')
lines=early.splitlines(True)
assert lines[530].strip()=='let now=Clock::get().unwrap().unix_timestamp;' and lines[531]=='\n'
lines[530]=' '*17+lines[530]
prefix='let end_timestamp = '
lines[531]=' '*(31-len(prefix))+prefix+'now+duration_hours*3600;\n'
early=''.join(lines).replace('state.end_timestamp=now+duration_hours*3600;','state.end_timestamp=end_timestamp;')
forms={'precomputed-end-timestamp':early}
start=early.index('    let state=&mut ctx.accounts.mayhem_state;',early.index('pub fn initialize('));end=early.index('    Ok(())',start)
fields='MayhemState {field_8:now as u64,end_timestamp,mint:mint_key,field_56:0,field_72:0,flag_88:false,field_89:now as u64,status:MayhemStatus::Variant0,burned_amount:0}'
forms['precomputed-aggregate']=early[:start]+'    let state=&mut ctx.accounts.mayhem_state; state.set_inner('+fields+');'+'\n'*early[start:end].count('\n')+early[end:]
for label,source in forms.items():
 D=P/'variants'/label;D.mkdir(parents=True,exist_ok=False)
 for name in ('source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv','path-map.tsv','build.py'):
  shutil.copyfile(P/name,D/name)
 shutil.copytree(P/'sources',D/'sources')
 after=source.encode();assert source.count('\n')==base.count('\n')
 (D/'sources/src/state.rs.gz').write_bytes(gzip.compress(after,mtime=0))
 inputs=json.loads((D/'source-inputs.json').read_bytes())
 for row in inputs['source_files']:
  if row['path']=='src/state.rs':row.update(bytes=len(after),sha256=hashlib.sha256(after).hexdigest())
 (D/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8',newline='\n')
 (D/'edit.json').write_text(json.dumps(dict(label=label,before_sha256=hashlib.sha256(base.encode()).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),source_file='src/state.rs',source_edit='Copy mint key before clock and compute end timestamp on original panic source line532column32; reproduce unwrap source531column43. Compare field vs aggregate assignment.',binary_basis='Original initializer has error Sources531:43 and532:32, and copies key beforeClock; does not authenticate original source spelling.'),indent=2)+'\n')
 cmd=[sys.executable,'-I','-B',str(D/'build.py'),'--sdk',str(W/'mayhem-native-build/sdk'),'--target-sysroot',str(W/'windows-typeid-probe/linux-sysroot/rust'),'--vendor',str(W/'mayhem-native-build/vendor'),'--msvc','C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207','--windows-sdk','C:/Program Files (x86)/Windows Kits/10','--output',str(D/'build-01')]
 with(D/'controller.stdout.log').open('wb')as out,(D/'controller.stderr.log').open('wb')as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 print(label,'exit',p.returncode,flush=True);assert p.returncode==0
 p=subprocess.run([sys.executable,'-I','-B',str(W/'measure_current_native.py')],creationflags=subprocess.CREATE_NO_WINDOW);assert p.returncode==0
