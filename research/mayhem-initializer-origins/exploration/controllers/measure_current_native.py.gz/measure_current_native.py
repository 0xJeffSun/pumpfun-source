from pathlib import Path
from collections import Counter
import gzip, importlib.util, json, hashlib, difflib
W=Path(__file__).resolve().parent; P=W/'mayhem-current-native'
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
v=mod('prior_verify',W/'pumpfun-source/research/mayhem-native-reference-identity/verify.py')
l=mod('current_layer',P/'upstream/reader.py')
original=l.Elf(W/'mayhem-native-build/comparison/original.so')
inventory=json.loads((W/'mayhem-native-build/comparison/prior-inventory.json').read_bytes())
originals={r['id']:original.window(r['start'],r['end'])for r in inventory['original_rows']}
paths={'current-baseline':P/'build-01/symbols.so'}
for result in sorted((P/'variants').glob('*/build-*/result.json')):
 if json.loads(result.read_bytes())['status']=='SUCCEEDED':paths[result.parent.parent.name+'/'+result.parent.name]=result.parent/'symbols.so'
report={}
for label,path in paths.items():
 elf=l.Elf(path);windows=v.functions(elf);shapes=Counter(v.shape(w)for w in windows.values());hashes={w['raw_sha256']for w in windows.values()}
 matched=sorted(k for k,w in originals.items()if v.shape(w)in shapes);raw=sorted(k for k,w in originals.items()if w['raw_sha256']in hashes)
 symbol=next(s for s in elf.symbols if '5state10initialize' in s['name']);start,end=symbol['value'],symbol['value']+symbol['size'];init=elf.window(start,end);norm=elf.norm(start,end)[0];orig=original.norm(534840,535800)[0]
 row=dict(sha256=hashlib.sha256(elf.b).hexdigest(),bytes=len(elf.b),functions=len(windows),normalized_ids=matched,raw_ids=raw,initializer=dict(start=start,end=end,bytes=end-start,normalized_equal=norm==orig,differing_overlap_bytes=sum(a!=b for a,b in zip(orig,norm)),window=init),new_ids=sorted(set(matched)-set(report.get('current-baseline',{}).get('normalized_ids',matched))),lost_ids=sorted(set(report.get('current-baseline',{}).get('normalized_ids',matched))-set(matched)))
 report[label]=row
 print(label,'matches',len(matched),'raw',len(raw),'init',end-start,'equal',norm==orig,'diff',row['initializer']['differing_overlap_bytes'],'gains',row['new_ids'],'losses',row['lost_ids'],flush=True)
(P/'comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n')
