from pathlib import Path
import gzip, hashlib, json, shutil, subprocess

W=Path(__file__).resolve().parent; P=W/'mayhem-current-native'
label='key-before-clock'; D=P/'variants'/label; D.mkdir(parents=True,exist_ok=False)
for name in ('source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv','path-map.tsv','build.py'):
 shutil.copyfile(P/name,D/name)
shutil.copytree(P/'sources',D/'sources')
path=D/'sources/src/state.rs.gz'; before=gzip.decompress(path.read_bytes()); text=before.decode()
old='    let mint=ctx.accounts.mint.to_account_info();'; new=old+' let mint_key=mint.key();'
assert text.count(old)==1 and text.count('state.mint=mint.key();')==1
text=text.replace(old,new).replace('state.mint=mint.key();','state.mint=mint_key;'); after=text.encode()
assert before.count(b'\n')==after.count(b'\n')
path.write_bytes(gzip.compress(after,mtime=0))
inputs=json.loads((D/'source-inputs.json').read_bytes())
for row in inputs['source_files']:
 if row['path']=='src/state.rs':row.update(bytes=len(after),sha256=hashlib.sha256(after).hexdigest())
(D/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8',newline='\n')
(D/'edit.json').write_text(json.dumps(dict(label=label,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),source_file='src/state.rs',source_edit='Read cloned mint AccountInfo key before Clock::get rather than after it; keep line count and all other source unchanged.',binary_basis='Original O0193 loads and spills all32 key bytes before the Clock syscall; current candidate loads the key after Clock.'),indent=2)+'\n')
print(D)
