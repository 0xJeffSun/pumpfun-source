from pathlib import Path
import gzip,json,shutil,difflib
W=Path(__file__).resolve().parent;P=W/'mayhem-current-native/latest';D=W/'pumpfun-source/research/mayhem-initializer-origins/latest';D.mkdir(exist_ok=True)
def put(n,b):p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for name in ('build.py','wrapper.rs','source-inputs.json','sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','metadata-map.tsv','path-map.tsv'):
 put(name,(P/'corrected'/name).read_bytes())
for p in(P/'corrected/sources').rglob('*.gz'):put('sources/'+p.relative_to(P/'corrected/sources').as_posix(),p.read_bytes())
for p in(P/'parent').rglob('*'):
 if p.is_file():put('parent/'+p.relative_to(P/'parent').as_posix(),p.read_bytes())
put('upstream-inputs.json',(P/'upstream-inputs.json').read_bytes())
old=gzip.decompress((P/'baseline/sources/src/state.rs.gz').read_bytes()).decode();new=gzip.decompress((P/'corrected/sources/src/state.rs.gz').read_bytes()).decode()
put('source.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/src/state.rs',tofile='b/src/state.rs')).encode())
put('overrides/src/state.rs.gz',(P/'corrected/sources/src/state.rs.gz').read_bytes())
for name in ('compose_latest_initializer.py','package_latest_initializer.py'):put('exploration/'+name+'.gz',gzip.compress((W/name).read_bytes(),mtime=0))
put('exploration/compose-attempt01.py.gz',gzip.compress((P/'compose-attempt01.py').read_bytes(),mtime=0))
for label,path in [('baseline',P/'baseline/build-01'),('corrected',P/'corrected/build-01'),('repeat',P/'corrected/build-repeat'),('portable',P/'portable-build')]:
 if not(path/'result.json').is_file():continue
 assert json.loads((path/'result.json').read_bytes())['status']=='SUCCEEDED'
 for p in path.iterdir():
  if p.is_file()and p.suffix in('.json','.log','.so','.exe'):put('builds/'+label+'/'+p.name+'.gz',gzip.compress(p.read_bytes(),mtime=0))
 rows=[json.loads(p.read_bytes())for p in sorted((path/'wrapper-records').glob('*.json'))]
 put('builds/'+label+'/records.json.gz',gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0))
print('Latest builds packaged',len(list((D/'builds').iterdir())))
