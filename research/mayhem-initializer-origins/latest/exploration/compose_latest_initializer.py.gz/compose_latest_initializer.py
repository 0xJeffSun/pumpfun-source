from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile,importlib.util,sys
W=Path(__file__).resolve().parent;R=W/'pumpfun-source';P=W/'mayhem-current-native';L=P/'latest';L.mkdir(exist_ok=True)
REV='a0eff02e';PACK='research/mayhem-trade-source-origins';REV=subprocess.check_output(['git','rev-parse',REV],cwd=R,text=True).strip()
spec=importlib.util.spec_from_file_location('init_verifier',R/'research/mayhem-initializer-origins/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
pins={}
for name in ('source.tar.gz','source-inputs.json','builds/recovered/launch.json','builds/recovered/stderr.gz','builds/recovered/result.json','artifacts/recovered/symbols.so.gz','artifacts/recovered/candidate.so.gz','data.py','data.json','source.patch'):
 b=subprocess.check_output(['git','show',REV+':'+PACK+'/'+name],cwd=R);dest=L/'parent'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);pins['parent/'+name]=dict(revision=REV,path=PACK+'/'+name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
(L/'upstream-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
sources=v.archive_sources((L/'parent/source.tar.gz').read_bytes());assert len(sources)==66
assert {n:v.digest(b)for n,b in sources.items()}==json.loads((L/'parent/source-inputs.json').read_bytes())
old=v.v.published_units(v.raw(P/'upstream/builds/recovered/stderr.gz').decode());new=v.v.published_units(v.raw(L/'parent/builds/recovered/stderr.gz').decode());assert len(old)==len(new)==4
assert sorted((v.v.value(a,'--crate-name'),v.v.metadata(a),v.v.signature(a))for a in old)==sorted((v.v.value(a,'--crate-name'),v.v.metadata(a),v.v.signature(a))for a in new)
for label in ('baseline','corrected'):
 D=L/label;D.mkdir()
 for name in ('sdk-components.json.gz','target-components.json','vendor-inputs.json','host-tools.json','wrapper.rs','metadata-map.tsv','path-map.tsv','build.py'):shutil.copyfile(P/name,D/name)
 current=dict(sources)
 if label=='corrected':current['src/state.rs']=v.corrected_source(sources['src/state.rs'])
 rows=[]
 for name,data in sorted(current.items()):
  dest=D/'sources'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(data,mtime=0));rows.append(dict(path=name,bytes=len(data),sha256=v.digest(data)))
 (D/'source-inputs.json').write_text(json.dumps(dict(revision=REV,source_files=rows),indent=2)+'\n',encoding='utf8',newline='\n')
 cmd=[sys.executable,'-I','-B',str(D/'build.py'),'--sdk',str(W/'mayhem-native-build/sdk'),'--target-sysroot',str(W/'windows-typeid-probe/linux-sysroot/rust'),'--vendor',str(W/'mayhem-native-build/vendor'),'--msvc','C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207','--windows-sdk','C:/Program Files (x86)/Windows Kits/10','--output',str(D/'build-01')]
 with(D/'controller.stdout.log').open('wb')as out,(D/'controller.stderr.log').open('wb')as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 print(label,'exit',p.returncode,flush=True);assert p.returncode==0
 result=json.loads((D/'build-01/result.json').read_bytes());print(json.dumps(result['outputs']),flush=True)
 if label=='baseline':assert (D/'build-01/symbols.so').read_bytes()==v.raw(L/'parent/artifacts/recovered/symbols.so.gz')
