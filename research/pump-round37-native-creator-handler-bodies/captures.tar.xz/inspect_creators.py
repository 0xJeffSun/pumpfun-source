"""Actual entry/wrapper-bound creator bodies and immediate calls; Source records explicit."""
from pathlib import Path
import importlib.util,json,struct,sys
if not __debug__:raise RuntimeError('Assertions required')
W=Path(__file__).resolve().parent;R=W.parent/'pump-recovery-restored433';p=R/'captures/analysis/inventory.py';s=importlib.util.spec_from_file_location('ivcreator',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
D=W/'builds'/sys.argv[1];a=(p.parent/'reference/original.so').read_bytes();b=(D/'unstripped.so').read_bytes();af={r['start']:r for r in json.loads((R/'captures/inventory.json').read_text())['windows']};bf={r['start']:r for r in m.functions(b)};sa,sb=m.sections(a),m.sections(b)
def nf(im,ss,r):return m.normalize(m.body(im,ss,r['start'],r['bytes']),r['start'],ss)
def eq(x,y):return x['bytes']==y['bytes']and nf(a,sa,x)[0]==nf(b,sb,y)[0]
def read(im,ss,ptr,n):
 hits=[q for q in ss.values()if q['addr']>0 and q['addr']<=ptr and ptr+n<=q['addr']+q['size']];assert hits;v=hits[0];o=v['offset']+ptr-v['addr'];return im[o:o+n]
rows=[]
for wrapper,frag,calloff in [(1233936,'8__global11set_creator',632),(1232784,'8__global20set_metaplex_creator',424)]:
 x=af[wrapper];y=next(r for r in bf.values()if any(frag in n for n in r['symbols']));assert eq(x,y)
 u=next(o for o in nf(a,sa,x)[1]if o['kind']=='direct-call'and o['offset']==calloff);v=next(o for o in nf(b,sb,y)[1]if o['kind']=='direct-call'and o['offset']==calloff);x=af[u['target']];y=bf[v['target']];ao=[c for c in nf(a,sa,x)[1]if c['kind']=='direct-call'];bo=[c for c in nf(b,sb,y)[1]if c['kind']=='direct-call'];calls=[]
 for c,d in zip(ao,bo):calls.append(dict(original_offset=c['offset'],candidate_offset=d['offset'],original_target=c['target'],candidate_target=d['target'],original_bytes=af[c['target']]['bytes'],candidate_bytes=bf[d['target']]['bytes'],complete_equal=eq(af[c['target']],bf[d['target']])))
 sources=[]
 for label,im,ss,r,fs in [('original',a,sa,x,af),('candidate',b,sb,y,bf)]:
  raw=m.body(im,ss,r['start'],r['bytes']);norm,ops=nf(im,ss,r)
  for c in ops:
   if c['kind']!='direct-call' or fs[c['target']]['bytes']!=200:continue
   refs=[o for o in ops if o['kind']=='elf-pointer'and max(0,c['offset']-48)<=o['offset']<c['offset']and raw[o['offset']+1]&15==3]
   for o in refs:
    loc=read(im,ss,o['value'],24);ptr,n,line,col=struct.unpack('<QQII',loc)
    if 0<n<512 and 0<line<10000:
     rel=ss['.rel.dyn'];relocs={struct.unpack_from('<QQ',im,k)[0]:struct.unpack_from('<QQ',im,k)[1] for k in range(rel['offset'],rel['offset']+rel['size'],16)};assert relocs[o['value']]==8 and ptr&0xffffffff==0;filename=read(im,ss,ptr>>32,n).decode('utf-8');sources.append(dict(role=label,call_offset=c['offset'],pointer=o['value'],raw_record=loc.hex(),filename=filename,counted_length=n,line=line,column=col))
 rows.append(dict(original=x['start'],candidate=y['start'],original_bytes=x['bytes'],candidate_bytes=y['bytes'],complete_equal=eq(x,y),calls=calls,call_counts=[len(ao),len(bo)],same_offset_complete_callees=len(ao)==len(bo)and all(c['complete_equal']and c['original_offset']==c['candidate_offset']for c in calls),source_records=sources))
out=dict(scope=__doc__,candidate_sha256=m.sha(b),roots=rows,vm_cases=0,whole_equal=a==b);(D/'creator-scope.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
