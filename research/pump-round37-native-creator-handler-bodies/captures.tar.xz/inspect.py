from pathlib import Path
import importlib.util,json,sys
W=Path(__file__).resolve().parent;B=W.parent/'pump-recovery-restored433';p=B/'captures/analysis/inventory.py';s=importlib.util.spec_from_file_location('iv',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);d=W/'builds'/sys.argv[1];r=json.loads((d/'result.json').read_text());assert r['exit_code']==0
j=m.inventory(d/'unstripped.so');old=json.loads((B/'captures/inventory.json').read_text());match=lambda j:{r['start']for r in j['windows']if r['candidates']};raw=lambda j:{r['start']for r in j['windows']if any(c['raw_sha256']==r['raw_sha256']for c in r['candidates'])}
x=dict(candidate=r['candidate_sha256'],symbols=r['unstripped_sha256'],injective=j['injective_normalized'],membership=j['membership_normalized'],raw=j['injective_raw'],gains=sorted(match(j)-match(old)),losses=sorted(match(old)-match(j)),raw_losses=sorted(raw(old)-raw(j)),new_windows=[z for z in j['windows']if z['start']in match(j)-match(old)])
(d/'inventory.json').write_text(json.dumps(j,indent=2)+'\n');(d/'inspection.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
